#!/usr/bin/env python3
"""
Arche GMAO — Panel de gestión de licencias
Uso exclusivo del administrador.
"""
import os, sys, json, datetime, getpass, hashlib

MASTER_KEY_1_HASH = "a3f8b2c1d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1"
MASTER_KEY_2_HASH = "b4c9d3e2f1a0b9c8d7e6f5a4b3c2d1e0f9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4"
MASTER_KEY_3_HASH = "c5d0e4f3a2b1c0d9e8f7a6b5c4d3e2f1a0b9c8d7e6f5a4b3c2d1e0f9a8b7c6d5"
RECORDS_FILE = os.path.expanduser("~/.arche_licenses.json")

def sha256(s): return hashlib.sha256(s.encode()).hexdigest()

def verify_keys():
    print("\n" + "═"*60)
    print("  ARCHE GMAO — Panel de Licencias")
    print("═"*60 + "\n")
    k1 = getpass.getpass("  Clave 1: ")
    if sha256(k1) != MASTER_KEY_1_HASH: print("  ✕ Clave incorrecta"); return False
    k2 = getpass.getpass("  Clave 2: ")
    if sha256(k2) != MASTER_KEY_2_HASH: print("  ✕ Clave incorrecta"); return False
    k3 = getpass.getpass("  Clave 3: ")
    if sha256(k3) != MASTER_KEY_3_HASH: print("  ✕ Clave incorrecta"); return False
    return True

def load_records():
    if not os.path.exists(RECORDS_FILE): return []
    with open(RECORDS_FILE) as f: return json.load(f)

def save_records(records):
    with open(RECORDS_FILE, "w") as f: json.dump(records, f, indent=2)

def list_all():
    records = load_records()
    if not records:
        print("\n  Sin licencias registradas.\n")
        return
    now = datetime.datetime.utcnow()
    print(f"\n  {'#':<4} {'Cliente':<25} {'ID':<20} {'Caduca':<12} {'Estado':<12} {'Generada'}")
    print("  " + "─"*90)
    for i, r in enumerate(records, 1):
        expires = datetime.datetime.fromisoformat(r['expires_at'][:19])
        days_left = (expires - now).days
        if r.get('revoked'):
            status = "REVOCADA"
        elif days_left < 0:
            status = "CADUCADA"
        elif days_left <= 30:
            status = f"⚠ {days_left}d"
        else:
            status = f"✓ {days_left}d"
        print(f"  {i:<4} {r['client_name']:<25} {r['license_id'][:18]:<20} {r['expires_at'][:10]:<12} {status:<12} {r['generated_at'][:10]}")
    print()

def revoke_license():
    records = load_records()
    list_all()
    try:
        idx = int(input("  Número de licencia a revocar: ")) - 1
        rec = records[idx]
    except (ValueError, IndexError):
        print("  Número inválido"); return
    confirm = input(f"  ¿Revocar licencia de '{rec['client_name']}'? (S/N): ")
    if confirm.lower() != 's': print("  Cancelado"); return
    records[idx]['revoked'] = True
    records[idx]['revoked_at'] = datetime.datetime.utcnow().isoformat()
    save_records(records)
    print(f"  ✓ Licencia de '{rec['client_name']}' revocada")
    print(f"  ⚠ El sistema del cliente seguirá funcionando hasta la próxima verificación.")
    print(f"  Para bloqueo inmediato, el administrador debe eliminar /opt/arche-gmao/config/license.key en el servidor del cliente.")

def show_expiring():
    records = load_records()
    now = datetime.datetime.utcnow()
    expiring = []
    for r in records:
        if r.get('revoked'): continue
        expires = datetime.datetime.fromisoformat(r['expires_at'][:19])
        days_left = (expires - now).days
        if 0 <= days_left <= 60:
            expiring.append((days_left, r))
    if not expiring:
        print("\n  Sin licencias próximas a caducar (en los próximos 60 días)\n")
        return
    print(f"\n  Licencias que caducan en los próximos 60 días:")
    print("  " + "─"*60)
    for days, r in sorted(expiring):
        print(f"  ⚠ {r['client_name']:<25} caduca en {days} días ({r['expires_at'][:10]})")
    print()

def main():
    if not verify_keys():
        print("\n  ✕ Acceso denegado\n"); sys.exit(1)

    while True:
        print("\n  ┌─────────────────────────────┐")
        print("  │  Panel de Licencias Arche   │")
        print("  ├─────────────────────────────┤")
        print("  │ 1. Ver todas las licencias  │")
        print("  │ 2. Nueva licencia           │")
        print("  │ 3. Revocar licencia         │")
        print("  │ 4. Próximas a caducar       │")
        print("  │ 5. Salir                    │")
        print("  └─────────────────────────────┘")
        op = input("\n  Opción: ").strip()

        if op == "1":
            list_all()
        elif op == "2":
            # Import the generator
            sys.path.insert(0, os.path.dirname(__file__) + "/../license")
            from generate_license import generate_license, save_license_record
            client_name = input("  Nombre del cliente: ").strip()
            client_id   = input("  ID (sin espacios): ").strip()
            modules_str = input("  Módulos (core,ai,metrics,preventive,qr,reports o all): ").strip()
            modules = [m.strip() for m in modules_str.split(",")]
            max_users   = int(input("  Máx usuarios: ").strip() or "50")
            days        = int(input("  Días de validez: ").strip() or "365")
            result = generate_license(client_name, client_id, modules, max_users, days)
            save_license_record(result)
            fname = f"license_{client_id}.key"
            with open(fname, "w") as f: f.write(result["license_b64"])
            print(f"\n  ✓ Generada: {fname} (caduca: {result['expires_at'][:10]})")
        elif op == "3":
            revoke_license()
        elif op == "4":
            show_expiring()
        elif op == "5":
            print("\n  Hasta luego.\n"); break

if __name__ == "__main__":
    main()
