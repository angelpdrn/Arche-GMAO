# Arche GMAO — Configuración de Claves Maestras

## IMPORTANTE — Lee esto antes de usar el sistema en producción

El sistema usa 3 claves maestras para proteger:
- La generación de licencias
- El cifrado del pendrive
- La instalación en servidores de clientes
- La desinstalación

Las claves hardcodeadas en los scripts son **de ejemplo**. Debes cambiarlas antes de usar el sistema en producción.

---

## Cómo cambiar las claves maestras

### Paso 1 — Elegir tus 3 claves

Cada clave debe ser:
- Al menos 20 caracteres
- Mezcla de letras, números y símbolos
- Diferente para cada persona que la guarda

**Recomendación:** Divide las 3 claves entre 3 personas de confianza. Ninguna persona sola puede generar licencias ni instalar el sistema.

### Paso 2 — Generar los hashes

```bash
# Para cada clave, ejecuta:
echo -n "TuClaveMaestra1AquiCambiar" | sha256sum | awk '{print $1}'
echo -n "TuClaveMaestra2AquiCambiar" | sha256sum | awk '{print $1}'
echo -n "TuClaveMaestra3AquiCambiar" | sha256sum | awk '{print $1}'
```

### Paso 3 — Actualizar los scripts

Sustituye los valores de `MASTER_KEY_X_HASH` en estos archivos:
- `license/generate_license.py`
- `scripts/build_usb.sh`
- `scripts/decrypt_and_install.sh`
- `scripts/uninstall_client.sh`
- `panel/manage_licenses.py`

### Paso 4 — Verificar

```bash
# Probar que las claves funcionan
python3 license/generate_license.py
```

---

## Cómo usar el sistema

### Generar una licencia para un cliente

```bash
python3 license/generate_license.py
# Introduce las 3 claves cuando las pida
# Se genera: license_nombre-cliente.key
```

### Construir el pendrive para un cliente

```bash
bash scripts/build_usb.sh license_nombre-cliente.key
# Introduce las 3 claves cuando las pida
# Se genera: arche_gmao_1.0.0_FECHA.bundle
# Copia ese archivo al pendrive
```

### Instalar en el servidor del cliente

```bash
# En el servidor del cliente, con el pendrive conectado:
sudo bash /media/pendrive/decrypt_and_install.sh arche_gmao_1.0.0_FECHA.bundle
# Introduce las 3 claves cuando las pida
```

### Gestionar licencias

```bash
python3 panel/manage_licenses.py
```

---

## Seguridad del pendrive

El bundle que va en el pendrive está cifrado con AES-256-CBC usando PBKDF2 con 100.000 iteraciones. Sin las 3 claves es computacionalmente imposible descifrarlo.

El hash de integridad SHA-256 garantiza que el bundle no ha sido manipulado.

Si alguien roba el pendrive solo tiene datos cifrados ilegibles.
