#!/bin/bash
# ============================================================
# Arche GMAO — Automatic PostgreSQL backup
# Run by cron: 0 3 * * *
# ============================================================

INSTALL_DIR="/opt/arche-gmao"
BACKUP_DIR="${INSTALL_DIR}/backups"
RETENTION_DAYS=30
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="${BACKUP_DIR}/arche_${DATE}.sql.gz"

mkdir -p "$BACKUP_DIR"

echo "[$(date)] Iniciando backup..."

# PostgreSQL dump
docker compose -f "${INSTALL_DIR}/docker-compose.yml" \
    exec -T postgres \
    pg_dump -U arche arche | gzip > "$BACKUP_FILE"

if [ $? -eq 0 ]; then
    SIZE=$(du -sh "$BACKUP_FILE" | awk '{print $1}')
    echo "[$(date)] ✓ Backup completado: $BACKUP_FILE ($SIZE)"
else
    echo "[$(date)] ✕ Error en el backup"
    rm -f "$BACKUP_FILE"
    exit 1
fi

# Remove old backups
find "$BACKUP_DIR" -name "arche_*.sql.gz" -mtime +${RETENTION_DAYS} -delete
KEPT=$(ls "$BACKUP_DIR"/*.sql.gz 2>/dev/null | wc -l)
echo "[$(date)] Backups conservados: $KEPT (retención: ${RETENTION_DAYS} días)"

# Check free space
FREE_GB=$(df -BG "$BACKUP_DIR" | awk 'NR==2{print $4}' | tr -d 'G')
if [ "${FREE_GB:-0}" -lt 5 ]; then
    echo "[$(date)] ⚠ AVISO: Menos de 5GB libres en disco"
fi
