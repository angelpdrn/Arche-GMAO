'use strict';

let currentStep = 0;
const totalSteps = 8;
let systemChecks = {};
let installerState = {
  operation: 'install',
  config: {},
  modules: [],
  license: null,
  licenseContent: ''
};

// ─── Navigation ─────────────────────────────────────────────────────────────

function showStep(step) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.steps-bar .step').forEach((s, i) => {
    s.classList.remove('active');
    if (i < step) s.classList.add('done');
    else s.classList.remove('done');
  });

  const panel = document.querySelector(`[data-panel="${step}"]`);
  if (panel) panel.classList.add('active');

  const stepEl = document.querySelector(`.step[data-step="${step}"]`);
  if (stepEl) stepEl.classList.add('active');

  const btnBack = document.getElementById('btnBack');
  const btnNext = document.getElementById('btnNext');

  btnBack.style.visibility = step === 0 ? 'hidden' : 'visible';

  if (step === 7) {
    btnBack.style.display = 'none';
    btnNext.style.display = 'none';
  } else if (step === 6) {
    btnNext.textContent = installerState.operation === 'uninstall' ? 'Desinstalar' : 'Instalar';
    btnNext.className = installerState.operation === 'uninstall' ? 'btn btn-danger' : 'btn btn-primary';
    btnBack.style.display = '';
    btnNext.style.display = '';
  } else {
    btnNext.textContent = 'Siguiente';
    btnNext.className = 'btn btn-primary';
    btnBack.style.display = '';
    btnNext.style.display = '';
  }

  currentStep = step;
}

function nextStep() {
  if (currentStep === 1) {
    collectOperation();
  }
  if (currentStep === 2 && !validateChecks()) return;
  if (currentStep === 3) collectConfig();
  if (currentStep === 4) collectModules();
  if (currentStep === 5) collectLicense();
  if (currentStep === 6) {
    startInstallation();
    showStep(7);
    return;
  }

  const next = getNextStep(currentStep);
  if (next < totalSteps) {
    showStep(next);
    if (next === 2) runSystemChecks();
    if (next === 6) buildSummary();
  }
}

function prevStep() {
  const prev = getPrevStep(currentStep);
  if (prev >= 0) showStep(prev);
}

function getNextStep(from) {
  const op = installerState.operation;
  if (op === 'uninstall') {
    if (from === 1) return 6;
  }
  if (op === 'update') {
    if (from === 2) return 5;
  }
  return from + 1;
}

function getPrevStep(from) {
  const op = installerState.operation;
  if (op === 'uninstall') {
    if (from === 6) return 1;
  }
  if (op === 'update') {
    if (from === 5) return 2;
  }
  return from - 1;
}

// ─── Operation cards ────────────────────────────────────────────────────────

document.querySelectorAll('.option-card').forEach(card => {
  card.addEventListener('click', () => {
    document.querySelectorAll('.option-card').forEach(c => c.classList.remove('selected'));
    card.classList.add('selected');
    card.querySelector('input').checked = true;
  });
});

function collectOperation() {
  const checked = document.querySelector('input[name="operation"]:checked');
  installerState.operation = checked ? checked.value : 'install';
}

// ─── System checks ──────────────────────────────────────────────────────────

async function runSystemChecks() {
  const items = document.querySelectorAll('.check-item');
  items.forEach(item => {
    item.className = 'check-item loading';
    item.querySelector('.check-status').textContent = '◻';
    item.querySelector('.check-detail').textContent = '';
  });
  document.getElementById('checksSummary').className = 'checks-summary';

  try {
    const res = await fetch('/api/checks');
    const data = await res.json();
    systemChecks = data;

    updateCheck('os', data.os);
    updateCheck('docker', data.docker);
    updateCheck('compose', data.compose);
    updateCheck('ram', data.ram);
    updateCheck('disk', data.disk);
    updateCheck('ports', data.ports);
    updateCheck('existing', data.existing);

    const summary = document.getElementById('checksSummary');
    if (data.can_proceed) {
      if (data.has_warnings) {
        summary.className = 'checks-summary warning';
        summary.textContent = 'Hay advertencias, pero puede continuar con la instalacion.';
      } else {
        summary.className = 'checks-summary ok';
        summary.textContent = 'Todas las verificaciones superadas. El sistema esta listo.';
      }
    } else {
      summary.className = 'checks-summary error';
      summary.textContent = 'Hay errores que impiden la instalacion. Corrija los problemas indicados e intente de nuevo.';
    }

    if (data.detected_ip) {
      document.getElementById('cfgDomain').placeholder = data.detected_ip;
    }

    if (data.suggested_http) {
      const httpInput = document.getElementById('cfgHttpPort');
      httpInput.value = data.suggested_http;
      const httpHint = document.getElementById('httpPortHint');
      if (data.suggested_http !== 80) {
        httpHint.textContent = 'Puerto 80 ocupado. Se asigno ' + data.suggested_http + ' automaticamente.';
        httpHint.style.color = 'var(--warning)';
      } else {
        httpHint.textContent = 'Puerto estandar disponible.';
      }
    }
    if (data.suggested_https) {
      const httpsInput = document.getElementById('cfgHttpsPort');
      httpsInput.value = data.suggested_https;
      const httpsHint = document.getElementById('httpsPortHint');
      if (data.suggested_https !== 443) {
        httpsHint.textContent = 'Puerto 443 ocupado. Se asigno ' + data.suggested_https + ' automaticamente.';
        httpsHint.style.color = 'var(--warning)';
      } else {
        httpsHint.textContent = 'Puerto estandar disponible.';
      }
    }
  } catch (err) {
    document.getElementById('checksSummary').className = 'checks-summary error';
    document.getElementById('checksSummary').textContent = 'Error conectando con el servidor: ' + err.message;
  }
}

function updateCheck(name, check) {
  const item = document.querySelector(`[data-check="${name}"]`);
  if (!item || !check) return;

  item.classList.remove('loading');
  const status = item.querySelector('.check-status');
  const detail = item.querySelector('.check-detail');

  if (check.status === 'ok') {
    item.classList.add('pass');
    status.textContent = '✓';
  } else if (check.status === 'warn') {
    item.classList.add('warn');
    status.textContent = '▦';
  } else {
    item.classList.add('fail');
    status.textContent = '✕';
  }

  detail.textContent = check.detail || '';
}

function validateChecks() {
  if (!systemChecks.can_proceed) {
    const summary = document.getElementById('checksSummary');
    summary.className = 'checks-summary error';
    summary.textContent = 'Corrija los errores antes de continuar.';
    return false;
  }
  return true;
}

// ─── Config collection ──────────────────────────────────────────────────────

function collectConfig() {
  installerState.config = {
    domain: document.getElementById('cfgDomain').value || document.getElementById('cfgDomain').placeholder,
    http_port: parseInt(document.getElementById('cfgHttpPort').value) || 80,
    https_port: parseInt(document.getElementById('cfgHttpsPort').value) || 443,
    db_password: document.getElementById('cfgDbPassword').value,
    redis_password: document.getElementById('cfgRedisPassword').value,
    jwt_secret: document.getElementById('cfgJwtSecret').value,
    jwt_refresh: document.getElementById('cfgJwtRefresh').value,
    ollama_url: document.getElementById('cfgOllamaUrl').value,
    install_dir: document.getElementById('cfgInstallDir').value || '/opt/arche-gmao'
  };
}

function collectModules() {
  const checked = document.querySelectorAll('input[name="modules"]:checked');
  installerState.modules = Array.from(checked).map(c => c.value);
}

// ─── License ────────────────────────────────────────────────────────────────

document.getElementById('licenseFile').addEventListener('change', function(e) {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function(ev) {
    installerState.licenseContent = ev.target.result;
    document.getElementById('uploadFilename').textContent = file.name;
    document.getElementById('uploadZone').classList.add('has-file');
    decodeLicense(ev.target.result);
  };
  reader.readAsText(file);
});

const uploadZone = document.getElementById('uploadZone');
uploadZone.addEventListener('dragover', e => { e.preventDefault(); uploadZone.style.borderColor = 'var(--primary)'; });
uploadZone.addEventListener('dragleave', () => { uploadZone.style.borderColor = ''; });
uploadZone.addEventListener('drop', e => {
  e.preventDefault();
  uploadZone.style.borderColor = '';
  const file = e.dataTransfer.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = function(ev) {
      installerState.licenseContent = ev.target.result;
      document.getElementById('uploadFilename').textContent = file.name;
      uploadZone.classList.add('has-file');
      decodeLicense(ev.target.result);
    };
    reader.readAsText(file);
  }
});

document.getElementById('licensePaste').addEventListener('input', function() {
  const val = this.value.trim();
  if (val.length > 50) {
    installerState.licenseContent = val;
    decodeLicense(val);
  }
});

function decodeLicense(content) {
  try {
    const decoded = JSON.parse(atob(content.trim()));
    const payload = typeof decoded.payload === 'string' ? JSON.parse(decoded.payload) : decoded.payload;

    installerState.license = payload;

    const info = document.getElementById('licenseInfo');
    const details = document.getElementById('licenseDetails');
    info.style.display = 'block';

    details.innerHTML = `
      <div><strong>Cliente:</strong> ${payload.client_name || payload.ClientName || '—'}</div>
      <div><strong>ID:</strong> ${payload.client_id || payload.ClientID || '—'}</div>
      <div><strong>Modulos:</strong> ${(payload.modules || payload.Modules || []).join(', ')}</div>
      <div><strong>Max usuarios:</strong> ${payload.max_users || payload.MaxUsers || '—'}</div>
      <div><strong>Max nodos:</strong> ${payload.max_nodes || payload.MaxNodes || '—'}</div>
      <div><strong>Caduca:</strong> ${(payload.expires_at || payload.ExpiresAt || '—').substring(0, 10)}</div>
    `;
  } catch (e) {
    document.getElementById('licenseInfo').style.display = 'none';
  }
}

function collectLicense() {
  const skip = document.getElementById('skipLicense').checked;
  if (skip) {
    installerState.licenseContent = '';
    installerState.license = null;
  }
}

// ─── Password generator ─────────────────────────────────────────────────────

function generatePassword(fieldId, length) {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const array = new Uint8Array(length);
  crypto.getRandomValues(array);
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars[array[i] % chars.length];
  }
  const field = document.getElementById(fieldId);
  field.value = result;
  field.type = 'text';
  setTimeout(() => { field.type = 'password'; }, 2000);
}

// ─── Summary ────────────────────────────────────────────────────────────────

function buildSummary() {
  const grid = document.getElementById('summaryGrid');
  const op = installerState.operation;

  if (op === 'uninstall') {
    grid.innerHTML = `
      <div class="summary-card" style="grid-column: span 2">
        <h4>Desinstalacion</h4>
        <div class="row"><span class="label">Operacion</span><span class="value" style="color: var(--danger)">Desinstalar Arche GMAO</span></div>
        <div class="row"><span class="label">Directorio</span><span class="value">/opt/arche-gmao</span></div>
        <div class="row"><span class="label">Datos</span><span class="value">Se pedira confirmacion para eliminar datos</span></div>
      </div>`;
    return;
  }

  const cfg = installerState.config;
  const mods = installerState.modules;
  const lic = installerState.license;

  grid.innerHTML = `
    <div class="summary-card">
      <h4>Operacion</h4>
      <div class="row"><span class="label">Tipo</span><span class="value">${op === 'install' ? 'Instalacion nueva' : 'Actualizacion'}</span></div>
      <div class="row"><span class="label">Directorio</span><span class="value">${cfg.install_dir || '/opt/arche-gmao'}</span></div>
    </div>
    <div class="summary-card">
      <h4>Red</h4>
      <div class="row"><span class="label">Servidor</span><span class="value">${cfg.domain || 'Auto-detectado'}</span></div>
      <div class="row"><span class="label">Puerto HTTP</span><span class="value">${cfg.http_port || 80}</span></div>
      <div class="row"><span class="label">Puerto HTTPS</span><span class="value">${cfg.https_port || 443}</span></div>
    </div>
    <div class="summary-card">
      <h4>Modulos (${mods.length})</h4>
      ${mods.map(m => `<div class="row"><span class="value">${moduleLabel(m)}</span></div>`).join('')}
    </div>
    <div class="summary-card">
      <h4>Licencia</h4>
      ${lic ? `
        <div class="row"><span class="label">Cliente</span><span class="value">${lic.client_name || lic.ClientName || '—'}</span></div>
        <div class="row"><span class="label">Caduca</span><span class="value">${(lic.expires_at || lic.ExpiresAt || '').substring(0, 10)}</span></div>
      ` : `<div class="row"><span class="value" style="color: var(--warning)">Modo evaluacion (72h)</span></div>`}
    </div>
    <div class="summary-card">
      <h4>Seguridad</h4>
      <div class="row"><span class="label">Contrasena BD</span><span class="value">${cfg.db_password ? '••••••••' : 'Auto-generada'}</span></div>
      <div class="row"><span class="label">JWT</span><span class="value">${cfg.jwt_secret ? '••••••••' : 'Auto-generado'}</span></div>
      <div class="row"><span class="label">Redis</span><span class="value">${cfg.redis_password ? '••••••••' : 'Auto-generada'}</span></div>
    </div>
    <div class="summary-card">
      <h4>IA</h4>
      <div class="row"><span class="label">Ollama</span><span class="value">${cfg.ollama_url || 'http://host-gateway:11434'}</span></div>
      <div class="row"><span class="label">Activada</span><span class="value">${mods.includes('ai') ? 'Si' : 'No'}</span></div>
    </div>
  `;
}

function moduleLabel(key) {
  const labels = {
    core: 'Core (OTs, Fabrica, Inventario)',
    ai: 'Arche IA con RAG',
    preventive: 'Mantenimiento preventivo',
    metrics: 'Metricas y KPIs',
    qr: 'Codigos QR',
    reports: 'Informes PDF/Excel'
  };
  return labels[key] || key;
}

// ─── Installation ───────────────────────────────────────────────────────────

async function startInstallation() {
  const logEl = document.getElementById('progressLog');
  const fillEl = document.getElementById('progressFill');
  const pctEl = document.getElementById('progressPct');
  const phaseEl = document.getElementById('progressPhase');
  const titleEl = document.getElementById('progressTitle');

  logEl.innerHTML = '';

  const opLabels = {
    install: 'Instalando Arche GMAO',
    update: 'Actualizando Arche GMAO',
    uninstall: 'Desinstalando Arche GMAO'
  };
  titleEl.textContent = opLabels[installerState.operation] || 'Procesando...';

  try {
    const body = {
      operation: installerState.operation,
      config: installerState.config,
      modules: installerState.modules,
      license_content: installerState.licenseContent
    };

    const response = await fetch('/api/execute', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop();

      for (const line of lines) {
        if (!line.startsWith('data: ')) continue;
        const raw = line.slice(6);
        if (raw === '') continue;

        try {
          const evt = JSON.parse(raw);

          if (evt.type === 'progress') {
            fillEl.style.width = evt.percent + '%';
            pctEl.textContent = evt.percent + '%';
            phaseEl.textContent = evt.phase || '';
          }

          if (evt.type === 'log') {
            const cls = evt.level === 'ok' ? 'log-ok' : evt.level === 'error' ? 'log-err' : evt.level === 'warn' ? 'log-warn' : 'log-info';
            logEl.innerHTML += `<div class="log-line ${cls}">${escapeHtml(evt.message)}</div>`;
            logEl.scrollTop = logEl.scrollHeight;
          }

          if (evt.type === 'complete') {
            fillEl.style.width = '100%';
            pctEl.textContent = '100%';
            phaseEl.textContent = '';
            document.getElementById('installComplete').style.display = 'block';

            const info = document.getElementById('completeInfo');
            info.innerHTML = `
              <div><strong>URL:</strong> http://${evt.url || installerState.config.domain || 'localhost'}</div>
              <div><strong>Directorio:</strong> ${evt.install_dir || installerState.config.install_dir || '/opt/arche-gmao'}</div>
              <div><strong>Usuario:</strong> admin@arche.local</div>
              ${evt.admin_password ? `<div><strong>Contrasena:</strong> ${evt.admin_password}</div>` : ''}
              <div style="margin-top: 8px; color: var(--warning); font-size: 12px;">Guarde estas credenciales en un lugar seguro.</div>
            `;

            const link = document.getElementById('completeLink');
            link.href = 'http://' + (evt.url || installerState.config.domain || 'localhost');
          }

          if (evt.type === 'error') {
            document.getElementById('installError').style.display = 'block';
            document.getElementById('errorMessage').textContent = evt.message;
          }
        } catch (e) {
          // skip malformed events
        }
      }
    }
  } catch (err) {
    document.getElementById('installError').style.display = 'block';
    document.getElementById('errorMessage').textContent = 'Error de conexion: ' + err.message;
  }
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ─── Init ───────────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
  showStep(0);

  fetch('/api/info')
    .then(r => r.json())
    .then(info => {
      if (info.version) {
        document.getElementById('versionBadge').textContent = 'v' + info.version;
      }
    })
    .catch(() => {});
});
