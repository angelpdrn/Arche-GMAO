module arche-gmao/installer

go 1.24.0
