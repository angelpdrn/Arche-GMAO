package main

import (
	"embed"
	"encoding/json"
	"fmt"
	"io/fs"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"runtime"
	"strconv"
	"strings"
	"time"
)

//go:embed web/*
var webFS embed.FS

const version = "1.3.1"

func main() {
	port := "9090"
	if p := os.Getenv("INSTALLER_PORT"); p != "" {
		port = p
	}

	mux := http.NewServeMux()

	webContent, _ := fs.Sub(webFS, "web")
	mux.Handle("/", http.FileServer(http.FS(webContent)))

	mux.HandleFunc("/api/info", handleInfo)
	mux.HandleFunc("/api/checks", handleChecks)
	mux.HandleFunc("/api/execute", handleExecute)

	addr := ":" + port
	log.Printf("[ARCHE INSTALLER] Servidor iniciado en http://localhost%s", addr)

	go openBrowser("http://localhost:" + port)

	if err := http.ListenAndServe(addr, mux); err != nil {
		log.Fatalf("[ARCHE INSTALLER] Error: %v", err)
	}
}

func openBrowser(url string) {
	time.Sleep(500 * time.Millisecond)
	var cmd *exec.Cmd
	switch runtime.GOOS {
	case "linux":
		cmd = exec.Command("xdg-open", url)
	case "darwin":
		cmd = exec.Command("open", url)
	case "windows":
		cmd = exec.Command("rundll32", "url.dll,FileProtocolHandler", url)
	}
	if cmd != nil {
		cmd.Start()
	}
}

// ─── Info ───────────────────────────────────────────────────────────────────

func handleInfo(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, map[string]string{
		"version": version,
		"os":      runtime.GOOS,
		"arch":    runtime.GOARCH,
	})
}

// ─── System checks ─────────────────────────────────────────────────────────

type checkResult struct {
	Status string `json:"status"`
	Detail string `json:"detail"`
}

func handleChecks(w http.ResponseWriter, r *http.Request) {
	result := map[string]interface{}{}
	canProceed := true
	hasWarnings := false

	// OS
	if runtime.GOOS == "linux" {
		result["os"] = checkResult{"ok", detectDistro()}
	} else {
		result["os"] = checkResult{"warn", runtime.GOOS + " (no oficial, recomendado Linux)"}
		hasWarnings = true
	}

	// Docker
	if out, err := runCmd("docker", "--version"); err == nil {
		v := strings.TrimSpace(out)
		if idx := strings.Index(v, ","); idx > 0 {
			v = v[:idx]
		}
		result["docker"] = checkResult{"ok", v}
	} else {
		result["docker"] = checkResult{"fail", "No instalado"}
		canProceed = false
	}

	// Docker Compose
	if out, err := runCmd("docker", "compose", "version"); err == nil {
		result["compose"] = checkResult{"ok", strings.TrimSpace(out)}
	} else if out, err := runCmd("docker-compose", "--version"); err == nil {
		result["compose"] = checkResult{"ok", strings.TrimSpace(out)}
	} else {
		result["compose"] = checkResult{"fail", "No disponible"}
		canProceed = false
	}

	// RAM
	ramGB := getRAMGB()
	if ramGB >= 2.0 {
		result["ram"] = checkResult{"ok", fmt.Sprintf("%.1f GB", ramGB)}
	} else if ramGB > 0 {
		result["ram"] = checkResult{"fail", fmt.Sprintf("%.1f GB (minimo 2 GB)", ramGB)}
		canProceed = false
	} else {
		result["ram"] = checkResult{"warn", "No se pudo detectar"}
		hasWarnings = true
	}

	// Disk
	diskGB := getFreeDiskGB("/opt")
	if diskGB >= 10.0 {
		result["disk"] = checkResult{"ok", fmt.Sprintf("%.1f GB libres", diskGB)}
	} else if diskGB > 0 {
		result["disk"] = checkResult{"warn", fmt.Sprintf("%.1f GB libres (recomendado 10 GB)", diskGB)}
		hasWarnings = true
	} else {
		result["disk"] = checkResult{"warn", "No se pudo detectar"}
		hasWarnings = true
	}

	// Ports
	portsOk := true
	portDetails := []string{}
	for _, p := range []int{80, 443} {
		if isPortFree(p) {
			portDetails = append(portDetails, fmt.Sprintf("%d libre", p))
		} else {
			portDetails = append(portDetails, fmt.Sprintf("%d ocupado", p))
			portsOk = false
		}
	}
	if portsOk {
		result["ports"] = checkResult{"ok", strings.Join(portDetails, ", ")}
	} else {
		result["ports"] = checkResult{"warn", strings.Join(portDetails, ", ") + " (se reasignaran)"}
		hasWarnings = true
	}

	// Existing installation
	if _, err := os.Stat("/opt/arche-gmao/docker-compose.yml"); err == nil {
		result["existing"] = checkResult{"warn", "Instalacion encontrada en /opt/arche-gmao"}
		hasWarnings = true
	} else {
		result["existing"] = checkResult{"ok", "No hay instalacion previa"}
	}

	// Detected IP
	detectedIP := detectLANIP()
	result["detected_ip"] = detectedIP
	result["can_proceed"] = canProceed
	result["has_warnings"] = hasWarnings

	writeJSON(w, result)
}

// ─── Execute installation ───────────────────────────────────────────────────

type executeRequest struct {
	Operation      string            `json:"operation"`
	Config         map[string]string `json:"config"`
	Modules        []string          `json:"modules"`
	LicenseContent string            `json:"license_content"`
}

func handleExecute(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "POST requerido", 405)
		return
	}

	var req executeRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "JSON invalido", 400)
		return
	}

	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache")
	w.Header().Set("Connection", "keep-alive")
	flusher, _ := w.(http.Flusher)

	send := func(evt interface{}) {
		data, _ := json.Marshal(evt)
		fmt.Fprintf(w, "data: %s\n\n", data)
		if flusher != nil {
			flusher.Flush()
		}
	}

	sendLog := func(level, msg string) {
		send(map[string]string{"type": "log", "level": level, "message": msg})
	}

	sendProgress := func(pct int, phase string) {
		send(map[string]interface{}{"type": "progress", "percent": pct, "phase": phase})
	}

	switch req.Operation {
	case "install":
		executeInstall(req, sendLog, sendProgress, send)
	case "update":
		executeUpdate(req, sendLog, sendProgress, send)
	case "uninstall":
		executeUninstall(req, sendLog, sendProgress, send)
	default:
		send(map[string]string{"type": "error", "message": "Operacion desconocida: " + req.Operation})
	}
}

func executeInstall(req executeRequest, sendLog func(string, string), sendProgress func(int, string), send func(interface{})) {
	installDir := req.Config["install_dir"]
	if installDir == "" {
		installDir = "/opt/arche-gmao"
	}
	domain := req.Config["domain"]
	if domain == "" {
		domain = detectLANIP()
	}
	httpPort := req.Config["http_port"]
	if httpPort == "" {
		httpPort = "80"
	}

	// Phase 1: Check the prerequisites
	sendProgress(5, "Verificando prerequisitos...")
	sendLog("info", "Verificando Docker...")
	if _, err := runCmd("docker", "--version"); err != nil {
		sendLog("warn", "Docker no encontrado. Intentando instalar...")
		if _, err := runCmdShell("curl -fsSL https://get.docker.com | sh"); err != nil {
			send(map[string]string{"type": "error", "message": "No se pudo instalar Docker: " + err.Error()})
			return
		}
		runCmdShell("systemctl enable docker && systemctl start docker")
		sendLog("ok", "Docker instalado correctamente")
	} else {
		sendLog("ok", "Docker disponible")
	}

	// Phase 2: Create the directory
	sendProgress(10, "Creando directorio de instalacion...")
	dirs := []string{
		installDir,
		installDir + "/data/postgres",
		installDir + "/data/redis",
		installDir + "/data/uploads",
		installDir + "/backups",
		installDir + "/config",
		installDir + "/config/ssl",
		installDir + "/logs",
	}
	for _, d := range dirs {
		os.MkdirAll(d, 0755)
	}
	sendLog("ok", "Directorio creado: "+installDir)

	// Phase 3: Generate secrets
	sendProgress(20, "Generando secretos de seguridad...")
	dbPass := req.Config["db_password"]
	if dbPass == "" {
		dbPass = generateSecret(32)
	}
	redisPass := req.Config["redis_password"]
	if redisPass == "" {
		redisPass = generateSecret(24)
	}
	jwtSecret := req.Config["jwt_secret"]
	if jwtSecret == "" {
		jwtSecret = generateSecret(64)
	}
	jwtRefresh := req.Config["jwt_refresh"]
	if jwtRefresh == "" {
		jwtRefresh = generateSecret(64)
	}
	sendLog("ok", "Secretos generados (DB, Redis, JWT)")

	// Phase 4: Create .env
	sendProgress(30, "Generando configuracion...")
	ollamaURL := req.Config["ollama_url"]
	if ollamaURL == "" {
		ollamaURL = "http://host-gateway:11434"
	}

	envContent := fmt.Sprintf(`POSTGRES_DB=arche
POSTGRES_USER=arche
POSTGRES_PASSWORD=%s
JWT_SECRET=%s
JWT_REFRESH_SECRET=%s
REDIS_PASSWORD=%s
APP_BASE_URL=http://%s
APP_ENV=production
ARCHE_LICENSE_PATH=/app/config/license.key
OLLAMA_URL=%s
HTTP_PORT=%s
HTTPS_PORT=%s
GOMAXPROCS=2
DB_MAX_CONNS=15
`, dbPass, jwtSecret, jwtRefresh, redisPass, domain, ollamaURL, httpPort, req.Config["https_port"])

	envPath := installDir + "/config/.env"
	if err := os.WriteFile(envPath, []byte(envContent), 0600); err != nil {
		send(map[string]string{"type": "error", "message": "Error escribiendo .env: " + err.Error()})
		return
	}
	sendLog("ok", "Archivo .env creado")

	// Phase 5: Copy docker-compose.yml
	sendProgress(40, "Preparando Docker Compose...")
	composeSrc := findComposeFile()
	if composeSrc != "" {
		data, err := os.ReadFile(composeSrc)
		if err == nil {
			os.WriteFile(installDir+"/docker-compose.yml", data, 0644)
			sendLog("ok", "docker-compose.yml copiado")
		}
	} else {
		sendLog("warn", "docker-compose.yml no encontrado. Debera copiarlo manualmente.")
	}

	// Phase 6: Copy nginx.conf
	sendProgress(45, "Configurando Nginx...")
	nginxSrc := findNginxConf()
	if nginxSrc != "" {
		data, _ := os.ReadFile(nginxSrc)
		os.WriteFile(installDir+"/config/nginx.conf", data, 0644)
		sendLog("ok", "nginx.conf copiado")
	}

	// Phase 7: Copy backup.sh
	sendProgress(48, "Configurando backups...")
	backupSrc := findBackupScript()
	if backupSrc != "" {
		data, _ := os.ReadFile(backupSrc)
		os.WriteFile(installDir+"/backup.sh", data, 0755)
		sendLog("ok", "Script de backup copiado")
	}

	// Phase 8: License
	sendProgress(50, "Configurando licencia...")
	if req.LicenseContent != "" {
		os.WriteFile(installDir+"/config/license.key", []byte(req.LicenseContent), 0600)
		sendLog("ok", "Archivo de licencia instalado")
	} else {
		sendLog("warn", "Sin licencia. El sistema funcionara en modo evaluacion (72 horas)")
	}

	// Phase 9: Copy the binary (when present)
	sendProgress(55, "Copiando binario del servidor...")
	binarySrc := findBinary()
	if binarySrc != "" {
		data, _ := os.ReadFile(binarySrc)
		os.WriteFile(installDir+"/arche-server", data, 0755)
		sendLog("ok", "Binario arche-server copiado")
	} else {
		sendLog("info", "Binario no encontrado localmente (se usara imagen Docker)")
	}

	// Phase 10: Start the containers
	sendProgress(60, "Iniciando contenedores Docker...")
	sendLog("info", "Esto puede tardar varios minutos la primera vez...")
	composeFile := installDir + "/docker-compose.yml"
	if _, err := os.Stat(composeFile); err == nil {
		out, err := runCmdShell(fmt.Sprintf("cd %s && docker compose --env-file config/.env up -d 2>&1", installDir))
		if err != nil {
			sendLog("warn", "docker compose up: "+out)
			out2, err2 := runCmdShell(fmt.Sprintf("cd %s && docker-compose --env-file config/.env up -d 2>&1", installDir))
			if err2 != nil {
				sendLog("error", "Error iniciando contenedores: "+out2)
			}
		} else {
			sendLog("ok", "Contenedores iniciados")
		}
	} else {
		sendLog("warn", "No hay docker-compose.yml. Omitiendo arranque de contenedores.")
	}

	// Phase 11: Wait for startup
	sendProgress(75, "Esperando a que el sistema arranque...")
	ready := false
	for i := 0; i < 30; i++ {
		time.Sleep(2 * time.Second)
		pct := 75 + (i * 15 / 30)
		sendProgress(pct, fmt.Sprintf("Esperando... (%d/60s)", (i+1)*2))
		if out, err := runCmdShell(fmt.Sprintf("cd %s && docker compose ps 2>&1", installDir)); err == nil && strings.Contains(out, "Up") {
			ready = true
			break
		}
	}
	if ready {
		sendLog("ok", "Sistema arrancado correctamente")
	} else {
		sendLog("warn", "El sistema puede tardar mas en arrancar. Verifique con: docker compose logs")
	}

	// Phase 12: Configure systemd
	sendProgress(92, "Configurando servicio del sistema...")
	serviceContent := fmt.Sprintf(`[Unit]
Description=Arche GMAO CMMS
After=docker.service
Requires=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=%s
ExecStart=/usr/bin/docker compose --env-file config/.env up -d
ExecStop=/usr/bin/docker compose down
TimeoutStartSec=300

[Install]
WantedBy=multi-user.target
`, installDir)

	if err := os.WriteFile("/etc/systemd/system/arche-gmao.service", []byte(serviceContent), 0644); err != nil {
		sendLog("warn", "No se pudo crear servicio systemd (requiere root): "+err.Error())
	} else {
		runCmdShell("systemctl daemon-reload && systemctl enable arche-gmao")
		sendLog("ok", "Servicio systemd configurado (arranque automatico)")
	}

	// Phase 13: Backup cron
	sendProgress(95, "Configurando backups automaticos...")
	cronLine := fmt.Sprintf("0 3 * * * %s/backup.sh >> %s/logs/backup.log 2>&1", installDir, installDir)
	runCmdShell(fmt.Sprintf(`(crontab -l 2>/dev/null | grep -v arche-gmao; echo "%s") | crontab -`, cronLine))
	sendLog("ok", "Backup diario a las 03:00 configurado")

	// Phase 14: Hardware fingerprint
	sendProgress(97, "Registrando hardware...")
	machineID, _ := os.ReadFile("/etc/machine-id")
	macAddr, _ := runCmdShell("ip link show | grep -A1 'state UP' | grep ether | head -1 | awk '{print $2}'")
	os.MkdirAll("/etc/arche", 0700)
	hwConf := fmt.Sprintf("MACHINE_ID=%s\nMAC_ADDRESS=%s\n", strings.TrimSpace(string(machineID)), strings.TrimSpace(macAddr))
	os.WriteFile("/etc/arche/hardware.conf", []byte(hwConf), 0600)
	sendLog("ok", "Hardware registrado")

	// Complete
	sendProgress(100, "Instalacion completada")
	sendLog("ok", "")
	sendLog("ok", "══════════════════════════════════════════════")
	sendLog("ok", "  ARCHE GMAO INSTALADO CORRECTAMENTE")
	sendLog("ok", fmt.Sprintf("  URL: http://%s", domain))
	sendLog("ok", fmt.Sprintf("  Directorio: %s", installDir))
	sendLog("ok", "  Usuario: admin@arche.local")
	sendLog("ok", "══════════════════════════════════════════════")

	url := domain
	if httpPort != "80" {
		url = domain + ":" + httpPort
	}

	send(map[string]interface{}{
		"type":        "complete",
		"url":         url,
		"install_dir": installDir,
	})
}

func executeUpdate(req executeRequest, sendLog func(string, string), sendProgress func(int, string), send func(interface{})) {
	installDir := "/opt/arche-gmao"
	if d := req.Config["install_dir"]; d != "" {
		installDir = d
	}

	sendProgress(5, "Verificando instalacion existente...")
	if _, err := os.Stat(installDir + "/docker-compose.yml"); err != nil {
		send(map[string]string{"type": "error", "message": "No se encontro instalacion en " + installDir})
		return
	}
	sendLog("ok", "Instalacion encontrada en "+installDir)

	// Backup
	sendProgress(15, "Creando backup de seguridad...")
	backupName := fmt.Sprintf("%s/backups/pre_update_%s.sql.gz", installDir, time.Now().Format("20060102_150405"))
	out, err := runCmdShell(fmt.Sprintf("cd %s && docker compose exec -T postgres pg_dump -U arche arche 2>/dev/null | gzip > %s", installDir, backupName))
	if err != nil {
		sendLog("warn", "Backup no completado: "+out)
	} else {
		sendLog("ok", "Backup creado: "+backupName)
	}

	// Stop the services
	sendProgress(30, "Deteniendo servicios...")
	runCmdShell(fmt.Sprintf("cd %s && docker compose down 2>&1", installDir))
	sendLog("ok", "Servicios detenidos")

	// Update the binary
	sendProgress(45, "Actualizando binario...")
	binarySrc := findBinary()
	if binarySrc != "" {
		data, _ := os.ReadFile(binarySrc)
		backupBin := installDir + "/arche-server.bak"
		if _, err := os.Stat(installDir + "/arche-server"); err == nil {
			os.Rename(installDir+"/arche-server", backupBin)
		}
		os.WriteFile(installDir+"/arche-server", data, 0755)
		sendLog("ok", "Binario actualizado")
	} else {
		sendLog("info", "No se encontro binario nuevo. Se mantiene el actual.")
	}

	// Update the license
	sendProgress(55, "Actualizando licencia...")
	if req.LicenseContent != "" {
		os.WriteFile(installDir+"/config/license.key", []byte(req.LicenseContent), 0600)
		sendLog("ok", "Licencia actualizada")
	} else {
		sendLog("info", "Se mantiene la licencia actual")
	}

	// Update the compose file when available
	sendProgress(60, "Actualizando configuracion...")
	composeSrc := findComposeFile()
	if composeSrc != "" {
		data, _ := os.ReadFile(composeSrc)
		os.WriteFile(installDir+"/docker-compose.yml", data, 0644)
		sendLog("ok", "docker-compose.yml actualizado")
	}

	// Restart
	sendProgress(70, "Reiniciando servicios...")
	out, err = runCmdShell(fmt.Sprintf("cd %s && docker compose --env-file config/.env up -d 2>&1", installDir))
	if err != nil {
		sendLog("error", "Error reiniciando: "+out)
		sendLog("warn", "Restaurando backup del binario...")
		os.Rename(installDir+"/arche-server.bak", installDir+"/arche-server")
		runCmdShell(fmt.Sprintf("cd %s && docker compose --env-file config/.env up -d 2>&1", installDir))
		send(map[string]string{"type": "error", "message": "Actualizacion fallida. Se restauro la version anterior."})
		return
	}
	sendLog("ok", "Servicios reiniciados")

	// Wait
	sendProgress(85, "Verificando arranque...")
	time.Sleep(10 * time.Second)
	sendLog("ok", "Sistema actualizado correctamente")

	// Clean up the binary backup
	os.Remove(installDir + "/arche-server.bak")

	sendProgress(100, "Actualizacion completada")

	domain := detectLANIP()
	send(map[string]interface{}{
		"type":        "complete",
		"url":         domain,
		"install_dir": installDir,
	})
}

func executeUninstall(req executeRequest, sendLog func(string, string), sendProgress func(int, string), send func(interface{})) {
	installDir := "/opt/arche-gmao"

	sendProgress(10, "Verificando instalacion...")
	if _, err := os.Stat(installDir); err != nil {
		send(map[string]string{"type": "error", "message": "No se encontro instalacion en " + installDir})
		return
	}
	sendLog("ok", "Instalacion encontrada")

	// Stop
	sendProgress(25, "Deteniendo servicios...")
	runCmdShell(fmt.Sprintf("cd %s && docker compose down -v 2>&1", installDir))
	sendLog("ok", "Contenedores detenidos y volumenes eliminados")

	// Systemd
	sendProgress(50, "Eliminando servicio del sistema...")
	runCmdShell("systemctl disable arche-gmao 2>/dev/null; rm -f /etc/systemd/system/arche-gmao.service; systemctl daemon-reload")
	sendLog("ok", "Servicio systemd eliminado")

	// Cron
	sendProgress(65, "Eliminando tareas programadas...")
	runCmdShell(`(crontab -l 2>/dev/null | grep -v arche-gmao) | crontab - 2>/dev/null`)
	sendLog("ok", "Cron limpiado")

	// Remove the directory
	sendProgress(80, "Eliminando archivos...")
	if err := os.RemoveAll(installDir); err != nil {
		sendLog("warn", "No se pudo eliminar completamente: "+err.Error())
	} else {
		sendLog("ok", "Directorio "+installDir+" eliminado")
	}

	// Hardware
	os.RemoveAll("/etc/arche")
	sendLog("ok", "Registro de hardware eliminado")

	sendProgress(100, "Desinstalacion completada")
	send(map[string]interface{}{
		"type":        "complete",
		"url":         "localhost",
		"install_dir": "(eliminado)",
	})
}

// ─── Helpers ────────────────────────────────────────────────────────────────

func writeJSON(w http.ResponseWriter, v interface{}) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(v)
}

func runCmd(name string, args ...string) (string, error) {
	cmd := exec.Command(name, args...)
	out, err := cmd.CombinedOutput()
	return string(out), err
}

func runCmdShell(command string) (string, error) {
	cmd := exec.Command("bash", "-c", command)
	out, err := cmd.CombinedOutput()
	return string(out), err
}

func detectDistro() string {
	if data, err := os.ReadFile("/etc/os-release"); err == nil {
		for _, line := range strings.Split(string(data), "\n") {
			if strings.HasPrefix(line, "PRETTY_NAME=") {
				return strings.Trim(strings.TrimPrefix(line, "PRETTY_NAME="), "\"")
			}
		}
	}
	return "Linux"
}

func detectLANIP() string {
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		return "localhost"
	}
	for _, addr := range addrs {
		if ipnet, ok := addr.(*net.IPNet); ok && !ipnet.IP.IsLoopback() && ipnet.IP.To4() != nil {
			return ipnet.IP.String()
		}
	}
	return "localhost"
}

func getRAMGB() float64 {
	data, err := os.ReadFile("/proc/meminfo")
	if err != nil {
		return 0
	}
	for _, line := range strings.Split(string(data), "\n") {
		if strings.HasPrefix(line, "MemTotal:") {
			fields := strings.Fields(line)
			if len(fields) >= 2 {
				kb, _ := strconv.ParseFloat(fields[1], 64)
				return kb / 1024 / 1024
			}
		}
	}
	return 0
}

func getFreeDiskGB(path string) float64 {
	out, err := runCmdShell(fmt.Sprintf("df -BG '%s' 2>/dev/null | awk 'NR==2{print $4}'", path))
	if err != nil {
		return 0
	}
	s := strings.TrimSpace(strings.TrimSuffix(strings.TrimSpace(out), "G"))
	gb, _ := strconv.ParseFloat(s, 64)
	return gb
}

func isPortFree(port int) bool {
	ln, err := net.Listen("tcp", fmt.Sprintf(":%d", port))
	if err != nil {
		return false
	}
	ln.Close()
	return true
}

func generateSecret(length int) string {
	out, err := runCmdShell(fmt.Sprintf("openssl rand -base64 %d | tr -dc 'a-zA-Z0-9' | head -c %d", length*2, length))
	if err != nil || strings.TrimSpace(out) == "" {
		const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
		b := make([]byte, length)
		for i := range b {
			b[i] = chars[time.Now().UnixNano()%int64(len(chars))]
			time.Sleep(time.Nanosecond)
		}
		return string(b)
	}
	return strings.TrimSpace(out)
}

func findComposeFile() string {
	paths := []string{
		"docker-compose.prod.yml",
		"../docker-compose.prod.yml",
		"arche-e11/docker-compose.prod.yml",
	}
	for _, p := range paths {
		if _, err := os.Stat(p); err == nil {
			return p
		}
	}
	// Try from the executable's directory
	if exe, err := os.Executable(); err == nil {
		dir := strings.TrimSuffix(exe, "/arche-installer")
		for _, name := range []string{"docker-compose.prod.yml", "docker-compose.yml"} {
			p := dir + "/" + name
			if _, err := os.Stat(p); err == nil {
				return p
			}
		}
	}
	return ""
}

func findNginxConf() string {
	paths := []string{
		"nginx/nginx.conf",
		"../nginx/nginx.conf",
		"arche-e11/nginx/nginx.conf",
	}
	for _, p := range paths {
		if _, err := os.Stat(p); err == nil {
			return p
		}
	}
	return ""
}

func findBackupScript() string {
	paths := []string{
		"backup/backup.sh",
		"../backup/backup.sh",
		"arche-e11/backup/backup.sh",
	}
	for _, p := range paths {
		if _, err := os.Stat(p); err == nil {
			return p
		}
	}
	return ""
}

func findBinary() string {
	paths := []string{
		"arche-server",
		"../build/arche-server",
		"build/arche-server",
	}
	for _, p := range paths {
		if _, err := os.Stat(p); err == nil {
			return p
		}
	}
	return ""
}
