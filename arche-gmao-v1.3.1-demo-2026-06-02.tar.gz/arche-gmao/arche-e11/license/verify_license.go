package license

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"os"
	"slices"
	"time"
)

var signingSecret = getSigningSecret()

func getSigningSecret() string {
	if s := os.Getenv("ARCHE_LICENSE_SECRET"); s != "" {
		return s
	}
	return "arche-system-signing-secret-v1-change-in-production"
}

type LicensePayload struct {
	LicenseID  string   `json:"license_id"`
	ClientName string   `json:"client_name"`
	ClientID   string   `json:"client_id"`
	Modules    []string `json:"modules"`
	MaxUsers   int      `json:"max_users"`
	IssuedAt   string   `json:"issued_at"`
	ExpiresAt  string   `json:"expires_at"`
	Notes      string   `json:"notes"`
	Version    string   `json:"version"`
}

type License struct {
	Payload   LicensePayload `json:"payload"`
	Signature string         `json:"signature"`
}

type LicenseInfo struct {
	Valid      bool
	ClientName string
	ClientID   string
	Modules    []string
	MaxUsers   int
	ExpiresAt  time.Time
	DaysLeft   int
	Error      string
}

var Current *LicenseInfo

// Load loads and verifies the license at startup
func Load(licensePath string) (*LicenseInfo, error) {
	if licensePath == "" {
		licensePath = os.Getenv("ARCHE_LICENSE_PATH")
	}
	if licensePath == "" {
		licensePath = "/app/license.key"
	}

	data, err := os.ReadFile(licensePath)
	if err != nil {
		return &LicenseInfo{Valid: false, Error: "Archivo de licencia no encontrado: " + licensePath}, nil
	}

	// Decode base64
	raw, err := base64.StdEncoding.DecodeString(string(data))
	if err != nil {
		return &LicenseInfo{Valid: false, Error: "Licencia corrupta (base64 inválido)"}, nil
	}

	// Parse JSON
	var lic License
	if err := json.Unmarshal(raw, &lic); err != nil {
		return &LicenseInfo{Valid: false, Error: "Licencia corrupta (JSON inválido)"}, nil
	}

	// Verify the HMAC signature
	payloadBytes, _ := json.Marshal(lic.Payload)
	// Re-serialize with sort_keys to reproduce the Python signature
	var payloadMap map[string]interface{}
	json.Unmarshal(payloadBytes, &payloadMap)
	sortedPayload, _ := json.Marshal(payloadMap)

	mac := hmac.New(sha256.New, []byte(signingSecret))
	mac.Write(sortedPayload)
	expectedSig := fmt.Sprintf("%x", mac.Sum(nil))

	if expectedSig != lic.Signature {
		return &LicenseInfo{Valid: false, Error: "Licencia inválida (firma no verificada)"}, nil
	}

	// Check the expiry
	expiresAt, err := time.Parse(time.RFC3339, lic.Payload.ExpiresAt)
	if err != nil {
		expiresAt, err = time.Parse("2006-01-02T15:04:05.999999", lic.Payload.ExpiresAt)
		if err != nil {
			return &LicenseInfo{Valid: false, Error: "Fecha de caducidad inválida"}, nil
		}
	}

	daysLeft := int(time.Until(expiresAt).Hours() / 24)
	if daysLeft < 0 {
		return &LicenseInfo{
			Valid:      false,
			ClientName: lic.Payload.ClientName,
			Error:      fmt.Sprintf("Licencia caducada hace %d días", -daysLeft),
		}, nil
	}

	info := &LicenseInfo{
		Valid:      true,
		ClientName: lic.Payload.ClientName,
		ClientID:   lic.Payload.ClientID,
		Modules:    lic.Payload.Modules,
		MaxUsers:   lic.Payload.MaxUsers,
		ExpiresAt:  expiresAt,
		DaysLeft:   daysLeft,
	}

	Current = info
	return info, nil
}

// HasModule checks whether a module is enabled
func HasModule(module string) bool {
	if Current == nil || !Current.Valid {
		return false
	}
	return slices.Contains(Current.Modules, module) || slices.Contains(Current.Modules, "all")
}

// Check verifies the license and exits when it is not valid
func Check(licensePath string) {
	info, err := Load(licensePath)
	if err != nil {
		fmt.Printf("[ARCHE-LICENSE] Error cargando licencia: %v\n", err)
		os.Exit(1)
	}

	if !info.Valid {
		fmt.Printf("\n╔══════════════════════════════════════════════════╗\n")
		fmt.Printf("║          ARCHE GMAO — LICENCIA INVÁLIDA        ║\n")
		fmt.Printf("╠══════════════════════════════════════════════════╣\n")
		fmt.Printf("║  Error: %-41s║\n", info.Error)
		fmt.Printf("║  Contacte con el administrador del sistema.      ║\n")
		fmt.Printf("╚══════════════════════════════════════════════════╝\n\n")
		os.Exit(1)
	}

	fmt.Printf("[ARCHE-LICENSE] ✓ %s | Módulos: %v | Caduca en %d días\n",
		info.ClientName, info.Modules, info.DaysLeft)

	if info.DaysLeft <= 30 {
		fmt.Printf("[ARCHE-LICENSE] ⚠ AVISO: La licencia caduca en %d días. Contacte con el administrador.\n",
			info.DaysLeft)
	}
}
