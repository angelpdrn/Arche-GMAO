#!/usr/bin/env python3
"""
Arche GMAO — Generador de licencias
Uso exclusivo del administrador del sistema.
Requiere las 3 claves maestras para generar una licencia.
"""
import os
import sys
import json
import hashlib
import hmac
import base64
import getpass
import datetime
import secrets
import struct

# ─── Master keys (hardcoded in the generator, NEVER in the client) ──────
# These 3 keys are split between 3 different people (simplified Shamir's Secret Sharing)
# To change them: edit here and regenerate every active license

MASTER_KEY_1_HASH = "a3f8b2c1d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1"  # change in production
MASTER_KEY_2_HASH = "b4c9d3e2f1a0b9c8d7e6f5a4b3c2d1e0f9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4"  # change in production
MASTER_KEY_3_HASH = "c5d0e4f3a2b1c0d9e8f7a6b5c4d3e2f1a0b9c8d7e6f5a4b3c2d1e0f9a8b7c6d5"  # change in production

SIGNING_SECRET = os.environ.get("ARCHE_LICENSE_SECRET", "arche-system-signing-secret-v1-change-in-production")


def sha256(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


def verify_master_keys() -> bool:
    """Solicita y verifica las 3 claves maestras."""
    print("\n" + "═"*60)
    print("  ARCHE GMAO — Generador de Licencias")
    print("  Requiere las 3 claves maestras de autorización")
    print("═"*60 + "\n")

    k1 = getpass.getpass("  Clave maestra 1: ")
    if sha256(k1) != MASTER_KEY_1_HASH:
        print("  ✕ Clave 1 incorrecta")
        return False

    k2 = getpass.getpass("  Clave maestra 2: ")
    if sha256(k2) != MASTER_KEY_2_HASH:
        print("  ✕ Clave 2 incorrecta")
        return False

    k3 = getpass.getpass("  Clave maestra 3: ")
    if sha256(k3) != MASTER_KEY_3_HASH:
        print("  ✕ Clave 3 incorrecta")
        return False

    print("\n  ✓ Autorización correcta\n")
    return True


def generate_license(
    client_name: str,
    client_id: str,
    modules: list,
    max_users: int,
    expires_days: int,
    notes: str = ""
) -> dict:
    """Genera una licencia firmada."""

    issued_at = datetime.datetime.utcnow().isoformat()
    expires_at = (datetime.datetime.utcnow() + datetime.timedelta(days=expires_days)).isoformat()
    license_id = secrets.token_hex(16)

    payload = {
        "license_id":   license_id,
        "client_name":  client_name,
        "client_id":    client_id,
        "modules":      modules,
        "max_users":    max_users,
        "issued_at":    issued_at,
        "expires_at":   expires_at,
        "notes":        notes,
        "version":      "1.0",
    }

    # Sign the payload
    payload_str = json.dumps(payload, sort_keys=True, separators=(',', ':'))
    signature = hmac.new(
        SIGNING_SECRET.encode(),
        payload_str.encode(),
        hashlib.sha256
    ).hexdigest()

    license_data = {
        "payload":   payload,
        "signature": signature,
    }

    # Encode as base64
    license_b64 = base64.b64encode(
        json.dumps(license_data, separators=(',', ':')).encode()
    ).decode()

    return {
        "license_id":  license_id,
        "client_name": client_name,
        "license_b64": license_b64,
        "expires_at":  expires_at,
    }


def save_license_record(license_info: dict):
    """Guarda un registro de la licencia generada."""
    records_file = os.path.expanduser("~/.arche_licenses.json")
    records = []
    if os.path.exists(records_file):
        try:
            with open(records_file) as f:
                records = json.load(f)
        except Exception:
            records = []

    records.append({
        "license_id":  license_info["license_id"],
        "client_name": license_info["client_name"],
        "expires_at":  license_info["expires_at"],
        "generated_at": datetime.datetime.utcnow().isoformat(),
    })

    with open(records_file, "w") as f:
        json.dump(records, f, indent=2)


def list_licenses():
    """Lista todas las licencias generadas."""
    records_file = os.path.expanduser("~/.arche_licenses.json")
    if not os.path.exists(records_file):
        print("Sin licencias generadas.")
        return

    with open(records_file) as f:
        records = json.load(f)

    print(f"\n{'ID':<34} {'Cliente':<25} {'Caduca':<22} {'Generada'}")
    print("-"*100)
    for r in records:
        print(f"{r['license_id']:<34} {r['client_name']:<25} {r['expires_at'][:10]:<22} {r['generated_at'][:10]}")


# ─── Interactive CLI ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "list":
        if verify_master_keys():
            list_licenses()
        sys.exit(0)

    if not verify_master_keys():
        print("\n  ✕ Autorización fallida. Acceso denegado.\n")
        sys.exit(1)

    print("─"*60)
    print("  Nueva licencia\n")

    client_name = input("  Nombre del cliente: ").strip()
    client_id   = input("  ID cliente (sin espacios, ej: acme-corp): ").strip()

    print("\n  Módulos disponibles:")
    print("  [1] core        — OTs, Fábrica Virtual, Inventario (siempre incluido)")
    print("  [2] ai          — Arche IA con RAG y cálculos técnicos")
    print("  [3] metrics     — Métricas, KPIs, MTBF, MTTR")
    print("  [4] preventive  — Plan preventivo automático")
    print("  [5] qr          — Códigos QR")
    print("  [6] reports     — Informes PDF y Excel")
    print("  [7] all         — Todos los módulos")

    modules_input = input("\n  Módulos (ej: 1,2,3 o 7 para todos): ").strip()
    MODULE_MAP = {
        "1": "core", "2": "ai", "3": "metrics",
        "4": "preventive", "5": "qr", "6": "reports",
    }
    if "7" in modules_input:
        modules = list(MODULE_MAP.values())
    else:
        modules = ["core"] + [MODULE_MAP[m] for m in modules_input.split(",") if m in MODULE_MAP]

    max_users   = int(input("  Máximo de usuarios: ").strip() or "50")
    expires_days = int(input("  Duración en días (365 = 1 año): ").strip() or "365")
    notes       = input("  Notas (opcional): ").strip()

    print("\n  Generando licencia...")
    result = generate_license(client_name, client_id, modules, max_users, expires_days, notes)
    save_license_record(result)

    license_file = f"license_{client_id}.key"
    with open(license_file, "w") as f:
        f.write(result["license_b64"])

    print(f"\n  ✓ Licencia generada: {license_file}")
    print(f"  ID:       {result['license_id']}")
    print(f"  Cliente:  {result['client_name']}")
    print(f"  Caduca:   {result['expires_at'][:10]}")
    print(f"  Módulos:  {', '.join(modules)}")
    print(f"\n  Copia este archivo al pendrive junto con el instalador.\n")
