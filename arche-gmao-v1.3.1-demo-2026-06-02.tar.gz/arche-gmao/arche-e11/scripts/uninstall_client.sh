#!/bin/bash
# ============================================================
# Arche GMAO — Uninstall
# It needs all 3 keys to run
# ============================================================

MASTER_KEY_1_HASH="a3f8b2c1d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1"
MASTER_KEY_2_HASH="b4c9d3e2f1a0b9c8d7e6f5a4b3c2d1e0f9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4"
MASTER_KEY_3_HASH="c5d0e4f3a2b1c0d9e8f7a6b5c4d3e2f1a0b9c8d7e6f5a4b3c2d1e0f9a8b7c6d5"
hash_key() { echo -n "$1" | sha256sum | awk '{print $1}'; }

echo "╔══════════════════════════════════════════════════════╗"
echo "║        ARCHE GMAO — Desinstalación                 ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""
echo "  ADVERTENCIA: Esta operación eliminará Arche GMAO"
echo "  y TODOS los datos del sistema."
echo ""
read -p "  ¿Continuar? (escribe CONFIRMAR): " CONFIRM
[ "$CONFIRM" != "CONFIRMAR" ] && echo "  Cancelado." && exit 0

read -sp "  Clave 1: " KEY1; echo ""
[ "$(hash_key "$KEY1")" != "$MASTER_KEY_1_HASH" ] && echo "  ✕ Clave incorrecta." && exit 1
read -sp "  Clave 2: " KEY2; echo ""
[ "$(hash_key "$KEY2")" != "$MASTER_KEY_2_HASH" ] && echo "  ✕ Clave incorrecta." && exit 1
read -sp "  Clave 3: " KEY3; echo ""
[ "$(hash_key "$KEY3")" != "$MASTER_KEY_3_HASH" ] && echo "  ✕ Clave incorrecta." && exit 1
unset KEY1 KEY2 KEY3

echo ""
echo "  Desinstalando..."
cd /opt/arche-gmao 2>/dev/null || true
docker compose down -v 2>/dev/null || true
systemctl disable arche-gmao 2>/dev/null || true
rm -f /etc/systemd/system/arche-gmao.service
systemctl daemon-reload
(crontab -l 2>/dev/null | grep -v arche-gmao) | crontab - 2>/dev/null || true

read -p "  ¿Eliminar también los datos y backups? (S/N): " DEL_DATA
if [ "$DEL_DATA" = "S" ] || [ "$DEL_DATA" = "s" ]; then
    rm -rf /opt/arche-gmao
    echo "  ✓ Datos eliminados"
else
    echo "  ✓ Datos conservados en /opt/arche-gmao"
fi

echo ""
echo "  ✓ Arche GMAO desinstalado correctamente"
echo ""
