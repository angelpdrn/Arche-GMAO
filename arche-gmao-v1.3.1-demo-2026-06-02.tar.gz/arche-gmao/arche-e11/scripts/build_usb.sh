#!/bin/bash
# ============================================================
# Arche GMAO — Deployment package builder
# Requires the master password to encrypt the bundle
# ============================================================
set -e

echo ""
echo "  ╔══════════════════════════════════════════════════════╗"
echo "  ║    ARCHE GMAO — Constructor de paquete             ║"
echo "  ╚══════════════════════════════════════════════════════╝"
echo ""

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
ARCHE_E11="$SCRIPT_DIR/.."
BUILD_DIR="$ROOT_DIR/build"

# ─── Check that the build exists ────────────────────────────────────────────
if [ ! -f "$BUILD_DIR/arche-server" ]; then
    echo "  Error: No se encontro el binario en $BUILD_DIR/arche-server"
    echo "  Ejecuta ./build.sh primero."
    exit 1
fi

# ─── Check the license ──────────────────────────────────────────────────────
if [ -z "$1" ]; then
    echo "  Uso: $0 <ruta_a_license.key>"
    echo "  Ejemplo: $0 ./license_acme-corp.key"
    exit 1
fi

LICENSE_FILE="$1"
if [ ! -f "$LICENSE_FILE" ]; then
    echo "  Error: Archivo de licencia no encontrado: $LICENSE_FILE"
    exit 1
fi
echo "  Licencia: $LICENSE_FILE"

# ─── Encryption password ────────────────────────────────────────────────────
echo ""
echo "  Elige una contrasena para cifrar este paquete."
echo "  El cliente la necesitara para instalar."
echo ""
read -sp "  Contrasena de despliegue: " DEPLOY_PASS; echo ""
read -sp "  Repetir contrasena:       " DEPLOY_PASS2; echo ""

if [ "$DEPLOY_PASS" != "$DEPLOY_PASS2" ]; then
    echo "  Error: Las contrasenas no coinciden."
    exit 1
fi
if [ ${#DEPLOY_PASS} -lt 8 ]; then
    echo "  Error: La contrasena debe tener al menos 8 caracteres."
    exit 1
fi

# ─── Configuration ───────────────────────────────────────────────────────────
VERSION=$(cat "$ARCHE_E11/../VERSION" 2>/dev/null || echo "2.0.0")
BUILD_DATE=$(date +%Y%m%d_%H%M)
OUTPUT_DIR="/tmp/arche_pkg_${BUILD_DATE}"
BUNDLE_NAME="arche_${VERSION}_${BUILD_DATE}.bundle"

echo ""
echo "  Version: $VERSION"
echo "  Fecha:   $BUILD_DATE"
echo ""

# ─── Prepare the contents ──────────────────────────────────────────────────────
echo "  [1/4] Preparando archivos..."
mkdir -p "$OUTPUT_DIR"

cp "$BUILD_DIR/arche-server"        "$OUTPUT_DIR/"
cp "$BUILD_DIR/arche-fingerprint"   "$OUTPUT_DIR/" 2>/dev/null || true
cp "$LICENSE_FILE"                  "$OUTPUT_DIR/license.key"
cp "$ARCHE_E11/scripts/install.sh"  "$OUTPUT_DIR/" 2>/dev/null || \
  cp "$ARCHE_E11/scripts/decrypt_and_install.sh" "$OUTPUT_DIR/install.sh"
cp "$ARCHE_E11/docker-compose.prod.yml" "$OUTPUT_DIR/docker-compose.yml"
cp "$ARCHE_E11/nginx/nginx.conf"    "$OUTPUT_DIR/"
cp "$ARCHE_E11/backup/backup.sh"    "$OUTPUT_DIR/"
cp "$ROOT_DIR/update.sh"            "$OUTPUT_DIR/" 2>/dev/null || true

# Create VERSION
cat > "$OUTPUT_DIR/VERSION" << VEOF
ARCHE_VERSION=${VERSION}
BUILD_DATE=${BUILD_DATE}
VEOF

chmod +x "$OUTPUT_DIR/"*.sh "$OUTPUT_DIR/arche-server" "$OUTPUT_DIR/arche-fingerprint" 2>/dev/null
echo "  Archivos preparados"

# ─── Encrypt ──────────────────────────────────────────────────────────────────
echo "  [2/4] Cifrando paquete con AES-256..."
tar -czf "/tmp/${BUNDLE_NAME}.tar.gz" -C "$OUTPUT_DIR" .

openssl enc -aes-256-cbc \
    -pbkdf2 -iter 200000 -salt \
    -pass "pass:${DEPLOY_PASS}" \
    -in "/tmp/${BUNDLE_NAME}.tar.gz" \
    -out "${BUNDLE_NAME}"

rm -f "/tmp/${BUNDLE_NAME}.tar.gz"
rm -rf "$OUTPUT_DIR"
unset DEPLOY_PASS DEPLOY_PASS2

echo "  Bundle cifrado: ${BUNDLE_NAME}"
SIZE=$(du -sh "${BUNDLE_NAME}" | awk '{print $1}')
echo "  Tamano: ${SIZE}"

# ─── Integrity hash ──────────────────────────────────────────────────────
echo "  [3/4] Generando hash de integridad..."
sha256sum "${BUNDLE_NAME}" > "${BUNDLE_NAME}.sha256"
echo "  SHA256: $(cat ${BUNDLE_NAME}.sha256 | awk '{print $1}')"

# ─── Create the self-contained installation script ────────────────────────────────
echo "  [4/4] Creando instalador..."
cat > "instalar_arche.sh" << 'INSTEOF'
#!/bin/bash
# Arche GMAO — Installer for the client server
set -e
echo ""
echo "  ╔══════════════════════════════════════════════════════╗"
echo "  ║          ARCHE GMAO — Instalacion                  ║"
echo "  ╚══════════════════════════════════════════════════════╝"
echo ""

BUNDLE=$(ls *.bundle 2>/dev/null | head -1)
if [ -z "$BUNDLE" ]; then
    echo "  Error: No se encontro archivo .bundle en el directorio actual."
    exit 1
fi
echo "  Bundle: $BUNDLE"

# Verificar integridad
if [ -f "${BUNDLE}.sha256" ]; then
    echo "  Verificando integridad..."
    sha256sum -c "${BUNDLE}.sha256" > /dev/null 2>&1 || {
        echo "  ERROR: Bundle corrupto o manipulado. Contacte con Arche GMAO."
        exit 1
    }
    echo "  Integridad OK"
fi

# Pedir contrasena
echo ""
read -sp "  Contrasena de instalacion: " PASS; echo ""
echo ""

# Descifrar
echo "  [1/6] Descifrando..."
TEMP_DIR=$(mktemp -d)
openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 \
    -pass "pass:${PASS}" \
    -in "$BUNDLE" -out "${TEMP_DIR}/pkg.tar.gz" 2>/dev/null || {
    echo "  Error: Contrasena incorrecta o bundle corrupto."
    rm -rf "$TEMP_DIR"; exit 1
}
unset PASS
tar -xzf "${TEMP_DIR}/pkg.tar.gz" -C "$TEMP_DIR"
rm -f "${TEMP_DIR}/pkg.tar.gz"
echo "  OK"

# Docker
echo "  [2/6] Verificando Docker..."
command -v docker >/dev/null 2>&1 || {
    echo "  Instalando Docker..."
    curl -fsSL https://get.docker.com | sh
    systemctl enable docker && systemctl start docker
}
echo "  Docker OK"

# Directorio
echo "  [3/6] Instalando en /opt/arche-gmao/..."
INSTALL_DIR="/opt/arche-gmao"
mkdir -p "$INSTALL_DIR"/{data/postgres,data/redis,data/uploads,backups,config,logs}
cp "$TEMP_DIR/arche-server" "$INSTALL_DIR/"
cp "$TEMP_DIR/license.key" "$INSTALL_DIR/config/"
cp "$TEMP_DIR/docker-compose.yml" "$INSTALL_DIR/"
cp "$TEMP_DIR/nginx.conf" "$INSTALL_DIR/config/"
cp "$TEMP_DIR/backup.sh" "$INSTALL_DIR/"
cp "$TEMP_DIR/arche-fingerprint" "$INSTALL_DIR/" 2>/dev/null || true
chmod +x "$INSTALL_DIR/arche-server" "$INSTALL_DIR/backup.sh" "$INSTALL_DIR/arche-fingerprint" 2>/dev/null
rm -rf "$TEMP_DIR"
echo "  OK"

# Secretos
echo "  [4/6] Generando secretos..."
cat > "$INSTALL_DIR/config/.env" << ENVEOF
POSTGRES_DB=arche
POSTGRES_USER=arche
POSTGRES_PASSWORD=$(openssl rand -base64 32 | tr -dc 'a-zA-Z0-9' | head -c 32)
JWT_SECRET=$(openssl rand -base64 64 | tr -dc 'a-zA-Z0-9' | head -c 64)
JWT_REFRESH_SECRET=$(openssl rand -base64 64 | tr -dc 'a-zA-Z0-9' | head -c 64)
REDIS_PASSWORD=$(openssl rand -base64 24 | tr -dc 'a-zA-Z0-9' | head -c 24)
APP_BASE_URL=http://$(hostname -I | awk '{print $1}')
APP_ENV=production
ARCHE_LICENSE_PATH=/app/config/license.key
OLLAMA_URL=http://host-gateway:11434
ENVEOF
chmod 600 "$INSTALL_DIR/config/.env"
echo "  OK"

# Capturar hardware fingerprint
echo "  [5/6] Registrando hardware..."
if [ -f "$INSTALL_DIR/arche-fingerprint" ]; then
    MACHINE_ID=$(cat /etc/machine-id 2>/dev/null || echo "unknown")
    PRIMARY_MAC=$(ip link show | grep -A1 'state UP' | grep ether | head -1 | awk '{print $2}' || echo "unknown")
    cat > /etc/arche/hardware.conf 2>/dev/null << HWEOF || true
MACHINE_ID=${MACHINE_ID}
MAC_ADDRESS=${PRIMARY_MAC}
ALLOWED_HOSTS=$(hostname -I | tr ' ' ',')
HWEOF
    mkdir -p /etc/arche
    cp /etc/arche/hardware.conf /etc/arche/hardware.conf 2>/dev/null || true
fi
echo "  OK"

# Arrancar
echo "  [6/6] Iniciando sistema..."
cd "$INSTALL_DIR"
docker compose --env-file config/.env up -d 2>/dev/null || \
  docker-compose --env-file config/.env up -d
sleep 10

# Systemd
cat > /etc/systemd/system/arche-gmao.service << 'SVCEOF'
[Unit]
Description=Arche GMAO CMMS
After=docker.service
Requires=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/opt/arche-gmao
ExecStart=/usr/bin/docker compose --env-file config/.env up -d
ExecStop=/usr/bin/docker compose down
TimeoutStartSec=300

[Install]
WantedBy=multi-user.target
SVCEOF
systemctl daemon-reload && systemctl enable arche-gmao

# Backup cron
(crontab -l 2>/dev/null | grep -v arche-gmao; echo "0 3 * * * /opt/arche-gmao/backup.sh >> /opt/arche-gmao/logs/backup.log 2>&1") | crontab -

IP=$(hostname -I | awk '{print $1}')
echo ""
echo "  ╔══════════════════════════════════════════════════════╗"
echo "  ║           ARCHE GMAO INSTALADO                     ║"
echo "  ╠══════════════════════════════════════════════════════╣"
echo "  ║  URL:  http://${IP}                                  "
echo "  ║  Dir:  /opt/arche-gmao                             "
echo "  ║  Logs: docker compose logs -f                        "
echo "  ╚══════════════════════════════════════════════════════╝"
echo ""
INSTEOF

chmod +x "instalar_arche.sh"
echo "  Instalador: instalar_arche.sh"

# ─── Summary ─────────────────────────────────────────────────────────────────
echo ""
echo "  ╔══════════════════════════════════════════════════════╗"
echo "  ║  Paquete listo para entregar:                        ║"
echo "  ║                                                      ║"
echo "  ║  Archivos:                                           ║"
echo "  ║    ${BUNDLE_NAME}"
echo "  ║    ${BUNDLE_NAME}.sha256"
echo "  ║    instalar_arche.sh                                 ║"
echo "  ║                                                      ║"
echo "  ║  Copiar los 3 archivos al pendrive.                  ║"
echo "  ║  En el servidor del cliente:                         ║"
echo "  ║    sudo bash instalar_arche.sh                       ║"
echo "  ╚══════════════════════════════════════════════════════╝"
echo ""
