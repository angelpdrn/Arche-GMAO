#!/bin/bash
# Internal installation script (inside the encrypted bundle)
# Run automatically from decrypt_and_install.sh

echo "[ARCHE] Ejecutando configuración inicial..."

# Apply the migrations
docker compose exec -T postgres psql -U arche -d arche < /app/migrations/all.sql 2>/dev/null || true

# Create the initial admin user with a random password
ADMIN_PASS=$(openssl rand -base64 12 | tr -dc 'a-zA-Z0-9' | head -c 12)
ADMIN_HASH=$(docker run --rm python:3.11-alpine python3 -c \
    "import bcrypt; print(bcrypt.hashpw('${ADMIN_PASS}'.encode(), bcrypt.gensalt(10)).decode())" 2>/dev/null)

docker compose exec -T postgres psql -U arche -d arche << SQLEOF
INSERT INTO tenants (name, slug) VALUES ('Mi Empresa', 'default') ON CONFLICT DO NOTHING;
INSERT INTO users (tenant_id, full_name, email, password_hash, role, status)
SELECT 1, 'Administrador', 'admin@arche.local', '${ADMIN_HASH}', 'admin', 'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email='admin@arche.local');
SQLEOF

echo "[ARCHE] ✓ Sistema configurado"
echo "[ARCHE] Usuario admin: admin@arche.local / ${ADMIN_PASS}"
echo "[ARCHE] GUARDA ESTA CONTRASEÑA — no se volverá a mostrar"
