#!/bin/bash
# ============================================================
# Arche GMAO — Installer for the client server
# This script ships on the USB stick alongside the encrypted bundle
# ============================================================
set -e

BUNDLE_FILE="$1"

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║          ARCHE GMAO — Instalación                  ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

if [ -z "$BUNDLE_FILE" ] || [ ! -f "$BUNDLE_FILE" ]; then
    echo "  Uso: sudo bash decrypt_and_install.sh <archivo.bundle>"
    ls *.bundle 2>/dev/null || true
    exit 1
fi

# ─── Check the bundle's integrity ──────────────────────────────────────────
if [ -f "${BUNDLE_FILE}.sha256" ]; then
    echo "  Verificando integridad del bundle..."
    sha256sum -c "${BUNDLE_FILE}.sha256" > /dev/null 2>&1 || {
        echo "  ✕ ERROR: El bundle está corrupto o ha sido manipulado."
        echo "  Contacte con el proveedor para obtener un nuevo pendrive."
        exit 1
    }
    echo "  ✓ Integridad verificada"
fi

# ─── Ask for the 3 decryption keys ─────────────────────────────────────────
MASTER_KEY_1_HASH="a3f8b2c1d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1"
MASTER_KEY_2_HASH="b4c9d3e2f1a0b9c8d7e6f5a4b3c2d1e0f9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4"
MASTER_KEY_3_HASH="c5d0e4f3a2b1c0d9e8f7a6b5c4d3e2f1a0b9c8d7e6f5a4b3c2d1e0f9a8b7c6d5"

hash_key() { echo -n "$1" | sha256sum | awk '{print $1}'; }

echo ""
echo "  Se requieren 3 claves de autorización para instalar."
echo ""

read -sp "  Clave de instalación 1: " KEY1; echo ""
if [ "$(hash_key "$KEY1")" != "$MASTER_KEY_1_HASH" ]; then
    echo "  ✕ Clave 1 incorrecta."; exit 1
fi

read -sp "  Clave de instalación 2: " KEY2; echo ""
if [ "$(hash_key "$KEY2")" != "$MASTER_KEY_2_HASH" ]; then
    echo "  ✕ Clave 2 incorrecta."; exit 1
fi

read -sp "  Clave de instalación 3: " KEY3; echo ""
if [ "$(hash_key "$KEY3")" != "$MASTER_KEY_3_HASH" ]; then
    echo "  ✕ Clave 3 incorrecta."; exit 1
fi

echo ""
echo "  ✓ Autorización correcta. Iniciando instalación..."
echo ""

DECRYPTION_KEY=$(echo -n "${KEY1}${KEY2}${KEY3}" | sha256sum | awk '{print $1}')
unset KEY1 KEY2 KEY3

# ─── Decrypt the bundle ─────────────────────────────────────────────────────────
echo "  [1/7] Descifrando bundle..."
TEMP_DIR=$(mktemp -d)
TEMP_TAR="${TEMP_DIR}/arche_install.tar.gz"

openssl enc -d -aes-256-cbc \
    -pbkdf2 \
    -iter 200000 \
    -pass "pass:${DECRYPTION_KEY}" \
    -in "$BUNDLE_FILE" \
    -out "$TEMP_TAR" 2>/dev/null || {
    echo "  ✕ Error descifrando. Claves incorrectas o bundle corrupto."
    rm -rf "$TEMP_DIR"
    exit 1
}
unset DECRYPTION_KEY

tar -xzf "$TEMP_TAR" -C "$TEMP_DIR"
rm -f "$TEMP_TAR"
echo "  ✓ Bundle descifrado"

# ─── Check the prerequisites ──────────────────────────────────────────────────
echo "  [2/7] Verificando prerequisitos..."

command -v docker >/dev/null 2>&1 || {
    echo "  Instalando Docker..."
    curl -fsSL https://get.docker.com | sh
    systemctl enable docker
    systemctl start docker
}

command -v docker >/dev/null 2>&1 && echo "  ✓ Docker disponible" || {
    echo "  ✕ Docker no disponible. Instálalo manualmente."
    exit 1
}

# ─── Installation directory ────────────────────────────────────────────────
echo "  [3/7] Preparando directorio de instalación..."
INSTALL_DIR="/opt/arche-gmao"
mkdir -p "$INSTALL_DIR"/{data,backups,config,logs}
cp "$TEMP_DIR/docker-compose.yml" "$INSTALL_DIR/"
cp "$TEMP_DIR/nginx.conf" "$INSTALL_DIR/config/"
cp "$TEMP_DIR/backup.sh" "$INSTALL_DIR/"
cp "$TEMP_DIR/license.key" "$INSTALL_DIR/config/"
chmod +x "$INSTALL_DIR/backup.sh"
echo "  ✓ Directorio: $INSTALL_DIR"

# ─── Load the Docker images ───────────────────────────────────────────────────
echo "  [4/7] Cargando imágenes Docker (puede tardar varios minutos)..."
for img in postgres redis arche-api arche-frontend; do
    if [ -f "$TEMP_DIR/${img}.tar.gz" ]; then
        echo "     Cargando ${img}..."
        docker load -i "$TEMP_DIR/${img}.tar.gz" > /dev/null 2>&1
    fi
done
rm -rf "$TEMP_DIR"
echo "  ✓ Imágenes cargadas"

# ─── Generate secure secrets ─────────────────────────────────────────────────
echo "  [5/7] Generando secretos de seguridad..."
DB_PASSWORD=$(openssl rand -base64 32 | tr -dc 'a-zA-Z0-9' | head -c 32)
JWT_SECRET=$(openssl rand -base64 64 | tr -dc 'a-zA-Z0-9' | head -c 64)
REDIS_PASSWORD=$(openssl rand -base64 24 | tr -dc 'a-zA-Z0-9' | head -c 24)

cat > "$INSTALL_DIR/config/.env" << ENVEOF
# Arche GMAO — Production configuration
# IMPORTANTE: No compartir este archivo

POSTGRES_DB=arche
POSTGRES_USER=arche
POSTGRES_PASSWORD=${DB_PASSWORD}

JWT_SECRET=${JWT_SECRET}
JWT_REFRESH_SECRET=$(openssl rand -base64 64 | tr -dc 'a-zA-Z0-9' | head -c 64)

REDIS_PASSWORD=${REDIS_PASSWORD}

APP_BASE_URL=http://localhost
APP_ENV=production

ARCHE_LICENSE_PATH=/app/config/license.key

OLLAMA_URL=http://host-gateway:11434
ENVEOF

chmod 600 "$INSTALL_DIR/config/.env"
echo "  ✓ Secretos generados y guardados en $INSTALL_DIR/config/.env"

# ─── Start the system ─────────────────────────────────────────────────────────
echo "  [6/7] Iniciando Arche GMAO..."
cd "$INSTALL_DIR"
docker compose --env-file config/.env up -d
sleep 15

# Check that it started
if docker compose ps | grep -q "Up"; then
    echo "  ✓ Sistema iniciado correctamente"
else
    echo "  ⚠ Algunos contenedores no arrancaron. Verificar con: docker compose logs"
fi

# ─── Set up automatic backups ─────────────────────────────────────────────
echo "  [7/7] Configurando backups automáticos..."
CRON_JOB="0 3 * * * /opt/arche-gmao/backup.sh >> /opt/arche-gmao/logs/backup.log 2>&1"
(crontab -l 2>/dev/null | grep -v arche-gmao; echo "$CRON_JOB") | crontab -
echo "  ✓ Backup diario a las 3:00 AM configurado"

# ─── Set up the systemd service ──────────────────────────────────────────────
cat > /etc/systemd/system/arche-gmao.service << 'SVCEOF'
[Unit]
Description=Arche GMAO CMMS
After=docker.service
Requires=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/opt/arche-gmao
ExecStart=/usr/bin/docker compose --env-file config/.env up -d
ExecStop=/usr/bin/docker compose down
TimeoutStartSec=300

[Install]
WantedBy=multi-user.target
SVCEOF

systemctl daemon-reload
systemctl enable arche-gmao
echo "  ✓ Servicio systemd configurado (arranca con el servidor)"

# ─── Summary ─────────────────────────────────────────────────────────────────
IP=$(hostname -I | awk '{print $1}')
echo ""
echo "  ╔══════════════════════════════════════════════════════╗"
echo "  ║           ARCHE GMAO INSTALADO                     ║"
echo "  ╠══════════════════════════════════════════════════════╣"
echo "  ║  URL: http://${IP}                                   ║"
echo "  ║  Dir: /opt/arche-gmao                              ║"
echo "  ║  Logs: docker compose -f /opt/arche-gmao/docker-compose.yml logs"
echo "  ║                                                      ║"
echo "  ║  Usuario inicial:                                    ║"
echo "  ║    Email:     admin@arche.local                      ║"
echo "  ║    Contraseña: (ver primer arranque en los logs)     ║"
echo "  ╚══════════════════════════════════════════════════════╝"
echo ""
echo "  IMPORTANTE: Guarda el archivo /opt/arche-gmao/config/.env"
echo "  en un lugar seguro. Contiene las claves de la base de datos."
echo ""
