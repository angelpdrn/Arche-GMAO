# Mantenimiento Preventivo

## Conceptos

- **Plan**: configuracion de mantenimiento periodico vinculado a nodos
- **Ejecucion**: registro de cada vez que el plan genera OTs
- **Escalonamiento (staggering)**: distribucion inteligente de carga entre tecnicos y dias
- **Exclusion**: fechas donde un plan no debe generar (vacaciones, paradas)

## Plan de mantenimiento

Campos clave:
- `frequency_type`: daily, weekly, monthly, yearly
- `frequency_value`: cada N unidades
- `last_generated`: ultima fecha que genero OTs
- `next_due`: proxima generacion
- `nodes`: nodos afectados (JSON array)
- `parts`: repuestos a vincular automaticamente
- `checklist`: pasos a incluir en la OT
- `instructions`: instrucciones tecnicas
- `active`: toggle on/off

## Generacion automatica

El `MaintenanceWorker` (tick 1h):
1. Busca planes con `active=true AND next_due <= NOW()`
2. Para cada nodo vinculado al plan, genera una OT tipo `preventive`
3. Vincula repuestos del plan a la OT
4. Actualiza `last_generated = NOW()`, `next_due = advanceDate(now, freq_type, freq_value)`
5. Registra en `maintenance_plan_executions`
6. Notifica tecnicos asignados

Numeros de OT: `OT-YYYY-NNNN` via `pg_advisory_xact_lock`.

## Ejecucion manual

`POST /maintenance-plans/:id/execute` — fuerza ejecucion inmediata (admin/supervisor).

## Escalonamiento (Staggering)

Problema: si hay 200 equipos con preventivo mensual, no pueden caer todos el mismo dia.

Solucion: `StaggeringService` distribuye OTs entre tecnicos y dias disponibles.

### Configuracion (`staggered_configs`)
- scope: all | subtree (desde un nodo)
- period: weekly, biweekly, monthly
- max_daily: maximo OTs por dia
- start_date: inicio del ciclo

### Ciclos (`staggered_cycles`)
- Periodo con fecha inicio/fin
- Auto-renovacion cuando expira

### Schedule (`staggered_schedule`)
- Calendario: que nodo, que dia, que tecnico
- Generado por `CalculatePreview` → aplicado con `ApplySchedule`

### Algoritmo de distribucion
1. Recolecta targets (nodos con plan activo en scope)
2. Obtiene tecnicos disponibles
3. Distribuye round-robin respetando max_daily y exclusiones
4. `findNextAvailableDate`: busca proximo dia libre

## Exclusiones

Admin/supervisor puede excluir fechas especificas de un plan:
- `POST /maintenance-plans/:id/exclusions`
- El worker las respeta al generar

## Plantillas de plan (`maintenance_plan_templates`)

Plantillas reutilizables que se pueden aplicar a nuevos planes.

## Compliance

`GET /maintenance-plans/:id/compliance` — porcentaje de ejecuciones a tiempo vs vencidas.

## Planes efectivos por nodo

`GET /maintenance-plans/effective?node_id=X` — todos los planes que afectan a un nodo (directos + heredados por arbol).
