# Deploy y Build

## Desarrollo

```bash
make up          # Docker compose: PostgreSQL + Redis + API Go + Frontend Vite
make down        # Parar todo
make logs        # Logs de todos los servicios
make db-reset    # Borrar y re-aplicar migraciones
```

Frontend en `:5173`, API en `:3000`. Sin Nginx, CORS auto-detecta IP LAN.

## Build produccion

```bash
./build.sh
```

Pasos:
1. `cd frontend && npm ci && npm run build` → genera dist/
2. `cd api && go build -ldflags="-s -w" -o ../build/arche-server ./cmd/server/`
   - Frontend queda embebido via `internal/static/` (Go embed)
3. `sha256sum build/arche-server > build/arche-server.sha256`

Output: `build/arche-server` (binario Linux amd64) + checksum.
Requisitos build: Node.js 20+, Go 1.24+.

## Instalacion servidor (`arche.sh`)

Script de 11 fases, ejecutar como root:

1. Detecta SO, SELinux, RAM, CPU, GPU
2. Verifica puertos (reasigna internos si ocupados)
3. Instala dependencias + Docker
4. Crea directorios + genera secretos en `/etc/arche/config.env`
5. Levanta PostgreSQL (pgvector:pg16) + Redis (7-alpine)
6. Copia binario, crea usuario `arche`, servicio systemd
7. Instala Ollama, sugiere modelo segun hardware
8. Nginx: proxy reverso, SSL, security headers, SSE
9. Aplica migraciones, crea tenant + admin + superadmin
10. Fingerprint hardware
11. Arranca servicio, health check, muestra credenciales

Opciones:
```
--domain DOMINIO     Dominio para SSL
--ssl auto|self|none Modo certificado
--binary RUTA        Ruta al binario
--migrations RUTA    Directorio migraciones
--tenant NOMBRE      Nombre empresa cliente
```

## Actualizacion (`update.sh`)

```bash
sudo /opt/arche-gmao/update.sh /tmp/arche-server
```

Pasos:
1. Verifica checksum SHA256
2. Backup binario actual (guarda ultimos 5)
3. Detiene servicio
4. Reemplaza binario
5. Reinicia servicio
6. Health check (5 intentos)
7. Si falla → rollback automatico

Tiempo de inactividad: ~5 segundos. PWA muestra banner offline.

## Estructura produccion

```
/opt/arche-gmao/
  arche-server              Binario
  docker-compose.yml        PostgreSQL + Redis
  .env -> /etc/arche/config.env
  hardware.conf             Fingerprint
  data/{postgres,redis,uploads}/
  backups/  migrations/  logs/

/etc/arche/
  config.env                Variables (permisos 600)
  ssl/                      Certificados

/etc/systemd/system/arche-gmao.service
/root/.arche-superadmin     Credenciales superadmin (600)
```

## Systemd hardening

```ini
NoNewPrivileges=true
ProtectSystem=strict
PrivateTmp=true
ReadWritePaths=/opt/arche-gmao/data /opt/arche-gmao/logs
```

## Docker (servicios de datos)

PostgreSQL y Redis corren en Docker Compose:
- Puertos configurables (se reasignan si ocupados)
- CPU/memory limits
- Volumes persistentes en `/opt/arche-gmao/data/`
- Sin `container_name` hardcodeado (permite multiples instancias)

## Variables de entorno clave

| Variable | Default dev | Produccion |
|----------|-------------|-----------|
| APP_ENV | (vacio) | production |
| PORT | 3000 | generado |
| DB_HOST | localhost | localhost |
| DB_PORT | 5432 | puede variar |
| DB_USER/PASSWORD/NAME | arche | generados |
| REDIS_PASSWORD | arche-redis-secret | generado |
| JWT_SECRET | dev default | generado (Fatal si default) |
| JWT_REFRESH_SECRET | dev default | generado |
| OLLAMA_URL | host.docker.internal:11434 | localhost:11434 |
| CORS_ORIGINS | localhost:5173 | dominio produccion |
| GOMAXPROCS | 2 | configurable |
| DB_MAX_CONNS | 20 | 15 |

## SSL

Tres modos:
- `auto`: Certbot (Let's Encrypt), renovacion automatica
- `self`: Certificado autofirmado (365 dias)
- `none`: Solo HTTP (desarrollo/intranet)
