# Ordenes de Trabajo (Work Orders)

## Estado machine

11 estados con transiciones definidas:

```
draft → pending → approved → assigned → in_progress → completed → verified → closed
                ↘ rejected → pending (vuelve)
         (cualquiera excepto closed/cancelled) → cancelled
         in_progress ↔ paused
         completed → closed (sin verificar, atajo)
```

### Transiciones permitidas

| Desde | Hacia |
|-------|-------|
| draft | pending, cancelled |
| pending | approved, rejected, cancelled |
| approved | assigned, cancelled |
| assigned | in_progress, paused, cancelled |
| in_progress | completed, paused, cancelled |
| paused | in_progress, cancelled |
| completed | verified, closed |
| verified | closed |
| rejected | pending |
| cancelled | (ninguna) |
| closed | (ninguna) |

### Roles por transicion de destino

| Estado destino | Roles permitidos |
|---------------|-----------------|
| pending | admin, supervisor, technician, operator |
| approved | admin, supervisor |
| rejected | admin, supervisor |
| assigned | admin, supervisor |
| in_progress | admin, supervisor, technician, operator |
| completed | admin, supervisor, technician, operator |
| verified | admin, supervisor |
| paused | admin, supervisor, technician, operator |
| closed | admin, supervisor |
| cancelled | admin, supervisor |

## Cronometro (intervals)

Cada vez que una OT pasa a `in_progress` se crea un registro en `work_order_intervals` con `started_at`. Al pausar o completar se escribe `ended_at`. El frontend suma intervalos para mostrar tiempo trabajado.

## Firmas

- `POST /:id/sign` — firma del tecnico (base64 imagen)
- `POST /:id/supervisor-sign` — firma supervisor (solo admin/supervisor)

## Verificacion

Paso entre `completed` y `closed`. El supervisor verifica la calidad del trabajo. Se registra en `verification_records`.

## Optimistic locking

Campo `version` en `work_orders`. Cada UPDATE incluye `WHERE version = $N` y retorna nueva version. Si no matchea → 409 Conflict.

## Numeros de OT

Formato: `OT-YYYY-NNNN` (secuencial por tenant por ano).
Generado con `pg_advisory_xact_lock(tenant_id)` para evitar duplicados bajo concurrencia.

## Comentarios

`POST /:id/comments` — cualquier rol operativo puede comentar. Se guarda en `work_order_comments` con user_id y timestamp.

## Repuestos usados

Al completar, se registran repuestos en `work_order_parts`. Descuenta automaticamente del stock en `spare_parts`.

## Offline bundle

`GET /work-orders/offline-bundle` retorna todas las OTs asignadas al usuario con datos necesarios para operar sin conexion (nodos, repuestos vinculados, etc.).

## Tipos

| Tipo | Uso |
|------|-----|
| corrective | Fallo detectado, reparacion |
| preventive | Generada por plan de mantenimiento |
| predictive | Generada por patron IA |
| improvement | Mejora voluntaria |
| inspection | Inspeccion programada |

## Prioridades

`low`, `medium`, `high`, `critical`
