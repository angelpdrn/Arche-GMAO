# Arquitectura general

## Componentes

```
[Browser/PWA] <--HTTPS--> [Nginx] <--HTTP--> [Go API :3000]
                                                 |
                                          [PostgreSQL :5432]
                                          [Redis :6379]
                                          [Ollama :11434]
```

En desarrollo no hay Nginx: el frontend Vite (:5173) se conecta directamente a la API (:3000).

## Capas del backend

```
cmd/server/main.go          Punto de entrada, config, workers
internal/server/server.go   Routing, middleware chain, grupos de rutas
internal/middleware/         Auth, permisos, RLS, rate limiting, seguridad
internal/handlers/           Logica de negocio (40 archivos, uno por dominio)
internal/database/           Pool pgxpool, migraciones, hooks RLS
internal/ai/                 Ollama client, prompt builder, index worker, patterns
internal/types/              Claims, configs compartidas
internal/config/             Variables de entorno
internal/license/            Verificacion de licencia Ed25519
internal/hwcheck/            Fingerprint de hardware
```

## Capas del frontend

```
views/              18 paginas principales (una por ruta)
components/         Subcomponentes organizados por dominio
composables/        Logica reutilizable (useToast, useOffline, useAuth, etc.)
stores/             Pinia stores (auth, factory, offline, directories, ai)
api/                Wrappers HTTP tipados (un archivo por dominio)
types/              Interfaces TypeScript compartidas
utils/              Utilidades puras (time, formatters)
offline/            IndexedDB + sync service para modo offline
router/             Rutas con guards de auth y modulos
layouts/            AppLayout (sidebar + topbar + content)
```

## Flujo de un request tipico

1. Browser envia request con `Authorization: Bearer <token>`
2. `RequireAuth` middleware valida JWT, extrae claims, pone en `c.Locals("claims")`
3. `SetTenantContext` pone tenant_id en el context de Go
4. `RequireRole` verifica que el rol del usuario tiene acceso al grupo de rutas
5. Handler ejecuta logica, hace queries a PostgreSQL
6. pgxpool `BeforeAcquire` hook detecta tenant_id en context y ejecuta `SET ROLE arche_app; SET app.current_tenant_id = X`
7. PostgreSQL aplica RLS (Row Level Security) a la query
8. pgxpool `AfterRelease` hook ejecuta `RESET ROLE; RESET app.current_tenant_id`
9. Handler responde JSON

## Multi-tenancy

Doble aislamiento:
- **Aplicacion**: todas las queries incluyen `WHERE tenant_id = $N`
- **Base de datos**: RLS con politicas `USING (tenant_id = current_setting('app.current_tenant_id')::BIGINT)`

Los workers (goroutines) usan `context.Background()` sin tenant_id, asi que pgxpool no ejecuta SET ROLE y el owner `arche` bypasea RLS. Esto es intencional: los workers operan sobre todos los tenants.
