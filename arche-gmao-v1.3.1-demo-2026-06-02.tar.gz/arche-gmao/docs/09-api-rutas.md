# API — Referencia de rutas

Base: `/api/v1`

## Publicas (sin auth)

```
GET  /health                         Health check
POST /auth/login                     Login (rate: 10/min)
POST /auth/refresh                   Refresh token
GET  /push/vapid-public-key          Clave publica VAPID
GET  /scan/:code                     Escaneo QR publico (rate: 30/min)
```

## Protegidas (RequireAuth + SetTenantContext + globalLimiter)

### Auth
```
POST /auth/logout
GET  /auth/me
GET  /license/info
```

### Push notifications
```
POST   /push/subscribe
DELETE /push/unsubscribe
```

### Import (admin, supervisor)
```
GET  /import/template
POST /import/nodes
GET  /import/conflicts
POST /import/cleanup                 (admin only)
```

### Factory (arbol)
```
GET    /factory/tree
GET    /factory/search
POST   /factory/nodes                (admin, supervisor)
GET    /factory/nodes/qr-sheet       (modulo qr)
GET    /factory/nodes/qr-excel       (modulo qr)
POST   /factory/nodes/clone          (admin, supervisor)
GET    /factory/nodes/:id            (node scope)
PUT    /factory/nodes/:id            (admin, supervisor + node scope)
DELETE /factory/nodes/:id            (admin, supervisor + node scope)
PATCH  /factory/nodes/:id/move       (admin, supervisor + node scope)
GET    /factory/nodes/:id/children
GET    /factory/nodes/:id/personnel
DELETE /factory/nodes/:id/personnel/:userId
POST   /factory/nodes/:id/personnel/:userId/exclude
DELETE /factory/nodes/:id/personnel/:userId/exclude
POST   /factory/nodes/:id/spare-parts
DELETE /factory/nodes/:id/spare-parts/:spareId
GET    /factory/nodes/:id/library
POST   /factory/nodes/:id/library/upload
PATCH  /factory/nodes/:id/template
GET    /factory/nodes/:id/siblings
GET    /factory/nodes/:id/patterns
GET    /factory/nodes/:id/metrics
GET    /factory/nodes/:id/health
GET    /factory/nodes/:id/health/history
GET    /factory/nodes/:id/qr         (modulo qr)
GET    /factory/nodes/:id/qr-scans   (modulo qr)
GET    /factory/nodes/:id/manuals
POST   /factory/nodes/:id/manuals/upload
GET    /factory/nodes/:id/manuals/:manualId/download
PUT    /factory/nodes/:id/manuals/:manualId
DELETE /factory/nodes/:id/manuals/:manualId
```

### Factory health
```
GET  /factory/health/summary
POST /factory/health/recalculate     (admin)
GET  /factory/health/weights         (admin)
PUT  /factory/health/weights/:nodeType (admin)
```

### Compositions
```
GET    /compositions/
POST   /compositions/                (admin, supervisor)
GET    /compositions/by-node/:nodeId
GET    /compositions/:id
PUT    /compositions/:id             (admin, supervisor)
DELETE /compositions/:id             (admin, supervisor)
POST   /compositions/:id/members     (admin, supervisor)
DELETE /compositions/:id/members/:nodeId
GET    /compositions/:id/qr          (modulo qr)
```

### Composition templates
```
GET    /composition-templates/
POST   /composition-templates/       (admin, supervisor)
GET    /composition-templates/:id
PUT    /composition-templates/:id    (admin, supervisor)
DELETE /composition-templates/:id    (admin, supervisor)
POST   /composition-templates/:id/apply
```

### Clients
```
GET    /clients/
POST   /clients/                     (admin, supervisor)
PUT    /clients/:id                  (admin, supervisor)
DELETE /clients/:id                  (admin)
```

### Node types
```
GET /node-types
```

### Work Orders
```
GET   /work-orders/
GET   /work-orders/offline-bundle
GET   /work-orders/suggest-parts
POST  /work-orders/                  (admin, supervisor, technician, operator)
GET   /work-orders/:id
PUT   /work-orders/:id               (admin, supervisor, technician)
PATCH /work-orders/:id/status        (admin, supervisor, technician, operator)
POST  /work-orders/:id/comments      (admin, supervisor, technician, operator)
GET   /work-orders/:id/intervals
GET   /work-orders/:id/library
POST  /work-orders/:id/sign
POST  /work-orders/:id/supervisor-sign (admin, supervisor)
GET   /work-orders/:id/signatures
GET   /work-orders/:id/procedures
```

### Spare parts
```
GET  /spare-parts/
POST /spare-parts/                   (admin, supervisor, warehouse)
GET  /spare-parts/:id
PUT  /spare-parts/:id                (admin, supervisor, warehouse)
POST /spare-parts/:id/movements      (admin, supervisor, warehouse, technician)
```

### Library
```
GET    /library/all
GET    /library/:id/download
DELETE /library/:id                   (admin, supervisor)
```

### Personnel
```
GET    /personnel/
GET    /personnel/:id/competencies
POST   /personnel/:id/competencies   (admin, supervisor)
DELETE /personnel/competencies/:id    (admin, supervisor)
GET    /personnel/:id/assignments
POST   /personnel/:id/assignments    (admin, supervisor)
```

### Calendar
```
GET    /calendar/
GET    /calendar/upcoming
POST   /calendar/                    (admin, supervisor)
DELETE /calendar/:id                  (admin, supervisor)
```

### Directories (personales)
```
GET    /directories/
POST   /directories/
PUT    /directories/:id
DELETE /directories/:id
POST   /directories/:id/verify-pin
GET    /directories/:id/items
```

### Maintenance plans (modulo preventive)
```
GET    /maintenance-plans/
POST   /maintenance-plans/           (admin, supervisor)
GET    /maintenance-plans/:id
PUT    /maintenance-plans/:id        (admin, supervisor)
DELETE /maintenance-plans/:id        (admin, supervisor)
PATCH  /maintenance-plans/:id/toggle (admin, supervisor)
GET    /maintenance-plans/:id/executions
```

### Staggering
```
GET  /staggering/config/:planId
POST /staggering/config              (admin, supervisor)
GET  /staggering/schedule/:planId
POST /staggering/generate            (admin, supervisor)
```

### Templates
```
GET    /templates/
POST   /templates/                   (admin, supervisor)
GET    /templates/:id
PUT    /templates/:id                (admin, supervisor)
DELETE /templates/:id                (admin, supervisor)
GET    /templates/folders
POST   /templates/folders            (admin, supervisor)
DELETE /templates/folders/:id        (admin, supervisor)
```

### Notifications
```
GET   /notifications/
GET   /notifications/stream          (SSE)
PATCH /notifications/:id/read
POST  /notifications/mark-all-read
GET   /notifications/unread-count
```

### AI (modulo ai, rate: 30/min)
```
POST   /ai/chat                      (SSE streaming)
GET    /ai/conversations
GET    /ai/conversations/:id
DELETE /ai/conversations/:id
POST   /ai/index-nodes               (admin, supervisor)
POST   /ai/index/:source_type/:source_id
POST   /ai/reindex-all               (admin)
GET    /ai/calcs
POST   /ai/calculate                 (admin, supervisor)
```

### AI Admin (admin only)
```
GET    /ai/admin/models
PUT    /ai/admin/models
GET    /ai/admin/roles
PUT    /ai/admin/roles
GET    /ai/admin/permission-log
GET    /ai/admin/knowledge
GET    /ai/admin/knowledge/:id
POST   /ai/admin/knowledge
POST   /ai/admin/knowledge/upload
PUT    /ai/admin/knowledge/:id
DELETE /ai/admin/knowledge/:id
GET    /ai/admin/folders
POST   /ai/admin/folders
PUT    /ai/admin/folders/:id
DELETE /ai/admin/folders/:id
GET    /ai/admin/calcs
POST   /ai/admin/calcs
PUT    /ai/admin/calcs/:id
DELETE /ai/admin/calcs/:id
GET    /ai/admin/log
GET    /ai/admin/stats
POST   /ai/admin/system-prompt
```

### Patterns (modulo ai)
```
GET   /patterns/
POST  /patterns/detect               (admin, supervisor)
PATCH /patterns/:id/acknowledge
```

### Reports (modulo reports)
```
GET /reports/wo/:id/html
GET /reports/wo/:id/data
GET /reports/spare-parts/excel
GET /reports/work-orders/excel
```

### Metrics (modulo metrics)
```
GET /metrics/summary
GET /metrics/equipment
GET /metrics/trends
GET /metrics/technicians
GET /metrics/spare-parts
GET /metrics/corrective-ratio
GET /metrics/alerts-summary
```

### Procedures (modulo preventive)
```
GET    /procedures/
GET    /procedures/suggest
POST   /procedures/generate          (modulo ai, admin/supervisor)
POST   /procedures/                  (admin, supervisor)
GET    /procedures/:id
PUT    /procedures/:id               (admin, supervisor)
DELETE /procedures/:id               (admin, supervisor)
POST   /procedures/:id/link          (admin, supervisor)
DELETE /procedures/:id/link/:linkId   (admin, supervisor)
POST   /procedures/:id/execute
GET    /procedures/executions/:execId
POST   /procedures/executions/:execId/steps/:stepId
POST   /procedures/executions/:execId/complete
```

### User profile
```
GET   /users/:id/profile
PUT   /users/:id/profile
PATCH /users/:id/change-password     (rate limited)
```

### Daily summaries
```
GET    /daily-summaries/
POST   /daily-summaries/
PUT    /daily-summaries/:id
DELETE /daily-summaries/:id
GET    /daily-summaries/days
GET    /daily-summaries/recent-wos
GET    /daily-summaries/months       (admin, supervisor)
GET    /daily-summaries/export       (admin, supervisor)
GET    /daily-summaries/export-all   (admin, supervisor)
```

### Users (admin only)
```
GET    /users/
POST   /users/
PUT    /users/:id
DELETE /users/:id
```

### System
```
GET  /system/status
POST /system/pause                   (primary admin / superadmin)
POST /system/resume                  (primary admin / superadmin)
GET  /system/retention               (admin)
PUT  /system/retention               (admin)
```

### Superadmin (superadmin only)
```
GET  /superadmin/whoami
GET  /superadmin/tenants
PUT  /superadmin/tenants/:id/max-users
PUT  /superadmin/tenants/:id/max-nodes
PUT  /superadmin/tenants/:id/modules
POST /superadmin/tenants/:id/pause
POST /superadmin/license/reload
```
