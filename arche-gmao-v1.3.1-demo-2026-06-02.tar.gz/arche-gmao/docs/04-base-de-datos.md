# Base de datos

PostgreSQL 16 con extensiones: pgvector, ltree, pg_trgm.

## Extensiones y su uso

| Extension | Para que |
|-----------|----------|
| pgvector | Embeddings 768d (ai_embeddings), busqueda semantica |
| ltree | Arbol jerarquico factory_nodes.path |
| pg_trgm | Busqueda fuzzy en nombres/descripciones |

## Tablas principales (69 total)

### Core

| Tabla | Funcion |
|-------|---------|
| tenants | Multi-tenant: nombre, config, max_users, max_nodes, disabled_modules |
| users | Usuarios por tenant. password bcrypt, role enum |
| factory_nodes | Arbol jerarquico (ltree path). version para optimistic lock |
| work_orders | OTs con estado, prioridad, nodo, asignado, timer, version |
| spare_parts | Repuestos con stock actual, min/max, ubicacion |
| maintenance_plans | Planes preventivos con frecuencia, ultimo/proximo |

### Arbol y relaciones

| Tabla | Funcion |
|-------|---------|
| node_assignments | Que nodos ve cada usuario (supervisor/tech scope) |
| node_assignment_exclusions | Exclusiones individuales dentro de un assignment |
| spare_part_nodes | Vinculacion repuesto↔nodo (M:N) |
| node_type_definitions | Tipos de nodo configurables por tenant |
| node_tags, tags, user_tags | Sistema de etiquetas |

### Work Orders

| Tabla | Funcion |
|-------|---------|
| work_order_comments | Comentarios en OT |
| work_order_intervals | Cronometro: inicio/fin cada sesion de trabajo |
| work_order_parts | Repuestos usados en OT (descuenta stock) |
| work_order_log | Historial de cambios de estado |
| wo_scores | Evaluacion calidad OT completada |
| verification_records | Verificacion supervisor |
| stock_movements | Historial de movimientos de stock |

### IA

| Tabla | Funcion |
|-------|---------|
| ai_embeddings | Vectores 768d con IVFFlat index |
| ai_index_queue | Cola de indexacion (status: pending/processing/done/failed) |
| ai_conversations, ai_messages | Historial chat por usuario |
| ai_patterns | Patrones detectados (recurrencia, stock, frecuencia, vencido) |
| ai_knowledge, ai_knowledge_folders | Base de conocimiento admin |
| ai_custom_calcs | Calculos personalizados IA |
| ai_permission_log | Log acceso IA por rol |
| ai_usage_stats | Estadisticas uso |

### Preventivos

| Tabla | Funcion |
|-------|---------|
| maintenance_plan_templates | Plantillas de plan |
| maintenance_plan_executions | Registro de ejecuciones |
| maintenance_plan_exclusions | Fechas excluidas |
| staggered_configs | Config escalonamiento |
| staggered_schedule | Calendario escalonado |
| staggered_cycles | Ciclos activos |
| maintenance_manuals | PDFs manuales por nodo |

### Procedimientos SOP

| Tabla | Funcion |
|-------|---------|
| procedure_templates | Plantilla con pasos |
| procedure_steps | Pasos individuales |
| procedure_template_links | Vinculacion a nodos/planes |
| procedure_executions | Ejecucion de un SOP |
| procedure_step_results | Resultado por paso |
| procedure_step_evidence | Evidencia por paso |

### Otros

| Tabla | Funcion |
|-------|---------|
| notifications, notification_preferences | Sistema notificaciones |
| push_subscriptions | Web Push endpoints |
| calendar_events | Eventos calendario |
| attachments | Archivos adjuntos |
| clients | Clientes del tenant |
| daily_summaries | Resumenes diarios por usuario |
| monthly_summary_folders | Carpetas mensuales exportadas |
| user_directories, directory_items | Carpetas personales con PIN |
| equipment_compositions, composition_templates | Composiciones de equipos |
| equipment_health_history, health_weight_configs | Health score historico |
| equipment_templates, template_folders | Plantillas de equipo |
| user_competencies | Competencias tecnicas |
| qr_scans | Historial escaneos QR |
| hardware_registration | Fingerprint servidor |
| superadmin_accounts | Cuentas superadmin (fuera de tenants) |
| technician_daily_activity | Actividad diaria tecnicos |

## RLS (Row Level Security)

Doble aislamiento:

1. **Aplicacion**: todas las queries llevan `WHERE tenant_id = $N`
2. **Base de datos**: RLS policies `USING (tenant_id = current_setting('app.current_tenant_id')::BIGINT)`

Mecanismo:
- Middleware `SetTenantContext` pone tenant_id en Go context
- pgxpool `BeforeAcquire`: si hay tenant_id → `SET ROLE arche_app; SET app.current_tenant_id = X`
- pgxpool `AfterRelease`: `RESET ROLE; RESET app.current_tenant_id`
- Workers usan `context.Background()` sin tenant → owner `arche` bypasea RLS (intencional)

Migracion 038 aplica RLS a todas las tablas con columna `tenant_id` via loop PL/pgSQL.

## Migraciones

36 archivos SQL en `migrations/`. Se aplican en orden numerico.
Formato: `NNN_descripcion.sql`

En desarrollo: `make db-reset` borra y re-aplica todas.
En produccion: aplicar nuevas manualmente con psql.

## Pool de conexiones

```
MaxConns:          20 (configurable DB_MAX_CONNS)
MinConns:          2
MaxConnIdleTime:   5 min
MaxConnLifetime:   30 min
HealthCheckPeriod: 30s
```
