# Backend (Go)

## Estructura

```
cmd/server/main.go              Punto de entrada, config, inicia workers
internal/server/server.go       Fiber app, middleware chain, registro de rutas
internal/handlers/              40 handlers (uno por dominio)
internal/middleware/            Auth, permisos, RLS, rate limiting, seguridad, pausa
internal/database/              pgxpool, migraciones, hooks RLS
internal/ai/                    Ollama, RAG, workers, patterns, staggering
internal/types/                 Claims, configs compartidas
internal/config/                Variables de entorno
internal/license/               Verificacion Ed25519
internal/hwcheck/               Fingerprint hardware
internal/static/                Embed frontend compilado (produccion)
```

## Handlers

Cada handler es un struct con `*pgxpool.Pool` (y servicios opcionales). Patron:

```go
type NodesHandler struct {
    db *pgxpool.Pool
}

func NewNodesHandler(db *pgxpool.Pool) *NodesHandler { ... }
func (h *NodesHandler) GetTree(c *fiber.Ctx) error { ... }
```

Handlers existentes:
- `auth_handler` — login, refresh, logout, me
- `nodes_handler` — CRUD arbol, move, children, search
- `work_orders_handler` — CRUD OTs, status, comments, intervals, offline bundle
- `spare_parts_handler` — CRUD repuestos, movements, link/unlink nodos
- `maintenance_handler` — planes preventivos, toggle, ejecucion
- `maintenance_manuals_handler` — manuales PDF por equipo
- `maintenance_template_handler` — plantillas de plan
- `ai_handler` — chat SSE, conversations, index, reindex
- `ai_admin_handler` — modelos, knowledge, folders, roles, stats, calcs
- `metrics_handler` — MTBF, MTTR, trends, technicians, corrective ratio
- `reports_handler` — HTML/PDF OT, Excel repuestos/OTs
- `equipment_health_handler` — health score, weights, history
- `patterns_handler` — deteccion patrones IA, acknowledge
- `calendar_handler` — eventos calendario
- `notification_handler` — SSE notificaciones, marcar leida
- `push_handler` — Web Push subscribe/unsubscribe, VAPID
- `qr_handler` — generar QR, scan, sheet, excel
- `signature_handler` — firma tecnico/supervisor
- `verification_handler` — verificacion supervisor
- `procedure_handler` — SOPs, generate AI, execute steps
- `composition_handler` — composiciones de nodos
- `composition_template_handler` — plantillas composicion, clone
- `directories_handler` — carpetas personales con PIN
- `personnel_handler` — competencias, assignments
- `library_handler` — archivos adjuntos (nodo/OT)
- `import_handler` — importacion masiva nodos
- `clients_handler` — clientes del tenant
- `users_handler` — CRUD usuarios (admin only)
- `user_profile_handler` — perfil propio, change password
- `daily_summaries_handler` — resumen diario, exportar excel
- `staggering_handler` — escalonamiento preventivos
- `technician_handler` — carga de trabajo tecnicos
- `templates_handler` — plantillas equipo, assign to node
- `license_handler` — info licencia
- `system_handler` — pausa, retention, status
- `superadmin_handler` — multi-tenant management
- `health_handler` — health check endpoint
- `node_types_handler` — tipos de nodo

## Middleware chain

Orden en cada request protegido:

1. `RequireAuth` — valida JWT, extrae Claims a `c.Locals("claims")`
2. `SetTenantContext` — pone `tenant_id` en Go context para RLS
3. `globalLimiter` — 120 req/min por IP
4. `RequireSystemActive` — bloquea si tenant pausado
5. `RequireRole(roles...)` — verifica rol en Claims
6. `RequireNodeScope(db)` — nodos: solo los asignados (supervisor/tech/op)
7. `RequireModuleTenant(db, mod)` — licencia global + disabled_modules

Archivos middleware:
- `auth.go` — JWT validation, OptionalAuth
- `permissions.go` — RequireRole, RequireNodeScope, RequirePrimaryAdminOrSuperadmin, RequireSuperadminOnly
- `rls.go` — SetTenantContext (pgxpool hooks leen de aqui)
- `security.go` — security headers, HSTS, CSP
- `license.go` — RequireModuleTenant
- `system_pause.go` — RequireSystemActive

## Errores

```go
return fiber.NewError(fiber.StatusNotFound, "Equipo no encontrado")
```

Siempre en espanol. El `errorHandler` en server.go serializa a JSON `{error: "..."}`.

## Concurrencia

- `pg_advisory_xact_lock` para numeros de OT (nunca retornar `OT-TEMP-*`)
- `version` (optimistic locking) en `factory_nodes` y `work_orders`
- `context.Background()` en goroutines (nunca `c.UserContext()`)
- SSE: capturar variables ANTES de `SetBodyStreamWriter`

## Tests

```bash
go test ./... -count=1                                    # Unit (86 tests)
go test ./internal/handlers/ -tags=integration -v         # Integration (16 tests)
```

Integration tests usan `//go:build integration` y `sync.Once` para cachear tokens.
