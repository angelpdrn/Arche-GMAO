# Frontend (Vue 3 + TypeScript)

## Estructura

```
src/
  views/              18 vistas (una por ruta principal)
  components/         Subcomponentes organizados por dominio
  composables/        Logica reutilizable (hooks)
  stores/             Pinia stores (5)
  api/                Wrappers HTTP tipados (14 modulos + client base)
  types/              Interfaces TypeScript compartidas
  utils/              Utilidades puras (time, formatters)
  offline/            IndexedDB + sync service
  router/             Rutas con guards de auth y modulos
  layouts/            AppLayout (sidebar + topbar + content)
```

## Vistas

| Vista | Rol minimo | Funcion |
|-------|-----------|---------|
| LoginView | publico | Autenticacion |
| DashboardView | todos | KPIs, actividad reciente |
| FactoryView | todos | Arbol jerarquico, health, manuales |
| WorkOrdersView | todos | CRUD OTs, cronometro, evidencias |
| InventoryView | todos | Repuestos, stock, movimientos |
| MaintenancePlansView | admin/sup | Preventivos, generacion automatica |
| CalendarView | todos | Vista calendario OTs/eventos |
| MetricsView | admin/sup | MTBF, MTTR, tendencias |
| AIView | todos | Chat RAG con contexto |
| AIAdminView | admin | Config modelos, knowledge, roles |
| ProceduresView | todos | SOPs, generacion IA |
| TemplatesView | admin/sup | Plantillas equipo |
| LibraryView | todos | Archivos adjuntos |
| ImportView | admin/sup | Importacion masiva |
| UsersView | admin | Gestion usuarios |
| UserProfileView | todos | Perfil propio |
| ClientsView | admin/sup | Clientes |
| ScanView | publico | Escaneo QR |

## API modules

Patron: cada modulo exporta funciones tipadas que usan `client` (Axios con interceptor 401).

```typescript
// api/nodes.ts
import client from './client'
export const nodesApi = {
  getTree: () => client.get('/factory/tree'),
  create: (data: CreateNodePayload) => client.post('/factory/nodes', data),
}
```

Modulos: `ai`, `auth`, `client` (base), `clients`, `compositions`, `directories`, `maintenance`, `metrics`, `nodes`, `phase2`, `reports`, `staggering`, `system`, `templates`

Regla: las vistas NUNCA importan `client` directamente. Siempre usan el modulo api correspondiente.

## Stores (Pinia)

| Store | Responsabilidad |
|-------|----------------|
| auth | JWT, user, role helpers (isAdmin, isSupervisor, isManager, etc.) |
| factory | Arbol de nodos, nodo seleccionado |
| offline | Cola offline, estado sync |
| directories | Carpetas personales |
| ai | Conversaciones, mensajes |

## Composables

| Composable | Funcion |
|------------|---------|
| useActiveWO | OT activa (cronometro en curso) |
| useIsMobile | Deteccion responsive |
| useOffline | Hook para modo offline |
| useResizablePanel | Panel redimensionable |
| useShortcuts | Atajos de teclado |
| useSidebar | Estado sidebar |
| useSystemPause | Sistema pausado |
| useToast | Notificaciones toast |
| useUndo | Deshacer acciones |

## Convenciones

- CSS scoped + variables globales CSS
- Sin emojis en UI. Simbolos Unicode: `◆◇◈▤▦▣◻✦✕✎✓`
- Idioma interfaz: espanol
- Errores: `catch (e: unknown)` con `apiErrorMsg(e)` de types
- Operativas (aprobar, verificar, firmar): guard `isSupervisor`
- Estructurales (editar nodo, asociar repuesto): guard `isManager`
- Admin no ve acciones operativas en UI

## Auth flow (frontend)

1. Login → recibe `access_token` + `refresh_token` (cookie httpOnly)
2. `client` interceptor: si 401 → intenta refresh con Promise compartida (evita race)
3. SSE (ai.ts): retry silencioso en 401 con fetch nativo (no Axios)
4. Logout → POST /auth/logout + limpiar store

## Offline (PWA)

- Service worker para assets
- IndexedDB: cola de operaciones pendientes
- Sync service: procesa cola cuando vuelve conexion
- Banner automatico cuando se pierde red
