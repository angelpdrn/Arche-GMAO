# Workers (goroutines)

Tres background workers arrancan con el servidor. Todos usan `context.Background()` (bypassean RLS intencionalmente para operar cross-tenant).

## IndexWorker

Archivo: `internal/ai/index_worker.go`

Dos goroutines:

### Cola de indexacion (10s tick)
1. Lee items con `status='pending'` de `ai_index_queue` (batch, LIMIT 50)
2. Marca como `processing`
3. Segun `source_type`: indexa WO, nodo, repuesto, plan, manual, knowledge, attachment
4. Cada indexacion: genera texto → chunking (400 words, overlap 50) → embed con nomic-embed-text → INSERT en `ai_embeddings`
5. Semaforo de 3 para detecciones concurrentes

### Deteccion de patrones (1h tick)
Para cada tenant, detecta:
- Fallos recurrentes (mismo nodo, tipo correctivo, ventana 30d)
- Stock bajo (bajo minimo configurado)
- Alta frecuencia (mas OTs de lo normal)
- Preventivo vencido (proximo < hoy sin OT generada)

Resultados → `ai_patterns`. Notifica supervisores via `SetNotifyRoleFunc`.

## MaintenanceWorker

Archivo: `internal/ai/maintenance_worker.go`

Una goroutine, tick cada 1h:

1. Lee planes activos con `next_due <= NOW()`
2. Para cada plan: genera OTs automaticas para los nodos vinculados
3. Numero de OT via `pg_advisory_xact_lock` (nunca temporal)
4. Actualiza `last_generated`, calcula `next_due` segun frecuencia
5. Procesa tambien schedules escalonados (`staggered_schedule`)
6. Auto-renueva ciclos escalonados expirados

Notifica tecnicos asignados via `SetNotifyFunc`.

## MonthlySummaryWorker

Archivo: `internal/ai/summary_worker.go`

Una goroutine, corre a las 3 AM:

1. Para cada tenant, verifica si hay meses sin resumen
2. Compila resumen mensual: OTs completadas, tiempos, repuestos
3. Genera Excel por usuario (`buildUserExcel`)
4. Congela el mes (no se puede modificar OTs de meses cerrados)
5. Guarda en `monthly_summary_folders`

## Lifecycle

```go
// En main.go / server.go
indexWorker.Start()
maintenanceWorker.Start()
summaryWorker.Start()

// Shutdown graceful
indexWorker.Stop()    // cierra stopCh, wg.Wait()
maintenanceWorker.Stop()
summaryWorker.Stop()
```

Todos tienen `stopCh chan struct{}` + `sync.WaitGroup` para shutdown limpio.

## Encolar indexacion desde handlers

```go
ai.EnqueueNow(context.Background(), h.db, tenantID, "index", "work_order", woID)
```

Acciones: `index`, `delete`. Source types: `work_order`, `node`, `spare_part`, `maintenance_plan`, `manual`, `knowledge`, `attachment`.
