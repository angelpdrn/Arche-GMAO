# IA y RAG

## Stack IA

- **Ollama** en host (no Docker): accesible via `host.docker.internal:11434` (dev) o localhost (prod)
- **Modelo chat**: llama3 (configurable por admin)
- **Modelo embeddings**: nomic-embed-text (768 dimensiones)
- **Vector store**: pgvector con indice IVFFlat

## Pipeline de indexacion

```
Evento (crear/editar OT, nodo, repuesto, etc.)
  → ai.EnqueueNow() inserta en ai_index_queue
  → IndexWorker (10s) lee pending items
  → RAGService.Index{WorkOrder|Node|SparePart|...}()
    → Construye texto descriptivo del source
    → chunkText(texto, 400 palabras, overlap 50)
    → OllamaClient.Embed() → vector 768d por chunk
    → INSERT ai_embeddings (tenant_id, source_type, source_id, chunk, vector)
```

Sources indexables:
- work_order, node, spare_part, maintenance_plan, manual, knowledge, attachment

Para attachments PDF: extrae texto con `extractPDFText()`.

## Pipeline de chat (RAG)

```
Usuario envia mensaje
  → ai_handler.Chat() (SSE stream)
  → OllamaClient.Embed(query) → vector consulta
  → RAGService.Search(vector, top 10, threshold 0.15)
  → PromptBuilder construye prompt:
      - System: rol del usuario, contexto equipo seleccionado
      - RAG chunks relevantes
      - Historial conversacion (ultimos N mensajes)
  → OllamaClient.ChatStream() → Ollama streaming
      - temp: 0.3
      - num_predict: 1024
      - repeat_penalty: 1.15
  → SSE: envia tokens al frontend en tiempo real
  → Al final: guarda mensaje completo en ai_messages
```

Streaming usa `strings.Builder` (no concatenacion `+=`).

## Web Search

Si la query parece tecnica general (detectado por keywords) y RAG retorna pocos resultados:
- `ShouldSearchWeb()` evalua si buscar
- `WebSearcher.Search()` hace scraping de resultados
- Resultados se agregan como contexto extra al prompt

## Deteccion de patrones

Cada 1h el IndexWorker analiza cada tenant:

| Tipo | Deteccion |
|------|-----------|
| recurrent_failure | Mismo nodo + tipo correctivo, 3+ veces en 30 dias |
| low_stock | Stock actual < stock minimo configurado |
| high_frequency | Nodo con mas OTs que promedio + 2 stddev |
| overdue_preventive | Plan con next_due < hoy sin OT generada |

Patrones nuevos → `ai_patterns` + notificacion a supervisores.
Admin puede "acknowledge" (marcar como visto).

## Admin IA

El admin puede:
- Cambiar modelo chat/embed
- Configurar roles que pueden usar IA
- Gestionar base de conocimiento (articles + folders)
- Upload PDFs a knowledge
- Ver log de permisos y estadisticas de uso
- Crear calculos personalizados
- Editar system prompt adicional

## Archivos del paquete ai/

| Archivo | Contenido |
|---------|-----------|
| ollama_client.go | HTTP client para Ollama (chat, embed, list models) |
| rag_service.go | Index, Search, Delete embeddings, chunking |
| index_worker.go | Worker cola + patron detection |
| maintenance_worker.go | Generacion automatica OTs preventivas |
| summary_worker.go | Resumen mensual + Excel + congelacion |
| pattern_detector.go | Logica deteccion 4 tipos de patron |
| prompt_builder.go | Construye prompts con contexto RAG + equipo + rol |
| staggering_service.go | Escalonamiento inteligente de preventivos |
| web_search.go | Busqueda web como fallback |
| concurrency.go | Helpers de concurrencia (semaforo) |
