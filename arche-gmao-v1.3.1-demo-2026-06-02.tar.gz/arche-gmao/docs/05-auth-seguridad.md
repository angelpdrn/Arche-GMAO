# Auth y Seguridad

## JWT

- Access token: 15 min, header `Authorization: Bearer <token>`
- Refresh token: 7 dias, cookie httpOnly `refresh_token`
- Claims: `UserID`, `TenantID`, `Role`, `IsPrimaryAdmin`, `IsSuperadmin`
- Secret: `JWT_SECRET` (access), `JWT_REFRESH_SECRET` (refresh)
- En produccion: Fatal si secrets son los defaults de desarrollo

## Flow de autenticacion

```
POST /auth/login
  → valida credentials (bcrypt)
  → genera access + refresh
  → refresh se guarda en Redis (key: refresh:<token_hash>)
  → retorna {access_token, user}

POST /auth/refresh
  → valida refresh cookie
  → verifica en Redis (no revocado)
  → rota: genera nuevo access + nuevo refresh
  → invalida refresh anterior en Redis

POST /auth/logout
  → elimina refresh de Redis
  → limpia cookie
```

## Cambio de password

Al cambiar password se invalidan TODOS los refresh tokens del usuario en Redis. Esto cierra sesion en todos los dispositivos.

## Middleware de seguridad

### RequireAuth
Valida JWT, extrae claims, pone en `c.Locals("claims")`. Sin token → 401.

### RequireRole(roles...)
Verifica `claims.Role` esta en la lista. Si no → 403.

### RequireNodeScope(db)
Para rutas con `:id` de nodo. Verifica que el usuario tiene acceso al nodo:
- Admin/auditor: acceso total
- Supervisor/tech/op: solo nodos asignados via `node_assignments` (ltree `<@`)

### RequireModuleTenant(db, module)
Verifica:
1. Licencia global tiene el modulo activo
2. Tenant no tiene el modulo en `disabled_modules`

### RequirePrimaryAdminOrSuperadmin(db)
Solo admin principal del tenant o superadmin.

### RequireSuperadminOnly()
Solo cuentas de `superadmin_accounts`.

### RequireSystemActive(db, rdb)
Bloquea requests si tenant esta pausado (superadmin puede pausar tenants).

## Rate limiting

| Contexto | Limite |
|----------|--------|
| Login | 10/min por IP |
| Global | 120/min por IP |
| Uploads | 10/min por IP |
| AI chat | 30/min por IP |
| QR scan | 30/min por IP |

Implementado con `fiber/middleware/limiter` (sliding window).

## Security headers (produccion)

Middleware `security.go` agrega:
- `X-Frame-Options: DENY`
- `X-Content-Type-Options: nosniff`
- `X-XSS-Protection: 1; mode=block`
- `Strict-Transport-Security: max-age=31536000`
- `Content-Security-Policy` (scripts self + inline styles)
- `Referrer-Policy: strict-origin-when-cross-origin`

## Licencia Ed25519

- Archivo de licencia firmado con Ed25519
- Payload v2.0: tenant, modulos, max_users, max_nodes, expiracion
- Check periodico cada 24h
- Periodo de gracia: 72h despues de expiracion
- HardwareID: fingerprint de machine-id + MAC + IP (opcional)

## Passwords

- Bcrypt para usuarios normales
- PBKDF2 200K iteraciones para desbloqueo pendrive (licencia en USB)

## Superadmin

Cuenta separada (tabla `superadmin_accounts`), no pertenece a ningun tenant.
Puede: gestionar tenants, pausar, cambiar limites, recargar licencia.
Credenciales en `/root/.arche-superadmin` (modo 600).
