# Arche GMAO — Guia de actualizacion

## 1. Compilar nuevo binario

En la maquina de desarrollo:

```bash
./build.sh
```

## 2. Copiar al servidor

```bash
scp build/arche-server build/arche-server.sha256 usuario@servidor:/tmp/
```

Si hay migraciones nuevas:

```bash
scp migrations/038_*.sql usuario@servidor:/opt/arche-gmao/migrations/
```

## 3. Aplicar migraciones (si hay nuevas)

```bash
docker compose -f /opt/arche-gmao/docker-compose.yml exec -T postgres \
  psql -U arche -d arche < /opt/arche-gmao/migrations/038_nueva.sql
```

## 4. Ejecutar actualizacion

```bash
sudo /opt/arche-gmao/update.sh /tmp/arche-server
```

El script verifica checksum, hace backup del binario actual (guarda 5), detiene servicio, reemplaza binario, reinicia, health check. Si falla, rollback automatico.

## 5. Verificar

```bash
curl -s http://localhost:$(grep ^PORT /etc/arche/config.env | cut -d= -f2)/api/v1/health | jq .
systemctl status arche-gmao
journalctl -u arche-gmao -n 20
```

## Rollback manual

```bash
ls -lt /opt/arche-gmao/backups/
sudo systemctl stop arche-gmao
sudo cp /opt/arche-gmao/backups/arche-server.FECHA.bak /opt/arche-gmao/arche-server
sudo chmod 755 /opt/arche-gmao/arche-server
sudo systemctl start arche-gmao
```

## Notas

- Ejecutar como root
- Binario siempre Linux amd64 (`build.sh` lo hace automaticamente)
- Si cambias variables en `/etc/arche/config.env`: `systemctl restart arche-gmao`
- Modelos Ollama no requieren reinicio: `ollama pull llama3`
- Tiempo de inactividad: ~5 segundos (PWA muestra banner offline automaticamente)
