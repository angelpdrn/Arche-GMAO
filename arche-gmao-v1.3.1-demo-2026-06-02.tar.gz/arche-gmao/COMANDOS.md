# Arche GMAO — Comandos

## Desarrollo

```bash
make up | down | logs | logs-api | shell-api | shell-db | health | test-login | db-reset | db-backup
```

```bash
cd frontend && npx vue-tsc --noEmit    # Type check frontend
cd api && go build ./cmd/server/       # Compilar backend
cd api && go test ./... -count=1       # Unit tests
cd api && go test ./internal/handlers/ -tags=integration -v  # Integration tests
```

## Build produccion

```bash
./build.sh    # Frontend + Go binario embebido en build/
```

## Produccion — Servicios

```bash
systemctl status|restart|stop arche-gmao
journalctl -u arche-gmao -f
systemctl status|restart ollama
ollama list
nginx -t && systemctl reload nginx
```

## Produccion — BD y Redis

```bash
docker compose exec postgres psql -U arche -d arche
docker compose exec postgres pg_dump -U arche arche | gzip > backup_$(date +%Y%m%d).sql.gz
docker compose exec -T postgres psql -U arche -d arche < /opt/arche-gmao/migrations/038_nueva.sql
```

## Produccion — Diagnostico

```bash
curl -s http://localhost:$(grep ^PORT /etc/arche/config.env | cut -d= -f2)/api/v1/health | jq .
ss -tlnp | grep -E ':(80|443) '
docker compose -f /opt/arche-gmao/docker-compose.yml ps
df -h /opt/arche-gmao/ && free -h
```

## Actualizacion

```bash
sudo ./update.sh /tmp/arche-server    # Rollback automatico si falla
```

## SSL

```bash
sudo certbot renew                                              # Let's Encrypt
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout /etc/arche/ssl/privkey.pem -out /etc/arche/ssl/fullchain.pem \
  -subj "/CN=$(hostname)" && systemctl restart nginx            # Autofirmado
```
