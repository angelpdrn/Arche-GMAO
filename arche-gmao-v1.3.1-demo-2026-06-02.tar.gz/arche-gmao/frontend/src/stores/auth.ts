import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { authApi } from '@/api/auth'
import { setAccessToken, getAccessToken } from '@/api/client'
import { clearLicenseCache } from '@/router'
import type { User, LoginRequest } from '@/types'

export const useAuthStore = defineStore('auth', () => {
  const user = ref<User | null>(null)
  const loading = ref(false)
  const error = ref<string | null>(null)
  const systemPaused = ref(false)
  let initDone = false

  const isAuthenticated = computed(() => user.value !== null)
  const isAdmin = computed(() => user.value?.role === 'admin')
  // isSupervisor = supervisor ONLY (it does not include admin)
  const isSupervisor = computed(() => user.value?.role === 'supervisor')
  // isManager = admin OR supervisor (for actions both can perform)
  const isManager = computed(() =>
    ['admin', 'supervisor'].includes(user.value?.role ?? '')
  )
  // isOperational = the roles that work in the field/operations
  const isOperational = computed(() =>
    ['supervisor', 'technician', 'operator'].includes(user.value?.role ?? '')
  )
  const isFieldWorker = computed(() =>
    ['technician', 'operator'].includes(user.value?.role ?? '')
  )

  const isPrimaryAdmin = computed(() => user.value?.is_primary_admin === true)
  const isSuperadmin = computed(() => user.value?.is_superadmin === true)

  // ─── Initialize from the in-memory token ──────────────────────────────────
  // On page reload, try to restore the session through the refresh cookie.

  async function init() {
    if (initDone) return
    initDone = true

    // When there is a token in memory, try to use it
    if (getAccessToken()) {
      try {
        const meData = await authApi.me()
        user.value = meData
        systemPaused.value = meData.system_paused ?? false
        return
      } catch {
        setAccessToken(null)
      }
    }

    // Try a silent refresh with the httpOnly cookie
    try {
      const res = await authApi.refresh()
      setAccessToken(res.access_token)
      const meData = await authApi.me()
      user.value = meData
      systemPaused.value = meData.system_paused ?? false
    } catch (err: unknown) {
      const axiosErr = err as { response?: { status?: number }; code?: string }
      const isNetworkError = !axiosErr.response?.status || axiosErr.code === 'ERR_NETWORK' || axiosErr.code === 'ECONNABORTED'
      if (!isNetworkError) {
        setAccessToken(null)
        user.value = null
      }
    }
  }

  // ─── Login ────────────────────────────────────────────────────────────────

  async function login(credentials: LoginRequest) {
    loading.value = true
    error.value = null

    try {
      const response = await authApi.login(credentials)
      setAccessToken(response.access_token)
      user.value = response.user
      systemPaused.value = response.system_paused ?? false
      return true
    } catch (err: unknown) {
      const axiosError = err as { response?: { data?: { error?: string } } }
      error.value =
        axiosError.response?.data?.error ?? 'Error al iniciar sesión'
      return false
    } finally {
      loading.value = false
    }
  }

  // ─── Logout ───────────────────────────────────────────────────────────────

  async function logout() {
    try {
      await authApi.logout()
    } catch {
      // Ignore errors while logging out (the token may have expired)
    } finally {
      setAccessToken(null)
      user.value = null
      systemPaused.value = false
      clearLicenseCache()
    }
  }

  function setSystemPaused(paused: boolean) {
    systemPaused.value = paused
  }

  function clearError() {
    error.value = null
  }

  return {
    user,
    loading,
    error,
    systemPaused,
    isAuthenticated,
    isAdmin,
    isSupervisor,
    isManager,
    isOperational,
    isFieldWorker,
    isPrimaryAdmin,
    isSuperadmin,
    init,
    login,
    logout,
    setSystemPaused,
    clearError
  }
})
