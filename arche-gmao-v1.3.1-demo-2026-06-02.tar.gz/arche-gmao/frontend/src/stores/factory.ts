import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { nodesApi } from '@/api/nodes'
import type { FactoryNode, SearchResult } from '@/types/factory'

export const useFactoryStore = defineStore('factory', () => {
  const tree = ref<FactoryNode[]>([])
  const selectedNode = ref<FactoryNode | null>(null)
  const loading = ref(false)
  const searchResults = ref<SearchResult[]>([])
  const searchQuery = ref('')
  const isSearching = ref(false)
  const expandedIds = ref<Set<number>>(new Set())

  const hasTree = computed(() => tree.value.length > 0)

  // ─── Load the full tree ────────────────────────────────────────────────

  async function loadTree() {
    loading.value = true
    try {
      const data = await nodesApi.getTree()
      tree.value = data.nodes ?? []
      // Expand the first level automatically
      if (tree.value.length > 0) {
        expandedIds.value.add(tree.value[0].id)
      }
    } finally {
      loading.value = false
    }
  }

  // ─── Select a node ────────────────────────────────────────────────────

  async function selectNode(node: FactoryNode) {
    selectedNode.value = node
    // Reload from the API to get fresh data
    try {
      const fresh = await nodesApi.getOne(node.id)
      selectedNode.value = fresh
    } catch {
      // On failure, use the node from the tree
    }
  }

  function clearSelection() {
    selectedNode.value = null
  }

  // ─── Toggle expand ───────────────────────────────────────────────────────

  function toggleExpand(id: number) {
    if (expandedIds.value.has(id)) {
      expandedIds.value.delete(id)
    } else {
      expandedIds.value.add(id)
    }
  }

  function isExpanded(id: number) {
    return expandedIds.value.has(id)
  }

  // ─── Search ────────────────────────────────────────────────────────────

  let searchTimeout: ReturnType<typeof setTimeout> | null = null

  function setSearch(q: string) {
    searchQuery.value = q
    if (searchTimeout) clearTimeout(searchTimeout)

    if (q.length < 2) {
      searchResults.value = []
      isSearching.value = false
      return
    }

    isSearching.value = true
    searchTimeout = setTimeout(async () => {
      try {
        const data = await nodesApi.search(q)
        searchResults.value = data.results ?? []
      } catch {
        searchResults.value = []
      } finally {
        isSearching.value = false
      }
    }, 300)
  }

  function clearSearch() {
    searchQuery.value = ''
    searchResults.value = []
    isSearching.value = false
  }

  // ─── Update the tree after mutations ────────────────────────────────────

  async function refreshTree() {
    const currentSelectedId = selectedNode.value?.id
    await loadTree()
    if (currentSelectedId) {
      const found = findNodeById(tree.value, currentSelectedId)
      if (found) selectedNode.value = found
    }
  }

  function findNodeById(nodes: FactoryNode[], id: number, depth = 0): FactoryNode | null {
    if (depth > 50) return null
    for (const n of nodes) {
      if (n.id === id) return n
      if (n.children?.length) {
        const found = findNodeById(n.children, id, depth + 1)
        if (found) return found
      }
    }
    return null
  }

  return {
    tree,
    selectedNode,
    loading,
    searchResults,
    searchQuery,
    isSearching,
    expandedIds,
    hasTree,
    loadTree,
    selectNode,
    clearSelection,
    toggleExpand,
    isExpanded,
    setSearch,
    clearSearch,
    refreshTree,
    findNodeById
  }
})
