import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { db, type OfflineWorkOrder, type OfflineOperation } from '@/offline/db'
import { useAuthStore } from '@/stores/auth'
import { startSyncListener, processQueue } from '@/offline/syncService'
import { workOrdersApi } from '@/api/phase2'
import type { WOStatus, WOComment, WOLogEntry } from '@/types/workorders'
import { WO_TRANSITIONS } from '@/types/workorders'

export const useOfflineStore = defineStore('offline', () => {
  const isOnline = ref(navigator.onLine)
  const pendingCount = ref(0)
  const lastSync = ref<Date | null>(null)
  const syncing = ref(false)
  const syncError = ref<string | null>(null)
  const storageWarning = ref(false)

  const SYNC_INTERVAL = 5 * 60 * 1000
  let syncTimer: ReturnType<typeof setInterval> | null = null

  const cacheAge = computed(() => {
    if (!lastSync.value) return null
    const mins = Math.floor((Date.now() - lastSync.value.getTime()) / 60000)
    if (mins < 1) return 'Hace menos de 1 min'
    if (mins < 60) return `Hace ${mins} min`
    return `Hace ${Math.floor(mins / 60)}h`
  })

  async function refreshPendingCount() {
    pendingCount.value = await db.operationQueue.where('status').anyOf(['pending', 'failed']).count()
  }

  async function loadSyncMeta() {
    const row = await db.syncMeta.get('lastSync')
    if (row) lastSync.value = new Date(row.value)
  }

  async function saveSyncMeta() {
    lastSync.value = new Date()
    await db.syncMeta.put({ key: 'lastSync', value: lastSync.value.toISOString() })
  }

  async function syncFromServer() {
    if (!isOnline.value || syncing.value) return
    syncing.value = true
    syncError.value = null
    try {
      const bundle = await workOrdersApi.offlineBundle()
      const serverWOs = bundle.work_orders ?? []

      const offlineWOs: OfflineWorkOrder[] = serverWOs.map((wo: any) => ({
        id: wo.id,
        tenant_id: wo.tenant_id,
        node_id: wo.node_id,
        node_name: wo.node_name,
        wo_number: wo.wo_number,
        title: wo.title,
        description: wo.description,
        wo_type: wo.wo_type,
        priority: wo.priority,
        status: wo.status,
        assigned_to: wo.assigned_to,
        assigned_name: wo.assigned_name,
        created_by: wo.created_by,
        created_by_name: wo.created_by_name,
        estimated_hours: wo.estimated_hours,
        actual_hours: wo.actual_hours,
        planned_start: wo.planned_start,
        planned_end: wo.planned_end,
        started_at: wo.started_at,
        completed_at: wo.completed_at,
        closed_at: wo.closed_at,
        root_cause: wo.root_cause,
        solution: wo.solution,
        version: wo.version,
        created_at: wo.created_at,
        updated_at: wo.updated_at,
        comments: wo.comments ?? [],
        log: wo.log ?? [],
      }))

      await db.transaction('rw', [db.workOrders, db.operationQueue], async () => {
        const pendingWoIds = new Set(
          (await db.operationQueue.where('status').anyOf(['pending', 'processing']).toArray())
            .map(op => op.woId)
        )
        const allIds = (await db.workOrders.toCollection().primaryKeys()) as number[]
        const toDelete = allIds.filter(id => !pendingWoIds.has(id))
        await db.workOrders.bulkDelete(toDelete)

        for (const wo of offlineWOs) {
          if (pendingWoIds.has(wo.id)) {
            // Only update the server version, without overwriting local changes
            const local = await db.workOrders.get(wo.id)
            if (local) {
              await db.workOrders.update(wo.id, { version: wo.version })
            }
          } else {
            await db.workOrders.put(wo)
          }
        }
      })

      await saveSyncMeta()
    } catch {
      syncError.value = 'Error al sincronizar datos'
    } finally {
      syncing.value = false
    }
  }

  async function getWorkOrders(): Promise<OfflineWorkOrder[]> {
    return db.workOrders.toArray()
  }

  async function getWorkOrder(id: number): Promise<OfflineWorkOrder | undefined> {
    return db.workOrders.get(id)
  }

  async function changeStatusOffline(
    woId: number,
    newStatus: WOStatus,
    comment?: string,
    extraData?: { actual_hours?: number; root_cause?: string; solution?: string }
  ) {
    const wo = await db.workOrders.get(woId)
    if (!wo) throw new Error('OT no encontrada en caché local')

    const auth = useAuthStore()
    const userRole = auth.user?.role ?? ''
    const transitions = WO_TRANSITIONS[wo.status] ?? []
    const valid = transitions.find(t => t.to === newStatus && t.roles.includes(userRole))
    if (!valid) throw new Error(`Transición ${wo.status} → ${newStatus} no permitida para rol ${userRole}`)
    if (valid.requireComment && !comment) throw new Error('Esta transición requiere un comentario')

    const now = new Date().toISOString()
    const updates: Partial<OfflineWorkOrder> = { status: newStatus, updated_at: now }
    if (newStatus === 'in_progress' && !wo.started_at) updates.started_at = now
    if (newStatus === 'completed') updates.completed_at = now
    if (newStatus === 'closed') updates.closed_at = now
    if (extraData?.actual_hours !== undefined) updates.actual_hours = extraData.actual_hours
    if (extraData?.root_cause) updates.root_cause = extraData.root_cause
    if (extraData?.solution) updates.solution = extraData.solution

    const logEntry: WOLogEntry = {
      id: -(Date.now() * 1000 + Math.floor(Math.random() * 1000)),
      user_id: auth.user?.id ?? null,
      user_name: auth.user?.full_name ?? null,
      from_status: wo.status,
      to_status: newStatus,
      comment: comment ?? null,
      created_at: now,
    }
    updates.log = [...wo.log, logEntry]

    await db.workOrders.update(woId, updates)

    const payload: Record<string, unknown> = {
      status: newStatus,
      version: wo.version,
    }
    if (comment) payload.comment = comment
    if (extraData?.actual_hours !== undefined) payload.actual_hours = extraData.actual_hours
    if (extraData?.root_cause) payload.root_cause = extraData.root_cause
    if (extraData?.solution) payload.solution = extraData.solution

    await db.operationQueue.add({
      woId,
      type: 'change_status',
      payload,
      createdAt: now,
      status: 'pending',
      retries: 0,
      error: null,
    })

    await refreshPendingCount()
  }

  async function addCommentOffline(woId: number, content: string) {
    const wo = await db.workOrders.get(woId)
    if (!wo) throw new Error('OT no encontrada en caché local')

    const auth = useAuthStore()
    const now = new Date().toISOString()

    const localComment: WOComment = {
      id: -(Date.now() * 1000 + Math.floor(Math.random() * 1000)),
      user_id: auth.user?.id ?? null,
      user_name: auth.user?.full_name ?? null,
      content,
      created_at: now,
    }

    await db.workOrders.update(woId, {
      comments: [...wo.comments, localComment],
      updated_at: now,
    })

    await db.operationQueue.add({
      woId,
      type: 'add_comment',
      payload: { content },
      createdAt: now,
      status: 'pending',
      retries: 0,
      error: null,
    })

    await refreshPendingCount()
  }

  async function getFailedOperations(): Promise<OfflineOperation[]> {
    return db.operationQueue.where('status').equals('failed').toArray()
  }

  async function retryFailedOperation(localId: number) {
    await db.operationQueue.update(localId, { status: 'pending', retries: 0, error: null })
    await refreshPendingCount()
  }

  async function discardFailedOperation(localId: number) {
    await db.operationQueue.delete(localId)
    await refreshPendingCount()
  }

  async function clearAllData() {
    await db.transaction('rw', [db.workOrders, db.operationQueue, db.syncMeta], async () => {
      await db.workOrders.clear()
      await db.operationQueue.clear()
      await db.syncMeta.clear()
    })
    pendingCount.value = 0
    lastSync.value = null
  }

  async function checkStorageQuota() {
    if (!navigator.storage?.estimate) {
      storageWarning.value = false
      return
    }
    try {
      const est = await navigator.storage.estimate()
      if (est.quota && est.usage) {
        storageWarning.value = (est.usage / est.quota) * 100 > 80
      } else {
        storageWarning.value = false
      }
    } catch { storageWarning.value = false }
  }

  function startPeriodicSync() {
    if (syncTimer) return
    syncTimer = setInterval(() => {
      if (isOnline.value && !syncing.value) {
        syncFromServer()
        checkStorageQuota()
      }
    }, SYNC_INTERVAL)
  }

  function stopPeriodicSync() {
    if (syncTimer) {
      clearInterval(syncTimer)
      syncTimer = null
    }
  }

  let listenersAttached = false
  function onOnline() {
    isOnline.value = true
    startPeriodicSync()
  }
  function onOffline() {
    isOnline.value = false
    stopPeriodicSync()
  }

  function init() {
    if (listenersAttached) return

    loadSyncMeta()
    refreshPendingCount()
    checkStorageQuota()

    window.addEventListener('online', onOnline)
    window.addEventListener('offline', onOffline)
    listenersAttached = true

    startSyncListener()

    if (isOnline.value) {
      syncFromServer()
      startPeriodicSync()
    }
  }

  function cleanup() {
    window.removeEventListener('online', onOnline)
    window.removeEventListener('offline', onOffline)
    stopPeriodicSync()
    listenersAttached = false
  }

  return {
    isOnline,
    pendingCount,
    lastSync,
    syncing,
    syncError,
    cacheAge,
    init,
    cleanup,
    syncFromServer,
    getWorkOrders,
    getWorkOrder,
    changeStatusOffline,
    addCommentOffline,
    getFailedOperations,
    retryFailedOperation,
    discardFailedOperation,
    clearAllData,
    refreshPendingCount,
    processQueue,
    storageWarning,
  }
})
