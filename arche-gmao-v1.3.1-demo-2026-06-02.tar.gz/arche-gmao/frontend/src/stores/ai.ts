import { defineStore } from 'pinia'
import { ref } from 'vue'
import { aiApi } from '@/api/ai'
import type { AIMessage, AIConversation, AISource, AIStatus } from '@/api/ai'

export const useAIStore = defineStore('ai', () => {
  // Chat state
  const isOpen = ref(false)
  const isStreaming = ref(false)
  const currentConvId = ref<number | null>(null)
  const activeNodeId = ref<number | null>(null)
  const activeNodeName = ref<string | null>(null)
  const messages = ref<AIMessage[]>([])
  const conversations = ref<AIConversation[]>([])
  const status = ref<AIStatus | null>(null)

  // For cancelling the stream in flight
  let cancelStream: (() => void) | null = null

  // ─── Open / close the chat ──────────────────────────────────────────────────

  function openChat(nodeId?: number | null, nodeName?: string | null) {
    if (isStreaming.value && activeNodeId.value !== (nodeId ?? null)) {
      cancelCurrentStream()
    }
    activeNodeId.value = nodeId ?? null
    activeNodeName.value = nodeName ?? null
    isOpen.value = true
  }

  /**
   * Opens the chat with a fresh conversation and sends an automatic message.
   * Used to start a diagnosis from "Suggest root cause".
   */
  function openDiagnostic(nodeId: number, nodeName: string, initialMessage: string) {
    // New conversation on the equipment's node
    currentConvId.value = null
    messages.value = []
    activeNodeId.value = nodeId
    activeNodeName.value = nodeName
    isOpen.value = true
    // Send the message automatically once the render has had time
    setTimeout(() => {
      sendMessage(initialMessage)
    }, 200)
  }

  function closeChat() {
    isOpen.value = false
  }

  function newConversation(nodeId?: number | null, nodeName?: string | null) {
    currentConvId.value = null
    messages.value = []
    activeNodeId.value = nodeId ?? null
    activeNodeName.value = nodeName ?? null
  }

  // ─── Send a message ───────────────────────────────────────────────────────

  async function sendMessage(text: string) {
    if (isStreaming.value || !text.trim()) return

    // Add the user's message straight away
    const userMsg: AIMessage = {
      id: Date.now(),
      role: 'user',
      content: text,
      created_at: new Date().toISOString(),
    }
    messages.value.push(userMsg)

    // Assistant placeholder (streaming)
    const assistantMsg: AIMessage = {
      id: Date.now() + 1,
      role: 'assistant',
      content: '',
      created_at: new Date().toISOString(),
    }
    messages.value.push(assistantMsg)
    isStreaming.value = true

    cancelStream = aiApi.chatStream({
      message: text,
      conversationId: currentConvId.value,
      nodeId: activeNodeId.value,

      onToken(token) {
        // Update the assistant's last message
        const last = messages.value[messages.value.length - 1]
        if (last.role === 'assistant') {
          last.content += token
        }
      },

      onDone(sources, convId) {
        isStreaming.value = false
        cancelStream = null
        currentConvId.value = convId

        // Add the sources to the message
        const last = messages.value[messages.value.length - 1]
        if (last.role === 'assistant') {
          last.sources = sources
        }

        // Update the conversation list
        loadConversations()
      },

      onError(error) {
        isStreaming.value = false
        cancelStream = null
        // Replace the placeholder with the error
        const last = messages.value[messages.value.length - 1]
        if (last.role === 'assistant' && !last.content) {
          last.content = `Error: ${error}`
        }
      },
    })
  }

  function cancelCurrentStream() {
    if (cancelStream) {
      cancelStream()
      cancelStream = null
      isStreaming.value = false
    }
  }

  // ─── Load the history ─────────────────────────────────────────────────────

  async function loadConversations() {
    try {
      const data = await aiApi.listConversations()
      conversations.value = data.conversations ?? []
    } catch { /* silent */ }
  }

  async function loadConversation(id: number) {
    try {
      const data = await aiApi.getConversation(id)
      messages.value = (data.messages ?? []).filter(m => m.role !== 'system')
      currentConvId.value = id
    } catch { /* silent */ }
  }

  async function deleteConversation(id: number) {
    await aiApi.deleteConversation(id)
    if (currentConvId.value === id) {
      newConversation()
    }
    await loadConversations()
  }

  // ─── AI status ──────────────────────────────────────────────────────

  async function loadStatus() {
    try {
      status.value = await aiApi.getStatus()
    } catch {
      status.value = null
    }
  }

  function reset() {
    cancelCurrentStream()
    isOpen.value = false
    isStreaming.value = false
    currentConvId.value = null
    activeNodeId.value = null
    activeNodeName.value = null
    messages.value = []
    conversations.value = []
    status.value = null
  }

  return {
    isOpen, isStreaming, currentConvId,
    activeNodeId, activeNodeName,
    messages, conversations, status,
    openChat, closeChat, newConversation,
    openDiagnostic,
    sendMessage, cancelCurrentStream,
    loadConversations, loadConversation, deleteConversation,
    loadStatus,
    reset,
  }
})
