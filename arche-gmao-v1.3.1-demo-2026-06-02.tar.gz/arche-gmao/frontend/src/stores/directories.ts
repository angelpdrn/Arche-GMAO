import { defineStore } from 'pinia'
import { ref, reactive } from 'vue'
import { directoriesApi } from '@/api/directories'
import type { Directory, DirectorySection, CreateDirectoryData, UpdateDirectoryData } from '@/api/directories'

export const useDirectoriesStore = defineStore('directories', () => {
  // Cache per section
  const myDirs = reactive<Record<string, Directory[]>>({})
  const publicDirs = reactive<Record<string, Directory[]>>({})
  const loading = reactive<Record<string, boolean>>({})

  // PINs verified this session (dirId → true)
  // Kept in memory — lost on page reload (deliberate)
  const unlockedDirs = ref<Set<number>>(new Set())

  async function loadSection(section: DirectorySection) {
    loading[section] = true
    try {
      const data = await directoriesApi.list(section)
      myDirs[section] = data.my_dirs ?? []
      publicDirs[section] = data.public_dirs ?? []
    } finally {
      loading[section] = false
    }
  }

  async function create(data: CreateDirectoryData) {
    const result = await directoriesApi.create(data)
    await loadSection(data.section)
    return result
  }

  async function update(id: number, data: UpdateDirectoryData, section: DirectorySection) {
    await directoriesApi.update(id, data)
    await loadSection(section)
  }

  async function remove(id: number, section: DirectorySection) {
    await directoriesApi.delete(id)
    unlockedDirs.value.delete(id)
    await loadSection(section)
  }

  // ─── PIN ──────────────────────────────────────────────────────────────────

  function isUnlocked(dirId: number): boolean {
    return unlockedDirs.value.has(dirId)
  }

  async function verifyPin(dirId: number, pin: string): Promise<boolean> {
    try {
      await directoriesApi.verifyPin(dirId, pin)
      unlockedDirs.value.add(dirId)
      return true
    } catch {
      return false
    }
  }

  function lockDir(dirId: number) {
    unlockedDirs.value.delete(dirId)
  }

  // ─── Items ────────────────────────────────────────────────────────────────

  async function addItem(dirId: number, itemType: string, itemId: number, section: DirectorySection) {
    await directoriesApi.addItem(dirId, itemType, itemId)
    await loadSection(section)
  }

  // ─── Helpers ──────────────────────────────────────────────────────────────

  function getMyDirs(section: DirectorySection): Directory[] {
    return myDirs[section] ?? []
  }

  function getPublicDirs(section: DirectorySection): Directory[] {
    return publicDirs[section] ?? []
  }

  function isLoading(section: DirectorySection): boolean {
    return loading[section] ?? false
  }

  function countItems(dirs: Directory[]): number {
    return dirs.reduce((sum, d) => sum + d.item_count + countItems(d.children ?? []), 0)
  }

  // Find a directory by ID in the tree
  function findDir(dirs: Directory[], id: number): Directory | null {
    for (const d of dirs) {
      if (d.id === id) return d
      const found = findDir(d.children ?? [], id)
      if (found) return found
    }
    return null
  }

  function findDirInSection(section: DirectorySection, id: number): Directory | null {
    return findDir(getMyDirs(section), id) ?? findDir(getPublicDirs(section), id)
  }

  return {
    myDirs,
    publicDirs,
    loading,
    unlockedDirs,
    loadSection,
    create,
    update,
    remove,
    isUnlocked,
    verifyPin,
    lockDir,
    addItem,
    getMyDirs,
    getPublicDirs,
    isLoading,
    countItems,
    findDir,
    findDirInSection,
  }
})
