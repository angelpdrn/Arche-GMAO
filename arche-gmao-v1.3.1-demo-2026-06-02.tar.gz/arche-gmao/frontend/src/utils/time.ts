/**
 * Date/time helpers in Spanish, tuned for operational lists.
 *
 * - formatRelative: "hace 3 min", "ayer", "en 2 días"…
 * - formatSmart:    relative under 24h, compact absolute when older.
 * - formatDate:     absolute date + time (compatibility).
 * - formatDateTime: date + time with seconds (intervals).
 *
 * Design: no Intl.RelativeTimeFormat (it does not behave the same across
 * PWA browsers). Short strings, industrial tone. Being pure, they can be
 * used in templates without computeds.
 */

const MIN = 60_000
const HOUR = 60 * MIN
const DAY = 24 * HOUR
const MONTH = 30 * DAY

const ABS_DATE: Intl.DateTimeFormatOptions = {
  day: '2-digit', month: '2-digit', year: 'numeric',
}
const ABS_DATETIME: Intl.DateTimeFormatOptions = {
  day: '2-digit', month: '2-digit', year: 'numeric',
  hour: '2-digit', minute: '2-digit',
}
const ABS_TIME_FULL: Intl.DateTimeFormatOptions = {
  day: '2-digit', month: '2-digit', year: 'numeric',
  hour: '2-digit', minute: '2-digit', second: '2-digit',
}

function parse(input: string | Date | null | undefined): Date | null {
  if (!input) return null
  if (input instanceof Date) return isNaN(input.getTime()) ? null : input
  // The backend returns TIMESTAMPTZ::text as "2026-04-28 10:14:32.123+00".
  // Browsers understand it, but we normalize it to ISO for old Safari.
  const iso = input.includes('T') ? input : input.replace(' ', 'T')
  const d = new Date(iso)
  return isNaN(d.getTime()) ? null : d
}

/**
 * Returns a relative string in Spanish: "hace 3 min", "en 2 días", "ahora".
 * When the date is null/invalid it returns "—".
 */
export function formatRelative(input: string | Date | null | undefined): string {
  const d = parse(input)
  if (!d) return '—'
  const now = Date.now()
  const diff = now - d.getTime()
  const abs = Math.abs(diff)
  const future = diff < 0

  if (abs < 45_000) return 'ahora'
  if (abs < HOUR) {
    const m = Math.round(abs / MIN)
    return future ? `en ${m} min` : `hace ${m} min`
  }
  if (abs < DAY) {
    const h = Math.round(abs / HOUR)
    return future ? `en ${h} h` : `hace ${h} h`
  }
  if (abs < 7 * DAY) {
    const days = Math.round(abs / DAY)
    if (days === 1) return future ? 'mañana' : 'ayer'
    return future ? `en ${days} días` : `hace ${days} días`
  }
  if (abs < MONTH) {
    const w = Math.round(abs / (7 * DAY))
    return future ? `en ${w} sem` : `hace ${w} sem`
  }
  if (abs < 12 * MONTH) {
    const m = Math.round(abs / MONTH)
    return future ? `en ${m} meses` : `hace ${m} meses`
  }
  const y = Math.round(abs / (12 * MONTH))
  return future ? `en ${y} año${y > 1 ? 's' : ''}` : `hace ${y} año${y > 1 ? 's' : ''}`
}

/**
 * "Smart" version: relative for the last 24h, short absolute when older.
 * Ideal for table columns and activity feeds.
 */
export function formatSmart(input: string | Date | null | undefined): string {
  const d = parse(input)
  if (!d) return '—'
  const diff = Math.abs(Date.now() - d.getTime())
  if (diff < DAY) return formatRelative(d)
  return d.toLocaleDateString('es-ES', ABS_DATE)
}

/** Absolute date + time (kept for compatibility with existing code). */
export function formatDate(input: string | Date | null | undefined): string {
  const d = parse(input)
  if (!d) return '—'
  try { return d.toLocaleString('es-ES', ABS_DATETIME) } catch { return String(input) }
}

/** Date + time with seconds, e.g. for work intervals. */
export function formatDateTime(input: string | Date | null | undefined): string {
  const d = parse(input)
  if (!d) return '—'
  try { return d.toLocaleString('es-ES', ABS_TIME_FULL) } catch { return String(input) }
}

/**
 * Human-readable duration from minutes (accumulated from intervals).
 * "1h 25m", "3 días", etc.
 */
export function formatDurationMinutes(min: number | null | undefined): string {
  if (min == null || isNaN(min)) return '—'
  if (min < 1) return '<1 min'
  if (min < 60) return `${Math.round(min)} min`
  const h = min / 60
  if (h < 24) {
    const hh = Math.floor(h)
    const mm = Math.round(min - hh * 60)
    return mm === 0 ? `${hh}h` : `${hh}h ${mm}m`
  }
  const d = Math.floor(h / 24)
  const rh = Math.round(h - d * 24)
  return rh === 0 ? `${d} días` : `${d}d ${rh}h`
}
