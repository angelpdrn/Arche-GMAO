import { createApp } from 'vue'
import { createPinia } from 'pinia'

import App from './App.vue'
import router from './router'
import './assets/styles/main.css'
import './assets/styles/responsive.css'

const app = createApp(App)

app.use(createPinia())
app.use(router)

app.mount('#app')

// Dismiss splash screen after app mounts
requestAnimationFrame(() => {
  const splash = document.getElementById('app-splash')
  if (splash) {
    splash.classList.add('fade-out')
    setTimeout(() => splash.remove(), 500)
  }
})

// Register the Service Worker for PWA + push notifications
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js').then((reg) => {
    reg.addEventListener('updatefound', () => {
      const newWorker = reg.installing
      if (!newWorker) return
      newWorker.addEventListener('statechange', () => {
        if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
          newWorker.postMessage('skipWaiting')
        }
      })
    })
  }).catch(() => {})

  navigator.serviceWorker.addEventListener('message', (event) => {
    if (event.data?.type === 'sync-operations') {
      import('@/offline/syncService').then(({ processQueue }) => processQueue())
    }
  })
}
