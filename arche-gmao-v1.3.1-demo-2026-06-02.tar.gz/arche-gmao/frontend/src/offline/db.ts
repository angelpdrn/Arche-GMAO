import Dexie, { type EntityTable } from 'dexie'
import type { WOStatus, WOType, WOPriority, WOComment, WOLogEntry } from '@/types/workorders'

export interface OfflineWorkOrder {
  id: number
  tenant_id: number
  node_id: number
  node_name: string
  wo_number: string
  title: string
  description: string | null
  wo_type: WOType
  priority: WOPriority
  status: WOStatus
  assigned_to: number | null
  assigned_name: string | null
  created_by: number | null
  created_by_name: string | null
  estimated_hours: number | null
  actual_hours: number | null
  planned_start: string | null
  planned_end: string | null
  started_at: string | null
  completed_at: string | null
  closed_at: string | null
  root_cause: string | null
  solution: string | null
  version: number
  created_at: string
  updated_at: string
  comments: WOComment[]
  log: WOLogEntry[]
}

export type OfflineOpType = 'change_status' | 'add_comment'
export type OfflineOpStatus = 'pending' | 'processing' | 'failed'

export interface OfflineOperation {
  localId?: number
  woId: number
  type: OfflineOpType
  payload: Record<string, unknown>
  createdAt: string
  status: OfflineOpStatus
  retries: number
  error: string | null
}

export interface SyncMeta {
  key: string
  value: string
}

const db = new Dexie('ArcheOffline') as Dexie & {
  workOrders: EntityTable<OfflineWorkOrder, 'id'>
  operationQueue: EntityTable<OfflineOperation, 'localId'>
  syncMeta: EntityTable<SyncMeta, 'key'>
}

db.version(1).stores({
  workOrders: 'id, status, assigned_to',
  operationQueue: '++localId, status, woId',
  syncMeta: 'key',
})

export { db }
