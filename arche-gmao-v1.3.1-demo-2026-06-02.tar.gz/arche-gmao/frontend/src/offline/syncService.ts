import { db, type OfflineOperation } from './db'
import client from '@/api/client'
import { useOfflineStore } from '@/stores/offline'

const MAX_RETRIES = 5
const BACKOFF_BASE = 1000

let processing = false

function backoffDelay(retries: number): number {
  return BACKOFF_BASE * Math.pow(2, retries)
}

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms))
}

async function executeOperation(op: OfflineOperation): Promise<{ success: boolean; retry: boolean }> {
  try {
    if (op.type === 'change_status') {
      await client.patch(`/work-orders/${op.woId}/status`, op.payload)
      return { success: true, retry: false }
    }

    if (op.type === 'add_comment') {
      await client.post(`/work-orders/${op.woId}/comments`, op.payload)
      return { success: true, retry: false }
    }

    return { success: false, retry: false }
  } catch (err: unknown) {
    const axiosErr = err as { response?: { status?: number }; code?: string }
    const status = axiosErr.response?.status
    const isNetworkError = !status || axiosErr.code === 'ERR_NETWORK' || axiosErr.code === 'ECONNABORTED'

    if (isNetworkError) {
      return { success: false, retry: true }
    }

    if (status === 401) {
      return { success: false, retry: true }
    }

    if (status === 409) {
      return await handleConflict(op)
    }

    if (status === 429 || status === 502 || status === 503 || status === 504) {
      return { success: false, retry: true }
    }

    return { success: false, retry: false }
  }
}

async function handleConflict(op: OfflineOperation): Promise<{ success: boolean; retry: boolean }> {
  try {
    if (op.type === 'change_status') {
      const { data } = await client.get(`/work-orders/${op.woId}`)
      const serverWO = data.work_order
      const updatedPayload = { ...op.payload, version: serverWO.version }
      const resp = await client.patch(`/work-orders/${op.woId}/status`, updatedPayload)
      if (resp.status >= 200 && resp.status < 300) {
        await db.workOrders.update(op.woId, {
          version: serverWO.version + 1,
          status: op.payload.status as string,
        })
      }
      return { success: true, retry: false }
    }

    if (op.type === 'add_comment') {
      await client.post(`/work-orders/${op.woId}/comments`, op.payload)
      return { success: true, retry: false }
    }

    return { success: false, retry: false }
  } catch {
    return { success: false, retry: false }
  }
}

export async function processQueue(): Promise<void> {
  if (processing || !navigator.onLine) return
  processing = true

  try {
    await db.operationQueue.where('status').equals('processing').modify({ status: 'pending' })

    const pending = await db.operationQueue
      .where('status')
      .equals('pending')
      .sortBy('localId')

    for (const op of pending) {
      if (!navigator.onLine) break

      await db.operationQueue.update(op.localId!, { status: 'processing' })

      const result = await executeOperation(op)

      if (result.success) {
        await db.operationQueue.delete(op.localId!)
        continue
      }

      if (result.retry && op.retries < MAX_RETRIES) {
        await db.operationQueue.update(op.localId!, {
          status: 'pending',
          retries: op.retries + 1,
        })
        await sleep(backoffDelay(op.retries))
        continue
      }

      const errorMsg = result.retry
        ? `Sin conexión tras ${MAX_RETRIES} reintentos`
        : 'Operación rechazada por el servidor'

      await db.operationQueue.update(op.localId!, {
        status: 'failed',
        error: errorMsg,
      })
    }

    const offlineStore = useOfflineStore()
    await offlineStore.refreshPendingCount()

    if (navigator.onLine) {
      await offlineStore.syncFromServer()
    }
  } finally {
    processing = false
  }
}

let listenerAttached = false

export function startSyncListener(): void {
  if (listenerAttached) return
  listenerAttached = true

  window.addEventListener('online', () => {
    setTimeout(processQueue, 1000)
  })

  if (navigator.onLine) {
    processQueue()
  }
}
