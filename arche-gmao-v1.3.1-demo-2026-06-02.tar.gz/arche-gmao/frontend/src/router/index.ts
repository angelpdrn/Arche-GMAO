import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { systemApi } from '@/api/system'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/login',
      name: 'login',
      component: () => import('@/views/LoginView.vue'),
      meta: { requiresGuest: true }
    },
    {
      path: '/scan/:code',
      name: 'scan',
      component: () => import('@/views/ScanView.vue'),
    },
    {
      path: '/',
      component: () => import('@/layouts/AppLayout.vue'),
      meta: { requiresAuth: true },
      children: [
        { path: '',                    redirect: '/dashboard' },
        { path: 'dashboard',           name: 'dashboard',           component: () => import('@/views/DashboardView.vue') },
        { path: 'factory',             name: 'factory',             component: () => import('@/views/FactoryView.vue') },
        { path: 'templates',           name: 'templates',           component: () => import('@/views/TemplatesView.vue'), meta: { requiresAdmin: true } },
        { path: 'work-orders',         name: 'work-orders',         component: () => import('@/views/WorkOrdersView.vue') },
        { path: 'inventory',           name: 'inventory',           component: () => import('@/views/InventoryView.vue'), meta: { requiresInventory: true } },
        { path: 'clients',             name: 'clients',             component: () => import('@/views/ClientsView.vue'), meta: { requiresAdmin: true } },
        { path: 'library',             name: 'library',             component: () => import('@/views/LibraryView.vue') },
        { path: 'calendar',            name: 'calendar',            component: () => import('@/views/CalendarView.vue') },
        { path: 'maintenance-plans',   name: 'maintenance-plans',   component: () => import('@/views/MaintenancePlansView.vue'), meta: { requiresManager: true, requiresModule: 'preventive' } },
        { path: 'procedures',         name: 'procedures',         component: () => import('@/views/ProceduresView.vue'), meta: { requiresManager: true, requiresModule: 'preventive' } },
        { path: 'import',              name: 'import',              component: () => import('@/views/ImportView.vue'), meta: { requiresAdmin: true } },
        { path: 'ai',                  name: 'ai',                  component: () => import('@/views/AIView.vue'), meta: { requiresModule: 'ai' } },
        { path: 'ai/admin',            name: 'ai-admin',            component: () => import('@/views/AIAdminView.vue'), meta: { requiresAdmin: true, requiresModule: 'ai' } },
        { path: 'metrics',             name: 'metrics',             component: () => import('@/views/MetricsView.vue'), meta: { requiresModule: 'metrics' } },
        {
          path: 'users/:id/profile',
          name: 'user-profile',
          component: () => import('@/views/UserProfileView.vue'),
        },
        {
          path: 'users',
          name: 'users',
          component: () => import('@/views/UsersView.vue'),
          meta: { requiresAdmin: true }
        },
      ]
    },
    { path: '/:pathMatch(.*)*', redirect: '/' }
  ]
})

// License module cache (loaded once after login)
let licenseModules: string[] | null = null

export function clearLicenseCache() {
  licenseModules = null
}

async function loadLicenseModules(): Promise<string[]> {
  if (licenseModules) return licenseModules
  try {
    const info = await systemApi.getLicenseInfo()
    licenseModules = info.modules
  } catch {
    licenseModules = ['all'] // on error, allow everything
  }
  return licenseModules
}

function hasModule(mod: string): boolean {
  if (!licenseModules) return true
  return licenseModules.includes(mod) || licenseModules.includes('all')
}

router.beforeEach(async (to, _from, next) => {
  const auth = useAuthStore()
  if (!auth.isAuthenticated) {
    await auth.init()
  }
  if (to.name === 'scan') return next()
  if (to.meta.requiresAuth && !auth.isAuthenticated)
    return next({ name: 'login', query: { redirect: to.fullPath } })
  if (to.meta.requiresGuest && auth.isAuthenticated)
    return next({ name: 'dashboard' })
  if (to.meta.requiresAdmin && auth.user?.role !== 'admin' && !auth.isSuperadmin)
    return next({ name: 'dashboard' })
  if (to.meta.requiresSupervisor && !['admin','supervisor'].includes(auth.user?.role ?? ''))
    return next({ name: 'dashboard' })
  if (to.meta.requiresManager && !['admin','supervisor'].includes(auth.user?.role ?? ''))
    return next({ name: 'dashboard' })
  if (to.meta.requiresInventory && !['admin','supervisor','warehouse'].includes(auth.user?.role ?? ''))
    return next({ name: 'dashboard' })

  // Check the license module
  if (to.meta.requiresModule && auth.isAuthenticated) {
    await loadLicenseModules()
    if (!hasModule(to.meta.requiresModule as string))
      return next({ name: 'dashboard' })
  }

  next()
})

// Clear the cache on logout so it reloads after the next login
router.afterEach((to) => {
  if (to.name === 'login') licenseModules = null
})

export default router
