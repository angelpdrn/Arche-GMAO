<template>
  <Teleport to="body">
    <div class="toast-host" role="status" aria-live="polite">
      <TransitionGroup name="toast">
        <div
          v-for="t in toasts"
          :key="t.id"
          :class="['toast', `toast--${t.type}`]"
          @click="dismiss(t.id)">
          <span class="toast-icon">{{ iconFor(t.type) }}</span>
          <div class="toast-body">
            <div class="toast-message">{{ t.message }}</div>
            <div v-if="t.detail" class="toast-detail">{{ t.detail }}</div>
          </div>
          <button
            v-if="t.action"
            class="toast-action"
            @click.stop="runAction(t)">{{ t.action.label }}</button>
          <button class="toast-close" @click.stop="dismiss(t.id)" aria-label="Cerrar">✕</button>
        </div>
      </TransitionGroup>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
import { useToast, type Toast, type ToastType } from '@/composables/useToast'

const { toasts, dismiss } = useToast()

function iconFor(type: ToastType): string {
  switch (type) {
    case 'success': return '✓'
    case 'error':   return '✕'
    case 'warning': return '!'
    case 'info':
    default:        return 'i'
  }
}

async function runAction(t: Toast) {
  try {
    await t.action?.handler()
  } finally {
    dismiss(t.id)
  }
}
</script>

<style scoped>
.toast-host {
  position: fixed;
  top: var(--space-4);
  right: var(--space-4);
  z-index: 10000;
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  pointer-events: none;
  max-width: 380px;
  width: calc(100vw - var(--space-8, 32px));
}

.toast {
  pointer-events: auto;
  display: flex;
  align-items: flex-start;
  gap: var(--space-3);
  padding: var(--space-3) var(--space-4);
  border-radius: var(--radius-md, 8px);
  background: var(--color-surface, #1a1a26);
  border: 1px solid var(--color-border, #2a2a3a);
  border-left-width: 4px;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.25);
  font-size: 0.85rem;
  color: var(--color-text, #e5e5e8);
  cursor: pointer;
  transition: transform 120ms ease, opacity 120ms ease;
}
.toast:hover { transform: translateX(-2px); }

.toast--success { border-left-color: #27ae60; }
.toast--error   { border-left-color: #e94560; }
.toast--warning { border-left-color: #f39c12; }
.toast--info    { border-left-color: #3b82f6; }

.toast-icon {
  flex-shrink: 0;
  width: 22px; height: 22px;
  display: inline-flex; align-items: center; justify-content: center;
  border-radius: 50%;
  font-weight: 700; font-size: 0.78rem;
  margin-top: 1px;
}
.toast--success .toast-icon { background: rgba(39, 174, 96, 0.18); color: #27ae60; }
.toast--error   .toast-icon { background: rgba(233, 69, 96, 0.18); color: #e94560; }
.toast--warning .toast-icon { background: rgba(243, 156, 18, 0.18); color: #f39c12; }
.toast--info    .toast-icon { background: rgba(59, 130, 246, 0.18); color: #3b82f6; }

.toast-body { flex: 1; min-width: 0; }
.toast-message { font-weight: 500; line-height: 1.35; word-break: break-word; }
.toast-detail  { margin-top: 2px; font-size: 0.78rem; color: var(--color-text-muted, #888); }

.toast-action {
  flex-shrink: 0;
  background: transparent;
  border: 1px solid var(--color-border-light, #3a3a4a);
  color: var(--color-text, #e5e5e8);
  border-radius: var(--radius, 4px);
  padding: 4px 10px;
  font-size: 0.78rem; font-weight: 600;
  cursor: pointer;
  transition: background 120ms;
}
.toast-action:hover { background: var(--color-border-light, #3a3a4a); }

.toast-close {
  flex-shrink: 0;
  background: transparent;
  border: none;
  color: var(--color-text-muted, #888);
  font-size: 0.85rem;
  cursor: pointer;
  padding: 0 2px;
}
.toast-close:hover { color: var(--color-text, #e5e5e8); }

/* Transitions */
.toast-enter-active, .toast-leave-active {
  transition: opacity 200ms ease, transform 200ms ease;
}
.toast-enter-from { opacity: 0; transform: translateX(20px); }
.toast-leave-to   { opacity: 0; transform: translateX(20px); }

@media (max-width: 640px) {
  .toast-host {
    top: auto;
    bottom: var(--space-4);
    left: var(--space-3);
    right: var(--space-3);
    max-width: none;
    width: auto;
  }
}
</style>
