<template>
  <Transition name="failed-slide">
    <div v-if="failedOps.length > 0 && showPanel" class="failed-panel">
      <div class="failed-header">
        <span class="failed-title">&#x26A0; {{ failedOps.length }} operación{{ failedOps.length > 1 ? 'es' : '' }} fallida{{ failedOps.length > 1 ? 's' : '' }}</span>
        <button class="failed-close" @click="showPanel = false">&times;</button>
      </div>
      <div class="failed-list">
        <div v-for="op in failedOps" :key="op.localId" class="failed-item">
          <div class="failed-item-info">
            <span class="failed-item-type">{{ opLabel(op) }}</span>
            <span class="failed-item-error">{{ op.error }}</span>
          </div>
          <div class="failed-item-actions">
            <button class="btn-retry" @click="retry(op.localId!)" :disabled="retrying">Reintentar</button>
            <button class="btn-discard" @click="discard(op.localId!)">Descartar</button>
          </div>
        </div>
      </div>
      <div v-if="failedOps.length > 1" class="failed-footer">
        <button class="btn-retry-all" @click="retryAll" :disabled="retrying">Reintentar todas</button>
        <button class="btn-discard-all" @click="discardAll">Descartar todas</button>
      </div>
    </div>
  </Transition>
  <button v-if="failedOps.length > 0 && !showPanel" class="failed-badge" @click="showPanel = true">
    &#x26A0; {{ failedOps.length }} fallida{{ failedOps.length > 1 ? 's' : '' }}
  </button>
</template>

<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import { useOfflineStore } from '@/stores/offline'
import type { OfflineOperation } from '@/offline/db'

const offlineStore = useOfflineStore()
const failedOps = ref<OfflineOperation[]>([])
const showPanel = ref(false)
const retrying = ref(false)

async function loadFailed() {
  failedOps.value = await offlineStore.getFailedOperations()
}

function opLabel(op: OfflineOperation): string {
  if (op.type === 'change_status') return `Cambio de estado OT #${op.woId}`
  if (op.type === 'add_comment') return `Comentario OT #${op.woId}`
  return `Operacion OT #${op.woId}`
}

async function retry(localId: number) {
  retrying.value = true
  try {
    await offlineStore.retryFailedOperation(localId)
    await offlineStore.processQueue()
    await loadFailed()
  } finally { retrying.value = false }
}

async function discard(localId: number) {
  await offlineStore.discardFailedOperation(localId)
  await loadFailed()
}

async function retryAll() {
  retrying.value = true
  try {
    for (const op of failedOps.value) {
      if (op.localId) await offlineStore.retryFailedOperation(op.localId)
    }
    await offlineStore.processQueue()
    await loadFailed()
  } finally { retrying.value = false }
}

async function discardAll() {
  for (const op of failedOps.value) {
    if (op.localId) await offlineStore.discardFailedOperation(op.localId)
  }
  await loadFailed()
}

onMounted(loadFailed)

watch(() => offlineStore.pendingCount, loadFailed)
</script>

<style scoped>
.failed-panel {
  position: fixed; bottom: 20px; right: 20px;
  background: #1A1A2E; color: #fff; border-radius: 12px;
  box-shadow: 0 8px 32px rgba(0,0,0,0.3); z-index: 200;
  max-width: 380px; width: calc(100vw - 40px);
  overflow: hidden;
}
.failed-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 12px 16px; background: #E94560;
}
.failed-title { font-weight: 600; font-size: 0.85rem; }
.failed-close { background: none; border: none; color: #fff; font-size: 1.2rem; cursor: pointer; padding: 0 4px; }
.failed-list { max-height: 240px; overflow-y: auto; }
.failed-item { padding: 10px 16px; border-bottom: 1px solid rgba(255,255,255,0.08); }
.failed-item-info { margin-bottom: 6px; }
.failed-item-type { display: block; font-size: 0.8rem; font-weight: 500; }
.failed-item-error { display: block; font-size: 0.72rem; opacity: 0.7; margin-top: 2px; }
.failed-item-actions { display: flex; gap: 8px; }
.btn-retry, .btn-discard, .btn-retry-all, .btn-discard-all {
  font-size: 0.72rem; border: none; border-radius: 4px; padding: 4px 10px; cursor: pointer;
}
.btn-retry { background: #3B82F6; color: #fff; }
.btn-retry:disabled { opacity: 0.5; }
.btn-discard { background: rgba(255,255,255,0.1); color: #ccc; }
.btn-retry-all { background: #3B82F6; color: #fff; flex: 1; }
.btn-retry-all:disabled { opacity: 0.5; }
.btn-discard-all { background: rgba(255,255,255,0.15); color: #ccc; flex: 1; }
.failed-footer { display: flex; gap: 8px; padding: 10px 16px; border-top: 1px solid rgba(255,255,255,0.1); }
.failed-badge {
  position: fixed; bottom: 20px; right: 20px;
  background: #E94560; color: #fff; border: none; border-radius: 20px;
  padding: 8px 16px; font-size: 0.8rem; font-weight: 600;
  cursor: pointer; z-index: 200; box-shadow: 0 4px 16px rgba(233,69,96,0.4);
}
.failed-slide-enter-active, .failed-slide-leave-active { transition: transform 0.3s ease, opacity 0.3s; }
.failed-slide-enter-from, .failed-slide-leave-to { transform: translateY(20px); opacity: 0; }
</style>
