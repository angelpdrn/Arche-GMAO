<template>
  <Transition name="active-wo-slide">
    <RouterLink
      v-if="activeWO"
      :to="goTo"
      class="active-wo-banner"
      :title="`${activeWO.wo_number} — abierta hace ${elapsedLabel}`">
      <span class="active-wo-pulse"></span>
      <div class="active-wo-text">
        <span class="active-wo-label">OT en curso</span>
        <span class="active-wo-number mono">{{ activeWO.wo_number }}</span>
        <span class="active-wo-title">{{ activeWO.title }}</span>
      </div>
      <span class="active-wo-elapsed mono">{{ elapsedLabel }}</span>
    </RouterLink>
  </Transition>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useActiveWO } from '@/composables/useActiveWO'

const { activeWO, elapsedLabel } = useActiveWO()

const goTo = computed(() => {
  if (!activeWO.value) return '/work-orders'
  return { path: '/work-orders', query: { open: String(activeWO.value.id) } }
})
</script>

<style scoped>
.active-wo-banner {
  display: flex;
  align-items: center;
  gap: var(--space-3, 12px);
  padding: 8px 14px;
  background: linear-gradient(90deg, rgba(39, 174, 96, 0.12), rgba(39, 174, 96, 0.04));
  border-bottom: 1px solid rgba(39, 174, 96, 0.35);
  color: var(--color-text, #d5d5d8);
  font-size: 0.82rem;
  text-decoration: none;
  cursor: pointer;
  transition: background 120ms ease;
}
.active-wo-banner:hover { background: rgba(39, 174, 96, 0.18); }

.active-wo-pulse {
  width: 8px; height: 8px; border-radius: 50%;
  background: #27ae60;
  flex-shrink: 0;
  position: relative;
  animation: pulse 1.4s ease-in-out infinite;
}
.active-wo-pulse::before {
  content: '';
  position: absolute; inset: -4px;
  border-radius: 50%;
  border: 1px solid rgba(39, 174, 96, 0.7);
  animation: ring 1.4s ease-in-out infinite;
}

.active-wo-text {
  flex: 1;
  display: flex;
  align-items: baseline;
  gap: var(--space-2, 8px);
  min-width: 0;
}
.active-wo-label {
  color: #27ae60;
  font-weight: 600;
  font-size: 0.72rem;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  flex-shrink: 0;
}
.active-wo-number {
  font-weight: 600;
  flex-shrink: 0;
}
.active-wo-title {
  color: var(--color-text-muted, #888);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
}

.active-wo-elapsed {
  color: #27ae60;
  font-variant-numeric: tabular-nums;
  font-weight: 600;
  flex-shrink: 0;
}

.active-wo-slide-enter-active, .active-wo-slide-leave-active {
  transition: max-height 200ms ease, opacity 200ms ease;
  overflow: hidden;
}
.active-wo-slide-enter-from, .active-wo-slide-leave-to {
  max-height: 0;
  opacity: 0;
}
.active-wo-slide-enter-to, .active-wo-slide-leave-from {
  max-height: 60px;
  opacity: 1;
}

@keyframes pulse {
  0%, 100% { transform: scale(1);   opacity: 1; }
  50%      { transform: scale(0.85); opacity: 0.7; }
}
@keyframes ring {
  0%   { transform: scale(0.9); opacity: 0.8; }
  100% { transform: scale(1.8); opacity: 0; }
}

@media (max-width: 640px) {
  .active-wo-banner { font-size: 0.78rem; padding: 6px 10px; gap: var(--space-2, 8px); }
  .active-wo-title { display: none; }
  .active-wo-label { font-size: 0.68rem; }
}
</style>
