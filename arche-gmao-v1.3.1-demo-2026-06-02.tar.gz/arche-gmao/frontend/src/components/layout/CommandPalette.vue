<template>
  <Teleport to="body">
    <Transition name="palette-fade">
      <div v-if="open" class="palette-overlay" @click.self="close">
        <div class="palette" role="dialog" aria-label="Buscar">
          <div class="palette-search">
            <span class="palette-icon">⌕</span>
            <input
              ref="inputRef"
              v-model="query"
              class="palette-input"
              placeholder="Saltar a una vista, OT, equipo o repuesto..."
              autocomplete="off"
              @keydown.down.prevent="moveCursor(1)"
              @keydown.up.prevent="moveCursor(-1)"
              @keydown.enter.prevent="runActive()"
              @keydown.escape="close" />
            <span class="palette-hint">Esc</span>
          </div>

          <div class="palette-results">
            <div v-if="loading" class="palette-empty small">Buscando...</div>
            <div v-else-if="!groups.length" class="palette-empty small">
              {{ query.trim() ? 'Sin resultados' : 'Escribe para buscar...' }}
            </div>

            <template v-for="(group, gi) in groups" :key="group.label">
              <div class="palette-group-label">{{ group.label }}</div>
              <button
                v-for="(item, ii) in group.items"
                :key="`${gi}-${ii}-${item.id}`"
                type="button"
                class="palette-item"
                :class="{ 'palette-item--active': cursor === flatIndex(gi, ii) }"
                @mouseenter="cursor = flatIndex(gi, ii)"
                @click="run(item)">
                <span class="palette-item-icon">{{ item.icon ?? '◇' }}</span>
                <span class="palette-item-text">
                  <span class="palette-item-title">{{ item.title }}</span>
                  <span v-if="item.subtitle" class="palette-item-sub">{{ item.subtitle }}</span>
                </span>
                <span v-if="item.shortcut" class="palette-item-shortcut">{{ item.shortcut }}</span>
              </button>
            </template>
          </div>

          <footer class="palette-footer">
            <span><kbd>↑</kbd><kbd>↓</kbd> Navegar</span>
            <span><kbd>↵</kbd> Abrir</span>
            <span><kbd>Esc</kbd> Cerrar</span>
          </footer>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup lang="ts">
import { ref, computed, watch, onMounted, onBeforeUnmount, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import client from '@/api/client'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const authStore = useAuthStore()

interface Item {
  id: string | number
  title: string
  subtitle?: string
  icon?: string
  shortcut?: string
  /** Action to run when the item is activated */
  run: () => void
}
interface Group {
  label: string
  items: Item[]
}

const open = ref(false)
const query = ref('')
const cursor = ref(0)
const loading = ref(false)
const inputRef = ref<HTMLInputElement | null>(null)

// Static catalogue of views, filtered by permissions
const navItems = computed<Item[]>(() => {
  const a = authStore
  const list: Item[] = [
    { id: 'nav-dashboard', icon: '◈', title: 'Dashboard',         subtitle: 'Resumen del día',                              run: () => goto('/dashboard') },
    { id: 'nav-factory',   icon: '▤', title: 'Fábrica Virtual',    subtitle: 'Árbol de equipos',                            run: () => goto('/factory') },
    { id: 'nav-wo',        icon: '◇', title: 'Órdenes de trabajo', subtitle: 'OTs activas y pendientes',                     run: () => goto('/work-orders') },
    { id: 'nav-inv',       icon: '▦', title: 'Inventario',         subtitle: 'Repuestos y movimientos',                      run: () => goto('/inventory') },
    { id: 'nav-cal',       icon: '◷', title: 'Calendario',         subtitle: 'Eventos y vencimientos',                       run: () => goto('/calendar') },
    { id: 'nav-mp',        icon: '◷', title: 'Mantenimiento preventivo', subtitle: 'Planes y plantillas',                  run: () => goto('/maintenance-plans') },
    { id: 'nav-procs',     icon: '✓', title: 'Procedimientos',     subtitle: 'SOP digitales',                                 run: () => goto('/procedures') },
    { id: 'nav-metrics',   icon: '▣', title: 'Métricas',           subtitle: 'Indicadores clave',                            run: () => goto('/metrics') },
    { id: 'nav-ai',        icon: '◬', title: 'Arché IA',           subtitle: 'Asistente de mantenimiento',                  run: () => goto('/ai') },
    { id: 'nav-cli',       icon: '◯', title: 'Clientes',           subtitle: 'Gestión de clientes',                          run: () => goto('/clients') },
    { id: 'nav-imp',       icon: '⬇', title: 'Importación',        subtitle: 'Excel y mantenimiento de datos',               run: () => goto('/import') },
    { id: 'nav-users',     icon: '◉', title: 'Usuarios',           subtitle: 'Cuentas y roles',                              run: () => goto('/users') },
  ]
  // Simple filters by role
  return list.filter(it => {
    if (it.id === 'nav-cli' || it.id === 'nav-imp' || it.id === 'nav-users') return a.isAdmin
    if (it.id === 'nav-mp' || it.id === 'nav-procs') return a.isManager
    return true
  })
})

// Dynamic results (WOs, equipment)
const woResults = ref<Item[]>([])
const nodeResults = ref<Item[]>([])

let searchTimer: number | undefined
async function runSearch() {
  if (searchTimer) window.clearTimeout(searchTimer)
  const q = query.value.trim()
  if (!q || q.length < 2) {
    woResults.value = []
    nodeResults.value = []
    return
  }
  searchTimer = window.setTimeout(async () => {
    loading.value = true
    try {
      // WOs: the backend only filters status/type/priority/node_id, not q.
      // We filter client-side over the last 100 (List returns LIMIT 100).
      const [woResp, nodeResp] = await Promise.all([
        client.get<{ work_orders: any[] }>('/work-orders/'),
        client.get<{ results: any[] }>('/factory/search', { params: { q } }),
      ])
      const lower = q.toLowerCase()
      woResults.value = (woResp.data.work_orders ?? [])
        .filter(w => (w.wo_number?.toLowerCase().includes(lower)
                   || w.title?.toLowerCase().includes(lower)
                   || w.node_name?.toLowerCase().includes(lower)))
        .slice(0, 5)
        .map(w => ({
          id: `wo-${w.id}`, icon: '◇',
          title: `${w.wo_number} — ${w.title}`,
          subtitle: w.node_name,
          run: () => router.push({ path: '/work-orders', query: { open: String(w.id) } }),
        }))
      nodeResults.value = (nodeResp.data.results ?? [])
        .slice(0, 5)
        .map((n: any) => ({
          id: `node-${n.id}`, icon: '▤',
          title: n.name,
          subtitle: n.code ? `${n.code} · ${n.node_type}` : n.node_type,
          run: () => router.push({ path: '/factory', query: { node: String(n.id) } }),
        }))
    } catch {
      // Silent: the palette must not break the session
    } finally {
      loading.value = false
    }
  }, 200) as unknown as number
}

watch(query, runSearch)

const groups = computed<Group[]>(() => {
  const q = query.value.trim().toLowerCase()
  const filteredNav = q
    ? navItems.value.filter(n => n.title.toLowerCase().includes(q) || n.subtitle?.toLowerCase().includes(q))
    : navItems.value
  const out: Group[] = []
  if (filteredNav.length) out.push({ label: 'Vistas', items: filteredNav })
  if (woResults.value.length) out.push({ label: 'Órdenes de trabajo', items: woResults.value })
  if (nodeResults.value.length) out.push({ label: 'Equipos', items: nodeResults.value })
  return out
})

// Flatten group/index → a single global index for arrow key navigation
function flatIndex(gi: number, ii: number) {
  let n = 0
  for (let i = 0; i < gi; i++) n += groups.value[i].items.length
  return n + ii
}
function totalCount(): number {
  return groups.value.reduce((s, g) => s + g.items.length, 0)
}
function moveCursor(delta: number) {
  const t = totalCount()
  if (!t) return
  cursor.value = (cursor.value + delta + t) % t
}
function activeItem(): Item | null {
  let n = 0
  for (const g of groups.value) {
    if (cursor.value < n + g.items.length) return g.items[cursor.value - n]
    n += g.items.length
  }
  return null
}
function runActive() {
  const it = activeItem()
  if (it) run(it)
}
function run(it: Item) {
  it.run()
  close()
}

function goto(path: string) {
  router.push(path)
}
function close() {
  open.value = false
  query.value = ''
  woResults.value = []
  nodeResults.value = []
  cursor.value = 0
}

watch(query, () => { cursor.value = 0 })

// Global shortcut: Cmd+K (Mac) / Ctrl+K (Win/Linux)
function onKey(e: KeyboardEvent) {
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
    e.preventDefault()
    open.value = true
    nextTick(() => inputRef.value?.focus())
  }
}

onMounted(() => window.addEventListener('keydown', onKey))
onBeforeUnmount(() => window.removeEventListener('keydown', onKey))

watch(open, (v) => {
  if (v) nextTick(() => inputRef.value?.focus())
})
</script>

<style scoped>
.palette-overlay {
  position: fixed; inset: 0;
  background: rgba(0, 0, 0, 0.55);
  z-index: 9700;
  display: flex; justify-content: center;
  padding-top: 12vh; padding-left: var(--space-4); padding-right: var(--space-4);
}
.palette {
  width: 100%; max-width: 580px;
  max-height: 60vh;
  background: var(--color-surface, #1a1a26);
  border: 1px solid var(--color-border-light, #3a3a4a);
  border-radius: var(--radius-md, 8px);
  display: flex; flex-direction: column;
  overflow: hidden;
  box-shadow: 0 25px 60px rgba(0, 0, 0, 0.5);
}

.palette-search {
  display: flex; align-items: center; gap: 8px;
  padding: 10px 14px;
  border-bottom: 1px solid var(--color-border-light, #2a2a3a);
}
.palette-icon {
  font-size: 1rem;
  color: var(--color-text-muted, #888);
}
.palette-input {
  flex: 1;
  background: transparent;
  border: none;
  outline: none;
  color: var(--color-text);
  font-size: 0.9rem;
}
.palette-hint {
  font-size: 0.7rem;
  color: var(--color-text-muted);
  border: 1px solid var(--color-border-light);
  padding: 1px 6px;
  border-radius: 3px;
  font-family: var(--font-mono);
}

.palette-results {
  flex: 1;
  overflow-y: auto;
  padding: 4px;
}
.palette-empty { padding: var(--space-4); text-align: center; color: var(--color-text-muted); }

.palette-group-label {
  padding: 8px 12px 4px;
  font-size: 0.68rem; font-weight: 600;
  text-transform: uppercase; letter-spacing: 0.06em;
  color: var(--color-text-muted, #888);
}
.palette-item {
  width: 100%;
  display: flex; align-items: center; gap: 10px;
  padding: 8px 12px;
  background: transparent;
  border: none;
  border-radius: var(--radius, 4px);
  text-align: left;
  cursor: pointer;
  font: inherit;
  color: var(--color-text);
}
.palette-item--active { background: var(--color-primary, #0f3460); color: #fff; }
.palette-item-icon { font-size: 1rem; opacity: 0.85; flex-shrink: 0; }
.palette-item-text { flex: 1; display: flex; flex-direction: column; min-width: 0; }
.palette-item-title { font-size: 0.86rem; font-weight: 500; }
.palette-item--active .palette-item-title { color: #fff; }
.palette-item-sub { font-size: 0.75rem; color: var(--color-text-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.palette-item--active .palette-item-sub { color: rgba(255, 255, 255, 0.75); }
.palette-item-shortcut { font-family: var(--font-mono); font-size: 0.72rem; opacity: 0.7; }

.palette-footer {
  display: flex; gap: var(--space-4);
  padding: 8px 14px;
  border-top: 1px solid var(--color-border-light, #2a2a3a);
  background: var(--color-surface-2, #20202c);
  font-size: 0.72rem;
  color: var(--color-text-muted);
}
.palette-footer kbd {
  background: var(--color-surface);
  border: 1px solid var(--color-border-light);
  border-bottom-width: 2px;
  border-radius: 3px;
  padding: 0 6px;
  margin: 0 4px 0 0;
  font-family: var(--font-mono);
  font-size: 0.7rem;
}

.palette-fade-enter-active, .palette-fade-leave-active { transition: opacity 150ms ease; }
.palette-fade-enter-from, .palette-fade-leave-to { opacity: 0; }
</style>
