<template>
  <Teleport to="body">
    <Transition name="cheatsheet-fade">
      <div v-if="state.cheatsheetOpen" class="cheatsheet-overlay" @click.self="close">
        <div class="cheatsheet" role="dialog" aria-labelledby="ch-title">
          <header class="cheatsheet-header">
            <h3 id="ch-title">Atajos de teclado</h3>
            <button class="cheatsheet-close" @click="close" aria-label="Cerrar">✕</button>
          </header>

          <div class="cheatsheet-body">
            <div v-for="(group, scope) in groups" :key="scope" class="cheatsheet-group">
              <h4>{{ scope || 'Global' }}</h4>
              <ul>
                <li v-for="s in group" :key="s.id">
                  <kbd v-for="k in keyParts(s.key)" :key="k" class="kbd">{{ prettyKey(k) }}</kbd>
                  <span class="cheatsheet-desc">{{ s.description }}</span>
                </li>
              </ul>
            </div>

            <div class="cheatsheet-group">
              <h4>Siempre disponible</h4>
              <ul>
                <li>
                  <kbd class="kbd">?</kbd>
                  <span class="cheatsheet-desc">Mostrar / ocultar esta ayuda</span>
                </li>
                <li>
                  <kbd class="kbd">Esc</kbd>
                  <span class="cheatsheet-desc">Cerrar diálogos</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { shortcutsState } from '@/composables/useShortcuts'

const state = shortcutsState

const groups = computed(() => {
  const m: Record<string, typeof state.shortcuts> = {}
  for (const s of state.shortcuts) {
    const k = s.scope || ''
    if (!m[k]) m[k] = []
    m[k].push(s)
  }
  return m
})

function close() { state.cheatsheetOpen = false }

function keyParts(key: string): string[] {
  return key.split('+')
}
function prettyKey(k: string): string {
  switch (k) {
    case 'mod': return navigator.platform.includes('Mac') ? '⌘' : 'Ctrl'
    case 'alt': return navigator.platform.includes('Mac') ? '⌥' : 'Alt'
    case 'shift': return '⇧'
    case 'escape': return 'Esc'
    case 'arrowup': return '↑'
    case 'arrowdown': return '↓'
    case 'arrowleft': return '←'
    case 'arrowright': return '→'
    case ' ': return 'Espacio'
    case 'enter': return '↵'
    default: return k.length === 1 ? k.toUpperCase() : k
  }
}
</script>

<style scoped>
.cheatsheet-overlay {
  position: fixed; inset: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 9500;
  display: flex; align-items: center; justify-content: center;
  padding: var(--space-4, 16px);
}
.cheatsheet {
  width: 100%; max-width: 540px;
  max-height: 80vh;
  background: var(--color-surface, #1a1a26);
  border: 1px solid var(--color-border-light, #3a3a4a);
  border-radius: var(--radius-md, 8px);
  display: flex; flex-direction: column;
  overflow: hidden;
  box-shadow: 0 20px 50px rgba(0, 0, 0, 0.4);
}
.cheatsheet-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: var(--space-4, 16px);
  border-bottom: 1px solid var(--color-border-light, #2a2a3a);
}
.cheatsheet-header h3 { margin: 0; font-size: 0.95rem; font-weight: 600; color: var(--color-text); }
.cheatsheet-close {
  background: none; border: none; color: var(--color-text-muted, #888);
  font-size: 0.9rem; cursor: pointer;
}
.cheatsheet-body {
  padding: var(--space-4, 16px);
  overflow-y: auto;
  display: flex; flex-direction: column; gap: var(--space-4, 16px);
}
.cheatsheet-group h4 {
  margin: 0 0 var(--space-2, 8px) 0;
  font-size: 0.72rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--color-text-muted, #888);
}
.cheatsheet-group ul { list-style: none; margin: 0; padding: 0; }
.cheatsheet-group li {
  display: flex; align-items: center; gap: var(--space-3, 12px);
  padding: 6px 0;
}
.kbd {
  display: inline-flex; align-items: center; justify-content: center;
  min-width: 26px; height: 24px;
  padding: 0 6px;
  background: var(--color-surface-2, #20202c);
  border: 1px solid var(--color-border-light, #3a3a4a);
  border-bottom-width: 2px;
  border-radius: var(--radius-sm, 4px);
  font-family: var(--font-mono, monospace);
  font-size: 0.78rem; font-weight: 600;
  color: var(--color-text, #d5d5d8);
}
.cheatsheet-desc { font-size: 0.85rem; color: var(--color-text, #d5d5d8); }

.cheatsheet-fade-enter-active, .cheatsheet-fade-leave-active {
  transition: opacity 150ms ease;
}
.cheatsheet-fade-enter-from, .cheatsheet-fade-leave-to { opacity: 0; }
</style>
