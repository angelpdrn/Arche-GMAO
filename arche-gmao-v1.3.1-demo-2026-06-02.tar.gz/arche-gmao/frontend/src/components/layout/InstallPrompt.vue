<template>
  <Teleport to="body">
    <Transition name="install-slide">
      <div v-if="visible" class="install-overlay" @click.self="dismiss">
        <div class="install-sheet">
          <div class="install-handle"></div>

          <!-- Android / Desktop Chrome — direct button -->
          <template v-if="platform === 'android' || platform === 'desktop'">
            <div class="install-header">
              <div class="install-icon-wrap">
                <svg width="28" height="28" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M 256 100 L 372 400 L 334 400 L 303 282 L 209 282 L 178 400 L 140 400 Z M 256 190 L 224 258 L 288 258 Z" fill="#FFFFFF" fill-rule="evenodd"/></svg>
              </div>
              <div>
                <h3 class="install-title">Instalar Arche GMAO</h3>
                <p class="install-sub">Acceso directo desde tu {{ platform === 'android' ? 'pantalla de inicio' : 'escritorio' }}</p>
              </div>
            </div>
            <ul class="install-benefits">
              <li>&#x25B8; Abre al instante sin navegador</li>
              <li>&#x25B8; Notificaciones push de OTs</li>
              <li>&#x25B8; Funciona sin conexión (datos en cache)</li>
            </ul>
            <div class="install-actions">
              <button class="install-btn-primary" @click="doInstall">Instalar aplicacion</button>
              <button class="install-btn-secondary" @click="dismiss">Ahora no</button>
            </div>
          </template>

          <!-- iOS Safari — step by step instructions -->
          <template v-else-if="platform === 'ios'">
            <div class="install-header">
              <div class="install-icon-wrap">
                <svg width="28" height="28" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M 256 100 L 372 400 L 334 400 L 303 282 L 209 282 L 178 400 L 140 400 Z M 256 190 L 224 258 L 288 258 Z" fill="#FFFFFF" fill-rule="evenodd"/></svg>
              </div>
              <div>
                <h3 class="install-title">Instalar Arche GMAO</h3>
                <p class="install-sub">Sigue estos pasos para instalar la app</p>
              </div>
            </div>
            <ol class="install-steps">
              <li>
                <span class="step-num">1</span>
                <span class="step-text">Pulsa el boton <strong>Compartir</strong> <span class="ios-share-icon">&#x2B06;</span> en la barra inferior de Safari</span>
              </li>
              <li>
                <span class="step-num">2</span>
                <span class="step-text">Desplaza hacia abajo y selecciona <strong>"Anadir a pantalla de inicio"</strong></span>
              </li>
              <li>
                <span class="step-num">3</span>
                <span class="step-text">Pulsa <strong>"Anadir"</strong> en la esquina superior derecha</span>
              </li>
            </ol>
            <div class="install-note">
              La app se instalara con acceso directo desde tu pantalla de inicio, con experiencia completa sin barras del navegador.
            </div>
            <div class="install-actions">
              <button class="install-btn-secondary" @click="dismiss">Entendido</button>
            </div>
          </template>

          <!-- Chrome/Edge desktop without beforeinstallprompt (HTTP or already dismissed) -->
          <template v-else-if="platform === 'desktop-manual'">
            <div class="install-header">
              <div class="install-icon-wrap">
                <svg width="28" height="28" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M 256 100 L 372 400 L 334 400 L 303 282 L 209 282 L 178 400 L 140 400 Z M 256 190 L 224 258 L 288 258 Z" fill="#FFFFFF" fill-rule="evenodd"/></svg>
              </div>
              <div>
                <h3 class="install-title">Instalar Arche GMAO</h3>
                <p class="install-sub">Instala la app desde el menu del navegador</p>
              </div>
            </div>
            <ol class="install-steps">
              <li>
                <span class="step-num">1</span>
                <span class="step-text">Haz click en el menu <strong>&#8942;</strong> (tres puntos) en la esquina superior derecha de Chrome</span>
              </li>
              <li>
                <span class="step-num">2</span>
                <span class="step-text">Busca <strong>"Instalar Arche GMAO"</strong> o <strong>"Guardar y compartir > Instalar..."</strong></span>
              </li>
              <li>
                <span class="step-num">3</span>
                <span class="step-text">Pulsa <strong>"Instalar"</strong> en el dialogo que aparece</span>
              </li>
            </ol>
            <div class="install-note">
              La app se abrira como ventana independiente con acceso directo en tu escritorio.
            </div>
            <div class="install-actions">
              <button class="install-btn-secondary" @click="dismiss">Entendido</button>
            </div>
          </template>

          <!-- Another browser — generic message -->
          <template v-else>
            <div class="install-header">
              <div class="install-icon-wrap">
                <svg width="28" height="28" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M 256 100 L 372 400 L 334 400 L 303 282 L 209 282 L 178 400 L 140 400 Z M 256 190 L 224 258 L 288 258 Z" fill="#FFFFFF" fill-rule="evenodd"/></svg>
              </div>
              <div>
                <h3 class="install-title">Instalar Arche GMAO</h3>
                <p class="install-sub">Usa Chrome o Safari para instalar la app</p>
              </div>
            </div>
            <p class="install-generic">
              Para instalar Arche GMAO como aplicacion, abre esta pagina en <strong>Google Chrome</strong> (Android/PC) o <strong>Safari</strong> (iPhone/iPad).
            </p>
            <div class="install-actions">
              <button class="install-btn-secondary" @click="dismiss">Cerrar</button>
            </div>
          </template>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted } from 'vue'

const visible = ref(false)
const platform = ref<'android' | 'ios' | 'desktop' | 'desktop-manual' | 'other'>('other')
let deferredPrompt: any = null

function detectPlatform() {
  const ua = navigator.userAgent.toLowerCase()
  const isIOS = /iphone|ipad|ipod/.test(ua) && !(window as any).MSStream
  const isAndroid = /android/.test(ua)
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches
    || (navigator as any).standalone === true

  // Do not show it when it is already installed as a PWA
  if (isStandalone) return 'installed'

  if (isIOS) return 'ios'
  if (isAndroid) return 'android'

  // Desktop Chrome/Edge
  if (/chrome|edg/.test(ua) && !/mobile/.test(ua)) return 'desktop'

  return 'other'
}

function shouldShow(): boolean {
  const dismissed = localStorage.getItem('install-prompt-dismissed')
  if (dismissed) {
    const age = Date.now() - parseInt(dismissed)
    // Do not show it again for 14 days
    if (age < 14 * 24 * 3600 * 1000) return false
  }
  return true
}

function handleBeforeInstall(e: Event) {
  e.preventDefault()
  deferredPrompt = e

  if (!shouldShow()) return
  platform.value = 'android'
  // Detect whether this is desktop
  const ua = navigator.userAgent.toLowerCase()
  if (/chrome|edg/.test(ua) && !/mobile|android/.test(ua)) {
    platform.value = 'desktop'
  }
  visible.value = true
}

function doInstall() {
  if (deferredPrompt) {
    deferredPrompt.prompt()
    deferredPrompt.userChoice.then(() => {
      deferredPrompt = null
      visible.value = false
      localStorage.setItem('install-prompt-dismissed', Date.now().toString())
    })
  }
}

function dismiss() {
  visible.value = false
  localStorage.setItem('install-prompt-dismissed', Date.now().toString())
}

function showForIOS() {
  if (!shouldShow()) return
  const p = detectPlatform()
  if (p === 'installed') return
  if (p === 'ios') {
    platform.value = 'ios'
    visible.value = true
  }
}

onMounted(() => {
  window.addEventListener('beforeinstallprompt', handleBeforeInstall)

  // iOS has no beforeinstallprompt — show it after 3 seconds
  const p = detectPlatform()
  if (p === 'ios') {
    setTimeout(showForIOS, 3000)
  }
})

onUnmounted(() => {
  window.removeEventListener('beforeinstallprompt', handleBeforeInstall)
})

defineExpose({
  show: () => {
    let p = detectPlatform()
    // On desktop with no native prompt, show the manual instructions
    if (p === 'desktop' && !deferredPrompt) p = 'desktop-manual'
    platform.value = p as any
    visible.value = true
  }
})
</script>

<style scoped>
.install-overlay {
  position: fixed; inset: 0; z-index: 3000;
  background: rgba(0,0,0,0.5);
  display: flex; align-items: flex-end; justify-content: center;
}

.install-sheet {
  width: 100%; max-width: 480px;
  background: var(--color-surface, #fff);
  border-radius: 20px 20px 0 0;
  padding: var(--space-4, 16px) var(--space-5, 20px) var(--space-6, 24px);
  display: flex; flex-direction: column; gap: var(--space-4, 16px);
  animation: slideUp 0.3s ease;
}
@keyframes slideUp {
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
}

.install-handle {
  width: 40px; height: 4px;
  background: var(--color-border, #ddd);
  border-radius: 2px; margin: 0 auto;
}

.install-header {
  display: flex; align-items: center; gap: var(--space-4, 16px);
}
.install-icon-wrap {
  width: 52px; height: 52px; border-radius: 14px;
  background: #1A1A2E;
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0;
}
.install-icon-text {
  font-family: -apple-system, BlinkMacSystemFont, 'Inter', sans-serif;
  font-size: 18px; font-weight: 800; color: #fff; letter-spacing: 1px;
}
.install-title {
  font-size: 1.05rem; font-weight: 700;
  color: var(--color-primary, #1A1A2E);
}
.install-sub {
  font-size: 0.78rem; color: var(--color-text-muted, #888);
}

.install-benefits {
  list-style: none; padding: 0; margin: 0;
  display: flex; flex-direction: column; gap: var(--space-2, 8px);
  font-size: 0.85rem; color: var(--color-text, #333);
}

.install-steps {
  list-style: none; padding: 0; margin: 0;
  display: flex; flex-direction: column; gap: var(--space-3, 12px);
}
.install-steps li {
  display: flex; align-items: flex-start; gap: var(--space-3, 12px);
}
.step-num {
  width: 28px; height: 28px; flex-shrink: 0;
  background: #1A1A2E; color: #fff;
  border-radius: 50%; font-size: 0.78rem; font-weight: 700;
  display: flex; align-items: center; justify-content: center;
}
.step-text {
  font-size: 0.85rem; color: var(--color-text, #333); line-height: 1.5;
  padding-top: 3px;
}
.ios-share-icon {
  display: inline-block; font-size: 1rem;
  color: #007AFF; font-weight: 700;
}

.install-note {
  font-size: 0.75rem; color: var(--color-text-muted, #888);
  line-height: 1.5; padding: var(--space-3, 12px);
  background: var(--color-surface-2, #f5f5f5);
  border-radius: var(--radius, 6px);
}

.install-generic {
  font-size: 0.85rem; color: var(--color-text, #333); line-height: 1.6;
}

.install-actions {
  display: flex; flex-direction: column; gap: var(--space-2, 8px);
  padding-bottom: max(0px, env(safe-area-inset-bottom));
}
.install-btn-primary {
  width: 100%; height: 50px;
  background: #1A1A2E; color: #fff;
  border: none; border-radius: var(--radius-md, 10px);
  font-size: 0.95rem; font-weight: 600; cursor: pointer;
}
.install-btn-primary:active { opacity: 0.9; }
.install-btn-secondary {
  width: 100%; height: 44px;
  background: none; color: var(--color-text-muted, #888);
  border: 1px solid var(--color-border, #ddd);
  border-radius: var(--radius-md, 10px);
  font-size: 0.85rem; cursor: pointer;
}

.install-slide-enter-active { transition: opacity 0.3s ease; }
.install-slide-enter-active .install-sheet { animation: slideUp 0.3s ease; }
.install-slide-leave-active { transition: opacity 0.25s ease; }
.install-slide-enter-from, .install-slide-leave-to { opacity: 0; }

@media (min-width: 768px) {
  .install-overlay { align-items: center; }
  .install-sheet { border-radius: 20px; max-height: 90vh; }
}
</style>
