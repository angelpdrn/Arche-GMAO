<template>
  <Transition name="offline-slide">
    <div v-if="!offlineStore.isOnline" class="offline-banner">
      <span class="offline-icon">◎</span>
      <div class="offline-info">
        <span class="offline-title">Sin conexión — trabajando offline</span>
        <span class="offline-sub">
          <template v-if="offlineStore.pendingCount > 0">{{ offlineStore.pendingCount }} cambio{{ offlineStore.pendingCount > 1 ? 's' : '' }} pendiente{{ offlineStore.pendingCount > 1 ? 's' : '' }}</template>
          <template v-else>Datos disponibles en caché</template>
          <template v-if="offlineStore.cacheAge"> · {{ offlineStore.cacheAge }}</template>
        </span>
      </div>
    </div>
  </Transition>
  <Transition name="offline-slide">
    <div v-if="offlineStore.isOnline && offlineStore.syncing" class="syncing-banner">
      <span>&#x21BB; Sincronizando cambios offline...</span>
    </div>
  </Transition>
  <Transition name="offline-slide">
    <div v-if="offlineStore.isOnline && showSynced && !offlineStore.syncing" class="online-banner">
      <span>&#x2713; Conexión restaurada — datos sincronizados</span>
    </div>
  </Transition>
  <Transition name="offline-slide">
    <div v-if="offlineStore.storageWarning" class="storage-banner">
      <span>&#x26A0; Almacenamiento local casi lleno — sincronice cuando tenga conexión</span>
    </div>
  </Transition>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import { useOfflineStore } from '@/stores/offline'

const offlineStore = useOfflineStore()
const showSynced = ref(false)

watch(() => offlineStore.isOnline, (online) => {
  if (online) {
    showSynced.value = true
    setTimeout(() => showSynced.value = false, 3000)
  }
})
</script>

<style scoped>
.offline-banner {
  position: fixed; top: var(--header-height); left: 0; right: 0;
  background: #E67E22; color: #fff;
  padding: 8px 20px; display: flex; align-items: center; gap: 12px;
  z-index: 150; font-size: 0.82rem;
}
.offline-icon { font-size: 1rem; }
.offline-title { display: block; font-weight: 600; }
.offline-sub { display: block; font-size: 0.72rem; opacity: 0.85; }

.syncing-banner {
  position: fixed; top: var(--header-height); left: 0; right: 0;
  background: #3B82F6; color: #fff;
  padding: 8px 20px; text-align: center;
  z-index: 150; font-size: 0.82rem; font-weight: 500;
}

.online-banner {
  position: fixed; top: var(--header-height); left: 0; right: 0;
  background: #27AE60; color: #fff;
  padding: 8px 20px; text-align: center;
  z-index: 150; font-size: 0.82rem; font-weight: 500;
}

.storage-banner {
  position: fixed; top: var(--header-height); left: 0; right: 0;
  background: #E94560; color: #fff;
  padding: 8px 20px; text-align: center;
  z-index: 150; font-size: 0.82rem; font-weight: 500;
}

.offline-slide-enter-active, .offline-slide-leave-active { transition: transform 0.3s ease, opacity 0.3s; }
.offline-slide-enter-from, .offline-slide-leave-to { transform: translateY(-100%); opacity: 0; }
</style>
