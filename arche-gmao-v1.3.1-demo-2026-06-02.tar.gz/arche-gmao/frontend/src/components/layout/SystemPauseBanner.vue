<template>
  <div class="pause-banner">
    <span class="pause-icon">◼</span>
    <div class="pause-text">
      <strong>Sistema en modo pausa</strong> — Solo lectura activa.
      <span v-if="contact" class="pause-contact">Contacto: {{ contact }}</span>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { systemApi } from '@/api/system'

const contact = ref('')

onMounted(async () => {
  try {
    const status = await systemApi.getStatus()
    contact.value = status.paused_contact ?? ''
  } catch {
    // When the contact cannot be loaded, the banner shows without it
  }
})
</script>

<style scoped>
.pause-banner {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  padding: var(--space-3) var(--space-5);
  background: var(--color-alert);
  color: #fff;
  font-size: 0.82rem;
  font-weight: 500;
  position: sticky;
  top: var(--header-height);
  z-index: 49;
  user-select: none;
}

.pause-icon {
  font-size: 0.9rem;
  flex-shrink: 0;
}

.pause-text {
  flex: 1;
}

.pause-contact {
  margin-left: var(--space-2);
  opacity: 0.9;
}
</style>
