<template>
  <div class="empty-state" :class="`empty-state--${size}`">
    <div v-if="icon" class="empty-icon">{{ icon }}</div>
    <p class="empty-title">{{ title }}</p>
    <p v-if="hint" class="empty-hint">{{ hint }}</p>
    <button
      v-if="action"
      type="button"
      class="empty-cta"
      @click="emit('action')">{{ action }}</button>
  </div>
</template>

<script setup lang="ts">
defineProps<{
  /** Optional Unicode symbol. E.g. ◇ ✓ ⚠ ◷ */
  icon?: string
  /** Main message */
  title: string
  /** Subtitle or explanation */
  hint?: string
  /** CTA text. When present, it emits "action" on click */
  action?: string
  /** "sm" (in-card) | "md" (default, in-section) | "lg" (full page) */
  size?: 'sm' | 'md' | 'lg'
}>()

const emit = defineEmits<{
  (e: 'action'): void
}>()
</script>

<style scoped>
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  color: var(--color-text-muted, #888);
  padding: var(--space-8, 32px) var(--space-4, 16px);
  gap: var(--space-2, 8px);
  background: var(--color-surface, #1a1a26);
  border: 1px solid var(--color-border-light, #2a2a3a);
  border-radius: var(--radius-md, 8px);
}

.empty-state--sm {
  padding: var(--space-5, 20px) var(--space-3, 12px);
  font-size: 0.85rem;
}
.empty-state--lg {
  padding: var(--space-12, 64px) var(--space-6, 24px);
}

.empty-icon {
  font-size: 2rem;
  line-height: 1;
  color: var(--color-border-light, #3a3a4a);
  margin-bottom: var(--space-1, 4px);
}
.empty-state--sm .empty-icon { font-size: 1.4rem; }
.empty-state--lg .empty-icon { font-size: 2.6rem; }

.empty-title {
  font-size: 0.95rem;
  font-weight: 500;
  color: var(--color-text, #d5d5d8);
  margin: 0;
}
.empty-state--sm .empty-title { font-size: 0.85rem; }

.empty-hint {
  font-size: 0.82rem;
  color: var(--color-text-muted, #888);
  margin: 0;
  max-width: 360px;
  line-height: 1.4;
}
.empty-state--sm .empty-hint { font-size: 0.78rem; }

.empty-cta {
  margin-top: var(--space-3, 12px);
  height: 32px;
  padding: 0 var(--space-4, 16px);
  background: var(--color-primary, #0f3460);
  color: #fff;
  border: none;
  border-radius: var(--radius, 4px);
  font-size: 0.82rem;
  font-weight: 500;
  cursor: pointer;
  transition: background 120ms ease;
}
.empty-cta:hover { background: var(--color-accent, #1a4d80); }
</style>
