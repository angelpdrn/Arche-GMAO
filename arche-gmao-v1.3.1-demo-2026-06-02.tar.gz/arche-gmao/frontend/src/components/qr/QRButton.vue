<template>
  <div class="qr-wrap" ref="wrapRef">
    <button class="qr-btn" @click.stop="toggleMenu" :title="'QR — ' + nodeName">
      <span>⬛</span>
    </button>

    <div v-if="open" class="qr-menu">
      <div class="qr-menu-header">
        <span class="qr-menu-name">{{ nodeName }}</span>
        <span class="qr-menu-code mono">{{ nodeCode }}</span>
      </div>

      <!-- QR preview -->
      <div class="qr-preview">
        <img v-if="qrSrc" :src="qrSrc" :alt="'QR ' + nodeCode" class="qr-image" />
        <div v-else class="qr-loading">Generando...</div>
      </div>

      <div class="qr-actions">
        <button class="qr-action-btn" @click="downloadQR">
          ↓ Descargar PNG
        </button>
        <button class="qr-action-btn" @click="openScanPage">
          ↗ Ver página
        </button>
        <button v-if="!compositionId" class="qr-action-btn" @click="openPrintSheet">
          ▤ Hoja impresión
        </button>
        <button v-if="!compositionId" class="qr-action-btn" @click="downloadQRExcel">
          ▦ Excel con QRs
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useToast } from '@/composables/useToast'
const toast = useToast()
import { ref, onMounted, onUnmounted } from 'vue'
import client, { downloadBlob } from '@/api/client'

const props = defineProps<{
  nodeId: number
  nodeCode: string
  nodeName: string
  parentId?: number | null
  compositionId?: number | null
}>()

const open = ref(false)
const qrSrc = ref('')
const wrapRef = ref<HTMLElement | null>(null)

function toggleMenu() {
  open.value = !open.value
  if (open.value && !qrSrc.value) loadQR()
}

function qrEndpointPath(size: number) {
  if (props.compositionId) return `/compositions/${props.compositionId}/qr?size=${size}`
  return `/factory/nodes/${props.nodeId}/qr?size=${size}`
}

async function loadQR() {
  try {
    const resp = await client.get<Blob>(qrEndpointPath(200), { responseType: 'blob' })
    qrSrc.value = URL.createObjectURL(resp.data)
  } catch (e) {
    console.error('[QR] no se pudo cargar el preview:', e)
  }
}

async function downloadQR() {
  const filename = props.compositionId ? `qr-comp-${props.compositionId}.png` : `qr-${props.nodeCode}.png`
  try {
    await downloadBlob(qrEndpointPath(512), filename)
  } catch (e) {
    toast.error('No se pudo descargar el QR. Recarga la página e inténtalo de nuevo.')
    console.error(e)
  }
  open.value = false
}

function openScanPage() {
  const code = props.compositionId ? `comp-${props.compositionId}` : props.nodeCode
  window.open(`/scan/${code}`, '_blank')
  open.value = false
}

async function openPrintSheet() {
  const params = props.parentId ? `?parent_id=${props.parentId}` : ''
  try {
    const resp = await client.get<string>(`/factory/nodes/qr-sheet${params}`, { responseType: 'text' as const })
    const blob = new Blob([resp.data], { type: 'text/html' })
    const url = URL.createObjectURL(blob)
    const win = window.open(url, '_blank')
    if (win) setTimeout(() => URL.revokeObjectURL(url), 10000)
  } catch (e) {
    toast.error('No se pudo abrir la hoja de impresión.')
    console.error(e)
  }
  open.value = false
}

async function downloadQRExcel() {
  const params = props.parentId ? `?parent_id=${props.parentId}` : ''
  try {
    await downloadBlob(`/factory/nodes/qr-excel${params}`, 'qr-equipos.xlsx')
  } catch (e) {
    toast.error('No se pudo descargar el Excel.')
    console.error(e)
  }
  open.value = false
}

function handleOutside(e: MouseEvent) {
  if (wrapRef.value && !wrapRef.value.contains(e.target as Node)) {
    open.value = false
  }
}

onMounted(() => document.addEventListener('click', handleOutside))
onUnmounted(() => {
  document.removeEventListener('click', handleOutside)
  if (qrSrc.value) URL.revokeObjectURL(qrSrc.value)
})
</script>

<style scoped>
.qr-wrap { position: relative; display: inline-block; }

.qr-btn { width: 30px; height: 30px; background: rgba(15,52,96,0.06); border: 1px solid rgba(15,52,96,0.2); border-radius: var(--radius-sm); cursor: pointer; font-size: 0.85rem; color: var(--color-accent); display: flex; align-items: center; justify-content: center; transition: all var(--transition); }
.qr-btn:hover { background: rgba(15,52,96,0.12); }

.qr-menu { position: absolute; top: calc(100% + 6px); right: 0; width: 240px; background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); box-shadow: var(--shadow-lg); z-index: 500; overflow: hidden; }

.qr-menu-header { padding: var(--space-3) var(--space-4); border-bottom: 1px solid var(--color-border-light); background: var(--color-surface-2); }
.qr-menu-name { display: block; font-size: 0.82rem; font-weight: 600; color: var(--color-text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.qr-menu-code { display: block; font-size: 0.72rem; color: var(--color-text-muted); }

.qr-preview { padding: var(--space-4); display: flex; align-items: center; justify-content: center; background: #fff; }
.qr-image { width: 160px; height: 160px; }
.qr-loading { font-size: 0.8rem; color: var(--color-text-muted); padding: var(--space-6); }

.qr-actions { display: flex; flex-direction: column; border-top: 1px solid var(--color-border-light); }
.qr-action-btn { padding: var(--space-3) var(--space-4); background: none; border: none; border-bottom: 1px solid var(--color-border-light); font-size: 0.82rem; color: var(--color-text-muted); cursor: pointer; text-align: left; transition: background var(--transition); }
.qr-action-btn:last-child { border-bottom: none; }
.qr-action-btn:hover { background: var(--color-surface-2); color: var(--color-text); }

.mono { font-family: var(--font-mono); }
</style>
