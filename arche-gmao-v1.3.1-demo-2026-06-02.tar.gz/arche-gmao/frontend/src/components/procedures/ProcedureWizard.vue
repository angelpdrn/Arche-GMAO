<template>
  <div v-if="execution" class="sop-wizard">
    <div class="sop-header">
      <div class="sop-header-info">
        <span class="sop-title">{{ execution.title ?? 'Procedimiento' }}</span>
        <span class="sop-progress">Paso {{ currentStepIndex + 1 }} de {{ steps.length }}</span>
      </div>
      <div class="sop-progress-bar">
        <div class="sop-progress-fill" :style="{ width: progressPercent + '%' }"></div>
      </div>
    </div>

    <div v-if="currentStep && execution.status !== 'completed'" class="sop-step">
      <div class="sop-step-header">
        <span class="sop-step-number">{{ currentStep.step_number }}</span>
        <div>
          <span class="sop-step-title">{{ currentStep.title }}</span>
          <span v-if="currentStep.is_required" class="sop-required">Obligatorio</span>
        </div>
      </div>
      <p v-if="currentStep.description" class="sop-step-desc">{{ currentStep.description }}</p>

      <!-- Checkbox -->
      <div v-if="currentStep.step_type === 'checkbox'" class="sop-input">
        <label class="sop-checkbox">
          <input type="checkbox" v-model="stepValue.value_bool" />
          <span>Completado</span>
        </label>
      </div>

      <!-- Pass/Fail -->
      <div v-if="currentStep.step_type === 'passfail'" class="sop-input sop-passfail">
        <button :class="['sop-pf-btn', stepValue.is_pass === true && 'sop-pf-pass']" @click="stepValue.is_pass = true">Pasa</button>
        <button :class="['sop-pf-btn', stepValue.is_pass === false && 'sop-pf-fail']" @click="stepValue.is_pass = false">No pasa</button>
      </div>

      <!-- Numeric / Meter Reading -->
      <div v-if="currentStep.step_type === 'numeric' || currentStep.step_type === 'meter_reading'" class="sop-input">
        <div class="sop-numeric-wrap">
          <input type="number" v-model.number="stepValue.value_numeric" class="sop-numeric"
                 :placeholder="numericPlaceholder" :step="0.01" />
          <span v-if="currentStep.config?.unit" class="sop-unit">{{ currentStep.config.unit }}</span>
        </div>
        <div v-if="numericRange" class="sop-range">Rango aceptable: {{ numericRange }}</div>
        <div v-if="isOutOfRange" class="sop-oor-warn">Valor fuera de rango</div>
      </div>

      <!-- Text -->
      <div v-if="currentStep.step_type === 'text'" class="sop-input">
        <textarea v-model="stepValue.value_text" class="sop-textarea" rows="3"
                  :maxlength="currentStep.config?.max_length ?? 500"
                  placeholder="Escriba aqui..."></textarea>
      </div>

      <!-- Selection -->
      <div v-if="currentStep.step_type === 'selection'" class="sop-input">
        <div v-for="opt in (currentStep.config?.options ?? [])" :key="opt"
             :class="['sop-option', stepValue.value_selection === opt && 'sop-option--selected']"
             @click="stepValue.value_selection = opt">
          {{ opt }}
        </div>
      </div>

      <!-- Photo -->
      <div v-if="currentStep.step_type === 'photo'" class="sop-input">
        <p class="sop-photo-hint">Foto requerida para este paso (se adjuntara a la OT)</p>
        <label class="sop-checkbox">
          <input type="checkbox" v-model="stepValue.value_bool" />
          <span>Foto tomada y adjunta</span>
        </label>
      </div>

      <!-- Signature -->
      <div v-if="currentStep.step_type === 'signature'" class="sop-input">
        <label class="sop-checkbox">
          <input type="checkbox" v-model="stepValue.value_bool" />
          <span>Firmo este paso</span>
        </label>
      </div>

      <!-- Notes -->
      <div class="sop-notes">
        <details>
          <summary>Agregar nota al paso</summary>
          <textarea v-model="stepValue.notes" class="sop-textarea sop-textarea--sm" rows="2" placeholder="Nota opcional..."></textarea>
        </details>
      </div>

      <!-- Navigation -->
      <div class="sop-nav">
        <button v-if="currentStepIndex > 0" class="sop-btn sop-btn--secondary" @click="prevStep">Anterior</button>
        <button v-if="!currentStep.is_required" class="sop-btn sop-btn--skip" @click="skipStep" :disabled="submitting">Saltar</button>
        <button class="sop-btn sop-btn--primary" @click="submitAndNext" :disabled="!canSubmit || submitting">
          {{ isLastStep ? 'Finalizar' : 'Siguiente' }}
        </button>
      </div>

      <div v-if="stepError" class="sop-error">{{ stepError }}</div>
    </div>

    <!-- Summary when complete -->
    <div v-if="execution.status === 'completed'" class="sop-complete">
      <span class="sop-complete-icon">&#x2713;</span>
      <span>Procedimiento completado</span>
      <span class="sop-complete-sub">{{ execution.completed_steps }} de {{ execution.total_steps }} pasos</span>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch } from 'vue'
import { apiErrorMsg } from '@/composables/useToast'
import { proceduresApi } from '@/api/phase2'
import type { ProcedureExecution, ProcedureStep } from '@/types/procedures'

const props = defineProps<{ executionId: number }>()
const emit = defineEmits<{ (e: 'completed'): void; (e: 'step-submitted', data: { step: number; out_of_range: boolean }): void }>()

const execution = ref<ProcedureExecution | null>(null)
const steps = ref<ProcedureStep[]>([])
const currentStepIndex = ref(0)
const submitting = ref(false)
const stepError = ref('')

const stepValue = ref<{
  value_text: string | null
  value_numeric: number | null
  value_bool: boolean | null
  value_selection: string | null
  is_pass: boolean | null
  notes: string | null
}>({ value_text: null, value_numeric: null, value_bool: null, value_selection: null, is_pass: null, notes: null })

const currentStep = computed(() => steps.value[currentStepIndex.value] ?? null)
const isLastStep = computed(() => currentStepIndex.value === steps.value.length - 1)
const progressPercent = computed(() => {
  if (!steps.value.length) return 0
  const completed = steps.value.filter(s => s.result).length
  return Math.round((completed / steps.value.length) * 100)
})

const numericPlaceholder = computed(() => {
  const c = currentStep.value?.config
  if (!c) return 'Valor'
  if (c.min !== undefined && c.max !== undefined) return `${c.min} - ${c.max}`
  return 'Valor'
})

const numericRange = computed(() => {
  const c = currentStep.value?.config
  if (!c) return ''
  const parts: string[] = []
  if (c.alert_min !== undefined) parts.push(`min ${c.alert_min}`)
  if (c.alert_max !== undefined) parts.push(`max ${c.alert_max}`)
  if (c.unit) return parts.join(', ') + ' ' + c.unit
  return parts.join(', ')
})

const isOutOfRange = computed(() => {
  const c = currentStep.value?.config
  const v = stepValue.value.value_numeric
  if (v === null || !c) return false
  if (c.alert_min !== undefined && v < c.alert_min) return true
  if (c.alert_max !== undefined && v > c.alert_max) return true
  return false
})

const canSubmit = computed(() => {
  const s = currentStep.value
  if (!s) return false
  const v = stepValue.value
  switch (s.step_type) {
    case 'checkbox': return v.value_bool === true
    case 'passfail': return v.is_pass !== null
    case 'numeric': case 'meter_reading': return v.value_numeric !== null
    case 'text': return !!v.value_text?.trim()
    case 'selection': return !!v.value_selection
    case 'photo': return v.value_bool === true
    case 'signature': return v.value_bool === true
    default: return true
  }
})

async function load() {
  try {
    const data = await proceduresApi.getExecution(props.executionId)
    execution.value = data
    steps.value = data.steps ?? []
    const firstIncomplete = steps.value.findIndex(s => !s.result)
    if (firstIncomplete >= 0) currentStepIndex.value = firstIncomplete
  } catch { stepError.value = 'Error cargando procedimiento' }
}

function resetStepValue() {
  stepValue.value = { value_text: null, value_numeric: null, value_bool: null, value_selection: null, is_pass: null, notes: null }
  stepError.value = ''
}

function prevStep() {
  if (currentStepIndex.value > 0) {
    currentStepIndex.value--
    loadStepResult()
  }
}

function loadStepResult() {
  const s = currentStep.value
  if (s?.result) {
    stepValue.value = {
      value_text: s.result.value_text,
      value_numeric: s.result.value_numeric,
      value_bool: s.result.value_bool,
      value_selection: s.result.value_selection,
      is_pass: s.result.is_pass,
      notes: s.result.notes,
    }
  } else {
    resetStepValue()
  }
}

async function submitAndNext() {
  const s = currentStep.value
  if (!s || !execution.value) return
  submitting.value = true
  stepError.value = ''
  try {
    const result = await proceduresApi.submitStep(execution.value.id, s.id, {
      ...stepValue.value,
      skipped: false,
    })
    emit('step-submitted', { step: s.step_number, out_of_range: result.out_of_range })

    if (isLastStep.value) {
      await proceduresApi.completeExecution(execution.value.id)
      execution.value = { ...execution.value, status: 'completed', completed_steps: result.completed_steps }
      emit('completed')
      return
    } else {
      s.result = { ...stepValue.value, out_of_range: result.out_of_range, completed_by: null, completed_by_name: null, completed_at: new Date().toISOString(), skipped: false, skip_reason: null }
      currentStepIndex.value++
      resetStepValue()
    }
  } catch (err: unknown) {
    stepError.value = apiErrorMsg(err, 'Error enviando resultado')
  } finally { submitting.value = false }
}

async function skipStep() {
  const s = currentStep.value
  if (!s || !execution.value || s.is_required) return
  submitting.value = true
  try {
    await proceduresApi.submitStep(execution.value.id, s.id, { skipped: true, skip_reason: 'Omitido por el técnico' })
    s.result = { value_text: null, value_numeric: null, value_bool: null, value_selection: null, is_pass: null, out_of_range: null, completed_by: null, completed_by_name: null, completed_at: null, skipped: true, skip_reason: 'Omitido', notes: null }
    if (isLastStep.value) {
      await proceduresApi.completeExecution(execution.value.id)
      execution.value = { ...execution.value, status: 'completed' }
      emit('completed')
      return
    } else {
      currentStepIndex.value++
      resetStepValue()
    }
  } catch { stepError.value = 'Error omitiendo paso' }
  finally { submitting.value = false }
}

// Conditional logic: work out whether steps should be skipped
function evaluateCondition(step: ProcedureStep): boolean {
  if (!step.condition) return true
  const cond = step.condition
  const sourceStep = steps.value.find(s => s.step_number === cond.if_step)
  if (!sourceStep?.result) return true

  const raw = sourceStep.result.value_numeric ?? sourceStep.result.value_text ?? sourceStep.result.value_selection ?? sourceStep.result.value_bool
  const target = cond.value

  switch (cond.operator) {
    case '>': return Number(raw) > Number(target)
    case '<': return Number(raw) < Number(target)
    case '>=': return Number(raw) >= Number(target)
    case '<=': return Number(raw) <= Number(target)
    case 'equals': return String(raw) === String(target)
    case 'not_equals': return String(raw) !== String(target)
    default: return true
  }
}

watch(currentStepIndex, () => {
  const s = currentStep.value
  if (s?.condition) {
    const shouldShow = evaluateCondition(s)
    if (!shouldShow && s.condition.action === 'goto' && s.condition.goto_step) {
      const gotoIdx = steps.value.findIndex(st => st.step_number === s.condition!.goto_step)
      if (gotoIdx >= 0) currentStepIndex.value = gotoIdx
    }
  }
  loadStepResult()
})

watch(() => props.executionId, load, { immediate: true })
</script>

<style scoped>
.sop-wizard { background: var(--color-surface, #f8f9fa); border-radius: 12px; overflow: hidden; }
.sop-header { padding: 12px 16px; background: var(--color-primary, #1A1A2E); color: #fff; }
.sop-header-info { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
.sop-title { font-weight: 600; font-size: 0.9rem; }
.sop-progress { font-size: 0.75rem; opacity: 0.7; }
.sop-progress-bar { height: 4px; background: rgba(255,255,255,0.2); border-radius: 2px; }
.sop-progress-fill { height: 100%; background: #27AE60; border-radius: 2px; transition: width 0.3s; }

.sop-step { padding: 16px; }
.sop-step-header { display: flex; align-items: flex-start; gap: 12px; margin-bottom: 8px; }
.sop-step-number { background: var(--color-accent, #0F3460); color: #fff; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.8rem; font-weight: 600; flex-shrink: 0; }
.sop-step-title { font-weight: 600; font-size: 0.9rem; display: block; }
.sop-required { font-size: 0.65rem; color: #E94560; font-weight: 500; }
.sop-step-desc { font-size: 0.8rem; color: #666; margin: 0 0 12px; }

.sop-input { margin-bottom: 12px; }
.sop-checkbox { display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 0.85rem; }
.sop-checkbox input { width: 18px; height: 18px; }

.sop-passfail { display: flex; gap: 8px; }
.sop-pf-btn { flex: 1; padding: 10px; border: 2px solid #ddd; border-radius: 8px; background: #fff; font-size: 0.85rem; font-weight: 600; cursor: pointer; transition: all 0.2s; }
.sop-pf-pass { border-color: #27AE60; background: #27AE60; color: #fff; }
.sop-pf-fail { border-color: #E94560; background: #E94560; color: #fff; }

.sop-numeric-wrap { display: flex; align-items: center; gap: 8px; }
.sop-numeric { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 8px; font-size: 1rem; font-family: 'JetBrains Mono', monospace; }
.sop-unit { font-size: 0.85rem; color: #666; white-space: nowrap; }
.sop-range { font-size: 0.72rem; color: #888; margin-top: 4px; }
.sop-oor-warn { font-size: 0.78rem; color: #E94560; font-weight: 600; margin-top: 4px; }

.sop-textarea { width: 100%; padding: 8px 10px; border: 1px solid #ddd; border-radius: 8px; font-size: 0.85rem; resize: vertical; font-family: inherit; }
.sop-textarea--sm { font-size: 0.78rem; }

.sop-option { padding: 10px 14px; border: 1px solid #ddd; border-radius: 8px; margin-bottom: 6px; cursor: pointer; font-size: 0.85rem; transition: all 0.15s; }
.sop-option--selected { border-color: var(--color-accent, #0F3460); background: var(--color-accent, #0F3460); color: #fff; }

.sop-photo-hint { font-size: 0.78rem; color: #888; margin-bottom: 8px; }

.sop-notes { margin-top: 12px; }
.sop-notes summary { font-size: 0.78rem; color: #888; cursor: pointer; }

.sop-nav { display: flex; gap: 8px; margin-top: 16px; }
.sop-btn { padding: 10px 16px; border: none; border-radius: 8px; font-size: 0.85rem; font-weight: 600; cursor: pointer; transition: opacity 0.2s; }
.sop-btn:disabled { opacity: 0.4; cursor: not-allowed; }
.sop-btn--primary { background: var(--color-accent, #0F3460); color: #fff; flex: 1; }
.sop-btn--secondary { background: #e8e8e8; color: #333; }
.sop-btn--skip { background: transparent; color: #888; border: 1px solid #ddd; }

.sop-error { color: #E94560; font-size: 0.78rem; margin-top: 8px; }

.sop-complete { padding: 24px; text-align: center; }
.sop-complete-icon { font-size: 2rem; color: #27AE60; display: block; margin-bottom: 8px; }
.sop-complete-sub { display: block; font-size: 0.78rem; color: #888; margin-top: 4px; }
</style>
