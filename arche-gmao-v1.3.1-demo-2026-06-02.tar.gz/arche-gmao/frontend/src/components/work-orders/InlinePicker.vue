<template>
  <span ref="rootRef" class="inline-picker" :class="{ 'inline-picker--open': open, 'inline-picker--readonly': readonly }">
    <button
      type="button"
      class="inline-picker-trigger"
      :title="readonly ? '' : 'Click para editar'"
      :disabled="readonly || saving"
      @click.stop="toggle"
      @keydown.enter.prevent="toggle"
      @keydown.escape="open = false">
      <slot name="display" :option="currentOption">
        <span :style="badgeStyle">{{ currentOption?.label ?? placeholder }}</span>
      </slot>
      <span v-if="!readonly" class="inline-picker-caret">▾</span>
    </button>

    <Teleport to="body">
      <div
        v-if="open"
        ref="popRef"
        class="inline-picker-pop"
        :style="popStyle"
        @click.stop>
        <button
          v-for="opt in options"
          :key="opt.value"
          type="button"
          class="inline-picker-item"
          :class="{ 'inline-picker-item--active': opt.value === modelValue }"
          @click="select(opt)">
          <slot name="option" :option="opt">
            <span class="inline-picker-item-label" :style="itemStyle(opt)">{{ opt.label }}</span>
          </slot>
        </button>
      </div>
    </Teleport>
  </span>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onBeforeUnmount, nextTick, watch } from 'vue'

interface Option {
  value: string | number | null
  label: string
  color?: string
}

const props = withDefaults(defineProps<{
  modelValue: string | number | null
  options: Option[]
  readonly?: boolean
  saving?: boolean
  placeholder?: string
}>(), {
  readonly: false,
  saving: false,
  placeholder: '—',
})

const emit = defineEmits<{
  (e: 'update:modelValue', v: string | number | null): void
  (e: 'change', v: string | number | null): void
}>()

const open = ref(false)
const rootRef = ref<HTMLElement | null>(null)
const popRef = ref<HTMLElement | null>(null)
const popStyle = ref<Record<string, string>>({})

const currentOption = computed(() => props.options.find(o => o.value === props.modelValue))

const badgeStyle = computed(() => {
  const c = currentOption.value?.color
  if (!c) return {}
  return { color: c, background: c + '15', padding: '2px 8px', borderRadius: '4px' }
})

function itemStyle(opt: Option): Record<string, string> {
  if (!opt.color) return {}
  return { color: opt.color }
}

async function toggle() {
  if (props.readonly || props.saving) return
  open.value = !open.value
  if (open.value) {
    await nextTick()
    positionPop()
  }
}

function positionPop() {
  if (!rootRef.value || !popRef.value) return
  const r = rootRef.value.getBoundingClientRect()
  const ph = popRef.value.offsetHeight
  // When it does not fit below, open it upwards
  const goUp = r.bottom + ph + 4 > window.innerHeight
  popStyle.value = goUp
    ? { left: r.left + 'px', top: (r.top - ph - 4) + 'px' }
    : { left: r.left + 'px', top: (r.bottom + 4) + 'px' }
}

function select(opt: Option) {
  open.value = false
  if (opt.value === props.modelValue) return
  emit('update:modelValue', opt.value)
  emit('change', opt.value)
}

function onClickOutside(e: MouseEvent) {
  if (!open.value) return
  if (rootRef.value?.contains(e.target as Node)) return
  if (popRef.value?.contains(e.target as Node)) return
  open.value = false
}

function onEsc(e: KeyboardEvent) {
  if (e.key === 'Escape') open.value = false
}

watch(() => props.saving, (v) => { if (v) open.value = false })

onMounted(() => {
  document.addEventListener('click', onClickOutside)
  document.addEventListener('keydown', onEsc)
  window.addEventListener('resize', positionPop)
  window.addEventListener('scroll', positionPop, true)
})
onBeforeUnmount(() => {
  document.removeEventListener('click', onClickOutside)
  document.removeEventListener('keydown', onEsc)
  window.removeEventListener('resize', positionPop)
  window.removeEventListener('scroll', positionPop, true)
})
</script>

<style scoped>
.inline-picker { position: relative; display: inline-flex; }

.inline-picker-trigger {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  background: transparent;
  border: 1px solid transparent;
  border-radius: var(--radius, 4px);
  padding: 2px 4px;
  font: inherit;
  color: inherit;
  cursor: pointer;
  transition: border-color 120ms ease, background 120ms ease;
}
.inline-picker-trigger:hover:not(:disabled) {
  border-color: var(--color-border, #2a2a3a);
  background: var(--color-surface-2, #20202c);
}
.inline-picker-trigger:disabled {
  cursor: default;
  opacity: 0.85;
}
.inline-picker--readonly .inline-picker-trigger { border-color: transparent !important; background: transparent !important; }
.inline-picker--open .inline-picker-trigger {
  border-color: var(--color-border-light, #3a3a4a);
  background: var(--color-surface-2, #20202c);
}

.inline-picker-caret {
  font-size: 0.65rem;
  color: var(--color-text-muted, #888);
  margin-left: 2px;
}
</style>

<style>
/* Global popup (not scoped) so it lives in <body> with its styles */
.inline-picker-pop {
  position: fixed;
  z-index: 9000;
  min-width: 180px;
  max-height: 280px;
  overflow-y: auto;
  background: var(--color-surface, #1a1a26);
  border: 1px solid var(--color-border-light, #3a3a4a);
  border-radius: var(--radius-md, 8px);
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.3);
  padding: 4px;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.inline-picker-item {
  text-align: left;
  background: transparent;
  border: none;
  border-radius: var(--radius, 4px);
  padding: 6px 10px;
  font-size: 0.82rem;
  color: var(--color-text, #d5d5d8);
  cursor: pointer;
}
.inline-picker-item:hover { background: var(--color-border-light, #3a3a4a); }
.inline-picker-item--active { background: var(--color-primary, #0f3460); color: #fff; }
.inline-picker-item-label { display: inline-block; }
</style>
