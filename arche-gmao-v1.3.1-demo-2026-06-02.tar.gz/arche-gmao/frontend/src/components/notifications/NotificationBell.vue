<template>
  <div class="notif-wrap" ref="wrapRef">
    <button class="notif-bell" @click="togglePanel" :class="{ 'notif-bell--active': unreadCount > 0 }">
      <span class="bell-icon">◈</span>
      <span v-if="unreadCount > 0" class="notif-badge">{{ unreadCount > 99 ? '99+' : unreadCount }}</span>
    </button>

    <Transition name="notif-slide">
      <div v-if="open" class="notif-panel">
        <div class="notif-header">
          <span class="notif-title">Notificaciones</span>
          <button v-if="unreadCount > 0" class="notif-read-all" @click="markAllRead">
            Marcar todas como leídas
          </button>
        </div>

        <div v-if="loading" class="notif-loading">Cargando...</div>
        <div v-else-if="!notifications.length" class="notif-empty">
          <span class="notif-empty-icon">◇</span>
          <p>Sin notificaciones</p>
        </div>
        <div v-else class="notif-list">
          <div v-for="n in notifications" :key="n.id"
            class="notif-item" :class="{ 'notif-item--unread': !n.is_read }"
            @click="handleClick(n)">
            <div class="notif-icon-wrap">
              <span class="notif-type-icon">{{ TYPE_ICONS[n.type] ?? '▤' }}</span>
            </div>
            <div class="notif-content">
              <p class="notif-item-title">{{ n.title }}</p>
              <p class="notif-item-body">{{ n.body }}</p>
              <span class="notif-time">{{ formatTime(n.created_at) }}</span>
            </div>
            <div v-if="!n.is_read" class="notif-unread-dot"></div>
          </div>
        </div>
      </div>
    </Transition>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import client from '@/api/client'

const router = useRouter()
const open = ref(false)
const loading = ref(false)
const notifications = ref<any[]>([])
const unreadCount = ref(0)
const wrapRef = ref<HTMLElement | null>(null)

const TYPE_ICONS: Record<string, string> = {
  wo_assigned:           '✦',
  wo_overdue:            '◷',
  stock_low:             '◫',
  plan_due:              '◉',
  verification_pending:  '◎',
  pattern_detected:      '△',
  wo_signed:             '◇',
  general:               '▤',
}

async function loadNotifications() {
  loading.value = true
  try {
    const { data } = await client.get('/notifications')
    notifications.value = data.notifications ?? []
    unreadCount.value = data.unread_count ?? 0
  } catch { /* silent */ }
  finally { loading.value = false }
}

async function loadUnreadCount() {
  try {
    const { data } = await client.get('/notifications?unread=true')
    unreadCount.value = data.unread_count ?? 0
  } catch { /* silent */ }
}

function togglePanel() {
  open.value = !open.value
  if (open.value) loadNotifications()
}

async function markAllRead() {
  try {
    await client.patch('/notifications/read-all')
    notifications.value.forEach(n => n.is_read = true)
    unreadCount.value = 0
  } catch { /* silent */ }
}

async function handleClick(n: any) {
  if (!n.is_read) {
    await client.patch(`/notifications/${n.id}/read`)
    n.is_read = true
    unreadCount.value = Math.max(0, unreadCount.value - 1)
  }
  if (n.link) {
    open.value = false
    router.push(n.link)
  }
}

function formatTime(iso: string) {
  try {
    const d = new Date(iso)
    const now = new Date()
    const diff = Math.floor((now.getTime() - d.getTime()) / 1000)
    if (diff < 60) return 'Ahora'
    if (diff < 3600) return `Hace ${Math.floor(diff/60)}m`
    if (diff < 86400) return `Hace ${Math.floor(diff/3600)}h`
    return d.toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit' })
  } catch { return '' }
}

function handleOutside(e: MouseEvent) {
  if (wrapRef.value && !wrapRef.value.contains(e.target as Node)) {
    open.value = false
  }
}

// Poll every 30 seconds
let interval: ReturnType<typeof setInterval>
onMounted(() => {
  loadUnreadCount()
  interval = setInterval(loadUnreadCount, 30000)
  document.addEventListener('click', handleOutside)
})
onUnmounted(() => {
  clearInterval(interval)
  document.removeEventListener('click', handleOutside)
})
</script>

<style scoped>
.notif-wrap { position: relative; }

.notif-bell { position: relative; width: 36px; height: 36px; background: var(--color-surface-2); border: 1px solid var(--color-border); border-radius: var(--radius); cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all var(--transition); }
.notif-bell:hover { background: var(--color-border-light); }
.notif-bell--active { border-color: rgba(233,69,96,0.4); background: rgba(233,69,96,0.06); }
.bell-icon { font-size: 1rem; }
.notif-badge { position: absolute; top: -4px; right: -4px; min-width: 16px; height: 16px; background: var(--color-alert); color: #fff; font-size: 0.6rem; font-weight: 700; border-radius: 8px; display: flex; align-items: center; justify-content: center; padding: 0 3px; }

.notif-panel { position: absolute; top: calc(100% + 8px); right: 0; width: 360px; background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-lg); box-shadow: var(--shadow-lg); z-index: 500; overflow: hidden; }
.notif-slide-enter-active, .notif-slide-leave-active { transition: all 0.2s ease; }
.notif-slide-enter-from, .notif-slide-leave-to { opacity: 0; transform: translateY(-8px); }

.notif-header { display: flex; align-items: center; justify-content: space-between; padding: var(--space-3) var(--space-4); border-bottom: 1px solid var(--color-border-light); }
.notif-title { font-size: 0.78rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--color-text-muted); }
.notif-read-all { font-size: 0.72rem; color: var(--color-accent); background: none; border: none; cursor: pointer; }
.notif-read-all:hover { text-decoration: underline; }

.notif-loading, .notif-empty { padding: var(--space-6); text-align: center; font-size: 0.82rem; color: var(--color-text-muted); }
.notif-empty-icon { font-size: 1.5rem; display: block; margin-bottom: var(--space-2); }

.notif-list { max-height: 400px; overflow-y: auto; }
.notif-item { display: flex; align-items: flex-start; gap: var(--space-3); padding: var(--space-3) var(--space-4); border-bottom: 1px solid var(--color-border-light); cursor: pointer; transition: background var(--transition); }
.notif-item:last-child { border-bottom: none; }
.notif-item:hover { background: var(--color-surface-2); }
.notif-item--unread { background: rgba(15,52,96,0.03); }
.notif-icon-wrap { width: 32px; height: 32px; background: var(--color-surface-2); border-radius: var(--radius-sm); display: flex; align-items: center; justify-content: center; flex-shrink: 0; font-size: 1rem; }
.notif-content { flex: 1; min-width: 0; }
.notif-item-title { font-size: 0.82rem; font-weight: 600; color: var(--color-text); margin-bottom: 2px; }
.notif-item-body { font-size: 0.75rem; color: var(--color-text-muted); line-height: 1.4; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.notif-time { font-size: 0.68rem; color: var(--color-text-light); margin-top: 3px; display: block; }
.notif-unread-dot { width: 8px; height: 8px; background: var(--color-accent); border-radius: 50%; flex-shrink: 0; margin-top: 4px; }
</style>
