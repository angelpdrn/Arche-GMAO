<template>
  <Teleport to="body">
    <!-- Floating button -->
    <div v-if="!aiStore.isOpen" class="ai-fab" @click="aiStore.openChat()" title="Arché IA">
      <span class="ai-fab-icon">◬</span>
      <span class="ai-fab-label">Arché IA</span>
      <span v-if="!status?.ollama_available" class="ai-fab-offline">●</span>
    </div>

    <!-- Chat window -->
    <Transition name="chat-slide">
      <div v-if="aiStore.isOpen" class="chat-window">
        <!-- Header -->
        <div class="chat-header">
          <div class="chat-header-left">
            <span class="chat-logo">◬</span>
            <div class="chat-header-info">
              <span class="chat-title">Arché IA</span>
              <span v-if="aiStore.activeNodeName" class="chat-node-context">{{ aiStore.activeNodeName }}</span>
              <span v-else class="chat-status-text">{{ status?.ollama_available ? 'En línea' : 'No disponible' }}</span>
            </div>
          </div>
          <div class="chat-header-actions">
            <button class="chat-action-btn" title="Nueva conversación" @click="startNew">✦</button>
            <button class="chat-action-btn" title="Historial" @click="showHistory = !showHistory">◷</button>
            <button class="chat-action-btn chat-action-btn--close" @click="aiStore.closeChat()">✕</button>
          </div>
        </div>

        <!-- History -->
        <Transition name="slide-down">
          <div v-if="showHistory" class="history-panel">
            <div class="history-title">Conversaciones recientes</div>
            <div v-if="!aiStore.conversations.length" class="history-empty">Sin conversaciones previas.</div>
            <div v-for="conv in aiStore.conversations" :key="conv.id"
              class="history-item"
              :class="{ 'history-item--active': aiStore.currentConvId === conv.id }"
              @click="loadConv(conv.id)">
              <div class="history-item-main">
                <span class="history-item-title">{{ conv.title ?? 'Sin título' }}</span>
                <span v-if="conv.node_name" class="history-item-node">{{ conv.node_name }}</span>
              </div>
              <div class="history-item-actions">
                <span class="history-item-date">{{ formatDate(conv.updated_at) }}</span>
                <button class="history-del-btn" @click.stop="aiStore.deleteConversation(conv.id)">✕</button>
              </div>
            </div>
          </div>
        </Transition>

        <!-- Messages -->
        <div ref="messagesEl" class="chat-messages">
          <!-- Empty state with suggestions -->
          <div v-if="!aiStore.messages.length" class="chat-empty">
            <div class="chat-empty-icon">◬</div>
            <p class="chat-empty-title">Arché IA</p>
            <p class="chat-empty-sub">
              <template v-if="aiStore.activeNodeName">
                Contexto: <strong>{{ aiStore.activeNodeName }}</strong>
              </template>
              <template v-else>Pregunta sobre equipos, averías o procedimientos.</template>
            </p>
            <div class="chat-suggestions">
              <button v-for="s in suggestions" :key="s" class="suggestion-btn" @click="sendSuggestion(s)">{{ s }}</button>
            </div>
          </div>

          <!-- Messages -->
          <template v-else>
            <div v-for="msg in aiStore.messages" :key="msg.id" class="chat-msg" :class="`chat-msg--${msg.role}`">
              <div v-if="msg.role === 'assistant'" class="msg-avatar">◬</div>
              <div class="msg-body">
                <div class="msg-content" v-html="renderMarkdown(msg.content)"></div>
                <!-- Typing indicator -->
                <div v-if="msg.role === 'assistant' && aiStore.isStreaming && msg === lastMsg" class="msg-typing">
                  <span></span><span></span><span></span>
                </div>
                <!-- Sources -->
                <div v-if="msg.sources?.length" class="msg-sources">
                  <span class="sources-label">Fuentes:</span>
                  <span v-for="(src, i) in msg.sources" :key="i" class="source-chip">
                    {{ sourceLabel(src) }} {{ src.similarity }}
                  </span>
                </div>
                <!-- Action: create WO detected -->
                <div v-if="msg.role === 'assistant' && pendingWOCreation && msg === lastMsg" class="action-card">
                  <p class="action-card-title">¿Crear esta OT?</p>
                  <div class="action-form">
                    <input v-model="woForm.title" class="action-input" placeholder="Título de la OT" />
                    <select v-model="woForm.wo_type" class="action-select">
                      <option value="corrective">Correctiva</option>
                      <option value="preventive">Preventiva</option>
                      <option value="inspection">Inspección</option>
                    </select>
                  </div>
                  <div class="action-buttons">
                    <button class="action-btn action-btn--cancel" @click="pendingWOCreation = false">Cancelar</button>
                    <button class="action-btn action-btn--confirm" :disabled="!woForm.title" @click="confirmCreateWO">Crear OT</button>
                  </div>
                </div>
              </div>
            </div>
          </template>
        </div>

        <!-- Offline bar -->
        <div v-if="status !== null && !status.ollama_available" class="chat-offline-bar">
          ⚠ Ollama no disponible. <code>sudo systemctl start ollama</code>
        </div>

        <!-- Input -->
        <div class="chat-input-area">
          <textarea
            ref="inputEl"
            v-model="inputText"
            class="chat-input"
            placeholder="Pregunta o di 'Crea una OT para...'"
            rows="1"
            :disabled="aiStore.isStreaming || !status?.ollama_available"
            @keydown.enter.exact.prevent="send"
            @keydown.enter.shift.exact="inputText += '\n'"
            @input="autoResize"
          />
          <button v-if="aiStore.isStreaming" class="chat-send-btn chat-send-btn--stop" @click="aiStore.cancelCurrentStream()">■</button>
          <button v-else class="chat-send-btn" :disabled="!inputText.trim() || !status?.ollama_available" @click="send">▶</button>
        </div>

        <!-- Footer -->
        <div class="chat-footer">
          <span class="footer-stat">{{ status?.indexed_chunks ?? 0 }} registros indexados</span>
          <span v-if="(status?.pending_queue ?? 0) > 0" class="footer-queue">{{ status?.pending_queue }} en cola</span>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup lang="ts">
import { useToast } from '@/composables/useToast'
const toast = useToast()
import { ref, computed, watch, nextTick, onMounted } from 'vue'
import DOMPurify from 'dompurify'
import { useAIStore } from '@/stores/ai'
import { aiApi } from '@/api/ai'
import client from '@/api/client'
import type { AISource } from '@/api/ai'

const aiStore = useAIStore()
const messagesEl = ref<HTMLElement | null>(null)
const inputEl = ref<HTMLTextAreaElement | null>(null)
const inputText = ref('')
const showHistory = ref(false)
const status = computed(() => aiStore.status)
const lastMsg = computed(() => aiStore.messages.length ? aiStore.messages[aiStore.messages.length - 1] : null)

// Create a WO from the chat
const pendingWOCreation = ref(false)
const woForm = ref({ title: '', wo_type: 'corrective' })

const suggestions = computed(() => {
  if (aiStore.activeNodeName) {
    return ['¿Qué averías ha tenido este equipo?', '¿Qué mantenimiento preventivo necesita?', '¿Qué repuestos tiene asociados?']
  }
  return ['¿Qué equipos críticos tengo en la planta?', '¿Hay repuestos con stock bajo?', '¿Qué OTs están pendientes?']
})

async function send() {
  if (!inputText.value.trim() || aiStore.isStreaming) return
  const text = inputText.value.trim()
  inputText.value = ''
  resetInputHeight()
  showHistory.value = false

  // Detect whether they want to create a WO
  const lowerText = text.toLowerCase()
  if ((lowerText.includes('crea') || lowerText.includes('crear') || lowerText.includes('genera')) &&
      (lowerText.includes('ot') || lowerText.includes('orden'))) {
    // Extract the title from the message
    const titleMatch = text.replace(/crea(r)?\s+(una\s+)?ot\s+(para\s+)?/i, '').trim()
    woForm.value.title = titleMatch || ''
    pendingWOCreation.value = true
  }

  await aiStore.sendMessage(text)
}

async function confirmCreateWO() {
  if (!woForm.value.title || !aiStore.activeNodeId) {
    toast.error('Necesito estar en el contexto de un equipo para crear la OT. Abre el chat desde la Fábrica Virtual.')
    return
  }
  try {
    const result = await client.post('/ai/create-wo', {
      node_id: aiStore.activeNodeId,
      title: woForm.value.title,
      wo_type: woForm.value.wo_type,
    }).then(r => r.data)

    pendingWOCreation.value = false
    // Add a confirmation to the chat
    aiStore.messages.push({
      id: Date.now(),
      role: 'assistant',
      content: `OT creada correctamente: **${result.wo_number}** — "${woForm.value.title}"\n\nPuedes verla en la sección de Órdenes de Trabajo.`,
      created_at: new Date().toISOString(),
    })
    scrollToBottom()
  } catch (err: unknown) {
    toast.fromError(err, 'Error creando la OT')
    pendingWOCreation.value = false
  }
}

function sendSuggestion(s: string) { inputText.value = s; send() }
function startNew() { aiStore.newConversation(aiStore.activeNodeId, aiStore.activeNodeName); showHistory.value = false }
async function loadConv(id: number) { await aiStore.loadConversation(id); showHistory.value = false; scrollToBottom() }

function autoResize() {
  if (!inputEl.value) return
  inputEl.value.style.height = 'auto'
  inputEl.value.style.height = Math.min(inputEl.value.scrollHeight, 120) + 'px'
}
function resetInputHeight() { if (inputEl.value) inputEl.value.style.height = 'auto' }
function scrollToBottom() { nextTick(() => { if (messagesEl.value) messagesEl.value.scrollTop = messagesEl.value.scrollHeight }) }

watch(() => aiStore.messages.map(m => m.content).join(''), scrollToBottom)
watch(() => aiStore.isOpen, (open) => {
  if (open) {
    aiStore.loadStatus()
    aiStore.loadConversations()
    nextTick(() => inputEl.value?.focus())
  }
})

function renderMarkdown(text: string): string {
  const html = text
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/`(.*?)`/g, '<code>$1</code>')
    .replace(/\n/g, '<br />')
  return DOMPurify.sanitize(html, { ALLOWED_TAGS: ['strong', 'code', 'br'] })
}

function sourceLabel(src: AISource): string {
  const labels: Record<string, string> = { work_order: 'Intervención', attachment: 'Doc', node_info: 'Equipo' }
  return labels[src.source_type] ?? src.source_type
}

function formatDate(iso: string) {
  try { return new Date(iso).toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit' }) }
  catch { return '' }
}

onMounted(() => aiStore.loadStatus())
</script>

<style scoped>
.ai-fab { position: fixed; bottom: var(--space-6); right: var(--space-6); height: 48px; padding: 0 var(--space-5); background: var(--color-primary); color: #fff; border-radius: 24px; display: flex; align-items: center; gap: var(--space-2); cursor: pointer; box-shadow: 0 4px 16px rgba(15,52,96,0.4); z-index: 1100; transition: transform var(--transition), box-shadow var(--transition); user-select: none; }
.ai-fab:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(15,52,96,0.5); }
.ai-fab-icon { font-size: 1.1rem; }
.ai-fab-label { font-size: 0.875rem; font-weight: 600; letter-spacing: 0.5px; }
.ai-fab-offline { color: #E94560; font-size: 0.6rem; }

.chat-window { position: fixed; bottom: var(--space-6); right: var(--space-6); width: 420px; height: 620px; background: var(--color-surface); border-radius: var(--radius-lg); box-shadow: 0 8px 40px rgba(0,0,0,0.25); display: flex; flex-direction: column; z-index: 1100; overflow: hidden; border: 1px solid var(--color-border-light); }
.chat-slide-enter-active, .chat-slide-leave-active { transition: all 0.25s ease; }
.chat-slide-enter-from, .chat-slide-leave-to { opacity: 0; transform: translateY(20px) scale(0.97); }

.chat-header { display: flex; align-items: center; justify-content: space-between; padding: var(--space-3) var(--space-4); background: var(--color-primary); color: #fff; flex-shrink: 0; }
.chat-header-left { display: flex; align-items: center; gap: var(--space-3); }
.chat-logo { font-size: 1.1rem; }
.chat-title { font-size: 0.875rem; font-weight: 700; display: block; }
.chat-node-context, .chat-status-text { font-size: 0.7rem; color: rgba(255,255,255,0.6); display: block; }
.chat-header-actions { display: flex; gap: var(--space-1); }
.chat-action-btn { width: 28px; height: 28px; background: rgba(255,255,255,0.1); border: none; color: rgba(255,255,255,0.7); border-radius: var(--radius-sm); cursor: pointer; font-size: 0.8rem; display: flex; align-items: center; justify-content: center; }
.chat-action-btn:hover { background: rgba(255,255,255,0.2); color: #fff; }
.chat-action-btn--close:hover { background: rgba(233,69,96,0.4); }

.history-panel { background: var(--color-surface-2); border-bottom: 1px solid var(--color-border-light); max-height: 200px; overflow-y: auto; flex-shrink: 0; }
.history-title { font-size: 0.68rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); padding: var(--space-2) var(--space-4); }
.history-empty { font-size: 0.8rem; color: var(--color-text-muted); padding: var(--space-3) var(--space-4); }
.history-item { display: flex; align-items: center; justify-content: space-between; padding: var(--space-2) var(--space-4); cursor: pointer; border-bottom: 1px solid var(--color-border-light); transition: background var(--transition); }
.history-item:hover { background: var(--color-surface); }
.history-item--active { background: rgba(15,52,96,0.06); }
.history-item-main { flex: 1; min-width: 0; }
.history-item-title { display: block; font-size: 0.8rem; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.history-item-node { display: block; font-size: 0.7rem; color: var(--color-text-muted); }
.history-item-actions { display: flex; align-items: center; gap: var(--space-2); flex-shrink: 0; margin-left: var(--space-2); }
.history-item-date { font-size: 0.68rem; color: var(--color-text-muted); }
.history-del-btn { background: none; border: none; color: var(--color-text-light); cursor: pointer; font-size: 0.7rem; }
.history-del-btn:hover { color: var(--color-alert); }
.slide-down-enter-active, .slide-down-leave-active { transition: all 0.2s ease; overflow: hidden; }
.slide-down-enter-from, .slide-down-leave-to { max-height: 0; opacity: 0; }

.chat-messages { flex: 1; overflow-y: auto; padding: var(--space-4); display: flex; flex-direction: column; gap: var(--space-4); scroll-behavior: smooth; }
.chat-empty { text-align: center; padding: var(--space-6) var(--space-4); }
.chat-empty-icon { font-size: 2.5rem; margin-bottom: var(--space-3); opacity: 0.4; }
.chat-empty-title { font-size: 1rem; font-weight: 700; color: var(--color-primary); margin-bottom: var(--space-2); }
.chat-empty-sub { font-size: 0.82rem; color: var(--color-text-muted); line-height: 1.6; margin-bottom: var(--space-4); }
.chat-suggestions { display: flex; flex-direction: column; gap: var(--space-2); }
.suggestion-btn { background: var(--color-surface-2); border: 1px solid var(--color-border-light); border-radius: var(--radius); padding: var(--space-2) var(--space-3); font-size: 0.8rem; color: var(--color-text-muted); cursor: pointer; text-align: left; transition: all var(--transition); }
.suggestion-btn:hover { border-color: var(--color-accent); color: var(--color-accent); }

.chat-msg { display: flex; gap: var(--space-3); align-items: flex-start; }
.chat-msg--user { flex-direction: row-reverse; }
.msg-avatar { width: 28px; height: 28px; background: var(--color-primary); color: #fff; font-size: 0.8rem; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.msg-body { max-width: 85%; display: flex; flex-direction: column; gap: var(--space-1); }
.chat-msg--user .msg-body { align-items: flex-end; }
.msg-content { padding: var(--space-3) var(--space-4); border-radius: var(--radius-md); font-size: 0.875rem; line-height: 1.7; word-break: break-word; }
.chat-msg--user .msg-content { background: var(--color-primary); color: #fff; border-bottom-right-radius: var(--radius-sm); }
.chat-msg--assistant .msg-content { background: var(--color-surface-2); color: var(--color-text); border-bottom-left-radius: var(--radius-sm); border: 1px solid var(--color-border-light); }
.msg-typing { display: flex; gap: 4px; padding: var(--space-1) 0; }
.msg-typing span { width: 6px; height: 6px; background: var(--color-text-muted); border-radius: 50%; animation: typing 1.2s infinite; }
.msg-typing span:nth-child(2) { animation-delay: 0.2s; }
.msg-typing span:nth-child(3) { animation-delay: 0.4s; }
@keyframes typing { 0%,60%,100% { opacity:.2; transform:translateY(0); } 30% { opacity:1; transform:translateY(-3px); } }
.msg-sources { display: flex; flex-wrap: wrap; gap: var(--space-1); margin-top: var(--space-1); }
.sources-label { font-size: 0.65rem; color: var(--color-text-light); }
.source-chip { font-size: 0.65rem; background: rgba(15,52,96,0.08); color: var(--color-accent); border: 1px solid rgba(15,52,96,0.2); padding: 1px 6px; border-radius: 10px; }

/* Action card for creating a WO */
.action-card { margin-top: var(--space-3); background: rgba(15,52,96,0.05); border: 1px solid rgba(15,52,96,0.2); border-radius: var(--radius-md); padding: var(--space-4); display: flex; flex-direction: column; gap: var(--space-3); }
.action-card-title { font-size: 0.82rem; font-weight: 600; color: var(--color-accent); }
.action-form { display: flex; flex-direction: column; gap: var(--space-2); }
.action-input, .action-select { height: 34px; padding: 0 var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius-sm); font-size: 0.82rem; background: var(--color-surface); outline: none; width: 100%; }
.action-input:focus, .action-select:focus { border-color: var(--color-accent); }
.action-buttons { display: flex; gap: var(--space-2); }
.action-btn { flex: 1; height: 32px; border-radius: var(--radius-sm); font-size: 0.8rem; font-weight: 500; cursor: pointer; border: none; }
.action-btn--confirm { background: var(--color-primary); color: #fff; }
.action-btn--confirm:hover:not(:disabled) { background: var(--color-accent); }
.action-btn--confirm:disabled { opacity: 0.5; cursor: not-allowed; }
.action-btn--cancel { background: var(--color-surface-2); color: var(--color-text-muted); border: 1px solid var(--color-border); }

.chat-offline-bar { background: rgba(243,156,18,0.1); border-top: 1px solid rgba(243,156,18,0.3); padding: var(--space-2) var(--space-4); font-size: 0.75rem; color: #D4AC0D; flex-shrink: 0; }
.chat-offline-bar code { background: rgba(243,156,18,0.15); padding: 1px 4px; border-radius: 3px; font-family: var(--font-mono); }

.chat-input-area { display: flex; gap: var(--space-2); padding: var(--space-3) var(--space-4); border-top: 1px solid var(--color-border-light); flex-shrink: 0; background: var(--color-surface); }
.chat-input { flex: 1; padding: var(--space-2) var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; font-family: var(--font-ui); resize: none; outline: none; line-height: 1.5; min-height: 38px; max-height: 120px; overflow-y: auto; }
.chat-input:focus { border-color: var(--color-accent); }
.chat-input:disabled { background: var(--color-surface-2); }
.chat-send-btn { width: 38px; height: 38px; background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); cursor: pointer; font-size: 0.875rem; display: flex; align-items: center; justify-content: center; flex-shrink: 0; transition: background var(--transition); }
.chat-send-btn:hover:not(:disabled) { background: var(--color-accent); }
.chat-send-btn:disabled { opacity: 0.4; cursor: not-allowed; }
.chat-send-btn--stop { background: var(--color-alert); }

.chat-footer { display: flex; justify-content: space-between; padding: var(--space-1) var(--space-4) var(--space-2); background: var(--color-surface-2); border-top: 1px solid var(--color-border-light); flex-shrink: 0; }
.footer-stat { font-size: 0.65rem; color: var(--color-text-light); }
.footer-queue { font-size: 0.65rem; color: var(--color-warning); }

@media (max-width: 768px) {
  .chat-window {
    bottom: 0; right: 0; left: 0;
    width: 100%; height: 100vh; height: 100dvh;
    border-radius: 0;
    border: none;
  }
  .ai-fab { bottom: 80px; right: var(--space-4); height: 44px; padding: 0 var(--space-4); }
  .ai-fab-label { display: none; }
  .chat-action-btn { width: 36px; height: 36px; font-size: 0.9rem; }
  .chat-input { font-size: 1rem; min-height: 42px; }
  .chat-send-btn { width: 42px; height: 42px; }
  .suggestion-btn { padding: var(--space-3); font-size: 0.82rem; }
  .action-input, .action-select { height: 40px; font-size: 0.875rem; }
  .action-btn { height: 40px; font-size: 0.82rem; }
}
</style>
