<template>
  <div v-if="patterns.length" class="patterns-widget">
    <div class="patterns-header">
      <span class="patterns-title">◬ Alertas predictivas</span>
      <div class="patterns-counts">
        <span v-if="counts.critical > 0" class="count-badge count-badge--critical">{{ counts.critical }} crítica{{ counts.critical > 1 ? 's' : '' }}</span>
        <span v-if="counts.high > 0" class="count-badge count-badge--high">{{ counts.high }} alta{{ counts.high > 1 ? 's' : '' }}</span>
        <span v-if="counts.medium > 0" class="count-badge count-badge--medium">{{ counts.medium }} media{{ counts.medium > 1 ? 's' : '' }}</span>
      </div>
    </div>

    <div class="patterns-list">
      <div v-for="p in patterns.slice(0, showAll ? patterns.length : 3)" :key="p.id"
        class="pattern-item" :class="`pattern-item--${p.severity}`">
        <div class="pattern-icon">{{ SEVERITY_ICONS[p.severity] }}</div>
        <div class="pattern-body">
          <div class="pattern-title-row">
            <span class="pattern-title">{{ p.title }}</span>
            <span class="pattern-type-badge">{{ PATTERN_TYPE_LABELS[p.pattern_type] ?? p.pattern_type }}</span>
            <span v-if="p.node_name" class="pattern-node">{{ p.node_name }}</span>
          </div>
          <p class="pattern-desc">{{ p.description }}</p>
          <p v-if="p.recommendation" class="pattern-rec">
            <strong>Recomendación:</strong> {{ p.recommendation }}
          </p>
        </div>
        <button class="pattern-ack" @click="acknowledge(p.id)" title="Marcar como visto">✓</button>
      </div>
    </div>

    <button v-if="patterns.length > 3" class="patterns-show-more" @click="showAll = !showAll">
      {{ showAll ? 'Ver menos' : `Ver ${patterns.length - 3} más` }}
    </button>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { patternsApi, PATTERN_TYPE_LABELS, type AIPattern } from '@/api/reports'

const props = defineProps<{ nodeId?: number | null }>()

const patterns = ref<AIPattern[]>([])
const showAll = ref(false)

const SEVERITY_ICONS: Record<string, string> = {
  critical: '●',
  high:     '●',
  medium:   '●',
  low:      '●',
}

const counts = computed(() => ({
  critical: patterns.value.filter(p => p.severity === 'critical').length,
  high:     patterns.value.filter(p => p.severity === 'high').length,
  medium:   patterns.value.filter(p => p.severity === 'medium').length,
}))

async function loadPatterns() {
  try {
    const data = props.nodeId
      ? await patternsApi.getNodePatterns(props.nodeId)
      : await patternsApi.list()
    patterns.value = data.patterns ?? []
  } catch { patterns.value = [] }
}

async function acknowledge(id: number) {
  try {
    await patternsApi.acknowledge(id)
    patterns.value = patterns.value.filter(p => p.id !== id)
  } catch { /* silent */ }
}

onMounted(loadPatterns)
</script>

<style scoped>
.patterns-widget {
  background: var(--color-surface);
  border: 1px solid var(--color-border-light);
  border-radius: var(--radius-md);
  overflow: hidden;
}

.patterns-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: var(--space-3) var(--space-4);
  background: var(--color-surface-2);
  border-bottom: 1px solid var(--color-border-light);
}

.patterns-title {
  font-size: 0.75rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: var(--color-text-muted);
}

.patterns-counts { display: flex; gap: var(--space-2); }
.count-badge { font-size: 0.68rem; font-weight: 700; padding: 2px 8px; border-radius: 20px; }
.count-badge--critical { background: rgba(233,69,96,0.12); color: var(--color-alert); }
.count-badge--high     { background: rgba(230,126,34,0.12); color: #E67E22; }
.count-badge--medium   { background: rgba(243,156,18,0.12); color: #F39C12; }

.patterns-list { display: flex; flex-direction: column; }

.pattern-item {
  display: flex;
  align-items: flex-start;
  gap: var(--space-3);
  padding: var(--space-3) var(--space-4);
  border-bottom: 1px solid var(--color-border-light);
  border-left: 3px solid transparent;
}
.pattern-item:last-child { border-bottom: none; }
.pattern-item--critical { border-left-color: var(--color-alert); background: rgba(233,69,96,0.02); }
.pattern-item--high     { border-left-color: #E67E22; background: rgba(230,126,34,0.02); }
.pattern-item--medium   { border-left-color: #F39C12; }

.pattern-icon { font-size: 1rem; flex-shrink: 0; margin-top: 2px; }
.pattern-item--critical .pattern-icon { color: var(--color-alert); }
.pattern-item--high .pattern-icon { color: #E67E22; }
.pattern-item--medium .pattern-icon { color: #F39C12; }
.pattern-item--low .pattern-icon { color: #27AE60; }
.pattern-body { flex: 1; display: flex; flex-direction: column; gap: 3px; }
.pattern-title-row { display: flex; align-items: center; gap: var(--space-2); flex-wrap: wrap; }
.pattern-title { font-size: 0.82rem; font-weight: 600; color: var(--color-text); }
.pattern-type-badge { font-size: 0.68rem; color: var(--color-text-light); background: var(--color-surface-2); padding: 1px 6px; border-radius: 10px; font-weight: 500; }
.pattern-node { font-size: 0.72rem; color: var(--color-text-muted); background: var(--color-surface-2); padding: 1px 6px; border-radius: 10px; }
.pattern-desc { font-size: 0.78rem; color: var(--color-text-muted); line-height: 1.5; }
.pattern-rec { font-size: 0.75rem; color: var(--color-text-muted); line-height: 1.5; }
.pattern-rec strong { color: var(--color-accent); }

.pattern-ack {
  width: 24px; height: 24px; flex-shrink: 0;
  background: var(--color-surface-2); border: 1px solid var(--color-border);
  border-radius: 50%; cursor: pointer; font-size: 0.75rem;
  color: var(--color-text-muted); display: flex; align-items: center; justify-content: center;
}
.pattern-ack:hover { background: rgba(39,174,96,0.1); color: var(--color-success); border-color: var(--color-success); }

.patterns-show-more {
  width: 100%; padding: var(--space-2); background: var(--color-surface-2);
  border: none; border-top: 1px solid var(--color-border-light);
  font-size: 0.75rem; color: var(--color-text-muted); cursor: pointer;
}
.patterns-show-more:hover { color: var(--color-accent); }
</style>
