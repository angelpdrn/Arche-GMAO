<template>
  <Teleport to="body">
    <div v-if="open" class="mobile-report-overlay">
      <div class="mobile-report-sheet">
        <div class="sheet-handle"></div>
        <div class="sheet-header">
          <h2 class="sheet-title">Reportar avería</h2>
          <button class="sheet-close" @click="close">✕</button>
        </div>

        <div class="sheet-body">
          <!-- Step 1: Equipment -->
          <div v-if="step === 1" class="step">
            <p class="step-label">¿En qué equipo?</p>
            <input
              v-model="search"
              class="mobile-input"
              placeholder="Buscar equipo..."
              @input="searchNodes"
              autofocus
            />
            <div class="node-results">
              <button
                v-for="n in filteredNodes"
                :key="n.id"
                class="node-result-btn"
                @click="selectNode(n)"
              >
                <span class="node-result-name">{{ n.name }}</span>
                <span class="node-result-code mono">{{ n.code }}</span>
                <span class="node-result-crit" :style="{ background: CRIT_COLORS[n.criticality] }">
                  {{ n.criticality }}
                </span>
              </button>
              <p v-if="search.length > 1 && !filteredNodes.length" class="no-results">
                Sin resultados
              </p>
            </div>
          </div>

          <!-- Step 2: Description -->
          <div v-if="step === 2" class="step">
            <button class="back-btn" @click="step = 1">← {{ selectedNode?.name }}</button>
            <p class="step-label">¿Qué está pasando?</p>
            <textarea
              v-model="description"
              class="mobile-textarea"
              placeholder="Describe el problema brevemente..."
              rows="4"
              autofocus
            />
            <div class="priority-selector">
              <p class="step-label-sm">Urgencia:</p>
              <div class="priority-btns">
                <button
                  v-for="p in PRIORITIES"
                  :key="p.value"
                  class="priority-btn"
                  :class="{ 'priority-btn--active': priority === p.value }"
                  :style="priority === p.value ? { background: p.color, borderColor: p.color } : { borderColor: p.color, color: p.color }"
                  @click="priority = p.value"
                >
                  {{ p.label }}
                </button>
              </div>
            </div>
          </div>

          <!-- Step 3: Confirmation -->
          <div v-if="step === 3" class="step step--confirm">
            <div class="confirm-icon">✓</div>
            <h3 class="confirm-title">{{ createdWONumber }}</h3>
            <p class="confirm-sub">OT creada correctamente</p>
            <div class="confirm-detail">
              <span class="confirm-row"><strong>Equipo:</strong> {{ selectedNode?.name }}</span>
              <span class="confirm-row"><strong>Descripción:</strong> {{ description }}</span>
              <span class="confirm-row"><strong>Prioridad:</strong> {{ priority }}</span>
            </div>
            <button class="mobile-btn-primary" @click="close">Cerrar</button>
          </div>
        </div>

        <!-- Footer with the action button -->
        <div v-if="step < 3" class="sheet-footer">
          <div v-if="error" class="mobile-error">{{ error }}</div>
          <button
            v-if="step === 1"
            class="mobile-btn-primary"
            :disabled="!selectedNode"
            @click="step = 2"
          >
            Continuar →
          </button>
          <button
            v-if="step === 2"
            class="mobile-btn-primary mobile-btn--alert"
            :disabled="!canWrite || !description.trim() || submitting"
            @click="submit"
          >
            {{ submitting ? 'Enviando...' : 'Reportar avería' }}
          </button>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { apiErrorMsg } from '@/composables/useToast'
import client from '@/api/client'
import { useSystemPause } from '@/composables/useSystemPause'

const { canWrite } = useSystemPause()
const props = defineProps<{ open: boolean }>()
const emit = defineEmits<{ (e: 'close'): void; (e: 'created', woNumber: string): void }>()

const step = ref(1)
const search = ref('')
const nodes = ref<any[]>([])
const selectedNode = ref<any>(null)
const description = ref('')
const priority = ref('high')
const submitting = ref(false)
const error = ref('')
const createdWONumber = ref('')

const CRIT_COLORS: Record<string, string> = {
  low: '#27AE60', medium: '#F39C12', high: '#E67E22', critical: '#E94560'
}
const PRIORITIES = [
  { value: 'medium',   label: 'Normal',   color: '#F39C12' },
  { value: 'high',     label: 'Urgente',  color: '#E67E22' },
  { value: 'critical', label: 'Crítico',  color: '#E94560' },
]

const filteredNodes = computed(() => {
  if (search.value.length < 2) return nodes.value.slice(0, 8)
  const q = search.value.toLowerCase()
  return nodes.value.filter(n =>
    n.name.toLowerCase().includes(q) || (n.code && n.code.toLowerCase().includes(q))
  ).slice(0, 10)
})

async function loadNodes() {
  try {
    const { data } = await client.get('/factory/tree')
    const flatten = (arr: any[]): any[] => {
      let result: any[] = []
      arr.forEach(n => {
        if (['equipment', 'component'].includes(n.node_type)) result.push(n)
        if (n.children?.length) result = result.concat(flatten(n.children))
      })
      return result
    }
    nodes.value = flatten(data.tree ?? data.nodes ?? [])
  } catch { nodes.value = [] }
}

function searchNodes() { /* the filteredNodes computed already does it */ }

function selectNode(n: any) {
  selectedNode.value = n
  step.value = 2
}

async function submit() {
  if (!selectedNode.value || !description.value.trim()) return
  submitting.value = true
  error.value = ''
  try {
    const { data } = await client.post('/work-orders', {
      node_id: selectedNode.value.id,
      title: description.value.trim().slice(0, 80),
      description: description.value.trim(),
      wo_type: 'corrective',
      priority: priority.value,
    })
    createdWONumber.value = data.wo_number
    step.value = 3
    emit('created', data.wo_number)
  } catch (err: unknown) {
    error.value = apiErrorMsg(err, 'Error enviando el reporte')
  } finally {
    submitting.value = false
  }
}

function close() {
  emit('close')
  setTimeout(() => {
    step.value = 1
    search.value = ''
    selectedNode.value = null
    description.value = ''
    priority.value = 'high'
    error.value = ''
    createdWONumber.value = ''
  }, 300)
}

onMounted(loadNodes)
</script>

<style scoped>
.mobile-report-overlay {
  position: fixed; inset: 0;
  background: rgba(0,0,0,0.5);
  z-index: 2000;
  display: flex; align-items: flex-end;
}

.mobile-report-sheet {
  width: 100%;
  background: var(--color-surface);
  border-radius: 20px 20px 0 0;
  max-height: 90vh;
  display: flex; flex-direction: column;
  animation: slideUp 0.3s ease;
}
@keyframes slideUp {
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
}

.sheet-handle {
  width: 40px; height: 4px;
  background: var(--color-border);
  border-radius: 2px;
  margin: 12px auto 0;
  flex-shrink: 0;
}

.sheet-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: var(--space-4) var(--space-5);
  border-bottom: 1px solid var(--color-border-light);
  flex-shrink: 0;
}
.sheet-title { font-size: 1.1rem; font-weight: 700; color: var(--color-primary); }
.sheet-close { background: none; border: none; font-size: 1.1rem; color: var(--color-text-muted); cursor: pointer; padding: var(--space-2); }

.sheet-body {
  flex: 1; overflow-y: auto;
  padding: var(--space-4) var(--space-5);
}

.step { display: flex; flex-direction: column; gap: var(--space-3); }
.step-label { font-size: 1rem; font-weight: 600; color: var(--color-text); }
.step-label-sm { font-size: 0.82rem; font-weight: 600; color: var(--color-text-muted); }

.mobile-input {
  width: 100%; height: 48px;
  padding: 0 var(--space-4);
  border: 1.5px solid var(--color-border);
  border-radius: var(--radius-md);
  font-size: 1rem;
  background: var(--color-surface);
  outline: none;
}
.mobile-input:focus { border-color: var(--color-accent); }

.mobile-textarea {
  width: 100%;
  padding: var(--space-3) var(--space-4);
  border: 1.5px solid var(--color-border);
  border-radius: var(--radius-md);
  font-size: 1rem;
  font-family: var(--font-ui);
  background: var(--color-surface);
  outline: none; resize: none;
  line-height: 1.5;
}
.mobile-textarea:focus { border-color: var(--color-accent); }

.node-results { display: flex; flex-direction: column; gap: var(--space-2); max-height: 40vh; overflow-y: auto; }
.node-result-btn {
  display: flex; align-items: center; gap: var(--space-3);
  padding: var(--space-3) var(--space-4);
  background: var(--color-surface-2);
  border: 1px solid var(--color-border-light);
  border-radius: var(--radius-md);
  cursor: pointer; text-align: left;
  transition: all var(--transition);
}
.node-result-btn:active { background: var(--color-border-light); }
.node-result-name { flex: 1; font-size: 0.9rem; font-weight: 500; }
.node-result-code { font-size: 0.72rem; color: var(--color-text-muted); }
.node-result-crit { font-size: 0.65rem; font-weight: 700; color: #fff; padding: 2px 8px; border-radius: 20px; }
.no-results { font-size: 0.85rem; color: var(--color-text-muted); text-align: center; padding: var(--space-4); }

.back-btn {
  background: none; border: none;
  font-size: 0.85rem; color: var(--color-accent);
  cursor: pointer; padding: 0; text-align: left;
}

.priority-selector { display: flex; flex-direction: column; gap: var(--space-2); }
.priority-btns { display: flex; gap: var(--space-2); }
.priority-btn {
  flex: 1; height: 44px;
  background: none;
  border: 2px solid;
  border-radius: var(--radius-md);
  font-size: 0.85rem; font-weight: 600;
  cursor: pointer; transition: all 0.15s;
}

.step--confirm { align-items: center; text-align: center; padding: var(--space-6) 0; gap: var(--space-4); }
.confirm-icon { width: 64px; height: 64px; background: rgba(39,174,96,0.1); color: #27AE60; font-size: 1.8rem; border-radius: 50%; display: flex; align-items: center; justify-content: center; }
.confirm-title { font-size: 1.4rem; font-weight: 700; font-family: var(--font-mono); color: var(--color-primary); }
.confirm-sub { font-size: 0.9rem; color: var(--color-text-muted); }
.confirm-detail { background: var(--color-surface-2); border-radius: var(--radius-md); padding: var(--space-4); width: 100%; display: flex; flex-direction: column; gap: var(--space-2); text-align: left; }
.confirm-row { font-size: 0.82rem; color: var(--color-text); }

.sheet-footer {
  padding: var(--space-4) var(--space-5);
  padding-bottom: max(var(--space-4), env(safe-area-inset-bottom));
  border-top: 1px solid var(--color-border-light);
  flex-shrink: 0;
}
.mobile-error { background: rgba(233,69,96,0.08); border: 1px solid rgba(233,69,96,0.3); border-radius: var(--radius); padding: var(--space-3); font-size: 0.82rem; color: var(--color-alert); margin-bottom: var(--space-3); }
.mobile-btn-primary {
  width: 100%; height: 52px;
  background: var(--color-primary); color: #fff;
  border: none; border-radius: var(--radius-md);
  font-size: 1rem; font-weight: 600; cursor: pointer;
  transition: background var(--transition);
}
.mobile-btn-primary:hover:not(:disabled) { background: var(--color-accent); }
.mobile-btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }
.mobile-btn--alert { background: var(--color-alert); }
.mobile-btn--alert:hover:not(:disabled) { background: #c0392b; }
.mono { font-family: var(--font-mono); }
</style>
