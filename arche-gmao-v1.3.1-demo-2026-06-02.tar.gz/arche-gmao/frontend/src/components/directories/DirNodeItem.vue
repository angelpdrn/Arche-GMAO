<template>
  <div class="dir-node">
    <div
      class="dir-item"
      :class="{
        'dir-item--active': selectedId === dir.id,
        'dir-item--public': dir.is_public && dir.is_owner,
        'dir-item--drag-over': dragOver,
      }"
      :style="{ paddingLeft: `${10 + depth * 12}px` }"
      @click="$emit('select', dir.id)"
      @dragover.prevent="onDragOver"
      @dragleave="onDragLeave"
      @drop.prevent="onDrop"
    >
      <!-- Toggle children -->
      <button v-if="dir.children?.length" class="dir-toggle" @click.stop="expanded = !expanded">
        {{ expanded ? '▾' : '▸' }}
      </button>
      <span v-else class="dir-toggle dir-toggle--leaf"></span>

      <!-- Folder icon with colour -->
      <span class="dir-folder-icon" :style="dir.color ? { color: dir.color } : {}">
        {{ dir.is_public ? '◇' : '◆' }}
      </span>

      <!-- Name -->
      <span class="dir-name">{{ dir.name }}</span>

      <!-- Badges -->
      <div class="dir-badges">
        <span v-if="dir.has_pin" class="dir-badge-pin" title="Protegida con PIN">◉</span>
        <span v-if="dir.is_public && !dir.is_owner" class="dir-badge-owner">{{ dir.owner_name?.[0] }}</span>
        <span class="dir-count">{{ dir.item_count }}</span>
      </div>

      <!-- Actions (owner only, on hover) -->
      <div v-if="dir.is_owner" class="dir-actions" @click.stop>
        <button class="dir-action-btn" title="Subcarpeta" @click="$emit('create-child', dir.id)">+</button>
        <button class="dir-action-btn" title="Editar" @click="$emit('edit', dir)">✎</button>
        <button class="dir-action-btn dir-action-btn--del" title="Eliminar" @click="$emit('delete', dir)">✕</button>
      </div>
    </div>

    <!-- Recursive children -->
    <div v-if="expanded && dir.children?.length">
      <DirNodeItem
        v-for="child in dir.children"
        :key="child.id"
        :dir="child"
        :depth="depth + 1"
        :selected-id="selectedId"
        @select="(id) => $emit('select', id)"
        @create-child="(id) => $emit('create-child', id)"
        @edit="(d) => $emit('edit', d)"
        @delete="(d) => $emit('delete', d)"
        @item-dropped="$emit('item-dropped')"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import type { Directory } from '@/api/directories'
import { directoriesApi } from '@/api/directories'
import DirNodeItem from './DirNodeItem.vue'

const props = defineProps<{
  dir: Directory
  depth: number
  selectedId: number | null
}>()

const emit = defineEmits<{
  select: [id: number]
  'create-child': [parentId: number]
  edit: [dir: Directory]
  delete: [dir: Directory]
  'item-dropped': []
}>()

const expanded = ref(true)
const dragOver = ref(false)
let dragLeaveTimer: ReturnType<typeof setTimeout> | null = null

function onDragOver(e: DragEvent) {
  if (!e.dataTransfer?.types.includes('application/x-dir-item')) return
  e.dataTransfer.dropEffect = 'copy'
  if (dragLeaveTimer) { clearTimeout(dragLeaveTimer); dragLeaveTimer = null }
  dragOver.value = true
}

function onDragLeave() {
  dragLeaveTimer = setTimeout(() => { dragOver.value = false }, 50)
}

async function onDrop(e: DragEvent) {
  dragOver.value = false
  const raw = e.dataTransfer?.getData('application/x-dir-item')
  if (!raw) return
  try {
    const { item_type, item_id } = JSON.parse(raw)
    await directoriesApi.addItem(props.dir.id, item_type, item_id)
    emit('item-dropped')
  } catch {
    // Already in the folder, or an error
  }
}
</script>

<style scoped>
.dir-node { user-select: none; }

.dir-item {
  display: flex;
  align-items: center;
  gap: 4px;
  height: 30px;
  cursor: pointer;
  border-radius: var(--radius-sm);
  padding-right: var(--space-2);
  margin: 1px var(--space-1);
  transition: background var(--transition);
  position: relative;
}

.dir-item:hover { background: var(--color-surface-2); }
.dir-item:hover .dir-actions { opacity: 1; }
.dir-item--drag-over { background: rgba(59,130,246,0.15); outline: 2px dashed var(--color-accent); outline-offset: -2px; }

.dir-item--active {
  background: rgba(15, 52, 96, 0.08);
}
.dir-item--active .dir-name {
  color: var(--color-accent);
  font-weight: 600;
}

/* Own public folder: subtle left border */
.dir-item--public {
  border-left: 2px solid var(--color-accent);
  padding-left: calc(inherit - 2px);
}

.dir-toggle {
  width: 14px;
  height: 14px;
  background: none;
  border: none;
  color: var(--color-text-muted);
  font-size: 0.6rem;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  padding: 0;
}
.dir-toggle--leaf { pointer-events: none; }

.dir-folder-icon {
  font-size: 0.85rem;
  flex-shrink: 0;
}

.dir-name {
  flex: 1;
  font-size: 0.78rem;
  color: var(--color-text);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
}

.dir-badges {
  display: flex;
  align-items: center;
  gap: 3px;
  flex-shrink: 0;
}

.dir-badge-pin {
  font-size: 0.65rem;
}

.dir-badge-owner {
  width: 16px;
  height: 16px;
  background: var(--color-accent);
  color: #fff;
  font-size: 0.6rem;
  font-weight: 700;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  text-transform: uppercase;
}

.dir-count {
  font-size: 0.62rem;
  color: var(--color-text-light);
  background: var(--color-surface-2);
  padding: 1px 4px;
  border-radius: 8px;
  min-width: 16px;
  text-align: center;
}

.dir-actions {
  display: flex;
  gap: 2px;
  opacity: 0;
  transition: opacity var(--transition);
  flex-shrink: 0;
  position: absolute;
  right: 4px;
  background: var(--color-surface);
  padding: 1px;
  border-radius: var(--radius-sm);
}

.dir-action-btn {
  width: 18px;
  height: 18px;
  background: none;
  border: none;
  cursor: pointer;
  font-size: 0.65rem;
  color: var(--color-text-muted);
  border-radius: 3px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.dir-action-btn:hover { background: var(--color-border-light); color: var(--color-text); }
.dir-action-btn--del:hover { color: var(--color-alert); }
</style>
