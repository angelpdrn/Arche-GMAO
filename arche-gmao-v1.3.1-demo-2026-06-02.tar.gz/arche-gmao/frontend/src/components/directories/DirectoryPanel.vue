<template>
  <div class="dir-panel">
    <!-- Header -->
    <div class="dir-header">
      <span class="dir-title">{{ SECTION_CONFIG[section]?.icon }} {{ SECTION_CONFIG[section]?.label ?? 'Carpetas' }}</span>
      <button class="dir-btn-new" @click="openCreate(null)" title="Nueva carpeta">+</button>
    </div>

    <!-- "All" option -->
    <div class="dir-item dir-item--all"
      :class="{ 'dir-item--active': selectedId === null }"
      @click="select(null)">
      <span class="dir-icon">≡</span>
      <span class="dir-name">Todos</span>
    </div>

    <div v-if="dirStore.isLoading(section)" class="dir-loading">Cargando...</div>

    <div v-else class="dir-scroll">
      <!-- My folders -->
      <div v-if="myDirs.length" class="dir-group">
        <span class="dir-group-label">Mis carpetas</span>
        <DirNodeItem
          v-for="dir in myDirs"
          :key="dir.id"
          :dir="dir"
          :depth="0"
          :selected-id="selectedId"
          @select="handleSelect"
          @create-child="openCreate"
          @edit="openEdit"
          @delete="confirmDelete"
          @item-dropped="onItemDropped"
        />
      </div>

      <!-- Other people's public folders -->
      <div v-if="publicDirs.length" class="dir-group">
        <span class="dir-group-label">Compartidas</span>
        <DirNodeItem
          v-for="dir in publicDirs"
          :key="dir.id"
          :dir="dir"
          :depth="0"
          :selected-id="selectedId"
          @select="handleSelect"
          @item-dropped="onItemDropped"
        />
      </div>

      <div v-if="!myDirs.length && !publicDirs.length" class="dir-empty">
        <p>Sin carpetas</p>
        <button class="btn-create-first" @click="openCreate(null)">Crear primera</button>
      </div>
    </div>
  </div>

  <!-- Create/edit folder modal -->
  <DirFormModal
    v-if="showForm"
    :section="section"
    :parent-id="formParentId"
    :edit-dir="formEditDir"
    @close="showForm = false"
    @saved="onSaved"
  />

  <!-- PIN modal -->
  <PinModal
    v-if="pinModal"
    :dir-id="pinModal.id"
    :dir-name="pinModal.name"
    :owner-name="pinModal.ownerName"
    @verified="onPinVerified"
    @cancel="pinModal = null"
  />
</template>

<script setup lang="ts">
import { computed, onMounted } from 'vue'
import { ref } from 'vue'
import { useDirectoriesStore } from '@/stores/directories'
import { SECTION_CONFIG } from '@/api/directories'
import type { Directory, DirectorySection } from '@/api/directories'
import DirNodeItem from './DirNodeItem.vue'
import DirFormModal from './DirFormModal.vue'
import PinModal from './PinModal.vue'

const props = defineProps<{
  section: DirectorySection
  selectedId: number | null
}>()

const emit = defineEmits<{
  select: [id: number | null]
  'item-dropped': []
}>()

const dirStore = useDirectoriesStore()

const myDirs = computed(() => dirStore.getMyDirs(props.section))
const publicDirs = computed(() => dirStore.getPublicDirs(props.section))

// ─── Form ───────────────────────────────────────────────────────────────
const showForm = ref(false)
const formParentId = ref<number | null>(null)
const formEditDir = ref<Directory | null>(null)

function openCreate(parentId: number | null) {
  formParentId.value = parentId
  formEditDir.value = null
  showForm.value = true
}

function openEdit(dir: Directory) {
  formEditDir.value = dir
  formParentId.value = dir.parent_id
  showForm.value = true
}

function onSaved(data: { id: number; name: string }) {
  // When the freshly created folder is the active one, do nothing special
}

// ─── Selection with a PIN ────────────────────────────────────────────────────────
const pinModal = ref<{ id: number; name: string; ownerName: string | null } | null>(null)
let pendingSelectId: number | null = null

function handleSelect(id: number) {
  const dir = dirStore.findDirInSection(props.section, id)
  if (!dir) return

  // When it has a PIN and is not unlocked → show the PIN modal
  if (dir.has_pin && !dirStore.isUnlocked(id)) {
    pendingSelectId = id
    pinModal.value = {
      id,
      name: dir.name,
      ownerName: dir.owner_name ?? null,
    }
    return
  }

  select(id)
}

function onPinVerified() {
  pinModal.value = null
  if (pendingSelectId !== null) {
    select(pendingSelectId)
    pendingSelectId = null
  }
}

function select(id: number | null) {
  emit('select', id)
}

// ─── Delete ─────────────────────────────────────────────────────────────────
async function confirmDelete(dir: Directory) {
  if (!confirm(`¿Eliminar la carpeta "${dir.name}"?\nLos elementos no se eliminarán.`)) return
  await dirStore.remove(dir.id, props.section)
  if (props.selectedId === dir.id) emit('select', null)
}

async function onItemDropped() {
  await dirStore.loadSection(props.section)
  emit('item-dropped')
}

onMounted(() => dirStore.loadSection(props.section))
</script>

<style scoped>
.dir-panel {
  width: 210px;
  flex-shrink: 0;
  border-right: 1px solid var(--color-border-light);
  background: var(--color-surface);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.dir-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: var(--space-3) var(--space-4);
  border-bottom: 1px solid var(--color-border-light);
}

.dir-title {
  font-size: 0.65rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  color: var(--color-text-muted);
}

.dir-btn-new {
  width: 22px;
  height: 22px;
  background: var(--color-surface-2);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  cursor: pointer;
  font-size: 1rem;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--color-text-muted);
  line-height: 1;
}
.dir-btn-new:hover { background: var(--color-primary); color: #fff; border-color: var(--color-primary); }

/* All */
.dir-item--all {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-2) var(--space-4);
  cursor: pointer;
  transition: background var(--transition);
  margin: var(--space-1) var(--space-1) 0;
  border-radius: var(--radius-sm);
}
.dir-item--all:hover { background: var(--color-surface-2); }
.dir-item--active { background: rgba(15,52,96,0.08) !important; }
.dir-item--active .dir-name { color: var(--color-accent); font-weight: 600; }
.dir-icon { font-size: 0.85rem; color: var(--color-text-muted); }
.dir-name { flex: 1; font-size: 0.8rem; color: var(--color-text); }

.dir-loading { padding: var(--space-5); text-align: center; font-size: 0.75rem; color: var(--color-text-muted); }

.dir-scroll { flex: 1; overflow-y: auto; padding: var(--space-2) 0; }

.dir-group { margin-bottom: var(--space-3); }
.dir-group-label {
  display: block;
  font-size: 0.6rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  color: var(--color-text-light);
  padding: var(--space-2) var(--space-4) var(--space-1);
}

.dir-empty {
  padding: var(--space-5) var(--space-4);
  text-align: center;
}
.dir-empty p { font-size: 0.8rem; color: var(--color-text-muted); margin-bottom: var(--space-3); }
.btn-create-first {
  background: var(--color-surface-2);
  border: 1px dashed var(--color-border);
  border-radius: var(--radius);
  padding: var(--space-2) var(--space-3);
  font-size: 0.75rem;
  color: var(--color-text-muted);
  cursor: pointer;
  width: 100%;
}
.btn-create-first:hover { border-color: var(--color-accent); color: var(--color-accent); }
</style>
