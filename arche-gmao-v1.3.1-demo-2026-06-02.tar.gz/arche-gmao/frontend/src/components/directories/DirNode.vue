<template>
  <div class="dir-node">
    <div
      class="dir-item"
      :class="{ 'dir-item--active': selectedId === dir.id }"
      :style="{ paddingLeft: `${8 + depth * 12}px` }"
      @click="$emit('select', dir.id)"
      @contextmenu.prevent="showMenu = !showMenu"
    >
      <!-- Toggle children -->
      <button v-if="dir.children?.length" class="dir-toggle"
        @click.stop="expanded = !expanded">
        {{ expanded ? '▾' : '▸' }}
      </button>
      <span v-else class="dir-toggle dir-toggle--leaf"></span>

      <span class="dir-icon">◆</span>
      <span class="dir-name">{{ dir.name }}</span>
      <span class="dir-count">{{ dir.item_count }}</span>

      <!-- Inline context menu -->
      <div class="dir-actions" @click.stop>
        <button class="dir-action-btn" title="Subcarpeta" @click="$emit('create-child', dir.id)">+</button>
        <button class="dir-action-btn" title="Renombrar" @click="$emit('rename', dir)">✎</button>
        <button class="dir-action-btn dir-action-btn--del" title="Eliminar" @click="$emit('delete', dir)">✕</button>
      </div>
    </div>

    <!-- Recursive children -->
    <div v-if="expanded && dir.children?.length" class="dir-children">
      <DirNode
        v-for="child in dir.children"
        :key="child.id"
        :dir="child"
        :depth="depth + 1"
        :selected-id="selectedId"
        :section="section"
        @select="(id) => $emit('select', id)"
        @create-child="(id) => $emit('create-child', id)"
        @rename="(d) => $emit('rename', d)"
        @delete="(d) => $emit('delete', d)"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import type { Directory, DirectorySection } from '@/api/directories'
import DirNode from './DirNode.vue'

defineProps<{
  dir: Directory
  depth: number
  selectedId: number | null
  section: DirectorySection
}>()

defineEmits<{
  select: [id: number]
  'create-child': [parentId: number]
  rename: [dir: Directory]
  delete: [dir: Directory]
}>()

const expanded = ref(true)
const showMenu = ref(false)
</script>

<style scoped>
.dir-node { user-select: none; }
.dir-item {
  display: flex; align-items: center; gap: 5px;
  height: 30px; cursor: pointer; border-radius: var(--radius-sm);
  padding-right: var(--space-2);
  transition: background var(--transition);
  position: relative;
}
.dir-item:hover { background: var(--color-surface-2); }
.dir-item:hover .dir-actions { opacity: 1; }
.dir-item--active { background: rgba(15,52,96,0.08); }
.dir-item--active .dir-name { color: var(--color-accent); font-weight: 600; }

.dir-toggle { width: 14px; height: 14px; background: none; border: none; color: var(--color-text-muted); font-size: 0.65rem; cursor: pointer; display: flex; align-items: center; justify-content: center; flex-shrink: 0; padding: 0; }
.dir-toggle--leaf { pointer-events: none; }
.dir-icon { font-size: 0.8rem; flex-shrink: 0; }
.dir-name { flex: 1; font-size: 0.78rem; color: var(--color-text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.dir-count { font-size: 0.62rem; color: var(--color-text-light); background: var(--color-surface-2); padding: 1px 4px; border-radius: 8px; min-width: 16px; text-align: center; flex-shrink: 0; }

.dir-actions { display: flex; gap: 2px; opacity: 0; transition: opacity var(--transition); flex-shrink: 0; }
.dir-action-btn { width: 18px; height: 18px; background: none; border: none; cursor: pointer; font-size: 0.65rem; color: var(--color-text-muted); border-radius: 3px; display: flex; align-items: center; justify-content: center; }
.dir-action-btn:hover { background: var(--color-border-light); color: var(--color-text); }
.dir-action-btn--del:hover { color: var(--color-alert); }
</style>
