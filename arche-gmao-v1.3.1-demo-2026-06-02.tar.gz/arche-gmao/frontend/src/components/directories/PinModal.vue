<template>
  <Teleport to="body">
    <div class="pin-overlay">
      <div class="pin-modal">
        <!-- Padlock icon -->
        <div class="pin-lock-icon">
          <div class="lock-body">
            <div class="lock-shackle"></div>
            <div class="lock-face">
              <div class="lock-keyhole"></div>
            </div>
          </div>
        </div>

        <h3 class="pin-title">Carpeta protegida</h3>
        <p class="pin-desc">
          La carpeta <strong>"{{ dirName }}"</strong>
          {{ ownerName ? `de ${ownerName}` : '' }}
          requiere verificación para acceder.
        </p>

        <!-- PIN input with individual digits, PIN pad style -->
        <div class="pin-input-wrap">
          <input
            ref="pinRef"
            v-model="pin"
            type="password"
            class="pin-input"
            :class="{ 'pin-input--error': error }"
            placeholder="Introduce el PIN"
            maxlength="20"
            @keydown.enter="submit"
            autofocus
          />
        </div>

        <div v-if="error" class="pin-error">{{ error }}</div>
        <div v-if="attempts > 0 && attempts < 3" class="pin-attempts">
          Intento {{ attempts }} de 3
        </div>

        <div class="pin-actions">
          <button class="pin-cancel" @click="$emit('cancel')">Cancelar</button>
          <button class="pin-submit" :disabled="!pin || loading" @click="submit">
            <span v-if="loading">Verificando...</span>
            <span v-else>Acceder</span>
          </button>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useDirectoriesStore } from '@/stores/directories'

const props = defineProps<{
  dirId: number
  dirName: string
  ownerName?: string | null
}>()

const emit = defineEmits<{
  verified: []
  cancel: []
}>()

const dirStore = useDirectoriesStore()
const pin = ref('')
const error = ref('')
const loading = ref(false)
const attempts = ref(0)
const pinRef = ref<HTMLInputElement | null>(null)

onMounted(() => {
  setTimeout(() => pinRef.value?.focus(), 100)
})

async function submit() {
  if (!pin.value || loading.value) return

  loading.value = true
  error.value = ''

  const ok = await dirStore.verifyPin(props.dirId, pin.value)

  loading.value = false

  if (ok) {
    emit('verified')
  } else {
    attempts.value++
    pin.value = ''
    if (attempts.value >= 3) {
      error.value = 'Demasiados intentos fallidos. Contacta con el propietario de la carpeta.'
    } else {
      error.value = 'PIN incorrecto. Inténtalo de nuevo.'
    }
  }
}
</script>

<style scoped>
.pin-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.7);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
  backdrop-filter: blur(4px);
}

.pin-modal {
  background: var(--color-surface);
  border-radius: var(--radius-lg);
  width: 360px;
  padding: var(--space-8) var(--space-8);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--space-5);
  box-shadow: var(--shadow-lg);
}

/* Padlock icon, pure CSS SVG */
.pin-lock-icon {
  width: 56px;
  height: 56px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.lock-body {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 3px;
}

.lock-shackle {
  width: 24px;
  height: 14px;
  border: 3px solid var(--color-primary);
  border-bottom: none;
  border-radius: 12px 12px 0 0;
}

.lock-face {
  width: 36px;
  height: 28px;
  background: var(--color-primary);
  border-radius: var(--radius-sm);
  display: flex;
  align-items: center;
  justify-content: center;
}

.lock-keyhole {
  width: 8px;
  height: 12px;
  background: var(--color-surface);
  border-radius: 4px 4px 0 0;
  position: relative;
}

.lock-keyhole::after {
  content: '';
  position: absolute;
  bottom: -4px;
  left: 50%;
  transform: translateX(-50%);
  width: 10px;
  height: 6px;
  background: var(--color-surface);
  border-radius: 0 0 5px 5px;
}

.pin-title {
  font-size: 1.1rem;
  font-weight: 700;
  color: var(--color-primary);
  text-align: center;
  margin: 0;
}

.pin-desc {
  font-size: 0.85rem;
  color: var(--color-text-muted);
  text-align: center;
  line-height: 1.6;
  margin: 0;
}

.pin-desc strong {
  color: var(--color-text);
}

.pin-input-wrap {
  width: 100%;
}

.pin-input {
  width: 100%;
  height: 48px;
  text-align: center;
  font-size: 1.25rem;
  font-family: var(--font-mono);
  letter-spacing: 0.5em;
  border: 2px solid var(--color-border);
  border-radius: var(--radius-md);
  outline: none;
  background: var(--color-surface);
  color: var(--color-text);
  transition: border-color var(--transition);
}

.pin-input:focus {
  border-color: var(--color-accent);
}

.pin-input--error {
  border-color: var(--color-alert);
  animation: shake 0.3s ease;
}

@keyframes shake {
  0%, 100% { transform: translateX(0); }
  25% { transform: translateX(-8px); }
  75% { transform: translateX(8px); }
}

.pin-error {
  font-size: 0.8rem;
  color: var(--color-alert);
  text-align: center;
  background: rgba(233, 69, 96, 0.08);
  border: 1px solid rgba(233, 69, 96, 0.2);
  border-radius: var(--radius);
  padding: var(--space-2) var(--space-4);
  width: 100%;
}

.pin-attempts {
  font-size: 0.75rem;
  color: var(--color-warning);
  text-align: center;
}

.pin-actions {
  display: flex;
  gap: var(--space-3);
  width: 100%;
}

.pin-cancel {
  flex: 1;
  height: 42px;
  background: var(--color-surface-2);
  border: 1px solid var(--color-border);
  border-radius: var(--radius);
  font-size: 0.875rem;
  cursor: pointer;
  color: var(--color-text-muted);
}

.pin-cancel:hover {
  background: var(--color-border-light);
}

.pin-submit {
  flex: 1;
  height: 42px;
  background: var(--color-primary);
  border: none;
  border-radius: var(--radius);
  font-size: 0.875rem;
  font-weight: 600;
  color: #fff;
  cursor: pointer;
  transition: background var(--transition);
}

.pin-submit:hover:not(:disabled) {
  background: var(--color-accent);
}

.pin-submit:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
</style>
