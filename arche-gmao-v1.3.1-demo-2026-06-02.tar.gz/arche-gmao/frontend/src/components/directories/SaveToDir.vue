<template>
  <div class="save-wrap" ref="wrapRef">
    <button class="save-btn" @click.stop="toggleDropdown" :title="`Guardar en carpeta`">
      <span>◆</span>
    </button>

    <div v-if="open" class="save-dropdown">
      <div class="save-header">Guardar en carpeta</div>
      <div v-if="loading" class="save-loading">Cargando...</div>
      <div v-else-if="!allDirs.length" class="save-empty">
        Sin carpetas.
        <button class="link-btn" @click="quickCreate">Crear</button>
      </div>
      <template v-else>
        <div class="save-group-label">Mis carpetas</div>
        <DirSaveOption
          v-for="dir in myDirs"
          :key="dir.id"
          :dir="dir"
          :depth="0"
          @save="saveToDir"
        />
        <template v-if="publicDirs.length">
          <div class="save-group-label">Compartidas</div>
          <DirSaveOption
            v-for="dir in publicDirs"
            :key="dir.id"
            :dir="dir"
            :depth="0"
            @save="saveToDir"
          />
        </template>
      </template>
      <div class="save-footer">
        <button class="save-new-btn" @click="quickCreate">+ Nueva carpeta</button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useToast } from '@/composables/useToast'
const toast = useToast()
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { directoriesApi } from '@/api/directories'
import { useDirectoriesStore } from '@/stores/directories'
import type { DirectorySection } from '@/api/directories'
import DirSaveOption from './DirSaveOption.vue'

const props = defineProps<{
  section: DirectorySection
  itemType: string
  itemId: number
}>()

const emit = defineEmits<{ saved: [dirId: number] }>()

const open = ref(false)
const loading = ref(false)
const wrapRef = ref<HTMLElement | null>(null)
const dirStore = useDirectoriesStore()

const myDirs = computed(() => dirStore.getMyDirs(props.section))
const publicDirs = computed(() => dirStore.getPublicDirs(props.section))
const allDirs = computed(() => [...myDirs.value, ...publicDirs.value])

async function toggleDropdown() {
  open.value = !open.value
  if (open.value) {
    loading.value = true
    await dirStore.loadSection(props.section)
    loading.value = false
  }
}

async function saveToDir(dirId: number) {
  try {
    await directoriesApi.addItem(dirId, props.itemType, props.itemId)
    open.value = false
    emit('saved', dirId)
  } catch {
    toast.error('Ya está en esa carpeta o error al guardar.')
  }
}

async function quickCreate() {
  const name = prompt('Nombre de la nueva carpeta:')
  if (!name?.trim()) return
  await directoriesApi.create({ name: name.trim(), section: props.section })
  await dirStore.loadSection(props.section)
}

function handleOutside(e: MouseEvent) {
  if (wrapRef.value && !wrapRef.value.contains(e.target as Node)) {
    open.value = false
  }
}

onMounted(() => document.addEventListener('click', handleOutside))
onUnmounted(() => document.removeEventListener('click', handleOutside))
</script>

<style scoped>
.save-wrap { position: relative; display: inline-block; }
.save-btn { width: 28px; height: 28px; background: var(--color-surface-2); border: 1px solid var(--color-border); border-radius: var(--radius-sm); cursor: pointer; font-size: 0.85rem; display: flex; align-items: center; justify-content: center; }
.save-btn:hover { background: var(--color-border-light); }
.save-dropdown { position: absolute; top: calc(100% + 4px); right: 0; width: 230px; background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius-md); box-shadow: var(--shadow-md); z-index: 500; max-height: 320px; overflow-y: auto; display: flex; flex-direction: column; }
.save-header { padding: var(--space-2) var(--space-3); font-size: 0.68rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); border-bottom: 1px solid var(--color-border-light); }
.save-group-label { padding: var(--space-1) var(--space-3); font-size: 0.6rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-light); letter-spacing: 1px; }
.save-loading, .save-empty { padding: var(--space-4) var(--space-3); font-size: 0.78rem; color: var(--color-text-muted); text-align: center; }
.link-btn { background: none; border: none; color: var(--color-accent); cursor: pointer; font-size: 0.78rem; text-decoration: underline; }
.save-footer { padding: var(--space-2) var(--space-3); border-top: 1px solid var(--color-border-light); }
.save-new-btn { width: 100%; height: 28px; background: none; border: 1px dashed var(--color-border); border-radius: var(--radius-sm); font-size: 0.75rem; color: var(--color-text-muted); cursor: pointer; }
.save-new-btn:hover { border-color: var(--color-accent); color: var(--color-accent); }
</style>
