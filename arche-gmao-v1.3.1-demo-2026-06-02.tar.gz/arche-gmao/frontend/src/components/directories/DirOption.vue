<template>
  <div>
    <div class="dir-option" :style="{ paddingLeft: `${8 + depth * 12}px` }" @click="$emit('save', dir.id)">
      <span>◆</span>
      <span class="dir-option-name">{{ dir.name }}</span>
      <span class="dir-option-count">{{ dir.item_count }}</span>
    </div>
    <DirOption
      v-for="child in dir.children"
      :key="child.id"
      :dir="child"
      :depth="depth + 1"
      @save="(id) => $emit('save', id)"
    />
  </div>
</template>

<script setup lang="ts">
import type { Directory } from '@/api/directories'
import DirOption from './DirOption.vue'

defineProps<{ dir: Directory; depth: number }>()
defineEmits<{ save: [id: number] }>()
</script>

<style scoped>
.dir-option {
  display: flex; align-items: center; gap: var(--space-2);
  height: 32px; padding-right: var(--space-3); cursor: pointer;
  font-size: 0.8rem; color: var(--color-text);
  transition: background var(--transition);
}
.dir-option:hover { background: var(--color-surface-2); }
.dir-option-name { flex: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.dir-option-count { font-size: 0.65rem; color: var(--color-text-light); }
</style>
