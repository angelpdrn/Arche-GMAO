<template>
  <div>
    <div
      class="save-option"
      :style="{ paddingLeft: `${10 + depth * 12}px` }"
      @click="$emit('save', dir.id)"
    >
      <span class="opt-icon">{{ dir.is_public ? '◇' : '◆' }}</span>
      <span class="opt-name">{{ dir.name }}</span>
      <span v-if="dir.has_pin" class="opt-pin">◉</span>
      <span class="opt-count">{{ dir.item_count }}</span>
    </div>
    <DirSaveOption
      v-for="child in dir.children"
      :key="child.id"
      :dir="child"
      :depth="depth + 1"
      @save="(id) => $emit('save', id)"
    />
  </div>
</template>

<script setup lang="ts">
import type { Directory } from '@/api/directories'
import DirSaveOption from './DirSaveOption.vue'
defineProps<{ dir: Directory; depth: number }>()
defineEmits<{ save: [id: number] }>()
</script>

<style scoped>
.save-option { display: flex; align-items: center; gap: var(--space-2); height: 32px; padding-right: var(--space-3); cursor: pointer; font-size: 0.8rem; color: var(--color-text); transition: background var(--transition); }
.save-option:hover { background: var(--color-surface-2); }
.opt-icon { font-size: 0.8rem; flex-shrink: 0; }
.opt-name { flex: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.opt-pin { font-size: 0.65rem; }
.opt-count { font-size: 0.65rem; color: var(--color-text-light); }
</style>
