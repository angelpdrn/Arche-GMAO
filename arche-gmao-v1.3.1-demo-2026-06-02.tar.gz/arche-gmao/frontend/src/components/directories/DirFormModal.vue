<template>
  <Teleport to="body">
    <div class="modal-overlay" @click.self="$emit('close')">
      <div class="dir-form-modal">
        <div class="modal-header">
          <h3>{{ isEdit ? 'Editar carpeta' : 'Nueva carpeta' }}</h3>
          <button class="modal-close" @click="$emit('close')">✕</button>
        </div>

        <div class="modal-body">
          <!-- Name -->
          <div class="field">
            <label class="field-label">Nombre *</label>
            <input v-model="form.name" class="field-input" placeholder="Nombre de la carpeta" />
          </div>

          <!-- Description -->
          <div class="field">
            <label class="field-label">Descripción</label>
            <input v-model="form.description" class="field-input" placeholder="Opcional..." />
          </div>

          <!-- Colour -->
          <div class="field">
            <label class="field-label">Color</label>
            <div class="color-grid">
              <button
                v-for="color in DIR_COLORS"
                :key="color"
                class="color-swatch"
                :class="{ 'color-swatch--active': form.color === color }"
                :style="{ background: color }"
                @click="form.color = color"
              ></button>
              <button
                class="color-swatch color-swatch--none"
                :class="{ 'color-swatch--active': !form.color }"
                @click="form.color = ''"
                title="Sin color"
              >—</button>
            </div>
          </div>

          <!-- Visibility -->
          <div class="field">
            <label class="field-label">Visibilidad</label>
            <div class="visibility-options">
              <button
                class="vis-option"
                :class="{ 'vis-option--active': !form.is_public }"
                @click="form.is_public = false"
              >
                <span class="vis-icon">◆</span>
                <div class="vis-text">
                  <span class="vis-title">Privada</span>
                  <span class="vis-desc">Solo tú la ves</span>
                </div>
              </button>
              <button
                class="vis-option"
                :class="{ 'vis-option--active': form.is_public }"
                @click="form.is_public = true"
              >
                <span class="vis-icon">◇</span>
                <div class="vis-text">
                  <span class="vis-title">Pública</span>
                  <span class="vis-desc">Visible para tu equipo</span>
                </div>
              </button>
            </div>
          </div>

          <!-- PIN (only when public) -->
          <div v-if="form.is_public" class="field pin-section">
            <div class="pin-toggle">
              <label class="field-label">Proteger con PIN</label>
              <label class="toggle-switch">
                <input type="checkbox" v-model="enablePin" />
                <span class="toggle-track"></span>
              </label>
            </div>
            <p class="pin-hint">
              Si activas el PIN, cualquiera que intente abrir la carpeta deberá introducirlo primero.
            </p>
            <div v-if="enablePin" class="pin-input-group">
              <input
                v-model="form.access_pin"
                type="password"
                class="field-input mono"
                placeholder="Introduce el PIN (mín. 4 caracteres)"
                maxlength="20"
              />
              <p v-if="isEdit && !form.access_pin" class="pin-hint-small">
                Deja vacío para mantener el PIN actual.
                <button class="link-btn" @click="form.remove_pin = true; enablePin = false">Eliminar PIN</button>
              </p>
            </div>
          </div>

          <div v-if="error" class="modal-error">{{ error }}</div>
        </div>

        <div class="modal-footer">
          <button class="btn-secondary" @click="$emit('close')">Cancelar</button>
          <button class="btn-primary" :disabled="saving || !form.name.trim()" @click="submit">
            {{ saving ? 'Guardando...' : (isEdit ? 'Guardar cambios' : 'Crear carpeta') }}
          </button>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import { apiErrorMsg } from '@/composables/useToast'
import { useDirectoriesStore } from '@/stores/directories'
import { DIR_COLORS } from '@/api/directories'
import type { Directory, DirectorySection } from '@/api/directories'

const props = defineProps<{
  section: DirectorySection
  parentId?: number | null
  editDir?: Directory | null
}>()

const emit = defineEmits<{
  close: []
  saved: [dir: { id: number; name: string }]
}>()

const dirStore = useDirectoriesStore()
const saving = ref(false)
const error = ref('')
const enablePin = ref(false)
const isEdit = !!props.editDir

const form = ref({
  name: props.editDir?.name ?? '',
  description: props.editDir?.description ?? '',
  color: props.editDir?.color ?? '',
  is_public: props.editDir?.is_public ?? false,
  access_pin: '',
  remove_pin: false,
})

// When it has a PIN while editing, show the toggle switched on
if (props.editDir?.has_pin) {
  enablePin.value = true
}

watch(enablePin, (val) => {
  if (!val) {
    form.value.access_pin = ''
  }
})

async function submit() {
  if (!form.value.name.trim()) {
    error.value = 'El nombre es requerido'
    return
  }
  if (form.value.is_public && enablePin.value && form.value.access_pin && form.value.access_pin.length < 4) {
    error.value = 'El PIN debe tener al menos 4 caracteres'
    return
  }

  saving.value = true
  error.value = ''

  try {
    const payload: any = {
      name: form.value.name.trim(),
      description: form.value.description || undefined,
      color: form.value.color || undefined,
      is_public: form.value.is_public,
    }

    if (enablePin.value && form.value.access_pin) {
      payload.access_pin = form.value.access_pin
    }
    if (form.value.remove_pin) {
      payload.remove_pin = true
    }

    let id: number

    if (isEdit && props.editDir) {
      await dirStore.update(props.editDir.id, payload, props.section)
      id = props.editDir.id
    } else {
      payload.section = props.section
      payload.parent_id = props.parentId ?? undefined
      const result = await dirStore.create(payload)
      id = result.id
    }

    emit('saved', { id, name: form.value.name.trim() })
    emit('close')
  } catch (err: unknown) {
    error.value = apiErrorMsg(err, 'Error guardando la carpeta')
  } finally {
    saving.value = false
  }
}
</script>

<style scoped>
.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; padding: var(--space-4); }
.dir-form-modal { background: var(--color-surface); border-radius: var(--radius-lg); width: 100%; max-width: 480px; box-shadow: var(--shadow-lg); }
.modal-header { display: flex; justify-content: space-between; align-items: center; padding: var(--space-5) var(--space-6); border-bottom: 1px solid var(--color-border-light); }
.modal-header h3 { font-size: 1rem; font-weight: 600; color: var(--color-primary); }
.modal-close { background: none; border: none; font-size: 1rem; cursor: pointer; color: var(--color-text-muted); }
.modal-body { padding: var(--space-5) var(--space-6); display: flex; flex-direction: column; gap: var(--space-5); }
.modal-footer { display: flex; justify-content: flex-end; gap: var(--space-3); padding: var(--space-4) var(--space-6); border-top: 1px solid var(--color-border-light); }
.modal-error { background: rgba(233,69,96,0.08); border: 1px solid rgba(233,69,96,0.3); border-radius: var(--radius); padding: var(--space-3); font-size: 0.875rem; color: var(--color-alert); }

.field { display: flex; flex-direction: column; gap: var(--space-2); }
.field-label { font-size: 0.68rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--color-text-muted); }
.field-input { height: 38px; padding: 0 var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; color: var(--color-text); background: var(--color-surface); outline: none; width: 100%; }
.field-input:focus { border-color: var(--color-accent); }

/* Colour swatches */
.color-grid { display: flex; gap: var(--space-2); flex-wrap: wrap; }
.color-swatch { width: 28px; height: 28px; border-radius: 50%; border: 2px solid transparent; cursor: pointer; transition: transform var(--transition), border-color var(--transition); }
.color-swatch:hover { transform: scale(1.15); }
.color-swatch--active { border-color: #fff; box-shadow: 0 0 0 2px var(--color-accent); }
.color-swatch--none { background: var(--color-surface-2) !important; border: 1px solid var(--color-border); color: var(--color-text-muted); font-size: 0.8rem; display: flex; align-items: center; justify-content: center; }

/* Visibility */
.visibility-options { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-3); }
.vis-option { display: flex; align-items: center; gap: var(--space-3); padding: var(--space-3) var(--space-4); border: 2px solid var(--color-border-light); border-radius: var(--radius-md); cursor: pointer; background: var(--color-surface); transition: border-color var(--transition), background var(--transition); }
.vis-option:hover { border-color: var(--color-border); background: var(--color-surface-2); }
.vis-option--active { border-color: var(--color-accent); background: rgba(15,52,96,0.04); }
.vis-icon { font-size: 1.2rem; flex-shrink: 0; }
.vis-text { display: flex; flex-direction: column; gap: 2px; text-align: left; }
.vis-title { font-size: 0.8rem; font-weight: 600; color: var(--color-text); }
.vis-desc { font-size: 0.7rem; color: var(--color-text-muted); }

/* PIN */
.pin-section { background: var(--color-surface-2); border-radius: var(--radius-md); padding: var(--space-4); gap: var(--space-3); }
.pin-toggle { display: flex; align-items: center; justify-content: space-between; }
.pin-hint { font-size: 0.75rem; color: var(--color-text-muted); line-height: 1.5; }
.pin-hint-small { font-size: 0.72rem; color: var(--color-text-muted); }
.pin-input-group { display: flex; flex-direction: column; gap: var(--space-2); }
.link-btn { background: none; border: none; color: var(--color-accent); cursor: pointer; font-size: 0.72rem; text-decoration: underline; }

/* Toggle switch */
.toggle-switch { position: relative; display: inline-block; width: 36px; height: 20px; cursor: pointer; }
.toggle-switch input { opacity: 0; width: 0; height: 0; }
.toggle-track { position: absolute; inset: 0; background: var(--color-border); border-radius: 10px; transition: background var(--transition); }
.toggle-track::before { content: ''; position: absolute; width: 14px; height: 14px; left: 3px; top: 3px; background: #fff; border-radius: 50%; transition: transform var(--transition); }
.toggle-switch input:checked + .toggle-track { background: var(--color-accent); }
.toggle-switch input:checked + .toggle-track::before { transform: translateX(16px); }

.btn-primary { height: 38px; padding: 0 var(--space-5); background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); font-size: 0.875rem; font-weight: 500; cursor: pointer; }
.btn-primary:hover:not(:disabled) { background: var(--color-accent); }
.btn-primary:disabled { opacity: 0.65; cursor: not-allowed; }
.btn-secondary { height: 38px; padding: 0 var(--space-5); background: var(--color-surface-2); color: var(--color-text); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; cursor: pointer; }
.mono { font-family: var(--font-mono); }
</style>
