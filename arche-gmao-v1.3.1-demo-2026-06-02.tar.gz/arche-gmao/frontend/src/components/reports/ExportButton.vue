<template>
  <div class="export-wrap" ref="wrapRef">
    <button class="export-btn" @click.stop="toggleMenu" :disabled="loading">
      <span>{{ loading ? '...' : '↓' }}</span>
      <span>Exportar</span>
    </button>

    <div v-if="open" class="export-menu">
      <button v-for="opt in options" :key="opt.format"
        class="export-option"
        @click="doExport(opt)">
        <span class="export-icon">{{ opt.icon }}</span>
        <div class="export-info">
          <span class="export-label">{{ opt.label }}</span>
          <span class="export-desc">{{ opt.description }}</span>
        </div>
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useToast } from '@/composables/useToast'
const toast = useToast()
import { ref, onMounted, onUnmounted } from 'vue'
import client, { downloadBlob } from '@/api/client'

const props = defineProps<{
  options: {
    format: string
    label: string
    description: string
    icon: string
    url: string
    filename: string
  }[]
}>()

const open = ref(false)
const loading = ref(false)
const wrapRef = ref<HTMLElement | null>(null)

function toggleMenu() { open.value = !open.value }

async function doExport(opt: typeof props.options[0]) {
  open.value = false
  loading.value = true

  try {
    // The URLs come prefixed with /api/v1; we normalize them to the client's baseURL.
    const path = opt.url.replace(/^\/api\/v1/, '')
    if (opt.format === 'html') {
      const resp = await client.get<string>(path, { responseType: 'text' as const })
      const win = window.open('', '_blank')
      if (win) {
        win.document.write(resp.data)
        win.document.close()
        win.focus()
        win.onload = () => win.print()
      }
    } else {
      await downloadBlob(path, opt.filename)
    }
  } catch (err: unknown) {
    const msg = err?.response?.data?.error ?? err?.message ?? 'Error exportando'
    toast.error(msg)
    console.error('[ExportButton]', err)
  } finally {
    loading.value = false
  }
}

function handleOutside(e: MouseEvent) {
  if (wrapRef.value && !wrapRef.value.contains(e.target as Node)) {
    open.value = false
  }
}

onMounted(() => document.addEventListener('click', handleOutside))
onUnmounted(() => document.removeEventListener('click', handleOutside))
</script>

<style scoped>
.export-wrap { position: relative; display: inline-block; }

.export-btn {
  display: flex; align-items: center; gap: var(--space-2);
  height: 36px; padding: 0 var(--space-4);
  background: var(--color-surface-2); border: 1px solid var(--color-border);
  border-radius: var(--radius); font-size: 0.8rem; color: var(--color-text-muted);
  cursor: pointer; transition: all var(--transition);
}
.export-btn:hover:not(:disabled) {
  background: var(--color-border-light); color: var(--color-text);
}
.export-btn:disabled { opacity: 0.5; cursor: not-allowed; }

.export-menu {
  position: absolute; top: calc(100% + 4px); right: 0;
  width: 260px; background: var(--color-surface);
  border: 1px solid var(--color-border); border-radius: var(--radius-md);
  box-shadow: var(--shadow-md); z-index: 500;
  overflow: hidden;
}

.export-option {
  display: flex; align-items: center; gap: var(--space-3);
  width: 100%; padding: var(--space-3) var(--space-4);
  background: none; border: none; border-bottom: 1px solid var(--color-border-light);
  cursor: pointer; text-align: left; transition: background var(--transition);
}
.export-option:last-child { border-bottom: none; }
.export-option:hover { background: var(--color-surface-2); }

.export-icon { font-size: 1.2rem; flex-shrink: 0; }
.export-info { display: flex; flex-direction: column; gap: 2px; }
.export-label { font-size: 0.82rem; font-weight: 500; color: var(--color-text); }
.export-desc { font-size: 0.72rem; color: var(--color-text-muted); }
</style>
