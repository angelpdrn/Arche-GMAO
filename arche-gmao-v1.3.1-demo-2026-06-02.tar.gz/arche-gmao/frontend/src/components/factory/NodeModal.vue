<template>
  <Teleport to="body">
    <div class="modal-overlay" @click.self="$emit('close')">
      <div class="modal">
        <div class="modal-header">
          <h3 class="modal-title">{{ isEdit ? 'Editar nodo' : 'Nuevo nodo' }}</h3>
          <button class="modal-close" @click="$emit('close')">✕</button>
        </div>

        <div class="modal-body">
          <!-- Name -->
          <div class="field">
            <label class="field-label">Nombre *</label>
            <input v-model="form.name" class="field-input" placeholder="Nombre del nodo" />
          </div>

          <!-- Code -->
          <div class="field">
            <label class="field-label">Código</label>
            <input v-model="form.code" class="field-input mono" placeholder="EQ-XXX-001" />
          </div>

          <div class="field-row">
            <!-- Type -->
            <div class="field">
              <label class="field-label">Tipo *</label>
              <select v-model="form.node_type" class="field-input">
                <option v-for="t in nodeTypes" :key="t.type_key" :value="t.type_key">{{ t.label }}</option>
              </select>
            </div>
            <!-- Criticality -->
            <div class="field">
              <label class="field-label">Criticidad</label>
              <select v-model="form.criticality" class="field-input">
                <option value="low">Baja</option>
                <option value="medium">Media</option>
                <option value="high">Alta</option>
                <option value="critical">Crítica</option>
              </select>
            </div>
          </div>

          <!-- Status -->
          <div class="field">
            <label class="field-label">Estado</label>
            <select v-model="form.status" class="field-input">
              <option value="active">Activo</option>
              <option value="inactive">Inactivo</option>
              <option value="maintenance">En Mantenimiento</option>
            </select>
          </div>

          <!-- Description -->
          <div class="field">
            <label class="field-label">Descripción</label>
            <textarea v-model="form.description" class="field-input field-textarea" rows="2" />
          </div>

          <!-- Equipment fields -->
          <template v-if="showEquipmentFields">
            <div class="field-section">Datos del equipo</div>

            <!-- ── Model template ─────────────────────────── -->
            <div class="field">
              <label class="field-label">
                Plantilla de modelo
                <span class="field-hint-inline">Vincula con máquinas del mismo modelo</span>
              </label>
              <div class="template-selector">
                <select v-model="form.template_id" class="field-input">
                  <option :value="null">— Sin plantilla</option>
                  <optgroup label="Plantillas globales">
                    <option v-for="t in globalTemplates" :key="t.id" :value="t.id">
                      {{ t.manufacturer }} {{ t.model }}
                      {{ t.category ? `(${t.category})` : '' }}
                    </option>
                  </optgroup>
                  <optgroup v-if="tenantTemplates.length" label="Mis plantillas">
                    <option v-for="t in tenantTemplates" :key="t.id" :value="t.id">
                      {{ t.manufacturer }} {{ t.model }}
                    </option>
                  </optgroup>
                </select>
                <button class="btn-new-template" type="button" @click="showTemplateQuick = true"
                  title="Crear nueva plantilla">+</button>
              </div>
              <p v-if="selectedTemplate" class="template-preview">
                {{ selectedTemplate.manufacturer }} {{ selectedTemplate.model }}
                <template v-if="selectedTemplate.category"> · {{ selectedTemplate.category }}</template>
              </p>
            </div>
            <!-- ────────────────────────────────────────────────── -->

            <div class="field-row">
              <div class="field">
                <label class="field-label">Fabricante</label>
                <input v-model="form.manufacturer" class="field-input" placeholder="ABB, Siemens..." />
              </div>
              <div class="field">
                <label class="field-label">Modelo</label>
                <input v-model="form.model" class="field-input" placeholder="ACS580..." />
              </div>
            </div>

            <div class="field-row">
              <div class="field">
                <label class="field-label">N° de Serie</label>
                <input v-model="form.serial_number" class="field-input mono" />
              </div>
              <div class="field">
                <label class="field-label">Año instalación</label>
                <input v-model.number="form.year_installed" type="number" class="field-input mono"
                  min="1900" max="2100" />
              </div>
            </div>

            <div class="field">
              <label class="field-label">Potencia nominal (kW)</label>
              <input v-model.number="form.rated_power_kw" type="number" class="field-input mono"
                step="0.1" min="0" />
            </div>
          </template>

          <div v-if="error" class="modal-error">{{ error }}</div>
        </div>

        <div class="modal-footer">
          <button class="btn btn--secondary" @click="$emit('close')">Cancelar</button>
          <button class="btn btn--primary" :disabled="!canWrite || saving" @click="handleSubmit">
            {{ saving ? 'Guardando...' : (isEdit ? 'Guardar cambios' : 'Crear nodo') }}
          </button>
        </div>
      </div>
    </div>
  </Teleport>

  <!-- Quick create template modal -->
  <Teleport to="body">
    <div v-if="showTemplateQuick" class="modal-overlay modal-overlay--top" @click.self="showTemplateQuick = false">
      <div class="quick-modal">
        <div class="modal-header">
          <h3>Nueva plantilla rápida</h3>
          <button class="modal-close" @click="showTemplateQuick = false">✕</button>
        </div>
        <div class="modal-body">
          <div class="field-row">
            <div class="field">
              <label class="field-label">Fabricante *</label>
              <input v-model="quickForm.manufacturer" class="field-input" />
            </div>
            <div class="field">
              <label class="field-label">Modelo *</label>
              <input v-model="quickForm.model" class="field-input" />
            </div>
          </div>
          <div class="field">
            <label class="field-label">Categoría</label>
            <input v-model="quickForm.category" class="field-input" placeholder="Variador, Compresor..." />
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn--secondary" @click="showTemplateQuick = false">Cancelar</button>
          <button class="btn btn--primary" :disabled="!canWrite || savingTemplate" @click="submitQuickTemplate">
            {{ savingTemplate ? 'Creando...' : 'Crear y seleccionar' }}
          </button>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
import { useToast } from '@/composables/useToast'
const toast = useToast()
import { ref, computed, onMounted } from 'vue'
import { nodesApi } from '@/api/nodes'
import { templatesApi } from '@/api/templates'
import { useFactoryStore } from '@/stores/factory'
import type { FactoryNode, NodeFormData, NodeTypeDefinition } from '@/types/factory'
import type { EquipmentTemplate } from '@/api/templates'
import client from '@/api/client'
import { useSystemPause } from '@/composables/useSystemPause'

const { canWrite } = useSystemPause()
const props = defineProps<{
  parentNode?: FactoryNode | null
  editNode?: FactoryNode | null
}>()

const emit = defineEmits<{
  close: []
  saved: [node: FactoryNode]
}>()

const factoryStore = useFactoryStore()
const saving = ref(false)
const error = ref('')
const nodeTypes = ref<NodeTypeDefinition[]>([])
const allTemplates = ref<EquipmentTemplate[]>([])

const isEdit = computed(() => !!props.editNode)

const showEquipmentFields = computed(
  () => ['equipment', 'component', 'measurement_point', 'composition'].includes(form.value.node_type)
)

const globalTemplates = computed(() => allTemplates.value.filter(t => t.is_global))
const tenantTemplates = computed(() => allTemplates.value.filter(t => !t.is_global))

const selectedTemplate = computed(() =>
  form.value.template_id
    ? allTemplates.value.find(t => t.id === form.value.template_id) ?? null
    : null
)

const form = ref<NodeFormData & { template_id: number | null }>({
  parent_id: props.parentNode?.id ?? null,
  client_id: props.parentNode?.client_id ?? null,
  name: '', code: '', node_type: 'equipment',
  status: 'active', criticality: 'medium',
  description: '', manufacturer: '', model: '',
  serial_number: '', year_installed: null, rated_power_kw: null,
  version: 1, template_id: null,
})

// Quick template
const showTemplateQuick = ref(false)
const savingTemplate = ref(false)
const quickForm = ref({ manufacturer: '', model: '', category: '' })

onMounted(async () => {
  // Load the node types
  try {
    const res = await client.get('/node-types')
    nodeTypes.value = res.data.node_types ?? []
  } catch { /* use an empty list */ }

  // Load the templates
  try {
    const data = await templatesApi.list()
    allTemplates.value = data.templates ?? []
  } catch { /* no templates */ }

  // When editing, fill the form
  if (props.editNode) {
    const n = props.editNode
    form.value = {
      parent_id: n.parent_id, client_id: n.client_id,
      name: n.name, code: n.code ?? '',
      node_type: n.node_type, status: n.status, criticality: n.criticality,
      description: n.description ?? '', manufacturer: n.manufacturer ?? '',
      model: n.model ?? '', serial_number: n.serial_number ?? '',
      year_installed: n.year_installed, rated_power_kw: n.rated_power_kw,
      version: n.version,
      template_id: (n as any).template_id ?? null,
    }
  }
})

async function submitQuickTemplate() {
  if (!quickForm.value.manufacturer || !quickForm.value.model) return
  savingTemplate.value = true
  try {
    const res = await templatesApi.create({
      manufacturer: quickForm.value.manufacturer,
      model: quickForm.value.model,
      category: quickForm.value.category || undefined,
    } as any)
    // Reload and select the new one
    const data = await templatesApi.list()
    allTemplates.value = data.templates ?? []
    form.value.template_id = res.id
    // Auto-fill manufacturer and model
    if (!form.value.manufacturer) form.value.manufacturer = quickForm.value.manufacturer
    if (!form.value.model) form.value.model = quickForm.value.model
    showTemplateQuick.value = false
    quickForm.value = { manufacturer: '', model: '', category: '' }
  } catch (err: unknown) {
    toast.fromError(err, 'Error creando plantilla')
  } finally { savingTemplate.value = false }
}

async function handleSubmit() {
  if (!form.value.name.trim()) {
    error.value = 'El nombre es requerido'
    return
  }

  saving.value = true
  error.value = ''

  const payload: any = {
    ...form.value,
    code: form.value.code || undefined,
    description: form.value.description || undefined,
    manufacturer: form.value.manufacturer || undefined,
    model: form.value.model || undefined,
    serial_number: form.value.serial_number || undefined,
  }

  try {
    let saved: FactoryNode
    if (isEdit.value && props.editNode) {
      saved = await nodesApi.update(props.editNode.id, payload)
      // Update the template when it changed
      await templatesApi.assignToNode(props.editNode.id, form.value.template_id)
    } else {
      saved = await nodesApi.create(payload)
      // Assign the template to the new node
      if (form.value.template_id) {
        await templatesApi.assignToNode(saved.id, form.value.template_id)
      }
    }
    await factoryStore.refreshTree()
    emit('saved', saved)
    emit('close')
  } catch (err: unknown) {
    const axiosError = err as { response?: { data?: { error?: string } } }
    error.value = axiosError.response?.data?.error ?? 'Error guardando el nodo'
  } finally {
    saving.value = false
  }
}
</script>

<style scoped>
.modal-overlay {
  position: fixed; inset: 0; background: rgba(0,0,0,0.5);
  display: flex; align-items: center; justify-content: center;
  z-index: 1000; padding: var(--space-4);
}
.modal-overlay--top { z-index: 1100; }

.modal, .quick-modal {
  background: var(--color-surface);
  border-radius: var(--radius-lg);
  width: 100%;
  box-shadow: var(--shadow-lg);
}
.modal { max-width: 560px; max-height: 90vh; display: flex; flex-direction: column; }
.quick-modal { max-width: 420px; }

.modal-header { display: flex; align-items: center; justify-content: space-between; padding: var(--space-5) var(--space-6); border-bottom: 1px solid var(--color-border-light); }
.modal-title { font-size: 1rem; font-weight: 600; color: var(--color-primary); }
.modal-close { background: none; border: none; color: var(--color-text-muted); cursor: pointer; font-size: 1rem; }
.modal-close:hover { color: var(--color-text); }
.modal-body { flex: 1; overflow-y: auto; padding: var(--space-5) var(--space-6); display: flex; flex-direction: column; gap: var(--space-4); }
.modal-footer { display: flex; justify-content: flex-end; gap: var(--space-3); padding: var(--space-4) var(--space-6); border-top: 1px solid var(--color-border-light); }
.modal-error { background: rgba(233,69,96,0.08); border: 1px solid rgba(233,69,96,0.3); border-radius: var(--radius); padding: var(--space-3) var(--space-4); font-size: 0.875rem; color: var(--color-alert); }

.field { display: flex; flex-direction: column; gap: var(--space-1); flex: 1; }
.field-row { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-4); }
.field-label { font-size: 0.72rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: var(--color-text-muted); display: flex; align-items: center; gap: var(--space-2); }
.field-hint-inline { font-size: 0.68rem; color: var(--color-text-light); font-weight: 400; text-transform: none; letter-spacing: 0; }
.field-section { font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; color: var(--color-text-muted); padding-top: var(--space-2); border-top: 1px solid var(--color-border-light); }

.field-input { height: 38px; padding: 0 var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; color: var(--color-text); background: var(--color-surface); outline: none; transition: border-color var(--transition); width: 100%; }
.field-input:focus { border-color: var(--color-accent); }
.field-textarea { height: auto; padding: var(--space-2) var(--space-3); resize: vertical; }

/* Template selector */
.template-selector { display: flex; gap: var(--space-2); }
.template-selector .field-input { flex: 1; }
.btn-new-template { width: 38px; height: 38px; background: var(--color-surface-2); border: 1px solid var(--color-border); border-radius: var(--radius); cursor: pointer; font-size: 1.2rem; color: var(--color-text-muted); display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.btn-new-template:hover { background: var(--color-primary); color: #fff; border-color: var(--color-primary); }

.template-preview { font-size: 0.75rem; color: var(--color-accent); padding: var(--space-1) var(--space-2); background: rgba(15,52,96,0.06); border-radius: var(--radius-sm); }

.btn { height: 38px; padding: 0 var(--space-5); border-radius: var(--radius); font-size: 0.875rem; font-weight: 500; cursor: pointer; border: none; transition: background var(--transition), opacity var(--transition); }
.btn--primary { background: var(--color-primary); color: #fff; }
.btn--primary:hover:not(:disabled) { background: var(--color-accent); }
.btn--primary:disabled { opacity: 0.65; cursor: not-allowed; }
.btn--secondary { background: var(--color-surface-2); color: var(--color-text); border: 1px solid var(--color-border); }
.btn--secondary:hover { background: var(--color-border-light); }

.mono { font-family: var(--font-mono); }
</style>
