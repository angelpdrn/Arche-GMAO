<template>
  <div class="tree-node">
    <div
      class="tree-item"
      :class="{
        'tree-item--selected': isSelected,
        'tree-item--has-children': hasChildren,
        'tree-item--drag-over': isDragOver,
        'tree-item--dragging': isDragging,
      }"
      :style="{ paddingLeft: `${8 + depth * 16}px` }"
      draggable="true"
      @click="handleClick"
      @dragstart="onDragStart"
      @dragend="onDragEnd"
      @dragover="onDragOver"
      @dragleave="onDragLeave"
      @drop="onDrop"
    >
      <!-- Toggle expand -->
      <button
        v-if="hasChildren"
        class="tree-toggle"
        @click.stop="factoryStore.toggleExpand(node.id)"
      >
        {{ isExpanded ? '▾' : '▸' }}
      </button>
      <span v-else class="tree-toggle tree-toggle--leaf"></span>

      <!-- Criticality indicator -->
      <span
        class="tree-crit"
        :style="{ background: critColor }"
        :title="node.criticality"
      ></span>

      <!-- Name -->
      <span class="tree-name">{{ node.name }}</span>

      <!-- Type badge -->
      <span class="tree-type">{{ typeLabel }}</span>
    </div>

    <!-- Children (recursive) -->
    <div v-if="isExpanded && hasChildren" class="tree-children">
      <TreeNode
        v-for="child in node.children"
        :key="child.id"
        :node="child"
        :depth="depth + 1"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { useToast } from '@/composables/useToast'
const toast = useToast()
import { computed, ref } from 'vue'
import { useFactoryStore } from '@/stores/factory'
import { nodesApi } from '@/api/nodes'
import { NODE_TYPE_CONFIG, CRITICALITY_CONFIG } from '@/types/factory'
import type { FactoryNode } from '@/types/factory'

// Self-referential import for recursion
import TreeNode from './TreeNode.vue'

const props = defineProps<{
  node: FactoryNode
  depth?: number
}>()

const factoryStore = useFactoryStore()

const depth = computed(() => props.depth ?? 0)
const hasChildren = computed(() => props.node.children?.length > 0)
const isExpanded = computed(() => factoryStore.isExpanded(props.node.id))
const isSelected = computed(() => factoryStore.selectedNode?.id === props.node.id)

const typeLabel = computed(
  () => NODE_TYPE_CONFIG[props.node.node_type]?.label ?? props.node.node_type
)

const critColor = computed(
  () => CRITICALITY_CONFIG[props.node.criticality]?.color ?? '#B0B8C4'
)

const isDragOver = ref(false)
const isDragging = ref(false)

// Hierarchy: a node can only be a child of types with a lower depth
const HIERARCHY: Record<string, number> = {
  organization: 0, plant: 1, area: 2, line: 3,
  composition: 4, equipment: 4, component: 5, measurement_point: 6,
}

function canAcceptDrop(draggedType: string, targetType: string): boolean {
  const dragLevel = HIERARCHY[draggedType] ?? 99
  const targetLevel = HIERARCHY[targetType] ?? 99
  return dragLevel > targetLevel
}

function isDescendant(parentPath: string, childPath: string): boolean {
  return childPath === parentPath || childPath.startsWith(parentPath + '.')
}

function handleClick() {
  factoryStore.selectNode(props.node)
  if (hasChildren.value) {
    factoryStore.toggleExpand(props.node.id)
  }
}

function onDragStart(e: DragEvent) {
  if (!e.dataTransfer) return
  isDragging.value = true
  e.dataTransfer.effectAllowed = 'move'
  e.dataTransfer.setData('application/json', JSON.stringify({
    id: props.node.id,
    node_type: props.node.node_type,
    path: props.node.path,
    name: props.node.name,
    version: props.node.version ?? 0,
  }))
}

function onDragEnd() {
  isDragging.value = false
}

function onDragOver(e: DragEvent) {
  e.preventDefault()
  if (!e.dataTransfer) return

  try {
    // We cannot read the data during dragover in every browser,
    // but we can use the types
    e.dataTransfer.dropEffect = 'move'
    isDragOver.value = true
  } catch {
    // ignore
  }
}

function onDragLeave() {
  isDragOver.value = false
}

async function onDrop(e: DragEvent) {
  e.preventDefault()
  e.stopPropagation()
  isDragOver.value = false

  if (!e.dataTransfer) return
  const raw = e.dataTransfer.getData('application/json')
  if (!raw) return

  let dragged: { id: number; node_type: string; path: string; name: string; version?: number }
  try { dragged = JSON.parse(raw) } catch { return }

  // Do not drop onto itself
  if (dragged.id === props.node.id) return

  // Do not drop inside its own subtree
  if (isDescendant(dragged.path, props.node.path)) return

  // Validate the hierarchy
  if (!canAcceptDrop(dragged.node_type, props.node.node_type)) {
    toast.error(`Un "${NODE_TYPE_CONFIG[dragged.node_type]?.label}" no puede estar dentro de un "${typeLabel.value}"`)
    return
  }

  if (!confirm(`¿Mover "${dragged.name}" dentro de "${props.node.name}"?`)) return

  try {
    await nodesApi.move(dragged.id, props.node.id, dragged.version)
    await factoryStore.refreshTree()
    // Expand the target node so the result is visible
    if (!factoryStore.isExpanded(props.node.id)) {
      factoryStore.toggleExpand(props.node.id)
    }
  } catch (err: unknown) {
    toast.fromError(err, 'Error moviendo nodo')
  }
}
</script>

<style scoped>
.tree-node {
  user-select: none;
}

.tree-item {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 34px;
  cursor: grab;
  border-radius: 4px;
  margin: 1px 4px;
  padding-right: 8px;
  transition: background var(--transition), border-color 0.15s;
  border: 2px solid transparent;
}

.tree-item:hover {
  background: rgba(255,255,255,0.06);
}

.tree-item--selected {
  background: rgba(255,255,255,0.12) !important;
}

.tree-item--dragging {
  opacity: 0.4;
  cursor: grabbing;
}

.tree-item--drag-over {
  border-color: var(--color-accent, #3B82F6);
  background: rgba(59,130,246,0.12) !important;
}

.tree-toggle {
  width: 16px;
  height: 16px;
  background: none;
  border: none;
  color: rgba(255,255,255,0.4);
  font-size: 0.75rem;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  padding: 0;
}

.tree-toggle:hover {
  color: #fff;
}

.tree-toggle--leaf {
  pointer-events: none;
}

.tree-crit {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  flex-shrink: 0;
}

.tree-name {
  flex: 1;
  font-size: 0.8rem;
  color: rgba(255,255,255,0.75);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.tree-item--selected .tree-name {
  color: #fff;
  font-weight: 500;
}

.tree-type {
  font-size: 0.65rem;
  color: rgba(255,255,255,0.25);
  white-space: nowrap;
}

.tree-children {
  /* No extra margin; the indentation comes from each item's padding-left */
}
</style>
