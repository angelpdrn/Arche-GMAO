<template>
  <div class="stagger-preview">
    <!-- Summary -->
    <div class="preview-summary">
      <div class="summary-item">
        <span class="summary-value mono">{{ preview.total_planned }}</span>
        <span class="summary-label">Tareas planificadas</span>
      </div>
      <div class="summary-item">
        <span class="summary-value mono">{{ workDayCount }}</span>
        <span class="summary-label">Días hábiles</span>
      </div>
      <div class="summary-item">
        <span class="summary-value mono">{{ avgPerDay }}</span>
        <span class="summary-label">Media diaria</span>
      </div>
      <div class="summary-item">
        <span class="summary-value mono">{{ preview.max_daily_per_tech }}</span>
        <span class="summary-label">Max/técnico/día</span>
      </div>
    </div>

    <!-- Timeline per day -->
    <div class="timeline-header">
      <span class="timeline-title">Distribución por día</span>
      <span class="timeline-range mono">{{ formatDate(preview.cycle_start) }} &#x2192; {{ formatDate(preview.cycle_end) }}</span>
    </div>

    <div class="timeline-grid">
      <div
        v-for="day in timelineDays"
        :key="day.date"
        class="timeline-day"
        :class="{
          'timeline-day--overload': day.load > preview.max_daily_per_tech,
          'timeline-day--empty': day.load === 0,
          'timeline-day--active': expandedDay === day.date
        }"
        @click="toggleDay(day.date)"
      >
        <div class="day-header">
          <span class="day-name">{{ day.dayName }}</span>
          <span class="day-date mono">{{ day.shortDate }}</span>
        </div>
        <div class="day-bar-wrap">
          <div
            class="day-bar"
            :style="{
              width: barWidth(day.load) + '%',
              background: barColor(day.load)
            }"
          ></div>
        </div>
        <span class="day-count mono" :class="{ 'day-count--over': day.load > preview.max_daily_per_tech }">
          {{ day.load }}
        </span>
      </div>
    </div>

    <!-- Expanded day detail -->
    <div v-if="expandedDay && expandedEntries.length" class="day-detail">
      <div class="day-detail-header">
        <span class="day-detail-title">{{ formatDate(expandedDay) }}</span>
        <span class="day-detail-count mono">{{ expandedEntries.length }} tareas</span>
      </div>
      <table class="day-detail-table">
        <thead>
          <tr>
            <th>Equipo</th>
            <th>Plan</th>
            <th>Técnico</th>
            <th>Criticidad</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="e in expandedEntries" :key="`${e.plan_id}-${e.node_id}`">
            <td>
              <span class="entry-node">{{ e.node_name }}</span>
              <span v-if="e.node_code" class="entry-code mono">{{ e.node_code }}</span>
            </td>
            <td class="entry-plan">{{ e.plan_title }}</td>
            <td class="entry-tech">{{ e.technician_name || '&#x2014;' }}</td>
            <td>
              <span class="crit-badge" :style="{ background: CRIT_COLORS[e.criticality] }">
                {{ CRIT_LABELS[e.criticality] }}
              </span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue'
import type { SchedulePreview } from '@/api/staggering'

const props = defineProps<{ preview: SchedulePreview }>()

const CRIT_COLORS: Record<string, string> = {
  low: '#27AE60', medium: '#F39C12', high: '#E67E22', critical: '#E94560'
}
const CRIT_LABELS: Record<string, string> = {
  low: 'Baja', medium: 'Media', high: 'Alta', critical: 'Crítica'
}
const DAY_NAMES: Record<number, string> = {
  0: 'Dom', 1: 'Lun', 2: 'Mar', 3: 'Mié', 4: 'Jue', 5: 'Vie', 6: 'Sáb'
}

const expandedDay = ref<string | null>(null)

interface TimelineDay {
  date: string
  shortDate: string
  dayName: string
  load: number
}

const timelineDays = computed<TimelineDay[]>(() => {
  const days: TimelineDay[] = []
  const start = new Date(props.preview.cycle_start + 'T00:00:00')
  const end = new Date(props.preview.cycle_end + 'T00:00:00')

  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    const dow = d.getDay()
    if (dow === 0 || dow === 6) continue // skip weekends
    const iso = d.toISOString().slice(0, 10)
    days.push({
      date: iso,
      shortDate: `${d.getDate()}/${d.getMonth() + 1}`,
      dayName: DAY_NAMES[dow],
      load: props.preview.daily_load[iso] ?? 0,
    })
  }
  return days
})

const workDayCount = computed(() => timelineDays.value.length)
const avgPerDay = computed(() => {
  if (!workDayCount.value) return '0'
  return (props.preview.total_planned / workDayCount.value).toFixed(1)
})

const maxLoad = computed(() => {
  let m = props.preview.max_daily_per_tech
  for (const d of timelineDays.value) {
    if (d.load > m) m = d.load
  }
  return m || 1
})

function barWidth(load: number): number {
  return Math.min((load / maxLoad.value) * 100, 100)
}

function barColor(load: number): string {
  if (load === 0) return 'transparent'
  if (load > props.preview.max_daily_per_tech) return '#E94560'
  if (load === props.preview.max_daily_per_tech) return '#E67E22'
  return '#0F3460'
}

const expandedEntries = computed(() => {
  if (!expandedDay.value) return []
  return props.preview.entries.filter(e => e.scheduled_date === expandedDay.value)
})

function toggleDay(date: string) {
  expandedDay.value = expandedDay.value === date ? null : date
}

function formatDate(iso: string) {
  if (!iso) return '\u2014'
  try {
    return new Date(iso + 'T00:00:00').toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric' })
  } catch { return iso }
}
</script>

<style scoped>
.stagger-preview { display: flex; flex-direction: column; gap: var(--space-4); }

/* Summary */
.preview-summary { display: grid; grid-template-columns: repeat(4, 1fr); gap: var(--space-3); }
.summary-item {
  display: flex; flex-direction: column; gap: 2px;
  padding: var(--space-3); background: var(--color-surface-2);
  border: 1px solid var(--color-border-light); border-radius: var(--radius);
  text-align: center;
}
.summary-value { font-size: 1.3rem; font-weight: 700; color: var(--color-primary); }
.summary-label { font-size: 0.65rem; font-weight: 600; text-transform: uppercase; color: var(--color-text-muted); }

/* Timeline header */
.timeline-header {
  display: flex; justify-content: space-between; align-items: center;
  padding-bottom: var(--space-2); border-bottom: 1px solid var(--color-border-light);
}
.timeline-title { font-size: 0.78rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); }
.timeline-range { font-size: 0.72rem; color: var(--color-text-muted); }

/* Timeline grid */
.timeline-grid { display: flex; flex-direction: column; gap: 2px; }
.timeline-day {
  display: grid; grid-template-columns: 72px 1fr 40px; align-items: center; gap: var(--space-3);
  padding: var(--space-2) var(--space-3);
  border-radius: var(--radius-sm);
  cursor: pointer; transition: background 0.15s;
}
.timeline-day:hover { background: var(--color-surface-2); }
.timeline-day--active { background: var(--color-surface-2); }
.timeline-day--empty { opacity: 0.5; }

.day-header { display: flex; gap: var(--space-2); align-items: baseline; }
.day-name { font-size: 0.72rem; font-weight: 600; color: var(--color-text-muted); width: 28px; }
.day-date { font-size: 0.68rem; color: var(--color-text-muted); }

.day-bar-wrap {
  height: 18px; background: var(--color-border-light); border-radius: 3px;
  overflow: hidden;
}
.day-bar { height: 100%; border-radius: 3px; transition: width 0.3s ease; min-width: 2px; }

.day-count { font-size: 0.75rem; font-weight: 600; text-align: right; color: var(--color-text); }
.day-count--over { color: var(--color-alert); }

/* Day detail */
.day-detail {
  background: var(--color-surface-2); border: 1px solid var(--color-border-light);
  border-radius: var(--radius); overflow: hidden;
}
.day-detail-header {
  display: flex; justify-content: space-between; align-items: center;
  padding: var(--space-3) var(--space-4);
  border-bottom: 1px solid var(--color-border-light);
}
.day-detail-title { font-size: 0.82rem; font-weight: 600; }
.day-detail-count { font-size: 0.72rem; color: var(--color-text-muted); }

.day-detail-table { width: 100%; border-collapse: collapse; font-size: 0.78rem; }
.day-detail-table th {
  padding: var(--space-2) var(--space-4);
  font-size: 0.62rem; font-weight: 700; text-transform: uppercase;
  color: var(--color-text-muted); text-align: left;
  background: var(--color-surface); border-bottom: 1px solid var(--color-border-light);
}
.day-detail-table td {
  padding: var(--space-2) var(--space-4);
  border-bottom: 1px solid var(--color-border-light);
  vertical-align: middle;
}
.day-detail-table tr:last-child td { border-bottom: none; }

.entry-node { font-weight: 500; display: block; }
.entry-code { font-size: 0.68rem; color: var(--color-text-muted); display: block; }
.entry-plan { max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.entry-tech { color: var(--color-text-muted); }

.crit-badge {
  font-size: 0.62rem; font-weight: 700; color: #fff;
  padding: 2px 8px; border-radius: 20px; white-space: nowrap;
}

.mono { font-family: var(--font-mono); }

@media (max-width: 768px) {
  .preview-summary { grid-template-columns: repeat(2, 1fr); }
  .timeline-day { grid-template-columns: 60px 1fr 32px; }
}
</style>
