import client from './client'

export interface EquipmentTemplate {
  id: number
  tenant_id: number | null
  manufacturer: string
  model: string
  category: string | null
  node_type: string
  description: string | null
  notes: string | null
  tags: string[]
  is_global: boolean
  is_active: boolean
  node_count: number
  created_at: string
}

export interface TemplateWithNodes {
  template: EquipmentTemplate
  nodes: {
    id: number
    name: string
    code: string | null
    node_type: string
    status: string
    criticality: string
  }[]
}

export const templatesApi = {
  list(params?: { q?: string; category?: string }): Promise<{ templates: EquipmentTemplate[]; total: number }> {
    return client.get('/templates', { params }).then(r => r.data)
  },

  getOne(id: number): Promise<TemplateWithNodes> {
    return client.get(`/templates/${id}`).then(r => r.data)
  },

  getCategories(): Promise<{ categories: string[] }> {
    return client.get('/templates/categories').then(r => r.data)
  },

  create(data: Partial<EquipmentTemplate>): Promise<{ id: number }> {
    return client.post('/templates', data).then(r => r.data)
  },

  update(id: number, data: Partial<EquipmentTemplate>): Promise<void> {
    return client.put(`/templates/${id}`, data).then(() => {})
  },

  delete(id: number): Promise<void> {
    return client.delete(`/templates/${id}`).then(() => {})
  },

  assignToNode(nodeId: number, templateId: number | null): Promise<void> {
    return client.patch(`/factory/nodes/${nodeId}/template`, { template_id: templateId }).then(() => {})
  },

  getSiblings(nodeId: number): Promise<{ siblings: { node_id: number; node_name: string }[]; total: number }> {
    return client.get(`/factory/nodes/${nodeId}/siblings`).then(r => r.data)
  },

  // ─── Template library ──────────────────────────────────────
  listLibrary(templateId: number, folderId?: number): Promise<{ attachments: any[]; folders: any[]; total: number }> {
    const params: Record<string, string> = {}
    if (folderId !== undefined) params.folder_id = String(folderId)
    return client.get(`/templates/${templateId}/library`, { params }).then(r => r.data)
  },

  uploadToTemplate(templateId: number, formData: FormData): Promise<{ id: number }> {
    return client.post(`/templates/${templateId}/library/upload`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    }).then(r => r.data)
  },

  deleteTemplateFile(attId: number): Promise<void> {
    return client.delete(`/templates/library/${attId}`).then(() => {})
  },

  listFolders(templateId: number): Promise<{ folders: any[] }> {
    return client.get(`/templates/${templateId}/folders`).then(r => r.data)
  },

  createFolder(templateId: number, data: { name: string; parent_id?: number }): Promise<{ id: number }> {
    return client.post(`/templates/${templateId}/folders`, data).then(r => r.data)
  },

  deleteFolder(folderId: number): Promise<void> {
    return client.delete(`/templates/folders/${folderId}`).then(() => {})
  }
}
