import client from './client'

export interface SystemStatus {
  system_paused: boolean
  paused_by: number | null
  paused_by_name: string | null
  paused_at: string | null
  paused_contact: string | null
  max_users: number | null
  active_users: number
  total_users: number
}

export interface LicenseInfo {
  modules: string[]
  max_users: number
  max_nodes: number
  days_left: number
}

export const systemApi = {
  getStatus(): Promise<SystemStatus> {
    return client.get<SystemStatus>('/system/status').then((r) => r.data)
  },

  pause(contact: string): Promise<void> {
    return client.post('/system/pause', { contact }).then(() => {})
  },

  resume(): Promise<void> {
    return client.post('/system/resume').then(() => {})
  },

  getLicenseInfo(): Promise<LicenseInfo> {
    return client.get<LicenseInfo>('/license/info').then((r) => r.data)
  },
}
