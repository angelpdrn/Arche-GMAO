import client, { getAccessToken, setAccessToken } from './client'
import axios from 'axios'

export interface AIMessage {
  id: number
  role: 'user' | 'assistant' | 'system'
  content: string
  sources?: AISource[]
  created_at: string
}

export interface AISource {
  source_type: string
  source_id: number
  data_type: string
  similarity: string
}

export interface AIConversation {
  id: number
  title: string | null
  node_id: number | null
  node_name: string | null
  updated_at: string
}

export interface AIStatus {
  ollama_available: boolean
  indexed_chunks: number
  pending_queue: number
  models: { name: string; size: number }[]
}

export const aiApi = {
  getStatus(): Promise<AIStatus> {
    return client.get('/ai/status').then(r => r.data)
  },

  listConversations(): Promise<{ conversations: AIConversation[] }> {
    return client.get('/ai/conversations').then(r => r.data)
  },

  getConversation(id: number): Promise<{ messages: AIMessage[] }> {
    return client.get(`/ai/conversations/${id}`).then(r => r.data)
  },

  deleteConversation(id: number): Promise<void> {
    return client.delete(`/ai/conversations/${id}`).then(() => {})
  },

  indexManual(sourceType: string, sourceId: number): Promise<void> {
    return client.post(`/ai/index/${sourceType}/${sourceId}`).then(() => {})
  },

  reindexAll(): Promise<{ message: string }> {
    return client.post('/ai/reindex-all').then(r => r.data)
  },

  /**
   * SSE streaming: sends a message and invokes the callbacks as tokens arrive.
   * Returns a function for cancelling the stream.
   */
  chatStream(params: {
    message: string
    conversationId?: number | null
    nodeId?: number | null
    onToken: (token: string) => void
    onDone: (sources: AISource[], conversationId: number) => void
    onError: (error: string) => void
  }): () => void {
    const controller = new AbortController()

    const doStream = async (authToken: string | null) => {
      const response = await fetch('/api/v1/ai/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(authToken ? { 'Authorization': `Bearer ${authToken}` } : {}),
        },
        body: JSON.stringify({
          message: params.message,
          conversation_id: params.conversationId ?? undefined,
          node_id: params.nodeId ?? undefined,
        }),
        signal: controller.signal,
      })

      // On a 401, try a refresh and retry once
      if (response.status === 401) {
        try {
          const res = await axios.post<{ access_token: string }>('/api/v1/auth/refresh', {}, {
            withCredentials: true
          })
          const newToken = res.data.access_token
          if (newToken) {
            setAccessToken(newToken)
            return doStream(newToken)
          }
        } catch {
          // Refresh failed — report the original error
        }
        params.onError('Sesión expirada. Recarga la página para continuar.')
        return
      }

      if (!response.ok) {
        const data = await response.json().catch(() => ({}))
        params.onError(data.error ?? `Error ${response.status}`)
        return
      }

      const reader = response.body!.getReader()
      const decoder = new TextDecoder()
      let buffer = ''
      let convId = 0

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split('\n')
        buffer = lines.pop() ?? ''

        for (const line of lines) {
          if (!line.startsWith('data: ')) continue
          try {
            const payload = JSON.parse(line.slice(6))

            if (payload.type === 'conversation_id') {
              convId = payload.id
            } else if (payload.type === 'chunk') {
              params.onToken(payload.content)
            } else if (payload.type === 'done') {
              params.onDone(payload.sources ?? [], convId)
            } else if (payload.type === 'error') {
              params.onError(payload.error)
            }
          } catch { /* skip malformed */ }
        }
      }
    }

    doStream(getAccessToken()).catch((err) => {
      if (err.name !== 'AbortError') {
        params.onError(err.message ?? 'Error de conexión con Arche IA')
      }
    })

    return () => controller.abort()
  }
}
