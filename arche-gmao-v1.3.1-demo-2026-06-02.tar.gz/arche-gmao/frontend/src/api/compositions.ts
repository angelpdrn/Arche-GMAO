import client from '@/api/client'

// ─── Equipment compositions ────────────────────────────────────────────────

export const compositionsApi = {
  // List a node's compositions
  byNode: (nodeId: number) =>
    client.get(`/compositions/by-node/${nodeId}`).then(r => r.data),

  // List the compositions under a parent node
  byParent: (parentId: number) =>
    client.get('/compositions', { params: { parent_id: parentId } }).then(r => r.data),

  // List them all
  list: () =>
    client.get('/compositions').then(r => r.data),

  // Detail with members
  getOne: (id: number) =>
    client.get(`/compositions/${id}`).then(r => r.data),

  // Create a composition
  create: (data: { name: string; description?: string; parent_node_id?: number; node_ids: number[]; roles?: string[] }) =>
    client.post('/compositions', data).then(r => r.data),

  // Update
  update: (id: number, data: { name: string; description?: string }) =>
    client.put(`/compositions/${id}`, data).then(r => r.data),

  // Delete
  delete: (id: number) =>
    client.delete(`/compositions/${id}`).then(r => r.data),

  // Add a member
  addMember: (compId: number, nodeId: number, role?: string) =>
    client.post(`/compositions/${compId}/members`, { node_id: nodeId, role }).then(r => r.data),

  // Remove a member
  removeMember: (compId: number, nodeId: number) =>
    client.delete(`/compositions/${compId}/members/${nodeId}`).then(r => r.data),
}

// ─── Composition templates ───────────────────────────────────────────────

export interface CompTemplateSlot {
  id?: number
  role: string
  equipment_template_id: number | null
  equipment_name?: string
  sort_order: number
}

export const compTemplatesApi = {
  list: () =>
    client.get('/composition-templates').then(r => r.data),

  getOne: (id: number) =>
    client.get(`/composition-templates/${id}`).then(r => r.data),

  create: (data: { name: string; description?: string; slots: CompTemplateSlot[] }) =>
    client.post('/composition-templates', data).then(r => r.data),

  update: (id: number, data: { name: string; description?: string; slots: CompTemplateSlot[] }) =>
    client.put(`/composition-templates/${id}`, data).then(r => r.data),

  delete: (id: number) =>
    client.delete(`/composition-templates/${id}`).then(r => r.data),

  // Apply a template (with or without a parent node)
  apply: (templateId: number, parentNodeId?: number, name?: string) =>
    client.post(`/composition-templates/${templateId}/apply`, {
      parent_node_id: parentNodeId ?? null,
      name: name ?? '',
    }).then(r => r.data),
}

// ─── Clone equipment from a template ──────────────────────────────────────────

export const cloneApi = {
  cloneEquipment: (data: {
    equipment_template_id: number
    parent_node_id: number
    count: number
    name_prefix?: string
    start_number?: number
  }) => client.post('/factory/nodes/clone', data).then(r => r.data),
}
