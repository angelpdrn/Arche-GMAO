import axios from 'axios'
import type { RefreshResponse } from '@/types'

const client = axios.create({
  baseURL: '/api/v1',
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json'
  },
  withCredentials: true // send httpOnly cookies automatically
})

// Token held in memory (not localStorage)
let accessToken: string | null = null

export function setAccessToken(token: string | null) {
  accessToken = token
}

export function getAccessToken(): string | null {
  return accessToken
}

// ─── Request interceptor: inject the access token ───────────────────────────

client.interceptors.request.use((config) => {
  if (accessToken) {
    config.headers.Authorization = `Bearer ${accessToken}`
  }
  return config
})

// ─── Response interceptor: automatic refresh on 401 ─────────────────────

let refreshPromise: Promise<string> | null = null

let isLoggingOut = false

function logout() {
  if (isLoggingOut) return
  isLoggingOut = true
  accessToken = null
  window.location.href = '/login'
}

function doRefresh(): Promise<string> {
  if (refreshPromise) return refreshPromise

  refreshPromise = axios
    .post<RefreshResponse>('/api/v1/auth/refresh', {}, { withCredentials: true })
    .then((res) => {
      const newToken = res.data.access_token
      if (!newToken) throw new Error('Empty token in refresh response')
      accessToken = newToken
      return newToken
    })
    .catch((err) => {
      const isNetworkError = !err.response || err.code === 'ERR_NETWORK' || err.code === 'ECONNABORTED'
      if (isNetworkError && !navigator.onLine) {
        throw err
      }
      logout()
      throw err
    })
    .finally(() => {
      refreshPromise = null
    })

  return refreshPromise
}

client.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config

    if (error.response?.status !== 401 || originalRequest._retry) {
      return Promise.reject(error)
    }

    if (originalRequest.url?.includes('/auth/login') || originalRequest.url?.includes('/auth/refresh')) {
      return Promise.reject(error)
    }

    originalRequest._retry = true

    try {
      const token = await doRefresh()
      originalRequest.headers.Authorization = `Bearer ${token}`
      return client(originalRequest)
    } catch (refreshError) {
      return Promise.reject(refreshError)
    }
  }
)

/**
 * Downloads a binary file through the axios client so it benefits from
 * the automatic refresh on 401. When the server sends a Content-Disposition
 * filename it is honoured; otherwise the fallback is used.
 */
export async function downloadBlob(
  path: string,
  fallbackName: string,
  config: import('axios').AxiosRequestConfig = {}
): Promise<void> {
  const res = await client.get<Blob>(path, {
    ...config,
    responseType: 'blob'
  })
  const cd = (res.headers && (res.headers['content-disposition'] as string)) || ''
  const m = /filename="?([^";]+)"?/i.exec(cd)
  const filename = m?.[1] || fallbackName
  const url = URL.createObjectURL(res.data)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}

export default client
