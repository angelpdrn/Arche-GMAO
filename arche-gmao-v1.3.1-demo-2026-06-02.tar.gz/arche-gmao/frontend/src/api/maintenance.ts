import client from './client'

// ─── Types ───────────────────────────────────────────────────────────────────

export interface ChecklistItem {
  step: string
  required: boolean
}

export interface RequiredPart {
  spare_part_id?: number
  name: string
  code: string
  quantity: number
}

export interface MaintenancePlan {
  id: number
  node_id: number | null
  node_name: string | null
  node_code: string | null
  title: string
  description: string | null
  wo_type: string
  priority: string
  frequency_type: string
  frequency_value: number
  advance_days: number
  assigned_to: number | null
  assigned_name: string | null
  estimated_hours: number | null
  is_active: boolean
  last_executed_at: string | null
  next_due_at: string | null
  total_executions: number
  created_at: string
  days_until_due: number | null
  apply_to_children: boolean
  has_instructions: boolean
  checklist_count: number
  equipment_template_id: number | null
  template_manufacturer: string | null
  template_model: string | null
}

export interface MaintenancePlanDetail extends Omit<MaintenancePlan, 'has_instructions' | 'checklist_count' | 'days_until_due'> {
  instructions: string | null
  checklist: ChecklistItem[]
  safety_notes: string | null
  tools_required: string[]
  required_parts: RequiredPart[]
  source_template_id: number | null
}

export interface PlanExecution {
  id: number
  wo_id: number | null
  wo_number: string | null
  target_node_id: number | null
  target_node_name: string | null
  created_by: string | null
  notes: string | null
  executed_at: string
}

export interface PlanExclusion {
  id: number
  node_id: number
  node_name: string
  node_code: string | null
  excluded_by_name: string | null
  created_at: string
}

export interface EffectivePlan {
  id: number
  title: string
  description: string | null
  wo_type: string
  priority: string
  frequency_type: string
  frequency_value: number
  next_due_at: string | null
  is_active: boolean
  node_id: number | null
  source_node_name: string | null
  equipment_template_id: number | null
  manufacturer: string | null
  model: string | null
  apply_to_children: boolean
  plan_source: 'direct' | 'inherited' | 'template'
  is_excluded: boolean
  assigned_name: string | null
  has_instructions: boolean
  checklist_count: number
  tools_count: number
}

export interface MaintenancePlanTemplate {
  id: number
  name: string
  description: string | null
  wo_type: string
  priority: string
  frequency_type: string
  frequency_value: number
  advance_days: number
  estimated_hours: number | null
  instructions: string | null
  checklist: ChecklistItem[]
  safety_notes: string | null
  tools_required: string[]
  required_parts: RequiredPart[]
  apply_to_children: boolean
  created_at: string
}

export interface MaintenanceManual {
  id: number
  title: string
  description: string | null
  original_name: string
  mime_type: string | null
  file_size: number
  is_active: boolean
  uploaded_by: string | null
  created_at: string
}

// ─── Maintenance plans ─────────────────────────────────────────────────

export const maintenancePlansApi = {
  list(params?: { node_id?: number; active?: boolean }): Promise<{ plans: MaintenancePlan[]; total: number }> {
    return client.get('/maintenance-plans', { params }).then(r => r.data)
  },

  getOne(id: number): Promise<{ plan: MaintenancePlanDetail; executions: PlanExecution[]; exclusions: PlanExclusion[] }> {
    return client.get(`/maintenance-plans/${id}`).then(r => r.data)
  },

  create(data: Record<string, any>): Promise<{ id: number }> {
    return client.post('/maintenance-plans', data).then(r => r.data)
  },

  update(id: number, data: Record<string, any>): Promise<void> {
    return client.put(`/maintenance-plans/${id}`, data).then(() => {})
  },

  delete(id: number): Promise<void> {
    return client.delete(`/maintenance-plans/${id}`).then(() => {})
  },

  upcoming(): Promise<{ plans: any[] }> {
    return client.get('/maintenance-plans/upcoming').then(r => r.data)
  },

  compliance(): Promise<{
    total_plans: number
    active_plans: number
    overdue_count: number
    on_time_count: number
    compliance_rate: number
    last_month_executions: number
  }> {
    return client.get('/maintenance-plans/compliance').then(r => r.data)
  },

  execute(id: number): Promise<{ work_orders: any[]; total: number; next_due: string; message: string }> {
    return client.post(`/maintenance-plans/${id}/execute`).then(r => r.data)
  },

  effectivePlans(nodeId: number): Promise<{ plans: EffectivePlan[]; total: number }> {
    return client.get(`/maintenance-plans/effective/${nodeId}`).then(r => r.data)
  },

  addExclusion(planId: number, nodeId: number): Promise<void> {
    return client.post(`/maintenance-plans/${planId}/exclusions`, { node_id: nodeId }).then(() => {})
  },

  removeExclusion(planId: number, nodeId: number): Promise<void> {
    return client.delete(`/maintenance-plans/${planId}/exclusions/${nodeId}`).then(() => {})
  }
}

// ─── Maintenance plan templates ──────────────────────────────────

export const maintenancePlanTemplatesApi = {
  list(): Promise<{ templates: MaintenancePlanTemplate[]; total: number }> {
    return client.get('/maintenance-plan-templates').then(r => r.data)
  },

  getOne(id: number): Promise<{ template: MaintenancePlanTemplate }> {
    return client.get(`/maintenance-plan-templates/${id}`).then(r => r.data)
  },

  create(data: Partial<MaintenancePlanTemplate>): Promise<{ id: number }> {
    return client.post('/maintenance-plan-templates', data).then(r => r.data)
  },

  update(id: number, data: Partial<MaintenancePlanTemplate>): Promise<void> {
    return client.put(`/maintenance-plan-templates/${id}`, data).then(() => {})
  },

  delete(id: number): Promise<void> {
    return client.delete(`/maintenance-plan-templates/${id}`).then(() => {})
  },

  saveFromPlan(planId: number, name: string): Promise<{ id: number; message: string }> {
    return client.post(`/maintenance-plan-templates/from-plan/${planId}`, { name }).then(r => r.data)
  }
}

// ─── Maintenance manuals ───────────────────────────────────────────────

export const maintenanceManualsApi = {
  listByNode(nodeId: number): Promise<{ manuals: MaintenanceManual[]; total: number }> {
    return client.get(`/factory/nodes/${nodeId}/manuals`).then(r => r.data)
  },

  upload(nodeId: number, formData: FormData): Promise<{ id: number; title: string; message: string }> {
    return client.post(`/factory/nodes/${nodeId}/manuals/upload`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    }).then(r => r.data)
  },

  downloadUrl(nodeId: number, manualId: number): string {
    return `/api/v1/factory/nodes/${nodeId}/manuals/${manualId}/download`
  },

  update(nodeId: number, manualId: number, data: { title?: string; description?: string | null; is_active?: boolean }): Promise<void> {
    return client.put(`/factory/nodes/${nodeId}/manuals/${manualId}`, data).then(() => {})
  },

  delete(nodeId: number, manualId: number): Promise<void> {
    return client.delete(`/factory/nodes/${nodeId}/manuals/${manualId}`).then(() => {})
  }
}
