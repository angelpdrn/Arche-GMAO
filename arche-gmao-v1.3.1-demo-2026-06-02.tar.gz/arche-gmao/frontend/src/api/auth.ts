import client from './client'
import type { LoginRequest, LoginResponse, RefreshResponse, MeResponse } from '@/types'

export const authApi = {
  login(data: LoginRequest): Promise<LoginResponse> {
    return client.post<LoginResponse>('/auth/login', data).then((r) => r.data)
  },

  refresh(): Promise<RefreshResponse> {
    return client.post<RefreshResponse>('/auth/refresh', {}).then((r) => r.data)
  },

  logout(): Promise<void> {
    return client.post('/auth/logout').then(() => {})
  },

  me(): Promise<MeResponse> {
    return client.get<MeResponse>('/auth/me').then((r) => r.data)
  }
}
