import client from './client'

export interface MetricsSummary {
  total_wos: number
  corrective_wos: number
  preventive_wos: number
  completed_wos: number
  pending_wos: number
  overdue_wos: number
  avg_resolution_hours: number
  total_nodes: number
  critical_nodes: number
  low_stock_parts: number
  active_alerts: number
  verif_pending: number
  estimated_cost_mtto: number
}

export interface EquipmentMetric {
  node_id: number
  node_name: string
  node_code: string | null
  criticality: string
  node_type: string
  total_failures: number
  mttr_hours: number | null
  max_repair_hours: number | null
  mtbf_days: number | null
  availability_pct: number | null
}

export interface TrendPoint {
  month: string
  corrective: number
  preventive: number
  inspection: number
  predictive: number
  total: number
  avg_resolution_hours: number | null
}

export interface TechMetric {
  user_id: number
  full_name: string
  total_assigned: number
  completed: number
  corrective_count: number
  preventive_count: number
  avg_resolution_hours: number | null
  avg_total_hours: number | null
}

export interface SPMetric {
  id: number
  name: string
  code: string
  category: string
  unit: string
  current_stock: number
  min_stock: number
  unit_price: number | null
  consumed: number
  exits_count: number
  cost: number
  is_low_stock: boolean
}

export type Period = 'week' | 'month' | 'quarter' | 'year'

export const PERIOD_LABELS: Record<Period, string> = {
  week:    'Última semana',
  month:   'Último mes',
  quarter: 'Último trimestre',
  year:    'Último año',
}

export const metricsApi = {
  getSummary(period: Period = 'month', nodeId?: number | null): Promise<MetricsSummary> {
    const params: Record<string, any> = { period }
    if (nodeId) params.node_id = nodeId
    return client.get('/metrics/summary', { params }).then(r => r.data)
  },

  getEquipment(params?: { criticality?: string; limit?: number }): Promise<{
    metrics: EquipmentMetric[]
    total: number
  }> {
    return client.get('/metrics/equipment', { params }).then(r => r.data)
  },

  getTrends(months = 12): Promise<{ trends: TrendPoint[] }> {
    return client.get('/metrics/trends', { params: { months } }).then(r => r.data)
  },

  getTechnicians(period: Period = 'month', nodeId?: number | null): Promise<{ technicians: TechMetric[] }> {
    const params: Record<string, any> = { period }
    if (nodeId) params.node_id = nodeId
    return client.get('/metrics/technicians', { params }).then(r => r.data)
  },

  getSpareParts(period: Period = 'month'): Promise<{
    spare_parts: SPMetric[]
    total: number
    total_cost: number
  }> {
    return client.get('/metrics/spare-parts', { params: { period } }).then(r => r.data)
  },

  getCorrectiveRatio(period: Period = 'month', nodeId?: number | null): Promise<{
    ratios: any[]
    global_ratio: number
    global_corrective: number
    global_preventive: number
  }> {
    const params: Record<string, any> = { period }
    if (nodeId) params.node_id = nodeId
    return client.get('/metrics/corrective-ratio', { params }).then(r => r.data)
  },

  getAlertsSummary(): Promise<{
    alerts: any[]
    total: number
    critical: number
    high: number
  }> {
    return client.get('/metrics/alerts-summary').then(r => r.data)
  },

  getNodeMetrics(nodeId: number): Promise<any> {
    return client.get(`/factory/nodes/${nodeId}/metrics`).then(r => r.data)
  }
}
