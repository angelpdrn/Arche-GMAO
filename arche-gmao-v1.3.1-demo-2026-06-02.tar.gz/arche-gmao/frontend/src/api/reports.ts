// api/reports.ts
import client from './client'

export interface AIPattern {
  id: number
  node_id: number | null
  node_name: string | null
  node_code: string | null
  pattern_type: 'recurring_failure' | 'low_stock_risk' | 'overdue_preventive' | 'high_frequency'
  severity: 'low' | 'medium' | 'high' | 'critical'
  title: string
  description: string
  recommendation: string | null
  pattern_data: any
  detected_at: string
}

export const PATTERN_TYPE_LABELS: Record<string, string> = {
  recurring_failure:  'Fallo recurrente',
  low_stock_risk:     'Riesgo de stock',
  overdue_preventive: 'Preventiva vencida',
  high_frequency:     'Alta frecuencia',
}

export const patternsApi = {
  list(params?: { node_id?: number; severity?: string }): Promise<{
    patterns: AIPattern[]
    total: number
    summary: { critical: number; high: number; medium: number }
  }> {
    return client.get('/patterns', { params }).then(r => r.data)
  },

  detect(): Promise<{ message: string; patterns_created: number }> {
    return client.post('/patterns/detect').then(r => r.data)
  },

  acknowledge(id: number): Promise<void> {
    return client.patch(`/patterns/${id}/acknowledge`).then(() => {})
  },

  getNodePatterns(nodeId: number): Promise<{ patterns: AIPattern[]; total: number }> {
    return client.get(`/factory/nodes/${nodeId}/patterns`).then(r => r.data)
  }
}

// api/reports.ts
export const reportsApi = {
  getWOExportOptions(woId: number) {
    return [
      {
        format: 'html',
        label: 'Informe PDF',
        description: 'Informe completo para imprimir',
        icon: '▤',
        url: `/api/v1/reports/wo/${woId}/html`,
        filename: `informe-ot-${woId}.html`,
      },
    ]
  },

  getInventoryExportOptions() {
    return [
      {
        format: 'excel',
        label: 'Inventario Excel',
        description: 'Todos los repuestos con stock y movimientos',
        icon: '▦',
        url: `/api/v1/reports/spare-parts/excel`,
        filename: `inventario-repuestos.xlsx`,
      },
    ]
  },

  getWOsExportOptions(params?: { status?: string; type?: string }) {
    const query = params
      ? '?' + Object.entries(params).filter(([,v]) => v).map(([k,v]) => `${k}=${v}`).join('&')
      : ''
    return [
      {
        format: 'excel',
        label: 'Exportar a Excel',
        description: 'Listado de OTs con filtros aplicados',
        icon: '▦',
        url: `/api/v1/reports/work-orders/excel${query}`,
        filename: `ordenes-trabajo.xlsx`,
      },
    ]
  }
}
