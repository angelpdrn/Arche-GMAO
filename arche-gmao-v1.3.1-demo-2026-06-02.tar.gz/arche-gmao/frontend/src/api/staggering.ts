import client from './client'

// ─── Types ───────────────────────────────────────────────────────────────────

export interface StaggeringConfig {
  id: number
  scope: 'global' | 'area' | 'line'
  scope_node_id: number | null
  scope_node_name: string | null
  period: 'weekly' | 'biweekly' | 'monthly'
  max_daily_per_tech: number
  is_active: boolean
  created_at: string
}

export interface StaggeringConfigPayload {
  id?: number
  scope: string
  scope_node_id: number | null
  period: string
  max_daily_per_tech: number
  is_active: boolean
}

export interface ScheduleEntry {
  plan_id: number
  plan_title: string
  node_id: number
  node_name: string
  node_code: string
  criticality: string
  technician_id: number | null
  technician_name: string
  scheduled_date: string
  priority: string
}

export interface SchedulePreview {
  cycle_start: string
  cycle_end: string
  total_planned: number
  entries: ScheduleEntry[]
  daily_load: Record<string, number>
  max_daily_per_tech: number
}

export interface StaggeringCycle {
  id: number
  config_id: number
  scope: string
  period: string
  cycle_start: string
  cycle_end: string
  total_planned: number
  total_executed: number
  total_rescheduled: number
  compliance_pct: number
  status: string
  created_at: string
}

export interface ScheduleData {
  cycle: {
    id: number
    config_id: number
    cycle_start: string
    cycle_end: string
    total_planned: number
    total_executed: number
    total_rescheduled: number
    status: string
  } | null
  entries: Array<{
    id: number
    plan_id: number
    plan_title: string
    node_id: number
    node_name: string
    node_code: string
    criticality: string
    scheduled_date: string
    technician_id: number | null
    technician_name: string
    status: string
    rescheduled_from: string | null
    wo_id: number | null
  }>
}

// ─── API ─────────────────────────────────────────────────────────────────────

export const staggeringApi = {
  getConfig(): Promise<{ configs: StaggeringConfig[] }> {
    return client.get('/maintenance/staggering/config').then(r => r.data)
  },

  updateConfig(payload: StaggeringConfigPayload): Promise<{ id: number; message: string }> {
    return client.put('/maintenance/staggering/config', payload).then(r => r.data)
  },

  preview(configId: number): Promise<SchedulePreview> {
    return client.post('/maintenance/staggering/preview', { config_id: configId }).then(r => r.data)
  },

  apply(configId: number): Promise<{ cycle_id: number; message: string }> {
    return client.post('/maintenance/staggering/apply', { config_id: configId }).then(r => r.data)
  },

  getSchedule(cycleId?: number): Promise<ScheduleData> {
    const params = cycleId ? { cycle_id: cycleId } : {}
    return client.get('/maintenance/staggering/schedule', { params }).then(r => r.data)
  },

  listCycles(): Promise<{ cycles: StaggeringCycle[] }> {
    return client.get('/maintenance/staggering/cycles').then(r => r.data)
  },
}
