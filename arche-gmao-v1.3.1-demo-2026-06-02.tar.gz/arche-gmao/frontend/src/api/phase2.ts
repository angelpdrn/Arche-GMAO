import client from './client'
import type { WorkOrder, WOStatus } from '@/types/workorders'
import type { SparePart } from '@/types/inventory'

// ─── Work Orders ─────────────────────────────────────────────────────────────

export const workOrdersApi = {
  list(params?: Record<string, string | number | undefined>) {
    return client.get<{ work_orders: WorkOrder[]; total: number }>('/work-orders', { params }).then(r => r.data)
  },
  getOne(id: number) {
    return client.get(`/work-orders/${id}`).then(r => r.data)
  },
  create(data: Partial<WorkOrder> & { node_id: number; title: string }) {
    return client.post<{ id: number; wo_number: string }>('/work-orders', data).then(r => r.data)
  },
  update(id: number, data: Partial<WorkOrder>) {
    return client.put(`/work-orders/${id}`, data).then(r => r.data)
  },
  changeStatus(id: number, data: { status: WOStatus; comment?: string; actual_hours?: number; root_cause?: string; solution?: string; version: number }) {
    return client.patch(`/work-orders/${id}/status`, data).then(r => r.data)
  },
  addComment(id: number, content: string) {
    return client.post(`/work-orders/${id}/comments`, { content }).then(r => r.data)
  },
  offlineBundle() {
    return client.get<{ work_orders: Array<WorkOrder & { comments: unknown[]; log: unknown[] }>; total: number }>('/work-orders/offline-bundle').then(r => r.data)
  }
}

// ─── Spare Parts ─────────────────────────────────────────────────────────────

export const sparePartsApi = {
  list(params?: { category?: string; low_stock?: boolean; node_id?: number }) {
    return client.get<{ spare_parts: SparePart[]; total: number }>('/spare-parts', { params }).then(r => r.data)
  },
  getOne(id: number) {
    return client.get(`/spare-parts/${id}`).then(r => r.data)
  },
  create(data: Partial<SparePart>) {
    return client.post('/spare-parts', data).then(r => r.data)
  },
  update(id: number, data: Partial<SparePart>) {
    return client.put(`/spare-parts/${id}`, data).then(r => r.data)
  },
  addMovement(id: number, data: { movement_type: string; quantity: number; unit_cost?: number; notes?: string }) {
    return client.post(`/spare-parts/${id}/movements`, data).then(r => r.data)
  }
}

// ─── Users ────────────────────────────────────────────────────────────────────

export const usersApi = {
  list(params?: { role?: string; status?: string }) {
    return client.get('/users', { params }).then(r => r.data)
  },
  create(data: { email: string; password: string; full_name: string; role: string; home_node_id?: number }) {
    return client.post('/users', data).then(r => r.data)
  },
  update(id: number, data: { full_name: string; role: string; status: string; home_node_id?: number }) {
    return client.put(`/users/${id}`, data).then(r => r.data)
  },
  delete(id: number) {
    return client.delete(`/users/${id}`).then(r => r.data)
  },
  changeOwnPassword(id: number, currentPassword: string, newPassword: string) {
    return client.patch(`/users/${id}/change-password`, {
      current_password: currentPassword,
      new_password: newPassword
    }).then(r => r.data)
  }
}

// ─── Procedures (digital SOPs) ─────────────────────────────────────────────

import type { ProcedureTemplate, ProcedureTemplateDetail, ProcedureExecution, ProcedureSuggestion } from '@/types/procedures'
import type { NodeHealth, HealthHistoryEntry, HealthSummaryNode, HealthDistribution, HealthWeightConfig } from '@/types/health'

export const proceduresApi = {
  list(params?: { category?: string; active?: string }) {
    return client.get<{ procedures: ProcedureTemplate[]; total: number }>('/procedures', { params }).then(r => r.data)
  },
  getOne(id: number) {
    return client.get<ProcedureTemplateDetail>(`/procedures/${id}`).then(r => r.data)
  },
  create(data: { title: string; description?: string; category?: string; node_type_target?: string; steps: unknown[] }) {
    return client.post<{ id: number; step_count: number }>('/procedures', data).then(r => r.data)
  },
  update(id: number, data: { title: string; description?: string; category?: string; node_type_target?: string; is_active?: boolean; steps?: unknown[] }) {
    return client.put(`/procedures/${id}`, data).then(r => r.data)
  },
  delete(id: number) {
    return client.delete(`/procedures/${id}`).then(r => r.data)
  },
  link(id: number, data: { maintenance_plan_id?: number; node_id?: number; wo_type?: string }) {
    return client.post(`/procedures/${id}/link`, data).then(r => r.data)
  },
  unlink(id: number, linkId: number) {
    return client.delete(`/procedures/${id}/link/${linkId}`).then(r => r.data)
  },
  startExecution(id: number, data: { wo_id?: number; node_id?: number }) {
    return client.post<{ execution_id: number; total_steps: number }>(`/procedures/${id}/execute`, data).then(r => r.data)
  },
  getExecution(execId: number) {
    return client.get<ProcedureExecution>(`/procedures/executions/${execId}`).then(r => r.data)
  },
  submitStep(execId: number, stepId: number, data: Record<string, unknown>) {
    return client.post<{ success: boolean; out_of_range: boolean; completed_steps: number }>(`/procedures/executions/${execId}/steps/${stepId}`, data).then(r => r.data)
  },
  completeExecution(execId: number, notes?: string) {
    return client.post(`/procedures/executions/${execId}/complete`, { notes }).then(r => r.data)
  },
  getWOProcedures(woId: number) {
    return client.get<{ procedures: ProcedureExecution[] }>(`/work-orders/${woId}/procedures`).then(r => r.data)
  },
  suggest(params: { node_id?: number; wo_type?: string }) {
    return client.get<{ suggestions: ProcedureSuggestion[] }>('/procedures/suggest', { params }).then(r => r.data)
  },
}

// ─── Equipment Health Score ─────────────────────────────────────────────────

export const healthApi = {
  getNodeHealth(nodeId: number) {
    return client.get<NodeHealth>(`/factory/nodes/${nodeId}/health`).then(r => r.data)
  },
  getHistory(nodeId: number, days?: number) {
    return client.get<{ node_id: number; history: HealthHistoryEntry[] }>(`/factory/nodes/${nodeId}/health/history`, { params: { days } }).then(r => r.data)
  },
  getSummary() {
    return client.get<{ nodes: HealthSummaryNode[]; total: number; distribution: HealthDistribution }>('/factory/health/summary').then(r => r.data)
  },
  recalculate() {
    return client.post<{ recalculated: number }>('/factory/health/recalculate').then(r => r.data)
  },
  getWeights() {
    return client.get<{ configs: HealthWeightConfig[] }>('/factory/health/weights').then(r => r.data)
  },
  updateWeights(nodeType: string, data: { weights: Record<string, number>; expected_life_years?: number; decay_per_day?: number }) {
    return client.put(`/factory/health/weights/${nodeType}`, data).then(r => r.data)
  },
}
