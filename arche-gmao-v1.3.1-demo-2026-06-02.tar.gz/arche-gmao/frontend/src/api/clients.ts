import client from './client'
import type { Client } from '@/types/factory'

export const clientsApi = {
  list(): Promise<{ clients: Client[]; total: number }> {
    return client.get('/clients/').then((r) => r.data)
  },

  create(data: Partial<Client>): Promise<{ id: number }> {
    return client.post('/clients/', data).then((r) => r.data)
  },

  update(id: number, data: Partial<Client>): Promise<void> {
    return client.put(`/clients/${id}`, data).then(() => {})
  },

  delete(id: number): Promise<void> {
    return client.delete(`/clients/${id}`).then(() => {})
  }
}
