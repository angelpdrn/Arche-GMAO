import client from './client'

export interface Directory {
  id: number
  name: string
  section: DirectorySection
  parent_id: number | null
  is_public: boolean
  has_pin: boolean
  is_owner: boolean
  owner_name: string | null
  description: string | null
  color: string | null
  icon: string | null
  item_count: number
  children: Directory[]
}

export interface DirectoryItem {
  id: number
  item_id: number
  ref: string | null
  name: string
  status: string | null
  extra: string | null
}

export type DirectorySection =
  | 'work_orders'
  | 'spare_parts'
  | 'nodes'
  | 'history'
  | 'library'
  | 'personnel'

export interface CreateDirectoryData {
  name: string
  section: DirectorySection
  parent_id?: number
  is_public?: boolean
  access_pin?: string
  description?: string
  color?: string
  icon?: string
}

export interface UpdateDirectoryData {
  name: string
  is_public?: boolean
  access_pin?: string
  remove_pin?: boolean
  description?: string
  color?: string
  icon?: string
}

export const directoriesApi = {
  list(section: DirectorySection): Promise<{
    my_dirs: Directory[]
    public_dirs: Directory[]
    total: number
  }> {
    return client.get('/directories', { params: { section } }).then(r => r.data)
  },

  create(data: CreateDirectoryData): Promise<{ id: number }> {
    return client.post('/directories', data).then(r => r.data)
  },

  update(id: number, data: UpdateDirectoryData): Promise<void> {
    return client.put(`/directories/${id}`, data).then(() => {})
  },

  delete(id: number): Promise<void> {
    return client.delete(`/directories/${id}`).then(() => {})
  },

  verifyPin(id: number, pin: string): Promise<{ verified: boolean }> {
    return client.post(`/directories/${id}/verify-pin`, { pin }).then(r => r.data)
  },

  getItems(id: number): Promise<{ items: DirectoryItem[]; section: string; total: number }> {
    return client.get(`/directories/${id}/items`).then(r => r.data)
  },

  addItem(dirId: number, itemType: string, itemId: number): Promise<{ id: number }> {
    return client.post(`/directories/${dirId}/items`, { item_type: itemType, item_id: itemId }).then(r => r.data)
  },

  removeItem(itemId: number): Promise<void> {
    return client.delete(`/directories/items/${itemId}`).then(() => {})
  }
}

// ─── Visual configuration of the sections ───────────────────────────────────────

export const SECTION_CONFIG: Record<DirectorySection, { label: string; icon: string }> = {
  work_orders: { label: 'Órdenes de Trabajo', icon: '✦' },
  spare_parts:  { label: 'Repuestos',          icon: '◫' },
  nodes:        { label: 'Nodos',              icon: '◈' },
  history:      { label: 'Historial',          icon: '◷' },
  library:      { label: 'Biblioteca',         icon: '◉' },
  personnel:    { label: 'Personal',           icon: '◷' },
}

// Predefined folder colours
export const DIR_COLORS = [
  '#1A1A2E', '#0F3460', '#E94560', '#27AE60',
  '#F39C12', '#8B5CF6', '#3B82F6', '#EC4899',
]
