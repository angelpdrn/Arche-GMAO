import client from './client'
import type { FactoryNode, SearchResult, NodeFormData } from '@/types/factory'

export const nodesApi = {
  getTree(): Promise<{ nodes: FactoryNode[] }> {
    return client.get('/factory/tree').then((r) => r.data)
  },

  getOne(id: number): Promise<FactoryNode> {
    return client.get(`/factory/nodes/${id}`).then((r) => r.data)
  },

  getChildren(id: number): Promise<{ children: FactoryNode[]; total: number }> {
    return client.get(`/factory/nodes/${id}/children`).then((r) => r.data)
  },

  search(q: string): Promise<{ results: SearchResult[]; total: number }> {
    return client.get('/factory/search', { params: { q } }).then((r) => r.data)
  },

  create(data: NodeFormData): Promise<FactoryNode> {
    return client.post('/factory/nodes', data).then((r) => r.data)
  },

  update(id: number, data: NodeFormData): Promise<FactoryNode> {
    return client.put(`/factory/nodes/${id}`, data).then((r) => r.data)
  },

  delete(id: number): Promise<{ message: string }> {
    return client.delete(`/factory/nodes/${id}`).then((r) => r.data)
  },

  move(id: number, parentId: number | null, version?: number): Promise<FactoryNode> {
    return client.patch(`/factory/nodes/${id}/move`, { parent_id: parentId, version: version ?? 0 }).then((r) => r.data)
  }
}
