import { ref, onMounted, onUnmounted } from 'vue'

const SIDEBAR_WIDTH_KEY = 'arche-sidebar-width'
const SIDEBAR_COLLAPSED_KEY = 'arche-sidebar-collapsed'

const DEFAULT_WIDTH = 220
const MIN_WIDTH = 180
const MAX_WIDTH = 340
const COLLAPSED_WIDTH = 56

export function useSidebar() {
  const width = ref(DEFAULT_WIDTH)
  const collapsed = ref(false)
  const isResizing = ref(false)

  let activeMoveHandler: ((e: MouseEvent) => void) | null = null
  let activeUpHandler: (() => void) | null = null

  function load() {
    const savedWidth = localStorage.getItem(SIDEBAR_WIDTH_KEY)
    const savedCollapsed = localStorage.getItem(SIDEBAR_COLLAPSED_KEY)
    if (savedWidth) width.value = Math.min(MAX_WIDTH, Math.max(MIN_WIDTH, parseInt(savedWidth)))
    if (savedCollapsed) collapsed.value = savedCollapsed === 'true'
  }

  function toggle() {
    collapsed.value = !collapsed.value
    localStorage.setItem(SIDEBAR_COLLAPSED_KEY, String(collapsed.value))
  }

  function stopResize() {
    isResizing.value = false
    if (activeMoveHandler) document.removeEventListener('mousemove', activeMoveHandler)
    if (activeUpHandler) document.removeEventListener('mouseup', activeUpHandler)
    activeMoveHandler = null
    activeUpHandler = null
    document.body.style.userSelect = ''
    document.body.style.cursor = ''
  }

  function startResize(e: MouseEvent) {
    if (collapsed.value) return
    isResizing.value = true
    const startX = e.clientX
    const startWidth = width.value

    activeMoveHandler = (e: MouseEvent) => {
      const newWidth = startWidth + (e.clientX - startX)
      width.value = Math.min(MAX_WIDTH, Math.max(MIN_WIDTH, newWidth))
    }

    activeUpHandler = () => {
      localStorage.setItem(SIDEBAR_WIDTH_KEY, String(width.value))
      stopResize()
    }

    document.body.style.userSelect = 'none'
    document.body.style.cursor = 'col-resize'
    document.addEventListener('mousemove', activeMoveHandler)
    document.addEventListener('mouseup', activeUpHandler)
  }

  const currentWidth = () => collapsed.value ? COLLAPSED_WIDTH : width.value

  onMounted(load)
  onUnmounted(stopResize)

  return { width, collapsed, isResizing, toggle, startResize, currentWidth, COLLAPSED_WIDTH }
}
