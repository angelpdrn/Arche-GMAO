import { ref, computed, onMounted, onUnmounted } from 'vue'
import client from '@/api/client'
import { useAuthStore } from '@/stores/auth'

export interface ActiveWO {
  id: number
  wo_number: string
  title: string
  node_name: string
  status: string
  assigned_to: number
  started_at: string | null
}

const activeWO = ref<ActiveWO | null>(null)
const polling = ref(false)
let timer: number | undefined
const POLL_MS = 60_000  // 60 s — enough to keep the banner from going stale
let activeMounts = 0

async function fetchActive() {
  const auth = useAuthStore()
  if (!auth.user || !auth.isOperational) {
    activeWO.value = null
    return
  }
  try {
    polling.value = true
    // We ask only for the user's in-progress WOs. List orders by created_at DESC,
    // so we take the first; with several, the technician still sees a single banner.
    const { data } = await client.get<{ work_orders: ActiveWO[] }>('/work-orders/', {
      params: { status: 'in_progress', assigned_to: auth.user.id },
    })
    const wos = data.work_orders ?? []
    activeWO.value = wos.length > 0 ? wos[0] : null
  } catch {
    // Silent: the banner is incidental and must not break the session
  } finally {
    polling.value = false
  }
}

export function useActiveWO() {
  // Time elapsed since started_at, recomputed every second in the template.
  const ticker = ref(Date.now())
  let tickInterval: number | undefined

  const elapsedMs = computed(() => {
    if (!activeWO.value?.started_at) return 0
    const started = new Date(activeWO.value.started_at).getTime()
    if (isNaN(started)) return 0
    return Math.max(0, ticker.value - started)
  })

  const elapsedLabel = computed(() => {
    const ms = elapsedMs.value
    if (!ms) return '—'
    const total = Math.floor(ms / 1000)
    const h = Math.floor(total / 3600)
    const m = Math.floor((total % 3600) / 60)
    const s = total % 60
    if (h > 0) return `${h}h ${m.toString().padStart(2, '0')}m`
    if (m > 0) return `${m}m ${s.toString().padStart(2, '0')}s`
    return `${s}s`
  })

  onMounted(() => {
    activeMounts++
    if (activeMounts === 1) {
      fetchActive()
      timer = window.setInterval(fetchActive, POLL_MS)
    }
    tickInterval = window.setInterval(() => { ticker.value = Date.now() }, 1000)
  })

  onUnmounted(() => {
    activeMounts--
    if (activeMounts <= 0 && timer) {
      window.clearInterval(timer)
      timer = undefined
    }
    if (tickInterval) window.clearInterval(tickInterval)
  })

  return {
    activeWO,
    elapsedMs,
    elapsedLabel,
    /** Force a manual refresh, e.g. after a state transition */
    refresh: fetchActive,
  }
}
