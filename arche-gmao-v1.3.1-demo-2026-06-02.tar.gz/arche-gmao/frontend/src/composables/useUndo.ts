import { useToast } from '@/composables/useToast'

/**
 * Helper for destructive actions with an "undo".
 *
 * Instead of a blocking confirm() that most users click through
 * blindly, we run the action straight away and show a toast with an
 * "Undo" button. When the user presses it before the TTL, we call undoFn.
 *
 * We do not use deferred soft-deletes: the action already took effect in the backend; the
 * "undo" is a complementary operation (e.g. status='active' after
 * status='inactive'). When the undo fails we show an error and the user
 * handles it as before.
 *
 * Typical use:
 *   await runWithUndo(
 *     () => api.deactivate(id),
 *     () => api.activate(id),
 *     `${nombre} desactivado`,
 *   )
 */
export interface UndoOpts {
  /** Main toast text. It appears next to the "Undo" button. */
  message: string
  /** Optional detail below the message. */
  detail?: string
  /** Time (ms) during which undo stays available. Default 6000. */
  ttl?: number
}

export async function runWithUndo<T>(
  action: () => Promise<T>,
  undo: () => Promise<unknown>,
  opts: UndoOpts,
): Promise<T> {
  const toast = useToast()
  const result = await action()
  toast.info(opts.message, {
    detail: opts.detail,
    ttl: opts.ttl ?? 6000,
    action: {
      label: 'Deshacer',
      handler: async () => {
        try {
          await undo()
          toast.success('Cambio revertido')
        } catch (err) {
          toast.fromError(err, 'No se pudo deshacer')
        }
      },
    },
  })
  return result
}
