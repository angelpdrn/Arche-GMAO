import { ref, onMounted, onUnmounted } from 'vue'

export function useResizablePanel(key: string, defaultWidth: number, min: number, max: number) {
  const width = ref(defaultWidth)
  const collapsed = ref(false)
  const isResizing = ref(false)

  const COLLAPSED_KEY = `arche-panel-collapsed-${key}`
  const WIDTH_KEY = `arche-panel-width-${key}`

  let activeMoveHandler: ((e: MouseEvent) => void) | null = null
  let activeUpHandler: (() => void) | null = null

  function load() {
    const w = localStorage.getItem(WIDTH_KEY)
    const c = localStorage.getItem(COLLAPSED_KEY)
    if (w) width.value = Math.min(max, Math.max(min, parseInt(w)))
    if (c) collapsed.value = c === 'true'
  }

  function toggle() {
    collapsed.value = !collapsed.value
    localStorage.setItem(COLLAPSED_KEY, String(collapsed.value))
  }

  function stopResize() {
    isResizing.value = false
    if (activeMoveHandler) document.removeEventListener('mousemove', activeMoveHandler)
    if (activeUpHandler) document.removeEventListener('mouseup', activeUpHandler)
    activeMoveHandler = null
    activeUpHandler = null
    document.body.style.userSelect = ''
    document.body.style.cursor = ''
  }

  function startResize(e: MouseEvent) {
    if (collapsed.value) return
    isResizing.value = true
    const startX = e.clientX
    const startW = width.value

    activeMoveHandler = (e: MouseEvent) => {
      width.value = Math.min(max, Math.max(min, startW + (e.clientX - startX)))
    }
    activeUpHandler = () => {
      localStorage.setItem(WIDTH_KEY, String(width.value))
      stopResize()
    }

    document.body.style.userSelect = 'none'
    document.body.style.cursor = 'col-resize'
    document.addEventListener('mousemove', activeMoveHandler)
    document.addEventListener('mouseup', activeUpHandler)
  }

  onMounted(load)
  onUnmounted(stopResize)

  return { width, collapsed, isResizing, toggle, startResize }
}
