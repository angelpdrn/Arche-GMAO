import { ref, onMounted, onUnmounted } from 'vue'

const MOBILE_BREAKPOINT = 768

// Shared singleton — a single listener for the whole app
const isMobile = ref(false)
let listenerCount = 0

function check() {
  isMobile.value = window.innerWidth < MOBILE_BREAKPOINT
}

export function useIsMobile() {
  onMounted(() => {
    if (listenerCount === 0) {
      check()
      window.addEventListener('resize', check)
    }
    listenerCount++
  })

  onUnmounted(() => {
    listenerCount--
    if (listenerCount === 0) {
      window.removeEventListener('resize', check)
    }
  })

  return isMobile
}
