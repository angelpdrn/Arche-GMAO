import { reactive } from 'vue'

export type ToastType = 'success' | 'error' | 'warning' | 'info'

export interface Toast {
  id: number
  type: ToastType
  message: string
  /** Optional: extra detail (shown below in grey) */
  detail?: string
  /** Optional action with a label (e.g. "Undo") */
  action?: {
    label: string
    handler: () => void | Promise<void>
  }
  /** Time in ms; 0 = no auto-dismiss */
  ttl: number
}

const state = reactive({
  toasts: [] as Toast[],
})

let nextId = 1
const DEFAULT_TTL: Record<ToastType, number> = {
  success: 3500,
  info: 4000,
  warning: 5000,
  error: 6000,
}

function push(type: ToastType, message: string, opts: Partial<Omit<Toast, 'id' | 'type' | 'message'>> = {}): number {
  const id = nextId++
  const ttl = opts.ttl ?? DEFAULT_TTL[type]
  const t: Toast = {
    id,
    type,
    message,
    detail: opts.detail,
    action: opts.action,
    ttl,
  }
  state.toasts.push(t)
  if (ttl > 0) {
    setTimeout(() => dismiss(id), ttl)
  }
  return id
}

function dismiss(id: number) {
  const idx = state.toasts.findIndex(t => t.id === id)
  if (idx !== -1) state.toasts.splice(idx, 1)
}

/**
 * Extracts a readable message from an axios error or any exception.
 * Handy for `toast.fromError(err)` inside catch blocks.
 */
function fromError(err: unknown, fallback = 'Ha ocurrido un error inesperado'): string {
  if (!err) return fallback
  if (typeof err === 'string') return err
  if (typeof err === 'object' && err !== null) {
    const e = err as Record<string, unknown>
    const resp = e.response as Record<string, unknown> | undefined
    const data = resp?.data as Record<string, unknown> | undefined
    if (typeof data?.error === 'string' && data.error.trim()) return data.error
    if (typeof e.message === 'string' && e.message.trim()) return e.message
  }
  return fallback
}

export function apiErrorMsg(err: unknown, fallback = 'Error'): string {
  return fromError(err, fallback)
}

export function useToast() {
  return {
    toasts: state.toasts,
    success: (msg: string, opts?: Partial<Toast>) => push('success', msg, opts),
    error:   (msg: string, opts?: Partial<Toast>) => push('error',   msg, opts),
    warning: (msg: string, opts?: Partial<Toast>) => push('warning', msg, opts),
    info:    (msg: string, opts?: Partial<Toast>) => push('info',    msg, opts),
    /** Error toast built from an Error/AxiosError */
    fromError: (err: unknown, fallback?: string, opts?: Partial<Toast>) =>
      push('error', fromError(err, fallback), opts),
    dismiss,
  }
}
