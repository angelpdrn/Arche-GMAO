import { computed } from 'vue'
import { storeToRefs } from 'pinia'
import { useOfflineStore } from '@/stores/offline'
import { useAuthStore } from '@/stores/auth'

export function useOffline() {
  const offlineStore = useOfflineStore()
  const authStore = useAuthStore()

  const { isOnline, pendingCount, lastSync, syncing, syncError, cacheAge } = storeToRefs(offlineStore)

  const hasPending = computed(() => pendingCount.value > 0)

  const canWrite = computed(() => {
    if (authStore.systemPaused && !authStore.isPrimaryAdmin && !authStore.isSuperadmin) return false
    return true
  })

  return {
    isOnline,
    pendingCount,
    hasPending,
    lastSync,
    syncing,
    syncError,
    cacheAge,
    canWrite,
  }
}
