import { onMounted, onBeforeUnmount, reactive } from 'vue'

/**
 * Keyboard shortcut system.
 *
 * - registerShortcut(key, fn, opts) registers a handler with automatic cleanup
 *   when the component unmounts.
 * - Keys are ignored while the user is typing in an input,
 *   textarea or contenteditable element, unless allowInForm is set.
 * - The central registry makes it possible to show a cheatsheet with `?`.
 */

export interface ShortcutInfo {
  key: string             // e.g. "n", "/", "?"
  description: string     // text for the cheatsheet
  scope?: string          // e.g. "Work orders"; empty = global
  allowInForm?: boolean   // let it fire even when the focus is in an input
}

interface RegisteredShortcut extends ShortcutInfo {
  id: number
  handler: (e: KeyboardEvent) => void
}

const state = reactive({
  shortcuts: [] as RegisteredShortcut[],
  cheatsheetOpen: false,
})

let nextId = 1

function isEditingTarget(t: EventTarget | null): boolean {
  if (!(t instanceof HTMLElement)) return false
  const tag = t.tagName
  if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return true
  if (t.isContentEditable) return true
  return false
}

function normalizeKey(e: KeyboardEvent): string {
  // Modifiers before the key, in order: ctrl/cmd → alt → shift → key
  const parts: string[] = []
  if (e.ctrlKey || e.metaKey) parts.push('mod')
  if (e.altKey) parts.push('alt')
  if (e.shiftKey && e.key.length > 1) parts.push('shift')  // shift+letter is already reflected in e.key
  parts.push(e.key.toLowerCase())
  return parts.join('+')
}

function onKeydown(e: KeyboardEvent) {
  const k = normalizeKey(e)
  const editing = isEditingTarget(e.target)

  for (const s of state.shortcuts) {
    // The registry accepts variants: "n" matches "n", and "shift+n" does not.
    if (s.key !== k) continue
    if (editing && !s.allowInForm) continue
    e.preventDefault()
    s.handler(e)
    return
  }

  // ? opens the cheatsheet — a reserved shortcut
  if (!editing && (k === 'shift+?' || k === '?')) {
    state.cheatsheetOpen = true
    e.preventDefault()
  }
  // Esc closes the cheatsheet
  if (k === 'escape' && state.cheatsheetOpen) {
    state.cheatsheetOpen = false
    e.preventDefault()
  }
}

let listenerAttached = false
let activeMounts = 0

export function useShortcuts() {
  onMounted(() => {
    activeMounts++
    if (!listenerAttached) {
      window.addEventListener('keydown', onKeydown)
      listenerAttached = true
    }
  })
  onBeforeUnmount(() => {
    activeMounts--
    if (activeMounts <= 0 && listenerAttached) {
      window.removeEventListener('keydown', onKeydown)
      listenerAttached = false
    }
  })

  /**
   * Registers a shortcut with automatic cleanup when the calling component unmounts.
   * Returns a manual unregister function when one is needed.
   */
  function registerShortcut(
    key: string,
    handler: (e: KeyboardEvent) => void,
    info: Omit<ShortcutInfo, 'key'>,
  ): () => void {
    const id = nextId++
    state.shortcuts.push({
      id,
      key: key.toLowerCase(),
      handler,
      description: info.description,
      scope: info.scope,
      allowInForm: info.allowInForm,
    })
    onBeforeUnmount(() => unregister(id))
    return () => unregister(id)
  }

  function unregister(id: number) {
    const idx = state.shortcuts.findIndex(s => s.id === id)
    if (idx !== -1) state.shortcuts.splice(idx, 1)
  }

  return {
    registerShortcut,
    cheatsheetOpen: () => state.cheatsheetOpen,
    shortcuts: state.shortcuts,
    closeCheatsheet: () => { state.cheatsheetOpen = false },
    openCheatsheet: () => { state.cheatsheetOpen = true },
  }
}

/** Reactive state exposed for the cheatsheet (no mount counting). */
export const shortcutsState = state
