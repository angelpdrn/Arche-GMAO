import { computed } from 'vue'
import { useAuthStore } from '@/stores/auth'

export function useSystemPause() {
  const authStore = useAuthStore()

  const isPaused = computed(() => authStore.systemPaused)

  // canWrite = false while the system is paused,
  // except for the primary admin and the superadmin, who can always write.
  const canWrite = computed(() =>
    !authStore.systemPaused || authStore.isPrimaryAdmin || authStore.isSuperadmin
  )

  return { isPaused, canWrite }
}
