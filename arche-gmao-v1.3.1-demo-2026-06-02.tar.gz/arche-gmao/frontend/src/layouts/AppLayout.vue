<template>
  <div class="app-layout" :style="{ '--current-sidebar-width': currentSidebarWidth + 'px' }">
    <!-- Mobile overlay -->
    <div v-if="sidebarOpen && isMobile" class="sidebar-overlay" @click="sidebarOpen = false"></div>

    <!-- ─── Sidebar ──────────────────────────────────────────────────────── -->
    <aside
      class="sidebar"
      :class="{
        'sidebar--collapsed': sidebar.collapsed.value && !isMobile,
        'sidebar--open': sidebarOpen && isMobile,
        'sidebar--resizing': sidebar.isResizing.value
      }"
      :style="!isMobile ? { width: currentSidebarWidth + 'px' } : {}"
    >
      <!-- Header -->
      <div class="sidebar-header">
        <div class="sidebar-brand-wrap">
          <span class="sidebar-logo">A</span>
          <div v-if="!sidebar.collapsed.value || isMobile" class="sidebar-brand">
            <span class="sidebar-brand-name">ARCHE</span>
            <span class="sidebar-brand-sub">System</span>
          </div>
        </div>
        <button class="sidebar-close-btn" v-if="isMobile" @click="sidebarOpen = false">✕</button>
        <button v-if="!isMobile" class="sidebar-collapse-btn-inline" @click="sidebar.toggle()" :title="sidebar.collapsed.value ? 'Expandir' : 'Colapsar'">
          {{ sidebar.collapsed.value ? '›' : '‹' }}
        </button>
      </div>

      <!-- Nav -->
      <nav class="sidebar-nav">
        <!-- General: every role -->
        <div class="nav-section">
          <span v-if="!sidebar.collapsed.value || isMobile" class="nav-section-label">General</span>
          <RouterLink to="/dashboard" class="nav-item" @click="closeSidebarMobile" :title="sidebar.collapsed.value ? 'Dashboard' : ''">
            <span class="nav-icon">▣</span>
            <span v-if="!sidebar.collapsed.value || isMobile" class="nav-label">Dashboard</span>
          </RouterLink>
          <RouterLink to="/calendar" class="nav-item" @click="closeSidebarMobile" :title="sidebar.collapsed.value ? 'Calendario' : ''">
            <span class="nav-icon">◷</span>
            <span v-if="!sidebar.collapsed.value || isMobile" class="nav-label">Calendario</span>
          </RouterLink>
        </div>

        <!-- Facilities: everyone sees Factory, only the admin sees Templates -->
        <div class="nav-section">
          <span v-if="!sidebar.collapsed.value || isMobile" class="nav-section-label">Instalaciones</span>
          <RouterLink to="/factory" class="nav-item" @click="closeSidebarMobile" :title="sidebar.collapsed.value ? 'Fábrica Virtual' : ''">
            <span class="nav-icon">◈</span>
            <span v-if="!sidebar.collapsed.value || isMobile" class="nav-label">Fábrica Virtual</span>
          </RouterLink>
          <RouterLink v-if="authStore.isAdmin && !isMobile" to="/templates" class="nav-item" @click="closeSidebarMobile" :title="sidebar.collapsed.value ? 'Plantillas' : ''">
            <span class="nav-icon">⧉</span>
            <span v-if="!sidebar.collapsed.value || isMobile" class="nav-label">Plantillas y Composiciones</span>
          </RouterLink>
        </div>

        <!-- Operations: everyone except the auditor -->
        <div v-if="authStore.isManager || authStore.isOperational || authStore.user?.role === 'warehouse'" class="nav-section">
          <span v-if="!sidebar.collapsed.value || isMobile" class="nav-section-label">Operaciones</span>
          <RouterLink to="/work-orders" class="nav-item" @click="closeSidebarMobile" :title="sidebar.collapsed.value ? 'Órdenes de Trabajo' : ''">
            <span class="nav-icon">✦</span>
            <span v-if="!sidebar.collapsed.value || isMobile" class="nav-label">Órdenes de Trabajo</span>
            <span v-if="pendingWOs > 0" class="nav-badge nav-badge--alert">{{ pendingWOs }}</span>
          </RouterLink>
          <RouterLink v-if="authStore.isManager && hasModule('preventive')" to="/maintenance-plans" class="nav-item" @click="closeSidebarMobile" :title="sidebar.collapsed.value ? 'Plan Preventivo' : ''">
            <span class="nav-icon">◉</span>
            <span v-if="!sidebar.collapsed.value || isMobile" class="nav-label">Plan Preventivo</span>
            <span v-if="overdueCount > 0" class="nav-badge nav-badge--alert">{{ overdueCount }}</span>
          </RouterLink>
          <RouterLink v-if="authStore.isManager && hasModule('preventive')" to="/procedures" class="nav-item" @click="closeSidebarMobile" :title="sidebar.collapsed.value ? 'Procedimientos' : ''">
            <span class="nav-icon">▣</span>
            <span v-if="!sidebar.collapsed.value || isMobile" class="nav-label">Procedimientos</span>
          </RouterLink>
          <RouterLink v-if="authStore.isManager || authStore.user?.role === 'warehouse'" to="/inventory" class="nav-item" @click="closeSidebarMobile" :title="sidebar.collapsed.value ? 'Inventario' : ''">
            <span class="nav-icon">◫</span>
            <span v-if="!sidebar.collapsed.value || isMobile" class="nav-label">Inventario</span>
            <span v-if="lowStock > 0" class="nav-badge nav-badge--warn">{{ lowStock }}</span>
          </RouterLink>
          <RouterLink to="/library" class="nav-item" @click="closeSidebarMobile" :title="sidebar.collapsed.value ? 'Biblioteca' : ''">
            <span class="nav-icon">▤</span>
            <span v-if="!sidebar.collapsed.value || isMobile" class="nav-label">Biblioteca</span>
          </RouterLink>
        </div>

        <!-- Library for the auditor (who does not see the Operations section) -->
        <div v-if="authStore.user?.role === 'auditor'" class="nav-section">
          <span v-if="!sidebar.collapsed.value || isMobile" class="nav-section-label">Documentacion</span>
          <RouterLink to="/library" class="nav-item" @click="closeSidebarMobile" :title="sidebar.collapsed.value ? 'Biblioteca' : ''">
            <span class="nav-icon">▤</span>
            <span v-if="!sidebar.collapsed.value || isMobile" class="nav-label">Biblioteca</span>
          </RouterLink>
        </div>

        <!-- Analysis: admin, supervisor and auditor -->
        <div v-if="(authStore.isManager || authStore.user?.role === 'auditor') && hasModule('metrics')" class="nav-section">
          <span v-if="!sidebar.collapsed.value || isMobile" class="nav-section-label">Análisis</span>
          <RouterLink to="/metrics" class="nav-item" @click="closeSidebarMobile" :title="sidebar.collapsed.value ? 'Métricas' : ''">
            <span class="nav-icon">▦</span>
            <span v-if="!sidebar.collapsed.value || isMobile" class="nav-label">Métricas y KPIs</span>
          </RouterLink>
        </div>

        <!-- Intelligence: AI for everyone, admin tools for the admin only -->
        <div v-if="hasModule('ai')" class="nav-section">
          <span v-if="!sidebar.collapsed.value || isMobile" class="nav-section-label">Inteligencia</span>
          <RouterLink to="/ai" class="nav-item" @click="closeSidebarMobile" :title="sidebar.collapsed.value ? 'Arché IA' : ''">
            <span class="nav-icon">◬</span>
            <span v-if="!sidebar.collapsed.value || isMobile" class="nav-label">Arché IA</span>
            <span class="ai-dot" :class="aiOnline ? 'ai-dot--on' : 'ai-dot--off'"></span>
          </RouterLink>
          <RouterLink v-if="authStore.isAdmin && !isMobile" to="/ai/admin" class="nav-item" @click="closeSidebarMobile" :title="sidebar.collapsed.value ? 'Admin IA' : ''">
            <span class="nav-icon">⚙</span>
            <span v-if="!sidebar.collapsed.value || isMobile" class="nav-label">Admin IA</span>
          </RouterLink>
        </div>

        <!-- Administration: admin only, desktop only -->
        <div v-if="authStore.isAdmin && !isMobile" class="nav-section">
          <span v-if="!sidebar.collapsed.value || isMobile" class="nav-section-label">Administracion</span>
          <RouterLink to="/users" class="nav-item" @click="closeSidebarMobile" :title="sidebar.collapsed.value ? 'Usuarios' : ''">
            <span class="nav-icon">◷</span>
            <span v-if="!sidebar.collapsed.value || isMobile" class="nav-label">Usuarios</span>
          </RouterLink>
          <RouterLink to="/clients" class="nav-item" @click="closeSidebarMobile" :title="sidebar.collapsed.value ? 'Clientes' : ''">
            <span class="nav-icon">◆</span>
            <span v-if="!sidebar.collapsed.value || isMobile" class="nav-label">Clientes</span>
          </RouterLink>
          <RouterLink to="/import" class="nav-item" @click="closeSidebarMobile" :title="sidebar.collapsed.value ? 'Importacion' : ''">
            <span class="nav-icon">↓</span>
            <span v-if="!sidebar.collapsed.value || isMobile" class="nav-label">Importacion</span>
          </RouterLink>
        </div>
      </nav>

      <!-- Footer -->
      <div class="sidebar-footer">
        <!-- Install app button — shown only when it is not installed -->
        <button
          v-if="showInstallBtn && (!sidebar.collapsed.value || isMobile)"
          class="install-app-btn"
          @click="triggerInstall"
        >
          <span class="nav-icon">↓</span>
          <span class="nav-label">Instalar App</span>
        </button>
        <button
          v-else-if="showInstallBtn && sidebar.collapsed.value"
          class="install-app-btn install-app-btn--mini"
          @click="triggerInstall"
          title="Instalar App"
        >
          <span class="nav-icon">↓</span>
        </button>

        <div class="sidebar-footer-row">
          <RouterLink v-if="!sidebar.collapsed.value || isMobile" class="sidebar-user sidebar-user--link" :to="`/users/${authStore.user?.id}/profile`">
            <div class="user-avatar">{{ userInitials }}</div>
            <div class="user-info">
              <span class="user-name">{{ authStore.user?.full_name }}</span>
              <span class="user-role">{{ roleLabel }}</span>
            </div>
          </RouterLink>
          <RouterLink v-else class="sidebar-user-mini sidebar-user--link" :to="`/users/${authStore.user?.id}/profile`">
            <div class="user-avatar" :title="authStore.user?.full_name">{{ userInitials }}</div>
          </RouterLink>
          <button class="logout-btn" @click="handleLogout" title="Cerrar sesión">⏻</button>
        </div>
      </div>

      <!-- Collapse button (desktop only) -->


      <!-- Resize handle (desktop only, not collapsed) -->
      <div
        v-if="!isMobile && !sidebar.collapsed.value"
        class="sidebar-resize-handle"
        @mousedown="sidebar.startResize"
        title="Arrastra para redimensionar"
      ></div>
    </aside>

    <!-- ─── Main content ───────────────────────────────────────────── -->
    <div class="main-wrap" :style="!isMobile ? { marginLeft: currentSidebarWidth + 'px' } : {}">
      <header class="app-header">
        <button v-if="isMobile" class="hamburger-btn" @click="sidebarOpen = true">
          <span></span><span></span><span></span>
        </button>
        <div class="header-breadcrumb">
          <span class="breadcrumb-app">Arche</span>
          <span class="breadcrumb-sep">›</span>
          <span class="breadcrumb-current">{{ currentPageTitle }}</span>
        </div>
        <div class="header-right">
          <!-- Offline indicator -->
          <div v-if="!offlineStore.isOnline" class="offline-pill" title="Sin conexión">
            Offline
            <span v-if="offlineStore.pendingCount > 0" class="offline-pending-count">{{ offlineStore.pendingCount }}</span>
          </div>
          <div v-if="offlineStore.isOnline && offlineStore.syncing" class="sync-pill" title="Sincronizando cambios offline">Sincronizando...</div>
          <div v-if="offlineStore.isOnline && offlineStore.pendingCount > 0 && !offlineStore.syncing" class="sync-pill sync-pill--pending" title="Cambios pendientes de sincronizar">{{ offlineStore.pendingCount }} pendiente{{ offlineStore.pendingCount > 1 ? 's' : '' }}</div>
          <NotificationBell />
        </div>
      </header>

      <!-- Pause mode banner -->
      <SystemPauseBanner v-if="authStore.systemPaused" />

      <!-- Offline banner -->
      <OfflineBanner />

      <!-- In-progress WO banner (shown only when the user has one in_progress) -->
      <ActiveWOBanner />

      <main class="app-main">
        <RouterView />
      </main>
    </div>

    <!-- Failed operations panel -->
    <FailedOpsPanel />

    <!-- Mobile FAB -->
    <button v-if="isMobile && authStore.user?.role !== 'auditor'" class="mobile-fab" @click="showReportModal = true">
      <span>⚠</span>
    </button>

    <!-- Quick report modal -->
    <MobileReportModal :open="showReportModal" @close="showReportModal = false" @created="() => {}" />

    <!-- PWA Install Prompt (auto-popup) -->
    <InstallPrompt ref="installPromptRef" />

    <!-- Global host for toast notifications -->
    <ToastHost />

    <!-- Shortcut cheatsheet (opened with "?") -->
    <ShortcutsCheatsheet />

    <!-- Command palette (Cmd/Ctrl + K) -->
    <CommandPalette />

    <!-- Installation instructions modal (from the sidebar button) -->
    <Teleport to="body">
      <div v-if="showInstallModal" class="install-modal-overlay" @click.self="closeInstallModal">
        <div class="install-modal">
          <div class="install-modal-header">
            <div class="install-modal-icon"><svg width="24" height="24" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M 256 100 L 372 400 L 334 400 L 303 282 L 209 282 L 178 400 L 140 400 Z M 256 190 L 224 258 L 288 258 Z" fill="#FFFFFF" fill-rule="evenodd"/></svg></div>
            <div>
              <h3 class="install-modal-title">Instalar Arche GMAO</h3>
              <p class="install-modal-sub">Acceso directo desde tu {{ installPlatform === 'ios' ? 'pantalla de inicio' : 'escritorio' }}</p>
            </div>
          </div>

          <!-- Chrome/Edge -->
          <template v-if="installPlatform === 'chrome'">
            <div class="install-modal-steps">
              <div class="install-step">
                <span class="install-step-num">1</span>
                <span>Haz click en el icono <strong>&#8942;</strong> (tres puntos verticales) arriba a la derecha del navegador</span>
              </div>
              <div class="install-step">
                <span class="install-step-num">2</span>
                <span>Selecciona <strong>"Instalar Arche GMAO..."</strong> o <strong>"Guardar y compartir" > "Instalar"</strong></span>
              </div>
              <div class="install-step">
                <span class="install-step-num">3</span>
                <span>Confirma pulsando <strong>"Instalar"</strong></span>
              </div>
            </div>
            <p class="install-modal-note">La app se abrira como ventana independiente con icono en tu escritorio.</p>
          </template>

          <!-- iOS Safari -->
          <template v-else-if="installPlatform === 'ios'">
            <div class="install-modal-steps">
              <div class="install-step">
                <span class="install-step-num">1</span>
                <span>Pulsa el boton <strong>Compartir</strong> <span style="color:#007AFF;font-weight:700">&#x2B06;</span> en la barra de Safari</span>
              </div>
              <div class="install-step">
                <span class="install-step-num">2</span>
                <span>Desplaza y selecciona <strong>"Anadir a pantalla de inicio"</strong></span>
              </div>
              <div class="install-step">
                <span class="install-step-num">3</span>
                <span>Pulsa <strong>"Anadir"</strong></span>
              </div>
            </div>
          </template>

          <!-- Other -->
          <template v-else>
            <p class="install-modal-note">Abre esta pagina en <strong>Google Chrome</strong> o <strong>Safari</strong> para instalar la app.</p>
          </template>

          <button class="install-modal-close" @click="closeInstallModal">Entendido</button>
        </div>
      </div>
    </Teleport>

    <ChatWidget v-if="hasModule('ai')" />
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { useAIStore } from '@/stores/ai'
import { useOfflineStore } from '@/stores/offline'
import { useSidebar } from '@/composables/useSidebar'
import { useIsMobile } from '@/composables/useIsMobile'
import NotificationBell from '@/components/notifications/NotificationBell.vue'
import MobileReportModal from '@/components/mobile/MobileReportModal.vue'
import OfflineBanner from '@/components/layout/OfflineBanner.vue'
import ToastHost from '@/components/layout/ToastHost.vue'
import ActiveWOBanner from '@/components/layout/ActiveWOBanner.vue'
import ShortcutsCheatsheet from '@/components/layout/ShortcutsCheatsheet.vue'
import CommandPalette from '@/components/layout/CommandPalette.vue'
import { useShortcuts } from '@/composables/useShortcuts'

// Turn on the global shortcut listener for the whole app and register
// the implicit "?" shortcut (handled by useShortcuts).
useShortcuts()
import FailedOpsPanel from '@/components/layout/FailedOpsPanel.vue'
import SystemPauseBanner from '@/components/layout/SystemPauseBanner.vue'
import ChatWidget from '@/components/ai/ChatWidget.vue'
import InstallPrompt from '@/components/layout/InstallPrompt.vue'
import client from '@/api/client'
import { systemApi, type LicenseInfo } from '@/api/system'
import { ROLE_LABELS } from '@/types'

const authStore    = useAuthStore()
const aiStore      = useAIStore()
const offlineStore = useOfflineStore()
const sidebar      = useSidebar()
const router       = useRouter()
const route        = useRoute()

const pendingWOs      = ref(0)
const lowStock        = ref(0)
const pendingVerif    = ref(0) // legacy, no longer used
const overdueCount    = ref(0)
const sidebarOpen     = ref(false)
const showReportModal = ref(false)
const showInstallBtn  = ref(false)
const isMobile        = useIsMobile()
let pushTimer: number | undefined
let deferredInstallPrompt: any = null

const licenseInfo = ref<LicenseInfo>({ modules: ['all'], max_users: 0, max_nodes: 0, days_left: 9999 })
const hasModule = (mod: string) => licenseInfo.value.modules.includes(mod) || licenseInfo.value.modules.includes('all')

const aiOnline = computed(() => aiStore.status?.ollama_available ?? false)

const currentSidebarWidth = computed(() =>
  sidebar.collapsed.value ? sidebar.COLLAPSED_WIDTH : sidebar.width.value
)

const userInitials = computed(() => {
  const name = authStore.user?.full_name ?? ''
  return name.split(' ').slice(0, 2).map(w => w[0]?.toUpperCase() ?? '').join('')
})

const roleLabel = computed(() => ROLE_LABELS[authStore.user?.role ?? ''] ?? '')

const pageTitles: Record<string, string> = {
  '/dashboard': 'Dashboard', '/factory': 'Fábrica Virtual',
  '/templates': 'Plantillas', '/work-orders': 'Órdenes de Trabajo',
  '/maintenance-plans': 'Plan Preventivo', '/procedures': 'Procedimientos', '/inventory': 'Inventario', '/clients': 'Clientes',
  '/library': 'Biblioteca',
  '/calendar': 'Calendario', '/ai': 'Arché IA',
  '/metrics': 'Métricas y KPIs', '/users': 'Usuarios',
}
const currentPageTitle = computed(() => {
  if (route.path.match(/^\/users\/\d+\/profile$/)) return 'Perfil de usuario'
  return pageTitles[route.path] ?? 'Panel'
})

function closeSidebarMobile() { if (isMobile.value) sidebarOpen.value = false }
async function handleLogout() {
  if (offlineStore.pendingCount > 0) {
    const ok = confirm(`Tiene ${offlineStore.pendingCount} cambio(s) offline sin sincronizar. Si cierra sesión se perderán. ¿Continuar?`)
    if (!ok) return
  }
  offlineStore.cleanup()
  await offlineStore.clearAllData()
  aiStore.reset()
  await authStore.logout()
  router.push('/login')
}

// ─── PWA Install ────────────────────────────────────────────────────────────
const isStandalone = window.matchMedia('(display-mode: standalone)').matches
  || (navigator as any).standalone === true
const isSecureContext = window.isSecureContext

function handleBeforeInstall(e: Event) {
  e.preventDefault()
  deferredInstallPrompt = e
  showInstallBtn.value = true
}

const installPromptRef = ref<{ show: () => void } | null>(null)
const showInstallModal = ref(false)
const installPlatform = ref<'chrome' | 'ios' | 'other'>('other')

function triggerInstall() {
  if (deferredInstallPrompt) {
    // Chrome/Edge — direct native prompt
    deferredInstallPrompt.prompt()
    deferredInstallPrompt.userChoice.then(() => {
      deferredInstallPrompt = null
      showInstallBtn.value = false
    })
  } else {
    // iOS or fallback — manual instructions
    const ua = navigator.userAgent.toLowerCase()
    if (/iphone|ipad|ipod/.test(ua)) {
      installPlatform.value = 'ios'
    } else if (/chrome|edg/.test(ua)) {
      installPlatform.value = 'chrome'
    } else {
      installPlatform.value = 'other'
    }
    showInstallModal.value = true
  }
}

function closeInstallModal() {
  showInstallModal.value = false
}

// Listener for hiding the button once the app is installed
window.addEventListener('appinstalled', () => {
  showInstallBtn.value = false
  deferredInstallPrompt = null
})

// On iOS over HTTPS, show the button with manual instructions
if (!isStandalone && isSecureContext) {
  const ua = navigator.userAgent.toLowerCase()
  if (/iphone|ipad|ipod/.test(ua)) {
    showInstallBtn.value = true
  }
}

// Push notifications — secure context only (HTTPS in production)
async function requestPushPermission() {
  if (!isSecureContext) return
  if (!('Notification' in window) || !('serviceWorker' in navigator)) return
  if (Notification.permission === 'granted') return
  if (Notification.permission === 'denied') return

  const permission = await Notification.requestPermission()
  if (permission === 'granted') {
    subscribeToPush()
  }
}

async function subscribeToPush() {
  try {
    const reg = await navigator.serviceWorker.ready
    const { data } = await client.get('/push/vapid-public-key')
    const vapidKey = urlBase64ToUint8Array(data.public_key)

    const subscription = await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: vapidKey
    })

    await client.post('/push/subscribe', {
      endpoint: subscription.endpoint,
      keys: {
        p256dh: arrayBufferToBase64(subscription.getKey('p256dh')),
        auth: arrayBufferToBase64(subscription.getKey('auth'))
      },
      user_agent: navigator.userAgent
    })
  } catch { /* silent */ }
}

function urlBase64ToUint8Array(base64String: string) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4)
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/')
  const rawData = window.atob(base64)
  return new Uint8Array([...rawData].map(c => c.charCodeAt(0)))
}

function arrayBufferToBase64(buffer: ArrayBuffer | null): string {
  if (!buffer) return ''
  return btoa(String.fromCharCode(...new Uint8Array(buffer)))
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '')
}

onMounted(async () => {
  offlineStore.init()
  window.addEventListener('beforeinstallprompt', handleBeforeInstall)

  pushTimer = window.setTimeout(requestPushPermission, 5000)

  // Load the license info
  try { licenseInfo.value = await systemApi.getLicenseInfo() } catch { /* use the defaults */ }

  // Badges for admin, supervisor and warehouse
  if (authStore.isManager || authStore.user?.role === 'warehouse') {
    try {
      const [wos, stock, comp] = await Promise.all([
        client.get('/work-orders?status=pending'),
        client.get('/spare-parts?low_stock=true'),
        client.get('/maintenance-plans/compliance').catch(() => ({ data: null })),
      ])
      pendingWOs.value = wos.data.total ?? 0
      lowStock.value   = stock.data.total ?? 0
      overdueCount.value = comp.data?.overdue_count ?? 0
    } catch { /* silent */ }
  }
  await aiStore.loadStatus()
})

onUnmounted(() => {
  offlineStore.cleanup()
  window.removeEventListener('beforeinstallprompt', handleBeforeInstall)
  if (pushTimer) clearTimeout(pushTimer)
})
</script>

<style scoped>
.app-layout {
  display: flex; min-height: 100vh; background: var(--color-bg);
  --current-sidebar-width: 220px;
}

/* ─── Sidebar ────────────────────────────────────────────────────────────── */
.sidebar {
  width: var(--current-sidebar-width);
  flex-shrink: 0; background: var(--color-primary);
  display: flex; flex-direction: column;
  position: fixed; top: 0; left: 0; bottom: 0;
  z-index: 200; transition: width 0.2s ease;
  overflow: hidden;
}
.sidebar--collapsed { width: 56px !important; }
.sidebar--resizing { transition: none !important; user-select: none; }

.sidebar-header { display: flex; align-items: center; justify-content: space-between; padding: var(--space-4) var(--space-4); border-bottom: 1px solid rgba(255,255,255,0.08); height: var(--header-height); flex-shrink: 0; }
.sidebar-brand-wrap { display: flex; align-items: center; gap: var(--space-3); min-width: 0; overflow: hidden; }
.sidebar-logo { font-family: var(--font-mono); font-size: 1.1rem; font-weight: 500; color: #fff; width: 28px; height: 28px; border: 1px solid rgba(255,255,255,0.3); display: flex; align-items: center; justify-content: center; flex-shrink: 0; border-radius: 4px; }
.sidebar-brand-name { display: block; font-size: 0.82rem; font-weight: 700; color: #fff; letter-spacing: 3px; white-space: nowrap; }
.sidebar-brand-sub { display: block; font-size: 0.62rem; color: rgba(255,255,255,0.4); letter-spacing: 1px; text-transform: uppercase; white-space: nowrap; }
.sidebar-close-btn { display: none; background: none; border: none; color: rgba(255,255,255,0.6); font-size: 1.1rem; cursor: pointer; flex-shrink: 0; }

.sidebar-nav { flex: 1; padding: var(--space-2) 0; overflow-y: auto; overflow-x: hidden; }
.nav-section { margin-bottom: var(--space-3); }
.nav-section-label { display: block; font-size: 0.6rem; font-weight: 600; color: rgba(255,255,255,0.25); text-transform: uppercase; letter-spacing: 1.5px; padding: 0 var(--space-4); margin-bottom: 2px; white-space: nowrap; overflow: hidden; }
.nav-item { display: flex; align-items: center; gap: var(--space-3); padding: 9px var(--space-4); color: rgba(255,255,255,0.65); font-size: 0.84rem; font-weight: 500; text-decoration: none; transition: background var(--transition), color var(--transition); min-height: 40px; white-space: nowrap; overflow: hidden; }
.nav-item:hover { background: rgba(255,255,255,0.06); color: #fff; text-decoration: none; }
.nav-item.router-link-active { background: rgba(255,255,255,0.1); color: #fff; border-right: 2px solid rgba(255,255,255,0.4); }
.nav-icon { font-size: 0.9rem; width: 18px; text-align: center; flex-shrink: 0; }
.nav-label { overflow: hidden; text-overflow: ellipsis; flex: 1; }
.nav-badge { margin-left: auto; min-width: 18px; height: 18px; font-size: 0.6rem; font-weight: 700; border-radius: 9px; display: flex; align-items: center; justify-content: center; padding: 0 4px; flex-shrink: 0; }
.nav-badge--alert { background: var(--color-alert); color: #fff; }
.nav-badge--warn  { background: var(--color-warning); color: #fff; }
.ai-dot { width: 7px; height: 7px; border-radius: 50%; margin-left: auto; flex-shrink: 0; }
.ai-dot--on  { background: #27AE60; box-shadow: 0 0 6px #27AE60; }
.ai-dot--off { background: rgba(255,255,255,0.2); }

.sidebar-footer { padding: var(--space-3) var(--space-4); border-top: 1px solid rgba(255,255,255,0.08); display: flex; flex-direction: column; gap: var(--space-2); flex-shrink: 0; overflow: hidden; }
.sidebar-footer-row { display: flex; align-items: center; gap: var(--space-2); width: 100%; }
.install-app-btn {
  display: flex; align-items: center; gap: var(--space-3); width: 100%;
  padding: var(--space-2) var(--space-3); border-radius: var(--radius);
  background: rgba(39, 174, 96, 0.15); border: 1px solid rgba(39, 174, 96, 0.3);
  color: #27AE60; cursor: pointer; font-size: 0.82rem; font-weight: 600;
  transition: all var(--transition);
}
.install-app-btn:hover { background: rgba(39, 174, 96, 0.25); border-color: rgba(39, 174, 96, 0.5); }
.install-app-btn .nav-icon { font-size: 1rem; }
.install-app-btn--mini {
  width: 100%; padding: var(--space-2); justify-content: center;
  background: rgba(39, 174, 96, 0.15); border: 1px solid rgba(39, 174, 96, 0.3);
  color: #27AE60; cursor: pointer; border-radius: var(--radius);
  font-size: 1rem; transition: all var(--transition);
}
.install-app-btn--mini:hover { background: rgba(39, 174, 96, 0.25); }
.sidebar-user { flex: 1; display: flex; align-items: center; gap: var(--space-3); min-width: 0; overflow: hidden; }
.sidebar-user--link { text-decoration: none; border-radius: var(--radius); padding: var(--space-1) var(--space-2); margin: calc(-1 * var(--space-1)) calc(-1 * var(--space-2)); transition: background var(--transition); }
.sidebar-user--link:hover { background: rgba(255,255,255,0.08); }
.sidebar-user--link .user-avatar { cursor: pointer; }
.sidebar-user-mini { flex: 1; display: flex; justify-content: center; }
.user-avatar { width: 30px; height: 30px; background: var(--color-accent); color: #fff; font-size: 0.72rem; font-weight: 600; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; cursor: default; }
.user-name { display: block; font-size: 0.78rem; font-weight: 600; color: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.user-role { display: block; font-size: 0.68rem; color: rgba(255,255,255,0.4); white-space: nowrap; }
.logout-btn { background: none; border: none; color: rgba(255,255,255,0.4); cursor: pointer; font-size: 1rem; padding: var(--space-1); transition: color var(--transition); flex-shrink: 0; }
.logout-btn:hover { color: var(--color-alert); }

/* Collapse button */
.sidebar-collapse-btn-inline { background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); color: rgba(255,255,255,0.7); width: 22px; height: 22px; border-radius: 4px; cursor: pointer; font-size: 0.9rem; display: flex; align-items: center; justify-content: center; flex-shrink: 0; transition: all var(--transition); }
.sidebar-collapse-btn-inline:hover { background: rgba(255,255,255,0.2); color: #fff; }
.sidebar-collapse-btn {
  position: absolute; bottom: 60px; right: -12px;
  width: 24px; height: 24px;
  background: var(--color-primary); border: 1px solid rgba(255,255,255,0.2);
  color: rgba(255,255,255,0.7); border-radius: 50%;
  cursor: pointer; font-size: 0.85rem; display: flex; align-items: center; justify-content: center;
  z-index: 10; transition: all var(--transition);
}
.sidebar-collapse-btn:hover { background: var(--color-accent); color: #fff; }

/* Resize handle */
.sidebar-resize-handle {
  position: absolute; top: 0; right: 0; bottom: 0; width: 4px;
  cursor: col-resize; z-index: 10;
  background: transparent;
  transition: background 0.2s;
}
.sidebar-resize-handle:hover { background: rgba(255,255,255,0.15); }

/* ─── Main ───────────────────────────────────────────────────────────────── */
.main-wrap { flex: 1; margin-left: var(--current-sidebar-width); display: flex; flex-direction: column; min-height: 100vh; transition: margin-left 0.2s ease; }
.app-header { height: var(--header-height); background: var(--color-surface); border-bottom: 1px solid var(--color-border-light); display: flex; align-items: center; justify-content: space-between; padding: 0 var(--space-6); position: sticky; top: 0; z-index: 50; gap: var(--space-3); }
.header-breadcrumb { display: flex; align-items: center; flex: 1; min-width: 0; }
.breadcrumb-app { font-size: 0.8rem; color: var(--color-text-light); white-space: nowrap; }
.breadcrumb-sep { color: var(--color-border); margin: 0 var(--space-2); }
.breadcrumb-current { font-size: 0.8rem; font-weight: 600; color: var(--color-text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.header-right { display: flex; align-items: center; gap: var(--space-3); flex-shrink: 0; }
.app-main { flex: 1; padding: var(--space-6); }

/* Offline indicator in the header */
.offline-pill { font-size: 0.72rem; color: #E67E22; background: rgba(230,126,34,0.1); border: 1px solid rgba(230,126,34,0.3); padding: 3px 8px; border-radius: 20px; display: flex; align-items: center; gap: 4px; }
.offline-pending-count { background: #E67E22; color: #fff; font-size: 0.65rem; font-weight: 700; min-width: 16px; height: 16px; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; padding: 0 4px; }
.sync-pill { font-size: 0.72rem; color: #3B82F6; background: rgba(59,130,246,0.1); border: 1px solid rgba(59,130,246,0.3); padding: 3px 8px; border-radius: 20px; }
.sync-pill--pending { color: #F39C12; background: rgba(243,156,18,0.1); border-color: rgba(243,156,18,0.3); }

/* ─── Hamburger ────────────────────────────────────────────────────────── */
.hamburger-btn { display: none; flex-direction: column; gap: 5px; background: none; border: none; cursor: pointer; padding: var(--space-2); flex-shrink: 0; }
.hamburger-btn span { display: block; width: 22px; height: 2px; background: var(--color-text); border-radius: 2px; }
.sidebar-overlay { display: none; }

/* ─── Mobile FAB ──────────────────────────────────────────────────────────── */
.mobile-fab { display: none; position: fixed; bottom: 24px; right: 24px; width: 56px; height: 56px; background: var(--color-alert); color: #fff; border: none; border-radius: 50%; box-shadow: 0 4px 16px rgba(233,69,96,0.4); cursor: pointer; font-size: 1.3rem; z-index: 100; align-items: center; justify-content: center; }

/* ─── PWA banner ─────────────────────────────────────────────────────────── */
/* PWA styles removed — handled by InstallPrompt component */

/* ─── RESPONSIVE ─────────────────────────────────────────────────────────── */
@media (max-width: 768px) {
  .sidebar { transform: translateX(-100%); width: 280px !important; transition: transform 0.3s ease; }
  .sidebar--open { transform: translateX(0); }
  .sidebar-close-btn { display: flex; }
  .sidebar-collapse-btn, .sidebar-resize-handle { display: none; }
  .sidebar-overlay { display: block; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 150; }
  .main-wrap { margin-left: 0 !important; transition: none; }
  .hamburger-btn { display: flex; }
  .mobile-fab { display: flex; bottom: 140px; }
  .app-main { padding: var(--space-4) var(--space-3); padding-bottom: max(80px, env(safe-area-inset-bottom)); }
  .app-header { padding: 0 var(--space-3); }
  .breadcrumb-current { font-size: 0.78rem; }
}

/* ─── PWA installation modal ──────────────────────────────────────────────── */
.install-modal-overlay {
  position: fixed; inset: 0; z-index: 9999;
  background: rgba(0,0,0,0.5);
  display: flex; align-items: center; justify-content: center;
  padding: var(--space-4);
}
.install-modal {
  background: var(--color-surface, #fff);
  border-radius: 16px; padding: var(--space-5);
  max-width: 420px; width: 100%;
  display: flex; flex-direction: column; gap: var(--space-4);
  box-shadow: 0 20px 60px rgba(0,0,0,0.3);
}
.install-modal-header {
  display: flex; align-items: center; gap: var(--space-4);
}
.install-modal-icon {
  width: 48px; height: 48px; border-radius: 12px;
  background: var(--color-primary, #1A1A2E); color: #fff;
  display: flex; align-items: center; justify-content: center;
  font-size: 16px; font-weight: 800; letter-spacing: 1px; flex-shrink: 0;
}
.install-modal-title {
  font-size: 1.05rem; font-weight: 700; color: var(--color-primary, #1A1A2E); margin: 0;
}
.install-modal-sub {
  font-size: 0.78rem; color: var(--color-text-muted, #888); margin: 2px 0 0;
}
.install-modal-steps {
  display: flex; flex-direction: column; gap: var(--space-3);
}
.install-step {
  display: flex; align-items: flex-start; gap: var(--space-3);
  font-size: 0.88rem; color: var(--color-text, #333); line-height: 1.5;
}
.install-step-num {
  width: 26px; height: 26px; flex-shrink: 0;
  background: var(--color-primary, #1A1A2E); color: #fff;
  border-radius: 50%; font-size: 0.75rem; font-weight: 700;
  display: flex; align-items: center; justify-content: center;
  margin-top: 1px;
}
.install-modal-note {
  font-size: 0.8rem; color: var(--color-text-muted, #888); line-height: 1.5;
  background: var(--color-surface-2, #f5f5f5); padding: var(--space-3);
  border-radius: var(--radius); margin: 0;
}
.install-modal-close {
  width: 100%; height: 44px;
  background: var(--color-primary, #1A1A2E); color: #fff;
  border: none; border-radius: var(--radius-md, 10px);
  font-size: 0.9rem; font-weight: 600; cursor: pointer;
  transition: opacity var(--transition);
}
.install-modal-close:hover { opacity: 0.9; }
</style>
