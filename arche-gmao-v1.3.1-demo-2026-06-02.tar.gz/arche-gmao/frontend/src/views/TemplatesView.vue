<template>
  <div class="templates-layout">
    <div class="page-header">
      <div>
        <h1 class="page-title">Plantillas y Composiciones</h1>
        <p class="page-sub">
          Plantillas de equipo para vincular máquinas del mismo modelo, y composiciones para agrupar equipos que trabajan juntos. La IA comparte conocimiento y realiza diagnóstico cruzado.
        </p>
      </div>
      <button class="btn-primary" @click="openCreate" :disabled="!canWrite">+ Nueva plantilla</button>
    </div>

    <!-- Filters -->
    <div class="filters-bar">
      <input v-model="searchQ" class="filter-search" placeholder="Buscar fabricante o modelo..."
        @input="debouncedLoad" />
      <select v-model="filterCategory" class="filter-select" @change="loadTemplates">
        <option value="">Todas las categorías</option>
        <option v-for="cat in categories" :key="cat" :value="cat">{{ cat }}</option>
      </select>
    </div>

    <!-- Global / own split -->
    <div v-if="loading" class="empty-state">Cargando...</div>
    <template v-else>
      <!-- Global system templates -->
      <div v-if="globalTemplates.length">
        <div class="section-divider">
          <span>Plantillas globales del sistema</span>
          <span class="divider-hint">Visibles para todos los tenants — solo lectura</span>
        </div>
        <div class="templates-grid">
          <div v-for="t in globalTemplates" :key="t.id" class="template-card template-card--global"
            @click="openDetail(t)">
            <div class="tc-header">
              <div class="tc-icon">⚙</div>
              <div class="tc-badge tc-badge--global">Global</div>
            </div>
            <div class="tc-manufacturer">{{ t.manufacturer }}</div>
            <div class="tc-model">{{ t.model }}</div>
            <div class="tc-category text-muted">{{ t.category ?? '—' }}</div>
            <div class="tc-footer">
              <span class="tc-count" :class="{ 'tc-count--active': t.node_count > 0 }">
                {{ t.node_count }} nodo(s) vinculados
              </span>
              <span class="tc-tags">
                <span v-for="tag in t.tags?.slice(0, 2)" :key="tag" class="tag-pill">{{ tag }}</span>
              </span>
            </div>
          </div>
        </div>
      </div>

      <!-- The tenant's own templates -->
      <div v-if="tenantTemplates.length">
        <div class="section-divider">
          <span>Plantillas de tu organización</span>
        </div>
        <div class="templates-grid">
          <div v-for="t in tenantTemplates" :key="t.id" class="template-card"
            @click="openDetail(t)">
            <div class="tc-header">
              <div class="tc-icon">⚙</div>
              <div class="tc-actions" @click.stop>
                <button class="tc-btn" @click="openEdit(t)" title="Editar">✎</button>
                <button class="tc-btn tc-btn--del" @click="confirmDelete(t)" title="Eliminar">✕</button>
              </div>
            </div>
            <div class="tc-manufacturer">{{ t.manufacturer }}</div>
            <div class="tc-model">{{ t.model }}</div>
            <div class="tc-category text-muted">{{ t.category ?? '—' }}</div>
            <div class="tc-footer">
              <span class="tc-count" :class="{ 'tc-count--active': t.node_count > 0 }">
                {{ t.node_count }} nodo(s)
              </span>
            </div>
          </div>
        </div>
      </div>

      <div v-if="!globalTemplates.length && !tenantTemplates.length" class="empty-state">
        No hay plantillas de equipo disponibles.
      </div>

      <!-- ══════════════════════════════════════════════════════════════════ -->
      <!-- Composition templates                                        -->
      <!-- ══════════════════════════════════════════════════════════════════ -->
      <div class="comp-section">
        <div class="page-header page-header--sub">
          <div>
            <h2 class="page-title page-title--sub">Composiciones</h2>
            <p class="page-sub">
              Agrupaciones funcionales de equipos. La IA realiza diagnóstico cruzado entre los componentes de una composición.
            </p>
          </div>
          <button class="btn-primary" @click="openCreateCompTemplate" :disabled="!canWrite">+ Nueva composición</button>
        </div>

        <div v-if="loadingCompTemplates" class="empty-state">Cargando...</div>
        <div v-else-if="!compTemplatesList.length" class="empty-state">
          No hay plantillas de composición. Crea una para definir como se agrupan tus equipos.
        </div>
        <div v-else class="templates-grid">
          <div v-for="ct in compTemplatesList" :key="'ct-' + ct.id" class="template-card template-card--comp"
            @click="openCompTemplateDetail(ct)">
            <div class="tc-header">
              <div class="tc-icon">◈</div>
              <div class="tc-actions" @click.stop>
                <button class="tc-btn" @click="openEditCompTemplate(ct)" title="Editar">✎</button>
                <button class="tc-btn tc-btn--del" @click="confirmDeleteCompTemplate(ct.id)" title="Eliminar">✕</button>
              </div>
            </div>
            <div class="tc-model">{{ ct.name }}</div>
            <div class="tc-category text-muted">{{ ct.slot_count }} slots definidos</div>
            <div class="tc-footer">
              <span class="tc-count" :class="{ 'tc-count--active': ct.usage_count > 0 }">
                {{ ct.usage_count }} composiciones activas
              </span>
              <button class="btn-apply" @click.stop="openApplyCompTemplate(ct)" title="Aplicar en nodo">Aplicar ▸</button>
            </div>
          </div>
        </div>
      </div>
    </template>

    <!-- Detail modal -->
    <Teleport to="body">
      <div v-if="detailTemplate" class="modal-overlay" @click.self="detailTemplate = null">
        <div class="detail-modal">
          <div class="modal-header">
            <div>
              <div class="detail-badge-row">
                <span v-if="detailTemplate.template.is_global" class="global-badge">Global</span>
                <span class="category-badge">{{ detailTemplate.template.category ?? 'Sin categoría' }}</span>
              </div>
              <h2 class="detail-manufacturer">{{ detailTemplate.template.manufacturer }}</h2>
              <h3 class="detail-model">{{ detailTemplate.template.model }}</h3>
            </div>
            <button class="modal-close" @click="detailTemplate = null">✕</button>
          </div>
          <div class="modal-body">
            <!-- Tabs -->
            <div class="detail-tabs">
              <button class="detail-tab" :class="{ 'detail-tab--active': detailTab === 'info' }" @click="detailTab = 'info'">Información</button>
              <button class="detail-tab" :class="{ 'detail-tab--active': detailTab === 'library' }" @click="detailTab = 'library'; loadTemplateLibrary()">
                Biblioteca <span v-if="tplAttachments.length" class="count-badge">{{ tplAttachments.length }}</span>
              </button>
            </div>

            <!-- Info tab -->
            <template v-if="detailTab === 'info'">
              <div v-if="detailTemplate.template.description" class="detail-desc">
                <p>{{ detailTemplate.template.description }}</p>
              </div>

              <!-- Tags -->
              <div v-if="detailTemplate.template.tags?.length" class="detail-tags">
                <span v-for="tag in detailTemplate.template.tags" :key="tag" class="tag-pill tag-pill--lg">
                  {{ tag }}
                </span>
              </div>

              <!-- Linked nodes -->
              <div class="detail-section-title">
                Nodos vinculados en tu planta
                <span class="count-badge">{{ detailTemplate.nodes?.length ?? 0 }}</span>
              </div>

              <div v-if="!detailTemplate.nodes?.length" class="nodes-empty">
                Ningún nodo de tu planta usa esta plantilla todavía.
                <br />
                Puedes asignarla desde la Fábrica Virtual → Editar nodo.
              </div>

              <div v-else class="nodes-list">
                <div v-for="node in detailTemplate.nodes" :key="node.id" class="node-row">
                  <span class="node-name">{{ node.name }}</span>
                  <span class="node-code mono text-muted">{{ node.code ?? '—' }}</span>
                  <span class="crit-dot" :style="{ background: CRIT_COLORS[node.criticality] }"></span>
                  <span class="node-status text-muted">{{ node.status }}</span>
                </div>
              </div>

              <!-- Clone into a node -->
              <div v-if="!detailTemplate.template.is_global" class="clone-section">
                <div class="detail-section-title">Clonar equipos en un nodo</div>
                <p class="clone-hint text-muted">Crea múltiples equipos de este modelo bajo un nodo de la fábrica.</p>
                <button class="btn-primary btn-sm" @click="openCloneFromDetail(detailTemplate.template)">Clonar en nodo ▸</button>
              </div>

              <!-- Info for the AI -->
              <div class="ai-info-box">
                <div class="ai-info-icon">◬</div>
                <div class="ai-info-text">
                  <strong>Arche IA:</strong> cuando un técnico consulta sobre cualquiera de estos nodos,
                  la IA tendra acceso al historial verificado de todos los nodos de esta plantilla.
                  {{ detailTemplate.nodes?.length > 1
                    ? `${detailTemplate.nodes.length} maquinas compartiendo conocimiento.`
                    : 'Vincula más nodos para ampliar el contexto.'
                  }}
                </div>
              </div>
            </template>

            <!-- Library tab -->
            <template v-if="detailTab === 'library'">
              <!-- Folder navigation -->
              <div class="lib-nav">
                <button v-if="currentFolderId" class="btn-back" @click="navigateFolder(null)">← Raiz</button>
                <span v-for="f in tplFolders" :key="f.id"
                  class="folder-chip"
                  :class="{ 'folder-chip--active': f.id === currentFolderId }"
                  @click="navigateFolder(f.id)">
                  ▤ {{ f.name }}
                </span>
              </div>

              <!-- Actions (tenant only, not global) -->
              <div v-if="!detailTemplate.template.is_global" class="lib-actions">
                <label class="btn-upload">
                  ↑ Subir archivo
                  <input type="file" hidden @change="uploadTemplateFile" />
                </label>
                <button class="btn-secondary btn-sm" @click="openFolderCreate">+ Carpeta</button>
              </div>

              <!-- Create a folder inline -->
              <div v-if="showFolderForm" class="folder-form">
                <input v-model="newFolderName" class="field-input field-input--sm" placeholder="Nombre de carpeta..." @keyup.enter="createTemplateFolder" />
                <button class="btn-primary btn-sm" @click="createTemplateFolder">Crear</button>
                <button class="btn-secondary btn-sm" @click="showFolderForm = false">Cancelar</button>
              </div>

              <!-- File list -->
              <div v-if="loadingLibrary" class="empty-state">Cargando...</div>
              <div v-else-if="!tplAttachments.length" class="empty-state">
                No hay archivos en esta {{ currentFolderId ? 'carpeta' : 'plantilla' }}.
              </div>
              <div v-else class="lib-list">
                <div v-for="a in tplAttachments" :key="a.id" class="lib-card">
                  <span class="lib-icon">{{ getMimeIcon(a.mime_type) }}</span>
                  <div class="lib-info">
                    <span class="lib-name">{{ a.original_name }}</span>
                    <span class="lib-meta text-muted">{{ formatSize(a.file_size) }} — {{ a.uploaded_by }}</span>
                  </div>
                  <button v-if="!detailTemplate.template.is_global" class="btn-unlink"
                    title="Eliminar" @click="deleteTemplateAttachment(a.id)">✕</button>
                </div>
              </div>

              <!-- Shared info -->
              <div class="ai-info-box">
                <div class="ai-info-icon">◇</div>
                <div class="ai-info-text">
                  Los archivos de esta plantilla se comparten automáticamente con todos los nodos vinculados.
                  <strong>Sin duplicar almacenamiento</strong> — un solo archivo, visible en {{ detailTemplate.nodes?.length ?? 0 }} nodo(s).
                </div>
              </div>
            </template>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Create/edit modal -->
    <Teleport to="body">
      <div v-if="showForm" class="modal-overlay" @click.self="showForm = false">
        <div class="create-modal">
          <div class="modal-header">
            <h3>{{ editTemplate ? 'Editar plantilla' : 'Nueva plantilla' }}</h3>
            <button class="modal-close" @click="showForm = false">✕</button>
          </div>
          <div class="modal-body">
            <div class="field-row">
              <div class="field">
                <label class="field-label">Fabricante *</label>
                <input v-model="form.manufacturer" class="field-input" placeholder="ABB, Siemens, KHS..." />
              </div>
              <div class="field">
                <label class="field-label">Modelo *</label>
                <input v-model="form.model" class="field-input" placeholder="ACS580, KR 40 PA..." />
              </div>
            </div>
            <div class="field-row">
              <div class="field">
                <label class="field-label">Categoría</label>
                <input v-model="form.category" class="field-input" placeholder="Variador de frecuencia..." list="categories-list" />
                <datalist id="categories-list">
                  <option v-for="cat in categories" :key="cat" :value="cat" />
                </datalist>
              </div>
              <div class="field">
                <label class="field-label">Tipo de nodo</label>
                <select v-model="form.node_type" class="field-input">
                  <option value="equipment">Equipo</option>
                  <option value="component">Componente</option>
                  <option value="measurement_point">Punto de Medición</option>
                </select>
              </div>
            </div>
            <div class="field">
              <label class="field-label">Descripción</label>
              <textarea v-model="form.description" class="field-input" rows="3"
                placeholder="Descripción técnica del equipo o componente..." />
            </div>
            <div class="field">
              <label class="field-label">Tags (separados por coma)</label>
              <input v-model="tagsInput" class="field-input"
                placeholder="variador, abb, frecuencia, motor..." />
              <p class="field-hint">Ayudan a la IA a identificar el tipo de equipo</p>
            </div>
            <div class="field">
              <label class="field-label">Notas técnicas</label>
              <textarea v-model="form.notes" class="field-input" rows="2"
                placeholder="Información relevante del fabricante, versiones, variantes..." />
            </div>
            <div v-if="formError" class="modal-error">{{ formError }}</div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary" @click="showForm = false">Cancelar</button>
            <button class="btn-primary" :disabled="!canWrite || saving" @click="submitForm">
              {{ saving ? 'Guardando...' : (editTemplate ? 'Guardar' : 'Crear plantilla') }}
            </button>
          </div>
        </div>
      </div>
    </Teleport>
    <!-- Clone equipment into a node modal -->
    <Teleport to="body">
      <div v-if="showCloneModal" class="modal-overlay" @click.self="showCloneModal = false">
        <div class="create-modal">
          <div class="modal-header">
            <h3>Clonar {{ cloneTemplateName }} en nodo</h3>
            <button class="modal-close" @click="showCloneModal = false">✕</button>
          </div>
          <div class="modal-body">
            <div class="field">
              <label class="field-label">Nodo destino *</label>
              <input v-model="nodeSearchQ" class="field-input" placeholder="Buscar nodo..." @input="debouncedNodeSearch" />
              <div v-if="nodeSearchResults.length" class="node-picker-results">
                <div v-for="n in nodeSearchResults" :key="n.id" class="node-picker-item"
                  :class="{ 'node-picker-item--active': cloneParentNodeId === n.id }"
                  @click="cloneParentNodeId = n.id; cloneParentNodeName = n.name; nodeSearchResults = []">
                  {{ n.name }} <span class="text-muted small">[{{ n.node_type }}]</span>
                </div>
              </div>
              <div v-if="cloneParentNodeName" class="selected-node-badge">{{ cloneParentNodeName }}</div>
            </div>
            <div class="field-row">
              <div class="field">
                <label class="field-label">Cantidad *</label>
                <input v-model.number="cloneCount" type="number" min="1" max="100" class="field-input" />
              </div>
              <div class="field">
                <label class="field-label">Número inicial</label>
                <input v-model.number="cloneStartNumber" type="number" min="1" class="field-input" />
              </div>
            </div>
            <div class="field">
              <label class="field-label">Prefijo del nombre</label>
              <input v-model="cloneNamePrefix" class="field-input" placeholder="Si vacio, usa fabricante+modelo" />
            </div>
            <div v-if="cloneError" class="modal-error">{{ cloneError }}</div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary" @click="showCloneModal = false">Cancelar</button>
            <button class="btn-primary" :disabled="cloning || !cloneParentNodeId" @click="submitClone">
              {{ cloning ? 'Creando...' : 'Clonar equipos' }}
            </button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Create/edit composition template modal -->
    <Teleport to="body">
      <div v-if="showCompForm" class="modal-overlay" @click.self="showCompForm = false">
        <div class="create-modal">
          <div class="modal-header">
            <h3>{{ editCompTemplate ? 'Editar composición' : 'Nueva composición' }}</h3>
            <button class="modal-close" @click="showCompForm = false">✕</button>
          </div>
          <div class="modal-body">
            <div class="field">
              <label class="field-label">Nombre *</label>
              <input v-model="compForm.name" class="field-input" placeholder="Ej: Sistema de climatizacion" />
            </div>
            <div class="field">
              <label class="field-label">Descripción</label>
              <textarea v-model="compForm.description" class="field-input" rows="2" placeholder="Descripción opcional..." />
            </div>
            <div class="field">
              <label class="field-label">Slots ({{ compForm.slots.length }})</label>
              <div class="slots-list">
                <div v-for="(slot, i) in compForm.slots" :key="i" class="slot-row">
                  <input v-model="slot.role" class="field-input slot-role" placeholder="Rol (ej: controlador)" />
                  <select v-model="slot.equipment_template_id" class="field-input slot-type">
                    <option :value="null">Tipo de equipo (opcional)</option>
                    <option v-for="et in templates" :key="et.id" :value="et.id">
                      {{ et.manufacturer }} {{ et.model }}
                    </option>
                  </select>
                  <button class="tc-btn tc-btn--del" @click="compForm.slots.splice(i, 1)">✕</button>
                </div>
              </div>
              <button class="btn-secondary btn-sm" @click="compForm.slots.push({ role: '', equipment_template_id: null, sort_order: compForm.slots.length })">+ Agregar slot</button>
            </div>
            <div v-if="compFormError" class="modal-error">{{ compFormError }}</div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary" @click="showCompForm = false">Cancelar</button>
            <button class="btn-primary" :disabled="savingComp" @click="submitCompForm">
              {{ savingComp ? 'Guardando...' : (editCompTemplate ? 'Guardar' : 'Crear composición') }}
            </button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Composition template detail modal -->
    <Teleport to="body">
      <div v-if="compDetail" class="modal-overlay" @click.self="compDetail = null">
        <div class="detail-modal">
          <div class="modal-header">
            <div>
              <div class="detail-badge-row">
                <span class="category-badge">Composición</span>
              </div>
              <h2 class="detail-model">{{ compDetail.template.name }}</h2>
            </div>
            <button class="modal-close" @click="compDetail = null">✕</button>
          </div>
          <div class="modal-body">
            <div v-if="compDetail.template.description" class="detail-desc">
              <p>{{ compDetail.template.description }}</p>
            </div>

            <div class="detail-section-title">
              Slots definidos
              <span class="count-badge">{{ compDetail.slots.length }}</span>
            </div>
            <div class="slots-preview">
              <div v-for="s in compDetail.slots" :key="s.id" class="slot-preview-item">
                <span class="slot-preview-role">{{ s.role }}</span>
                <span class="slot-preview-type text-muted">{{ s.equipment_name ?? 'Cualquier equipo' }}</span>
              </div>
            </div>

            <div class="clone-section">
              <div class="detail-section-title">Aplicar en un nodo</div>
              <p class="clone-hint text-muted">
                Selecciona un nodo padre. El sistema buscará equipos hijos que coincidan con los slots y creará las composiciones automáticamente.
              </p>
              <button class="btn-primary btn-sm" @click="openApplyCompTemplate(compDetail.template)">Aplicar en nodo ▸</button>
            </div>

            <div class="ai-info-box">
              <div class="ai-info-icon">◬</div>
              <div class="ai-info-text">
                <strong>Arche IA:</strong> cuando un componente de una composición tiene una avería,
                la IA consulta automáticamente el historial de TODOS los componentes vinculados para un diagnóstico cruzado.
              </div>
            </div>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Apply composition to a node modal -->
    <Teleport to="body">
      <div v-if="showApplyModal" class="modal-overlay" @click.self="showApplyModal = false">
        <div class="create-modal">
          <div class="modal-header">
            <h3>Aplicar "{{ applyCompName }}" en nodo</h3>
            <button class="modal-close" @click="showApplyModal = false">✕</button>
          </div>
          <div class="modal-body">
            <p class="text-muted" style="font-size:0.82rem;margin-bottom:12px">
              El sistema buscará equipos hijos del nodo seleccionado que coincidan con los tipos de equipo de los slots y los emparejará automáticamente.
            </p>
            <div class="field">
              <label class="field-label">Nodo destino *</label>
              <input v-model="nodeSearchQ" class="field-input" placeholder="Buscar nodo..." @input="debouncedNodeSearch" />
              <div v-if="nodeSearchResults.length" class="node-picker-results">
                <div v-for="n in nodeSearchResults" :key="n.id" class="node-picker-item"
                  :class="{ 'node-picker-item--active': applyParentNodeId === n.id }"
                  @click="applyParentNodeId = n.id; applyParentNodeName = n.name; nodeSearchResults = []">
                  {{ n.name }} <span class="text-muted small">[{{ n.node_type }}]</span>
                </div>
              </div>
              <div v-if="applyParentNodeName" class="selected-node-badge">{{ applyParentNodeName }}</div>
            </div>
            <div v-if="applyError" class="modal-error">{{ applyError }}</div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary" @click="showApplyModal = false">Cancelar</button>
            <button class="btn-primary" :disabled="applyingComp || !applyParentNodeId" @click="submitApplyComp">
              {{ applyingComp ? 'Aplicando...' : 'Aplicar composición' }}
            </button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import { useToast, apiErrorMsg } from '@/composables/useToast'
const toast = useToast()
import { ref, computed, onMounted } from 'vue'
import { templatesApi } from '@/api/templates'
import type { EquipmentTemplate, TemplateWithNodes } from '@/api/templates'
import { nodesApi } from '@/api/nodes'
import { compTemplatesApi, cloneApi } from '@/api/compositions'
import { useSystemPause } from '@/composables/useSystemPause'

const { canWrite } = useSystemPause()
const CRIT_COLORS: Record<string, string> = {
  low: '#27AE60', medium: '#F39C12', high: '#E67E22', critical: '#E94560'
}

const templates = ref<EquipmentTemplate[]>([])
const categories = ref<string[]>([])
const loading = ref(false)
const searchQ = ref('')
const filterCategory = ref('')

const globalTemplates = computed(() => templates.value.filter(t => t.is_global))
const tenantTemplates = computed(() => templates.value.filter(t => !t.is_global))

// Detail
const detailTemplate = ref<TemplateWithNodes | null>(null)
const detailTab = ref<'info' | 'library'>('info')

// Template library
const tplAttachments = ref<any[]>([])
const tplFolders = ref<any[]>([])
const currentFolderId = ref<number | null>(null)
const loadingLibrary = ref(false)
const showFolderForm = ref(false)
const newFolderName = ref('')

async function loadTemplateLibrary() {
  if (!detailTemplate.value) return
  loadingLibrary.value = true
  try {
    const data = await templatesApi.listLibrary(
      detailTemplate.value.template.id,
      currentFolderId.value ?? undefined,
    )
    tplAttachments.value = data.attachments ?? []
    tplFolders.value = data.folders ?? []
  } catch { tplAttachments.value = []; tplFolders.value = [] }
  finally { loadingLibrary.value = false }
}

function navigateFolder(folderId: number | null) {
  currentFolderId.value = folderId
  loadTemplateLibrary()
}

async function uploadTemplateFile(e: Event) {
  const input = e.target as HTMLInputElement
  const file = input.files?.[0]
  if (!file || !detailTemplate.value) return

  const fd = new FormData()
  fd.append('file', file)
  if (currentFolderId.value) fd.append('folder_id', String(currentFolderId.value))

  try {
    await templatesApi.uploadToTemplate(detailTemplate.value.template.id, fd)
    await loadTemplateLibrary()
  } catch (err: unknown) {
    toast.fromError(err, 'Error subiendo archivo')
  }
  input.value = ''
}

async function deleteTemplateAttachment(attId: number) {
  if (!confirm('¿Eliminar este archivo de la plantilla?')) return
  try {
    await templatesApi.deleteTemplateFile(attId)
    await loadTemplateLibrary()
  } catch (err: unknown) {
    toast.fromError(err, 'Error eliminando archivo')
  }
}

function openFolderCreate() {
  newFolderName.value = ''
  showFolderForm.value = true
}

async function createTemplateFolder() {
  if (!newFolderName.value.trim() || !detailTemplate.value) return
  try {
    await templatesApi.createFolder(detailTemplate.value.template.id, {
      name: newFolderName.value.trim(),
      parent_id: currentFolderId.value ?? undefined,
    })
    showFolderForm.value = false
    await loadTemplateLibrary()
  } catch (err: unknown) {
    toast.fromError(err, 'Error creando carpeta')
  }
}

function getMimeIcon(mime: string): string {
  if (mime?.startsWith('image/')) return '▣'
  if (mime?.includes('pdf')) return '▤'
  if (mime?.startsWith('video/')) return '▶'
  if (mime?.includes('spreadsheet') || mime?.includes('excel')) return '▦'
  if (mime?.includes('word') || mime?.includes('document')) return '≡'
  return '◻'
}

function formatSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / 1024 / 1024).toFixed(1) + ' MB'
}

// Form
const showForm = ref(false)
const editTemplate = ref<EquipmentTemplate | null>(null)
const saving = ref(false)
const formError = ref('')
const tagsInput = ref('')
const form = ref({
  manufacturer: '', model: '', category: '',
  node_type: 'equipment', description: '', notes: ''
})

async function loadTemplates() {
  loading.value = true
  try {
    const data = await templatesApi.list({
      q: searchQ.value || undefined,
      category: filterCategory.value || undefined,
    })
    templates.value = data.templates ?? []
  } finally { loading.value = false }
}

async function loadCategories() {
  try {
    const data = await templatesApi.getCategories()
    categories.value = data.categories ?? []
  } catch { categories.value = [] }
}

// Debounce the search
let searchTimeout: ReturnType<typeof setTimeout> | null = null
function debouncedLoad() {
  if (searchTimeout) clearTimeout(searchTimeout)
  searchTimeout = setTimeout(loadTemplates, 300)
}

async function openDetail(t: EquipmentTemplate) {
  const data = await templatesApi.getOne(t.id)
  detailTemplate.value = data
  detailTab.value = 'info'
  tplAttachments.value = []
  tplFolders.value = []
  currentFolderId.value = null
}

function openCreate() {
  editTemplate.value = null
  form.value = { manufacturer: '', model: '', category: '', node_type: 'equipment', description: '', notes: '' }
  tagsInput.value = ''
  formError.value = ''
  showForm.value = true
}

function openEdit(t: EquipmentTemplate) {
  editTemplate.value = t
  form.value = {
    manufacturer: t.manufacturer,
    model: t.model,
    category: t.category ?? '',
    node_type: t.node_type,
    description: t.description ?? '',
    notes: t.notes ?? '',
  }
  tagsInput.value = t.tags?.join(', ') ?? ''
  formError.value = ''
  showForm.value = true
}

async function submitForm() {
  if (!form.value.manufacturer || !form.value.model) {
    formError.value = 'Fabricante y modelo son requeridos'
    return
  }
  saving.value = true; formError.value = ''

  const payload = {
    ...form.value,
    category: form.value.category || undefined,
    description: form.value.description || undefined,
    notes: form.value.notes || undefined,
    tags: tagsInput.value ? tagsInput.value.split(',').map(t => t.trim()).filter(Boolean) : [],
  }

  try {
    if (editTemplate.value) {
      await templatesApi.update(editTemplate.value.id, payload)
    } else {
      await templatesApi.create(payload)
    }
    showForm.value = false
    await loadTemplates()
  } catch (err: unknown) {
    formError.value = apiErrorMsg(err, 'Error guardando la plantilla')
  } finally { saving.value = false }
}

async function confirmDelete(t: EquipmentTemplate) {
  if (!confirm(`¿Desactivar la plantilla "${t.manufacturer} ${t.model}"?`)) return
  try {
    await templatesApi.delete(t.id)
    await loadTemplates()
  } catch (err: unknown) {
    toast.fromError(err, 'Error eliminando plantilla')
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// Node picker (shared between clone and apply)
// ═══════════════════════════════════════════════════════════════════════════
const nodeSearchQ = ref('')
const nodeSearchResults = ref<any[]>([])
let nodeSearchTimeout: ReturnType<typeof setTimeout> | null = null

function debouncedNodeSearch() {
  if (nodeSearchTimeout) clearTimeout(nodeSearchTimeout)
  nodeSearchTimeout = setTimeout(async () => {
    if (nodeSearchQ.value.length < 2) { nodeSearchResults.value = []; return }
    try {
      const data = await nodesApi.search(nodeSearchQ.value)
      nodeSearchResults.value = (data.results ?? data ?? []).slice(0, 10)
    } catch { nodeSearchResults.value = [] }
  }, 300)
}

// ═══════════════════════════════════════════════════════════════════════════
// Clone equipment from an equipment template
// ═══════════════════════════════════════════════════════════════════════════
const showCloneModal = ref(false)
const cloneTemplateId = ref(0)
const cloneTemplateName = ref('')
const cloneParentNodeId = ref<number>(0)
const cloneParentNodeName = ref('')
const cloneCount = ref(1)
const cloneStartNumber = ref(1)
const cloneNamePrefix = ref('')
const cloneError = ref('')
const cloning = ref(false)

function openCloneFromDetail(tmpl: any) {
  cloneTemplateId.value = tmpl.id
  cloneTemplateName.value = `${tmpl.manufacturer} ${tmpl.model}`
  cloneParentNodeId.value = 0
  cloneParentNodeName.value = ''
  cloneCount.value = 1
  cloneStartNumber.value = 1
  cloneNamePrefix.value = ''
  cloneError.value = ''
  nodeSearchQ.value = ''
  nodeSearchResults.value = []
  showCloneModal.value = true
}

async function submitClone() {
  if (!cloneParentNodeId.value) { cloneError.value = 'Selecciona un nodo destino'; return }
  cloning.value = true; cloneError.value = ''
  try {
    const result = await cloneApi.cloneEquipment({
      equipment_template_id: cloneTemplateId.value,
      parent_node_id: cloneParentNodeId.value,
      count: cloneCount.value,
      name_prefix: cloneNamePrefix.value || undefined,
      start_number: cloneStartNumber.value,
    })
    toast.error(result.message)
    showCloneModal.value = false
    await loadTemplates()
  } catch (err: unknown) {
    cloneError.value = apiErrorMsg(err, 'Error clonando equipos')
  } finally { cloning.value = false }
}

// ═══════════════════════════════════════════════════════════════════════════
// Composition templates
// ═══════════════════════════════════════════════════════════════════════════
const compTemplatesList = ref<any[]>([])
const loadingCompTemplates = ref(false)
const compDetail = ref<any>(null)

const showCompForm = ref(false)
const editCompTemplate = ref<any>(null)
const savingComp = ref(false)
const compFormError = ref('')
const compForm = ref<{ name: string; description: string; slots: { role: string; equipment_template_id: number | null; sort_order: number }[] }>({
  name: '', description: '', slots: [{ role: '', equipment_template_id: null, sort_order: 0 }]
})

async function loadCompTemplates() {
  loadingCompTemplates.value = true
  try {
    compTemplatesList.value = await compTemplatesApi.list()
  } catch { compTemplatesList.value = [] }
  loadingCompTemplates.value = false
}

function openCreateCompTemplate() {
  editCompTemplate.value = null
  compForm.value = { name: '', description: '', slots: [{ role: '', equipment_template_id: null, sort_order: 0 }] }
  compFormError.value = ''
  showCompForm.value = true
}

async function openEditCompTemplate(ct: any) {
  editCompTemplate.value = ct
  try {
    const data = await compTemplatesApi.getOne(ct.id)
    compForm.value = {
      name: data.template.name,
      description: data.template.description ?? '',
      slots: data.slots.map((s: any) => ({
        role: s.role, equipment_template_id: s.equipment_template_id, sort_order: s.sort_order
      }))
    }
    if (!compForm.value.slots.length) compForm.value.slots.push({ role: '', equipment_template_id: null, sort_order: 0 })
  } catch { /* use empty form */ }
  compFormError.value = ''
  showCompForm.value = true
}

async function submitCompForm() {
  if (!compForm.value.name.trim()) { compFormError.value = 'El nombre es obligatorio'; return }
  const validSlots = compForm.value.slots.filter(s => s.role.trim())
  if (!validSlots.length) { compFormError.value = 'Se necesita al menos un slot con rol'; return }
  savingComp.value = true; compFormError.value = ''
  try {
    const payload = {
      name: compForm.value.name,
      description: compForm.value.description || undefined,
      slots: validSlots.map((s, i) => ({ ...s, sort_order: i })),
    }
    if (editCompTemplate.value) {
      await compTemplatesApi.update(editCompTemplate.value.id, payload)
    } else {
      await compTemplatesApi.create(payload)
    }
    showCompForm.value = false
    await loadCompTemplates()
  } catch (err: unknown) {
    compFormError.value = apiErrorMsg(err, 'Error guardando composición')
  } finally { savingComp.value = false }
}

async function openCompTemplateDetail(ct: any) {
  try {
    compDetail.value = await compTemplatesApi.getOne(ct.id)
  } catch { /* ignore */ }
}

async function confirmDeleteCompTemplate(id: number) {
  if (!confirm('¿Eliminar esta plantilla de composición?')) return
  try {
    await compTemplatesApi.delete(id)
    await loadCompTemplates()
  } catch (err: unknown) { toast.fromError(err, 'Error eliminando') }
}

// ═══════════════════════════════════════════════════════════════════════════
// Apply a composition to a node
// ═══════════════════════════════════════════════════════════════════════════
const showApplyModal = ref(false)
const applyCompId = ref(0)
const applyCompName = ref('')
const applyParentNodeId = ref<number>(0)
const applyParentNodeName = ref('')
const applyError = ref('')
const applyingComp = ref(false)

function openApplyCompTemplate(ct: any) {
  applyCompId.value = ct.id
  applyCompName.value = ct.name
  applyParentNodeId.value = 0
  applyParentNodeName.value = ''
  applyError.value = ''
  nodeSearchQ.value = ''
  nodeSearchResults.value = []
  showApplyModal.value = true
}

async function submitApplyComp() {
  if (!applyParentNodeId.value) { applyError.value = 'Selecciona un nodo destino'; return }
  applyingComp.value = true; applyError.value = ''
  try {
    const result = await compTemplatesApi.apply(applyCompId.value, applyParentNodeId.value)
    toast.error(result.message)
    showApplyModal.value = false
    await loadCompTemplates()
  } catch (err: unknown) {
    applyError.value = apiErrorMsg(err, 'Error aplicando composición')
  } finally { applyingComp.value = false }
}

onMounted(() => { loadTemplates(); loadCategories(); loadCompTemplates() })
</script>

<style scoped>
.templates-layout { display: flex; flex-direction: column; gap: var(--space-6); }
.page-header { display: flex; align-items: flex-start; justify-content: space-between; }
.page-title { font-size: 1.4rem; font-weight: 700; color: var(--color-primary); }
.page-sub { font-size: 0.8rem; color: var(--color-text-muted); max-width: 560px; line-height: 1.6; }

.filters-bar { display: flex; gap: var(--space-3); }
.filter-search { height: 36px; padding: 0 var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.8rem; background: var(--color-surface); outline: none; width: 260px; }
.filter-search:focus { border-color: var(--color-accent); }
.filter-select { height: 36px; padding: 0 var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.8rem; background: var(--color-surface); }

.section-divider { display: flex; align-items: center; justify-content: space-between; margin: var(--space-2) 0; }
.section-divider span:first-child { font-size: 0.72rem; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; color: var(--color-text-muted); }
.divider-hint { font-size: 0.7rem; color: var(--color-text-light); }

.templates-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: var(--space-4); }

.template-card {
  background: var(--color-surface);
  border: 1px solid var(--color-border-light);
  border-radius: var(--radius-md);
  padding: var(--space-5);
  cursor: pointer;
  transition: border-color var(--transition), box-shadow var(--transition);
  display: flex; flex-direction: column; gap: var(--space-3);
}
.template-card:hover { border-color: var(--color-accent); box-shadow: var(--shadow-sm); }
.template-card--global { border-left: 3px solid var(--color-accent); }

.tc-header { display: flex; align-items: center; justify-content: space-between; }
.tc-icon { font-size: 1.4rem; }
.tc-badge { font-size: 0.65rem; font-weight: 700; padding: 2px 7px; border-radius: 10px; text-transform: uppercase; letter-spacing: 0.5px; }
.tc-badge--global { background: rgba(15,52,96,0.1); color: var(--color-accent); }

.tc-manufacturer { font-size: 0.72rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--color-text-muted); }
.tc-model { font-size: 1rem; font-weight: 600; color: var(--color-primary); line-height: 1.3; }
.tc-category { font-size: 0.78rem; }

.tc-footer { display: flex; align-items: center; justify-content: space-between; gap: var(--space-2); margin-top: auto; }
.tc-count { font-size: 0.72rem; color: var(--color-text-muted); }
.tc-count--active { color: var(--color-success); font-weight: 600; }
.tc-tags { display: flex; gap: var(--space-1); flex-wrap: wrap; }
.tag-pill { font-size: 0.62rem; background: var(--color-surface-2); border: 1px solid var(--color-border-light); border-radius: 10px; padding: 1px 6px; color: var(--color-text-muted); }
.tag-pill--lg { font-size: 0.72rem; padding: 2px 8px; }

.tc-actions { display: flex; gap: var(--space-1); }
.tc-btn { width: 22px; height: 22px; background: var(--color-surface-2); border: 1px solid var(--color-border); border-radius: var(--radius-sm); cursor: pointer; font-size: 0.7rem; color: var(--color-text-muted); display: flex; align-items: center; justify-content: center; }
.tc-btn:hover { background: var(--color-border-light); color: var(--color-text); }
.tc-btn--del:hover { color: var(--color-alert); }

.empty-state { text-align: center; padding: var(--space-10); color: var(--color-text-muted); font-size: 0.875rem; }

/* Detail modal */
.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; padding: var(--space-4); }
.detail-modal { background: var(--color-surface); border-radius: var(--radius-lg); width: 100%; max-width: 600px; max-height: 90vh; display: flex; flex-direction: column; box-shadow: var(--shadow-lg); }
.modal-header { display: flex; justify-content: space-between; align-items: flex-start; padding: var(--space-5) var(--space-6); border-bottom: 1px solid var(--color-border-light); }
.detail-badge-row { display: flex; gap: var(--space-2); margin-bottom: var(--space-2); }
.global-badge { font-size: 0.65rem; font-weight: 700; background: rgba(15,52,96,0.1); color: var(--color-accent); padding: 2px 8px; border-radius: 10px; text-transform: uppercase; }
.category-badge { font-size: 0.65rem; font-weight: 600; background: var(--color-surface-2); color: var(--color-text-muted); padding: 2px 8px; border-radius: 10px; }
.detail-manufacturer { font-size: 0.78rem; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; color: var(--color-text-muted); margin-bottom: 3px; }
.detail-model { font-size: 1.2rem; font-weight: 700; color: var(--color-primary); }
.modal-close { background: none; border: none; font-size: 1rem; cursor: pointer; color: var(--color-text-muted); }
.modal-body { flex: 1; overflow-y: auto; padding: var(--space-5) var(--space-6); display: flex; flex-direction: column; gap: var(--space-5); }

.detail-desc { font-size: 0.875rem; color: var(--color-text-muted); background: var(--color-surface-2); border-radius: var(--radius-md); padding: var(--space-4); line-height: 1.7; }
.detail-tags { display: flex; gap: var(--space-2); flex-wrap: wrap; }
.detail-section-title { font-size: 0.72rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--color-text-muted); display: flex; align-items: center; gap: var(--space-2); }
.count-badge { background: var(--color-surface-2); border: 1px solid var(--color-border-light); border-radius: 10px; font-size: 0.65rem; padding: 1px 6px; }

.nodes-empty { font-size: 0.82rem; color: var(--color-text-muted); background: var(--color-surface-2); border-radius: var(--radius-md); padding: var(--space-4); line-height: 1.7; text-align: center; }
.nodes-list { display: flex; flex-direction: column; gap: var(--space-2); }
.node-row { display: flex; align-items: center; gap: var(--space-3); padding: var(--space-2) var(--space-3); background: var(--color-surface-2); border-radius: var(--radius); }
.node-name { flex: 1; font-size: 0.82rem; font-weight: 500; }
.node-code { font-size: 0.72rem; }
.crit-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
.node-status { font-size: 0.72rem; }

.ai-info-box { display: flex; gap: var(--space-3); padding: var(--space-4); background: rgba(15,52,96,0.05); border: 1px solid rgba(15,52,96,0.15); border-radius: var(--radius-md); }
.ai-info-icon { font-size: 1.2rem; flex-shrink: 0; margin-top: 2px; }
.ai-info-text { font-size: 0.82rem; color: var(--color-text-muted); line-height: 1.6; }
.ai-info-text strong { color: var(--color-accent); }

/* Form modal */
.create-modal { background: var(--color-surface); border-radius: var(--radius-lg); width: 100%; max-width: 560px; box-shadow: var(--shadow-lg); }
.modal-footer { display: flex; justify-content: flex-end; gap: var(--space-3); padding: var(--space-4) var(--space-6); border-top: 1px solid var(--color-border-light); }
.modal-error { background: rgba(233,69,96,0.08); border: 1px solid rgba(233,69,96,0.3); border-radius: var(--radius); padding: var(--space-3); font-size: 0.875rem; color: var(--color-alert); }
.field { display: flex; flex-direction: column; gap: var(--space-2); flex: 1; }
.field-row { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-3); }
.field-label { font-size: 0.68rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); }
.field-input { padding: 0 var(--space-3); height: 38px; border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; background: var(--color-surface); outline: none; width: 100%; }
.field-input:focus { border-color: var(--color-accent); }
textarea.field-input { height: auto; padding: var(--space-2) var(--space-3); resize: vertical; font-family: var(--font-ui); }
.field-hint { font-size: 0.72rem; color: var(--color-text-muted); }
.btn-primary { height: 38px; padding: 0 var(--space-5); background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); font-size: 0.875rem; font-weight: 500; cursor: pointer; }
.btn-primary:hover:not(:disabled) { background: var(--color-accent); }
.btn-primary:disabled { opacity: 0.65; cursor: not-allowed; }
.btn-secondary { height: 38px; padding: 0 var(--space-5); background: var(--color-surface-2); color: var(--color-text); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; cursor: pointer; }
.modal-body { padding: var(--space-5) var(--space-6); display: flex; flex-direction: column; gap: var(--space-4); }
.mono { font-family: var(--font-mono); }
.text-muted { color: var(--color-text-muted); }

/* Detail tabs */
.detail-tabs { display: flex; gap: 0; border-bottom: 1px solid var(--color-border-light); margin: calc(-1 * var(--space-4)) calc(-1 * var(--space-6)) var(--space-4); padding: 0 var(--space-6); }
.detail-tab { background: none; border: none; padding: var(--space-3) var(--space-4); font-size: 0.82rem; font-weight: 500; color: var(--color-text-muted); cursor: pointer; border-bottom: 2px solid transparent; transition: all var(--transition); }
.detail-tab:hover { color: var(--color-text); }
.detail-tab--active { color: var(--color-accent); border-bottom-color: var(--color-accent); }

/* Template library */
.lib-nav { display: flex; align-items: center; gap: var(--space-2); flex-wrap: wrap; }
.btn-back { background: none; border: 1px solid var(--color-border); border-radius: var(--radius-sm); padding: 2px 8px; font-size: 0.72rem; cursor: pointer; color: var(--color-accent); }
.folder-chip { font-size: 0.72rem; padding: 3px 8px; border-radius: var(--radius-sm); background: var(--color-surface-2); border: 1px solid var(--color-border-light); cursor: pointer; }
.folder-chip:hover { border-color: var(--color-accent); }
.folder-chip--active { background: rgba(15,52,96,0.08); border-color: var(--color-accent); color: var(--color-accent); font-weight: 600; }
.lib-actions { display: flex; gap: var(--space-2); }
.btn-upload { display: inline-flex; align-items: center; height: 30px; padding: 0 var(--space-3); background: var(--color-primary); color: #fff; border-radius: var(--radius); font-size: 0.75rem; font-weight: 500; cursor: pointer; }
.btn-sm { height: 30px; font-size: 0.75rem; padding: 0 var(--space-3); }
.folder-form { display: flex; gap: var(--space-2); align-items: center; }
.field-input--sm { height: 30px; font-size: 0.8rem; }
.lib-list { display: flex; flex-direction: column; gap: var(--space-2); }
.lib-card { display: flex; align-items: center; gap: var(--space-3); padding: var(--space-2) var(--space-3); background: var(--color-surface-2); border-radius: var(--radius); border: 1px solid var(--color-border-light); }
.lib-icon { font-size: 1rem; flex-shrink: 0; width: 24px; text-align: center; }
.lib-info { flex: 1; display: flex; flex-direction: column; min-width: 0; }
.lib-name { font-size: 0.82rem; font-weight: 500; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.lib-meta { font-size: 0.68rem; }
.btn-unlink { width: 22px; height: 22px; background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius-sm); cursor: pointer; font-size: 0.7rem; color: var(--color-text-muted); display: flex; align-items: center; justify-content: center; }
.btn-unlink:hover { color: var(--color-alert); }

/* Compositions section */
.comp-section { margin-top: var(--space-4); padding-top: var(--space-6); border-top: 2px solid var(--color-border-light); }
.page-header--sub { margin-bottom: var(--space-4); }
.page-title--sub { font-size: 1.15rem; }
.template-card--comp { border-left: 3px solid #8E44AD; }
.btn-apply { font-size: 0.72rem; padding: 2px 10px; background: var(--color-surface); border: 1px solid var(--color-accent); border-radius: var(--radius-sm); color: var(--color-accent); cursor: pointer; font-weight: 500; }
.btn-apply:hover { background: rgba(15,52,96,0.06); }

/* Node picker */
.node-picker-results { max-height: 200px; overflow-y: auto; border: 1px solid var(--color-border); border-radius: var(--radius); margin-top: var(--space-1); }
.node-picker-item { padding: var(--space-2) var(--space-3); font-size: 0.82rem; cursor: pointer; }
.node-picker-item:hover { background: var(--color-surface-2); }
.node-picker-item--active { background: rgba(15,52,96,0.08); }
.selected-node-badge { display: inline-flex; align-items: center; gap: var(--space-2); margin-top: var(--space-2); padding: var(--space-2) var(--space-3); background: rgba(15,52,96,0.06); border: 1px solid var(--color-accent); border-radius: var(--radius); font-size: 0.82rem; font-weight: 500; color: var(--color-accent); }

/* Clone section in the detail view */
.clone-section { padding: var(--space-4); background: var(--color-surface-2); border-radius: var(--radius-md); }
.clone-hint { font-size: 0.78rem; margin-bottom: var(--space-2); line-height: 1.5; }

/* Slots in the form/detail view */
.slots-list { display: flex; flex-direction: column; gap: var(--space-2); margin-bottom: var(--space-2); }
.slot-row { display: flex; gap: var(--space-2); align-items: center; }
.slot-role { flex: 1; }
.slot-type { flex: 1; }
.slots-preview { display: flex; flex-direction: column; gap: var(--space-1); }
.slot-preview-item { display: flex; justify-content: space-between; padding: var(--space-2) var(--space-3); background: var(--color-surface-2); border-radius: var(--radius); font-size: 0.82rem; }
.slot-preview-role { font-weight: 600; }
.slot-preview-type { font-size: 0.78rem; }
.small { font-size: 0.75rem; }

@media (max-width: 768px) {
  .page-header { flex-direction: column; gap: var(--space-3); }
  .page-title { font-size: 1.15rem; }
  .header-actions { width: 100%; flex-wrap: wrap; }
  .templates-table, .comp-table { font-size: 0.78rem; }
  .templates-table th, .templates-table td,
  .comp-table th, .comp-table td { padding: var(--space-2); }

  .modal-overlay { padding: 0; }
  .create-modal { max-width: 100%; border-radius: 0; max-height: 100vh; max-height: 100dvh; overflow-y: auto; }
  .modal-body { padding: var(--space-4); }
  .field-row { grid-template-columns: 1fr; }
  .field-input { height: 42px; }
  .btn-primary, .btn-secondary { height: 44px; font-size: 0.9rem; }
  .slot-row { flex-wrap: wrap; }
  .slot-role, .slot-type { flex: 1; min-width: 120px; }
}
</style>
