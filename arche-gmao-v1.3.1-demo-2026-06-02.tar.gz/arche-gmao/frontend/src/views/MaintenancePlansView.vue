<template>
  <div class="mplans-layout">
    <div class="page-header">
      <div>
        <h1 class="page-title">Plan de Mantenimiento Preventivo</h1>
        <p class="page-sub">Programación automática de OTs recurrentes por equipo</p>
      </div>
      <div class="header-actions">
        <button class="btn-secondary" @click="loadCompliance">&#x21BA; Actualizar</button>
        <button v-if="canManage" class="btn-primary" @click="openCreate" :disabled="!canWrite">+ Nuevo plan</button>
      </div>
    </div>

    <!-- Collapsible manual -->
    <div class="guide-section" :class="{ 'guide-section--open': showGuide }">
      <button class="guide-toggle" @click="showGuide = !showGuide">
        <span class="guide-icon">{{ showGuide ? '&#x25BE;' : '&#x25B8;' }}</span>
        Guia de mantenimiento preventivo
        <span class="guide-hint">{{ showGuide ? 'Ocultar' : 'Mostrar manual' }}</span>
      </button>
      <div v-if="showGuide" class="guide-content">

        <div class="guide-block">
          <h4 class="guide-title">1. Crear un plan</h4>
          <ol class="guide-steps">
            <li>Pulsa <strong>"+ Nuevo plan"</strong>. Si tienes plantillas guardadas, el sistema te ofrecera usarlas o crear desde cero.</li>
            <li>Elige el <strong>destino</strong>: un equipo especifico o un tipo de equipo (fabricante/modelo). Si eliges tipo de equipo, el plan aplicara a todos los equipos de ese modelo.</li>
            <li>Completa el <strong>título</strong>, la <strong>frecuencia</strong> (días, semanas o meses) y los <strong>días de anticipación</strong>.</li>
            <li>Opcionalmente configura: técnico asignado, horas estimadas, prioridad, tipo de OT, fecha de primera ejecución y si aplica a equipos hijos.</li>
            <li>Pulsa <strong>"Crear"</strong>. El plan quedara activo inmediatamente.</li>
          </ol>
        </div>

        <div class="guide-block">
          <h4 class="guide-title">2. Secciones del plan</h4>
          <p class="guide-text">Además de los datos básicos, cada plan tiene secciones opcionales que se incluyen automáticamente en la OT generada:</p>
          <ul class="guide-list">
            <li><strong>Procedimiento:</strong> instrucciones paso a paso de como realizar el mantenimiento.</li>
            <li><strong>Lista de verificación:</strong> pasos que el técnico debe completar. Los marcados como "obligatorio" no se pueden omitir.</li>
            <li><strong>Seguridad:</strong> notas sobre EPP, precauciones y permisos de trabajo necesarios.</li>
            <li><strong>Herramientas:</strong> lista de herramientas que el técnico necesitará.</li>
            <li><strong>Repuestos:</strong> piezas del inventario que se consumiran, con la cantidad necesaria de cada una.</li>
          </ul>
        </div>

        <div class="guide-block">
          <h4 class="guide-title">3. Frecuencia y anticipacion</h4>
          <p class="guide-text">La <strong>frecuencia</strong> define cada cuánto se repite (ej. "30 días", "2 semanas", "3 meses"). El sistema mantiene la cadencia original incluso si una ejecución se retrasa.</p>
          <p class="guide-text">Los <strong>días de anticipación</strong> indican cuántos días ANTES de la fecha de vencimiento se genera la OT. Valor por defecto: 3 días. Esto da tiempo al técnico para planificar.</p>
        </div>

        <div class="guide-block">
          <h4 class="guide-title">4. Generacion de OTs</h4>
          <ul class="guide-list">
            <li><strong>Automática:</strong> el sistema revisa cada hora los planes activos. Cuando se alcanza la anticipación, genera la OT con prefijo [PM] y la asigna al técnico configurado.</li>
            <li><strong>Manual:</strong> pulsa &#x25B6; en la tabla para generar la OT inmediatamente, sin esperar a la hora programada.</li>
          </ul>
        </div>

        <div class="guide-block">
          <h4 class="guide-title">5. Ciclo completo</h4>
          <ol class="guide-steps">
            <li>Se crea el plan con frecuencia y anticipacion.</li>
            <li>El sistema calcula la primera fecha de vencimiento.</li>
            <li>Al alcanzar la anticipación, se genera la OT [PM] automáticamente.</li>
            <li>El técnico ejecuta y completa la OT. Su firma digital se registra automáticamente.</li>
            <li>El supervisor cierra la OT. Su firma digital se registra automáticamente.</li>
            <li>El sistema recalcula la siguiente fecha de vencimiento.</li>
            <li>El ciclo se repite mientras el plan este activo.</li>
          </ol>
        </div>

        <div class="guide-block">
          <h4 class="guide-title">6. Plantillas</h4>
          <p class="guide-text">Puedes <strong>guardar un plan existente como plantilla</strong> para reutilizarlo. Al crear un nuevo plan, el sistema ofrece cargar una plantilla guardada que pre-llena todos los campos. Util para planes que se repiten en varios equipos.</p>
        </div>

        <div class="guide-block">
          <h4 class="guide-title">7. Aplicar a equipos hijos</h4>
          <p class="guide-text">Activa esta opcion para generar una OT individual por cada equipo descendiente del nodo seleccionado. Ideal para planes en lineas o areas que aplican a todos los equipos debajo.</p>
        </div>

        <div class="guide-block">
          <h4 class="guide-title">8. Indicadores</h4>
          <p class="guide-text">Las 4 tarjetas superiores muestran: planes activos, vencidos, porcentaje de cumplimiento y ejecutados este mes. Cada OT preventiva crea además un evento en el Calendario.</p>
        </div>

        <div class="guide-block">
          <h4 class="guide-title">9. IA y manuales</h4>
          <p class="guide-text">Sube manuales del fabricante (PDF/TXT) desde la pestaña "Preventivo" de cada equipo en la Fábrica Virtual. La IA de Arche analiza los manuales, planes activos e historial de ejecuciones para dar recomendaciones y diagnósticos más precisos.</p>
        </div>

      </div>
    </div>

    <!-- Staggered maintenance -->
    <div v-if="canManageStagger" class="stagger-section" :class="{ 'stagger-section--open': showStagger }">
      <button class="stagger-toggle" @click="showStagger = !showStagger">
        <span class="stagger-toggle-icon">{{ showStagger ? '&#x25BE;' : '&#x25B8;' }}</span>
        Mantenimiento escalonado
        <span v-if="activeConfig" class="stagger-status stagger-status--active">Activo</span>
        <span v-else class="stagger-status">Inactivo</span>
        <span class="stagger-hint">{{ showStagger ? 'Ocultar' : 'Configurar distribución automática' }}</span>
      </button>

      <div v-if="showStagger" class="stagger-body">
        <!-- Subtabs -->
        <div class="stagger-tabs">
          <button
            v-for="tab in STAGGER_TABS"
            :key="tab.key"
            class="stagger-tab"
            :class="{ 'stagger-tab--active': staggerTab === tab.key }"
            @click="staggerTab = tab.key"
          >{{ tab.label }}</button>
        </div>

        <!-- Tab: Configuration -->
        <div v-if="staggerTab === 'config'" class="stagger-panel">
          <p class="stagger-desc">
            Distribuye las OTs preventivas de forma uniforme en el periodo seleccionado, respetando la carga máxima por técnico y priorizando equipos críticos.
          </p>

          <div class="stagger-form">
            <div class="stagger-form-row">
              <div class="field">
                <label class="field-label">Ambito</label>
                <select v-model="staggerForm.scope" class="field-input" @change="onScopeChange">
                  <option value="global">Global (toda la planta)</option>
                  <option value="area">Por area</option>
                  <option value="line">Por linea</option>
                </select>
              </div>
              <div v-if="staggerForm.scope !== 'global'" class="field">
                <label class="field-label">Nodo raiz</label>
                <select v-model="staggerForm.scope_node_id" class="field-input">
                  <option :value="null">Seleccionar...</option>
                  <option
                    v-for="n in scopeNodes"
                    :key="n.id"
                    :value="n.id"
                  >{{ n.name }}{{ n.code ? ` (${n.code})` : '' }}</option>
                </select>
              </div>
            </div>
            <div class="stagger-form-row">
              <div class="field">
                <label class="field-label">Periodo</label>
                <select v-model="staggerForm.period" class="field-input">
                  <option value="weekly">Semanal (7 días)</option>
                  <option value="biweekly">Quincenal (14 días)</option>
                  <option value="monthly">Mensual (30 días)</option>
                </select>
              </div>
              <div class="field">
                <label class="field-label">Máx OTs/técnico/día</label>
                <input v-model.number="staggerForm.max_daily_per_tech" type="number" min="1" max="20"
                  class="field-input mono" />
              </div>
            </div>

            <div class="stagger-actions">
              <button class="btn-secondary" :disabled="!canWrite || staggerSaving" @click="saveStaggerConfig">
                {{ staggerSaving ? 'Guardando...' : (staggerForm.id ? 'Actualizar config' : 'Crear config') }}
              </button>
              <button
                v-if="staggerForm.id && staggerForm.is_active"
                class="btn-primary"
                :disabled="!canWrite || staggerPreviewing"
                @click="loadPreview"
              >
                {{ staggerPreviewing ? 'Calculando...' : 'Previsualizar distribución' }}
              </button>
            </div>

            <!-- Enable/disable toggle — isPrimaryAdmin or isSuperadmin only -->
            <div v-if="staggerForm.id && canToggleStagger" class="stagger-toggle-active">
              <label class="toggle-label">
                <input type="checkbox" v-model="staggerForm.is_active" @change="saveStaggerConfig" :disabled="!canWrite" />
                <span class="toggle-text">{{ staggerForm.is_active ? 'Escalonado activo' : 'Escalonado desactivado' }}</span>
              </label>
            </div>
          </div>

          <div v-if="staggerError" class="stagger-error">{{ staggerError }}</div>

          <!-- Preview -->
          <div v-if="staggerPreview" class="stagger-preview-wrap">
            <div class="stagger-preview-header">
              <h4 class="stagger-preview-title">Previsualizacion del ciclo</h4>
              <button
                class="btn-primary btn-apply"
                :disabled="!canWrite || staggerApplying || !staggerPreview.total_planned"
                @click="applyStagger"
              >
                {{ staggerApplying ? 'Aplicando...' : 'Confirmar y aplicar' }}
              </button>
            </div>
            <StaggeringPreview :preview="staggerPreview" />
          </div>
        </div>

        <!-- Tab: Active schedule -->
        <div v-if="staggerTab === 'schedule'" class="stagger-panel">
          <div v-if="!activeSchedule || !activeSchedule.cycle" class="stagger-empty">
            No hay ningun ciclo activo de escalonado.
          </div>
          <div v-else>
            <div class="schedule-meta">
              <span><strong>Ciclo:</strong> {{ formatDate(activeSchedule.cycle.cycle_start) }} &#x2192; {{ formatDate(activeSchedule.cycle.cycle_end) }}</span>
              <span><strong>Estado:</strong>
                <span class="cycle-status" :class="`cycle-status--${activeSchedule.cycle.status}`">{{ CYCLE_STATUS_LABELS[activeSchedule.cycle.status] }}</span>
              </span>
              <span><strong>Planificadas:</strong> {{ activeSchedule.cycle.total_planned }}</span>
              <span><strong>Ejecutadas:</strong> {{ activeSchedule.cycle.total_executed }}</span>
              <span v-if="activeSchedule.cycle.total_rescheduled"><strong>Reescalonadas:</strong> {{ activeSchedule.cycle.total_rescheduled }}</span>
            </div>

            <table class="schedule-table">
              <thead>
                <tr>
                  <th>Fecha</th>
                  <th>Equipo</th>
                  <th>Plan</th>
                  <th>Técnico</th>
                  <th>Estado</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="e in activeSchedule.entries" :key="e.id"
                  :class="{
                    'schedule-row--done': e.status === 'completed',
                    'schedule-row--rescheduled': e.status === 'rescheduled'
                  }">
                  <td class="mono">
                    {{ formatShortDate(e.scheduled_date) }}
                    <span v-if="e.rescheduled_from" class="rescheduled-from" title="Fecha original">
                      &#x2190; {{ formatShortDate(e.rescheduled_from) }}
                    </span>
                  </td>
                  <td>
                    <span class="entry-node">{{ e.node_name }}</span>
                    <span v-if="e.node_code" class="entry-code mono">{{ e.node_code }}</span>
                  </td>
                  <td>{{ e.plan_title }}</td>
                  <td class="text-muted">{{ e.technician_name || '&#x2014;' }}</td>
                  <td>
                    <span class="entry-status" :class="`entry-status--${e.status}`">
                      {{ ENTRY_STATUS_LABELS[e.status] }}
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <!-- Tab: History -->
        <div v-if="staggerTab === 'history'" class="stagger-panel">
          <div v-if="!staggerCycles.length" class="stagger-empty">
            No hay ciclos de escalonado registrados.
          </div>
          <div v-else>
            <table class="cycles-table">
              <thead>
                <tr>
                  <th>Periodo</th>
                  <th>Ambito</th>
                  <th>Planificadas</th>
                  <th>Ejecutadas</th>
                  <th>Reescalonadas</th>
                  <th>Cumplimiento</th>
                  <th>Estado</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="cy in staggerCycles" :key="cy.id" class="cycle-row" @click="loadCycleSchedule(cy.id)">
                  <td class="mono">{{ formatShortDate(cy.cycle_start) }} &#x2192; {{ formatShortDate(cy.cycle_end) }}</td>
                  <td>{{ SCOPE_LABELS[cy.scope] }} &#x00B7; {{ PERIOD_LABELS[cy.period] }}</td>
                  <td class="mono text-right">{{ cy.total_planned }}</td>
                  <td class="mono text-right">{{ cy.total_executed }}</td>
                  <td class="mono text-right">{{ cy.total_rescheduled }}</td>
                  <td>
                    <div class="compliance-cell">
                      <span class="mono" :class="{
                        'text-success': cy.compliance_pct >= 80,
                        'text-warning': cy.compliance_pct >= 50 && cy.compliance_pct < 80,
                        'text-alert': cy.compliance_pct < 50
                      }">{{ cy.compliance_pct }}%</span>
                      <div class="mini-bar">
                        <div class="mini-bar-fill" :style="{
                          width: cy.compliance_pct + '%',
                          background: cy.compliance_pct >= 80 ? '#27AE60' : cy.compliance_pct >= 50 ? '#F39C12' : '#E94560'
                        }"></div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <span class="cycle-status" :class="`cycle-status--${cy.status}`">{{ CYCLE_STATUS_LABELS[cy.status] }}</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

    <!-- Compliance KPIs -->
    <div class="compliance-grid" v-if="compliance">
      <div class="comp-card">
        <span class="comp-value">{{ compliance.active_plans }}</span>
        <span class="comp-label">Planes activos</span>
      </div>
      <div class="comp-card" :class="{ 'comp-card--alert': compliance.overdue_count > 0 }">
        <span class="comp-value" :class="{ 'text-alert': compliance.overdue_count > 0 }">
          {{ compliance.overdue_count }}
        </span>
        <span class="comp-label">Vencidos</span>
      </div>
      <div class="comp-card">
        <span class="comp-value">{{ compliance.compliance_rate?.toFixed(1) }}%</span>
        <span class="comp-label">Cumplimiento</span>
        <div class="comp-bar">
          <div class="comp-bar-fill"
            :style="{ width: compliance.compliance_rate + '%',
                      background: compliance.compliance_rate >= 80 ? 'var(--color-success)' : 'var(--color-alert)' }">
          </div>
        </div>
      </div>
      <div class="comp-card">
        <span class="comp-value">{{ compliance.last_month_executions }}</span>
        <span class="comp-label">Ejecutados este mes</span>
      </div>
    </div>

    <!-- Upcoming due dates -->
    <div class="card" v-if="upcoming.length">
      <div class="card-header">
        <span class="card-title">Próximos 30 días</span>
      </div>
      <div class="upcoming-list">
        <div v-for="u in upcoming" :key="u.plan_id" class="upcoming-item"
          :class="getDueSeverity(u.days_until_due)">
          <div class="upcoming-days">
            <span class="days-num">{{ u.days_until_due ?? '!' }}</span>
            <span class="days-label">dias</span>
          </div>
          <div class="upcoming-info">
            <span class="upcoming-title">{{ u.title }}</span>
            <span class="upcoming-node text-muted">{{ u.node_name }}{{ u.node_code ? ` (${u.node_code})` : '' }}</span>
          </div>
          <div class="upcoming-meta">
            <span class="crit-dot" :style="{ background: CRIT_COLORS[u.criticality] }"></span>
            <span class="upcoming-assigned text-muted">{{ u.assigned_name ?? 'Sin asignar' }}</span>
            <span class="upcoming-date mono text-muted">{{ formatDate(u.next_due_at) }}</span>
          </div>
          <button v-if="canManage" class="btn-execute" @click="executePlan(u.plan_id)"
            title="Generar OT ahora">&#x25B6; Generar OT</button>
        </div>
      </div>
    </div>

    <!-- Success: offer to save as template -->
    <div v-if="showSaveTemplateOffer" class="save-template-offer">
      <span class="save-template-text">Plan creado.</span>
      <button class="btn-text" @click="saveNewPlanAsTemplate">Guardar como plantilla para reutilizar?</button>
      <button class="save-template-dismiss" @click="showSaveTemplateOffer = false">&#x2715;</button>
    </div>

    <!-- List of every plan -->
    <div class="card">
      <div class="card-header">
        <span class="card-title">Todos los planes</span>
        <div class="header-filters">
          <input v-model="searchQuery" class="search-input" placeholder="Buscar plan..." />
          <select v-model="filterActive" class="filter-select" @change="loadPlans">
            <option value="true">Activos</option>
            <option value="false">Todos</option>
          </select>
        </div>
      </div>
      <EmptyState
        v-if="!plans.length"
        icon="◷"
        title="Sin planes de mantenimiento preventivo"
        hint="Crea el primer plan para que el sistema genere OTs preventivas automáticamente."
        :action="canWrite ? '+ Nuevo plan' : undefined"
        size="sm"
        @action="openCreate" />
      <EmptyState
        v-else-if="!filteredPlans.length"
        icon="◇"
        title="Ningún plan coincide con la búsqueda"
        hint="Prueba a quitar filtros o cambiar el término."
        size="sm" />
      <div v-else class="plans-table-wrap">
        <table class="plans-table">
          <thead>
            <tr>
              <th>Equipo</th>
              <th>Plan</th>
              <th>Frecuencia</th>
              <th>Tipo</th>
              <th>Próxima ejecución</th>
              <th>Asignado</th>
              <th>Ejecuciones</th>
              <th v-if="canManage"></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="p in filteredPlans" :key="p.id" class="plan-row"
              :class="{ 'plan-row--overdue': p.days_until_due !== null && p.days_until_due < 0 }"
              @click="openDetail(p.id)" style="cursor:pointer">
              <td>
                <template v-if="p.node_name">
                  <span class="node-name">{{ p.node_name }}</span>
                  <span v-if="p.node_code" class="node-code mono text-muted">{{ p.node_code }}</span>
                </template>
                <template v-else-if="p.template_manufacturer">
                  <span class="node-name">{{ p.template_manufacturer }} {{ p.template_model }}</span>
                  <span class="plan-badge plan-badge--template">Tipo</span>
                </template>
                <template v-else>
                  <span class="text-muted">&mdash;</span>
                </template>
              </td>
              <td class="plan-title">
                {{ p.title }}
                <div class="plan-badges">
                  <span v-if="p.has_instructions" class="plan-badge" title="Con procedimiento">&#x2630;</span>
                  <span v-if="p.checklist_count > 0" class="plan-badge" title="Lista de verificación">&#x2611; {{ p.checklist_count }}</span>
                  <span v-if="p.apply_to_children" class="plan-badge plan-badge--children" title="Aplica a hijos">&#x25BC; Hijos</span>
                </div>
              </td>
              <td class="mono small">{{ p.frequency_value }} {{ FREQ_LABELS[p.frequency_type] }}</td>
              <td>
                <span class="type-pill" :class="`type-pill--${p.wo_type}`">
                  {{ WO_TYPE_LABELS[p.wo_type] }}
                </span>
              </td>
              <td>
                <span v-if="p.next_due_at" class="due-cell">
                  <span class="due-dot"
                    :class="p.days_until_due !== null && p.days_until_due <= 0 ? 'due-dot--overdue'
                      : p.days_until_due !== null && p.days_until_due <= 7 ? 'due-dot--soon'
                      : 'due-dot--ok'"
                    :title="p.days_until_due !== null && p.days_until_due <= 0 ? 'Vencido'
                      : p.days_until_due !== null && p.days_until_due <= 7 ? 'Proximo'
                      : 'Al dia'"></span>
                  <span class="mono small"
                    :class="{ 'text-alert': p.days_until_due !== null && p.days_until_due < 0,
                               'text-warning': p.days_until_due !== null && p.days_until_due <= 7 && p.days_until_due >= 0 }">
                    {{ formatDate(p.next_due_at) }}
                    <span v-if="p.days_until_due !== null">
                      ({{ p.days_until_due < 0 ? `${Math.abs(p.days_until_due)}d vencido` : `en ${p.days_until_due}d` }})
                    </span>
                  </span>
                </span>
                <span v-else class="text-muted">&mdash;</span>
              </td>
              <td class="text-muted small">{{ p.assigned_name ?? '&mdash;' }}</td>
              <td class="mono small text-right">{{ p.total_executions }}</td>
              <td v-if="canManage" @click.stop>
                <div class="row-actions">
                  <button class="action-btn" @click="openEdit(p)">&#x270E;</button>
                  <button class="action-btn action-btn--exec" @click="executePlan(p.id)"
                    title="Generar OT ahora">&#x25B6;</button>
                  <button class="action-btn action-btn--del" @click="deletePlan(p.id)">&#x2715;</button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Plan detail panel -->
    <Teleport to="body">
      <div v-if="showDetail && detailPlan" class="modal-overlay" @click.self="showDetail = false">
        <div class="detail-modal">
          <div class="modal-header">
            <h3>{{ detailPlan.title }}</h3>
            <button class="modal-close" @click="showDetail = false">&#x2715;</button>
          </div>
          <div class="modal-body">
            <div class="detail-meta">
              <span><strong>Equipo:</strong> {{ detailPlan.node_name }}</span>
              <span v-if="detailPlan.template_manufacturer"><strong>Tipo equipo:</strong> {{ detailPlan.template_manufacturer }} {{ detailPlan.template_model }}</span>
              <span><strong>Frecuencia:</strong> {{ detailPlan.frequency_value }} {{ FREQ_LABELS[detailPlan.frequency_type] }}</span>
              <span><strong>Proxima:</strong> {{ formatDate(detailPlan.next_due_at ?? '') }}</span>
              <span v-if="detailPlan.assigned_name"><strong>Asignado:</strong> {{ detailPlan.assigned_name }}</span>
              <span v-if="detailPlan.apply_to_children" class="plan-badge plan-badge--children">Aplica a equipos hijos</span>
            </div>

            <div v-if="detailPlan.description" class="detail-section">
              <h4 class="detail-section-title">Descripción</h4>
              <p class="detail-text">{{ detailPlan.description }}</p>
            </div>

            <div v-if="detailPlan.instructions" class="detail-section">
              <h4 class="detail-section-title">Procedimiento</h4>
              <pre class="detail-pre">{{ detailPlan.instructions }}</pre>
            </div>

            <div v-if="detailPlan.checklist?.length" class="detail-section">
              <h4 class="detail-section-title">Lista de verificación</h4>
              <ul class="detail-checklist">
                <li v-for="(item, i) in detailPlan.checklist" :key="i" :class="{ 'checklist--required': item.required }">
                  <span class="check-marker">{{ item.required ? '[*]' : '[ ]' }}</span>
                  {{ item.step }}
                  <span v-if="item.required" class="check-req">(obligatorio)</span>
                </li>
              </ul>
            </div>

            <div v-if="detailPlan.safety_notes" class="detail-section">
              <h4 class="detail-section-title">Notas de seguridad</h4>
              <p class="detail-text detail-text--safety">{{ detailPlan.safety_notes }}</p>
            </div>

            <div v-if="detailPlan.tools_required?.length" class="detail-section">
              <h4 class="detail-section-title">Herramientas necesarias</h4>
              <div class="detail-chips">
                <span v-for="t in detailPlan.tools_required" :key="t" class="detail-chip">{{ t }}</span>
              </div>
            </div>

            <div v-if="detailPlan.required_parts?.length" class="detail-section">
              <h4 class="detail-section-title">Repuestos necesarios</h4>
              <table class="parts-mini-table">
                <tr v-for="p in detailPlan.required_parts" :key="p.code">
                  <td>{{ p.name }}</td>
                  <td class="mono text-muted">{{ p.code }}</td>
                  <td class="mono text-right">x{{ p.quantity || 1 }}</td>
                </tr>
              </table>
            </div>

            <div v-if="detailPlan && (detailPlan.apply_to_children || detailPlan.equipment_template_id)" class="detail-section">
              <h4 class="detail-section-title">Exclusiones de nodos</h4>
              <div v-if="detailExclusions.length" class="exclusion-list">
                <div v-for="ex in detailExclusions" :key="ex.id" class="exclusion-item">
                  <span>{{ ex.node_name }}{{ ex.node_code ? ` (${ex.node_code})` : '' }}</span>
                  <button v-if="canManage" class="action-btn action-btn--del" @click="removeExclusion(detailPlan.id, ex.node_id)">&#x2715;</button>
                </div>
              </div>
              <div v-else class="text-muted small">Sin exclusiones. Todos los nodos descendientes reciben este plan.</div>
            </div>

            <div v-if="detailExecs.length" class="detail-section">
              <h4 class="detail-section-title">Historial de ejecuciones (últimas 20)</h4>
              <div class="exec-list">
                <div v-for="e in detailExecs" :key="e.id" class="exec-item">
                  <span class="small" :title="formatDate(e.executed_at)">{{ formatSmart(e.executed_at) }}</span>
                  <span v-if="e.wo_number" class="mono small text-muted">{{ e.wo_number }}</span>
                  <span v-if="e.target_node_name" class="small text-muted">&#x2192; {{ e.target_node_name }}</span>
                  <span v-if="e.notes" class="small text-muted">{{ e.notes }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Create/edit plan modal -->
    <Teleport to="body">
      <div v-if="showForm" class="modal-overlay" @click.self="showForm = false">
        <div class="plan-modal">
          <div class="modal-header">
            <h3>{{ editPlan ? 'Editar plan' : 'Nuevo plan de mantenimiento' }}</h3>
            <div class="template-actions">
              <button type="button" class="btn-text" @click="showLoadTemplate = true" title="Cargar desde plantilla">
                &#x21E9; Cargar plantilla
              </button>
              <button v-if="editPlan" type="button" class="btn-text" @click="saveAsTemplate" title="Guardar como plantilla">
                &#x21E7; Guardar plantilla
              </button>
            </div>
            <button class="modal-close" @click="showForm = false">&#x2715;</button>
          </div>
          <div class="modal-body">

            <!-- Template choice panel (only on create when templates exist) -->
            <div v-if="!editPlan && showTemplateChoice" class="template-choice-panel">
              <h4 class="template-choice-title">Crear desde plantilla guardada?</h4>
              <div class="template-choice-list">
                <div v-for="t in planTemplates" :key="t.id" class="template-choice-card"
                  @click="loadFromTemplate(t); showTemplateChoice = false">
                  <div class="template-choice-card-title">{{ t.name }}</div>
                  <div class="template-choice-card-meta text-muted small">
                    {{ WO_TYPE_LABELS[t.wo_type] || t.wo_type }} &#x00B7; {{ t.frequency_value }} {{ FREQ_LABELS[t.frequency_type] }} &#x00B7; {{ t.priority }}
                  </div>
                </div>
              </div>
              <button class="btn-text template-choice-skip" @click="showTemplateChoice = false">
                Crear desde cero &#x2192;
              </button>
            </div>

            <template v-if="editPlan || !showTemplateChoice">
            <!-- Section 1: Basic data -->
            <div class="form-section">
              <div class="form-section-title" @click="sectionOpen.basic = !sectionOpen.basic">
                <span>{{ sectionOpen.basic ? '&#x25BE;' : '&#x25B8;' }}</span> Datos basicos
              </div>
              <div v-show="sectionOpen.basic" class="form-section-body">
                <div class="field">
                  <label class="field-label">Destino del plan *</label>
                  <div class="target-toggle">
                    <button type="button" :class="['toggle-btn', { active: targetType === 'node' }]" @click="targetType = 'node'">
                      Nodo especifico
                    </button>
                    <button type="button" :class="['toggle-btn', { active: targetType === 'template' }]" @click="targetType = 'template'">
                      Tipo de equipo
                    </button>
                  </div>
                </div>
                <div v-if="targetType === 'node'" class="field">
                  <label class="field-label">Equipo *</label>
                  <select v-model="form.node_id" class="field-input" @change="onNodeChange">
                    <option :value="0">Selecciona un equipo...</option>
                    <option v-for="n in filteredNodes" :key="n.id" :value="n.id">
                      {{ n.name }}{{ n.code ? ` (${n.code})` : '' }} [{{ n.node_type }}]
                    </option>
                  </select>
                </div>
                <div v-if="targetType === 'template'" class="field">
                  <label class="field-label">Tipo de equipo (fabricante/modelo) *</label>
                  <select v-model="form.equipment_template_id" class="field-input">
                    <option :value="null">Selecciona un tipo de equipo...</option>
                    <option v-for="t in equipmentTemplates" :key="t.id" :value="t.id">
                      {{ t.manufacturer }} {{ t.model }}{{ t.node_count ? ` (${t.node_count} equipos)` : '' }}
                    </option>
                  </select>
                  <p class="field-hint">El plan aplicara a todos los equipos de este modelo de equipo</p>
                </div>
                <div class="field">
                  <label class="field-label">Título del plan *</label>
                  <input v-model="form.title" class="field-input" placeholder="Ej: Revision mensual hidraulica" />
                </div>
                <div class="field">
                  <label class="field-label">Descripción</label>
                  <textarea v-model="form.description" class="field-input" rows="2"
                    placeholder="Que se debe hacer en esta intervencion..." />
                </div>
                <div class="field-row">
                  <div class="field">
                    <label class="field-label">Tipo de OT</label>
                    <select v-model="form.wo_type" class="field-input">
                      <option value="preventive">Preventiva</option>
                      <option value="inspection">Inspeccion</option>
                      <option value="predictive">Predictiva</option>
                    </select>
                  </div>
                  <div class="field">
                    <label class="field-label">Prioridad</label>
                    <select v-model="form.priority" class="field-input">
                      <option value="low">Baja</option>
                      <option value="medium">Media</option>
                      <option value="high">Alta</option>
                      <option value="critical">Critica</option>
                    </select>
                  </div>
                </div>
                <div class="field-row">
                  <div class="field">
                    <label class="field-label">Frecuencia *</label>
                    <div class="freq-input">
                      <input v-model.number="form.frequency_value" type="number" min="1"
                        class="field-input freq-num" placeholder="1" />
                      <select v-model="form.frequency_type" class="field-input freq-type">
                        <option value="days">Dias</option>
                        <option value="weeks">Semanas</option>
                        <option value="months">Meses</option>
                      </select>
                    </div>
                  </div>
                  <div class="field">
                    <label class="field-label">Anticipacion (dias)</label>
                    <input v-model.number="form.advance_days" type="number" min="0"
                      class="field-input" placeholder="3" />
                    <p class="field-hint">Días antes de crear la OT automáticamente</p>
                  </div>
                </div>
                <div class="field-row">
                  <div class="field">
                    <label class="field-label">Técnico asignado</label>
                    <select v-model="form.assigned_to" class="field-input">
                      <option :value="null">Sin asignar</option>
                      <option v-for="t in technicians" :key="t.user_id" :value="t.user_id">
                        {{ t.full_name }}
                      </option>
                    </select>
                  </div>
                  <div class="field">
                    <label class="field-label">Horas estimadas</label>
                    <input v-model.number="form.estimated_hours" type="number" step="0.5"
                      class="field-input mono" placeholder="2.0" />
                  </div>
                </div>
                <div class="field">
                  <label class="field-label">Primera ejecución</label>
                  <input v-model="form.start_date" type="date" class="field-input mono" />
                  <p class="field-hint">Si no se indica, se calcula desde hoy segun la frecuencia</p>
                </div>
                <div class="field field-toggle">
                  <label class="toggle-label">
                    <input type="checkbox" v-model="form.apply_to_children" />
                    <span class="toggle-text">Aplicar a equipos hijos</span>
                  </label>
                  <p class="field-hint">Genera una OT individual por cada equipo descendiente del nodo seleccionado</p>
                </div>
              </div>
            </div>

            <!-- Section 2: Procedure -->
            <div class="form-section">
              <div class="form-section-title" @click="sectionOpen.procedure = !sectionOpen.procedure">
                <span>{{ sectionOpen.procedure ? '&#x25BE;' : '&#x25B8;' }}</span> Procedimiento
              </div>
              <div v-show="sectionOpen.procedure" class="form-section-body">
                <div class="field">
                  <label class="field-label">Instrucciones</label>
                  <textarea v-model="form.instructions" class="field-input" rows="6"
                    placeholder="Describe paso a paso el procedimiento de mantenimiento..." />
                </div>
              </div>
            </div>

            <!-- Section 3: Checklist -->
            <div class="form-section">
              <div class="form-section-title" @click="sectionOpen.checklist = !sectionOpen.checklist">
                <span>{{ sectionOpen.checklist ? '&#x25BE;' : '&#x25B8;' }}</span>
                Lista de verificación
                <span v-if="form.checklist.length" class="section-count">{{ form.checklist.length }}</span>
              </div>
              <div v-show="sectionOpen.checklist" class="form-section-body">
                <div v-for="(item, i) in form.checklist" :key="i" class="checklist-row">
                  <input v-model="item.step" class="field-input checklist-input" placeholder="Paso..." />
                  <label class="checklist-req-label" :title="item.required ? 'Obligatorio' : 'Opcional'">
                    <input type="checkbox" v-model="item.required" />
                    Oblig.
                  </label>
                  <button class="action-btn action-btn--del" @click="form.checklist.splice(i, 1)">&#x2715;</button>
                </div>
                <button class="btn-add-row" @click="form.checklist.push({ step: '', required: false })">
                  + Agregar paso
                </button>
              </div>
            </div>

            <!-- Section 4: Safety -->
            <div class="form-section">
              <div class="form-section-title" @click="sectionOpen.safety = !sectionOpen.safety">
                <span>{{ sectionOpen.safety ? '&#x25BE;' : '&#x25B8;' }}</span> Seguridad
              </div>
              <div v-show="sectionOpen.safety" class="form-section-body">
                <div class="field">
                  <label class="field-label">Notas de seguridad</label>
                  <textarea v-model="form.safety_notes" class="field-input" rows="3"
                    placeholder="EPP, precauciones, permisos de trabajo..." />
                </div>
              </div>
            </div>

            <!-- Section 5: Tools -->
            <div class="form-section">
              <div class="form-section-title" @click="sectionOpen.tools = !sectionOpen.tools">
                <span>{{ sectionOpen.tools ? '&#x25BE;' : '&#x25B8;' }}</span>
                Herramientas
                <span v-if="form.tools_required.length" class="section-count">{{ form.tools_required.length }}</span>
              </div>
              <div v-show="sectionOpen.tools" class="form-section-body">
                <div class="tools-chips">
                  <span v-for="(t, i) in form.tools_required" :key="i" class="tool-chip">
                    {{ t }}
                    <button class="chip-remove" @click="form.tools_required.splice(i, 1)">&#x2715;</button>
                  </span>
                </div>
                <div class="add-tool-row">
                  <input v-model="newTool" class="field-input" placeholder="Nombre de herramienta..."
                    @keydown.enter.prevent="addTool" />
                  <button class="btn-add-inline" @click="addTool">Agregar</button>
                </div>
              </div>
            </div>

            <!-- Section 6: Spare parts -->
            <div class="form-section">
              <div class="form-section-title" @click="sectionOpen.parts = !sectionOpen.parts">
                <span>{{ sectionOpen.parts ? '&#x25BE;' : '&#x25B8;' }}</span>
                Repuestos necesarios
                <span v-if="form.required_parts.length" class="section-count">{{ form.required_parts.length }}</span>
              </div>
              <div v-show="sectionOpen.parts" class="form-section-body">
                <div v-for="(part, i) in form.required_parts" :key="i" class="part-row">
                  <span class="part-name">{{ part.name }} <span class="mono text-muted">({{ part.code }})</span></span>
                  <input v-model.number="part.quantity" type="number" min="1" class="field-input part-qty" />
                  <button class="action-btn action-btn--del" @click="form.required_parts.splice(i, 1)">&#x2715;</button>
                </div>
                <div v-if="nodeSpares.length" class="add-part-row">
                  <select v-model="selectedSpare" class="field-input">
                    <option :value="null">Seleccionar repuesto...</option>
                    <option v-for="s in availableSpares" :key="s.id" :value="s">
                      {{ s.name }} ({{ s.code }}) — Stock: {{ s.current_stock }}
                    </option>
                  </select>
                  <button class="btn-add-inline" @click="addPart" :disabled="!selectedSpare">Agregar</button>
                </div>
                <p v-else-if="form.node_id" class="field-hint">No hay repuestos vinculados a este equipo</p>
                <p v-else class="field-hint">Selecciona un equipo primero</p>
              </div>
            </div>

            <div v-if="formError" class="modal-error">{{ formError }}</div>
            </template>
          </div>
          <div v-if="editPlan || !showTemplateChoice" class="modal-footer">
            <button class="btn-secondary" @click="showForm = false">Cancelar</button>
            <button class="btn-primary" :disabled="!canWrite || saving" @click="submitForm">
              {{ saving ? 'Guardando...' : (editPlan ? 'Guardar' : 'Crear plan') }}
            </button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Load template modal -->
    <Teleport to="body">
      <div v-if="showLoadTemplate" class="modal-overlay" @click.self="showLoadTemplate = false" style="z-index:1100">
        <div class="small-modal">
          <div class="modal-header">
            <h3>Cargar plantilla de mantenimiento</h3>
            <button class="modal-close" @click="showLoadTemplate = false">&#x2715;</button>
          </div>
          <div class="modal-body">
            <div v-if="!planTemplates.length" class="card-empty">No hay plantillas guardadas.</div>
            <div v-else class="template-list">
              <div v-for="t in planTemplates" :key="t.id" class="template-card" @click="loadFromTemplate(t)">
                <div class="template-card-title">{{ t.name }}</div>
                <div class="template-card-meta text-muted small">
                  {{ t.wo_type }} · {{ t.frequency_value }} {{ FREQ_LABELS[t.frequency_type] }} · {{ t.priority }}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Reusable confirmation modal -->
    <Teleport to="body">
      <div v-if="dialogConfirm.show" class="modal-overlay" style="z-index:1200" @click.self="resolveConfirm(false)">
        <div class="dialog-modal">
          <div class="dialog-body">
            <p class="dialog-message">{{ dialogConfirm.message }}</p>
          </div>
          <div class="dialog-footer">
            <button class="btn-secondary" @click="resolveConfirm(false)">Cancelar</button>
            <button class="btn-primary" @click="resolveConfirm(true)">Confirmar</button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Reusable prompt modal -->
    <Teleport to="body">
      <div v-if="dialogPrompt.show" class="modal-overlay" style="z-index:1200" @click.self="resolvePrompt(null)">
        <div class="dialog-modal">
          <div class="dialog-body">
            <p class="dialog-message">{{ dialogPrompt.message }}</p>
            <input v-model="dialogPrompt.value" class="field-input" @keydown.enter="resolvePrompt(dialogPrompt.value)" ref="promptInput" />
          </div>
          <div class="dialog-footer">
            <button class="btn-secondary" @click="resolvePrompt(null)">Cancelar</button>
            <button class="btn-primary" :disabled="!dialogPrompt.value?.trim()" @click="resolvePrompt(dialogPrompt.value)">Aceptar</button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Result toast -->
    <Teleport to="body">
      <Transition name="toast">
        <div v-if="toast.show" class="toast-notification" :class="`toast--${toast.type}`" @click="toast.show = false">
          {{ toast.message }}
        </div>
      </Transition>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, reactive, nextTick } from 'vue'
import { apiErrorMsg } from '@/composables/useToast'
import { formatSmart } from '@/utils/time'
import EmptyState from '@/components/layout/EmptyState.vue'
import { useRoute, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import client from '@/api/client'
import { maintenancePlansApi, maintenancePlanTemplatesApi } from '@/api/maintenance'
import type { MaintenancePlanDetail, MaintenancePlanTemplate, PlanExecution, PlanExclusion, ChecklistItem, RequiredPart } from '@/api/maintenance'
import { staggeringApi } from '@/api/staggering'
import type { StaggeringConfig, SchedulePreview, StaggeringCycle, ScheduleData } from '@/api/staggering'
import StaggeringPreview from '@/components/maintenance/StaggeringPreview.vue'

const route = useRoute()
const router = useRouter()

const authStore = useAuthStore()
const canManage = computed(() => authStore.isManager)

import { useSystemPause } from '@/composables/useSystemPause'
const { canWrite } = useSystemPause()
const showGuide = ref(false)

const FREQ_LABELS: Record<string, string> = {
  days: 'dias', weeks: 'semanas', months: 'meses', hours: 'horas'
}
const WO_TYPE_LABELS: Record<string, string> = {
  preventive: 'Preventiva', inspection: 'Inspeccion', predictive: 'Predictiva'
}
const CRIT_COLORS: Record<string, string> = {
  low: '#27AE60', medium: '#F39C12', high: '#E67E22', critical: '#E94560'
}

// ─── Dialog system (replaces the native alert/confirm/prompt) ─────────────────
const dialogConfirm = reactive({ show: false, message: '', resolve: null as ((v: boolean) => void) | null })
const dialogPrompt = reactive({ show: false, message: '', value: '', resolve: null as ((v: string | null) => void) | null })
const toast = reactive({ show: false, message: '', type: 'success' as 'success' | 'error' })
const promptInput = ref<HTMLInputElement | null>(null)

function showConfirm(message: string): Promise<boolean> {
  return new Promise(resolve => {
    dialogConfirm.message = message
    dialogConfirm.resolve = resolve
    dialogConfirm.show = true
  })
}
function resolveConfirm(value: boolean) {
  dialogConfirm.show = false
  dialogConfirm.resolve?.(value)
}

function showPrompt(message: string, defaultValue = ''): Promise<string | null> {
  return new Promise(resolve => {
    dialogPrompt.message = message
    dialogPrompt.value = defaultValue
    dialogPrompt.resolve = resolve
    dialogPrompt.show = true
    nextTick(() => promptInput.value?.focus())
  })
}
function resolvePrompt(value: string | null) {
  dialogPrompt.show = false
  dialogPrompt.resolve?.(value?.trim() || null)
}

function showToast(message: string, type: 'success' | 'error' = 'success') {
  toast.message = message
  toast.type = type
  toast.show = true
  setTimeout(() => { toast.show = false }, 4000)
}

// ─── Data ───────────────────────────────────────────────────────────────────
const plans = ref<any[]>([])
const upcoming = ref<any[]>([])
const compliance = ref<any>(null)
const nodes = ref<any[]>([])
const technicians = ref<any[]>([])
const filterActive = ref('true')
const searchQuery = ref('')

const showForm = ref(false)
const editPlan = ref<any>(null)
const saving = ref(false)
const formError = ref('')
const newTool = ref('')
const selectedSpare = ref<any>(null)
const nodeSpares = ref<any[]>([])

// Detail panel
const showDetail = ref(false)
const detailPlan = ref<MaintenancePlanDetail | null>(null)
const detailExecs = ref<PlanExecution[]>([])
const detailExclusions = ref<PlanExclusion[]>([])

// Template & target type
const targetType = ref<'node' | 'template'>('node')
const equipmentTemplates = ref<any[]>([])
const showLoadTemplate = ref(false)
const planTemplates = ref<MaintenancePlanTemplate[]>([])
const showTemplateChoice = ref(false)
const showSaveTemplateOffer = ref(false)
const lastCreatedPlanId = ref<number | null>(null)

const sectionOpen = reactive({
  basic: true,
  procedure: false,
  checklist: false,
  safety: false,
  tools: false,
  parts: false,
})

interface FormData {
  node_id: number
  title: string
  description: string
  wo_type: string
  priority: string
  frequency_type: string
  frequency_value: number
  advance_days: number
  assigned_to: number | null
  estimated_hours: number | null
  start_date: string
  apply_to_children: boolean
  instructions: string
  checklist: ChecklistItem[]
  safety_notes: string
  tools_required: string[]
  required_parts: RequiredPart[]
  equipment_template_id: number | null
  source_template_id: number | null
}

const defaultForm = (): FormData => ({
  node_id: 0, title: '', description: '',
  wo_type: 'preventive', priority: 'medium',
  frequency_type: 'months', frequency_value: 1,
  advance_days: 3, assigned_to: null,
  estimated_hours: null, start_date: '',
  apply_to_children: false,
  instructions: '',
  checklist: [],
  safety_notes: '',
  tools_required: [],
  required_parts: [],
  equipment_template_id: null,
  source_template_id: null,
})

const form = ref<FormData>(defaultForm())

const filteredNodes = computed(() => {
  if (form.value.apply_to_children) {
    return nodes.value
  }
  return nodes.value.filter((n: any) =>
    ['equipment', 'component', 'measurement_point'].includes(n.node_type)
  )
})

const availableSpares = computed(() => {
  const usedIds = new Set(form.value.required_parts.map(p => p.spare_part_id))
  return nodeSpares.value.filter((s: any) => !usedIds.has(s.id))
})

const filteredPlans = computed(() => {
  const q = searchQuery.value.trim().toLowerCase()
  if (!q) return plans.value
  return plans.value.filter((p: any) => {
    const fields = [
      p.title,
      p.node_name,
      p.template_manufacturer,
      p.template_model,
    ]
    return fields.some(f => f && String(f).toLowerCase().includes(q))
  })
})

async function loadPlans() {
  try {
    const { data } = await client.get('/maintenance-plans', {
      params: { active: filterActive.value }
    })
    plans.value = data.plans ?? []
  } catch { plans.value = [] }
}

async function loadUpcoming() {
  try {
    const { data } = await client.get('/maintenance-plans/upcoming', { params: { days: 30 } })
    upcoming.value = data.upcoming ?? []
  } catch { upcoming.value = [] }
}

async function loadCompliance() {
  try {
    const { data } = await client.get('/maintenance-plans/compliance')
    compliance.value = data
  } catch { compliance.value = null }
}

async function loadNodes() {
  try {
    const { data } = await client.get('/factory/tree')
    const flatten = (arr: any[]) => {
      let result: any[] = []
      arr.forEach(n => {
        result.push(n)
        if (n.children?.length) result = result.concat(flatten(n.children))
      })
      return result
    }
    nodes.value = flatten(data.tree ?? data.nodes ?? [])
  } catch { nodes.value = [] }
}

async function loadTechnicians() {
  try {
    const { data } = await client.get('/technicians')
    technicians.value = data.technicians ?? []
  } catch { technicians.value = [] }
}

async function loadNodeSpares(nodeId: number) {
  if (!nodeId) { nodeSpares.value = []; return }
  try {
    const { data } = await client.get('/spare-parts', { params: { node_id: nodeId } })
    nodeSpares.value = data.spare_parts ?? []
  } catch { nodeSpares.value = [] }
}

function onNodeChange() {
  loadNodeSpares(form.value.node_id)
}

function openCreate() {
  editPlan.value = null
  form.value = defaultForm()
  targetType.value = 'node'
  formError.value = ''
  sectionOpen.basic = true
  sectionOpen.procedure = false
  sectionOpen.checklist = false
  sectionOpen.safety = false
  sectionOpen.tools = false
  sectionOpen.parts = false
  nodeSpares.value = []
  showTemplateChoice.value = planTemplates.value.length > 0
  showForm.value = true
}

async function openEdit(p: any) {
  editPlan.value = p
  // Fetch full plan to get procedure fields
  try {
    const data = await maintenancePlansApi.getOne(p.id)
    const plan = data.plan
    targetType.value = plan.equipment_template_id ? 'template' : 'node'
    form.value = {
      node_id: plan.node_id ?? 0,
      title: plan.title,
      description: plan.description ?? '',
      wo_type: plan.wo_type,
      priority: plan.priority,
      frequency_type: plan.frequency_type,
      frequency_value: plan.frequency_value,
      advance_days: plan.advance_days,
      assigned_to: plan.assigned_to,
      estimated_hours: plan.estimated_hours,
      start_date: '',
      apply_to_children: plan.apply_to_children,
      instructions: plan.instructions ?? '',
      checklist: plan.checklist ?? [],
      safety_notes: plan.safety_notes ?? '',
      tools_required: plan.tools_required ?? [],
      required_parts: plan.required_parts ?? [],
      equipment_template_id: plan.equipment_template_id ?? null,
      source_template_id: plan.source_template_id ?? null,
    }
    loadNodeSpares(plan.node_id ?? 0)
  } catch {
    targetType.value = p.equipment_template_id ? 'template' : 'node'
    form.value = {
      ...defaultForm(),
      node_id: p.node_id, title: p.title, description: p.description ?? '',
      wo_type: p.wo_type, priority: p.priority,
      frequency_type: p.frequency_type, frequency_value: p.frequency_value,
      advance_days: p.advance_days, assigned_to: p.assigned_to,
      estimated_hours: p.estimated_hours,
      equipment_template_id: p.equipment_template_id ?? null,
    }
  }
  formError.value = ''
  sectionOpen.basic = true
  showForm.value = true
}

async function openDetail(id: number) {
  try {
    const data = await maintenancePlansApi.getOne(id)
    detailPlan.value = data.plan
    detailExecs.value = data.executions ?? []
    detailExclusions.value = data.exclusions ?? []
    showDetail.value = true
  } catch { /* ignore */ }
}

function addTool() {
  const t = newTool.value.trim()
  if (t && !form.value.tools_required.includes(t)) {
    form.value.tools_required.push(t)
  }
  newTool.value = ''
}

function addPart() {
  if (!selectedSpare.value) return
  form.value.required_parts.push({
    spare_part_id: selectedSpare.value.id,
    name: selectedSpare.value.name,
    code: selectedSpare.value.code,
    quantity: 1,
  })
  selectedSpare.value = null
}

async function submitForm() {
  if (!form.value.title || !form.value.frequency_value) {
    formError.value = 'Título y frecuencia son obligatorios'
    return
  }
  if (targetType.value === 'node' && !form.value.node_id) {
    formError.value = 'Selecciona un equipo'
    return
  }
  if (targetType.value === 'template' && !form.value.equipment_template_id) {
    formError.value = 'Selecciona un tipo de equipo'
    return
  }
  saving.value = true; formError.value = ''
  try {
    const payload = {
      ...form.value,
      node_id: targetType.value === 'node' ? form.value.node_id : 0,
      equipment_template_id: targetType.value === 'template' ? form.value.equipment_template_id : null,
      source_template_id: form.value.source_template_id ?? null,
      instructions: form.value.instructions || null,
      safety_notes: form.value.safety_notes || null,
      description: form.value.description || null,
    }
    if (editPlan.value) {
      await client.put(`/maintenance-plans/${editPlan.value.id}`, { ...payload, is_active: true })
    } else {
      const resp = await client.post('/maintenance-plans', payload)
      lastCreatedPlanId.value = resp.data?.plan?.id ?? resp.data?.id ?? null
      if (lastCreatedPlanId.value) {
        showSaveTemplateOffer.value = true
      }
    }
    showForm.value = false
    await loadPlans()
    await loadUpcoming()
    await loadCompliance()
  } catch (err: unknown) {
    formError.value = apiErrorMsg(err, 'Error guardando el plan')
  } finally { saving.value = false }
}

async function executePlan(id: number) {
  if (!await showConfirm('Generar la OT preventiva ahora?')) return
  try {
    const data = await maintenancePlansApi.execute(id)
    const msgs = data.work_orders?.map((w: any) => w.wo_number).join(', ') || 'OK'
    showToast(`${data.message} — OTs: ${msgs} — Proxima: ${data.next_due}`)
    await loadPlans()
    await loadUpcoming()
    await loadCompliance()
  } catch (err: unknown) {
    showToast(apiErrorMsg(err, 'Error generando OT'), 'error')
  }
}

async function deletePlan(id: number) {
  if (!await showConfirm('Desactivar este plan?')) return
  await client.delete(`/maintenance-plans/${id}`)
  showToast('Plan desactivado')
  await loadPlans()
  await loadCompliance()
}

function loadFromTemplate(t: MaintenancePlanTemplate) {
  form.value.title = t.name
  form.value.description = t.description ?? ''
  form.value.wo_type = t.wo_type
  form.value.priority = t.priority
  form.value.frequency_type = t.frequency_type
  form.value.frequency_value = t.frequency_value
  form.value.advance_days = t.advance_days
  form.value.estimated_hours = t.estimated_hours
  form.value.apply_to_children = t.apply_to_children
  form.value.instructions = t.instructions ?? ''
  form.value.checklist = t.checklist?.length ? [...t.checklist] : []
  form.value.safety_notes = t.safety_notes ?? ''
  form.value.tools_required = t.tools_required?.length ? [...t.tools_required] : []
  form.value.required_parts = t.required_parts?.length ? [...t.required_parts] : []
  form.value.source_template_id = t.id
  showLoadTemplate.value = false
}

async function saveNewPlanAsTemplate() {
  if (!lastCreatedPlanId.value) return
  const name = await showPrompt('Nombre para la plantilla:')
  if (!name) return
  try {
    await maintenancePlanTemplatesApi.saveFromPlan(lastCreatedPlanId.value, name)
    const r = await maintenancePlanTemplatesApi.list()
    planTemplates.value = r.templates ?? []
    showSaveTemplateOffer.value = false
    showToast('Plantilla guardada')
  } catch { showToast('Error guardando plantilla', 'error') }
}

async function saveAsTemplate() {
  if (!editPlan.value) return
  const name = await showPrompt('Nombre para la plantilla:')
  if (!name) return
  try {
    await maintenancePlanTemplatesApi.saveFromPlan(editPlan.value.id, name)
    const r = await maintenancePlanTemplatesApi.list()
    planTemplates.value = r.templates ?? []
    showToast('Plantilla guardada')
  } catch { showToast('Error guardando plantilla', 'error') }
}

async function removeExclusion(planId: number, nodeId: number) {
  try {
    await maintenancePlansApi.removeExclusion(planId, nodeId)
    openDetail(planId)
  } catch { /* silent */ }
}

// ─── Staggering ──────────────────────────────────────────────────────────────

const STAGGER_TABS = [
  { key: 'config', label: 'Configuración' },
  { key: 'schedule', label: 'Schedule activo' },
  { key: 'history', label: 'Historial' },
] as const

const SCOPE_LABELS: Record<string, string> = { global: 'Global', area: 'Área', line: 'Línea' }
const PERIOD_LABELS: Record<string, string> = { weekly: 'Semanal', biweekly: 'Quincenal', monthly: 'Mensual' }
const CYCLE_STATUS_LABELS: Record<string, string> = {
  planned: 'Planificado', in_progress: 'En curso', completed: 'Completado'
}
const ENTRY_STATUS_LABELS: Record<string, string> = {
  scheduled: 'Pendiente', rescheduled: 'Reescalonada', completed: 'Completada', skipped: 'Omitida'
}

const showStagger = ref(false)
const staggerTab = ref<string>('config')
const staggerConfigs = ref<StaggeringConfig[]>([])
const staggerForm = reactive({
  id: null as number | null,
  scope: 'global' as string,
  scope_node_id: null as number | null,
  period: 'monthly' as string,
  max_daily_per_tech: 3,
  is_active: false,
})
const staggerSaving = ref(false)
const staggerError = ref('')
const staggerPreviewing = ref(false)
const staggerPreview = ref<SchedulePreview | null>(null)
const staggerApplying = ref(false)
const staggerCycles = ref<StaggeringCycle[]>([])
const activeSchedule = ref<ScheduleData | null>(null)

const canManageStagger = computed(() => canManage.value)
const canToggleStagger = computed(() => authStore.isPrimaryAdmin || authStore.isSuperadmin)

const activeConfig = computed(() => staggerConfigs.value.find(c => c.is_active))

const scopeNodes = computed(() => {
  const targetType = staggerForm.scope === 'area' ? 'area' : 'line'
  return nodes.value.filter((n: any) => n.node_type === targetType)
})

function onScopeChange() {
  staggerForm.scope_node_id = null
}

async function loadStaggerConfig() {
  try {
    const { configs } = await staggeringApi.getConfig()
    staggerConfigs.value = configs ?? []
    // Load the first config into the form if exists
    if (configs?.length) {
      const c = configs[0]
      staggerForm.id = c.id
      staggerForm.scope = c.scope
      staggerForm.scope_node_id = c.scope_node_id
      staggerForm.period = c.period
      staggerForm.max_daily_per_tech = c.max_daily_per_tech
      staggerForm.is_active = c.is_active
    }
  } catch { /* silent */ }
}

async function saveStaggerConfig() {
  staggerSaving.value = true
  staggerError.value = ''
  try {
    const payload = {
      id: staggerForm.id ?? undefined,
      scope: staggerForm.scope,
      scope_node_id: staggerForm.scope === 'global' ? null : staggerForm.scope_node_id,
      period: staggerForm.period,
      max_daily_per_tech: staggerForm.max_daily_per_tech,
      is_active: staggerForm.is_active,
    }
    const resp = await staggeringApi.updateConfig(payload)
    if (!staggerForm.id) staggerForm.id = resp.id
    await loadStaggerConfig()
  } catch (err: unknown) {
    staggerError.value = apiErrorMsg(err, 'Error guardando configuración')
  } finally {
    staggerSaving.value = false
  }
}

async function loadPreview() {
  if (!staggerForm.id) return
  staggerPreviewing.value = true
  staggerError.value = ''
  staggerPreview.value = null
  try {
    staggerPreview.value = await staggeringApi.preview(staggerForm.id)
  } catch (err: unknown) {
    staggerError.value = apiErrorMsg(err, 'Error calculando previsualizacion')
  } finally {
    staggerPreviewing.value = false
  }
}

async function applyStagger() {
  if (!staggerForm.id) return
  if (!await showConfirm('Confirmar y aplicar la distribución escalonada? Se creará un nuevo ciclo.')) return
  staggerApplying.value = true
  staggerError.value = ''
  try {
    await staggeringApi.apply(staggerForm.id)
    staggerPreview.value = null
    // Reload schedule and cycles
    await Promise.all([loadActiveSchedule(), loadStaggerCycles()])
    staggerTab.value = 'schedule'
  } catch (err: unknown) {
    staggerError.value = apiErrorMsg(err, 'Error aplicando escalonado')
  } finally {
    staggerApplying.value = false
  }
}

async function loadActiveSchedule() {
  try {
    activeSchedule.value = await staggeringApi.getSchedule()
  } catch {
    activeSchedule.value = null
  }
}

async function loadStaggerCycles() {
  try {
    const { cycles } = await staggeringApi.listCycles()
    staggerCycles.value = cycles ?? []
  } catch {
    staggerCycles.value = []
  }
}

async function loadCycleSchedule(cycleId: number) {
  try {
    activeSchedule.value = await staggeringApi.getSchedule(cycleId)
    staggerTab.value = 'schedule'
  } catch { /* silent */ }
}

function formatShortDate(iso: string) {
  if (!iso) return '\u2014'
  try {
    return new Date(iso + 'T00:00:00').toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit' })
  } catch { return iso }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function getDueSeverity(days: number | null) {
  if (days === null) return ''
  if (days < 0) return 'upcoming-item--overdue'
  if (days <= 3) return 'upcoming-item--urgent'
  if (days <= 7) return 'upcoming-item--soon'
  return ''
}

function formatDate(iso: string) {
  if (!iso) return '\u2014'
  try {
    return new Date(iso).toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric' })
  } catch { return iso }
}

onMounted(async () => {
  await Promise.all([loadPlans(), loadUpcoming(), loadCompliance(), loadNodes(), loadTechnicians()])

  // Load equipment templates
  client.get('/templates').then(r => { equipmentTemplates.value = r.data?.templates ?? [] }).catch(() => {})
  // Load plan templates
  maintenancePlanTemplatesApi.list().then(r => { planTemplates.value = r.templates ?? [] }).catch(() => {})

  // Load staggering data (non-blocking)
  if (canManage.value) {
    loadStaggerConfig()
    loadActiveSchedule()
    loadStaggerCycles()
  }

  // Check for query params to open create form with pre-selected node
  if (route.query.create === '1' && route.query.node_id) {
    form.value.node_id = Number(route.query.node_id)
    showForm.value = true
    router.replace({ query: {} })
  }
})
</script>

<style scoped>
.mplans-layout { display: flex; flex-direction: column; gap: var(--space-6); }
.page-header { display: flex; align-items: flex-start; justify-content: space-between; }
.page-title { font-size: 1.4rem; font-weight: 700; color: var(--color-primary); }
.page-sub { font-size: 0.8rem; color: var(--color-text-muted); }
.header-actions { display: flex; gap: var(--space-3); }

/* Compliance */
.compliance-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: var(--space-4); }
.comp-card { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); padding: var(--space-4); display: flex; flex-direction: column; gap: var(--space-2); }
.comp-card--alert { border-color: rgba(233,69,96,0.3); }
.comp-value { font-size: 1.8rem; font-weight: 700; font-family: var(--font-mono); color: var(--color-primary); }
.comp-label { font-size: 0.72rem; font-weight: 600; text-transform: uppercase; color: var(--color-text-muted); }
.comp-bar { height: 4px; background: var(--color-border-light); border-radius: 2px; overflow: hidden; margin-top: var(--space-1); }
.comp-bar-fill { height: 100%; border-radius: 2px; transition: width 0.4s ease; }
.text-alert { color: var(--color-alert) !important; }
.text-warning { color: #F39C12 !important; }

/* Upcoming */
.card { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); overflow: hidden; }
.card-header { display: flex; align-items: center; justify-content: space-between; padding: var(--space-4) var(--space-5); border-bottom: 1px solid var(--color-border-light); }
.card-title { font-size: 0.78rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--color-text-muted); }
.card-empty { padding: var(--space-8); text-align: center; font-size: 0.875rem; color: var(--color-text-muted); }

.upcoming-list { display: flex; flex-direction: column; }
.upcoming-item { display: flex; align-items: center; gap: var(--space-4); padding: var(--space-3) var(--space-5); border-bottom: 1px solid var(--color-border-light); border-left: 3px solid transparent; }
.upcoming-item:last-child { border-bottom: none; }
.upcoming-item--overdue { border-left-color: var(--color-alert); background: rgba(233,69,96,0.02); }
.upcoming-item--urgent  { border-left-color: #E67E22; }
.upcoming-item--soon    { border-left-color: #F39C12; }
.upcoming-days { display: flex; flex-direction: column; align-items: center; width: 40px; flex-shrink: 0; }
.days-num { font-size: 1.4rem; font-weight: 700; font-family: var(--font-mono); color: var(--color-primary); line-height: 1; }
.days-label { font-size: 0.65rem; color: var(--color-text-muted); }
.upcoming-item--overdue .days-num { color: var(--color-alert); }
.upcoming-info { flex: 1; display: flex; flex-direction: column; gap: 2px; min-width: 0; }
.upcoming-title { font-size: 0.875rem; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.upcoming-node { font-size: 0.75rem; }
.upcoming-meta { display: flex; align-items: center; gap: var(--space-3); flex-shrink: 0; }
.crit-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
.upcoming-assigned, .upcoming-date { font-size: 0.75rem; }
.btn-execute { height: 28px; padding: 0 var(--space-3); background: rgba(39,174,96,0.1); border: 1px solid rgba(39,174,96,0.3); color: #27AE60; border-radius: var(--radius-sm); font-size: 0.75rem; font-weight: 600; cursor: pointer; white-space: nowrap; }
.btn-execute:hover { background: rgba(39,174,96,0.2); }

/* Plans table */
.plans-table-wrap { overflow-x: auto; }
.plans-table { width: 100%; border-collapse: collapse; font-size: 0.82rem; }
.plans-table th { padding: var(--space-2) var(--space-4); font-size: 0.65rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); background: var(--color-surface-2); border-bottom: 1px solid var(--color-border-light); text-align: left; }
.plan-row td { padding: var(--space-3) var(--space-4); border-bottom: 1px solid var(--color-border-light); vertical-align: middle; }
.plan-row:last-child td { border-bottom: none; }
.plan-row--overdue { background: rgba(233,69,96,0.02); }
.plan-row:hover { background: var(--color-surface-2); }
.node-name { display: block; font-weight: 500; }
.node-code { font-size: 0.72rem; display: block; }
.plan-title { font-weight: 500; max-width: 260px; }
.plan-badges { display: flex; gap: var(--space-1); margin-top: 2px; }
.plan-badge { font-size: 0.62rem; padding: 1px 5px; border-radius: 3px; background: var(--color-surface-2); color: var(--color-text-muted); border: 1px solid var(--color-border-light); }
.plan-badge--children { background: rgba(59,130,246,0.08); color: #3B82F6; border-color: rgba(59,130,246,0.2); }
.type-pill { font-size: 0.68rem; font-weight: 600; padding: 2px 8px; border-radius: 20px; }
.type-pill--preventive { background: rgba(59,130,246,0.1); color: #3B82F6; }
.type-pill--inspection { background: rgba(139,92,246,0.1); color: #8B5CF6; }
.type-pill--predictive { background: rgba(243,156,18,0.1); color: #F39C12; }
.text-right { text-align: right; }
.row-actions { display: flex; gap: var(--space-1); }
.action-btn { width: 26px; height: 26px; background: var(--color-surface-2); border: 1px solid var(--color-border); border-radius: var(--radius-sm); cursor: pointer; font-size: 0.75rem; color: var(--color-text-muted); display: flex; align-items: center; justify-content: center; }
.action-btn:hover { background: var(--color-border-light); color: var(--color-text); }
.action-btn--exec { color: #27AE60; }
.action-btn--exec:hover { background: rgba(39,174,96,0.1); }
.action-btn--del:hover { color: var(--color-alert); }

/* Base modal */
.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; padding: var(--space-4); }
.plan-modal { background: var(--color-surface); border-radius: var(--radius-lg); width: 100%; max-width: 700px; max-height: 90vh; display: flex; flex-direction: column; box-shadow: var(--shadow-lg); }
.detail-modal { background: var(--color-surface); border-radius: var(--radius-lg); width: 100%; max-width: 640px; max-height: 90vh; display: flex; flex-direction: column; box-shadow: var(--shadow-lg); }
.modal-header { display: flex; justify-content: space-between; align-items: center; padding: var(--space-5) var(--space-6); border-bottom: 1px solid var(--color-border-light); }
.modal-header h3 { font-size: 1rem; font-weight: 600; color: var(--color-primary); }
.modal-close { background: none; border: none; font-size: 1rem; cursor: pointer; color: var(--color-text-muted); }
.modal-body { flex: 1; overflow-y: auto; padding: var(--space-5) var(--space-6); display: flex; flex-direction: column; gap: var(--space-4); }
.modal-footer { display: flex; justify-content: flex-end; gap: var(--space-3); padding: var(--space-4) var(--space-6); border-top: 1px solid var(--color-border-light); }
.modal-error { background: rgba(233,69,96,0.08); border: 1px solid rgba(233,69,96,0.3); border-radius: var(--radius); padding: var(--space-3); font-size: 0.875rem; color: var(--color-alert); }

/* Form sections */
.form-section { border: 1px solid var(--color-border-light); border-radius: var(--radius); overflow: hidden; }
.form-section-title { display: flex; align-items: center; gap: var(--space-2); padding: var(--space-3) var(--space-4); font-size: 0.78rem; font-weight: 700; color: var(--color-text); cursor: pointer; background: var(--color-surface-2); user-select: none; }
.form-section-title:hover { background: var(--color-border-light); }
.section-count { margin-left: auto; font-size: 0.68rem; font-weight: 600; background: var(--color-accent); color: #fff; width: 20px; height: 20px; border-radius: 50%; display: flex; align-items: center; justify-content: center; }
.form-section-body { padding: var(--space-4); display: flex; flex-direction: column; gap: var(--space-3); }

/* Fields */
.field { display: flex; flex-direction: column; gap: var(--space-1); flex: 1; }
.field-row { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-3); }
.field-label { font-size: 0.68rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); }
.field-input { height: 38px; padding: 0 var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; background: var(--color-surface); outline: none; width: 100%; }
.field-input:focus { border-color: var(--color-accent); }
textarea.field-input { height: auto; padding: var(--space-2) var(--space-3); resize: vertical; font-family: var(--font-ui); }
.field-hint { font-size: 0.72rem; color: var(--color-text-muted); }
.freq-input { display: flex; gap: var(--space-2); }
.freq-num { width: 80px; flex-shrink: 0; }
.freq-type { flex: 1; }
.field-toggle { padding: var(--space-2) 0; }
.toggle-label { display: flex; align-items: center; gap: var(--space-2); cursor: pointer; font-size: 0.875rem; }
.toggle-text { font-weight: 500; }

/* Checklist builder */
.checklist-row { display: flex; align-items: center; gap: var(--space-2); }
.checklist-input { flex: 1; }
.checklist-req-label { font-size: 0.72rem; display: flex; align-items: center; gap: 3px; color: var(--color-text-muted); white-space: nowrap; cursor: pointer; }
.btn-add-row { background: none; border: 1px dashed var(--color-border); border-radius: var(--radius); padding: var(--space-2); font-size: 0.8rem; color: var(--color-accent); cursor: pointer; text-align: center; }
.btn-add-row:hover { background: var(--color-surface-2); }

/* Tools */
.tools-chips { display: flex; flex-wrap: wrap; gap: var(--space-2); }
.tool-chip { display: flex; align-items: center; gap: var(--space-1); background: var(--color-surface-2); border: 1px solid var(--color-border-light); border-radius: 20px; padding: 2px 10px; font-size: 0.8rem; }
.chip-remove { background: none; border: none; cursor: pointer; font-size: 0.7rem; color: var(--color-text-muted); padding: 0; }
.chip-remove:hover { color: var(--color-alert); }
.add-tool-row { display: flex; gap: var(--space-2); }
.btn-add-inline { height: 38px; padding: 0 var(--space-4); background: var(--color-surface-2); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.8rem; cursor: pointer; white-space: nowrap; }
.btn-add-inline:hover:not(:disabled) { background: var(--color-border-light); }

/* Parts selector */
.part-row { display: flex; align-items: center; gap: var(--space-3); }
.part-name { flex: 1; font-size: 0.85rem; }
.part-qty { width: 70px; text-align: center; flex-shrink: 0; }
.add-part-row { display: flex; gap: var(--space-2); }

/* Detail panel */
.detail-meta { display: flex; flex-wrap: wrap; gap: var(--space-3); font-size: 0.82rem; }
.detail-meta strong { color: var(--color-text-muted); font-size: 0.72rem; text-transform: uppercase; }
.detail-section { border-top: 1px solid var(--color-border-light); padding-top: var(--space-3); }
.detail-section-title { font-size: 0.72rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); margin-bottom: var(--space-2); }
.detail-text { font-size: 0.85rem; line-height: 1.7; white-space: pre-wrap; }
.detail-text--safety { color: #E67E22; }
.detail-pre { font-family: var(--font-mono); font-size: 0.8rem; background: var(--color-surface-2); padding: var(--space-3); border-radius: var(--radius); white-space: pre-wrap; line-height: 1.7; }
.detail-checklist { list-style: none; padding: 0; display: flex; flex-direction: column; gap: var(--space-1); font-size: 0.85rem; }
.detail-checklist li { display: flex; align-items: center; gap: var(--space-2); }
.check-marker { font-family: var(--font-mono); color: var(--color-text-muted); }
.check-req { font-size: 0.72rem; color: #E67E22; }
.checklist--required .check-marker { color: #E67E22; }
.detail-chips { display: flex; flex-wrap: wrap; gap: var(--space-2); }
.detail-chip { background: var(--color-surface-2); border: 1px solid var(--color-border-light); border-radius: 20px; padding: 2px 10px; font-size: 0.8rem; }
.parts-mini-table { width: 100%; font-size: 0.85rem; border-collapse: collapse; }
.parts-mini-table td { padding: var(--space-1) var(--space-2); border-bottom: 1px solid var(--color-border-light); }
.exec-list { display: flex; flex-direction: column; gap: var(--space-2); }
.exec-item { display: flex; gap: var(--space-3); align-items: center; padding: var(--space-1) 0; }

/* Common */
.header-filters { display: flex; gap: var(--space-2); }
.filter-select { height: 30px; padding: 0 var(--space-2); border: 1px solid var(--color-border); border-radius: var(--radius-sm); font-size: 0.78rem; background: var(--color-surface); }
.btn-primary { height: 38px; padding: 0 var(--space-5); background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); font-size: 0.875rem; font-weight: 500; cursor: pointer; }
.btn-primary:hover:not(:disabled) { background: var(--color-accent); }
.btn-primary:disabled { opacity: 0.65; cursor: not-allowed; }
.btn-secondary { height: 38px; padding: 0 var(--space-5); background: var(--color-surface-2); color: var(--color-text); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; cursor: pointer; }
.mono { font-family: var(--font-mono); }
.small { font-size: 0.75rem; }
.text-muted { color: var(--color-text-muted); }

/* Guide */
.guide-section { border: 1px solid var(--color-border-light); border-radius: var(--radius-md); background: var(--color-surface); overflow: hidden; }
.guide-section--open { border-color: var(--color-accent); }
.guide-toggle { width: 100%; display: flex; align-items: center; gap: var(--space-2); padding: var(--space-3) var(--space-4); background: none; border: none; cursor: pointer; font-size: 0.82rem; font-weight: 600; color: var(--color-text); text-align: left; }
.guide-toggle:hover { background: var(--color-surface-2); }
.guide-icon { font-size: 0.8rem; flex-shrink: 0; }
.guide-hint { margin-left: auto; font-size: 0.7rem; font-weight: 400; color: var(--color-text-muted); }
.guide-content { padding: 0 var(--space-5) var(--space-5); display: flex; flex-direction: column; gap: var(--space-4); }
.guide-title { font-size: 0.82rem; font-weight: 700; color: var(--color-primary); margin-bottom: var(--space-2); }
.guide-text { font-size: 0.8rem; color: var(--color-text-muted); line-height: 1.7; margin-bottom: var(--space-2); }
.guide-steps { font-size: 0.8rem; color: var(--color-text-muted); line-height: 1.8; padding-left: var(--space-5); }
.guide-steps li { margin-bottom: var(--space-1); }
.guide-list { font-size: 0.8rem; color: var(--color-text-muted); line-height: 1.8; padding-left: var(--space-5); list-style: disc; }
.guide-list li { margin-bottom: var(--space-1); }
.guide-content code { font-family: var(--font-mono); font-size: 0.75rem; background: var(--color-surface-2); padding: 1px 4px; border-radius: 3px; }
.guide-content strong { color: var(--color-text); }

/* Target toggle */
.target-toggle {
  display: flex;
  gap: 0;
  border: 1px solid var(--border);
  border-radius: 6px;
  overflow: hidden;
}
.toggle-btn {
  flex: 1;
  padding: 8px 12px;
  border: none;
  background: transparent;
  color: var(--text-secondary);
  cursor: pointer;
  font-size: 0.85rem;
  transition: all 0.15s;
}
.toggle-btn.active {
  background: var(--color-primary);
  color: #fff;
}

/* Template actions */
.template-actions {
  display: flex;
  gap: 8px;
  margin-left: auto;
  margin-right: 12px;
}
.btn-text {
  background: none;
  border: none;
  color: var(--color-accent);
  cursor: pointer;
  font-size: 0.8rem;
  padding: 4px 8px;
}
.btn-text:hover { text-decoration: underline; }
.plan-badge--template {
  background: var(--color-accent);
  color: #fff;
}

/* Template list & cards */
.small-modal { background: var(--color-surface); border-radius: var(--radius-lg); width: 100%; max-width: 500px; max-height: 80vh; display: flex; flex-direction: column; box-shadow: var(--shadow-lg); }
.template-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.template-card {
  padding: 12px;
  border: 1px solid var(--border);
  border-radius: 6px;
  cursor: pointer;
  transition: border-color 0.15s;
}
.template-card:hover {
  border-color: var(--color-accent);
}
.template-card-title {
  font-weight: 600;
  margin-bottom: 4px;
}

/* Exclusions */
.exclusion-list {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.exclusion-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 8px;
  background: var(--bg-tertiary);
  border-radius: 4px;
  font-size: 0.85rem;
}

/* Search input */
.search-input {
  height: 30px;
  padding: 0 var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  font-size: 0.78rem;
  background: var(--color-surface);
  outline: none;
  min-width: 160px;
}
.search-input:focus { border-color: var(--color-accent); }
.search-input::placeholder { color: var(--color-text-muted); }

/* Due status dots */
.due-cell { display: flex; align-items: center; gap: 6px; }
.due-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
.due-dot--ok { background: #27AE60; }
.due-dot--soon { background: #F39C12; }
.due-dot--overdue { background: var(--color-alert); }

/* Template choice panel */
.template-choice-panel {
  border: 1px solid var(--color-border-light);
  border-radius: var(--radius);
  padding: var(--space-4);
  background: var(--color-surface-2);
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
}
.template-choice-title {
  font-size: 0.85rem;
  font-weight: 600;
  color: var(--color-text);
}
.template-choice-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.template-choice-card {
  padding: 10px 12px;
  border: 1px solid var(--color-border-light);
  border-radius: var(--radius);
  cursor: pointer;
  background: var(--color-surface);
  transition: border-color 0.15s;
}
.template-choice-card:hover {
  border-color: var(--color-accent);
}
.template-choice-card-title {
  font-weight: 600;
  font-size: 0.85rem;
  margin-bottom: 2px;
}
.template-choice-card-meta {
  font-size: 0.72rem;
}
.template-choice-skip {
  align-self: flex-start;
  font-size: 0.82rem;
  padding: var(--space-1) 0;
}

/* Save template offer */
.save-template-offer {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  padding: var(--space-3) var(--space-4);
  background: rgba(39,174,96,0.06);
  border: 1px solid rgba(39,174,96,0.25);
  border-radius: var(--radius);
}
.save-template-text {
  font-size: 0.85rem;
  font-weight: 500;
  color: #27AE60;
}
.save-template-dismiss {
  margin-left: auto;
  background: none;
  border: none;
  cursor: pointer;
  font-size: 0.8rem;
  color: var(--color-text-muted);
  padding: 2px 4px;
}
.save-template-dismiss:hover { color: var(--color-text); }

/* ─── Staggering section ─── */
.stagger-section {
  border: 1px solid var(--color-border-light); border-radius: var(--radius-md);
  background: var(--color-surface); overflow: hidden;
}
.stagger-section--open { border-color: var(--color-accent); }
.stagger-toggle {
  width: 100%; display: flex; align-items: center; gap: var(--space-2);
  padding: var(--space-3) var(--space-4);
  background: none; border: none; cursor: pointer;
  font-size: 0.82rem; font-weight: 600; color: var(--color-text); text-align: left;
}
.stagger-toggle:hover { background: var(--color-surface-2); }
.stagger-toggle-icon { font-size: 0.8rem; flex-shrink: 0; }
.stagger-hint { margin-left: auto; font-size: 0.7rem; font-weight: 400; color: var(--color-text-muted); }
.stagger-status {
  font-size: 0.62rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;
  padding: 2px 8px; border-radius: 20px;
  background: var(--color-surface-2); color: var(--color-text-muted);
}
.stagger-status--active { background: rgba(39,174,96,0.1); color: #27AE60; }

.stagger-body { padding: 0 var(--space-5) var(--space-5); display: flex; flex-direction: column; gap: var(--space-4); }

.stagger-tabs { display: flex; gap: 0; border-bottom: 1px solid var(--color-border-light); }
.stagger-tab {
  padding: var(--space-2) var(--space-4);
  background: none; border: none; border-bottom: 2px solid transparent;
  font-size: 0.78rem; font-weight: 600; color: var(--color-text-muted);
  cursor: pointer; transition: all 0.15s;
}
.stagger-tab:hover { color: var(--color-text); }
.stagger-tab--active { color: var(--color-accent); border-bottom-color: var(--color-accent); }

.stagger-panel { display: flex; flex-direction: column; gap: var(--space-4); }
.stagger-desc { font-size: 0.82rem; color: var(--color-text-muted); line-height: 1.6; }
.stagger-empty { padding: var(--space-6); text-align: center; font-size: 0.875rem; color: var(--color-text-muted); }
.stagger-error {
  background: rgba(233,69,96,0.08); border: 1px solid rgba(233,69,96,0.3);
  border-radius: var(--radius); padding: var(--space-3);
  font-size: 0.82rem; color: var(--color-alert);
}

.stagger-form { display: flex; flex-direction: column; gap: var(--space-3); }
.stagger-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-3); }
.stagger-actions { display: flex; gap: var(--space-3); }
.stagger-toggle-active { padding-top: var(--space-2); border-top: 1px solid var(--color-border-light); }

.stagger-preview-wrap { border-top: 1px solid var(--color-border-light); padding-top: var(--space-4); }
.stagger-preview-header {
  display: flex; justify-content: space-between; align-items: center;
  margin-bottom: var(--space-3);
}
.stagger-preview-title { font-size: 0.82rem; font-weight: 700; color: var(--color-primary); }
.btn-apply { height: 36px; padding: 0 var(--space-5); font-size: 0.82rem; }

/* Schedule table */
.schedule-meta {
  display: flex; flex-wrap: wrap; gap: var(--space-3);
  font-size: 0.82rem; margin-bottom: var(--space-3);
  padding-bottom: var(--space-3); border-bottom: 1px solid var(--color-border-light);
}
.schedule-meta strong { font-size: 0.68rem; text-transform: uppercase; color: var(--color-text-muted); }

.schedule-table, .cycles-table { width: 100%; border-collapse: collapse; font-size: 0.78rem; }
.schedule-table th, .cycles-table th {
  padding: var(--space-2) var(--space-3);
  font-size: 0.62rem; font-weight: 700; text-transform: uppercase;
  color: var(--color-text-muted); background: var(--color-surface-2);
  border-bottom: 1px solid var(--color-border-light); text-align: left;
}
.schedule-table td, .cycles-table td {
  padding: var(--space-2) var(--space-3);
  border-bottom: 1px solid var(--color-border-light); vertical-align: middle;
}
.schedule-row--done { opacity: 0.6; }
.schedule-row--rescheduled { background: rgba(243,156,18,0.04); }
.rescheduled-from { font-size: 0.65rem; color: var(--color-text-muted); display: block; }

.entry-node { font-weight: 500; display: block; }
.entry-code { font-size: 0.68rem; color: var(--color-text-muted); display: block; }
.entry-status {
  font-size: 0.62rem; font-weight: 700; padding: 2px 8px; border-radius: 20px;
  background: var(--color-surface-2); color: var(--color-text-muted);
}
.entry-status--scheduled { background: rgba(15,52,96,0.08); color: var(--color-accent); }
.entry-status--completed { background: rgba(39,174,96,0.1); color: #27AE60; }
.entry-status--rescheduled { background: rgba(243,156,18,0.1); color: #F39C12; }
.entry-status--skipped { background: rgba(233,69,96,0.08); color: var(--color-alert); }

/* Cycles table */
.cycle-row { cursor: pointer; transition: background 0.15s; }
.cycle-row:hover { background: var(--color-surface-2); }
.cycle-status {
  font-size: 0.62rem; font-weight: 700; padding: 2px 8px; border-radius: 20px;
  background: var(--color-surface-2); color: var(--color-text-muted);
}
.cycle-status--planned { background: rgba(15,52,96,0.08); color: var(--color-accent); }
.cycle-status--in_progress { background: rgba(243,156,18,0.1); color: #F39C12; }
.cycle-status--completed { background: rgba(39,174,96,0.1); color: #27AE60; }

.compliance-cell { display: flex; flex-direction: column; gap: 2px; }
.mini-bar { height: 3px; background: var(--color-border-light); border-radius: 2px; overflow: hidden; width: 60px; }
.mini-bar-fill { height: 100%; border-radius: 2px; }

.text-success { color: #27AE60 !important; }

/* Dialog modals */
.dialog-modal {
  background: var(--color-surface); border-radius: var(--radius-lg);
  width: 100%; max-width: 400px; box-shadow: var(--shadow-lg); overflow: hidden;
}
.dialog-body { padding: var(--space-6); }
.dialog-message { font-size: 0.9rem; line-height: 1.6; color: var(--color-text); margin: 0; }
.dialog-footer {
  display: flex; justify-content: flex-end; gap: var(--space-3);
  padding: var(--space-3) var(--space-6); border-top: 1px solid var(--color-border-light);
  background: var(--color-surface-2);
}
.dialog-body .field-input { margin-top: var(--space-3); }

/* Toast notification */
.toast-notification {
  position: fixed; bottom: var(--space-6); left: 50%; transform: translateX(-50%);
  z-index: 2000; padding: var(--space-3) var(--space-6);
  border-radius: var(--radius-md); font-size: 0.85rem; font-weight: 500;
  box-shadow: var(--shadow-lg); max-width: 500px; text-align: center; cursor: pointer;
}
.toast--success { background: #27AE60; color: #fff; }
.toast--error { background: var(--color-alert); color: #fff; }
.toast-enter-active, .toast-leave-active { transition: all 0.3s ease; }
.toast-enter-from, .toast-leave-to { opacity: 0; transform: translateX(-50%) translateY(20px); }

@media (max-width: 768px) {
  .page-header { flex-direction: column; gap: var(--space-3); }
  .page-title { font-size: 1.15rem; }
  .header-actions { width: 100%; flex-wrap: wrap; }
  .compliance-grid { grid-template-columns: repeat(2, 1fr); }
  .field-row, .stagger-form-row { grid-template-columns: 1fr; }

  .modal-overlay { padding: 0; }
  .plan-modal, .detail-modal { max-width: 100%; border-radius: 0; max-height: 100vh; max-height: 100dvh; }
  .modal-body { padding: var(--space-4); }
  .field-input { height: 42px; }
  .btn-primary, .btn-secondary { height: 44px; font-size: 0.9rem; }

  .stagger-actions { flex-direction: column; }
  .schedule-meta { flex-direction: column; gap: var(--space-1); }
  .toast-notification { max-width: calc(100vw - var(--space-8)); }
}

@media (max-width: 480px) {
  .compliance-grid { grid-template-columns: 1fr; }
}
</style>
