<template>
  <div class="login-root">
    <!-- Left panel: visual identity -->
    <div class="login-brand">
      <div class="brand-content">
        <div class="brand-logo">
          <span class="brand-alpha">A</span>
        </div>
        <h1 class="brand-name">ARCHE</h1>
        <p class="brand-tagline">Plataforma Industrial de Mantenimiento Inteligente</p>
        <div class="brand-divider"></div>
        <p class="brand-desc">
          Control total sobre tus instalaciones.<br />
          Cada equipo. Cada intervención. Cada dato.
        </p>
      </div>
      <p class="brand-version">Arche GMAO V1.1.0</p>
    </div>

    <!-- Right panel: form -->
    <div class="login-panel">
      <div class="login-form-wrapper">
        <h2 class="login-title">Acceder al sistema</h2>
        <p class="login-subtitle">Introduce tus credenciales para continuar</p>

        <form class="login-form" @submit.prevent="handleLogin">
          <div class="field">
            <label for="email" class="field-label">Correo electrónico</label>
            <input
              id="email"
              v-model="form.email"
              type="email"
              class="field-input"
              :class="{ 'field-input--error': !!authStore.error }"
              placeholder="usuario@empresa.com"
              autocomplete="email"
              required
              :disabled="authStore.loading"
            />
          </div>

          <div class="field">
            <label for="password" class="field-label">Contraseña</label>
            <div class="field-input-wrap">
              <input
                id="password"
                v-model="form.password"
                :type="showPassword ? 'text' : 'password'"
                class="field-input field-input--password"
                :class="{ 'field-input--error': !!authStore.error }"
                placeholder="••••••••"
                autocomplete="current-password"
                required
                :disabled="authStore.loading"
              />
              <button
                type="button"
                class="field-toggle"
                @click="showPassword = !showPassword"
                :aria-label="showPassword ? 'Ocultar contraseña' : 'Mostrar contraseña'"
              >
                {{ showPassword ? '◉' : '○' }}
              </button>
            </div>
          </div>

          <div v-if="authStore.error" class="login-error" role="alert">
            {{ authStore.error }}
          </div>

          <button
            type="submit"
            class="login-btn"
            :disabled="authStore.loading"
          >
            <span v-if="authStore.loading" class="btn-loading">
              <span class="loading-dot"></span>
              <span class="loading-dot"></span>
              <span class="loading-dot"></span>
            </span>
            <span v-else>Acceder</span>
          </button>
        </form>

        <p class="login-help">
          Sistema restringido. Solo personal autorizado.
        </p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const authStore = useAuthStore()
const router = useRouter()
const route = useRoute()

const showPassword = ref(false)
const form = ref({
  email: '',
  password: ''
})

async function handleLogin() {
  authStore.clearError()
  const ok = await authStore.login(form.value)
  if (ok) {
    let redirect = (route.query.redirect as string) ?? '/dashboard'
    // Prevent open redirects: allow internal routes only
    if (!redirect.startsWith('/') || redirect.startsWith('//')) {
      redirect = '/dashboard'
    }
    router.push(redirect)
  }
}
</script>

<style scoped>
.login-root {
  display: flex;
  min-height: 100vh;
}

/* ─── Left panel ────────────────────────────────────────── */

.login-brand {
  width: 420px;
  flex-shrink: 0;
  background: var(--color-primary);
  color: #fff;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: var(--space-12) var(--space-10);
}

.brand-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.brand-logo {
  width: 64px;
  height: 64px;
  border: 2px solid rgba(255,255,255,0.3);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: var(--space-6);
}

.brand-alpha {
  font-family: var(--font-mono);
  font-size: 2rem;
  font-weight: 500;
  color: #fff;
  letter-spacing: -2px;
}

.brand-name {
  font-size: 2.25rem;
  font-weight: 700;
  letter-spacing: 6px;
  color: #fff;
  margin-bottom: var(--space-2);
}

.brand-tagline {
  font-size: 0.8rem;
  color: rgba(255,255,255,0.5);
  text-transform: uppercase;
  letter-spacing: 1px;
  margin-bottom: var(--space-8);
}

.brand-divider {
  width: 40px;
  height: 2px;
  background: var(--color-accent);
  margin-bottom: var(--space-6);
}

.brand-desc {
  font-size: 0.95rem;
  color: rgba(255,255,255,0.7);
  line-height: 1.8;
}

.brand-version {
  font-family: var(--font-mono);
  font-size: 0.7rem;
  color: rgba(255,255,255,0.3);
}

/* ─── Right panel ──────────────────────────────────────────── */

.login-panel {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--color-surface);
  padding: var(--space-8);
}

.login-form-wrapper {
  width: 100%;
  max-width: 400px;
}

.login-title {
  font-size: 1.5rem;
  font-weight: 600;
  color: var(--color-primary);
  margin-bottom: var(--space-1);
}

.login-subtitle {
  font-size: 0.875rem;
  color: var(--color-text-muted);
  margin-bottom: var(--space-8);
}

/* ─── Fields ─────────────────────────────────────────────────── */

.login-form {
  display: flex;
  flex-direction: column;
  gap: var(--space-5);
}

.field {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
}

.field-label {
  font-size: 0.8rem;
  font-weight: 500;
  color: var(--color-text-muted);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.field-input {
  height: 44px;
  padding: 0 var(--space-4);
  border: 1px solid var(--color-border);
  border-radius: var(--radius);
  font-size: 0.9rem;
  color: var(--color-text);
  background: var(--color-surface);
  transition: border-color var(--transition), box-shadow var(--transition);
  outline: none;
  width: 100%;
}

.field-input:focus {
  border-color: var(--color-accent);
  box-shadow: 0 0 0 3px rgba(15, 52, 96, 0.1);
}

.field-input--error {
  border-color: var(--color-alert);
}

.field-input--error:focus {
  box-shadow: 0 0 0 3px rgba(233, 69, 96, 0.1);
}

.field-input--password {
  padding-right: 48px;
}

.field-input-wrap {
  position: relative;
}

.field-toggle {
  position: absolute;
  right: 0;
  top: 0;
  height: 44px;
  width: 44px;
  background: none;
  border: none;
  cursor: pointer;
  color: var(--color-text-muted);
  font-size: 1rem;
  display: flex;
  align-items: center;
  justify-content: center;
}

.field-toggle:hover {
  color: var(--color-accent);
}

/* ─── Error ──────────────────────────────────────────────────── */

.login-error {
  background: rgba(233, 69, 96, 0.08);
  border: 1px solid rgba(233, 69, 96, 0.3);
  border-radius: var(--radius);
  padding: var(--space-3) var(--space-4);
  font-size: 0.875rem;
  color: var(--color-alert);
}

/* ─── Button ──────────────────────────────────────────────────── */

.login-btn {
  height: 44px;
  background: var(--color-primary);
  color: #fff;
  border: none;
  border-radius: var(--radius);
  font-size: 0.9rem;
  font-weight: 600;
  cursor: pointer;
  transition: background var(--transition), opacity var(--transition);
  display: flex;
  align-items: center;
  justify-content: center;
  letter-spacing: 0.5px;
  margin-top: var(--space-2);
}

.login-btn:hover:not(:disabled) {
  background: var(--color-accent);
}

.login-btn:disabled {
  opacity: 0.65;
  cursor: not-allowed;
}

/* ─── Loading dots ───────────────────────────────────────────── */

.btn-loading {
  display: flex;
  gap: 5px;
  align-items: center;
}

.loading-dot {
  width: 6px;
  height: 6px;
  background: #fff;
  border-radius: 50%;
  animation: dot-blink 1.2s infinite;
}

.loading-dot:nth-child(2) { animation-delay: 0.2s; }
.loading-dot:nth-child(3) { animation-delay: 0.4s; }

@keyframes dot-blink {
  0%, 80%, 100% { opacity: 0.2; transform: scale(0.8); }
  40%           { opacity: 1;   transform: scale(1); }
}

/* ─── Footer ─────────────────────────────────────────────────── */

.login-help {
  margin-top: var(--space-6);
  font-size: 0.75rem;
  color: var(--color-text-light);
  text-align: center;
}

/* ─── Responsive ─────────────────────────────────────────────── */

@media (max-width: 768px) {
  .login-root { flex-direction: column; }
  .login-brand {
    width: 100%;
    padding: var(--space-8) var(--space-6);
    min-height: 200px;
  }
  .brand-content { flex-direction: row; align-items: center; gap: var(--space-4); }
  .brand-desc, .brand-divider { display: none; }
  .brand-name { font-size: 1.5rem; margin-bottom: 0; }
}
</style>
