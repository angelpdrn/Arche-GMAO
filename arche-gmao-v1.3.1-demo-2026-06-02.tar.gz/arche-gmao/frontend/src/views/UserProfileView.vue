<template>
  <div v-if="loading" class="profile-loading">Cargando perfil...</div>
  <div v-else-if="!profile" class="profile-error">Usuario no encontrado</div>
  <div v-else class="profile-layout">

    <!-- ─── Header ────────────────────────────────────────────────────────── -->
    <div class="profile-header-card">
      <div class="profile-avatar" :style="{ background: profile.user.avatar_color }">
        {{ initials }}
      </div>
      <div class="profile-header-info">
        <div class="profile-name-row">
          <h1 class="profile-name">{{ profile.user.full_name }}</h1>
          <span class="profile-status" :class="`status--${profile.user.status}`">
            {{ STATUS_LABELS[profile.user.status] ?? profile.user.status }}
          </span>
        </div>
        <div class="profile-role-row">
          <span class="profile-role">{{ ROLE_LABELS[profile.user.role] ?? profile.user.role }}</span>
          <span v-if="profile.user.department" class="profile-dept">· {{ profile.user.department }}</span>
          <span v-if="profile.user.position" class="profile-position">· {{ profile.user.position }}</span>
        </div>
        <div class="profile-contact">
          <span class="contact-item">✉ {{ profile.user.email }}</span>
          <span v-if="profile.user.phone" class="contact-item">☎ {{ profile.user.phone }}</span>
          <span v-if="profile.user.hire_date" class="contact-item">
            Desde {{ formatDate(profile.user.hire_date) }}
          </span>
        </div>
        <p v-if="profile.user.bio" class="profile-bio">{{ profile.user.bio }}</p>
        <button v-if="canEdit" class="btn-edit-profile" @click="openEdit">✎ Editar perfil</button>
      </div>

      <!-- Rank -->
      <div class="profile-rank-card">
        <div class="rank-icon" :style="{ color: profile.rank.color }">{{ profile.rank.icon }}</div>
        <div class="rank-name" :style="{ color: profile.rank.color }">{{ profile.rank.name }}</div>
        <div class="rank-progress-wrap">
          <div class="rank-progress-bar">
            <div class="rank-progress-fill"
              :style="{ width: profile.rank.progress + '%', background: profile.rank.color }">
            </div>
          </div>
          <span class="rank-progress-label">
            {{ profile.rank.completed }} / {{ profile.rank.next_min }} OTs
          </span>
        </div>
        <div v-if="profile.rank.bonus" class="rank-bonus">{{ profile.rank.bonus }}</div>
      </div>
    </div>

    <!-- ─── Main KPIs ─────────────────────────────────────────────── -->
    <div class="kpi-grid kpi-grid--primary">
      <div class="kpi-card kpi-card--accent">
        <span class="kpi-value">{{ profile.wo_stats.assigned ?? 0 }}</span>
        <span class="kpi-label">OTs asignadas</span>
      </div>
      <div class="kpi-card kpi-card--blue">
        <span class="kpi-value">{{ profile.wo_stats.in_progress ?? 0 }}</span>
        <span class="kpi-label">OTs en curso</span>
      </div>
      <div class="kpi-card kpi-card--warn">
        <span class="kpi-value">{{ profile.wo_stats.paused ?? 0 }}</span>
        <span class="kpi-label">OTs pendientes</span>
      </div>
    </div>

    <!-- ─── Secondary statistics ─────────────────────────────────────── -->
    <div class="kpi-grid kpi-grid--secondary">
      <div class="kpi-card kpi-card--small kpi-card--green">
        <span class="kpi-value">{{ profile.wo_stats.completed ?? 0 }}</span>
        <span class="kpi-label">Completadas</span>
      </div>
      <div class="kpi-card kpi-card--small">
        <span class="kpi-value">{{ profile.wo_stats.avg_hours?.toFixed(1) ?? '—' }}h</span>
        <span class="kpi-label">Horas medias / OT</span>
      </div>
      <div class="kpi-card kpi-card--small" :class="profile.wo_stats.on_time_rate >= 80 ? 'kpi-card--green' : 'kpi-card--warn'">
        <span class="kpi-value">{{ profile.wo_stats.on_time_rate ?? 0 }}%</span>
        <span class="kpi-label">A tiempo</span>
      </div>
      <div class="kpi-card kpi-card--small kpi-card--purple">
        <span class="kpi-value">{{ profile.score_stats.avg_score?.toFixed(1) ?? '—' }}</span>
        <span class="kpi-label">Puntuacion media</span>
      </div>
    </div>

    <div class="profile-main-grid">
      <!-- Left column -->
      <div class="profile-col">

        <!-- Tags / skills -->
        <div class="card" v-if="profile.tags?.length || canEdit">
          <div class="card-header">
            <span class="card-title">Habilidades y especialidades</span>
          </div>
          <div class="card-body">
            <div v-if="profile.tags?.length" class="tags-wrap">
              <span v-for="tag in profile.tags" :key="tag" class="skill-tag">{{ tag }}</span>
            </div>
            <p v-else class="text-muted small">Sin habilidades registradas</p>
          </div>
        </div>

        <!-- Breakdown by WO type -->
        <div class="card" v-if="profile.type_distrib?.length">
          <div class="card-header"><span class="card-title">Tipo de trabajo</span></div>
          <div class="card-body">
            <div v-for="td in profile.type_distrib" :key="td.type" class="type-row">
              <span class="type-label">{{ TYPE_LABELS[td.type] ?? td.type }}</span>
              <div class="type-bar-wrap">
                <div class="type-bar" :style="{
                  width: (td.count / profile.wo_stats.total * 100) + '%',
                  background: TYPE_COLORS[td.type] ?? '#888'
                }"></div>
              </div>
              <span class="type-count">{{ td.count }}</span>
            </div>
          </div>
        </div>

        <!-- Certifications -->
        <div class="card" v-if="certifications.length || canEdit">
          <div class="card-header">
            <span class="card-title">Certificaciones</span>
            <button v-if="canEdit" class="btn-add-cert" @click="addCert">+ Añadir</button>
          </div>
          <div class="card-body">
            <div v-if="certifications.length" class="cert-list">
              <div v-for="(cert, i) in certifications" :key="i" class="cert-item">
                <span class="cert-icon">◉</span>
                <div class="cert-info">
                  <span class="cert-name">{{ cert.name }}</span>
                  <span class="cert-date text-muted small" v-if="cert.date">{{ cert.date }}</span>
                </div>
                <button v-if="canEdit" class="action-btn action-btn--del"
                  @click="removeCert(i)">✕</button>
              </div>
            </div>
            <p v-else class="text-muted small">Sin certificaciones registradas</p>
          </div>
        </div>
      </div>

      <!-- Right column -->
      <div class="profile-col">

        <!-- ─── Daily summaries (calendar) ─────────────────────────────── -->
        <div class="card" v-if="showSummarySection">
          <div class="card-header">
            <span class="card-title">Resumenes diarios</span>
            <span v-if="monthFrozen" class="frozen-badge">Mes cerrado</span>
          </div>
          <div class="card-body">
            <div class="cal-controls">
              <button class="cal-nav" @click="calPrev">&lt;</button>
              <span class="cal-month-label">{{ calMonthLabel }}</span>
              <button class="cal-nav" @click="calNext">&gt;</button>
            </div>
            <div class="cal-grid">
              <span class="cal-weekday" v-for="d in ['L','M','X','J','V','S','D']" :key="d">{{ d }}</span>
              <button v-for="(day, i) in calDays" :key="i"
                class="cal-day"
                :class="{
                  'cal-day--other': day.other,
                  'cal-day--today': day.today,
                  'cal-day--selected': day.date === selectedDate,
                  'cal-day--has-activity': day.count > 0
                }"
                :disabled="day.other"
                @click="!day.other && selectDay(day.date)">
                {{ day.num }}
                <span v-if="day.count > 0" class="cal-dot"></span>
              </button>
            </div>

            <!-- Detail of the selected day -->
            <div v-if="selectedDate" class="day-detail">
              <div class="day-detail-header">
                <span class="day-detail-title">{{ formatCalDate(selectedDate) }}</span>
                <span v-if="daySummaries.length" class="day-detail-badge">
                  {{ daySummaries.length }} registro{{ daySummaries.length > 1 ? 's' : '' }}
                  · {{ daySummariesHours.toFixed(1) }}h
                </span>
                <span v-else class="day-detail-empty-badge">Sin registros</span>
              </div>

              <div v-if="dayDetailLoading" class="day-detail-loading">Cargando...</div>

              <!-- List of the day's summaries -->
              <div v-else-if="daySummaries.length" class="day-detail-list">
                <div v-for="s in daySummaries" :key="s.id" class="day-entry">
                  <div class="day-entry-header">
                    <span v-if="s.wo_number" class="day-entry-wo mono">{{ s.wo_number }}</span>
                    <span class="day-entry-type" :style="{ background: SHIFT_COLORS[s.shift] ?? '#888' }">
                      {{ s.shift }}
                    </span>
                    <span v-for="ex in s.shift_extras" :key="ex" class="day-entry-extra">{{ ex }}</span>
                    <span class="day-entry-hours-badge">{{ s.hours.toFixed(1) }}h</span>
                  </div>
                  <div v-if="s.wo_title" class="day-entry-title">{{ s.wo_title }}</div>
                  <div class="day-entry-client">{{ s.client_name }}
                    <span v-if="s.project_number && s.project_number !== 'Interno'"> · Proy: {{ s.project_number }}</span>
                  </div>
                  <div v-if="s.observations" class="day-entry-obs">{{ s.observations }}</div>
                  <!-- Edit/delete buttons when it is your own and not frozen -->
                  <div v-if="canEditSummaries && !monthFrozen" class="day-entry-actions">
                    <button class="action-btn" @click="editSummary(s)">✎</button>
                    <button class="action-btn action-btn--del" @click="deleteSummary(s.id)">✕</button>
                  </div>
                </div>
              </div>

              <div v-else-if="!dayDetailLoading" class="day-detail-none">
                Sin registros para este dia
              </div>

              <!-- Add summary button (technicians, own profile, month not frozen) -->
              <button v-if="canEditSummaries && !monthFrozen" class="btn-add-summary"
                @click="openSummaryForm">
                + Añadir resumen
              </button>
            </div>

            <!-- Download buttons (admin/supervisor) -->
            <div v-if="canViewActivity" class="cal-actions">
              <button class="btn-cal-dl" @click="downloadUserMonth" :disabled="dlLoading">
                {{ dlLoading ? '...' : '↓ Excel técnico' }}
              </button>
              <button class="btn-cal-dl btn-cal-dl--primary" @click="downloadAllMonth" :disabled="dlLoading">
                {{ dlLoading ? 'Descargando...' : '↓ ZIP todos los tecnicos' }}
              </button>
            </div>
            <div v-if="dlError" class="day-detail-error">{{ dlError }}</div>
          </div>
        </div>

        <!-- Monthly activity -->
        <div class="card" v-if="profile.activity?.length">
          <div class="card-header"><span class="card-title">Actividad (últimos 6 meses)</span></div>
          <div class="card-body">
            <div class="activity-chart">
              <div v-for="a in profile.activity" :key="a.month" class="activity-bar-wrap">
                <div class="activity-bar"
                  :style="{ height: (a.count / maxActivity * 80) + 'px' }"
                  :title="`${a.month}: ${a.count} OTs`">
                </div>
                <span class="activity-month">{{ a.month }}</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Change password (own profile only) -->
        <div class="card" v-if="isOwnProfile">
          <div class="card-header"><span class="card-title">Cambiar contraseña</span></div>
          <div class="card-body">
            <form @submit.prevent="submitPasswordChange" class="pw-form">
              <div class="field">
                <label class="field-label">Contraseña actual</label>
                <input v-model="pwForm.current" type="password" class="field-input"
                  autocomplete="current-password" placeholder="Tu contraseña actual" />
              </div>
              <div class="field">
                <label class="field-label">Nueva contraseña</label>
                <input v-model="pwForm.newPw" type="password" class="field-input"
                  autocomplete="new-password" placeholder="Min. 8 caracteres, mayúscula, minúscula, número" />
              </div>
              <div class="field">
                <label class="field-label">Confirmar nueva contraseña</label>
                <input v-model="pwForm.confirm" type="password" class="field-input"
                  autocomplete="new-password" placeholder="Repetir nueva contraseña" />
              </div>
              <div v-if="pwError" class="pw-error">{{ pwError }}</div>
              <div v-if="pwSuccess" class="pw-success">{{ pwSuccess }}</div>
              <button type="submit" class="btn-primary btn-pw" :disabled="pwSaving || !pwFormValid">
                {{ pwSaving ? 'Guardando...' : 'Cambiar contraseña' }}
              </button>
            </form>
          </div>
        </div>

        <!-- Notification preferences (own profile only) -->
        <div class="card" v-if="isOwnProfile">
          <div class="card-header"><span class="card-title">Preferencias de notificación</span></div>
          <div class="card-body">
            <div v-if="loadingPrefs" class="text-muted small">Cargando...</div>
            <div v-else-if="notifPrefs.length" class="notif-prefs-list">
              <div v-for="p in notifPrefs" :key="p.event_type" class="notif-pref-row">
                <span class="notif-pref-label">{{ NOTIF_TYPE_LABELS[p.event_type] ?? p.event_type }}</span>
                <label class="notif-toggle">
                  <input type="checkbox" v-model="p.in_app" @change="savePrefs" /> App
                </label>
                <label class="notif-toggle">
                  <input type="checkbox" v-model="p.email" @change="savePrefs" /> Email
                </label>
              </div>
            </div>
            <p v-else class="text-muted small">Sin preferencias configuradas. Las notificaciones estan activadas por defecto.</p>
          </div>
        </div>

        <!-- Latest WOs -->
        <div class="card">
          <div class="card-header"><span class="card-title">Últimas órdenes de trabajo</span></div>
          <div v-if="!profile.recent_wos?.length" class="card-empty">Sin OTs asignadas</div>
          <div v-else class="recent-wo-list">
            <div v-for="wo in profile.recent_wos" :key="wo.wo_number" class="recent-wo-item">
              <div class="wo-item-left">
                <span class="wo-number mono">{{ wo.wo_number }}</span>
                <span class="wo-title">{{ wo.title }}</span>
                <span class="wo-node text-muted small">{{ wo.node_name }}</span>
              </div>
              <div class="wo-item-right">
                <span class="wo-priority" :style="{ background: PRIORITY_COLORS[wo.priority] }">
                  {{ wo.priority }}
                </span>
                <span class="wo-status" :class="`wo-status--${wo.status}`">
                  {{ STATUS_WO_LABELS[wo.status] ?? wo.status }}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ─── Edit profile modal ───────────────────────────────────────────── -->
    <Teleport to="body">
      <div v-if="showEditModal" class="modal-overlay" @click.self="showEditModal = false">
        <div class="edit-modal">
          <div class="modal-header">
            <h3>Editar perfil</h3>
            <button class="modal-close" @click="showEditModal = false">✕</button>
          </div>
          <div class="modal-body">
            <div class="field-row">
              <div class="field">
                <label class="field-label">Telefono</label>
                <input v-model="editForm.phone" class="field-input" placeholder="+34 600 000 000" />
              </div>
              <div class="field">
                <label class="field-label">Fecha de incorporacion</label>
                <input v-model="editForm.hire_date" type="date" class="field-input" />
              </div>
            </div>
            <div class="field-row">
              <div class="field">
                <label class="field-label">Departamento</label>
                <input v-model="editForm.department" class="field-input" placeholder="Mantenimiento" />
              </div>
              <div class="field">
                <label class="field-label">Cargo</label>
                <input v-model="editForm.position" class="field-input" placeholder="Técnico de mantenimiento" />
              </div>
            </div>
            <div class="field">
              <label class="field-label">Descripción / Bio</label>
              <textarea v-model="editForm.bio" class="field-input" rows="3"
                placeholder="Breve descripción del técnico, especialidades, experiencia..." />
            </div>
            <div class="field">
              <label class="field-label">Color del avatar</label>
              <div class="color-picker">
                <div v-for="color in AVATAR_COLORS" :key="color"
                  class="color-swatch"
                  :class="{ 'color-swatch--active': editForm.avatar_color === color }"
                  :style="{ background: color }"
                  @click="editForm.avatar_color = color">
                </div>
              </div>
            </div>
            <div v-if="editError" class="modal-error">{{ editError }}</div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary" @click="showEditModal = false">Cancelar</button>
            <button class="btn-primary" :disabled="saving" @click="submitEdit">
              {{ saving ? 'Guardando...' : 'Guardar cambios' }}
            </button>
          </div>
        </div>
      </div>

      <!-- Add certification modal -->
      <div v-if="showCertModal" class="modal-overlay" @click.self="showCertModal = false">
        <div class="cert-modal">
          <div class="modal-header">
            <h3>Añadir certificacion</h3>
            <button class="modal-close" @click="showCertModal = false">✕</button>
          </div>
          <div class="modal-body">
            <div class="field">
              <label class="field-label">Nombre de la certificacion *</label>
              <input v-model="newCert.name" class="field-input"
                placeholder="Ej: Certificacion en Hidraulica Industrial" />
            </div>
            <div class="field">
              <label class="field-label">Fecha (opcional)</label>
              <input v-model="newCert.date" class="field-input" placeholder="2023" />
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary" @click="showCertModal = false">Cancelar</button>
            <button class="btn-primary" :disabled="!newCert.name.trim()" @click="submitCert">
              Añadir
            </button>
          </div>
        </div>
      </div>

      <!-- ─── Daily summary modal ────────────────────────────────────────── -->
      <div v-if="showSummaryModal" class="modal-overlay" @click.self="showSummaryModal = false">
        <div class="edit-modal">
          <div class="modal-header">
            <h3>{{ summaryForm.id ? 'Editar resumen' : 'Nuevo resumen' }} — {{ formatCalDate(selectedDate) }}</h3>
            <button class="modal-close" @click="showSummaryModal = false">✕</button>
          </div>
          <div class="modal-body">
            <!-- WO -->
            <div class="field">
              <label class="field-label">Orden de trabajo</label>
              <select v-model="summaryForm.wo_id" class="field-input">
                <option :value="null">— Sin OT —</option>
                <option v-for="wo in recentWOs" :key="wo.id" :value="wo.id">
                  {{ wo.wo_number }} — {{ wo.title }} ({{ wo.node_name }})
                </option>
              </select>
            </div>

            <!-- Client -->
            <div class="field">
              <label class="field-label">Cliente</label>
              <select v-if="clientsList.length" v-model="summaryForm.client_id" class="field-input">
                <option :value="null">Interno</option>
                <option v-for="cl in clientsList" :key="cl.id" :value="cl.id">{{ cl.name }}</option>
              </select>
              <input v-else class="field-input" value="Interno" disabled />
            </div>

            <!-- Project -->
            <div class="field">
              <label class="field-label">Número de proyecto</label>
              <input v-model="summaryForm.project_number" class="field-input"
                :disabled="!summaryForm.client_id"
                :placeholder="summaryForm.client_id ? 'Número de proyecto' : 'Interno'" />
            </div>

            <!-- Shift -->
            <div class="field">
              <label class="field-label">Turno *</label>
              <div class="shift-options">
                <label v-for="s in SHIFTS" :key="s" class="shift-radio"
                  :class="{ 'shift-radio--active': summaryForm.shift === s }">
                  <input type="radio" v-model="summaryForm.shift" :value="s" /> {{ s }}
                </label>
              </div>
            </div>

            <!-- Shift extras -->
            <div class="field">
              <label class="field-label">Condiciones adicionales (opcional)</label>
              <div class="shift-extras">
                <label v-for="ex in SHIFT_EXTRAS" :key="ex" class="shift-check"
                  :class="{ 'shift-check--active': summaryForm.shift_extras.includes(ex) }">
                  <input type="checkbox" :value="ex"
                    :checked="summaryForm.shift_extras.includes(ex)"
                    @change="toggleExtra(ex)" /> {{ EXTRA_LABELS[ex] }}
                </label>
              </div>
            </div>

            <!-- Hours -->
            <div class="field">
              <label class="field-label">Horas trabajadas *</label>
              <input v-model.number="summaryForm.hours" type="number" step="0.5" min="0" max="24"
                class="field-input" placeholder="Ej: 8" />
            </div>

            <!-- Notes -->
            <div class="field">
              <label class="field-label">Observaciones (opcional)</label>
              <textarea v-model="summaryForm.observations" class="field-input" rows="3"
                placeholder="Detalles adicionales del trabajo realizado..." />
            </div>

            <div v-if="summaryError" class="modal-error">{{ summaryError }}</div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary" @click="showSummaryModal = false">Cancelar</button>
            <button class="btn-primary" :disabled="summarySaving || !summaryFormValid"
              @click="submitSummary">
              {{ summarySaving ? 'Guardando...' : (summaryForm.id ? 'Guardar cambios' : 'Crear resumen') }}
            </button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'
import { apiErrorMsg } from '@/composables/useToast'
import { useRoute } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import client from '@/api/client'
import { ROLE_LABELS } from '@/types'

const route     = useRoute()
const authStore = useAuthStore()

const loading  = ref(true)
const profile  = ref<any>(null)
const showEditModal = ref(false)
const showCertModal = ref(false)
const saving   = ref(false)
const editError = ref('')
const editForm = ref({
  phone: '', department: '', position: '',
  bio: '', hire_date: '', avatar_color: '#0f3460'
})
const newCert = ref({ name: '', date: '' })

const STATUS_LABELS: Record<string, string> = {
  active: 'Activo', inactive: 'Inactivo', suspended: 'Suspendido'
}
const TYPE_LABELS: Record<string, string> = {
  corrective: 'Correctiva', preventive: 'Preventiva',
  inspection: 'Inspeccion', predictive: 'Predictiva',
}
const TYPE_COLORS: Record<string, string> = {
  corrective: '#E94560', preventive: '#27AE60',
  inspection: '#3B82F6', predictive: '#8B5CF6',
}
const PRIORITY_COLORS: Record<string, string> = {
  low: '#27AE60', medium: '#F39C12', high: '#E67E22', critical: '#E94560'
}
const STATUS_WO_LABELS: Record<string, string> = {
  pending: 'Pendiente', assigned: 'Asignada', in_progress: 'En progreso',
  completed: 'Completada', verified: 'Verificada', closed: 'Cerrada',
}
const AVATAR_COLORS = [
  '#0f3460', '#e94560', '#27AE60', '#3B82F6', '#8B5CF6',
  '#F39C12', '#E67E22', '#1ABC9C', '#2C3E50', '#7F8C8D',
]
const SHIFTS = ['mañana', 'tarde', 'noche'] as const
const SHIFT_EXTRAS = ['fin_de_semana', 'festivo', 'reten', 'guardia'] as const
const EXTRA_LABELS: Record<string, string> = {
  fin_de_semana: 'Fin de semana', festivo: 'Festivo', reten: 'Reten', guardia: 'Guardia'
}
const SHIFT_COLORS: Record<string, string> = {
  'mañana': '#F39C12', 'tarde': '#3B82F6', 'noche': '#8B5CF6'
}

const initials = computed(() => {
  const name = profile.value?.user?.full_name ?? ''
  return name.split(' ').slice(0, 2).map((w: string) => w[0]?.toUpperCase() ?? '').join('')
})

const canEdit = computed(() => {
  return authStore.user?.role === 'admin' || authStore.user?.id === profile.value?.user?.id
})

const isOwnProfile = computed(() => String(authStore.user?.id) === String(route.params.id))

const certifications = computed(() => {
  try {
    const raw = profile.value?.user?.certifications
    if (!raw) return []
    return typeof raw === 'string' ? JSON.parse(raw) : raw
  } catch { return [] }
})

const maxActivity = computed(() => {
  return Math.max(...(profile.value?.activity ?? []).map((a: any) => a.count), 1)
})

async function loadProfile() {
  loading.value = true
  try {
    const id = route.params.id
    const { data } = await client.get(`/users/${id}/profile`)
    profile.value = data
  } catch { profile.value = null }
  finally { loading.value = false }
}

function openEdit() {
  const u = profile.value?.user
  editForm.value = {
    phone:        u.phone ?? '',
    department:   u.department ?? '',
    position:     u.position ?? '',
    bio:          u.bio ?? '',
    hire_date:    u.hire_date ?? '',
    avatar_color: u.avatar_color ?? '#0f3460',
  }
  editError.value = ''
  showEditModal.value = true
}

async function submitEdit() {
  saving.value = true; editError.value = ''
  try {
    await client.put(`/users/${route.params.id}/profile`, {
      ...editForm.value,
      phone:      editForm.value.phone || null,
      department: editForm.value.department || null,
      position:   editForm.value.position || null,
      bio:        editForm.value.bio || null,
      hire_date:  editForm.value.hire_date || null,
    })
    showEditModal.value = false
    await loadProfile()
  } catch (err: unknown) {
    editError.value = apiErrorMsg(err, 'Error guardando')
  } finally { saving.value = false }
}

function addCert() {
  newCert.value = { name: '', date: '' }
  showCertModal.value = true
}

async function submitCert() {
  if (!newCert.value.name.trim()) return
  const certs = [...certifications.value, { name: newCert.value.name.trim(), date: newCert.value.date }]
  await client.put(`/users/${route.params.id}/profile`, {
    certifications: JSON.stringify(certs)
  })
  showCertModal.value = false
  await loadProfile()
}

async function removeCert(index: number) {
  const certs = certifications.value.filter((_: any, i: number) => i !== index)
  await client.put(`/users/${route.params.id}/profile`, {
    certifications: JSON.stringify(certs)
  })
  await loadProfile()
}

// ─── Change own password ──────────────────────────────────────────────────────
const pwForm = ref({ current: '', newPw: '', confirm: '' })
const pwSaving = ref(false)
const pwError = ref('')
const pwSuccess = ref('')

const pwFormValid = computed(() =>
  pwForm.value.current.length > 0 &&
  pwForm.value.newPw.length >= 8 &&
  pwForm.value.confirm === pwForm.value.newPw
)

async function submitPasswordChange() {
  pwError.value = ''
  pwSuccess.value = ''
  if (pwForm.value.newPw !== pwForm.value.confirm) {
    pwError.value = 'Las contraseñas no coinciden'
    return
  }
  pwSaving.value = true
  try {
    await client.patch(`/users/${route.params.id}/change-password`, {
      current_password: pwForm.value.current,
      new_password: pwForm.value.newPw,
    })
    pwSuccess.value = 'Contraseña actualizada correctamente'
    pwForm.value = { current: '', newPw: '', confirm: '' }
  } catch (err: unknown) {
    pwError.value = apiErrorMsg(err, 'Error cambiando contraseña')
  } finally { pwSaving.value = false }
}

// ─── Notification preferences ─────────────────────────────────────────────────
const notifPrefs = ref<any[]>([])
const loadingPrefs = ref(false)

const NOTIF_TYPE_LABELS: Record<string, string> = {
  wo_assigned: 'OT asignada',
  wo_status_change: 'Cambio de estado OT',
  wo_comment: 'Comentario en OT',
  stock_low: 'Stock bajo',
  maintenance_due: 'Mantenimiento pendiente',
  wo_completed: 'OT completada',
  pattern_detected: 'Patrón detectado',
}

async function loadNotifPrefs() {
  if (!isOwnProfile.value) return
  loadingPrefs.value = true
  try {
    const { data } = await client.get('/notifications/preferences')
    notifPrefs.value = data.preferences ?? []
  } catch { /* silent */ }
  finally { loadingPrefs.value = false }
}

async function savePrefs() {
  try {
    await client.put('/notifications/preferences', { preferences: notifPrefs.value })
  } catch { /* silent */ }
}

// ─── Daily Summaries (calendar + CRUD) ──────────────────────────────────────
const canViewActivity = computed(() => {
  const viewerRole = authStore.user?.role
  const profileRole = profile.value?.user?.role
  if (!viewerRole || !profileRole) return false
  return (viewerRole === 'admin' || viewerRole === 'supervisor') &&
         (profileRole === 'technician' || profileRole === 'operator')
})

const canEditSummaries = computed(() => {
  return isOwnProfile.value &&
    (authStore.user?.role === 'technician' || authStore.user?.role === 'operator' ||
     authStore.user?.role === 'supervisor' || authStore.user?.role === 'admin')
})

const showSummarySection = computed(() => {
  const role = profile.value?.user?.role
  return role === 'technician' || role === 'operator' || canViewActivity.value
})

const calYear = ref(new Date().getFullYear())
const calMonth = ref(new Date().getMonth())
const summaryDaysMap = ref<Record<string, { count: number; hours: number }>>({})
const selectedDate = ref('')
const dayDetailLoading = ref(false)
const daySummaries = ref<any[]>([])
const monthFrozen = ref(false)
const dlLoading = ref(false)
const dlError = ref('')

// Summary form
const showSummaryModal = ref(false)
const summarySaving = ref(false)
const summaryError = ref('')
const recentWOs = ref<any[]>([])
const clientsList = ref<any[]>([])
const summaryForm = ref({
  id: null as number | null,
  wo_id: null as number | null,
  client_id: null as number | null,
  project_number: '',
  shift: 'mañana',
  shift_extras: [] as string[],
  hours: 0,
  observations: '',
})

const daySummariesHours = computed(() =>
  daySummaries.value.reduce((sum: number, s: any) => sum + (s.hours ?? 0), 0)
)

const summaryFormValid = computed(() =>
  summaryForm.value.shift && summaryForm.value.hours > 0
)

const calMonthLabel = computed(() => {
  const months = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre']
  return `${months[calMonth.value]} ${calYear.value}`
})

const calDays = computed(() => {
  const y = calYear.value, m = calMonth.value
  const firstDay = new Date(y, m, 1)
  const lastDay = new Date(y, m + 1, 0)
  const daysInMonth = lastDay.getDate()
  let startWeekday = firstDay.getDay() - 1
  if (startWeekday < 0) startWeekday = 6

  const today = new Date().toISOString().slice(0, 10)
  const days: { num: number; date: string; other: boolean; today: boolean; count: number }[] = []

  const prevMonthDays = new Date(y, m, 0).getDate()
  for (let i = startWeekday - 1; i >= 0; i--) {
    days.push({ num: prevMonthDays - i, date: '', other: true, today: false, count: 0 })
  }

  for (let d = 1; d <= daysInMonth; d++) {
    const dateStr = `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`
    const info = summaryDaysMap.value[dateStr]
    days.push({ num: d, date: dateStr, other: false, today: dateStr === today, count: info?.count ?? 0 })
  }

  const remaining = 7 - (days.length % 7)
  if (remaining < 7) {
    for (let d = 1; d <= remaining; d++) {
      days.push({ num: d, date: '', other: true, today: false, count: 0 })
    }
  }
  return days
})

function calPrev() {
  if (calMonth.value === 0) { calMonth.value = 11; calYear.value-- }
  else calMonth.value--
  selectedDate.value = ''
  daySummaries.value = []
  loadSummaryDays()
}

function calNext() {
  if (calMonth.value === 11) { calMonth.value = 0; calYear.value++ }
  else calMonth.value++
  selectedDate.value = ''
  daySummaries.value = []
  loadSummaryDays()
}

async function selectDay(date: string) {
  selectedDate.value = date
  daySummaries.value = []
  dayDetailLoading.value = true
  try {
    const uid = route.params.id
    const month = date.slice(0, 7)
    const { data } = await client.get(`/daily-summaries?user_id=${uid}&month=${month}`)
    daySummaries.value = (data.summaries ?? []).filter((s: any) => s.summary_date === date)
  } catch { daySummaries.value = [] }
  finally { dayDetailLoading.value = false }
}

async function loadSummaryDays() {
  const month = `${calYear.value}-${String(calMonth.value + 1).padStart(2, '0')}`
  const uid = route.params.id
  try {
    const { data } = await client.get(`/daily-summaries/days?user_id=${uid}&month=${month}`)
    const map: Record<string, { count: number; hours: number }> = {}
    for (const d of data.days ?? []) map[d.date] = { count: d.count, hours: d.hours }
    summaryDaysMap.value = map
    monthFrozen.value = data.frozen ?? false
  } catch {
    summaryDaysMap.value = {}
    monthFrozen.value = false
  }
}

function openSummaryForm() {
  summaryForm.value = {
    id: null,
    wo_id: null,
    client_id: null,
    project_number: '',
    shift: 'mañana',
    shift_extras: [],
    hours: 0,
    observations: '',
  }
  summaryError.value = ''
  showSummaryModal.value = true
  loadFormData()
}

function editSummary(s: any) {
  summaryForm.value = {
    id: s.id,
    wo_id: s.wo_id,
    client_id: s.client_id,
    project_number: s.project_number ?? '',
    shift: s.shift,
    shift_extras: s.shift_extras ?? [],
    hours: s.hours,
    observations: s.observations ?? '',
  }
  summaryError.value = ''
  showSummaryModal.value = true
  loadFormData()
}

async function loadFormData() {
  try {
    const [wosRes, clientsRes] = await Promise.all([
      client.get('/daily-summaries/recent-wos', { params: { date: selectedDate.value } }),
      client.get('/clients').catch(() => ({ data: { clients: [] } })),
    ])
    recentWOs.value = wosRes.data.work_orders ?? []
    clientsList.value = clientsRes.data.clients ?? []
  } catch { /* silent */ }
}

function toggleExtra(ex: string) {
  const idx = summaryForm.value.shift_extras.indexOf(ex)
  if (idx >= 0) summaryForm.value.shift_extras.splice(idx, 1)
  else summaryForm.value.shift_extras.push(ex)
}

async function submitSummary() {
  summarySaving.value = true
  summaryError.value = ''
  try {
    const payload = {
      summary_date: selectedDate.value,
      wo_id: summaryForm.value.wo_id,
      client_id: summaryForm.value.client_id,
      project_number: summaryForm.value.client_id ? summaryForm.value.project_number : '',
      shift: summaryForm.value.shift,
      shift_extras: summaryForm.value.shift_extras,
      hours: summaryForm.value.hours,
      observations: summaryForm.value.observations,
    }

    if (summaryForm.value.id) {
      await client.put(`/daily-summaries/${summaryForm.value.id}`, payload)
    } else {
      await client.post('/daily-summaries', payload)
    }
    showSummaryModal.value = false
    await selectDay(selectedDate.value)
    await loadSummaryDays()
  } catch (err: unknown) {
    summaryError.value = apiErrorMsg(err, 'Error guardando resumen')
  } finally { summarySaving.value = false }
}

async function deleteSummary(id: number) {
  if (!confirm('Eliminar este resumen?')) return
  try {
    await client.delete(`/daily-summaries/${id}`)
    await selectDay(selectedDate.value)
    await loadSummaryDays()
  } catch { /* silent */ }
}

// ─── Excel downloads ────────────────────────────────────────────────────────
function downloadUserMonth() {
  const uid = route.params.id
  const month = `${calYear.value}-${String(calMonth.value + 1).padStart(2, '0')}`
  triggerDownload(`/daily-summaries/export?user_id=${uid}&month=${month}`, `resumen_${month}.xlsx`)
}

function downloadAllMonth() {
  const month = `${calYear.value}-${String(calMonth.value + 1).padStart(2, '0')}`
  triggerDownload(`/daily-summaries/export-all?month=${month}`, `resumenes_${month}.zip`)
}

function triggerDownload(url: string, filename: string) {
  dlLoading.value = true
  dlError.value = ''
  client.get(url, { responseType: 'blob' })
    .then(res => {
      const blob = new Blob([res.data])
      const objUrl = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = objUrl
      a.download = filename
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(objUrl)
    })
    .catch(() => { dlError.value = 'Error descargando. Verifique que existan datos.' })
    .finally(() => { dlLoading.value = false })
}

// ─── Utils ──────────────────────────────────────────────────────────────────
function formatCalDate(dateStr: string) {
  try { return new Date(dateStr + 'T00:00:00').toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' }) }
  catch { return dateStr }
}

function formatDate(iso: string) {
  if (!iso) return ''
  try { return new Date(iso).toLocaleDateString('es-ES', { day: '2-digit', month: 'long', year: 'numeric' }) }
  catch { return iso }
}

// ─── Init ───────────────────────────────────────────────────────────────────
watch(() => profile.value, () => {
  if (showSummarySection.value) loadSummaryDays()
})

onMounted(() => { loadProfile(); loadNotifPrefs() })
</script>

<style scoped>
.profile-loading, .profile-error { padding: var(--space-8); text-align: center; color: var(--color-text-muted); font-size: 0.9rem; }
.profile-layout { display: flex; flex-direction: column; gap: var(--space-5); }

/* Header */
.profile-header-card { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-lg); padding: var(--space-6); display: flex; align-items: flex-start; gap: var(--space-6); }
.profile-avatar { width: 80px; height: 80px; border-radius: 50%; color: #fff; font-size: 1.8rem; font-weight: 700; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.profile-header-info { flex: 1; min-width: 0; }
.profile-name-row { display: flex; align-items: center; gap: var(--space-3); flex-wrap: wrap; margin-bottom: var(--space-2); }
.profile-name { font-size: 1.5rem; font-weight: 700; color: var(--color-primary); }
.profile-status { font-size: 0.72rem; font-weight: 700; padding: 3px 10px; border-radius: 20px; }
.status--active   { background: rgba(39,174,96,0.1); color: #27AE60; }
.status--inactive { background: rgba(233,69,96,0.1); color: var(--color-alert); }
.profile-role-row { display: flex; align-items: center; gap: var(--space-2); flex-wrap: wrap; margin-bottom: var(--space-3); }
.profile-role { font-size: 0.875rem; font-weight: 600; color: var(--color-accent); }
.profile-dept, .profile-position { font-size: 0.82rem; color: var(--color-text-muted); }
.profile-contact { display: flex; flex-wrap: wrap; gap: var(--space-4); margin-bottom: var(--space-3); }
.contact-item { font-size: 0.82rem; color: var(--color-text-muted); }
.profile-bio { font-size: 0.875rem; color: var(--color-text); line-height: 1.6; font-style: italic; }

/* Rank */
.profile-rank-card { background: var(--color-surface-2); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); padding: var(--space-4); text-align: center; min-width: 160px; flex-shrink: 0; }
.rank-icon { font-size: 2.5rem; margin-bottom: 4px; }
.rank-name { font-size: 1rem; font-weight: 700; margin-bottom: var(--space-3); }
.rank-progress-wrap { display: flex; flex-direction: column; gap: 4px; }
.rank-progress-bar { height: 6px; background: var(--color-border-light); border-radius: 3px; overflow: hidden; }
.rank-progress-fill { height: 100%; border-radius: 3px; transition: width 0.5s ease; }
.rank-progress-label { font-size: 0.68rem; color: var(--color-text-muted); }
.rank-bonus { font-size: 0.72rem; color: #F39C12; margin-top: var(--space-2); font-weight: 600; }
.btn-edit-profile { height: 32px; padding: 0 var(--space-4); background: none; border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.78rem; color: var(--color-text-muted); cursor: pointer; margin-top: var(--space-3); align-self: flex-start; }
.btn-edit-profile:hover { border-color: var(--color-accent); color: var(--color-accent); }

/* KPIs */
.kpi-grid { display: grid; gap: var(--space-3); }
.kpi-grid--primary { grid-template-columns: repeat(3, 1fr); margin-bottom: var(--space-3); }
.kpi-grid--secondary { grid-template-columns: repeat(4, 1fr); }
.kpi-card { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); padding: var(--space-4); text-align: center; }
.kpi-card--small .kpi-value { font-size: 1.2rem; }
.kpi-card--small .kpi-label { font-size: 0.65rem; }
.kpi-card--accent { border-top: 3px solid var(--color-accent); }
.kpi-card--green  { border-top: 3px solid #27AE60; }
.kpi-card--blue   { border-top: 3px solid #3B82F6; }
.kpi-card--purple { border-top: 3px solid #8B5CF6; }
.kpi-card--warn   { border-top: 3px solid #F39C12; }
.kpi-value { display: block; font-size: 1.6rem; font-weight: 700; font-family: var(--font-mono); color: var(--color-primary); }
.kpi-label { display: block; font-size: 0.68rem; color: var(--color-text-muted); margin-top: 4px; }

/* Main grid */
.profile-main-grid { display: grid; grid-template-columns: 1fr 1.5fr; gap: var(--space-5); align-items: start; }
.profile-col { display: flex; flex-direction: column; gap: var(--space-4); }
.card { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); overflow: hidden; }
.card-header { display: flex; align-items: center; justify-content: space-between; padding: var(--space-3) var(--space-5); border-bottom: 1px solid var(--color-border-light); background: var(--color-surface-2); }
.card-title { font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--color-text-muted); }
.card-body { padding: var(--space-4) var(--space-5); }
.card-empty { padding: var(--space-5); text-align: center; font-size: 0.875rem; color: var(--color-text-muted); }

/* Tags */
.tags-wrap { display: flex; flex-wrap: wrap; gap: var(--space-2); }
.skill-tag { font-size: 0.78rem; background: rgba(15,52,96,0.08); color: var(--color-accent); border: 1px solid rgba(15,52,96,0.15); padding: 4px 10px; border-radius: 20px; font-weight: 500; }

/* Distribution type */
.type-row { display: flex; align-items: center; gap: var(--space-3); padding: var(--space-2) 0; }
.type-label { font-size: 0.78rem; width: 90px; flex-shrink: 0; }
.type-bar-wrap { flex: 1; height: 8px; background: var(--color-surface-2); border-radius: 4px; overflow: hidden; }
.type-bar { height: 100%; border-radius: 4px; transition: width 0.5s ease; min-width: 4px; }
.type-count { font-size: 0.75rem; color: var(--color-text-muted); width: 24px; text-align: right; flex-shrink: 0; }

/* Certifications */
.cert-list { display: flex; flex-direction: column; gap: var(--space-2); }
.cert-item { display: flex; align-items: center; gap: var(--space-3); padding: var(--space-2) var(--space-3); background: var(--color-surface-2); border-radius: var(--radius); }
.cert-icon { font-size: 1rem; flex-shrink: 0; }
.cert-info { flex: 1; }
.cert-name { display: block; font-size: 0.82rem; font-weight: 500; }
.cert-date { display: block; }
.btn-add-cert { font-size: 0.72rem; color: var(--color-accent); background: none; border: none; cursor: pointer; }

/* Activity chart */
.activity-chart { display: flex; align-items: flex-end; gap: var(--space-3); height: 100px; padding: var(--space-2) 0; }
.activity-bar-wrap { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: flex-end; gap: 4px; height: 100%; }
.activity-bar { width: 100%; background: var(--color-accent); border-radius: 4px 4px 0 0; min-height: 4px; opacity: 0.8; transition: height 0.5s ease; cursor: default; }
.activity-bar:hover { opacity: 1; }
.activity-month { font-size: 0.62rem; color: var(--color-text-muted); }

/* Latest WOs */
.recent-wo-list { display: flex; flex-direction: column; }
.recent-wo-item { display: flex; align-items: flex-start; justify-content: space-between; gap: var(--space-4); padding: var(--space-3) var(--space-5); border-bottom: 1px solid var(--color-border-light); }
.recent-wo-item:last-child { border-bottom: none; }
.wo-item-left { flex: 1; min-width: 0; }
.wo-number { display: block; font-size: 0.72rem; color: var(--color-text-muted); margin-bottom: 2px; }
.wo-title { display: block; font-size: 0.82rem; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.wo-node { display: block; margin-top: 2px; }
.wo-item-right { display: flex; flex-direction: column; align-items: flex-end; gap: 4px; flex-shrink: 0; }
.wo-priority { font-size: 0.62rem; font-weight: 700; color: #fff; padding: 2px 6px; border-radius: 10px; }
.wo-status { font-size: 0.68rem; color: var(--color-text-muted); }
.wo-status--completed, .wo-status--verified, .wo-status--closed { color: #27AE60; }
.wo-status--in_progress { color: #3B82F6; }

/* Modals */
.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; padding: var(--space-4); }
.edit-modal, .cert-modal { background: var(--color-surface); border-radius: var(--radius-lg); width: 100%; max-width: 540px; max-height: 90vh; display: flex; flex-direction: column; box-shadow: var(--shadow-lg); }
.cert-modal { max-width: 380px; }
.modal-header { display: flex; justify-content: space-between; align-items: center; padding: var(--space-4) var(--space-5); border-bottom: 1px solid var(--color-border-light); }
.modal-header h3 { font-size: 1rem; font-weight: 600; color: var(--color-primary); }
.modal-close { background: none; border: none; font-size: 1rem; cursor: pointer; color: var(--color-text-muted); }
.modal-body { flex: 1; overflow-y: auto; padding: var(--space-5); display: flex; flex-direction: column; gap: var(--space-4); }
.modal-footer { display: flex; justify-content: flex-end; gap: var(--space-3); padding: var(--space-4) var(--space-5); border-top: 1px solid var(--color-border-light); }
.modal-error { background: rgba(233,69,96,0.08); border: 1px solid rgba(233,69,96,0.3); border-radius: var(--radius); padding: var(--space-3); font-size: 0.875rem; color: var(--color-alert); }

/* Color picker */
.color-picker { display: flex; gap: var(--space-2); flex-wrap: wrap; }
.color-swatch { width: 28px; height: 28px; border-radius: 50%; cursor: pointer; border: 2px solid transparent; transition: all 0.15s; }
.color-swatch--active { border-color: var(--color-text); transform: scale(1.2); }

/* Fields */
.field { display: flex; flex-direction: column; gap: var(--space-1); }
.field-row { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-3); }
.field-label { font-size: 0.68rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); }
.field-input { height: 38px; padding: 0 var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; background: var(--color-surface); outline: none; width: 100%; }
.field-input:focus { border-color: var(--color-accent); }
.field-input:disabled { background: var(--color-surface-2); color: var(--color-text-muted); }
textarea.field-input { height: auto; padding: var(--space-2) var(--space-3); resize: vertical; font-family: var(--font-ui); }
select.field-input { cursor: pointer; }
.btn-primary { height: 36px; padding: 0 var(--space-5); background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); font-size: 0.875rem; font-weight: 500; cursor: pointer; }
.btn-primary:hover:not(:disabled) { background: var(--color-accent); }
.btn-primary:disabled { opacity: 0.65; cursor: not-allowed; }
.btn-secondary { height: 36px; padding: 0 var(--space-4); background: var(--color-surface-2); color: var(--color-text); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; cursor: pointer; }
.action-btn { width: 24px; height: 24px; background: none; border: none; cursor: pointer; font-size: 0.75rem; color: var(--color-text-muted); }
.action-btn--del:hover { color: var(--color-alert); }
/* Password form */
.pw-form { display: flex; flex-direction: column; gap: var(--space-3); }
.pw-error { font-size: 0.78rem; color: var(--color-alert); padding: var(--space-2) var(--space-3); background: rgba(233,69,96,0.08); border-radius: var(--radius); }
.pw-success { font-size: 0.78rem; color: #27AE60; padding: var(--space-2) var(--space-3); background: rgba(39,174,96,0.08); border-radius: var(--radius); }
.btn-pw { align-self: flex-start; }

.notif-prefs-list { display: flex; flex-direction: column; gap: var(--space-2); }
.notif-pref-row { display: flex; align-items: center; gap: var(--space-3); padding: var(--space-2) 0; border-bottom: 1px solid var(--color-border-light); }
.notif-pref-row:last-child { border-bottom: none; }
.notif-pref-label { flex: 1; font-size: 0.82rem; }
.notif-toggle { font-size: 0.75rem; color: var(--color-text-muted); display: flex; align-items: center; gap: 4px; cursor: pointer; }
.notif-toggle input { cursor: pointer; }
.text-muted { color: var(--color-text-muted); }
.small { font-size: 0.75rem; }
.mono { font-family: var(--font-mono); }

/* Calendar */
.cal-controls { display: flex; align-items: center; justify-content: space-between; margin-bottom: var(--space-3); }
.cal-nav { background: none; border: 1px solid var(--color-border); border-radius: var(--radius); width: 28px; height: 28px; cursor: pointer; font-size: 0.875rem; color: var(--color-text-muted); display: flex; align-items: center; justify-content: center; }
.cal-nav:hover { border-color: var(--color-accent); color: var(--color-accent); }
.cal-month-label { font-size: 0.875rem; font-weight: 600; color: var(--color-primary); }
.cal-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 2px; }
.cal-weekday { font-size: 0.62rem; font-weight: 700; text-align: center; color: var(--color-text-muted); padding: var(--space-1) 0; }
.cal-day { position: relative; aspect-ratio: 1; display: flex; align-items: center; justify-content: center; background: none; border: 1px solid transparent; border-radius: var(--radius); font-size: 0.75rem; cursor: pointer; color: var(--color-text); }
.cal-day:hover:not(:disabled) { background: var(--color-surface-2); }
.cal-day--other { color: var(--color-border); cursor: default; }
.cal-day--today { font-weight: 700; border-color: var(--color-accent); }
.cal-day--selected { background: var(--color-accent) !important; color: #fff; font-weight: 600; }
.cal-day--has-activity .cal-dot { position: absolute; bottom: 2px; left: 50%; transform: translateX(-50%); width: 4px; height: 4px; background: #27AE60; border-radius: 50%; }
.cal-day--selected .cal-dot { background: #fff; }
.frozen-badge { font-size: 0.62rem; font-weight: 700; background: rgba(233,69,96,0.1); color: var(--color-alert); padding: 2px 8px; border-radius: 10px; }

/* Day detail */
.day-detail { margin-top: var(--space-3); border-top: 1px solid var(--color-border-light); padding-top: var(--space-3); }
.day-detail-header { display: flex; align-items: center; gap: var(--space-2); margin-bottom: var(--space-3); }
.day-detail-title { font-size: 0.82rem; font-weight: 600; color: var(--color-primary); text-transform: capitalize; flex: 1; }
.day-detail-badge { font-size: 0.68rem; font-weight: 700; background: rgba(15,52,96,0.1); color: var(--color-accent); padding: 2px 8px; border-radius: 10px; }
.day-detail-empty-badge { font-size: 0.68rem; color: var(--color-text-muted); }
.day-detail-loading { font-size: 0.78rem; color: var(--color-text-muted); padding: var(--space-2) 0; }
.day-detail-none { font-size: 0.78rem; color: var(--color-text-muted); padding: var(--space-2) 0; font-style: italic; }
.day-detail-error { font-size: 0.72rem; color: var(--color-alert); margin-top: var(--space-2); }
.day-detail-list { display: flex; flex-direction: column; gap: var(--space-2); max-height: 320px; overflow-y: auto; }
.day-entry { background: var(--color-surface-2); border: 1px solid var(--color-border-light); border-radius: var(--radius); padding: var(--space-3); position: relative; }
.day-entry-header { display: flex; align-items: center; gap: var(--space-2); margin-bottom: 4px; flex-wrap: wrap; }
.day-entry-wo { font-size: 0.68rem; color: var(--color-text-muted); }
.day-entry-type { font-size: 0.6rem; font-weight: 700; color: #fff; padding: 1px 6px; border-radius: 8px; }
.day-entry-extra { font-size: 0.58rem; background: var(--color-surface); border: 1px solid var(--color-border); padding: 1px 5px; border-radius: 6px; color: var(--color-text-muted); }
.day-entry-hours-badge { font-size: 0.68rem; font-weight: 700; color: var(--color-accent); background: rgba(15,52,96,0.08); padding: 1px 6px; border-radius: 8px; margin-left: auto; }
.day-entry-title { font-size: 0.78rem; font-weight: 500; color: var(--color-text); margin-bottom: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.day-entry-client { font-size: 0.68rem; color: var(--color-text-muted); margin-bottom: 2px; }
.day-entry-obs { font-size: 0.72rem; color: var(--color-text-muted); font-style: italic; margin-top: 4px; padding-top: 4px; border-top: 1px dashed var(--color-border-light); }
.day-entry-actions { position: absolute; top: var(--space-2); right: var(--space-2); display: flex; gap: 2px; }
.btn-add-summary { width: 100%; margin-top: var(--space-3); height: 36px; background: none; border: 1px dashed var(--color-border); border-radius: var(--radius); color: var(--color-accent); font-size: 0.82rem; font-weight: 500; cursor: pointer; }
.btn-add-summary:hover { border-color: var(--color-accent); background: rgba(15,52,96,0.04); }

/* Shift options */
.shift-options { display: flex; gap: var(--space-2); }
.shift-radio { display: flex; align-items: center; gap: 4px; padding: 6px 14px; border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.82rem; cursor: pointer; transition: all 0.15s; }
.shift-radio--active { background: var(--color-accent); color: #fff; border-color: var(--color-accent); }
.shift-radio input { display: none; }
.shift-extras { display: flex; flex-wrap: wrap; gap: var(--space-2); }
.shift-check { display: flex; align-items: center; gap: 4px; padding: 4px 10px; border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.78rem; cursor: pointer; transition: all 0.15s; }
.shift-check--active { background: rgba(15,52,96,0.1); border-color: var(--color-accent); color: var(--color-accent); }
.shift-check input { display: none; }

/* Download buttons */
.cal-actions { display: flex; gap: var(--space-2); margin-top: var(--space-3); }
.btn-cal-dl { flex: 1; height: 32px; font-size: 0.72rem; font-weight: 600; border: 1px solid var(--color-border); background: var(--color-surface); color: var(--color-text); border-radius: var(--radius); cursor: pointer; }
.btn-cal-dl:hover:not(:disabled) { border-color: var(--color-accent); color: var(--color-accent); }
.btn-cal-dl:disabled { opacity: 0.45; cursor: not-allowed; }
.btn-cal-dl--primary { background: var(--color-primary); color: #fff; border-color: var(--color-primary); }
.btn-cal-dl--primary:hover:not(:disabled) { background: var(--color-accent); border-color: var(--color-accent); }

@media (max-width: 900px) {
  .kpi-grid--primary { grid-template-columns: repeat(3, 1fr); }
  .kpi-grid--secondary { grid-template-columns: repeat(2, 1fr); }
  .profile-main-grid { grid-template-columns: 1fr; }
  .profile-header-card { flex-wrap: wrap; }
  .profile-rank-card { width: 100%; }
}
@media (max-width: 768px) {
  .kpi-grid--primary { grid-template-columns: repeat(3, 1fr); }
  .kpi-grid--secondary { grid-template-columns: repeat(2, 1fr); }
  .field-row { grid-template-columns: 1fr; }
  .shift-options { flex-wrap: wrap; }

  .profile-header-card { padding: var(--space-4); gap: var(--space-3); }
  .profile-avatar { width: 52px; height: 52px; font-size: 1.1rem; }
  .profile-name { font-size: 1.1rem; }

  .profile-tabs { padding: 0 var(--space-3); overflow-x: auto; -webkit-overflow-scrolling: touch; }
  .profile-tab { height: 44px; font-size: 0.82rem; padding: 0 var(--space-3); white-space: nowrap; flex-shrink: 0; }

  .tab-content { padding: var(--space-4); }
  .section-card { padding: var(--space-4); }

  /* Modals */
  .modal-overlay { padding: 0; }
  .edit-modal { max-width: 100%; border-radius: 0; max-height: 100vh; max-height: 100dvh; overflow-y: auto; }
  .modal-body { padding: var(--space-4); }
  .field-input { height: 42px; }
  textarea.field-input { font-size: 1rem; }
  .btn-primary, .btn-secondary { height: 44px; font-size: 0.9rem; }

  /* Daily summaries calendar */
  .ds-calendar { overflow-x: auto; -webkit-overflow-scrolling: touch; }
  .summary-form { padding: var(--space-3); }
}

@media (max-width: 480px) {
  .kpi-grid--primary { grid-template-columns: repeat(2, 1fr); }
  .kpi-grid--secondary { grid-template-columns: 1fr; }
  .profile-header-card { flex-direction: column; text-align: center; }
  .profile-header-actions { width: 100%; justify-content: center; }
}
</style>
