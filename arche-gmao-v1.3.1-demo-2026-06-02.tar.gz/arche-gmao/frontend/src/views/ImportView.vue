<template>
  <div class="import-layout">
    <div class="page-header">
      <div>
        <h1 class="page-title">Importación y Mantenimiento</h1>
        <p class="page-sub">Importa equipos masivamente y mantén la base de datos limpia</p>
      </div>
    </div>

    <div class="import-tabs">
      <button v-for="t in TABS" :key="t.id" class="import-tab"
        :class="{ 'import-tab--active': activeTab === t.id }"
        @click="activeTab = t.id">
        {{ t.label }}
      </button>
    </div>

    <!-- ─── Import equipment ─────────────────────────────────────────────── -->
    <div v-if="activeTab === 'import'" class="tab-content">
      <div class="card">
        <div class="card-header"><span class="card-title">Importar equipos desde Excel</span></div>
        <div class="card-body">
          <div class="import-steps">
            <div class="step-item">
              <div class="step-num">1</div>
              <div class="step-info">
                <span class="step-title">Descarga la plantilla</span>
                <span class="step-desc">Contiene todas las columnas necesarias con ejemplos y validaciones</span>
              </div>
              <button class="btn-secondary" @click="downloadTemplate">↓ Descargar plantilla</button>
            </div>
            <div class="step-item">
              <div class="step-num">2</div>
              <div class="step-info">
                <span class="step-title">Rellena los datos</span>
                <span class="step-desc">Una fila por equipo. Los padres deben aparecer antes que sus hijos. Consulta la hoja "Referencia" para los valores válidos.</span>
              </div>
            </div>
            <div class="step-item">
              <div class="step-num">3</div>
              <div class="step-info">
                <span class="step-title">Sube el archivo</span>
                <span class="step-desc">El sistema validará cada fila y te mostrará un informe detallado</span>
              </div>
              <div class="upload-zone" @dragover.prevent @drop.prevent="onDrop"
                :class="{ 'upload-zone--active': importFile }">
                <template v-if="!importFile">
                  <span class="upload-icon">▦</span>
                  <p>Arrastra el Excel aquí</p>
                  <label class="btn-secondary" style="cursor:pointer;margin-top:8px">
                    Seleccionar archivo
                    <input type="file" accept=".xlsx,.xls" style="display:none" @change="onFileSelect" />
                  </label>
                </template>
                <template v-else>
                  <span style="font-size:1.5rem">▦</span>
                  <span class="file-name">{{ importFile.name }}</span>
                  <span class="text-muted small">{{ (importFile.size/1024).toFixed(0) }} KB</span>
                  <button class="btn-sm" @click="importFile = null">Cambiar</button>
                </template>
              </div>
            </div>
          </div>

          <div v-if="importError" class="import-error">{{ importError }}</div>

          <button class="btn-primary" style="margin-top:16px"
            :disabled="!canWrite || !importFile || importing"
            @click="runImport">
            {{ importing ? 'Importando...' : 'Iniciar importación' }}
          </button>
        </div>
      </div>

      <!-- Results -->
      <div v-if="importResult" class="card">
        <div class="card-header">
          <span class="card-title">Resultado de la importación</span>
          <div class="result-summary">
            <span class="badge-ok">✓ {{ importResult.created }} creados</span>
            <span v-if="importResult.failed > 0" class="badge-err">✕ {{ importResult.failed }} errores</span>
          </div>
        </div>
        <div class="result-list">
          <div v-for="r in importResult.results" :key="r.line"
            class="result-row" :class="`result-row--${r.status}`">
            <span class="result-line">L{{ r.line }}</span>
            <span class="result-status-icon">
              {{ r.status === 'creado' ? '✓' : r.status === 'duplicado' ? '⚠' : '✕' }}
            </span>
            <span class="result-name">{{ r.name }}</span>
            <span v-if="r.code" class="result-code mono">{{ r.code }}</span>
            <span v-if="r.error" class="result-error">{{ r.error }}</span>
            <span v-if="r.node_id" class="result-id text-muted small">ID: {{ r.node_id }}</span>
          </div>
        </div>
      </div>
    </div>

    <!-- ─── Optimistic locking / conflicts ───────────────────────────────── -->
    <div v-if="activeTab === 'conflicts'" class="tab-content">
      <div class="card">
        <div class="card-header"><span class="card-title">Sobre el bloqueo optimista</span></div>
        <div class="card-body">
          <div class="info-block">
            <p>Arche GMAO protege contra conflictos de edición simultánea. Cuando dos usuarios editan la misma OT al mismo tiempo, el sistema detecta el conflicto y avisa al segundo usuario antes de que sobreescriba los cambios del primero.</p>
            <p style="margin-top:12px">Cada OT y nodo tiene un número de versión interno. Al guardar, el sistema comprueba que la versión no ha cambiado desde que se abrió el formulario. Si ha cambiado, muestra un aviso con el nombre del usuario que realizó el cambio.</p>
          </div>
          <div class="conflict-stats">
            <div class="stat-card">
              <span class="stat-value">{{ conflictStats.total }}</span>
              <span class="stat-label">Conflictos detectados</span>
            </div>
            <div class="stat-card">
              <span class="stat-value">{{ conflictStats.wos }}</span>
              <span class="stat-label">En Órdenes de Trabajo</span>
            </div>
            <div class="stat-card">
              <span class="stat-value">{{ conflictStats.nodes }}</span>
              <span class="stat-label">En Fábrica Virtual</span>
            </div>
          </div>
          <div v-if="recentConflicts.length" class="conflict-list">
            <p class="card-title" style="margin-bottom:8px">Conflictos recientes</p>
            <div v-for="c in recentConflicts" :key="c.id" class="conflict-row">
              <span class="conflict-type">{{ c.entity_type }}</span>
              <span class="conflict-entity">ID {{ c.entity_id }}</span>
              <span class="text-muted small">{{ formatDate(c.conflict_at) }}</span>
            </div>
          </div>
          <div v-else class="card-empty" style="padding:16px 0">
            Sin conflictos registrados. El sistema funciona correctamente.
          </div>
        </div>
      </div>
    </div>

    <!-- ─── Cleanup ─────────────────────────────────────────────────────── -->
    <div v-if="activeTab === 'cleanup'" class="tab-content">
      <div class="card">
        <div class="card-header"><span class="card-title">Limpieza de datos</span></div>
        <div class="card-body">
          <div class="info-block">
            <p>Esta operación elimina datos huérfanos y obsoletos para mantener la base de datos optimizada. Se eliminará:</p>
            <ul class="cleanup-list">
              <li>Embeddings de conocimiento que ya fue eliminado del índice de la IA</li>
              <li>Entradas del log de auditoría con más de 1 año de antigüedad</li>
              <li>Notificaciones leídas con más de 90 días de antigüedad</li>
            </ul>
            <p style="margin-top:12px" class="text-muted small">Esta operación es segura y no elimina ningún dato operativo. Los OTs, equipos, repuestos y conocimiento activo no se ven afectados.</p>
          </div>

          <button class="btn-primary btn--warn" style="margin-top:8px"
            :disabled="!canWrite || cleaning" @click="runCleanup">
            {{ cleaning ? 'Limpiando...' : 'Ejecutar limpieza' }}
          </button>

          <div v-if="cleanupResults.length" class="cleanup-results">
            <p class="card-title" style="margin-bottom:8px">Resultado</p>
            <div v-for="r in cleanupResults" :key="r.action" class="cleanup-row">
              <span class="cleanup-action">{{ r.action.replace(/_/g, ' ') }}</span>
              <span class="cleanup-count">{{ r.count }}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Pagination info -->
      <div class="card">
        <div class="card-header"><span class="card-title">Paginación</span></div>
        <div class="card-body">
          <div class="info-block">
            <p>Las tablas de Órdenes de Trabajo, Inventario y Biblioteca cargan un máximo de 200 registros por consulta. Cuando una tabla supera ese número, aparece un botón "Cargar más" al final. La búsqueda y los filtros funcionan sobre todos los registros, no solo los cargados.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useToast, apiErrorMsg } from '@/composables/useToast'
const toast = useToast()
import { ref, onMounted } from 'vue'
import client, { downloadBlob } from '@/api/client'
import { useSystemPause } from '@/composables/useSystemPause'

const { canWrite } = useSystemPause()
const activeTab = ref('import')
const TABS = [
  { id: 'import',    label: '↑ Importar equipos' },
  { id: 'conflicts', label: '◆ Bloqueo optimista' },
  { id: 'cleanup',   label: '◈ Limpieza' },
]

// ─── Import ──────────────────────────────────────────────────────────────
const importFile   = ref<File | null>(null)
const importing    = ref(false)
const importError  = ref('')
const importResult = ref<any>(null)

async function downloadTemplate() {
  try {
    await downloadBlob('/import/template', 'plantilla_importacion_equipos.xlsx')
  } catch (err) {
    toast.error('No se pudo descargar la plantilla. Recarga la página e inténtalo de nuevo.')
    console.error('[Import]', err)
  }
}

function onFileSelect(e: Event) {
  const input = e.target as HTMLInputElement
  if (input.files?.[0]) importFile.value = input.files[0]
}

function onDrop(e: DragEvent) {
  const file = e.dataTransfer?.files?.[0]
  if (file && (file.name.endsWith('.xlsx') || file.name.endsWith('.xls'))) {
    importFile.value = file
  }
}

async function runImport() {
  if (!importFile.value) return
  importing.value = true; importError.value = ''; importResult.value = null
  try {
    const form = new FormData()
    form.append('file', importFile.value)
    const { data } = await client.post('/import/nodes', form, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })
    importResult.value = data
    if (data.created > 0) importFile.value = null
  } catch (err: unknown) {
    importError.value = apiErrorMsg(err, 'Error procesando el archivo')
  } finally { importing.value = false }
}

// ─── Conflicts ───────────────────────────────────────────────────────────────
const conflictStats   = ref({ total: 0, wos: 0, nodes: 0 })
const recentConflicts = ref<any[]>([])

async function loadConflicts() {
  try {
    const { data } = await client.get('/import/conflicts')
    conflictStats.value = data.stats ?? { total: 0, wos: 0, nodes: 0 }
    recentConflicts.value = data.recent ?? []
  } catch { /* silent */ }
}

// ─── Cleanup ─────────────────────────────────────────────────────────────────
const cleaning       = ref(false)
const cleanupResults = ref<any[]>([])

async function runCleanup() {
  if (!confirm('¿Ejecutar limpieza de datos obsoletos?')) return
  cleaning.value = true; cleanupResults.value = []
  try {
    const { data } = await client.post('/import/cleanup')
    cleanupResults.value = data.results ?? []
  } catch (err: unknown) {
    toast.fromError(err, 'Error en la limpieza')
  } finally { cleaning.value = false }
}

function formatDate(iso: string) {
  try { return new Date(iso).toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) }
  catch { return iso }
}

onMounted(loadConflicts)
</script>

<style scoped>
.import-layout { display: flex; flex-direction: column; gap: var(--space-5); }
.page-title { font-size: 1.4rem; font-weight: 700; color: var(--color-primary); }
.page-sub { font-size: 0.8rem; color: var(--color-text-muted); }
.import-tabs { display: flex; border-bottom: 2px solid var(--color-border-light); }
.import-tab { height: 42px; padding: 0 var(--space-5); background: none; border: none; font-size: 0.875rem; color: var(--color-text-muted); cursor: pointer; border-bottom: 2px solid transparent; margin-bottom: -2px; transition: all var(--transition); }
.import-tab:hover { color: var(--color-text); }
.import-tab--active { color: var(--color-primary); border-bottom-color: var(--color-primary); font-weight: 600; }
.tab-content { display: flex; flex-direction: column; gap: var(--space-4); }
.card { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); overflow: hidden; }
.card-header { display: flex; align-items: center; justify-content: space-between; padding: var(--space-3) var(--space-5); border-bottom: 1px solid var(--color-border-light); background: var(--color-surface-2); }
.card-title { font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--color-text-muted); }
.card-body { padding: var(--space-5); display: flex; flex-direction: column; gap: var(--space-4); }
.card-empty { padding: var(--space-6); text-align: center; font-size: 0.875rem; color: var(--color-text-muted); }

/* Steps */
.import-steps { display: flex; flex-direction: column; gap: var(--space-5); }
.step-item { display: flex; align-items: flex-start; gap: var(--space-4); padding: var(--space-4); background: var(--color-surface-2); border-radius: var(--radius-md); border: 1px solid var(--color-border-light); }
.step-num { width: 32px; height: 32px; background: var(--color-primary); color: #fff; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.9rem; font-weight: 700; flex-shrink: 0; }
.step-info { flex: 1; }
.step-title { display: block; font-size: 0.875rem; font-weight: 600; color: var(--color-text); margin-bottom: 4px; }
.step-desc { display: block; font-size: 0.78rem; color: var(--color-text-muted); line-height: 1.5; }

/* Upload */
.upload-zone { border: 2px dashed var(--color-border); border-radius: var(--radius-md); padding: var(--space-5); text-align: center; cursor: pointer; display: flex; flex-direction: column; align-items: center; gap: var(--space-2); min-width: 200px; transition: border-color var(--transition); }
.upload-zone--active { border-color: var(--color-accent); }
.upload-icon { font-size: 2rem; }
.file-name { font-size: 0.82rem; font-weight: 500; }
.import-error { background: rgba(233,69,96,0.08); border: 1px solid rgba(233,69,96,0.3); border-radius: var(--radius); padding: var(--space-3); font-size: 0.875rem; color: var(--color-alert); }

/* Results */
.result-summary { display: flex; gap: var(--space-2); }
.badge-ok  { font-size: 0.75rem; background: rgba(39,174,96,0.1); color: #27AE60; padding: 3px 8px; border-radius: 10px; font-weight: 600; }
.badge-err { font-size: 0.75rem; background: rgba(233,69,96,0.1); color: var(--color-alert); padding: 3px 8px; border-radius: 10px; font-weight: 600; }
.result-list { display: flex; flex-direction: column; max-height: 400px; overflow-y: auto; }
.result-row { display: flex; align-items: center; gap: var(--space-3); padding: var(--space-2) var(--space-5); border-bottom: 1px solid var(--color-border-light); font-size: 0.82rem; }
.result-row:last-child { border-bottom: none; }
.result-row--creado   { background: rgba(39,174,96,0.02); }
.result-row--error    { background: rgba(233,69,96,0.03); }
.result-row--duplicado { background: rgba(243,156,18,0.03); }
.result-line { font-size: 0.68rem; color: var(--color-text-muted); width: 30px; flex-shrink: 0; }
.result-status-icon { width: 18px; flex-shrink: 0; font-size: 0.8rem; }
.result-row--creado .result-status-icon { color: #27AE60; }
.result-row--error .result-status-icon { color: var(--color-alert); }
.result-row--duplicado .result-status-icon { color: #F39C12; }
.result-name { flex: 1; font-weight: 500; }
.result-code { font-family: var(--font-mono); font-size: 0.75rem; color: var(--color-text-muted); }
.result-error { font-size: 0.75rem; color: var(--color-alert); }
.result-id { font-size: 0.68rem; }

/* Conflicts */
.info-block { background: var(--color-surface-2); border-radius: var(--radius); padding: var(--space-4); font-size: 0.875rem; line-height: 1.7; color: var(--color-text-muted); }
.conflict-stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: var(--space-4); }
.stat-card { background: var(--color-surface-2); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); padding: var(--space-4); text-align: center; }
.stat-value { display: block; font-size: 2rem; font-weight: 700; font-family: var(--font-mono); color: var(--color-primary); }
.stat-label { display: block; font-size: 0.72rem; color: var(--color-text-muted); margin-top: 4px; }
.conflict-list { display: flex; flex-direction: column; }
.conflict-row { display: flex; align-items: center; gap: var(--space-4); padding: var(--space-2) 0; border-bottom: 1px solid var(--color-border-light); font-size: 0.82rem; }
.conflict-type { font-size: 0.68rem; font-weight: 700; background: rgba(15,52,96,0.08); color: var(--color-accent); padding: 2px 6px; border-radius: 10px; }
.conflict-entity { flex: 1; }

/* Cleanup */
.cleanup-list { list-style: disc; padding-left: 20px; margin-top: 8px; display: flex; flex-direction: column; gap: 4px; }
.cleanup-list li { font-size: 0.82rem; color: var(--color-text-muted); }
.cleanup-results { display: flex; flex-direction: column; gap: var(--space-2); margin-top: var(--space-2); }
.cleanup-row { display: flex; align-items: center; justify-content: space-between; padding: var(--space-2) var(--space-4); background: var(--color-surface-2); border-radius: var(--radius); font-size: 0.82rem; }
.cleanup-action { color: var(--color-text); text-transform: capitalize; }
.cleanup-count { font-family: var(--font-mono); font-weight: 600; color: var(--color-primary); }

/* Buttons */
.btn-primary { height: 38px; padding: 0 var(--space-5); background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); font-size: 0.875rem; font-weight: 500; cursor: pointer; }
.btn-primary:hover:not(:disabled) { background: var(--color-accent); }
.btn-primary:disabled { opacity: 0.65; cursor: not-allowed; }
.btn--warn { background: #E67E22; }
.btn--warn:hover:not(:disabled) { background: #CA6F1E; }
.btn-secondary { height: 34px; padding: 0 var(--space-4); background: var(--color-surface-2); color: var(--color-text); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.82rem; cursor: pointer; white-space: nowrap; }
.btn-sm { height: 26px; padding: 0 var(--space-3); background: var(--color-surface-2); border: 1px solid var(--color-border); border-radius: var(--radius-sm); font-size: 0.75rem; cursor: pointer; }
.text-muted { color: var(--color-text-muted); }
.small { font-size: 0.75rem; }
.mono { font-family: var(--font-mono); }

@media (max-width: 768px) {
  .page-header { flex-direction: column; gap: var(--space-3); }
  .page-title { font-size: 1.15rem; }
  .import-steps { flex-direction: column; }
  .step-card { min-width: 0; }
  .field-input { height: 42px; }
  .btn-primary, .btn-secondary, .btn--warn { height: 44px; font-size: 0.9rem; }
}
</style>
