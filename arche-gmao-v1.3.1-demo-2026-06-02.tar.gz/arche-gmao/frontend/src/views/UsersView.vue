<template>
  <div class="users-layout">
    <!-- System panel: only visible to the primary admin or the superadmin -->
    <div v-if="authStore.isPrimaryAdmin || authStore.isSuperadmin" class="system-panel">
      <div class="system-panel-header">
        <h2 class="system-title">Control del sistema</h2>
      </div>
      <div class="system-controls">
        <!-- Stop mode: primary admin and superadmin -->
        <div class="control-card">
          <div class="control-info">
            <span class="control-label">Modo parada</span>
            <span class="control-desc">
              {{ authStore.systemPaused ? 'El sistema está en solo lectura' : 'El sistema opera con normalidad' }}
            </span>
          </div>
          <div v-if="!authStore.systemPaused" class="pause-form">
            <input v-model="pauseContact" class="field-input field-input--sm"
              placeholder="Contacto de emergencia (opcional)" />
            <button class="btn-danger" @click="activatePause" :disabled="pauseLoading">
              {{ pauseLoading ? 'Activando...' : 'Activar pausa' }}
            </button>
          </div>
          <button v-else class="btn-success" @click="deactivatePause" :disabled="pauseLoading">
            {{ pauseLoading ? 'Desactivando...' : 'Desactivar pausa' }}
          </button>
        </div>

        <!-- User limit: superadmin only -->
        <div v-if="authStore.isSuperadmin" class="control-card">
          <div class="control-info">
            <span class="control-label">Límite de usuarios</span>
            <span class="control-desc">
              {{ systemStatus?.max_users ? `Máximo: ${systemStatus.max_users}` : 'Sin límite configurado' }}
            </span>
          </div>
          <div class="limit-form">
            <input v-model.number="newMaxUsers" type="number" min="1" class="field-input field-input--sm"
              placeholder="Sin límite" style="width: 120px;" />
            <button class="btn-primary btn-sm" @click="updateMaxUsers" :disabled="limitLoading">
              {{ limitLoading ? 'Guardando...' : 'Actualizar' }}
            </button>
          </div>
        </div>

      </div>
    </div>

    <!-- ─── Monthly summary folders ─────────────────────────────── -->
    <div class="monthly-folders-panel">
      <div class="system-panel-header">
        <h2 class="system-title">Resumenes mensuales de tecnicos</h2>
        <span class="system-subtitle">Carpetas con hojas de horas de todos los tecnicos, organizadas por mes</span>
      </div>
      <div v-if="loadingFolders" class="table-empty">Cargando meses...</div>
      <div v-else-if="!monthlyFolders.length" class="table-empty">
        Aun no hay resumenes. Los tecnicos deben crear sus resumenes diarios desde su perfil.
      </div>
      <div v-else class="folders-grid">
        <div v-for="m in monthlyFolders" :key="m.month" class="folder-card"
          :class="{ 'folder-card--frozen': m.frozen }">
          <div class="folder-icon">{{ m.frozen ? '◆' : '◇' }}</div>
          <div class="folder-info">
            <span class="folder-month">{{ formatMonthLabel(m.month) }}</span>
            <span class="folder-status" :class="m.frozen ? 'folder-status--frozen' : 'folder-status--open'">
              {{ m.frozen ? 'Cerrado' : 'Abierto' }}
            </span>
          </div>
          <button class="btn-folder-dl" @click="downloadMonthZIP(m.month)" :disabled="dlFolderLoading">
            {{ dlFolderLoading === m.month ? '...' : '↓ Descargar ZIP' }}
          </button>
        </div>
      </div>
    </div>

    <div class="page-header">
      <div>
        <h1 class="page-title">Usuarios</h1>
        <p class="page-sub">
          {{ stats.total }} usuarios · {{ stats.active }} activos
          <span v-if="maxUsersLimit" class="limit-badge">
            · Límite: {{ stats.active }} / {{ maxUsersLimit }}
          </span>
        </p>
      </div>
      <div class="header-actions">
        <button class="btn-primary" @click="openCreate"
          :disabled="!canWrite || isAtUserLimit"
          :title="isAtUserLimit ? 'Se alcanzó el límite de usuarios configurado' : ''">
          + Nuevo usuario
        </button>
        <span v-if="isAtUserLimit" class="limit-msg">Límite de usuarios alcanzado</span>
      </div>
    </div>

    <!-- Filters -->
    <div class="filters-bar">
      <select v-model="filterRole" class="filter-select" @change="loadUsers">
        <option value="">Todos los roles</option>
        <option v-for="(label, key) in ROLE_LABELS" :key="key" :value="key">{{ label }}</option>
      </select>
      <select v-model="filterStatus" class="filter-select" @change="loadUsers">
        <option value="">Activos</option>
        <option value="all">Todos los estados</option>
        <option value="inactive">Inactivos</option>
      </select>
    </div>

    <!-- Table -->
    <div class="table-wrap">
      <div v-if="loading" class="table-empty">Cargando...</div>
      <table v-else class="users-table">
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Email</th>
            <th>Rol</th>
            <th>Area asignada</th>
            <th>Estado</th>
            <th>Ultimo acceso</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="u in users" :key="u.id" class="user-row">
            <td>
              <div class="user-name-cell">
                <div class="user-avatar">{{ (u.full_name[0] ?? 'U').toUpperCase() }}</div>
                <span class="user-name">
                  {{ u.full_name }}
                  <span v-if="u.is_primary_admin" class="primary-badge">Admin principal</span>
                </span>
              </div>
            </td>
            <td class="mono small text-muted">{{ u.email }}</td>
            <td>
              <span class="role-pill" :style="{ background: ROLE_COLORS[u.role] + '20', color: ROLE_COLORS[u.role] }">
                {{ ROLE_LABELS[u.role] ?? u.role }}
              </span>
            </td>
            <td class="text-muted small">{{ u.home_node_name ?? '-- (acceso total)' }}</td>
            <td>
              <span :class="u.status === 'active' ? 'status-active' : 'status-inactive'">
                {{ u.status === 'active' ? 'Activo' : 'Inactivo' }}
              </span>
            </td>
            <td class="mono small text-muted">{{ formatDate(u.last_login_at) }}</td>
            <td>
              <div class="action-btns">
                <RouterLink :to="`/users/${u.id}/profile`" class="btn-profile" title="Ver perfil">&#x25C9;</RouterLink>
                <!-- Hide edit/deactivate for the primary admin -->
                <template v-if="!u.is_primary_admin">
                  <button class="btn-table" @click="openEdit(u)" :disabled="!canWrite">Editar</button>
                  <button v-if="['technician','supervisor','operator'].includes(u.role)"
                    class="btn-tags" @click="openTags(u)" title="Etiquetas" :disabled="!canWrite">&#x25C7;</button>
                  <button class="btn-table btn-table--danger" @click="confirmDelete(u)"
                    :disabled="!canWrite || u.id === currentUserId">Desactivar</button>
                </template>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Create/edit user modal -->
    <Teleport to="body">
      <div v-if="showForm" class="modal-overlay" @click.self="showForm = false">
        <div class="create-modal">
          <div class="modal-header">
            <h3>{{ editUser ? 'Editar usuario' : 'Nuevo usuario' }}</h3>
            <button class="modal-close" @click="showForm = false">&#x2715;</button>
          </div>
          <div class="modal-body">
            <div class="field">
              <label class="field-label">Nombre completo *</label>
              <input v-model="form.full_name" class="field-input" />
            </div>
            <div v-if="!editUser" class="field">
              <label class="field-label">Email *</label>
              <input v-model="form.email" type="email" class="field-input" />
            </div>
            <div v-if="!editUser" class="field">
              <label class="field-label">Contrasena *</label>
              <input v-model="form.password" type="password" class="field-input" placeholder="Minimo 8 caracteres" />
            </div>
            <div class="field-row">
              <div class="field">
                <label class="field-label">Rol *</label>
                <select v-model="form.role" class="field-input">
                  <option v-for="(label, key) in ROLE_LABELS" :key="key" :value="key">{{ label }}</option>
                </select>
              </div>
              <div class="field" v-if="editUser">
                <label class="field-label">Estado</label>
                <select v-model="form.status" class="field-input">
                  <option value="active">Activo</option>
                  <option value="inactive">Inactivo</option>
                </select>
              </div>
            </div>
            <div class="field node-picker-field">
              <label class="field-label">Area de trabajo (home node)</label>
              <div class="node-picker" ref="nodePickerRef">
                <div class="node-picker-input" @click="showNodeDropdown = !showNodeDropdown">
                  <div v-if="selectedNodeInfo" class="node-picker-selected">
                    <span class="np-type-badge">{{ NODE_TYPE_SHORT[selectedNodeInfo.node_type] ?? selectedNodeInfo.node_type }}</span>
                    <span class="np-selected-name">{{ selectedNodeInfo.name }}</span>
                    <button type="button" class="np-clear" @click.stop="clearNodeSelection">&#x2715;</button>
                  </div>
                  <span v-else class="np-placeholder">-- Acceso total (admin) --</span>
                  <span class="np-chevron">&#x25BE;</span>
                </div>
                <div v-if="showNodeDropdown" class="node-picker-dropdown">
                  <input
                    ref="nodeSearchInputRef"
                    v-model="nodeSearchQ"
                    class="np-search"
                    placeholder="Buscar por nombre, tipo o ruta..."
                    @keydown.escape="showNodeDropdown = false"
                  />
                  <div class="np-results">
                    <div
                      class="np-option np-option--none"
                      :class="{ 'np-option--active': form.home_node_id === null }"
                      @click="selectNode(null)"
                    >
                      <span class="np-option-name">-- Acceso total (admin) --</span>
                    </div>
                    <div v-if="filteredNodes.length === 0 && nodeSearchQ.length > 0" class="np-empty">
                      Sin resultados para "{{ nodeSearchQ }}"
                    </div>
                    <div
                      v-for="n in filteredNodes"
                      :key="n.id"
                      class="np-option"
                      :class="{ 'np-option--active': form.home_node_id === n.id }"
                      @click="selectNode(n.id)"
                    >
                      <span class="np-type-badge" :class="'np-type--' + n.node_type">{{ NODE_TYPE_SHORT[n.node_type] ?? n.node_type }}</span>
                      <div class="np-option-body">
                        <span class="np-option-name">{{ n.name }}</span>
                        <span class="np-option-path">{{ n.path }}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div v-if="formError" class="modal-error">{{ formError }}</div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary" @click="showForm = false">Cancelar</button>
            <button class="btn-primary" :disabled="saving" @click="submitForm">
              {{ saving ? 'Guardando...' : (editUser ? 'Guardar' : 'Crear usuario') }}
            </button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>

  <!-- Tags and scoring modal -->
  <Teleport to="body">
    <div v-if="tagsUser" class="modal-overlay" @click.self="tagsUser = null">
      <div class="tags-modal">
        <div class="modal-header">
          <h3>Etiquetas -- {{ tagsUser.full_name }}</h3>
          <button class="modal-close" @click="tagsUser = null">&#x2715;</button>
        </div>
        <div class="modal-body">
          <div class="field">
            <label class="field-label">Etiquetas actuales</label>
            <div class="tags-list">
              <span v-for="tag in userTags" :key="tag" class="tag-chip">
                {{ tag }}
                <button class="tag-remove" @click="removeTag(tag)" :disabled="!canWrite">&#x2715;</button>
              </span>
              <span v-if="!userTags.length" class="text-muted small">Sin etiquetas</span>
            </div>
          </div>
          <div class="field">
            <label class="field-label">Anadir etiqueta</label>
            <div class="tag-input-row">
              <input v-model="newTag" class="field-input" placeholder="PLC, hidraulica, KHS..."
                @keydown.enter.prevent="addTag" list="tag-suggestions" />
              <datalist id="tag-suggestions">
                <option v-for="s in TAG_SUGGESTIONS" :key="s" :value="s" />
              </datalist>
              <button class="btn-add-tag" @click="addTag" :disabled="!canWrite || !newTag.trim()">+</button>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn-secondary" @click="tagsUser = null">Cerrar</button>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
import { useToast, apiErrorMsg } from '@/composables/useToast'
import { runWithUndo } from '@/composables/useUndo'
const toast = useToast()
import { ref, computed, onMounted, onBeforeUnmount, nextTick, watch } from 'vue'
import { usersApi } from '@/api/phase2'
import { systemApi, type SystemStatus } from '@/api/system'
import client from '@/api/client'
import { nodesApi } from '@/api/nodes'
import { useAuthStore } from '@/stores/auth'
import { useSystemPause } from '@/composables/useSystemPause'
import { ROLE_LABELS, ROLE_COLORS } from '@/types'

const authStore = useAuthStore()
const { canWrite } = useSystemPause()
const currentUserId = authStore.user?.id


const users = ref<any[]>([])
const stats = ref({ total: 0, active: 0 })
const loading = ref(false)
const filterRole = ref('')
const filterStatus = ref('')
interface FlatNode { id: number; name: string; path: string; node_type: string }
const availableNodes = ref<FlatNode[]>([])
const nodeSearchQ = ref('')
const showNodeDropdown = ref(false)
const nodePickerRef = ref<HTMLElement | null>(null)
const nodeSearchInputRef = ref<HTMLInputElement | null>(null)

const NODE_TYPE_SHORT: Record<string, string> = {
  organization: 'ORG', plant: 'PLA', area: 'ARE',
  line: 'LIN', equipment: 'EQP', component: 'COM', measurement_point: 'MED',
}

const filteredNodes = computed(() => {
  const q = nodeSearchQ.value.toLowerCase().trim()
  if (!q) return availableNodes.value
  return availableNodes.value.filter(n =>
    n.name.toLowerCase().includes(q) ||
    n.path.toLowerCase().includes(q) ||
    (NODE_TYPE_SHORT[n.node_type] ?? n.node_type).toLowerCase().includes(q)
  )
})

const selectedNodeInfo = computed(() => {
  if (form.value.home_node_id == null) return null
  return availableNodes.value.find(n => n.id === form.value.home_node_id) ?? null
})

function selectNode(id: number | null) {
  form.value.home_node_id = id
  showNodeDropdown.value = false
  nodeSearchQ.value = ''
}

function clearNodeSelection() {
  form.value.home_node_id = null
}

function onClickOutsidePicker(e: MouseEvent) {
  if (nodePickerRef.value && !nodePickerRef.value.contains(e.target as Node)) {
    showNodeDropdown.value = false
  }
}

watch(showNodeDropdown, (open) => {
  if (open) {
    nextTick(() => nodeSearchInputRef.value?.focus())
  } else {
    nodeSearchQ.value = ''
  }
})

onMounted(() => document.addEventListener('mousedown', onClickOutsidePicker))
onBeforeUnmount(() => document.removeEventListener('mousedown', onClickOutsidePicker))

const showForm = ref(false)
const editUser = ref<any | null>(null)
const saving = ref(false)
const formError = ref('')
const form = ref({ full_name: '', email: '', password: '', role: 'technician', status: 'active', home_node_id: null as number | null })

// System
const systemStatus = ref<SystemStatus | null>(null)
const pauseContact = ref('')
const pauseLoading = ref(false)
const limitLoading = ref(false)
const newMaxUsers = ref<number | null>(null)

const maxUsersLimit = computed(() => systemStatus.value?.max_users ?? null)
const isAtUserLimit = computed(() => {
  if (!maxUsersLimit.value) return false
  return stats.value.active >= maxUsersLimit.value
})

const TAG_SUGGESTIONS = ['PLC', 'hidraulica', 'neumatica', 'soldadura', 'electricidad',
  'KHS', 'Krones', 'KUKA', 'ABB', 'Siemens', 'mecanica', 'instrumentacion', 'refrigeracion']

const tagsUser = ref<any>(null)
const userTags = ref<string[]>([])
const newTag = ref('')

async function openTags(user: any) {
  tagsUser.value = user
  newTag.value = ''
  try {
    const { data } = await client.get(`/technicians/${user.id}`)
    userTags.value = data.profile?.tags ?? []
  } catch { userTags.value = [] }
}

async function addTag() {
  if (!newTag.value.trim() || !tagsUser.value) return
  try {
    await client.post(`/technicians/${tagsUser.value.id}/tags`, { tag: newTag.value.trim() })
    userTags.value.push(newTag.value.trim())
    newTag.value = ''
  } catch (err: unknown) { toast.fromError(err, 'Error') }
}

async function removeTag(tag: string) {
  if (!tagsUser.value) return
  await client.delete(`/technicians/${tagsUser.value.id}/tags/${encodeURIComponent(tag)}`)
  userTags.value = userTags.value.filter(t => t !== tag)
}

async function loadUsers() {
  loading.value = true
  try {
    const data = await usersApi.list({ role: filterRole.value || undefined, status: filterStatus.value || undefined })
    users.value = data.users ?? []
    stats.value = { total: data.total ?? 0, active: data.active ?? 0 }
  } finally { loading.value = false }
}

async function loadNodes() {
  try {
    const data = await nodesApi.getTree()
    const flat: FlatNode[] = []
    const flatten = (nodes: any[], ancestors: string[] = []) => {
      nodes.forEach(n => {
        const path = ancestors.length ? ancestors.join(' > ') : ''
        flat.push({ id: n.id, name: n.name, path, node_type: n.node_type ?? '' })
        if (n.children) flatten(n.children, [...ancestors, n.name])
      })
    }
    flatten(data.nodes ?? [])
    availableNodes.value = flat
  } catch { availableNodes.value = [] }
}

async function loadSystemStatus() {
  try {
    systemStatus.value = await systemApi.getStatus()
    newMaxUsers.value = systemStatus.value.max_users
  } catch { /* no access */ }
}

function openCreate() {
  if (isAtUserLimit.value) return
  editUser.value = null
  form.value = { full_name: '', email: '', password: '', role: 'technician', status: 'active', home_node_id: null }
  formError.value = ''
  showNodeDropdown.value = false
  nodeSearchQ.value = ''
  showForm.value = true
}

function openEdit(u: any) {
  editUser.value = u
  form.value = { full_name: u.full_name, email: u.email, password: '', role: u.role, status: u.status, home_node_id: u.home_node_id }
  formError.value = ''
  showNodeDropdown.value = false
  nodeSearchQ.value = ''
  showForm.value = true
}

async function submitForm() {
  formError.value = ''
  saving.value = true
  try {
    if (editUser.value) {
      await usersApi.update(editUser.value.id, { full_name: form.value.full_name, role: form.value.role, status: form.value.status, home_node_id: form.value.home_node_id ?? undefined })
    } else {
      if (!form.value.email || !form.value.password || !form.value.full_name) { formError.value = 'Todos los campos son requeridos'; return }
      await usersApi.create({ email: form.value.email, password: form.value.password, full_name: form.value.full_name, role: form.value.role, home_node_id: form.value.home_node_id ?? undefined })
    }
    showForm.value = false
    await loadUsers()
  } catch (err: unknown) {
    formError.value = apiErrorMsg(err, 'Error guardando usuario')
  } finally { saving.value = false }
}

async function confirmDelete(u: any) {
  // Reversible action: deactivate and allow "Undo" before the toast's TTL.
  try {
    await runWithUndo(
      async () => usersApi.delete(u.id),
      async () => usersApi.update(u.id, {
        full_name: u.full_name,
        role: u.role,
        status: 'active',
        home_node_id: u.home_node_id ?? undefined,
      }),
      { message: `Cuenta de ${u.full_name} desactivada`, detail: 'Pulsa Deshacer para revertir' }
    )
    await loadUsers()
  } catch (err: unknown) {
    toast.fromError(err, 'Error desactivando usuario')
  }
}

// ─── System control ───────────────────────────────────────────────────

async function activatePause() {
  pauseLoading.value = true
  try {
    await systemApi.pause(pauseContact.value || 'Contacte al administrador del sistema')
    authStore.setSystemPaused(true)
    pauseContact.value = ''
    await loadSystemStatus()
  } catch (err: unknown) {
    toast.fromError(err, 'Error activando modo parada')
  } finally { pauseLoading.value = false }
}

async function deactivatePause() {
  pauseLoading.value = true
  try {
    await systemApi.resume()
    authStore.setSystemPaused(false)
    await loadSystemStatus()
  } catch (err: unknown) {
    toast.fromError(err, 'Error desactivando modo parada')
  } finally { pauseLoading.value = false }
}

async function updateMaxUsers() {
  limitLoading.value = true
  try {
    await client.put(`/superadmin/tenants/${authStore.user?.tenant_id}/max-users`, {
      max_users: newMaxUsers.value || null
    })
    await loadSystemStatus()
  } catch (err: unknown) {
    toast.fromError(err, 'Error actualizando límite')
  } finally { limitLoading.value = false }
}

// ─── Monthly folders ─────────────────────────────────────────────────────
const monthlyFolders = ref<{ month: string; frozen: boolean }[]>([])
const loadingFolders = ref(false)
const dlFolderLoading = ref<string | false>(false)

async function loadMonthlyFolders() {
  loadingFolders.value = true
  try {
    const { data } = await client.get('/daily-summaries/months')
    monthlyFolders.value = data.months ?? []
  } catch { monthlyFolders.value = [] }
  finally { loadingFolders.value = false }
}

function formatMonthLabel(m: string) {
  const MONTHS: Record<string, string> = {
    '01':'Enero','02':'Febrero','03':'Marzo','04':'Abril',
    '05':'Mayo','06':'Junio','07':'Julio','08':'Agosto',
    '09':'Septiembre','10':'Octubre','11':'Noviembre','12':'Diciembre'
  }
  const [y, mm] = m.split('-')
  return `${MONTHS[mm] ?? mm} ${y}`
}

function downloadMonthZIP(month: string) {
  dlFolderLoading.value = month
  client.get(`/daily-summaries/export-all?month=${month}`, { responseType: 'blob' })
    .then(res => {
      const blob = new Blob([res.data])
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `resumenes_${month}.zip`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    })
    .catch(() => toast.error('Error descargando. Verifique que existan datos.'))
    .finally(() => { dlFolderLoading.value = false })
}

function formatDate(iso: string | null) {
  if (!iso) return '--'
  try { return new Date(iso).toLocaleDateString('es-ES', { day:'2-digit', month:'2-digit', year:'numeric' }) }
  catch { return iso }
}

onMounted(async () => {
  await Promise.all([loadNodes(), loadUsers(), loadSystemStatus(), loadMonthlyFolders()])
})
</script>

<style scoped>
.users-layout { display: flex; flex-direction: column; gap: var(--space-5); }
.page-header { display: flex; align-items: flex-start; justify-content: space-between; }
.page-title { font-size: 1.4rem; font-weight: 700; color: var(--color-primary); }
.page-sub { font-size: 0.8rem; color: var(--color-text-muted); }
.header-actions { display: flex; flex-direction: column; align-items: flex-end; gap: var(--space-2); }
.limit-msg { font-size: 0.72rem; color: var(--color-alert); font-weight: 500; }
.limit-badge { color: var(--color-alert); font-weight: 600; }
.filters-bar { display: flex; gap: var(--space-3); }
.filter-select { height: 36px; padding: 0 var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.8rem; background: var(--color-surface); }

/* System panel */
.system-panel { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); padding: var(--space-5) var(--space-6); }
.system-title { font-size: 1rem; font-weight: 600; color: var(--color-primary); margin-bottom: var(--space-4); }
.system-controls { display: flex; flex-direction: column; gap: var(--space-4); }
.control-card { display: flex; align-items: center; justify-content: space-between; gap: var(--space-4); padding: var(--space-4); background: var(--color-surface-2); border-radius: var(--radius); flex-wrap: wrap; }
.control-info { display: flex; flex-direction: column; gap: 2px; }
.control-label { font-size: 0.82rem; font-weight: 600; color: var(--color-text); }
.control-desc { font-size: 0.75rem; color: var(--color-text-muted); }
.pause-form { display: flex; gap: var(--space-2); align-items: center; }
.limit-form { display: flex; gap: var(--space-2); align-items: center; }
.field-input--sm { height: 32px; font-size: 0.8rem; }
.btn-danger { height: 32px; padding: 0 var(--space-4); background: var(--color-alert); color: #fff; border: none; border-radius: var(--radius); font-size: 0.8rem; font-weight: 500; cursor: pointer; }
.btn-danger:hover:not(:disabled) { opacity: 0.9; }
.btn-danger:disabled { opacity: 0.5; cursor: not-allowed; }
.btn-success { height: 32px; padding: 0 var(--space-4); background: var(--color-success, #27AE60); color: #fff; border: none; border-radius: var(--radius); font-size: 0.8rem; font-weight: 500; cursor: pointer; }
.btn-success:hover:not(:disabled) { opacity: 0.9; }
.btn-success:disabled { opacity: 0.5; cursor: not-allowed; }
.btn-sm { height: 32px; font-size: 0.8rem; padding: 0 var(--space-3); }

/* Table */
.table-wrap { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); overflow: hidden; }
.table-empty { padding: var(--space-8); text-align: center; color: var(--color-text-muted); }
.users-table { width: 100%; border-collapse: collapse; }
.users-table th { padding: var(--space-3) var(--space-4); font-size: 0.68rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); background: var(--color-surface-2); border-bottom: 1px solid var(--color-border-light); text-align: left; }
.user-row { border-bottom: 1px solid var(--color-border-light); }
.user-row td { padding: var(--space-3) var(--space-4); font-size: 0.8rem; }

.user-name-cell { display: flex; align-items: center; gap: var(--space-3); }
.user-avatar { width: 28px; height: 28px; border-radius: 50%; background: var(--color-accent); color: #fff; font-size: 0.72rem; font-weight: 700; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.user-name { font-weight: 500; }
.primary-badge { display: inline-block; font-size: 0.62rem; font-weight: 700; color: var(--color-alert); background: rgba(233,69,96,0.08); border: 1px solid rgba(233,69,96,0.2); padding: 1px 6px; border-radius: 10px; margin-left: var(--space-2); vertical-align: middle; }

.role-pill { font-size: 0.7rem; font-weight: 600; padding: 2px 8px; border-radius: 20px; }
.status-active { color: var(--color-success); font-size: 0.8rem; font-weight: 500; }
.status-inactive { color: var(--color-text-muted); font-size: 0.8rem; }

.action-btns { display: flex; gap: var(--space-2); }
.btn-table { height: 28px; padding: 0 var(--space-3); background: var(--color-surface-2); border: 1px solid var(--color-border); border-radius: var(--radius-sm); font-size: 0.75rem; cursor: pointer; }
.btn-table:hover:not(:disabled) { background: var(--color-border-light); }
.btn-table:disabled { opacity: 0.4; cursor: not-allowed; }
.btn-table--danger:hover:not(:disabled) { background: rgba(233,69,96,0.1); border-color: rgba(233,69,96,0.3); color: var(--color-alert); }

.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; padding: var(--space-4); }
.create-modal { background: var(--color-surface); border-radius: var(--radius-lg); width: 100%; max-width: 480px; box-shadow: var(--shadow-lg); }
.tags-modal { background: var(--color-surface); border-radius: var(--radius-lg); width: 100%; max-width: 480px; box-shadow: var(--shadow-lg); }
.modal-header { display: flex; justify-content: space-between; align-items: center; padding: var(--space-5) var(--space-6); border-bottom: 1px solid var(--color-border-light); }
.modal-header h3 { font-size: 1rem; font-weight: 600; color: var(--color-primary); }
.modal-close { background: none; border: none; cursor: pointer; color: var(--color-text-muted); font-size: 1rem; }
.modal-body { padding: var(--space-5) var(--space-6); display: flex; flex-direction: column; gap: var(--space-4); }
.modal-footer { display: flex; justify-content: flex-end; gap: var(--space-3); padding: var(--space-4) var(--space-6); border-top: 1px solid var(--color-border-light); }
.modal-error { background: rgba(233,69,96,0.08); border: 1px solid rgba(233,69,96,0.3); border-radius: var(--radius); padding: var(--space-3); font-size: 0.875rem; color: var(--color-alert); }
.field { display: flex; flex-direction: column; gap: var(--space-1); }
.field-row { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-3); }
.field-label { font-size: 0.68rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); }
.field-input { height: 38px; padding: 0 var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; background: var(--color-surface); outline: none; width: 100%; }
.field-input:focus { border-color: var(--color-accent); }
.btn-primary { height: 38px; padding: 0 var(--space-5); background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); font-size: 0.875rem; font-weight: 500; cursor: pointer; }
.btn-primary:hover:not(:disabled) { background: var(--color-accent); }
.btn-primary:disabled { opacity: 0.65; cursor: not-allowed; }
.btn-secondary { height: 38px; padding: 0 var(--space-5); background: var(--color-surface-2); color: var(--color-text); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; cursor: pointer; }
.btn-tags { height: 28px; width: 28px; display: inline-flex; align-items: center; justify-content: center; background: var(--color-surface-2); border: 1px solid var(--color-border); border-radius: var(--radius-sm); font-size: 0.85rem; cursor: pointer; }
.btn-tags:hover:not(:disabled) { background: var(--color-border-light); }
.btn-tags:disabled { opacity: 0.4; cursor: not-allowed; }
.tags-list { display: flex; flex-wrap: wrap; gap: var(--space-2); }
.tag-chip { display: inline-flex; align-items: center; gap: var(--space-1); background: var(--color-surface-2); border: 1px solid var(--color-border); border-radius: 16px; padding: 2px 10px; font-size: 0.78rem; }
.tag-remove { background: none; border: none; cursor: pointer; color: var(--color-text-muted); font-size: 0.7rem; padding: 0; }
.tag-remove:disabled { opacity: 0.4; cursor: not-allowed; }
.tag-input-row { display: flex; gap: var(--space-2); }
.btn-add-tag { height: 38px; width: 38px; background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); font-size: 1rem; cursor: pointer; flex-shrink: 0; }
.btn-add-tag:disabled { opacity: 0.5; cursor: not-allowed; }
.mono { font-family: var(--font-mono); }
.small { font-size: 0.75rem; }
.text-muted { color: var(--color-text-muted); }
.btn-profile { display: inline-flex; align-items: center; justify-content: center; width: 30px; height: 30px; background: rgba(15,52,96,0.06); border: 1px solid rgba(15,52,96,0.2); border-radius: var(--radius-sm); font-size: 0.85rem; text-decoration: none; color: var(--color-accent); transition: all var(--transition); }
.btn-profile:hover { background: rgba(15,52,96,0.12); }

/* ─── Node Picker ────────────────────────────────────────── */
.node-picker-field { position: relative; }
.node-picker { position: relative; }
.node-picker-input {
  display: flex; align-items: center; justify-content: space-between;
  height: 38px; padding: 0 var(--space-3);
  border: 1px solid var(--color-border); border-radius: var(--radius);
  background: var(--color-surface); cursor: pointer; gap: var(--space-2);
}
.node-picker-input:hover { border-color: var(--color-accent); }
.np-placeholder { font-size: 0.875rem; color: var(--color-text-muted); }
.np-chevron { font-size: 0.75rem; color: var(--color-text-muted); flex-shrink: 0; }
.node-picker-selected {
  display: flex; align-items: center; gap: var(--space-2);
  flex: 1; min-width: 0; overflow: hidden;
}
.np-selected-name { font-size: 0.875rem; color: var(--color-text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.np-clear {
  background: none; border: none; cursor: pointer; color: var(--color-text-muted);
  font-size: 0.7rem; padding: 2px 4px; border-radius: 50%; flex-shrink: 0;
}
.np-clear:hover { color: var(--color-alert); background: rgba(233,69,96,0.08); }

.node-picker-dropdown {
  position: absolute; top: calc(100% + 4px); left: 0; right: 0;
  background: var(--color-surface); border: 1px solid var(--color-border);
  border-radius: var(--radius); box-shadow: var(--shadow-lg);
  z-index: 50; overflow: hidden;
}
.np-search {
  width: 100%; height: 36px; padding: 0 var(--space-3);
  border: none; border-bottom: 1px solid var(--color-border-light);
  font-size: 0.825rem; background: var(--color-surface-2); outline: none;
  box-sizing: border-box;
}
.np-search:focus { background: var(--color-surface); }
.np-results { max-height: 260px; overflow-y: auto; }
.np-option {
  display: flex; align-items: center; gap: var(--space-2);
  padding: var(--space-2) var(--space-3); cursor: pointer;
  border-bottom: 1px solid var(--color-border-light);
}
.np-option:last-child { border-bottom: none; }
.np-option:hover { background: var(--color-surface-2); }
.np-option--active { background: rgba(15,52,96,0.06); }
.np-option--none { padding: var(--space-3); }
.np-option--none .np-option-name { font-size: 0.825rem; color: var(--color-text-muted); }
.np-option-body { display: flex; flex-direction: column; min-width: 0; flex: 1; }
.np-option-name { font-size: 0.825rem; font-weight: 500; color: var(--color-text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.np-option-path { font-size: 0.68rem; color: var(--color-text-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.np-type-badge {
  display: inline-flex; align-items: center; justify-content: center;
  font-size: 0.58rem; font-weight: 700; letter-spacing: 0.03em;
  padding: 1px 6px; border-radius: 3px; flex-shrink: 0;
  background: var(--color-surface-2); color: var(--color-text-muted);
  border: 1px solid var(--color-border);
}
.np-type--organization { background: rgba(233,69,96,0.08); color: #E94560; border-color: rgba(233,69,96,0.2); }
.np-type--plant { background: rgba(15,52,96,0.08); color: #0F3460; border-color: rgba(15,52,96,0.2); }
.np-type--area { background: rgba(39,174,96,0.08); color: #27AE60; border-color: rgba(39,174,96,0.2); }
.np-type--line { background: rgba(243,156,18,0.08); color: #F39C12; border-color: rgba(243,156,18,0.2); }
.np-type--equipment { background: rgba(139,92,246,0.08); color: #8B5CF6; border-color: rgba(139,92,246,0.2); }
.np-type--component { background: rgba(107,114,128,0.08); color: #6B7280; border-color: rgba(107,114,128,0.2); }
.np-type--measurement_point { background: rgba(6,182,212,0.08); color: #06B6D4; border-color: rgba(6,182,212,0.2); }
.np-empty { padding: var(--space-4); text-align: center; font-size: 0.8rem; color: var(--color-text-muted); }

/* Monthly folders */
.monthly-folders-panel { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); padding: var(--space-5) var(--space-6); }
.system-subtitle { display: block; font-size: 0.75rem; color: var(--color-text-muted); margin-top: 2px; }
.folders-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: var(--space-3); }
.folder-card { display: flex; align-items: center; gap: var(--space-3); padding: var(--space-4); background: var(--color-surface-2); border: 1px solid var(--color-border-light); border-radius: var(--radius); }
.folder-card--frozen { border-left: 3px solid var(--color-accent); }
.folder-icon { font-size: 1.5rem; color: var(--color-accent); flex-shrink: 0; }
.folder-info { flex: 1; display: flex; flex-direction: column; gap: 2px; }
.folder-month { font-size: 0.875rem; font-weight: 600; color: var(--color-primary); }
.folder-status { font-size: 0.68rem; font-weight: 700; }
.folder-status--frozen { color: var(--color-accent); }
.folder-status--open { color: #27AE60; }
.btn-folder-dl { height: 30px; padding: 0 var(--space-3); background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); font-size: 0.72rem; font-weight: 600; cursor: pointer; white-space: nowrap; }
.btn-folder-dl:hover:not(:disabled) { background: var(--color-accent); }
.btn-folder-dl:disabled { opacity: 0.45; cursor: not-allowed; }

@media (max-width: 768px) {
  .page-header { flex-direction: column; gap: var(--space-3); }
  .page-title { font-size: 1.15rem; }
  .header-actions { width: 100%; }
  .users-table { font-size: 0.78rem; }
  .users-table th, .users-table td { padding: var(--space-2); }
  .users-table th:nth-child(n+4), .users-table td:nth-child(n+4) { display: none; }

  .modal-overlay { padding: 0; }
  .create-modal { max-width: 100%; border-radius: 0; max-height: 100vh; max-height: 100dvh; overflow-y: auto; }
  .modal-body { padding: var(--space-4); }
  .field-row { grid-template-columns: 1fr; }
  .field-input { height: 42px; }
  .btn-primary, .btn-secondary { height: 44px; font-size: 0.9rem; }

  .folders-grid { grid-template-columns: 1fr; }
  .monthly-folders-panel { padding: var(--space-4); }
  .btn-folder-dl { height: 40px; font-size: 0.78rem; }
}
</style>
