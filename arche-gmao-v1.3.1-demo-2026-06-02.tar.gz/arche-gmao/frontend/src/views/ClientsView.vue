<template>
  <div class="clients-page">
    <div class="page-header">
      <div>
        <h1 class="page-title">Clientes</h1>
        <p class="page-sub">{{ clients.length }} clientes registrados</p>
      </div>
      <button class="btn-primary" @click="openCreate" :disabled="!canWrite">+ Nuevo cliente</button>
    </div>

    <div class="table-wrap">
      <div v-if="loading" class="table-empty">Cargando...</div>
      <div v-else-if="!clients.length" class="table-empty">No hay clientes registrados.</div>
      <table v-else class="clients-table">
        <thead>
          <tr>
            <th>Código</th>
            <th>Nombre</th>
            <th>Tipo</th>
            <th>Contacto</th>
            <th>Email</th>
            <th>Teléfono</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="c in clients" :key="c.id" @click="openEdit(c)">
            <td class="mono small">{{ c.code }}</td>
            <td>{{ c.name }}</td>
            <td><span class="type-badge" :class="`type--${c.client_type}`">{{ TYPE_LABELS[c.client_type] ?? c.client_type }}</span></td>
            <td class="text-muted small">{{ c.contact_name ?? '-' }}</td>
            <td class="text-muted small">{{ c.contact_email ?? '-' }}</td>
            <td class="text-muted small">{{ c.contact_phone ?? '-' }}</td>
            <td>
              <button class="action-btn action-btn--del" @click.stop="deleteClient(c)" title="Desactivar">✕</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Create/edit modal -->
    <Teleport to="body">
      <div v-if="showModal" class="modal-overlay" @click.self="showModal = false">
        <div class="client-modal">
          <div class="modal-header">
            <h3>{{ editing ? 'Editar cliente' : 'Nuevo cliente' }}</h3>
            <button class="modal-close" @click="showModal = false">✕</button>
          </div>
          <div class="modal-body">
            <div class="field-row">
              <div class="field">
                <label class="field-label">Código *</label>
                <input v-model="form.code" class="field-input" :disabled="!!editing" placeholder="CLI-001" />
              </div>
              <div class="field">
                <label class="field-label">Nombre *</label>
                <input v-model="form.name" class="field-input" placeholder="Nombre del cliente" />
              </div>
            </div>
            <div class="field-row">
              <div class="field">
                <label class="field-label">Tipo</label>
                <select v-model="form.client_type" class="field-input">
                  <option value="external">Externo</option>
                  <option value="internal">Interno</option>
                </select>
              </div>
              <div class="field">
                <label class="field-label">Persona de contacto</label>
                <input v-model="form.contact_name" class="field-input" placeholder="Nombre" />
              </div>
            </div>
            <div class="field-row">
              <div class="field">
                <label class="field-label">Email de contacto</label>
                <input v-model="form.contact_email" class="field-input" type="email" placeholder="email@ejemplo.com" />
              </div>
              <div class="field">
                <label class="field-label">Teléfono</label>
                <input v-model="form.contact_phone" class="field-input" placeholder="+34 600 000 000" />
              </div>
            </div>
            <div class="field">
              <label class="field-label">Notas</label>
              <textarea v-model="form.notes" class="field-input" rows="2" placeholder="Notas adicionales..." />
            </div>
            <div v-if="formError" class="modal-error">{{ formError }}</div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary" @click="showModal = false">Cancelar</button>
            <button class="btn-primary" :disabled="!canWrite || saving" @click="submitForm">
              {{ saving ? 'Guardando...' : (editing ? 'Guardar cambios' : 'Crear cliente') }}
            </button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import { useToast, apiErrorMsg } from '@/composables/useToast'
import { runWithUndo } from '@/composables/useUndo'
const toast = useToast()
import { ref, onMounted } from 'vue'
import { clientsApi } from '@/api/clients'
import type { Client } from '@/types/factory'
import { useSystemPause } from '@/composables/useSystemPause'

const { canWrite } = useSystemPause()
const TYPE_LABELS: Record<string, string> = { external: 'Externo', internal: 'Interno' }

const clients = ref<Client[]>([])
const loading = ref(false)
const showModal = ref(false)
const editing = ref<Client | null>(null)
const saving = ref(false)
const formError = ref('')
const form = ref({ name: '', code: '', client_type: 'external', contact_name: '', contact_email: '', contact_phone: '', notes: '' })

async function loadClients() {
  loading.value = true
  try {
    const data = await clientsApi.list()
    clients.value = data.clients ?? []
  } finally { loading.value = false }
}

function openCreate() {
  editing.value = null
  form.value = { name: '', code: '', client_type: 'external', contact_name: '', contact_email: '', contact_phone: '', notes: '' }
  formError.value = ''
  showModal.value = true
}

function openEdit(c: Client) {
  editing.value = c
  form.value = {
    name: c.name, code: c.code, client_type: c.client_type,
    contact_name: c.contact_name ?? '', contact_email: c.contact_email ?? '',
    contact_phone: c.contact_phone ?? '', notes: c.notes ?? ''
  }
  formError.value = ''
  showModal.value = true
}

async function submitForm() {
  if (!form.value.name || !form.value.code) { formError.value = 'Nombre y código son requeridos'; return }
  saving.value = true; formError.value = ''
  const payload = {
    ...form.value,
    contact_name: form.value.contact_name || null,
    contact_email: form.value.contact_email || null,
    contact_phone: form.value.contact_phone || null,
    notes: form.value.notes || null,
  }
  try {
    if (editing.value) {
      await clientsApi.update(editing.value.id, payload)
    } else {
      await clientsApi.create(payload)
    }
    showModal.value = false
    await loadClients()
  } catch (err: unknown) {
    formError.value = apiErrorMsg(err, 'Error guardando')
  } finally { saving.value = false }
}

async function deleteClient(c: Client) {
  // Reversible action: deactivate immediately and offer "Undo" in the toast.
  try {
    await runWithUndo(
      async () => clientsApi.delete(c.id),
      async () => clientsApi.update(c.id, { ...c, status: 'active' } as any),
      { message: `Cliente "${c.name}" desactivado`, detail: 'Pulsa Deshacer para revertir' }
    )
    await loadClients()
  } catch (err) {
    toast.fromError(err, 'Error desactivando cliente')
  }
}

onMounted(loadClients)
</script>

<style scoped>
.clients-page { display: flex; flex-direction: column; gap: var(--space-4); }
.page-header { display: flex; align-items: center; justify-content: space-between; gap: var(--space-4); flex-wrap: wrap; }
.page-title { font-size: 1.25rem; font-weight: 700; color: var(--color-primary); }
.page-sub { font-size: 0.78rem; color: var(--color-text-muted); margin-top: 2px; }

.table-wrap { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); overflow: hidden; }
.table-empty { padding: var(--space-8); text-align: center; color: var(--color-text-muted); font-size: 0.875rem; }
.clients-table { width: 100%; border-collapse: collapse; font-size: 0.875rem; }
.clients-table th { text-align: left; padding: var(--space-3) var(--space-4); font-size: 0.68rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--color-text-muted); background: var(--color-surface-2); border-bottom: 1px solid var(--color-border-light); }
.clients-table td { padding: var(--space-3) var(--space-4); border-bottom: 1px solid var(--color-border-light); }
.clients-table tbody tr { cursor: pointer; transition: background var(--transition); }
.clients-table tbody tr:hover { background: var(--color-surface-2); }

.type-badge { font-size: 0.72rem; font-weight: 600; padding: 2px 8px; border-radius: 10px; }
.type--external { background: rgba(59,130,246,0.1); color: #3B82F6; }
.type--internal { background: rgba(139,92,246,0.1); color: #8B5CF6; }

.btn-primary { height: 36px; padding: 0 var(--space-5); background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); font-size: 0.875rem; font-weight: 500; cursor: pointer; }
.btn-primary:hover:not(:disabled) { background: var(--color-accent); }
.btn-primary:disabled { opacity: 0.65; cursor: not-allowed; }
.btn-secondary { height: 36px; padding: 0 var(--space-4); background: var(--color-surface-2); color: var(--color-text); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; cursor: pointer; }
.action-btn { width: 28px; height: 28px; background: none; border: none; cursor: pointer; font-size: 0.8rem; color: var(--color-text-muted); border-radius: var(--radius-sm); }
.action-btn--del:hover { color: var(--color-alert); background: rgba(233,69,96,0.08); }

.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; padding: var(--space-4); }
.client-modal { background: var(--color-surface); border-radius: var(--radius-lg); width: 100%; max-width: 540px; max-height: 90vh; display: flex; flex-direction: column; box-shadow: var(--shadow-lg); }
.modal-header { display: flex; justify-content: space-between; align-items: center; padding: var(--space-4) var(--space-5); border-bottom: 1px solid var(--color-border-light); }
.modal-header h3 { font-size: 1rem; font-weight: 600; color: var(--color-primary); }
.modal-close { background: none; border: none; font-size: 1rem; cursor: pointer; color: var(--color-text-muted); }
.modal-body { flex: 1; overflow-y: auto; padding: var(--space-5); display: flex; flex-direction: column; gap: var(--space-4); }
.modal-footer { display: flex; justify-content: flex-end; gap: var(--space-3); padding: var(--space-4) var(--space-5); border-top: 1px solid var(--color-border-light); }
.modal-error { background: rgba(233,69,96,0.08); border: 1px solid rgba(233,69,96,0.3); border-radius: var(--radius); padding: var(--space-3); font-size: 0.875rem; color: var(--color-alert); }

.field { display: flex; flex-direction: column; gap: var(--space-1); }
.field-row { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-3); }
.field-label { font-size: 0.68rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); }
.field-input { height: 38px; padding: 0 var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; background: var(--color-surface); outline: none; width: 100%; }
.field-input:focus { border-color: var(--color-accent); }
textarea.field-input { height: auto; padding: var(--space-2) var(--space-3); resize: vertical; font-family: var(--font-ui); }

.mono { font-family: var(--font-mono); }
.small { font-size: 0.75rem; }
.text-muted { color: var(--color-text-muted); }

@media (max-width: 768px) {
  .page-header { flex-direction: column; gap: var(--space-3); }
  .page-title { font-size: 1.15rem; }
  .clients-table { font-size: 0.78rem; }
  .clients-table th, .clients-table td { padding: var(--space-2); }
  .clients-table th:nth-child(n+4), .clients-table td:nth-child(n+4) { display: none; }

  .modal-overlay { padding: 0; }
  .create-modal { max-width: 100%; border-radius: 0; max-height: 100vh; max-height: 100dvh; overflow-y: auto; }
  .modal-body { padding: var(--space-4); }
  .field-row { grid-template-columns: 1fr; }
  .field-input { height: 42px; }
  .btn-primary, .btn-secondary { height: 44px; font-size: 0.9rem; }
}
</style>
