<template>
  <div class="ai-layout">
    <div class="page-header">
      <div>
        <h1 class="page-title">Arche IA</h1>
        <p class="page-sub">Motor de conocimiento industrial — aprende exclusivamente de tu planta</p>
      </div>
      <div class="header-actions">
        <button v-if="isAdminOrSupervisor" class="btn-secondary"
          :disabled="indexingNodes" @click="indexNodes">
          {{ indexingNodes ? 'Indexando nodos...' : '◈ Indexar Fábrica Virtual' }}
        </button>
        <button v-if="isAdmin" class="btn-secondary"
          :disabled="reindexing" @click="reindexAll">
          {{ reindexing ? 'Reindexando...' : '↺ Reindexar OTs' }}
        </button>
        <button class="btn-primary" @click="aiStore.openChat()">
          Abrir chat ◬
        </button>
      </div>
    </div>

    <!-- Status -->
    <div class="status-grid">
      <div class="status-card" :class="status?.ollama_available ? 'status-card--ok' : 'status-card--error'">
        <div class="status-icon">{{ status?.ollama_available ? '●' : '○' }}</div>
        <div class="status-info">
          <span class="status-label">Motor de IA</span>
          <span class="status-value">{{ status?.ollama_available ? 'Ollama — En línea' : 'No disponible' }}</span>
        </div>
      </div>
      <div class="status-card">
        <div class="status-icon indexed">◈</div>
        <div class="status-info">
          <span class="status-label">Chunks indexados</span>
          <span class="status-value mono">{{ status?.indexed_chunks ?? 0 }}</span>
        </div>
      </div>
      <div class="status-card" :class="(status?.pending_queue ?? 0) > 0 ? 'status-card--warn' : ''">
        <div class="status-icon">◷</div>
        <div class="status-info">
          <span class="status-label">Cola de indexación</span>
          <span class="status-value mono">{{ status?.pending_queue ?? 0 }} pendientes</span>
        </div>
      </div>
      <div class="status-card">
        <div class="status-icon">◬</div>
        <div class="status-info">
          <span class="status-label">Modelos cargados</span>
          <span class="status-value">{{ status?.models?.length ?? 0 }} disponibles</span>
        </div>
      </div>
    </div>

    <!-- Warning when there are no chunks -->
    <div v-if="status && status.ollama_available && status.indexed_chunks === 0" class="card card--info">
      <div class="card-header"><span class="card-title">Primer uso — Indexar el conocimiento</span></div>
      <div class="setup-steps">
        <div class="step">
          <span class="step-num">1</span>
          <div class="step-body">
            <p class="step-title">Indexar la Fábrica Virtual</p>
            <p class="step-desc">Esto permite a la IA conocer todos los equipos de tu planta (nombre, fabricante, criticidad, repuestos...).</p>
            <button class="btn-action" :disabled="indexingNodes" @click="indexNodes">
              {{ indexingNodes ? 'Indexando...' : '◈ Indexar ahora' }}
            </button>
          </div>
        </div>
        <div class="step">
          <span class="step-num">2</span>
          <div class="step-body">
            <p class="step-title">Completar OTs</p>
            <p class="step-desc">Las OTs completadas y cerradas se indexan automáticamente en el sistema de IA.</p>
          </div>
        </div>
        <div class="step">
          <span class="step-num">3</span>
          <div class="step-body">
            <p class="step-title">¡Listo para preguntar!</p>
            <p class="step-desc">La IA ya conocerá tu planta y podrá responder con datos reales.</p>
          </div>
        </div>
      </div>
    </div>

    <!-- Models -->
    <div v-if="status?.models?.length" class="card">
      <div class="card-header"><span class="card-title">Modelos Ollama</span></div>
      <div class="models-list">
        <div v-for="m in status.models" :key="m.name" class="model-row">
          <span class="mono model-name">{{ m.name }}</span>
          <span class="model-size text-muted">{{ formatSize(m.size) }}</span>
        </div>
      </div>
    </div>

    <!-- Setup when Ollama is unavailable -->
    <div v-if="status && !status.ollama_available" class="card card--warn">
      <div class="card-header"><span class="card-title">⚠ Ollama no disponible</span></div>
      <div class="setup-steps">
        <div class="step">
          <span class="step-num">1</span>
          <div class="step-body">
            <p class="step-title">Arrancar Ollama</p>
            <code>sudo systemctl start ollama</code>
          </div>
        </div>
        <div class="step">
          <span class="step-num">2</span>
          <div class="step-body">
            <p class="step-title">Verificar que está corriendo</p>
            <code>curl http://localhost:11434/api/tags</code>
          </div>
        </div>
      </div>
    </div>

    <!-- Knowledge sources -->
    <div class="card">
      <div class="card-header"><span class="card-title">Fuentes de conocimiento</span></div>
      <div class="knowledge-grid">
        <div class="knowledge-item">
          <div class="ki-icon">✦</div>
          <div class="ki-info">
            <span class="ki-title">Informes de reparación</span>
            <span class="ki-desc">OTs completadas y verificadas. Incluye causa raíz, solución y notas del técnico.</span>
            <span class="ki-status ok">Se indexan automáticamente al verificar</span>
          </div>
        </div>
        <div class="knowledge-item">
          <div class="ki-icon">◈</div>
          <div class="ki-info">
            <span class="ki-title">Fábrica Virtual</span>
            <span class="ki-desc">Equipos, fabricantes, modelos, criticidad y repuestos asociados a cada nodo.</span>
            <span class="ki-status ok">Indexar con el botón "Indexar Fábrica Virtual"</span>
          </div>
        </div>
        <div class="knowledge-item">
          <div class="ki-icon">⧉</div>
          <div class="ki-info">
            <span class="ki-title">Plantillas de equipo</span>
            <span class="ki-desc">El conocimiento se comparte entre máquinas del mismo modelo automáticamente.</span>
            <span class="ki-status ok">Activo — compartido por modelo</span>
          </div>
        </div>
        <div class="knowledge-item">
          <div class="ki-icon">◎</div>
          <div class="ki-info">
            <span class="ki-title">Solo datos verificados</span>
            <span class="ki-desc">Los informes sin verificar no entran al índice. La calidad la controla el supervisor.</span>
            <span class="ki-status ok">Garantizado por el pipeline de verificación</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Recent conversations -->
    <div class="card">
      <div class="card-header">
        <span class="card-title">Mis conversaciones recientes</span>
        <button class="card-link-btn" @click="aiStore.openChat()">Nueva conversación</button>
      </div>
      <div v-if="!aiStore.conversations.length" class="card-empty">No hay conversaciones aún.</div>
      <div v-else class="convs-list">
        <div v-for="conv in aiStore.conversations" :key="conv.id" class="conv-row"
          @click="openConv(conv)">
          <div class="conv-info">
            <span class="conv-title">{{ conv.title ?? 'Conversación sin título' }}</span>
            <span v-if="conv.node_name" class="conv-node text-muted">{{ conv.node_name }}</span>
          </div>
          <div class="conv-meta">
            <span class="conv-date text-muted">{{ formatDate(conv.updated_at) }}</span>
            <button class="conv-del" @click.stop="aiStore.deleteConversation(conv.id)">✕</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useToast } from '@/composables/useToast'
const toast = useToast()
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useAIStore } from '@/stores/ai'
import { useAuthStore } from '@/stores/auth'
import { aiApi } from '@/api/ai'
import client from '@/api/client'

const aiStore    = useAIStore()
const authStore  = useAuthStore()
const isAdmin    = computed(() => authStore.isAdmin)
const isAdminOrSupervisor = computed(() => authStore.isManager)
const status     = computed(() => aiStore.status)
const reindexing = ref(false)
const indexingNodes = ref(false)
let indexTimer: number | undefined

onUnmounted(() => {
  if (indexTimer) clearTimeout(indexTimer)
})

async function indexNodes() {
  indexingNodes.value = true
  try {
    const result = await client.post('/ai/index-nodes').then(r => r.data)
    toast.error(result.message + '\n\nEspera unos minutos y recarga la página para ver los chunks indexados.')
    indexTimer = window.setTimeout(() => aiStore.loadStatus(), 30000)
  } catch (err: unknown) {
    toast.fromError(err, 'Error indexando nodos')
  } finally { indexingNodes.value = false }
}

async function reindexAll() {
  if (!confirm('¿Reindexar todas las OTs verificadas?')) return
  reindexing.value = true
  try {
    const result = await aiApi.reindexAll()
    toast.error(result.message)
    await aiStore.loadStatus()
  } catch (err: unknown) {
    toast.fromError(err, 'Error reindexando')
  } finally { reindexing.value = false }
}

async function openConv(conv: any) {
  await aiStore.loadConversation(conv.id)
  aiStore.openChat(conv.node_id, conv.node_name)
}

function formatSize(bytes: number) {
  if (!bytes) return '—'
  return (bytes / 1024 / 1024 / 1024).toFixed(1) + ' GB'
}

function formatDate(iso: string) {
  try {
    return new Date(iso).toLocaleDateString('es-ES', {
      day: '2-digit', month: '2-digit', year: 'numeric',
      hour: '2-digit', minute: '2-digit'
    })
  } catch { return iso }
}

onMounted(async () => {
  await aiStore.loadStatus()
  await aiStore.loadConversations()
})
</script>

<style scoped>
.ai-layout { display: flex; flex-direction: column; gap: var(--space-6); max-width: 900px; }
.page-header { display: flex; align-items: flex-start; justify-content: space-between; }
.page-title { font-size: 1.4rem; font-weight: 700; color: var(--color-primary); }
.page-sub { font-size: 0.8rem; color: var(--color-text-muted); }
.header-actions { display: flex; gap: var(--space-3); flex-wrap: wrap; }
.status-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: var(--space-4); }
.status-card { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); padding: var(--space-4); display: flex; align-items: center; gap: var(--space-3); }
.status-card--ok { border-color: rgba(39,174,96,0.3); background: rgba(39,174,96,0.03); }
.status-card--error { border-color: rgba(233,69,96,0.3); background: rgba(233,69,96,0.03); }
.status-card--warn { border-color: rgba(243,156,18,0.3); background: rgba(243,156,18,0.03); }
.status-icon { font-size: 1.1rem; flex-shrink: 0; }
.status-icon.indexed { color: var(--color-accent); }
.status-info { display: flex; flex-direction: column; gap: 2px; }
.status-label { font-size: 0.68rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); }
.status-value { font-size: 0.82rem; font-weight: 500; color: var(--color-text); }
.card { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); overflow: hidden; }
.card--warn { border-color: rgba(243,156,18,0.3); }
.card--info { border-color: rgba(59,130,246,0.3); background: rgba(59,130,246,0.02); }
.card-header { display: flex; align-items: center; justify-content: space-between; padding: var(--space-4) var(--space-5); border-bottom: 1px solid var(--color-border-light); }
.card-title { font-size: 0.78rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--color-text-muted); }
.card-link-btn { font-size: 0.75rem; color: var(--color-accent); background: none; border: none; cursor: pointer; }
.card-link-btn:hover { text-decoration: underline; }
.card-empty { padding: var(--space-5); text-align: center; font-size: 0.875rem; color: var(--color-text-muted); }
.models-list { padding: var(--space-3) var(--space-5); display: flex; flex-direction: column; gap: var(--space-2); }
.model-row { display: flex; align-items: center; justify-content: space-between; padding: var(--space-2) 0; border-bottom: 1px solid var(--color-border-light); }
.model-row:last-child { border-bottom: none; }
.model-name { font-size: 0.82rem; }
.model-size { font-size: 0.75rem; }
.setup-steps { display: flex; flex-direction: column; gap: var(--space-4); padding: var(--space-5); }
.step { display: flex; gap: var(--space-4); align-items: flex-start; }
.step-num { width: 24px; height: 24px; background: var(--color-primary); color: #fff; border-radius: 50%; font-size: 0.75rem; font-weight: 700; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.step-body { flex: 1; }
.step-title { font-size: 0.875rem; font-weight: 500; color: var(--color-text); margin-bottom: var(--space-1); display: block; }
.step-desc { font-size: 0.8rem; color: var(--color-text-muted); display: block; margin-bottom: var(--space-2); line-height: 1.5; }
.step-body code { display: block; font-family: var(--font-mono); font-size: 0.82rem; background: var(--color-surface-2); border: 1px solid var(--color-border-light); border-radius: var(--radius); padding: var(--space-2) var(--space-3); color: var(--color-accent); }
.knowledge-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 0; }
.knowledge-item { display: flex; gap: var(--space-3); padding: var(--space-4) var(--space-5); border-bottom: 1px solid var(--color-border-light); border-right: 1px solid var(--color-border-light); }
.knowledge-item:nth-child(2n) { border-right: none; }
.knowledge-item:nth-last-child(-n+2) { border-bottom: none; }
.ki-icon { font-size: 1.2rem; flex-shrink: 0; margin-top: 2px; color: var(--color-accent); }
.ki-info { display: flex; flex-direction: column; gap: var(--space-1); }
.ki-title { font-size: 0.875rem; font-weight: 600; color: var(--color-text); }
.ki-desc { font-size: 0.78rem; color: var(--color-text-muted); line-height: 1.5; }
.ki-status { font-size: 0.68rem; font-weight: 600; color: var(--color-text-light); }
.ki-status.ok { color: var(--color-success); }
.convs-list { display: flex; flex-direction: column; }
.conv-row { display: flex; align-items: center; justify-content: space-between; padding: var(--space-3) var(--space-5); border-bottom: 1px solid var(--color-border-light); cursor: pointer; transition: background var(--transition); }
.conv-row:last-child { border-bottom: none; }
.conv-row:hover { background: var(--color-surface-2); }
.conv-info { display: flex; flex-direction: column; gap: 2px; }
.conv-title { font-size: 0.875rem; font-weight: 500; }
.conv-node { font-size: 0.72rem; }
.conv-meta { display: flex; align-items: center; gap: var(--space-3); }
.conv-date { font-size: 0.72rem; }
.conv-del { background: none; border: none; color: var(--color-text-light); cursor: pointer; font-size: 0.8rem; padding: 2px 4px; border-radius: 3px; }
.conv-del:hover { color: var(--color-alert); background: rgba(233,69,96,0.08); }
.btn-primary { height: 38px; padding: 0 var(--space-5); background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); font-size: 0.875rem; font-weight: 500; cursor: pointer; }
.btn-primary:hover { background: var(--color-accent); }
.btn-secondary { height: 38px; padding: 0 var(--space-5); background: var(--color-surface); color: var(--color-text); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; cursor: pointer; }
.btn-secondary:hover:not(:disabled) { background: var(--color-surface-2); }
.btn-secondary:disabled { opacity: 0.5; cursor: not-allowed; }
.btn-action { height: 32px; padding: 0 var(--space-4); background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); font-size: 0.8rem; font-weight: 500; cursor: pointer; margin-top: var(--space-2); }
.btn-action:hover:not(:disabled) { background: var(--color-accent); }
.btn-action:disabled { opacity: 0.5; cursor: not-allowed; }
.mono { font-family: var(--font-mono); }
.text-muted { color: var(--color-text-muted); }

@media (max-width: 768px) {
  .page-header { flex-direction: column; gap: 12px; }
  .header-actions { width: 100%; }
  .status-grid { grid-template-columns: repeat(2, 1fr); }
  .knowledge-grid { grid-template-columns: 1fr; }
  .knowledge-item { border-right: none; }
}
</style>
