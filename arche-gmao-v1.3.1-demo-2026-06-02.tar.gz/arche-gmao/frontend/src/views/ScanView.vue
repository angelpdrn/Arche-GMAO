<template>
  <div class="scan-wrap">
    <!-- Loading -->
    <div v-if="loading" class="scan-card">
      <div class="scan-spinner"></div>
      <p class="scan-msg">Cargando equipo...</p>
    </div>

    <!-- Not found -->
    <div v-else-if="notFound" class="scan-card">
      <div class="scan-icon">&#x25B3;</div>
      <h2 class="scan-title">Equipo no encontrado</h2>
      <p class="scan-msg">El código QR no corresponde a ningún equipo registrado.</p>
      <p class="scan-code">Código: {{ code }}</p>
    </div>

    <!-- Found but not authenticated -->
    <div v-else-if="!authenticated" class="scan-card">
      <div class="scan-icon">&#x25C6;</div>
      <h2 class="scan-title">{{ isComposition ? 'Composición identificada' : 'Equipo identificado' }}</h2>
      <p class="scan-msg">Para ver la ficha completa, inicia sesión en Arche GMAO.</p>
      <button class="scan-btn" @click="goLogin">Iniciar sesión</button>
    </div>

    <!-- Authenticated: node card -->
    <div v-else-if="!isComposition" class="scan-full">
      <div class="scan-header">
        <div class="scan-header-logo">ARCHE</div>
        <div class="scan-header-sub">SYSTEM &middot; MANTENIMIENTO</div>
      </div>

      <div class="scan-section">
        <div class="node-name">{{ node.name }}</div>
        <div class="node-code-label">{{ node.code }}</div>
        <div class="badges">
          <span class="badge" :style="{ background: statusColor }">{{ statusLabel }}</span>
          <span class="badge" :style="{ background: critColor }">Criticidad: {{ critLabel }}</span>
          <span class="badge badge--type">{{ typeLabel }}</span>
        </div>
      </div>

      <!-- Active WOs -->
      <div class="scan-section">
        <div class="section-title">OTs activas</div>
        <div v-if="!activeWOs.length" class="section-empty">Sin OTs activas</div>
        <div v-else class="wo-list">
          <div v-for="wo in activeWOs" :key="wo.wo_number" class="wo-row">
            <span class="wo-num">{{ wo.wo_number }}</span>
            <span class="wo-title">{{ wo.title }}</span>
            <span class="wo-prio" :style="{ background: prioColor(wo.priority) }">{{ wo.priority }}</span>
          </div>
        </div>
      </div>

      <!-- Maintenance -->
      <div class="scan-section">
        <div class="section-title">Mantenimiento</div>
        <div class="maint-row">
          <span class="maint-label">Ultimo mantenimiento</span>
          <span v-if="lastMaint.wo_number">{{ lastMaint.wo_number }} ({{ formatDate(lastMaint.date) }})</span>
          <span v-else class="text-muted">Sin registros</span>
        </div>
        <div class="maint-row">
          <span class="maint-label">Proximo mantenimiento</span>
          <span v-if="nextMaint.title">{{ nextMaint.title }} — {{ formatDate(nextMaint.date) }}</span>
          <span v-else class="text-muted">Sin plan configurado</span>
        </div>
      </div>

      <!-- Compositions -->
      <div v-if="compositions.length" class="scan-section">
        <div class="section-title">Composiciones</div>
        <div v-for="comp in compositions" :key="comp.id" class="comp-row">
          <span class="comp-name">{{ comp.name }}</span>
        </div>
      </div>

      <!-- Actions -->
      <div class="scan-section scan-actions">
        <button class="scan-btn scan-btn--primary" @click="goToNode">Ir al equipo</button>
        <button class="scan-btn scan-btn--alert" @click="goReport">Reportar averia</button>
      </div>
    </div>

    <!-- Authenticated: composition -->
    <div v-else-if="isComposition && authenticated" class="scan-full">
      <div class="scan-header">
        <div class="scan-header-logo">ARCHE</div>
        <div class="scan-header-sub">SYSTEM &middot; COMPOSICION</div>
      </div>

      <div class="scan-section">
        <div class="node-name">{{ composition.name }}</div>
        <div v-if="composition.description" class="node-code-label">{{ composition.description }}</div>
        <div class="badges">
          <span class="badge badge--type">Composición</span>
        </div>
      </div>

      <div class="scan-section">
        <div class="section-title">Miembros ({{ members.length }})</div>
        <div v-if="!members.length" class="section-empty">Sin miembros</div>
        <div v-else class="wo-list">
          <div v-for="m in members" :key="m.node_id" class="wo-row">
            <span class="wo-num">{{ m.node_code || m.node_id }}</span>
            <span class="wo-title">{{ m.node_name }}</span>
            <span v-if="m.role" class="wo-prio" style="background:#0f3460">{{ m.role }}</span>
          </div>
        </div>
      </div>

      <div class="scan-section scan-actions">
        <button class="scan-btn scan-btn--primary" @click="goToFactory">Ver en fábrica</button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import client from '@/api/client'
import axios from 'axios'

const route = useRoute()
const router = useRouter()
const authStore = useAuthStore()

const code = route.params.code as string
const loading = ref(true)
const notFound = ref(false)
const authenticated = ref(false)
const isComposition = ref(false)
const node = ref<any>({})
const activeWOs = ref<any[]>([])
const lastMaint = ref<any>({})
const nextMaint = ref<any>({})
const compositions = ref<any[]>([])
const composition = ref<any>({})
const members = ref<any[]>([])

const statusMap: Record<string, { color: string; label: string }> = {
  active: { color: 'var(--color-success, #27AE60)', label: 'Operativo' },
  maintenance: { color: 'var(--color-warning, #F39C12)', label: 'En mantenimiento' },
  inactive: { color: 'var(--color-text-muted, #888)', label: 'Inactivo' },
  decommissioned: { color: 'var(--color-alert, #E94560)', label: 'Desmantelado' },
}
const critMap: Record<string, { color: string; label: string }> = {
  low: { color: 'var(--color-success, #27AE60)', label: 'Baja' },
  medium: { color: 'var(--color-warning, #F39C12)', label: 'Media' },
  high: { color: '#E67E22', label: 'Alta' },
  critical: { color: 'var(--color-alert, #E94560)', label: 'Critica' },
}
const typeMap: Record<string, string> = {
  equipment: 'Equipo', component: 'Componente', line: 'Linea',
  area: 'Área', plant: 'Planta', organization: 'Organización', measurement_point: 'Punto de medida',
}

const statusColor = computed(() => statusMap[node.value.status]?.color ?? '#888')
const statusLabel = computed(() => statusMap[node.value.status]?.label ?? node.value.status)
const critColor = computed(() => critMap[node.value.criticality]?.color ?? '#888')
const critLabel = computed(() => critMap[node.value.criticality]?.label ?? node.value.criticality)
const typeLabel = computed(() => typeMap[node.value.node_type] ?? node.value.node_type)

function prioColor(p: string) {
  return { critical: 'var(--color-alert, #E94560)', high: '#E67E22', medium: 'var(--color-warning, #F39C12)', low: 'var(--color-success, #27AE60)' }[p] ?? 'var(--color-text-muted, #888)'
}

function formatDate(d: string | null) {
  if (!d) return '—'
  return d.length >= 10 ? d.substring(0, 10) : d
}

function goLogin() {
  router.push({ name: 'login', query: { redirect: `/scan/${encodeURIComponent(code)}` } })
}

function goToNode() {
  router.push({ name: 'factory', query: { scan: node.value.code || node.value.id } })
}

function goReport() {
  router.push({ path: '/work-orders', query: { new: '1', node: String(node.value.id) } })
}

function goToFactory() {
  router.push({ name: 'factory' })
}

onMounted(async () => {
  // Make sure auth is initialized (init() is idempotent)
  await authStore.init()

  try {
    const { data } = await client.get(`/scan/${encodeURIComponent(code)}`)

    if (!data.found) {
      notFound.value = true
      return
    }

    if (!data.authenticated) {
      // API says found but not authenticated — redirect to login
      authenticated.value = false
      isComposition.value = data.type === 'composition'
      return
    }

    authenticated.value = true

    if (data.type === 'composition') {
      isComposition.value = true
      composition.value = data.composition ?? {}
      members.value = data.members ?? []
    } else {
      // Full node data
      node.value = data.node ?? {}
      activeWOs.value = data.active_wos ?? []
      lastMaint.value = data.last_maintenance ?? {}
      nextMaint.value = data.next_maintenance ?? {}
      compositions.value = data.compositions ?? []
    }
  } catch (err: unknown) {
    if (err?.response?.status === 401 || !authStore.isAuthenticated) {
      // Not logged in — show login prompt
      // But first check if the node exists (unauthenticated call)
      // Anonymous call (no auth) to detect whether the node exists.
      // We use axios without the intercepting client, so we do not fall into
      // refresh loops precisely while unauthenticated.
      try {
        const { data: d } = await axios.get(`/api/v1/scan/${encodeURIComponent(code)}`)
        if (d?.found) {
          authenticated.value = false
        } else {
          notFound.value = true
        }
      } catch {
        notFound.value = true
      }
    } else {
      notFound.value = true
    }
  } finally {
    loading.value = false
  }
})
</script>

<style scoped>
.scan-wrap {
  min-height: 100vh;
  min-height: 100dvh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--color-bg, #f0f2f5);
  padding: 16px;
}

/* ─── Generic card (loading, login, error) ──────────────────── */
.scan-card {
  background: #fff;
  border-radius: 12px;
  padding: 32px;
  text-align: center;
  max-width: 360px;
  width: 100%;
  box-shadow: 0 4px 20px rgba(0,0,0,0.1);
}
.scan-icon { font-size: 3rem; margin-bottom: 16px; color: var(--color-accent, #0f3460); }
.scan-title { font-size: 1.2rem; font-weight: 700; color: var(--color-primary, #1a1a2e); margin-bottom: 8px; }
.scan-msg { font-size: 0.9rem; color: #666; margin-bottom: 16px; line-height: 1.4; }
.scan-code { font-family: monospace; font-size: 0.8rem; background: #f0f0f0; padding: 4px 8px; border-radius: 4px; display: inline-block; }
.scan-spinner { width: 40px; height: 40px; border: 3px solid var(--color-border, #e5e7eb); border-top-color: var(--color-accent, #0f3460); border-radius: 50%; animation: spin 0.8s linear infinite; margin: 0 auto 16px; }
@keyframes spin { to { transform: rotate(360deg); } }

/* ─── Buttons ────────────────────────────────────────────────── */
.scan-btn {
  display: inline-block;
  background: var(--color-accent, #0F3460);
  color: #fff;
  padding: 12px 28px;
  border-radius: 8px;
  text-decoration: none;
  font-weight: 600;
  font-size: 0.95rem;
  border: none;
  cursor: pointer;
  min-height: 44px;
}
.scan-btn:active { background: var(--color-primary, #1a1a2e); }
.scan-btn--primary { background: var(--color-accent, #0F3460); flex: 1; }
.scan-btn--alert { background: var(--color-alert, #E94560); flex: 1; }
.scan-btn--alert:active { background: #c0392b; }

/* ─── Full view (authenticated) ───────────────────────────── */
.scan-full {
  width: 100%;
  max-width: 480px;
  background: #fff;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 4px 20px rgba(0,0,0,0.1);
}
.scan-header {
  background: var(--color-accent, #0f3460);
  color: #fff;
  padding: 16px 20px;
}
.scan-header-logo { font-size: 1.2rem; font-weight: 900; letter-spacing: 3px; }
.scan-header-sub { font-size: 0.7rem; opacity: 0.6; letter-spacing: 1px; }

.scan-section {
  padding: 16px 20px;
  border-bottom: 1px solid #f0f0f0;
}
.scan-section:last-child { border-bottom: none; }

.node-name { font-size: 1.15rem; font-weight: 700; color: var(--color-accent, #0f3460); line-height: 1.3; }
.node-code-label { font-family: monospace; font-size: 0.75rem; color: #888; margin: 4px 0 12px; }

.badges { display: flex; flex-wrap: wrap; gap: 6px; }
.badge { font-size: 0.7rem; font-weight: 700; padding: 3px 10px; border-radius: 20px; color: #fff; }
.badge--type { background: var(--color-accent, #0f3460); }

.section-title {
  font-size: 0.7rem;
  font-weight: 700;
  text-transform: uppercase;
  color: #888;
  letter-spacing: 0.5px;
  border-bottom: 1px solid #f0f0f0;
  padding-bottom: 6px;
  margin-bottom: 10px;
}
.section-empty { font-size: 0.85rem; color: #888; text-align: center; padding: 8px 0; }

/* WOs */
.wo-list { display: flex; flex-direction: column; }
.wo-row { display: flex; align-items: center; gap: 8px; padding: 8px 0; border-bottom: 1px solid #f8f8f8; flex-wrap: wrap; }
.wo-num { font-family: monospace; font-size: 0.75rem; color: var(--color-accent, #0f3460); font-weight: 600; }
.wo-title { font-size: 0.82rem; flex: 1; min-width: 80px; }
.wo-prio { font-size: 0.65rem; font-weight: 700; color: #fff; padding: 2px 6px; border-radius: 10px; }

/* Maintenance */
.maint-row { padding: 6px 0; border-bottom: 1px solid #f8f8f8; font-size: 0.85rem; display: flex; flex-direction: column; gap: 2px; }
.maint-row:last-child { border-bottom: none; }
.maint-label { font-size: 0.68rem; color: #888; }

/* Compositions */
.comp-row { padding: 6px 0; border-bottom: 1px solid #f8f8f8; font-size: 0.85rem; }
.comp-row:last-child { border-bottom: none; }
.comp-name { font-weight: 500; color: var(--color-accent, #0f3460); }

.text-muted { color: #888; }

/* Actions */
.scan-actions {
  display: flex;
  gap: 12px;
  padding: 16px 20px;
}

/* ─── Responsive ─────────────────────────────────────────────── */
@media (max-width: 480px) {
  .scan-wrap { padding: 0; align-items: flex-start; }
  .scan-full { max-width: 100%; border-radius: 0; min-height: 100vh; min-height: 100dvh; }
  .scan-card { border-radius: 0; max-width: 100%; min-height: 100vh; min-height: 100dvh; display: flex; flex-direction: column; align-items: center; justify-content: center; }
  .scan-actions { flex-direction: column; }
  .scan-btn { width: 100%; text-align: center; }
}
</style>
