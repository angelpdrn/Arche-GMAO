<template>
  <div class="metrics-layout">
    <!-- Header -->
    <div class="page-header">
      <div>
        <h1 class="page-title">Métricas y KPIs</h1>
        <p class="page-sub">Indicadores de rendimiento del sistema de mantenimiento</p>
      </div>
      <div class="header-controls">
        <select v-if="nodes.length" class="node-filter" v-model="selectedNodeId">
          <option :value="null">Toda la fábrica</option>
          <option v-for="n in nodes" :key="n.id" :value="n.id">
            {{ '\u00A0'.repeat(n.depth * 2) }}{{ n.name }}
          </option>
        </select>
        <div class="period-tabs">
          <button v-for="(label, key) in PERIOD_LABELS" :key="key"
            class="period-tab" :class="{ 'period-tab--active': period === key }"
            @click="setPeriod(key as Period)">
            {{ label }}
          </button>
        </div>
      </div>
    </div>

    <div v-if="loading" class="loading-state">Cargando métricas...</div>

    <template v-else>
      <!-- ─── Main KPIs ─────────────────────────────────────────────── -->
      <div class="kpi-grid">
        <div class="kpi-card">
          <div class="kpi-icon kpi-icon--blue">✦</div>
          <div class="kpi-data">
            <span class="kpi-value">{{ summary?.total_wos ?? 0 }}</span>
            <span class="kpi-label">OTs totales</span>
          </div>
          <div class="kpi-breakdown">
            <span class="kpi-sub kpi-sub--alert">{{ summary?.corrective_wos ?? 0 }} correctivas</span>
            <span class="kpi-sub kpi-sub--ok">{{ summary?.preventive_wos ?? 0 }} preventivas</span>
          </div>
        </div>

        <div class="kpi-card" :class="{ 'kpi-card--alert': (summary?.overdue_wos ?? 0) > 0 }">
          <div class="kpi-icon kpi-icon--orange">◷</div>
          <div class="kpi-data">
            <span class="kpi-value" :class="{ 'text-alert': (summary?.overdue_wos ?? 0) > 0 }">
              {{ summary?.overdue_wos ?? 0 }}
            </span>
            <span class="kpi-label">OTs vencidas</span>
          </div>
          <div class="kpi-breakdown">
            <span class="kpi-sub">{{ summary?.pending_wos ?? 0 }} pendientes</span>
          </div>
        </div>

        <div class="kpi-card">
          <div class="kpi-icon kpi-icon--green">◉</div>
          <div class="kpi-data">
            <span class="kpi-value">{{ summary?.avg_resolution_hours?.toFixed(1) ?? '—' }}h</span>
            <span class="kpi-label">MTTR medio</span>
          </div>
          <div class="kpi-breakdown">
            <span class="kpi-sub">Tiempo medio de reparación</span>
          </div>
        </div>

        <div class="kpi-card" :class="{ 'kpi-card--alert': (summary?.low_stock_parts ?? 0) > 0 }">
          <div class="kpi-icon kpi-icon--red">◫</div>
          <div class="kpi-data">
            <span class="kpi-value" :class="{ 'text-alert': (summary?.low_stock_parts ?? 0) > 0 }">
              {{ summary?.low_stock_parts ?? 0 }}
            </span>
            <span class="kpi-label">Stock bajo</span>
          </div>
          <div class="kpi-breakdown">
            <span class="kpi-sub">{{ summary?.active_alerts ?? 0 }} alertas activas</span>
          </div>
        </div>

        <div class="kpi-card">
          <div class="kpi-icon kpi-icon--purple">◬</div>
          <div class="kpi-data">
            <span class="kpi-value">{{ summary?.verif_pending ?? 0 }}</span>
            <span class="kpi-label">Verificaciones pendientes</span>
          </div>
          <div class="kpi-breakdown">
            <span class="kpi-sub">Sin aprobar por supervisor</span>
          </div>
        </div>

        <div class="kpi-card">
          <div class="kpi-icon kpi-icon--green">€</div>
          <div class="kpi-data">
            <span class="kpi-value">{{ formatCost(summary?.estimated_cost_mtto ?? 0) }}</span>
            <span class="kpi-label">Coste estimado en materiales</span>
          </div>
          <div class="kpi-breakdown">
            <span class="kpi-sub">{{ summary?.completed_wos ?? 0 }} OTs completadas</span>
          </div>
        </div>
      </div>

      <!-- ─── Global corrective/preventive ratio ───────────────────────────── -->
      <div class="ratio-banner" v-if="correctiveRatio">
        <div class="ratio-info">
          <span class="ratio-label">Ratio correctivo / preventivo global</span>
          <span class="ratio-value" :class="correctiveRatio.global_ratio > 60 ? 'text-alert' : correctiveRatio.global_ratio > 40 ? 'text-warning' : 'text-ok'">
            {{ correctiveRatio.global_ratio?.toFixed(1) ?? '—' }}% correctivo
          </span>
        </div>
        <div class="ratio-bar-wrap">
          <div class="ratio-bar">
            <div class="ratio-fill ratio-fill--corrective"
              :style="{ width: correctiveRatio.global_ratio + '%' }">
            </div>
          </div>
          <div class="ratio-bar-labels">
            <span>Correctivo: {{ correctiveRatio.global_corrective }}</span>
            <span>Preventivo: {{ correctiveRatio.global_preventive }}</span>
          </div>
        </div>
        <div class="ratio-hint">
          <template v-if="correctiveRatio.global_ratio > 60">⚠ Alto ratio correctivo — revisar plan de mantenimiento preventivo</template>
          <template v-else-if="correctiveRatio.global_ratio > 40">La distribución es aceptable pero mejorable</template>
          <template v-else>✓ Buen balance — mantenimiento preventivo dominante</template>
        </div>
      </div>

      <!-- ─── Equipment health ──────────────────────────────────────────────── -->
      <div v-if="healthSummary" class="health-overview">
        <div class="health-overview-header">
          <span class="card-title">Salud de equipos</span>
          <button class="btn-ghost btn-sm" @click="recalcHealth" :disabled="recalculating">
            {{ recalculating ? 'Recalculando...' : 'Recalcular' }}
          </button>
        </div>
        <div class="health-dist-bar">
          <div v-if="healthDist.excellent" class="hdist hdist--excellent" :style="{ flex: healthDist.excellent }" :title="'Excelente: ' + healthDist.excellent">{{ healthDist.excellent }}</div>
          <div v-if="healthDist.good" class="hdist hdist--good" :style="{ flex: healthDist.good }" :title="'Bueno: ' + healthDist.good">{{ healthDist.good }}</div>
          <div v-if="healthDist.fair" class="hdist hdist--fair" :style="{ flex: healthDist.fair }" :title="'Regular: ' + healthDist.fair">{{ healthDist.fair }}</div>
          <div v-if="healthDist.poor" class="hdist hdist--poor" :style="{ flex: healthDist.poor }" :title="'Pobre: ' + healthDist.poor">{{ healthDist.poor }}</div>
          <div v-if="healthDist.critical" class="hdist hdist--critical" :style="{ flex: healthDist.critical }" :title="'Crítico: ' + healthDist.critical">{{ healthDist.critical }}</div>
        </div>
        <div class="health-dist-legend">
          <span class="hleg"><span class="hleg-dot" style="background:#27AE60"></span> Excelente {{ healthDist.excellent }}</span>
          <span class="hleg"><span class="hleg-dot" style="background:#6BCB77"></span> Bueno {{ healthDist.good }}</span>
          <span class="hleg"><span class="hleg-dot" style="background:#E6A817"></span> Regular {{ healthDist.fair }}</span>
          <span class="hleg"><span class="hleg-dot" style="background:#E67E22"></span> Pobre {{ healthDist.poor }}</span>
          <span class="hleg"><span class="hleg-dot" style="background:#E94560"></span> Crítico {{ healthDist.critical }}</span>
        </div>
        <div v-if="healthNodes.length" class="health-nodes-list">
          <div v-for="hn in healthNodes.slice(0, 10)" :key="hn.id" class="health-node-row">
            <span class="health-node-name">{{ hn.name }}</span>
            <span class="health-node-type">{{ hn.node_type }}</span>
            <div class="health-node-bar-wrap">
              <div class="health-node-bar">
                <div class="health-node-fill" :style="{ width: (hn.health_score ?? 0) + '%', background: healthColor(hn.health_score) }"></div>
              </div>
            </div>
            <span class="health-node-score mono" :style="{ color: healthColor(hn.health_score) }">{{ hn.health_score !== null ? Math.round(hn.health_score) : '—' }}</span>
          </div>
        </div>
      </div>

      <!-- ─── Main grid ───────────────────────────────────────────────── -->
      <div class="main-grid">

        <!-- WO trend (chart) -->
        <div class="card card--wide">
          <div class="card-header">
            <span class="card-title">Evolución de OTs — últimos 12 meses</span>
          </div>
          <div class="chart-wrap">
            <canvas ref="trendsCanvas" height="200"></canvas>
          </div>
        </div>

        <!-- MTBF/MTTR per equipment item -->
        <div class="card">
          <div class="card-header">
            <span class="card-title">MTBF / MTTR por equipo</span>
            <span class="card-hint">Top equipos con más averías</span>
          </div>
          <div v-if="!equipmentMetrics.length" class="card-empty">Sin datos suficientes aún.</div>
          <div v-else class="equipment-list">
            <div class="equipment-header-row">
              <span>Equipo</span>
              <span class="text-right">Averías</span>
              <span class="text-right">MTTR</span>
              <span class="text-right">MTBF</span>
              <span class="text-right">Disponib.</span>
            </div>
            <div v-for="m in equipmentMetrics" :key="m.node_id" class="equipment-row">
              <div class="equip-name-col">
                <span class="equip-name">{{ m.node_name }}</span>
                <span class="crit-dot" :style="{ background: CRIT_COLORS[m.criticality] }"></span>
              </div>
              <span class="metric-val text-right">{{ m.total_failures }}</span>
              <span class="metric-val text-right mono">{{ m.mttr_hours ? m.mttr_hours.toFixed(1) + 'h' : '—' }}</span>
              <span class="metric-val text-right mono">{{ m.mtbf_days ? m.mtbf_days.toFixed(1) + 'd' : '—' }}</span>
              <span class="metric-val text-right" :class="availabilityClass(m.availability_pct)">
                {{ m.availability_pct ? m.availability_pct.toFixed(1) + '%' : '—' }}
              </span>
            </div>
          </div>
        </div>

        <!-- Technician performance -->
        <div class="card">
          <div class="card-header">
            <span class="card-title">Rendimiento de técnicos</span>
          </div>
          <div v-if="!technicians.length" class="card-empty">Sin asignaciones en este período.</div>
          <div v-else class="tech-list">
            <div class="tech-header-row">
              <span>Técnico</span>
              <span class="text-right">Asignadas</span>
              <span class="text-right">Completadas</span>
              <span class="text-right">H. media</span>
            </div>
            <div v-for="t in technicians" :key="t.user_id" class="tech-row">
              <div class="tech-name-col">
                <div class="tech-avatar">{{ t.full_name.charAt(0) }}</div>
                <span class="tech-name">{{ t.full_name }}</span>
              </div>
              <span class="metric-val text-right">{{ t.total_assigned }}</span>
              <span class="metric-val text-right">
                <span class="completion-pill" :class="completionClass(t.completed, t.total_assigned)">
                  {{ t.completed }}/{{ t.total_assigned }}
                </span>
              </span>
              <span class="metric-val text-right mono">{{ t.avg_resolution_hours ? t.avg_resolution_hours.toFixed(1) + 'h' : '—' }}</span>
            </div>
          </div>
        </div>

        <!-- Spare part consumption -->
        <div class="card">
          <div class="card-header">
            <span class="card-title">Repuestos más consumidos</span>
            <span class="card-hint" v-if="totalSparesCost > 0">
              Coste total: {{ formatCost(totalSparesCost) }}
            </span>
          </div>
          <div v-if="!spareParts.length" class="card-empty">Sin consumos en este período.</div>
          <div v-else class="spares-list">
            <div v-for="sp in spareParts.slice(0, 8)" :key="sp.id" class="spare-row">
              <div class="spare-info">
                <span class="spare-name">{{ sp.name }}</span>
                <span class="spare-code mono text-muted">{{ sp.code }}</span>
              </div>
              <div class="spare-stats">
                <span class="spare-consumed mono">{{ sp.consumed }} {{ sp.unit }}</span>
                <span v-if="sp.is_low_stock" class="low-stock-badge">⚠ Stock bajo</span>
              </div>
              <div class="spare-bar-wrap">
                <div class="spare-bar">
                  <div class="spare-bar-fill"
                    :style="{ width: Math.min((sp.consumed / maxConsumed) * 100, 100) + '%',
                              background: sp.is_low_stock ? 'var(--color-alert)' : 'var(--color-accent)' }">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Ratio per equipment item (table) -->
        <div v-if="ratioData.length" class="card card--wide">
          <div class="card-header">
            <span class="card-title">Ratio correctivo/preventivo por equipo</span>
          </div>
          <div class="ratio-table-wrap">
            <table class="ratio-table">
              <thead>
                <tr>
                  <th>Equipo</th>
                  <th>Criticidad</th>
                  <th>Correctivas</th>
                  <th>Preventivas</th>
                  <th>Total</th>
                  <th>Ratio correctivo</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="r in ratioData" :key="r.node_name" class="ratio-row"
                  :class="{ 'ratio-row--alert': r.corrective_ratio > 70 }">
                  <td>{{ r.node_name }}</td>
                  <td><span class="crit-dot" :style="{ background: CRIT_COLORS[r.criticality] }"></span> {{ r.criticality }}</td>
                  <td class="mono text-right">{{ r.corrective }}</td>
                  <td class="mono text-right">{{ r.preventive }}</td>
                  <td class="mono text-right">{{ r.total }}</td>
                  <td>
                    <div class="inline-bar">
                      <div class="inline-bar-fill"
                        :style="{ width: r.corrective_ratio + '%',
                                  background: r.corrective_ratio > 70 ? 'var(--color-alert)' : r.corrective_ratio > 50 ? '#F39C12' : 'var(--color-success)' }">
                      </div>
                    </div>
                    <span class="mono" :class="r.corrective_ratio > 70 ? 'text-alert' : ''">{{ r.corrective_ratio }}%</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </template>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watch, nextTick } from 'vue'
import { metricsApi, PERIOD_LABELS } from '@/api/metrics'
import type { MetricsSummary, EquipmentMetric, TrendPoint, TechMetric, SPMetric, Period } from '@/api/metrics'
import client from '@/api/client'
import { CRIT_COLORS } from '@/types'
import Chart from 'chart.js/auto'
import { healthApi } from '@/api/phase2'
import { healthColor } from '@/types/health'
import type { HealthSummaryNode, HealthDistribution } from '@/types/health'

const period = ref<Period>('month')
const loading = ref(false)

/* ── Node / area filter ─────────────────────────────────────────────── */
interface FilterNode { id: number; name: string; node_type: string; depth: number }
const nodes = ref<FilterNode[]>([])
const selectedNodeId = ref<number | null>(null)

const ALLOWED_NODE_TYPES = new Set(['organization', 'plant', 'area', 'line'])

function flattenTree(items: any[], depth = 0): FilterNode[] {
  const result: FilterNode[] = []
  for (const item of items) {
    if (ALLOWED_NODE_TYPES.has(item.node_type)) {
      result.push({ id: item.id, name: item.name, node_type: item.node_type, depth })
    }
    if (item.children?.length) {
      result.push(...flattenTree(item.children, depth + 1))
    }
  }
  return result
}

async function loadNodes() {
  try {
    const { data } = await client.get('/factory/tree')
    nodes.value = flattenTree(Array.isArray(data) ? data : data.nodes ?? [])
  } catch {
    nodes.value = []
  }
}

const summary = ref<MetricsSummary | null>(null)
const equipmentMetrics = ref<EquipmentMetric[]>([])
const trends = ref<TrendPoint[]>([])
const technicians = ref<TechMetric[]>([])
const spareParts = ref<SPMetric[]>([])
const totalSparesCost = ref(0)
const correctiveRatio = ref<any>(null)
const ratioData = ref<any[]>([])

const trendsCanvas = ref<HTMLCanvasElement | null>(null)
let trendsChart: Chart | null = null


const maxConsumed = computed(() => {
  const vals = spareParts.value.map(s => s.consumed)
  return vals.length > 0 ? Math.max(...vals, 1) : 1
})

async function loadAll() {
  loading.value = true
  try {
    const nid = selectedNodeId.value
    const [sum, equip, trend, tech, sp, ratio] = await Promise.all([
      metricsApi.getSummary(period.value, nid),
      metricsApi.getEquipment({ limit: 10 }),
      metricsApi.getTrends(12),
      metricsApi.getTechnicians(period.value, nid),
      metricsApi.getSpareParts(period.value),
      metricsApi.getCorrectiveRatio(period.value, nid),
    ])

    summary.value = sum
    equipmentMetrics.value = equip.metrics ?? []
    trends.value = trend.trends ?? []
    technicians.value = tech.technicians ?? []
    spareParts.value = sp.spare_parts ?? []
    totalSparesCost.value = sp.total_cost ?? 0
    correctiveRatio.value = ratio
    ratioData.value = ratio.ratios ?? []
  } finally {
    loading.value = false
    await nextTick()
    renderTrendsChart()
  }
}

function setPeriod(p: Period) {
  period.value = p
  loadAll()
}

function renderTrendsChart() {
  if (!trendsCanvas.value || !trends.value.length) return

  if (trendsChart) { trendsChart.destroy(); trendsChart = null }

  const labels = trends.value.map(t => t.month)
  const corrective = trends.value.map(t => t.corrective)
  const preventive = trends.value.map(t => t.preventive)
  const total = trends.value.map(t => t.total)

  trendsChart = new Chart(trendsCanvas.value, {
    type: 'bar',
    data: {
      labels,
      datasets: [
        {
          label: 'Correctivas',
          data: corrective,
          backgroundColor: 'rgba(233,69,96,0.7)',
          borderRadius: 4,
          stack: 'main',
        },
        {
          label: 'Preventivas',
          data: preventive,
          backgroundColor: 'rgba(59,130,246,0.7)',
          borderRadius: 4,
          stack: 'main',
        },
        {
          label: 'Total',
          data: total,
          type: 'line',
          borderColor: 'rgba(15,52,96,0.8)',
          backgroundColor: 'transparent',
          borderWidth: 2,
          pointRadius: 3,
          tension: 0.3,
          yAxisID: 'y',
          stack: undefined,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { position: 'bottom', labels: { font: { size: 11 }, boxWidth: 12 } },
      },
      scales: {
        x: { grid: { display: false }, ticks: { font: { size: 10 } } },
        y: { grid: { color: 'rgba(0,0,0,0.06)' }, ticks: { font: { size: 10 }, stepSize: 1 } },
      },
    },
  })
}

// UI helpers
function availabilityClass(pct: number | null) {
  if (!pct) return ''
  if (pct >= 95) return 'text-ok'
  if (pct >= 85) return 'text-warning'
  return 'text-alert'
}

function completionClass(completed: number, total: number) {
  if (!total) return ''
  const ratio = completed / total
  if (ratio >= 0.9) return 'completion-pill--ok'
  if (ratio >= 0.6) return 'completion-pill--warn'
  return 'completion-pill--alert'
}

function formatCost(val: number) {
  if (!val) return '—'
  return val.toLocaleString('es-ES', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 })
}

// ─── Health Summary ─────────────────────────────────────────────────────────
const healthSummary = ref(false)
const healthNodes = ref<HealthSummaryNode[]>([])
const healthDist = ref<HealthDistribution>({ critical: 0, poor: 0, fair: 0, good: 0, excellent: 0 })
const recalculating = ref(false)

async function loadHealthSummary() {
  try {
    const data = await healthApi.getSummary()
    healthNodes.value = (data.nodes ?? []).sort((a, b) => (a.health_score ?? 999) - (b.health_score ?? 999))
    healthDist.value = data.distribution ?? { critical: 0, poor: 0, fair: 0, good: 0, excellent: 0 }
    healthSummary.value = true
  } catch { healthSummary.value = false }
}

async function recalcHealth() {
  recalculating.value = true
  try {
    await healthApi.recalculate()
    await loadHealthSummary()
  } finally { recalculating.value = false }
}

watch(selectedNodeId, () => loadAll())

onMounted(() => {
  loadNodes()
  loadAll()
  loadHealthSummary()
})
</script>

<style scoped>
.metrics-layout { display: flex; flex-direction: column; gap: var(--space-6); }
.page-header { display: flex; align-items: flex-start; justify-content: space-between; flex-wrap: wrap; gap: var(--space-4); }
.page-title { font-size: 1.4rem; font-weight: 700; color: var(--color-primary); }
.page-sub { font-size: 0.8rem; color: var(--color-text-muted); }
.header-controls { display: flex; align-items: center; gap: var(--space-3); flex-wrap: wrap; }
.loading-state { text-align: center; padding: var(--space-10); color: var(--color-text-muted); }

/* Period tabs */
.period-tabs { display: flex; gap: 0; border: 1px solid var(--color-border); border-radius: var(--radius); overflow: hidden; }
.period-tab { height: 34px; padding: 0 var(--space-4); background: var(--color-surface); border: none; font-size: 0.78rem; color: var(--color-text-muted); cursor: pointer; border-right: 1px solid var(--color-border); transition: all var(--transition); }
.period-tab:last-child { border-right: none; }
.period-tab:hover { background: var(--color-surface-2); color: var(--color-text); }
.period-tab--active { background: var(--color-primary); color: #fff; }

/* KPI Grid */
.kpi-grid { display: grid; grid-template-columns: repeat(6, 1fr); gap: var(--space-4); }
.kpi-card { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); padding: var(--space-4); display: flex; flex-direction: column; gap: var(--space-2); }
.kpi-card--alert { border-color: rgba(233,69,96,0.3); background: rgba(233,69,96,0.02); }
.kpi-icon { font-size: 1.2rem; width: 32px; height: 32px; border-radius: var(--radius-sm); display: flex; align-items: center; justify-content: center; }
.kpi-icon--blue { background: rgba(59,130,246,0.1); color: #3B82F6; }
.kpi-icon--orange { background: rgba(230,126,34,0.1); color: #E67E22; }
.kpi-icon--green { background: rgba(39,174,96,0.1); color: #27AE60; }
.kpi-icon--red { background: rgba(233,69,96,0.1); color: var(--color-alert); }
.kpi-icon--purple { background: rgba(139,92,246,0.1); color: #8B5CF6; }
.kpi-data { display: flex; flex-direction: column; gap: 2px; }
.kpi-value { font-size: 1.6rem; font-weight: 700; font-family: var(--font-mono); color: var(--color-primary); line-height: 1; }
.kpi-label { font-size: 0.72rem; font-weight: 600; color: var(--color-text-muted); }
.kpi-breakdown { display: flex; gap: var(--space-2); flex-wrap: wrap; }
.kpi-sub { font-size: 0.68rem; color: var(--color-text-muted); }
.kpi-sub--alert { color: var(--color-alert); }
.kpi-sub--ok { color: var(--color-success); }
.text-alert { color: var(--color-alert) !important; }
.text-warning { color: #F39C12 !important; }
.text-ok { color: var(--color-success) !important; }

/* Ratio banner */
.ratio-banner { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); padding: var(--space-5); display: grid; grid-template-columns: auto 1fr auto; gap: var(--space-5); align-items: center; }
.ratio-info { display: flex; flex-direction: column; gap: var(--space-1); }
.ratio-label { font-size: 0.72rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--color-text-muted); }
.ratio-value { font-size: 1.1rem; font-weight: 700; font-family: var(--font-mono); }
.ratio-bar-wrap { flex: 1; display: flex; flex-direction: column; gap: var(--space-2); }
.ratio-bar { height: 12px; background: rgba(39,174,96,0.2); border-radius: 6px; overflow: hidden; }
.ratio-fill--corrective { height: 100%; background: var(--color-alert); border-radius: 6px; transition: width 0.5s ease; }
.ratio-bar-labels { display: flex; justify-content: space-between; font-size: 0.72rem; color: var(--color-text-muted); }
.ratio-hint { font-size: 0.78rem; color: var(--color-text-muted); white-space: nowrap; }

/* Main grid */
.main-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: var(--space-4); }
.card { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); overflow: hidden; }
.card--wide { grid-column: span 2; }
.card-header { display: flex; align-items: center; justify-content: space-between; padding: var(--space-4) var(--space-5); border-bottom: 1px solid var(--color-border-light); }
.card-title { font-size: 0.78rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--color-text-muted); }
.card-hint { font-size: 0.72rem; color: var(--color-text-muted); }
.card-empty { padding: var(--space-8); text-align: center; font-size: 0.875rem; color: var(--color-text-muted); }
.chart-wrap { padding: var(--space-4); height: 240px; }

/* Equipment list */
.equipment-list { display: flex; flex-direction: column; }
.equipment-header-row { display: grid; grid-template-columns: 1fr repeat(4, 70px); gap: var(--space-2); padding: var(--space-2) var(--space-4); font-size: 0.65rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); border-bottom: 1px solid var(--color-border-light); }
.equipment-row { display: grid; grid-template-columns: 1fr repeat(4, 70px); gap: var(--space-2); padding: var(--space-2) var(--space-4); border-bottom: 1px solid var(--color-border-light); font-size: 0.8rem; align-items: center; }
.equipment-row:last-child { border-bottom: none; }
.equip-name-col { display: flex; align-items: center; gap: var(--space-2); min-width: 0; }
.equip-name { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-weight: 500; }
.crit-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
.metric-val { font-size: 0.8rem; }
.text-right { text-align: right; }

/* Technicians */
.tech-list { display: flex; flex-direction: column; }
.tech-header-row { display: grid; grid-template-columns: 1fr repeat(3, 80px); gap: var(--space-2); padding: var(--space-2) var(--space-4); font-size: 0.65rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); border-bottom: 1px solid var(--color-border-light); }
.tech-row { display: grid; grid-template-columns: 1fr repeat(3, 80px); gap: var(--space-2); padding: var(--space-3) var(--space-4); border-bottom: 1px solid var(--color-border-light); align-items: center; }
.tech-row:last-child { border-bottom: none; }
.tech-name-col { display: flex; align-items: center; gap: var(--space-2); min-width: 0; }
.tech-avatar { width: 24px; height: 24px; background: var(--color-accent); color: #fff; border-radius: 50%; font-size: 0.7rem; font-weight: 600; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.tech-name { font-size: 0.82rem; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.completion-pill { font-size: 0.72rem; font-family: var(--font-mono); padding: 2px 6px; border-radius: 10px; }
.completion-pill--ok   { background: rgba(39,174,96,0.1); color: #27AE60; }
.completion-pill--warn { background: rgba(243,156,18,0.1); color: #F39C12; }
.completion-pill--alert { background: rgba(233,69,96,0.1); color: var(--color-alert); }

/* Spare parts */
.spares-list { display: flex; flex-direction: column; gap: var(--space-2); padding: var(--space-4) var(--space-5); }
.spare-row { display: flex; flex-direction: column; gap: 4px; }
.spare-info { display: flex; align-items: center; justify-content: space-between; }
.spare-name { font-size: 0.82rem; font-weight: 500; }
.spare-code { font-size: 0.72rem; }
.spare-stats { display: flex; align-items: center; gap: var(--space-2); }
.spare-consumed { font-size: 0.75rem; }
.low-stock-badge { font-size: 0.65rem; background: rgba(233,69,96,0.1); color: var(--color-alert); padding: 1px 6px; border-radius: 10px; }
.spare-bar-wrap { width: 100%; }
.spare-bar { height: 4px; background: var(--color-border-light); border-radius: 2px; overflow: hidden; }
.spare-bar-fill { height: 100%; border-radius: 2px; transition: width 0.4s ease; }

/* Ratio table */
.ratio-table-wrap { overflow-x: auto; }
.ratio-table { width: 100%; border-collapse: collapse; font-size: 0.82rem; }
.ratio-table th { padding: var(--space-2) var(--space-4); font-size: 0.65rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); background: var(--color-surface-2); border-bottom: 1px solid var(--color-border-light); text-align: left; }
.ratio-row td { padding: var(--space-2) var(--space-4); border-bottom: 1px solid var(--color-border-light); }
.ratio-row:last-child td { border-bottom: none; }
.ratio-row--alert { background: rgba(233,69,96,0.02); }
.inline-bar { display: inline-block; width: 80px; height: 6px; background: var(--color-border-light); border-radius: 3px; overflow: hidden; vertical-align: middle; margin-right: var(--space-2); }
.inline-bar-fill { height: 100%; border-radius: 3px; transition: width 0.4s ease; }

.mono { font-family: var(--font-mono); }
.text-muted { color: var(--color-text-muted); }

/* Node filter select */
.node-filter {
  height: 34px;
  padding: 0 var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius);
  background: var(--color-surface);
  font-size: 0.78rem;
  color: var(--color-text);
  cursor: pointer;
  max-width: 220px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  outline: none;
  transition: border-color var(--transition);
}
.node-filter:focus { border-color: var(--color-accent); }

/* ─── Responsive breakpoints ────────────────────────────────────────── */
@media (max-width: 1200px) {
  .kpi-grid { grid-template-columns: repeat(3, 1fr); }
}
@media (max-width: 768px) {
  .kpi-grid { grid-template-columns: repeat(2, 1fr); }
  .main-grid { grid-template-columns: 1fr; }
  .card--wide { grid-column: span 1; }
  .ratio-banner { grid-template-columns: 1fr; }
  .period-tabs { flex-wrap: wrap; }
  .equipment-header-row, .equipment-row { grid-template-columns: 1fr repeat(2, 60px); }
  .equipment-header-row span:nth-child(4), .equipment-row span:nth-child(4),
  .equipment-header-row span:nth-child(5), .equipment-row span:nth-child(5) { display: none; }
  .tech-header-row, .tech-row { grid-template-columns: 1fr repeat(2, 70px); }
  .tech-header-row span:nth-child(4), .tech-row span:nth-child(4) { display: none; }
  .page-title { font-size: 1.15rem; }
  .page-header { flex-direction: column; gap: var(--space-3); }
}
@media (max-width: 480px) {
  .kpi-grid { grid-template-columns: 1fr; }
  .period-tabs { gap: var(--space-1); }
}

/* ─── Health overview ─────────────────────────────────────────────── */
.health-overview { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-lg, 10px); padding: var(--space-5) var(--space-6); }
.health-overview-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: var(--space-4); }
.btn-sm { font-size: 0.75rem; padding: 4px 12px; }
.health-dist-bar { display: flex; height: 28px; border-radius: 6px; overflow: hidden; gap: 2px; margin-bottom: var(--space-3); }
.hdist { display: flex; align-items: center; justify-content: center; font-size: 0.72rem; font-weight: 700; color: #fff; min-width: 24px; transition: flex 0.3s; }
.hdist--excellent { background: #27AE60; }
.hdist--good { background: #6BCB77; }
.hdist--fair { background: #E6A817; }
.hdist--poor { background: #E67E22; }
.hdist--critical { background: #E94560; }
.health-dist-legend { display: flex; gap: var(--space-4); flex-wrap: wrap; font-size: 0.72rem; color: var(--color-text-muted); margin-bottom: var(--space-4); }
.hleg { display: flex; align-items: center; gap: 4px; }
.hleg-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
.health-nodes-list { display: flex; flex-direction: column; gap: 6px; }
.health-node-row { display: grid; grid-template-columns: 1fr 80px 120px 40px; gap: var(--space-3); align-items: center; padding: 6px 0; border-bottom: 1px solid var(--color-border-light); }
.health-node-row:last-child { border-bottom: none; }
.health-node-name { font-size: 0.82rem; font-weight: 500; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.health-node-type { font-size: 0.7rem; color: var(--color-text-muted); text-transform: capitalize; }
.health-node-bar-wrap { width: 100%; }
.health-node-bar { height: 6px; background: var(--color-border-light); border-radius: 3px; overflow: hidden; }
.health-node-fill { height: 100%; border-radius: 3px; transition: width 0.4s ease; }
.health-node-score { font-size: 0.82rem; font-weight: 700; text-align: right; }
</style>
