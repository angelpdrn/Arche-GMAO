<template>
  <div class="lib-page">
    <DirectoryPanel
      section="library"
      :selected-id="selectedDirId"
      @select="onDirSelect"
      @item-dropped="refreshDir"
    />

    <div class="lib-content">
      <div class="page-header">
        <div>
          <h1 class="page-title">
            Biblioteca
            <span v-if="selectedDirName" class="page-title-dir">/ {{ selectedDirName }}</span>
          </h1>
          <p class="page-sub">Documentación, manuales, planos y multimedia de la planta</p>
        </div>
      </div>

      <!-- Filters -->
      <div class="filters-bar">
        <select v-model="filterCategory" class="filter-select" @change="loadFiles">
          <option value="">Todas las categorías</option>
          <option v-for="(label, key) in CATEGORY_LABELS" :key="key" :value="key">{{ label }}</option>
        </select>
        <input v-model="searchQ" class="filter-search" placeholder="Buscar por nombre..." @input="onSearch" />
      </div>

      <!-- File grid -->
      <div v-if="loading" class="table-empty">Cargando...</div>
      <div v-else-if="!displayedFiles.length" class="table-empty">
        {{ selectedDirId ? 'Esta carpeta está vacía.' : 'No hay archivos en la biblioteca.' }}
      </div>
      <div v-else class="files-grid">
        <div v-for="att in displayedFiles" :key="att.id" class="file-card"
          draggable="true" @dragstart="(e) => startDrag(e, 'attachment', att.id)">
          <div class="file-icon">{{ getFileIcon(att.mime_type) }}</div>
          <div class="file-info">
            <span class="file-name" :title="att.original_name">{{ att.original_name }}</span>
            <span class="file-node text-muted small">{{ att.node_name ?? '—' }}</span>
            <div class="file-meta">
              <span class="cat-badge" :style="{ background: CATEGORY_COLORS[att.category] + '20', color: CATEGORY_COLORS[att.category] }">
                {{ CATEGORY_LABELS[att.category] ?? att.category }}
              </span>
              <span class="file-size text-muted">{{ formatSize(att.file_size) }}</span>
            </div>
          </div>
          <div class="file-actions">
            <SaveToDir section="library" item-type="attachment" :item-id="att.id" @saved="refreshDir" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { directoriesApi } from '@/api/directories'
import { useDirectoriesStore } from '@/stores/directories'
import client from '@/api/client'
import DirectoryPanel from '@/components/directories/DirectoryPanel.vue'
import SaveToDir from '@/components/directories/SaveToDir.vue'

const CATEGORY_LABELS: Record<string, string> = {
  manual: 'Manual', blueprint: 'Plano', photo: 'Foto',
  procedure: 'Procedimiento', certificate: 'Certificado',
  report: 'Reporte', datasheet: 'Ficha Técnica', video: 'Video',
  schema: 'Esquema', other: 'Otro',
}
const CATEGORY_COLORS: Record<string, string> = {
  manual: '#0F3460', blueprint: '#3B82F6', photo: '#27AE60',
  procedure: '#8B5CF6', certificate: '#F39C12', report: '#E67E22',
  datasheet: '#0F3460', video: '#E94560', schema: '#3B82F6', other: '#9CA3AF',
}

const files = ref<any[]>([])
const loading = ref(false)
const filterCategory = ref('')
const searchQ = ref('')
const dirStore = useDirectoriesStore()
const selectedDirId = ref<number | null>(null)
const selectedDirName = ref<string | null>(null)
const dirItemIds = ref<number[]>([])
const dirFullItems = ref<any[]>([])

const displayedFiles = computed(() => {
  let result = files.value
  if (selectedDirId.value !== null) {
    const fromLoaded = result.filter(f => dirItemIds.value.includes(f.id))
    if (fromLoaded.length === dirItemIds.value.length) {
      result = fromLoaded
    } else {
      const loadedIds = new Set(fromLoaded.map(f => f.id))
      const fromDir = dirFullItems.value
        .filter(item => !loadedIds.has(item.item_id))
        .map(item => ({
          id: item.item_id,
          original_name: item.name ?? '',
          category: item.status ?? '',
          mime_type: item.extra ?? '',
          file_size: 0,
          node_name: '',
        }))
      result = [...fromLoaded, ...fromDir]
    }
  }
  if (searchQ.value.length >= 2) result = result.filter(f => f.original_name.toLowerCase().includes(searchQ.value.toLowerCase()))
  return result
})

async function loadFiles() {
  loading.value = true
  try {
    // Load the attachments of every node in the tenant
    const params = filterCategory.value ? `?category=${filterCategory.value}` : ''
    const { data } = await client.get(`/library/all${params}`)
    files.value = data.attachments ?? []
  } catch {
    // When the global endpoint does not exist yet, show an empty state
    files.value = []
  } finally { loading.value = false }
}

async function onDirSelect(id: number | null) {
  selectedDirId.value = id; selectedDirName.value = null
  dirItemIds.value = []; dirFullItems.value = []
  if (!id) return
  try {
    const data = await directoriesApi.getItems(id)
    dirItemIds.value = data.items.map(i => i.item_id)
    dirFullItems.value = data.items
    selectedDirName.value = dirStore.findDirInSection('library', id)?.name ?? null
  } catch { dirItemIds.value = []; dirFullItems.value = [] }
}

async function refreshDir() {
  if (selectedDirId.value) await onDirSelect(selectedDirId.value)
}

function startDrag(e: DragEvent, itemType: string, itemId: number) {
  if (!e.dataTransfer) return
  e.dataTransfer.setData('application/x-dir-item', JSON.stringify({ item_type: itemType, item_id: itemId }))
  e.dataTransfer.effectAllowed = 'copy'
}

function onSearch() { /* the computed filters in real time */ }

function getFileIcon(mime: string) {
  if (!mime) return '◻'
  if (mime.startsWith('image/')) return '▣'
  if (mime === 'application/pdf') return '▤'
  if (mime.includes('video')) return '▶'
  if (mime.includes('spreadsheet') || mime.includes('excel')) return '▦'
  if (mime.includes('word')) return '≡'
  return '◻'
}

function formatSize(bytes: number) {
  if (!bytes) return '—'
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB'
}

onMounted(loadFiles)
</script>

<style scoped>
.lib-page { display: flex; height: calc(100vh - var(--header-height)); margin: calc(-1 * var(--space-6)); overflow: hidden; }
.lib-content { flex: 1; overflow-y: auto; padding: var(--space-6); display: flex; flex-direction: column; gap: var(--space-5); }
.page-header { display: flex; align-items: flex-start; justify-content: space-between; }
.page-title { font-size: 1.4rem; font-weight: 700; color: var(--color-primary); }
.page-title-dir { font-size: 1rem; font-weight: 400; color: var(--color-text-muted); }
.page-sub { font-size: 0.8rem; color: var(--color-text-muted); }
.filters-bar { display: flex; gap: var(--space-3); }
.filter-select { height: 36px; padding: 0 var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.8rem; background: var(--color-surface); }
.filter-search { height: 36px; padding: 0 var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.8rem; background: var(--color-surface); outline: none; width: 220px; }
.filter-search:focus { border-color: var(--color-accent); }
.table-empty { padding: var(--space-8); text-align: center; color: var(--color-text-muted); font-size: 0.875rem; background: var(--color-surface); border-radius: var(--radius-md); border: 1px solid var(--color-border-light); }
.files-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: var(--space-3); }
.file-card { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); padding: var(--space-4); display: flex; flex-direction: column; gap: var(--space-3); transition: border-color var(--transition); }
.file-card:hover { border-color: var(--color-border); }
.file-icon { font-size: 2rem; }
.file-info { flex: 1; display: flex; flex-direction: column; gap: 4px; }
.file-name { font-size: 0.875rem; font-weight: 500; color: var(--color-text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.file-node { font-size: 0.72rem; }
.file-meta { display: flex; align-items: center; gap: var(--space-2); }
.cat-badge { font-size: 0.68rem; font-weight: 600; padding: 2px 7px; border-radius: 20px; }
.file-size { font-size: 0.72rem; font-family: var(--font-mono); }
.file-actions { display: flex; justify-content: flex-end; }
.text-muted { color: var(--color-text-muted); }
.small { font-size: 0.75rem; }

@media (max-width: 768px) {
  .filters-bar { flex-direction: column; gap: var(--space-2); }
  .filter-search { width: 100%; }
  .files-grid { grid-template-columns: 1fr; }
}
</style>
