<template>
  <div class="inv-page">
    <!-- Folder panel -->
    <DirectoryPanel
      section="spare_parts"
      :selected-id="selectedDirId"
      @select="onDirSelect"
      @item-dropped="onItemSaved"
    />

    <!-- Content -->
    <div class="inv-content">
      <div class="page-header">
        <div>
          <h1 class="page-title">
            Inventario
            <span v-if="selectedDirName" class="page-title-dir">/ {{ selectedDirName }}</span>
          </h1>
          <p class="page-sub">
            {{ total }} referencias ·
            <span class="alert-text">{{ lowStockCount }} con stock bajo</span>
          </p>
        </div>
        <ExportButton :options="reportsApi.getInventoryExportOptions()" />
        <button class="btn-primary" @click="openCreate" :disabled="!canWrite">+ Nuevo repuesto</button>
      </div>

      <!-- Filters -->
      <div class="filters-bar">
        <select v-model="filterCategory" class="filter-select" @change="loadParts">
          <option value="">Todas las categorías</option>
          <option v-for="(cfg, key) in CATEGORY_CONFIG" :key="key" :value="key">{{ cfg.label }}</option>
        </select>
        <label class="filter-check">
          <input type="checkbox" v-model="filterLowStock" @change="loadParts" />
          <span>Solo stock bajo</span>
        </label>
      </div>

      <!-- Table (desktop) -->
      <div class="inv-table-desktop table-wrap">
        <div v-if="loading" class="table-empty">Cargando...</div>
        <div v-else-if="!displayedParts.length" class="table-empty">
          {{ selectedDirId ? 'Esta carpeta está vacía.' : 'No hay repuestos registrados.' }}
        </div>
        <table v-else class="inv-table">
          <thead>
            <tr>
              <th>Código</th>
              <th>Nombre</th>
              <th>Categoría</th>
              <th>Stock actual</th>
              <th>Mínimo</th>
              <th>Ubicación</th>
              <th>Precio unit.</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="sp in displayedParts" :key="sp.id" class="inv-row"
              draggable="true" @dragstart="(e) => startDrag(e, 'spare_part', sp.id)">
              <td class="mono">{{ sp.code }}</td>
              <td class="sp-name">{{ sp.name }}</td>
              <td>
                <span class="cat-pill"
                  :style="{ color: CATEGORY_CONFIG[sp.category]?.color, background: CATEGORY_CONFIG[sp.category]?.color + '15' }">
                  {{ CATEGORY_CONFIG[sp.category]?.label }}
                </span>
              </td>
              <td :style="stockSeverityStyle(sp)">
                <span :class="{ 'stock-low': sp.low_stock }" class="mono">
                  {{ sp.current_stock }} {{ sp.unit }}
                </span>
                <span v-if="sp.low_stock" class="low-badge">BAJO</span>
                <div class="stock-mini-bar">
                  <div class="stock-mini-fill" :style="{ width: Math.min((sp.current_stock / Math.max(sp.min_stock, 1)) * 100, 100) + '%', background: sp.low_stock ? 'var(--color-alert)' : 'var(--color-success)' }"></div>
                </div>
              </td>
              <td class="mono text-muted">{{ sp.min_stock }}</td>
              <td class="text-muted small">{{ sp.location ?? '—' }}</td>
              <td class="mono">{{ sp.unit_price ? sp.unit_price.toFixed(2) + ' €' : '—' }}</td>
              <td class="actions-cell" @click.stop>
                <button class="btn-table" @click="openDetail(sp)">Ver</button>
                <SaveToDir section="spare_parts" item-type="spare_part" :item-id="sp.id" @saved="onItemSaved" />
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Mobile cards -->
      <div v-if="isMobile" class="inv-mobile-cards">
        <div v-if="loading" class="table-empty">Cargando...</div>
        <div v-else-if="!displayedParts.length" class="table-empty">
          {{ selectedDirId ? 'Esta carpeta está vacía.' : 'No hay repuestos registrados.' }}
        </div>
        <div v-else v-for="sp in displayedParts" :key="'m-'+sp.id" class="inv-mcard" @click="openDetail(sp)">
          <div class="inv-mcard-top">
            <span class="inv-mcard-code mono">{{ sp.code }}</span>
            <span class="cat-pill"
              :style="{ color: CATEGORY_CONFIG[sp.category]?.color, background: CATEGORY_CONFIG[sp.category]?.color + '15' }">
              {{ CATEGORY_CONFIG[sp.category]?.label }}
            </span>
          </div>
          <div class="inv-mcard-name">{{ sp.name }}</div>
          <div class="inv-mcard-stock">
            <div class="inv-mcard-stock-row">
              <span :class="{ 'stock-low': sp.low_stock }" class="mono inv-mcard-qty">
                {{ sp.current_stock }} {{ sp.unit }}
              </span>
              <span v-if="sp.low_stock" class="low-badge">BAJO</span>
              <span class="inv-mcard-min text-muted">min: {{ sp.min_stock }}</span>
            </div>
            <div class="stock-mini-bar" style="width: 100%">
              <div class="stock-mini-fill" :style="{ width: Math.min((sp.current_stock / Math.max(sp.min_stock, 1)) * 100, 100) + '%', background: sp.low_stock ? 'var(--color-alert)' : 'var(--color-success)' }"></div>
            </div>
          </div>
          <div class="inv-mcard-bottom">
            <span v-if="sp.location" class="text-muted">{{ sp.location }}</span>
            <span v-if="sp.unit_price" class="mono">{{ sp.unit_price.toFixed(2) }} €</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Spare part detail modal -->
    <Teleport to="body">
      <div v-if="selectedPart" class="modal-overlay" @click.self="selectedPart = null">
        <div class="detail-modal">
          <div class="modal-header">
            <div>
              <div class="mono small text-muted">{{ selectedPart.spare_part.code }}</div>
              <h3 class="detail-title">{{ selectedPart.spare_part.name }}</h3>
            </div>
            <div class="modal-header-actions">
              <button class="btn-table" @click="openEdit">Editar</button>
              <button class="modal-close" @click="selectedPart = null">✕</button>
            </div>
          </div>
          <div class="modal-body">
            <div class="stock-highlight" :class="{ 'stock-highlight--low': selectedPart.spare_part.low_stock }">
              <div class="stock-number">{{ selectedPart.spare_part.current_stock }} <span class="stock-unit">{{ selectedPart.spare_part.unit }}</span></div>
              <div class="stock-label">Stock actual · Mínimo: {{ selectedPart.spare_part.min_stock }}</div>
            </div>

            <div class="movement-form">
              <div class="form-section-title">Registrar movimiento</div>
              <div class="field-row">
                <div class="field">
                  <label class="field-label">Tipo</label>
                  <select v-model="movForm.movement_type" class="field-input">
                    <option v-for="(cfg, key) in MOVEMENT_CONFIG" :key="key" :value="key">
                      {{ cfg.sign }} {{ cfg.label }}
                    </option>
                  </select>
                </div>
                <div class="field">
                  <label class="field-label">Cantidad</label>
                  <input v-model.number="movForm.quantity" type="number" class="field-input mono" step="0.001" min="0.001" placeholder="0" />
                </div>
              </div>
              <div class="field">
                <label class="field-label">Notas</label>
                <input v-model="movForm.notes" class="field-input" placeholder="Opcional..." />
              </div>
              <div v-if="movError" class="modal-error">{{ movError }}</div>
              <button class="btn-primary" :disabled="!canWrite || movSubmitting || movForm.quantity <= 0" @click="submitMovement">
                {{ movSubmitting ? 'Registrando...' : 'Registrar movimiento' }}
              </button>
            </div>

            <div class="form-section-title">Últimos movimientos</div>
            <div v-if="!selectedPart.movements?.length" class="table-empty small">Sin movimientos.</div>
            <div v-else class="movements-list">
              <div v-for="m in selectedPart.movements" :key="m.id" class="mov-item">
                <span class="mov-sign" :style="{ color: MOVEMENT_CONFIG[m.movement_type]?.color }">
                  {{ MOVEMENT_CONFIG[m.movement_type]?.sign }}{{ Math.abs(m.quantity) }}
                </span>
                <div class="mov-info">
                  <span class="mov-type">{{ MOVEMENT_CONFIG[m.movement_type]?.label }}</span>
                  <span class="mov-stock mono small text-muted">{{ m.stock_before }} → {{ m.stock_after }}</span>
                </div>
                <span class="mov-date small text-muted" :title="formatDate(m.created_at)">{{ formatSmart(m.created_at) }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Edit spare part modal -->
    <Teleport to="body">
      <div v-if="showEdit" class="modal-overlay" @click.self="showEdit = false">
        <div class="create-modal">
          <div class="modal-header"><h3>Editar Repuesto</h3><button class="modal-close" @click="showEdit = false">✕</button></div>
          <div class="modal-body">
            <div class="field"><label class="field-label">Código</label><input :value="editForm.code" class="field-input mono" disabled /></div>
            <div class="field"><label class="field-label">Nombre *</label><input v-model="editForm.name" class="field-input" /></div>
            <div class="field-row">
              <div class="field"><label class="field-label">Categoría</label>
                <select v-model="editForm.category" class="field-input">
                  <option v-for="(cfg, key) in CATEGORY_CONFIG" :key="key" :value="key">{{ cfg.label }}</option>
                </select>
              </div>
              <div class="field"><label class="field-label">Unidad</label><input v-model="editForm.unit" class="field-input" /></div>
            </div>
            <div class="field-row">
              <div class="field"><label class="field-label">Stock mínimo</label><input v-model.number="editForm.min_stock" type="number" class="field-input mono" step="0.001" /></div>
              <div class="field"><label class="field-label">Stock máximo</label><input v-model.number="editForm.max_stock" type="number" class="field-input mono" step="0.001" /></div>
            </div>
            <div class="field-row">
              <div class="field"><label class="field-label">Ubicación</label><input v-model="editForm.location" class="field-input" /></div>
              <div class="field"><label class="field-label">Precio unit. (€)</label><input v-model.number="editForm.unit_price" type="number" class="field-input mono" step="0.01" /></div>
            </div>
            <div class="field-row">
              <div class="field"><label class="field-label">Proveedor</label><input v-model="editForm.supplier" class="field-input" /></div>
              <div class="field"><label class="field-label">Días de entrega</label><input v-model.number="editForm.lead_days" type="number" class="field-input mono" /></div>
            </div>
            <div class="field"><label class="field-label">Notas</label><input v-model="editForm.notes" class="field-input" placeholder="Opcional..." /></div>
            <div v-if="editError" class="modal-error">{{ editError }}</div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary" @click="showEdit = false">Cancelar</button>
            <button class="btn-primary" :disabled="!canWrite || editing" @click="submitEdit">{{ editing ? 'Guardando...' : 'Guardar cambios' }}</button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Create spare part modal -->
    <Teleport to="body">
      <div v-if="showCreate" class="modal-overlay" @click.self="showCreate = false">
        <div class="create-modal">
          <div class="modal-header"><h3>Nuevo Repuesto</h3><button class="modal-close" @click="showCreate = false">✕</button></div>
          <div class="modal-body">
            <div class="field-row">
              <div class="field"><label class="field-label">Código *</label><input v-model="createForm.code" class="field-input mono" placeholder="ROD-6205-ZZ" /></div>
              <div class="field"><label class="field-label">Categoría</label>
                <select v-model="createForm.category" class="field-input">
                  <option v-for="(cfg, key) in CATEGORY_CONFIG" :key="key" :value="key">{{ cfg.label }}</option>
                </select>
              </div>
            </div>
            <div class="field"><label class="field-label">Nombre *</label><input v-model="createForm.name" class="field-input" /></div>
            <div class="field-row">
              <div class="field"><label class="field-label">Unidad</label><input v-model="createForm.unit" class="field-input" placeholder="unit / kg / liter" /></div>
              <div class="field"><label class="field-label">Stock mínimo</label><input v-model.number="createForm.min_stock" type="number" class="field-input mono" step="0.001" /></div>
            </div>
            <div class="field-row">
              <div class="field"><label class="field-label">Ubicación</label><input v-model="createForm.location" class="field-input" /></div>
              <div class="field"><label class="field-label">Precio unit. (€)</label><input v-model.number="createForm.unit_price" type="number" class="field-input mono" step="0.01" /></div>
            </div>
            <div class="field"><label class="field-label">Proveedor</label><input v-model="createForm.supplier" class="field-input" /></div>
            <div v-if="createError" class="modal-error">{{ createError }}</div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary" @click="showCreate = false">Cancelar</button>
            <button class="btn-primary" :disabled="!canWrite || creating" @click="submitCreate">{{ creating ? 'Creando...' : 'Crear repuesto' }}</button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { apiErrorMsg } from '@/composables/useToast'
import { formatDate, formatSmart } from '@/utils/time'
import { sparePartsApi } from '@/api/phase2'
import { reportsApi } from '@/api/reports'
import ExportButton from '@/components/reports/ExportButton.vue'
import { directoriesApi } from '@/api/directories'
import { useDirectoriesStore } from '@/stores/directories'
import { CATEGORY_CONFIG, MOVEMENT_CONFIG } from '@/types/inventory'
import type { SparePart, StockMovement } from '@/types/inventory'
import DirectoryPanel from '@/components/directories/DirectoryPanel.vue'
import SaveToDir from '@/components/directories/SaveToDir.vue'
import { useSystemPause } from '@/composables/useSystemPause'
import { useIsMobile } from '@/composables/useIsMobile'

const { canWrite } = useSystemPause()
const isMobile = useIsMobile()
const parts = ref<SparePart[]>([])
const total = ref(0)
const loading = ref(false)
const filterCategory = ref('')
const filterLowStock = ref(false)
const lowStockCount = computed(() => parts.value.filter(p => p.low_stock).length)

function stockSeverityStyle(sp: any): Record<string, string> {
  if (!sp.low_stock) return {}
  if (sp.current_stock === 0) return { background: 'rgba(233,69,96,0.15)' }
  if (sp.current_stock < sp.min_stock * 0.5) return { background: 'rgba(233,69,96,0.08)' }
  return { background: 'rgba(243,156,18,0.08)' }
}

const selectedPart = ref<{ spare_part: SparePart; movements: StockMovement[] } | null>(null)
const movForm = ref({ movement_type: 'purchase', quantity: 0, notes: '' })
const movSubmitting = ref(false)
const movError = ref('')

const showCreate = ref(false)
const creating = ref(false)
const createError = ref('')
const createForm = ref({ code: '', name: '', category: 'mechanical', unit: 'unit', min_stock: 0, location: '', unit_price: undefined as number | undefined, supplier: '' })

const showEdit = ref(false)
const editing = ref(false)
const editError = ref('')
const editForm = ref({ code: '', name: '', category: 'mechanical', unit: 'unit', min_stock: 0, max_stock: undefined as number | undefined, location: '', unit_price: undefined as number | undefined, supplier: '', lead_days: undefined as number | undefined, notes: '' })

// ─── Directories ─────────────────────────────────────────────────────────────
const dirStore = useDirectoriesStore()
const selectedDirId = ref<number | null>(null)
const selectedDirName = ref<string | null>(null)
const dirItemIds = ref<number[]>([])
const dirFullItems = ref<any[]>([])

const displayedParts = computed(() => {
  if (selectedDirId.value === null) return parts.value
  const fromLoaded = parts.value.filter(p => dirItemIds.value.includes(p.id))
  if (fromLoaded.length === dirItemIds.value.length) return fromLoaded
  const loadedIds = new Set(fromLoaded.map(p => p.id))
  const fromDir = dirFullItems.value
    .filter(item => !loadedIds.has(item.item_id))
    .map(item => ({
      id: item.item_id,
      code: item.ref ?? '',
      name: item.name ?? '',
      category: item.status ?? '',
      current_stock: Number(item.extra) || 0,
      min_stock: 0,
      node_name: '',
      unit: '',
    }))
  return [...fromLoaded, ...fromDir]
})

async function onDirSelect(id: number | null) {
  selectedDirId.value = id
  selectedDirName.value = null
  dirItemIds.value = []
  dirFullItems.value = []
  if (id === null) return
  try {
    const data = await directoriesApi.getItems(id)
    dirItemIds.value = data.items.map(i => i.item_id)
    dirFullItems.value = data.items
    const dir = dirStore.findDirInSection('spare_parts', id)
    selectedDirName.value = dir?.name ?? null
  } catch { dirItemIds.value = []; dirFullItems.value = [] }
}

function onItemSaved() {
  if (selectedDirId.value) onDirSelect(selectedDirId.value)
}

function startDrag(e: DragEvent, itemType: string, itemId: number) {
  if (!e.dataTransfer) return
  e.dataTransfer.setData('application/x-dir-item', JSON.stringify({ item_type: itemType, item_id: itemId }))
  e.dataTransfer.effectAllowed = 'copy'
}

async function loadParts() {
  loading.value = true
  try {
    const data = await sparePartsApi.list({
      category: filterCategory.value || undefined,
      low_stock: filterLowStock.value || undefined,
    })
    parts.value = data.spare_parts ?? []
    total.value = data.total ?? 0
  } finally { loading.value = false }
}

async function openDetail(sp: SparePart) {
  const data = await sparePartsApi.getOne(sp.id)
  selectedPart.value = data
  movForm.value = { movement_type: 'purchase', quantity: 0, notes: '' }
  movError.value = ''
}

async function submitMovement() {
  if (!selectedPart.value || movForm.value.quantity <= 0) return
  const part = selectedPart.value.spare_part
  movSubmitting.value = true
  movError.value = ''
  try {
    await sparePartsApi.addMovement(part.id, {
      movement_type: movForm.value.movement_type,
      quantity: movForm.value.quantity,
      notes: movForm.value.notes || undefined,
    })
    await openDetail(part)
    await loadParts()
    movForm.value = { movement_type: 'purchase', quantity: 0, notes: '' }
  } catch (err: unknown) {
    movError.value = apiErrorMsg(err, 'Error registrando movimiento')
  } finally { movSubmitting.value = false }
}

function openEdit() {
  if (!selectedPart.value) return
  const sp = selectedPart.value.spare_part
  editForm.value = {
    code: sp.code,
    name: sp.name,
    category: sp.category,
    unit: sp.unit,
    min_stock: sp.min_stock,
    max_stock: sp.max_stock ?? undefined,
    location: sp.location ?? '',
    unit_price: sp.unit_price ?? undefined,
    supplier: sp.supplier ?? '',
    lead_days: sp.lead_days ?? undefined,
    notes: sp.notes ?? '',
  }
  editError.value = ''
  showEdit.value = true
}

async function submitEdit() {
  if (!selectedPart.value || !editForm.value.name) { editError.value = 'El nombre es requerido'; return }
  editing.value = true; editError.value = ''
  try {
    await sparePartsApi.update(selectedPart.value.spare_part.id, editForm.value as any)
    showEdit.value = false
    await openDetail({ id: selectedPart.value.spare_part.id } as SparePart)
    await loadParts()
  } catch (err: unknown) {
    editError.value = apiErrorMsg(err, 'Error actualizando repuesto')
  } finally { editing.value = false }
}

function openCreate() {
  createForm.value = { code: '', name: '', category: 'mechanical', unit: 'unit', min_stock: 0, location: '', unit_price: undefined, supplier: '' }
  createError.value = ''
  showCreate.value = true
}

async function submitCreate() {
  if (!createForm.value.code || !createForm.value.name) { createError.value = 'Código y nombre son requeridos'; return }
  creating.value = true; createError.value = ''
  try {
    await sparePartsApi.create(createForm.value as any)
    showCreate.value = false
    await loadParts()
  } catch (err: unknown) {
    createError.value = apiErrorMsg(err, 'Error creando repuesto')
  } finally { creating.value = false }
}

// formatDate / formatSmart come from @/utils/time

onMounted(loadParts)
</script>

<style scoped>
.inv-page { display: flex; height: calc(100vh - var(--header-height)); margin: calc(-1 * var(--space-6)); overflow: hidden; }
.inv-content { flex: 1; overflow-y: auto; padding: var(--space-6); display: flex; flex-direction: column; gap: var(--space-5); }
.page-header { display: flex; align-items: flex-start; justify-content: space-between; }
.page-title { font-size: 1.4rem; font-weight: 700; color: var(--color-primary); }
.page-title-dir { font-size: 1rem; font-weight: 400; color: var(--color-text-muted); }
.page-sub { font-size: 0.8rem; color: var(--color-text-muted); }
.alert-text { color: var(--color-alert); }
.filters-bar { display: flex; gap: var(--space-3); align-items: center; }
.filter-select { height: 36px; padding: 0 var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.8rem; background: var(--color-surface); }
.filter-check { display: flex; align-items: center; gap: var(--space-2); font-size: 0.8rem; cursor: pointer; }
.table-wrap { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); overflow: hidden; }
.table-empty { padding: var(--space-8); text-align: center; color: var(--color-text-muted); font-size: 0.875rem; }
.table-empty.small { padding: var(--space-4); font-size: 0.8rem; }
.inv-table { width: 100%; border-collapse: collapse; }
.inv-table th { padding: var(--space-3) var(--space-4); font-size: 0.68rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--color-text-muted); background: var(--color-surface-2); border-bottom: 1px solid var(--color-border-light); text-align: left; }
.inv-row { border-bottom: 1px solid var(--color-border-light); }
.inv-row td { padding: var(--space-3) var(--space-4); font-size: 0.8rem; }
.sp-name { font-weight: 500; }
.cat-pill { font-size: 0.7rem; font-weight: 600; padding: 2px 8px; border-radius: 20px; }
.stock-low { color: var(--color-alert); font-weight: 600; }
.low-badge { margin-left: 6px; font-size: 0.6rem; font-weight: 700; color: var(--color-alert); background: rgba(233,69,96,0.1); padding: 1px 5px; border-radius: 3px; }
.stock-mini-bar { width: 60px; height: 3px; background: var(--color-border-light); border-radius: 2px; overflow: hidden; margin-top: 3px; }
.stock-mini-fill { height: 100%; border-radius: 2px; transition: width 0.3s; }
.actions-cell { display: flex; align-items: center; gap: var(--space-2); }
.btn-table { height: 28px; padding: 0 var(--space-3); background: var(--color-surface-2); border: 1px solid var(--color-border); border-radius: var(--radius-sm); font-size: 0.75rem; cursor: pointer; }
.btn-table:hover { background: var(--color-border-light); }
.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; padding: var(--space-4); }
.detail-modal { background: var(--color-surface); border-radius: var(--radius-lg); width: 100%; max-width: 560px; max-height: 90vh; display: flex; flex-direction: column; box-shadow: var(--shadow-lg); }
.modal-header { display: flex; justify-content: space-between; align-items: flex-start; padding: var(--space-5) var(--space-6); border-bottom: 1px solid var(--color-border-light); }
.detail-title { font-size: 1rem; font-weight: 700; color: var(--color-primary); margin-top: 4px; }
.modal-close { background: none; border: none; cursor: pointer; color: var(--color-text-muted); font-size: 1rem; }
.modal-header-actions { display: flex; align-items: center; gap: var(--space-2); }
.modal-body { flex: 1; overflow-y: auto; padding: var(--space-5) var(--space-6); display: flex; flex-direction: column; gap: var(--space-4); }
.stock-highlight { background: var(--color-surface-2); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); padding: var(--space-4) var(--space-5); text-align: center; }
.stock-highlight--low { border-color: rgba(233,69,96,0.3); background: rgba(233,69,96,0.05); }
.stock-number { font-size: 2rem; font-weight: 700; font-family: var(--font-mono); color: var(--color-primary); }
.stock-unit { font-size: 1rem; color: var(--color-text-muted); }
.stock-label { font-size: 0.75rem; color: var(--color-text-muted); margin-top: 4px; }
.movement-form { display: flex; flex-direction: column; gap: var(--space-3); background: var(--color-surface-2); border-radius: var(--radius-md); padding: var(--space-4); }
.form-section-title { font-size: 0.68rem; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; color: var(--color-text-muted); }
.field { display: flex; flex-direction: column; gap: var(--space-1); flex: 1; }
.field-row { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-3); }
.field-label { font-size: 0.68rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); }
.field-input { height: 36px; padding: 0 var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; background: var(--color-surface); outline: none; width: 100%; }
.field-input:focus { border-color: var(--color-accent); }
.movements-list { display: flex; flex-direction: column; gap: 6px; }
.mov-item { display: flex; align-items: center; gap: var(--space-3); padding: var(--space-2) var(--space-3); background: var(--color-surface-2); border-radius: var(--radius); }
.mov-sign { font-family: var(--font-mono); font-size: 0.9rem; font-weight: 700; min-width: 50px; }
.mov-info { flex: 1; display: flex; flex-direction: column; gap: 2px; }
.mov-type { font-size: 0.8rem; font-weight: 500; }
.mov-stock { display: block; }
.mov-date { white-space: nowrap; }
.modal-error { background: rgba(233,69,96,0.08); border: 1px solid rgba(233,69,96,0.3); border-radius: var(--radius); padding: var(--space-3); font-size: 0.875rem; color: var(--color-alert); }
.create-modal { background: var(--color-surface); border-radius: var(--radius-lg); width: 100%; max-width: 520px; box-shadow: var(--shadow-lg); }
.modal-footer { display: flex; justify-content: flex-end; gap: var(--space-3); padding: var(--space-4) var(--space-6); border-top: 1px solid var(--color-border-light); }
.btn-primary { height: 38px; padding: 0 var(--space-5); background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); font-size: 0.875rem; font-weight: 500; cursor: pointer; }
.btn-primary:hover:not(:disabled) { background: var(--color-accent); }
.btn-primary:disabled { opacity: 0.65; cursor: not-allowed; }
.btn-secondary { height: 38px; padding: 0 var(--space-5); background: var(--color-surface-2); color: var(--color-text); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; cursor: pointer; }
.mono { font-family: var(--font-mono); }
.small { font-size: 0.75rem; }
.text-muted { color: var(--color-text-muted); }

/* ─── Mobile cards ────────────────────────────────────────────────────────── */
.inv-mobile-cards {
  display: none;
  flex-direction: column;
  gap: var(--space-2);
}
.inv-mcard {
  background: var(--color-surface);
  border: 1px solid var(--color-border-light);
  border-radius: var(--radius-md);
  padding: var(--space-3);
  cursor: pointer;
  transition: border-color var(--transition);
}
.inv-mcard:active { border-color: var(--color-accent); }
.inv-mcard-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 4px;
}
.inv-mcard-code { font-size: 0.7rem; color: var(--color-text-light); }
.inv-mcard-name {
  font-size: 0.88rem;
  font-weight: 600;
  color: var(--color-text);
  margin-bottom: 8px;
  line-height: 1.3;
}
.inv-mcard-stock { margin-bottom: 6px; }
.inv-mcard-stock-row {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  margin-bottom: 4px;
}
.inv-mcard-qty { font-size: 0.9rem; font-weight: 600; }
.inv-mcard-min { font-size: 0.7rem; margin-left: auto; }
.inv-mcard-bottom {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 0.75rem;
}

@media (max-width: 768px) {
  .inv-table-desktop { display: none !important; }
  .inv-mobile-cards { display: flex !important; }

  .page-header { flex-direction: column; gap: var(--space-3); }
  .page-title { font-size: 1.15rem; }
  .header-actions { width: 100%; flex-wrap: wrap; }
  .filters-bar { flex-direction: column; }
  .filter-select { height: 40px; font-size: 0.82rem; width: 100%; }
  .search-input { height: 40px; font-size: 0.82rem; }

  /* Detail modal full-screen */
  .modal-overlay { padding: 0; }
  .detail-modal, .create-modal, .small-modal { max-width: 100%; border-radius: 0; max-height: 100vh; max-height: 100dvh; overflow-y: auto; }
  .modal-body { padding: var(--space-4); }
  .field-row { grid-template-columns: 1fr; }
  .field-input { height: 42px; }
  .btn-primary, .btn-secondary { height: 44px; font-size: 0.9rem; }
}
</style>
