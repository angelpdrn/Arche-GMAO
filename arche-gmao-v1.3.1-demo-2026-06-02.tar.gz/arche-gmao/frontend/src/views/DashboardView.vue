<template>
  <div class="dashboard">
    <div class="page-header">
      <div>
        <h1 class="page-title">{{ greeting }}</h1>
        <p class="page-sub">{{ roleDescription }}</p>
      </div>
      <span class="page-date mono">{{ today }}</span>
    </div>

    <!-- Main KPIs (every role; the backend scopes the data) -->
    <div class="kpi-grid">
      <div class="kpi-card kpi-card--clickable" :class="{ 'kpi-card--active': stats.wos_active > 0 }"
        @click="router.push('/work-orders?status=assigned,in_progress')">
        <div class="kpi-value">{{ stats.wos_active }}</div>
        <div class="kpi-label">OTs activas</div>
        <div class="kpi-sub">{{ stats.wos_critical }} críticas</div>
      </div>
      <div class="kpi-card kpi-card--clickable" :class="{ 'kpi-card--alert-active': stats.wos_pending > 0 }"
        @click="router.push('/work-orders?status=pending')">
        <div class="kpi-value">{{ stats.wos_pending }}</div>
        <div class="kpi-label">{{ authStore.isSupervisor ? 'Pendientes de aprobación' : 'Mis OTs pendientes' }}</div>
      </div>
      <div v-if="authStore.isSupervisor || authStore.user?.role === 'warehouse'" class="kpi-card kpi-card--clickable"
        :class="{ 'kpi-card--warning-active': stats.low_stock > 0 }"
        @click="router.push('/inventory?low_stock=true')">
        <div class="kpi-value">{{ stats.low_stock }}</div>
        <div class="kpi-label">Stock bajo</div>
        <div class="kpi-sub">Repuestos bajo mínimo</div>
      </div>
      <div v-if="authStore.isManager" class="kpi-card kpi-card--clickable"
        :class="{ 'kpi-card--warning-active': stats.overdue > 0 }"
        @click="router.push('/work-orders?filter=overdue')">
        <div class="kpi-value">{{ stats.overdue }}</div>
        <div class="kpi-label">OTs vencidas</div>
        <div class="kpi-sub">Plazo excedido</div>
      </div>
      <div v-if="authStore.isAdmin" class="kpi-card kpi-card--clickable"
        :class="complianceRate >= 80 ? 'kpi-card--success-active' : complianceRate >= 60 ? 'kpi-card--warning-active' : 'kpi-card--alert-active'"
        @click="router.push('/maintenance-plans')">
        <div class="kpi-value">{{ complianceRate }}%</div>
        <div class="kpi-label">Compliance</div>
        <div class="kpi-sub">Cumplimiento preventivo</div>
      </div>
      <div v-if="authStore.isAdmin" class="kpi-card kpi-card--clickable"
        @click="router.push('/maintenance-plans')">
        <div class="kpi-value">{{ activeMaintenancePlans }}</div>
        <div class="kpi-label">Planes activos</div>
        <div class="kpi-sub">Mantenimiento preventivo</div>
      </div>
    </div>

    <!-- Predictive AI alerts (manager and auditor) -->
    <PatternAlerts v-if="authStore.isManager || authStore.user?.role === 'auditor'" />

    <!-- ADMIN: System status -->
    <div v-if="authStore.isAdmin" class="section-grid">
      <div class="card">
        <div class="card-header"><span class="card-title">Estado del sistema</span></div>
        <div class="status-list">
          <div class="status-row">
            <span class="status-dot" :class="health.db === 'ok' ? 'ok' : 'error'"></span>
            <span class="status-label">Base de datos</span>
            <span class="status-val mono">PostgreSQL 16</span>
          </div>
          <div class="status-row">
            <span class="status-dot" :class="health.redis === 'ok' ? 'ok' : 'error'"></span>
            <span class="status-label">Cache</span>
            <span class="status-val mono">Redis 7</span>
          </div>
          <div class="status-row">
            <span class="status-dot" :class="health.ollama ? 'ok' : 'error'"></span>
            <span class="status-label">Arche IA</span>
            <span class="status-val mono">{{ health.ollama ? 'En línea' : 'Desconectada' }}</span>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-header">
          <span class="card-title">Fábrica virtual</span>
          <RouterLink to="/factory" class="card-link">Administrar</RouterLink>
        </div>
        <div class="node-stats">
          <div class="node-stat">
            <span class="node-stat-value">{{ stats.total_nodes }}</span>
            <span class="node-stat-label">Nodos</span>
          </div>
          <div class="node-stat">
            <span class="node-stat-value">{{ stats.total_equipment }}</span>
            <span class="node-stat-label">Equipos</span>
          </div>
          <div class="node-stat">
            <span class="node-stat-value" :class="{ 'alert-val': stats.critical_nodes > 0 }">{{ stats.critical_nodes }}</span>
            <span class="node-stat-label">Críticos</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Main content: recent WOs + side panel -->
    <div class="main-grid">
      <!-- Recent WOs -->
      <div class="card">
        <div class="card-header">
          <span class="card-title">{{ authStore.isFieldWorker ? 'Mis órdenes de trabajo' : 'Órdenes de trabajo recientes' }}</span>
          <RouterLink v-if="authStore.isSupervisor" to="/work-orders" class="card-link">Ver todas</RouterLink>
          <RouterLink v-else to="/factory" class="card-link">Ir a mis equipos</RouterLink>
        </div>
        <div v-if="loadingWOs" class="card-loading">Cargando...</div>
        <EmptyState
          v-else-if="!recentWOs.length"
          icon="◇"
          :title="authStore.isFieldWorker ? 'Sin OTs asignadas' : 'Sin OTs recientes'"
          :hint="authStore.isFieldWorker
            ? 'Cuando tu supervisor te asigne una orden, aparecerá aquí.'
            : 'Crea la primera OT desde la fábrica virtual o haciendo click abajo.'"
          :action="authStore.isManager ? 'Ir a Órdenes' : undefined"
          size="sm"
          @action="router.push('/work-orders')" />
        <div v-else class="wo-list">
          <div v-for="wo in recentWOs" :key="wo.id" class="wo-item" @click="navigateToWO(wo)">
            <div class="wo-item-left">
              <span class="wo-number mono">{{ wo.wo_number }}</span>
              <span class="wo-title">{{ wo.title }}</span>
              <span class="wo-node text-muted">{{ wo.node_name }}</span>
            </div>
            <div class="wo-item-right">
              <span class="priority-dot" :style="{ background: WO_PRIORITY_CONFIG[wo.priority]?.color }"></span>
              <span class="status-pill small"
                :style="{ color: WO_STATUS_CONFIG[wo.status]?.color, background: WO_STATUS_CONFIG[wo.status]?.color + '15' }">
                {{ WO_STATUS_CONFIG[wo.status]?.label }}
              </span>
            </div>
          </div>
        </div>
      </div>

      <!-- Side panel -->
      <div class="side-col">
        <!-- SUPERVISOR: Nodes in their charge -->
        <div v-if="authStore.isSupervisor" class="card">
          <div class="card-header">
            <span class="card-title">Mis nodos</span>
            <RouterLink to="/factory" class="card-link">Ver equipos</RouterLink>
          </div>
          <div class="node-stats">
            <div class="node-stat">
              <span class="node-stat-value">{{ stats.total_nodes }}</span>
              <span class="node-stat-label">Nodos</span>
            </div>
            <div class="node-stat">
              <span class="node-stat-value">{{ stats.total_equipment }}</span>
              <span class="node-stat-label">Equipos</span>
            </div>
            <div class="node-stat">
              <span class="node-stat-value" :class="{ 'alert-val': stats.critical_nodes > 0 }">{{ stats.critical_nodes }}</span>
              <span class="node-stat-label">Críticos</span>
            </div>
          </div>
        </div>

        <!-- Upcoming preventive work (admin + supervisor) -->
        <div v-if="authStore.isManager && upcomingMaint.length > 0" class="card">
          <div class="card-header">
            <span class="card-title">Preventivos próximos</span>
            <RouterLink to="/maintenance-plans" class="card-link">Ver planes</RouterLink>
          </div>
          <div class="maint-list">
            <div v-for="m in upcomingMaint" :key="m.plan_id" class="maint-item">
              <div class="maint-info">
                <span class="maint-title">{{ m.title }}</span>
                <span class="maint-node text-muted">{{ m.node_name }}</span>
              </div>
              <span class="maint-days mono" :class="{ 'alert-val': m.days_until_due <= 0 }">
                {{ m.days_until_due <= 0 ? 'Vencido' : m.days_until_due + 'd' }}
              </span>
            </div>
          </div>
        </div>

        <!-- Low stock (manager + warehouse) -->
        <div v-if="(authStore.isSupervisor || authStore.user?.role === 'warehouse') && lowStockParts.length > 0" class="card card--warning">
          <div class="card-header">
            <span class="card-title">Stock bajo</span>
            <RouterLink to="/inventory" class="card-link">Ver inventario</RouterLink>
          </div>
          <div class="low-stock-list">
            <div v-for="sp in lowStockParts" :key="sp.id" class="low-stock-item">
              <span class="ls-code mono">{{ sp.code }}</span>
              <span class="ls-name">{{ sp.name }}</span>
              <span class="ls-stock alert-val mono">{{ sp.current_stock }} {{ sp.unit }}</span>
            </div>
          </div>
        </div>

        <!-- Quick access (field workers) -->
        <div v-if="authStore.isFieldWorker" class="card">
          <div class="card-header"><span class="card-title">Acceso rapido</span></div>
          <div class="quick-actions">
            <RouterLink to="/factory" class="quick-action-btn">
              <span class="qa-icon">◈</span>
              <span>Mis equipos</span>
            </RouterLink>
            <RouterLink to="/calendar" class="quick-action-btn">
              <span class="qa-icon">◷</span>
              <span>Mi calendario</span>
            </RouterLink>
            <RouterLink to="/ai" class="quick-action-btn">
              <span class="qa-icon">◬</span>
              <span>Consultar IA</span>
            </RouterLink>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { useAIStore } from '@/stores/ai'
import { workOrdersApi, sparePartsApi } from '@/api/phase2'
import PatternAlerts from '@/components/ai/PatternAlerts.vue'
import EmptyState from '@/components/layout/EmptyState.vue'
import { WO_PRIORITY_CONFIG, WO_STATUS_CONFIG } from '@/types/workorders'
import client from '@/api/client'
import axios from 'axios'
import { useOfflineStore } from '@/stores/offline'

const authStore = useAuthStore()
const aiStore = useAIStore()
const router = useRouter()
const offlineStore = useOfflineStore()

const today = new Date().toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })

const greeting = computed(() => `Bienvenido, ${authStore.user?.full_name ?? ''}`)
const roleDescription = computed(() => {
  const role = authStore.user?.role
  if (role === 'admin') return 'Panel administrativo del sistema'
  if (role === 'supervisor') return 'Resumen operativo de tus nodos asignados'
  if (role === 'technician' || role === 'operator') return 'Resumen de tus tareas y equipos'
  if (role === 'warehouse') return 'Estado del inventario'
  if (role === 'auditor') return 'Vista general del sistema'
  return ''
})

const health = ref({ db: 'unknown', redis: 'unknown', ollama: false })
const stats = ref({
  wos_active: 0, wos_pending: 0, wos_critical: 0, overdue: 0,
  low_stock: 0, verif_pending: 0,
  total_nodes: 0, total_equipment: 0, critical_nodes: 0,
})
const recentWOs = ref<any[]>([])
const lowStockParts = ref<any[]>([])
const upcomingMaint = ref<any[]>([])
const loadingWOs = ref(true)
const complianceRate = ref(0)
const activeMaintenancePlans = ref(0)

function navigateToWO(wo: any) {
  if (authStore.isManager) {
    router.push(`/work-orders?search=${encodeURIComponent(wo.wo_number)}`)
  } else {
    router.push('/factory')
  }
}

const PRIORITY_SORT_ORDER: Record<string, number> = {
  critical: 0,
  high: 1,
  medium: 2,
  low: 3,
}

function sortByPriority(wos: any[]): any[] {
  return [...wos].sort((a, b) => {
    const pa = PRIORITY_SORT_ORDER[a.priority] ?? 9
    const pb = PRIORITY_SORT_ORDER[b.priority] ?? 9
    return pa - pb
  })
}

onMounted(async () => {
  // Health + compliance (admin only)
  if (authStore.isAdmin) {
    try {
      const { data } = await axios.get('/api/v1/health')
      health.value = {
        db: data.services?.database ?? 'unknown',
        redis: data.services?.redis ?? 'unknown',
        ollama: aiStore.status?.ollama_available ?? false
      }
    } catch { /* silent */ }
    await aiStore.loadStatus()
    health.value.ollama = aiStore.status?.ollama_available ?? false

    // Compliance rate and active plans
    try {
      const { data } = await client.get('/maintenance-plans/compliance')
      complianceRate.value = Math.round(data.compliance_rate ?? data.rate ?? 0)
    } catch { /* silent */ }
    try {
      const { data } = await client.get('/maintenance-plans')
      const plans = data.plans ?? data.maintenance_plans ?? []
      activeMaintenancePlans.value = plans.filter((p: any) => p.status !== 'inactive' && p.status !== 'deleted').length
    } catch { /* silent */ }
  }

  // WOs (every role - the backend filters by scope)
  try {
    let all: any[]
    if (!navigator.onLine) {
      all = await offlineStore.getWorkOrders()
    } else {
      const d = await workOrdersApi.list({})
      all = d.work_orders ?? []
    }

    if (authStore.isFieldWorker) {
      const myActive = all.filter((w: any) => ['assigned', 'in_progress'].includes(w.status))
      recentWOs.value = sortByPriority(myActive).slice(0, 8)
    } else {
      recentWOs.value = all.slice(0, 8)
    }

    stats.value.wos_active = all.filter((w: any) => ['assigned', 'in_progress'].includes(w.status)).length
    stats.value.wos_pending = all.filter((w: any) => w.status === 'pending').length
    stats.value.wos_critical = all.filter((w: any) => w.priority === 'critical' && !['closed', 'cancelled', 'verified'].includes(w.status)).length
    stats.value.overdue = all.filter((w: any) =>
      w.planned_end && new Date(w.planned_end) < new Date() &&
      !['completed', 'verified', 'closed', 'cancelled'].includes(w.status)
    ).length
  } catch {
    const all = await offlineStore.getWorkOrders()
    if (authStore.isFieldWorker) {
      const myActive = all.filter(w => ['assigned', 'in_progress'].includes(w.status))
      recentWOs.value = sortByPriority(myActive).slice(0, 8)
    } else {
      recentWOs.value = all.slice(0, 8)
    }
    stats.value.wos_active = all.filter(w => ['assigned', 'in_progress'].includes(w.status)).length
    stats.value.wos_pending = all.filter(w => w.status === 'pending').length
  } finally { loadingWOs.value = false }

  // Low stock (supervisor + warehouse)
  if (authStore.isSupervisor || authStore.user?.role === 'warehouse') {
    try {
      const d = await sparePartsApi.list({ low_stock: true })
      lowStockParts.value = (d.spare_parts ?? []).slice(0, 5)
      stats.value.low_stock = d.total ?? 0
    } catch { /* silent */ }
  }

  // Node stats (every role - the backend filters)
  try {
    const { data } = await client.get('/factory/tree')
    const nodes: any[] = []
    const flatten = (arr: any[]) => arr.forEach(n => { nodes.push(n); if (n.children?.length) flatten(n.children) })
    flatten(data.tree ?? data.nodes ?? [])
    stats.value.total_nodes = nodes.length
    stats.value.total_equipment = nodes.filter(n => n.node_type === 'equipment').length
    stats.value.critical_nodes = nodes.filter(n => n.criticality === 'critical').length
  } catch { /* silent */ }

  // Upcoming preventive work (admin + supervisor)
  if (authStore.isManager) {
    try {
      const { data } = await client.get('/maintenance-plans/upcoming?days=14')
      upcomingMaint.value = (data.plans ?? []).slice(0, 5)
    } catch { /* silent */ }
  }
})
</script>

<style scoped>
.dashboard { display: flex; flex-direction: column; gap: var(--space-5); max-width: 1200px; }

.page-header { display: flex; align-items: flex-start; justify-content: space-between; }
.page-title { font-size: 1.3rem; font-weight: 700; color: var(--color-primary); }
.page-sub { font-size: 0.78rem; color: var(--color-text-muted); margin-top: 2px; }
.page-date { font-size: 0.72rem; color: var(--color-text-muted); margin-top: var(--space-1); }

/* KPIs */
.kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: var(--space-4); }

.kpi-card {
  background: var(--color-surface);
  border: 1px solid var(--color-border-light);
  border-radius: var(--radius-md);
  padding: var(--space-4) var(--space-5);
  display: flex; flex-direction: column; gap: 2px;
}
.kpi-value { font-size: 1.8rem; font-weight: 700; font-family: var(--font-mono); color: var(--color-primary); line-height: 1.1; }
.kpi-label { font-size: 0.78rem; font-weight: 600; color: var(--color-text); }
.kpi-sub { font-size: 0.7rem; color: var(--color-text-muted); }

.kpi-card--clickable { cursor: pointer; transition: transform 0.15s ease, box-shadow 0.15s ease; }
.kpi-card--clickable:hover { transform: translateY(-2px); box-shadow: var(--shadow-md, 0 4px 12px rgba(0,0,0,0.1)); }

.kpi-card--alert-active { border-color: rgba(233,69,96,0.3); }
.kpi-card--alert-active .kpi-value { color: var(--color-alert); }
.kpi-card--warning-active { border-color: rgba(243,156,18,0.3); }
.kpi-card--warning-active .kpi-value { color: var(--color-warning); }
.kpi-card--info-active { border-color: rgba(59,130,246,0.3); }
.kpi-card--info-active .kpi-value { color: #3B82F6; }
.kpi-card--success-active { border-color: rgba(39,174,96,0.3); }
.kpi-card--success-active .kpi-value { color: var(--color-success); }

/* Admin section grid */
.section-grid { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-4); }

/* Main grid */
.main-grid { display: grid; grid-template-columns: 1fr 320px; gap: var(--space-4); align-items: start; }
.side-col { display: flex; flex-direction: column; gap: var(--space-4); }

/* Cards */
.card { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); overflow: hidden; }
.card--warning { border-color: rgba(243,156,18,0.3); }
.card-header { display: flex; align-items: center; justify-content: space-between; padding: var(--space-3) var(--space-4); border-bottom: 1px solid var(--color-border-light); }
.card-title { font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--color-text-muted); }
.card-link { font-size: 0.72rem; color: var(--color-accent); text-decoration: none; }
.card-link:hover { text-decoration: underline; }
.card-loading { padding: var(--space-4); font-size: 0.8rem; color: var(--color-text-muted); text-align: center; }
.card-empty { padding: var(--space-4); font-size: 0.8rem; color: var(--color-text-muted); text-align: center; }

/* Recent WOs */
.wo-list { display: flex; flex-direction: column; }
.wo-item { display: flex; align-items: center; justify-content: space-between; padding: var(--space-3) var(--space-4); border-bottom: 1px solid var(--color-border-light); cursor: pointer; transition: background var(--transition); }
.wo-item:last-child { border-bottom: none; }
.wo-item:hover { background: var(--color-surface-2); }
.wo-item-left { display: flex; flex-direction: column; gap: 1px; min-width: 0; }
.wo-number { font-size: 0.66rem; color: var(--color-text-muted); }
.wo-title { font-size: 0.8rem; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 300px; }
.wo-node { font-size: 0.7rem; }
.wo-item-right { display: flex; align-items: center; gap: var(--space-2); flex-shrink: 0; }
.priority-dot { width: 7px; height: 7px; border-radius: 50%; flex-shrink: 0; }
.status-pill { font-size: 0.68rem; font-weight: 600; padding: 2px 8px; border-radius: 20px; white-space: nowrap; }
.status-pill.small { font-size: 0.66rem; }

/* System status */
.status-list { display: flex; flex-direction: column; padding: var(--space-3) var(--space-4); gap: var(--space-3); }
.status-row { display: flex; align-items: center; gap: var(--space-3); }
.status-dot { width: 7px; height: 7px; border-radius: 50%; flex-shrink: 0; }
.status-dot.ok { background: var(--color-success); }
.status-dot.error { background: var(--color-alert); }
.status-label { flex: 1; font-size: 0.8rem; color: var(--color-text); }
.status-val { font-size: 0.72rem; color: var(--color-text-muted); }

/* Nodes */
.node-stats { display: grid; grid-template-columns: repeat(3, 1fr); padding: var(--space-4); gap: var(--space-3); }
.node-stat { display: flex; flex-direction: column; align-items: center; gap: 2px; }
.node-stat-value { font-size: 1.3rem; font-weight: 700; font-family: var(--font-mono); color: var(--color-primary); }
.node-stat-label { font-size: 0.66rem; color: var(--color-text-muted); text-align: center; }
.alert-val { color: var(--color-alert) !important; }

/* Upcoming preventive work */
.maint-list { display: flex; flex-direction: column; }
.maint-item { display: flex; align-items: center; justify-content: space-between; padding: var(--space-3) var(--space-4); border-bottom: 1px solid var(--color-border-light); }
.maint-item:last-child { border-bottom: none; }
.maint-info { display: flex; flex-direction: column; gap: 1px; min-width: 0; flex: 1; }
.maint-title { font-size: 0.8rem; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.maint-node { font-size: 0.7rem; }
.maint-days { font-size: 0.78rem; font-weight: 600; flex-shrink: 0; margin-left: var(--space-3); }

/* Low stock */
.low-stock-list { display: flex; flex-direction: column; }
.low-stock-item { display: flex; align-items: center; gap: var(--space-3); padding: var(--space-2) var(--space-4); border-bottom: 1px solid var(--color-border-light); }
.low-stock-item:last-child { border-bottom: none; }
.ls-code { font-size: 0.66rem; color: var(--color-text-muted); width: 80px; flex-shrink: 0; }
.ls-name { flex: 1; font-size: 0.76rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.ls-stock { font-size: 0.76rem; flex-shrink: 0; }

/* Quick access */
.quick-actions { display: flex; flex-direction: column; padding: var(--space-3); gap: var(--space-2); }
.quick-action-btn {
  display: flex; align-items: center; gap: var(--space-3);
  padding: var(--space-3) var(--space-4);
  background: var(--color-surface-2); border-radius: var(--radius);
  text-decoration: none; color: var(--color-text);
  font-size: 0.82rem; font-weight: 500;
  transition: background var(--transition);
}
.quick-action-btn:hover { background: var(--color-border-light); text-decoration: none; }
.qa-icon { font-size: 0.9rem; width: 18px; text-align: center; color: var(--color-accent); }

.mono { font-family: var(--font-mono); }
.text-muted { color: var(--color-text-muted); }

/* Responsive */
@media (max-width: 768px) {
  .kpi-grid { grid-template-columns: repeat(2, 1fr); }
  .section-grid { grid-template-columns: 1fr; }
  .main-grid { grid-template-columns: 1fr; }
  .page-title { font-size: 1.15rem; }
}
@media (max-width: 480px) {
  .kpi-grid { grid-template-columns: 1fr; }
}
</style>
