<template>
  <div class="wo-page">
    <!-- ─── Directory panel ─────────────────────────────────────────── -->
    <DirectoryPanel
      section="work_orders"
      :selected-id="selectedDirId"
      @select="onDirSelect"
      @item-dropped="onItemSaved"
    />

    <!-- ─── Main content ──────────────────────────────────────────── -->
    <div class="wo-content">
      <div class="page-header">
        <div>
          <h1 class="page-title">
            Órdenes de Trabajo
            <span v-if="selectedDirName" class="page-title-dir">/ {{ selectedDirName }}</span>
          </h1>
          <p class="page-sub">{{ total }} órdenes</p>
        </div>
        <div class="header-actions">
          <ExportButton :options="reportsApi.getWOsExportOptions()" />
          <div class="view-toggle">
            <button class="view-toggle-btn" :class="{ 'view-toggle-btn--active': viewMode === 'table' }" @click="viewMode = 'table'" title="Vista tabla">&#x2261;</button>
            <button class="view-toggle-btn" :class="{ 'view-toggle-btn--active': viewMode === 'kanban' }" @click="viewMode = 'kanban'" title="Vista kanban">&#x25A6;</button>
          </div>
          <button class="btn-primary" @click="openCreateModal" :disabled="!canWrite">+ Nueva OT</button>
        </div>
      </div>

      <!-- Quick filters (smart filters) -->
      <div class="smart-filters">
        <button
          v-for="sf in smartFilters" :key="sf.id"
          class="smart-chip"
          :class="{ 'smart-chip--active': activeSmartFilter === sf.id }"
          @click="applySmartFilter(sf)">
          {{ sf.label }}
          <span v-if="sf.count !== undefined && sf.count > 0" class="smart-chip-count">{{ sf.count }}</span>
        </button>
      </div>

      <!-- Advanced filters -->
      <div class="filters-bar">
        <select v-model="filters.status" class="filter-select" @change="loadWOs">
          <option value="">Todos los estados</option>
          <option v-for="(cfg, key) in WO_STATUS_CONFIG" :key="key" :value="key">{{ cfg.label }}</option>
        </select>
        <select v-model="filters.type" class="filter-select" @change="loadWOs">
          <option value="">Todos los tipos</option>
          <option v-for="(cfg, key) in WO_TYPE_CONFIG" :key="key" :value="key">{{ cfg.label }}</option>
        </select>
        <select v-model="filters.priority" class="filter-select" @change="loadWOs">
          <option value="">Todas las prioridades</option>
          <option v-for="(cfg, key) in WO_PRIORITY_CONFIG" :key="key" :value="key">{{ cfg.label }}</option>
        </select>
        <button class="btn-ghost" @click="clearFilters">Limpiar</button>
      </div>

      <!-- Table (desktop) -->
      <div v-if="viewMode === 'table' || isMobile" class="wo-table-desktop table-wrap">
        <div v-if="loading" class="table-empty">Cargando...</div>
        <EmptyState
          v-else-if="!displayedWOs.length"
          icon="◇"
          :title="emptyTitle"
          :hint="emptyHint"
          :action="canWrite ? '+ Nueva OT' : undefined"
          @action="openCreateModal" />
        <table v-else class="wo-table">
          <thead>
            <tr>
              <th v-if="isManager" class="check-col" @click.stop>
                <input
                  type="checkbox"
                  :checked="allSelected"
                  :indeterminate.prop="someSelected && !allSelected"
                  @change="toggleSelectAll" />
              </th>
              <th>Número</th>
              <th>Título</th>
              <th>Equipo</th>
              <th>Tipo</th>
              <th>Prioridad</th>
              <th>Estado</th>
              <th>Asignado</th>
              <th>Creada</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(wo, idx) in displayedWOs" :key="wo.id"
              class="wo-row"
              :class="{ 'wo-row--highlight': highlightIndex === idx, 'wo-row--selected': selectedIds.has(wo.id) }"
              :data-wo-row="wo.id"
              @click="openDetail(wo)"
              draggable="true" @dragstart="(e) => startDrag(e, 'work_order', wo.id)">
              <td v-if="isManager" class="check-col" @click.stop>
                <input
                  type="checkbox"
                  :checked="selectedIds.has(wo.id)"
                  @change="toggleSelect(wo.id)" />
              </td>
              <td class="mono small">{{ wo.wo_number }}</td>
              <td class="wo-title-cell">{{ wo.title }}</td>
              <td class="text-muted small">{{ wo.node_name }}</td>
              <td class="small">{{ WO_TYPE_CONFIG[wo.wo_type]?.label }}</td>
              <td @click.stop>
                <InlinePicker
                  :model-value="wo.priority"
                  :options="priorityOptions"
                  :readonly="!isManager || rowSaving === wo.id"
                  :saving="rowSaving === wo.id"
                  @change="(v) => quickEditPriority(wo, v as any)" />
              </td>
              <td>
                <span class="status-pill"
                  :style="{ color: WO_STATUS_CONFIG[wo.status]?.color, background: WO_STATUS_CONFIG[wo.status]?.color + '15' }">
                  {{ WO_STATUS_CONFIG[wo.status]?.label }}
                </span>
              </td>
              <td class="text-muted small" @click.stop>
                <InlinePicker
                  :model-value="wo.assigned_to ?? null"
                  :options="assigneeOptions"
                  :readonly="!isManager || ['closed','cancelled'].includes(wo.status) || rowSaving === wo.id"
                  :saving="rowSaving === wo.id"
                  placeholder="Sin asignar"
                  @change="(v) => quickEditAssignee(wo, v as any)" />
              </td>
              <td class="small text-muted" :title="formatDate(wo.created_at)">{{ formatSmart(wo.created_at) }}</td>
              <td @click.stop>
                <SaveToDir section="work_orders" item-type="work_order" :item-id="wo.id" @saved="onItemSaved" />
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Mobile cards -->
      <div v-if="isMobile" class="wo-mobile-cards">
        <div v-if="loading" class="table-empty">Cargando...</div>
        <EmptyState
          v-else-if="!displayedWOs.length"
          icon="◇"
          :title="emptyTitle"
          :hint="emptyHint"
          :action="canWrite ? '+ Nueva OT' : undefined"
          size="sm"
          @action="openCreateModal" />
        <div v-else v-for="wo in displayedWOs" :key="'m-'+wo.id" class="wo-mcard" @click="openDetail(wo)">
          <div class="wo-mcard-top">
            <span class="wo-mcard-number mono">{{ wo.wo_number }}</span>
            <span class="priority-pill"
              :style="{ color: WO_PRIORITY_CONFIG[wo.priority]?.color, background: WO_PRIORITY_CONFIG[wo.priority]?.color + '15' }">
              {{ WO_PRIORITY_CONFIG[wo.priority]?.label }}
            </span>
          </div>
          <div class="wo-mcard-title">{{ wo.title }}</div>
          <div class="wo-mcard-meta">
            <span class="wo-mcard-node">{{ wo.node_name }}</span>
            <span class="wo-mcard-type">{{ WO_TYPE_CONFIG[wo.wo_type]?.label }}</span>
          </div>
          <div class="wo-mcard-bottom">
            <span class="status-pill"
              :style="{ color: WO_STATUS_CONFIG[wo.status]?.color, background: WO_STATUS_CONFIG[wo.status]?.color + '15' }">
              {{ WO_STATUS_CONFIG[wo.status]?.label }}
            </span>
            <span v-if="wo.assigned_name" class="wo-mcard-assign">{{ wo.assigned_name }}</span>
            <span v-else class="wo-mcard-assign text-muted">Sin asignar</span>
          </div>
        </div>
      </div>

      <!-- Kanban -->
      <div v-else class="kanban-board">
        <div v-if="loading" class="table-empty" style="width:100%">Cargando...</div>
        <template v-else>
          <div v-for="col in kanbanColumns" :key="col.status" class="kanban-column">
            <div class="kanban-header" :style="{ borderBottomColor: col.color }">
              <span class="kanban-header-label">{{ col.label }}</span>
              <span class="kanban-header-count" :style="{ background: col.color + '18', color: col.color }">{{ col.items.length }}</span>
            </div>
            <div class="kanban-body">
              <div v-if="!col.items.length" class="kanban-empty">Sin órdenes</div>
              <div v-for="wo in col.items" :key="wo.id" class="kanban-card" @click="openDetail(wo)">
                <div class="kanban-card-number mono">{{ wo.wo_number }}</div>
                <div class="kanban-card-title">{{ wo.title }}</div>
                <div class="kanban-card-footer">
                  <span class="kanban-card-priority"
                    :style="{ background: WO_PRIORITY_CONFIG[wo.priority]?.color }"
                    :title="WO_PRIORITY_CONFIG[wo.priority]?.label"></span>
                  <span class="kanban-card-node text-muted">{{ wo.node_name }}</span>
                  <span v-if="wo.assigned_name" class="kanban-card-assign text-muted">{{ wo.assigned_name }}</span>
                </div>
              </div>
            </div>
          </div>
        </template>
      </div>
    </div>

    <!-- ─── Floating bulk action bar ──────────────────────────── -->
    <Teleport to="body">
      <Transition name="bulkbar-slide">
        <div v-if="selectedIds.size > 0" class="bulkbar">
          <span class="bulkbar-count">{{ selectedIds.size }} OT{{ selectedIds.size > 1 ? 's' : '' }} seleccionada{{ selectedIds.size > 1 ? 's' : '' }}</span>
          <div class="bulkbar-actions">
            <select v-model="bulkPriorityValue" class="bulkbar-select" :disabled="bulkRunning">
              <option value="">Cambiar prioridad...</option>
              <option v-for="p in priorityOptions" :key="p.value" :value="p.value">{{ p.label }}</option>
            </select>
            <button class="bulkbar-btn" :disabled="!bulkPriorityValue || bulkRunning" @click="bulkApplyPriority">Aplicar</button>

            <select v-model="bulkAssigneeValue" class="bulkbar-select" :disabled="bulkRunning">
              <option value="__none">Reasignar a...</option>
              <option :value="null">Sin asignar</option>
              <option v-for="t in availableTechnicians" :key="t.id" :value="t.id">{{ t.full_name }}</option>
            </select>
            <button class="bulkbar-btn" :disabled="bulkAssigneeValue === '__none' || bulkRunning" @click="bulkApplyAssignee">Aplicar</button>

            <button class="bulkbar-btn bulkbar-btn--danger" :disabled="bulkRunning" @click="bulkCancel">Cancelar OTs</button>
          </div>
          <button class="bulkbar-close" @click="clearSelection" aria-label="Cerrar">✕</button>
        </div>
      </Transition>
    </Teleport>

    <!-- ─── WO detail modal ──────────────────────────────────────────────── -->
    <Teleport to="body">
      <div v-if="selectedWO" class="modal-overlay" @click.self="selectedWO = null">
        <div class="detail-modal" :class="{ 'detail-modal--loading': detailLoading }">
          <div v-if="detailLoading" class="detail-loading-bar"></div>
          <div class="detail-header">
            <div>
              <div class="mono small text-muted">{{ selectedWO.work_order.wo_number }}</div>
              <h2 class="detail-title">{{ selectedWO.work_order.title }}</h2>
              <div class="detail-meta">
                <span class="status-pill"
                  :style="{ color: WO_STATUS_CONFIG[selectedWO.work_order.status]?.color, background: WO_STATUS_CONFIG[selectedWO.work_order.status]?.color + '15' }">
                  {{ WO_STATUS_CONFIG[selectedWO.work_order.status]?.label }}
                </span>
                <span class="meta-sep">·</span>
                <span class="small">{{ selectedWO.work_order.node_name }}</span>
                <span class="meta-sep">·</span>
                <span :style="{ color: WO_PRIORITY_CONFIG[selectedWO.work_order.priority]?.color }">
                  {{ WO_PRIORITY_CONFIG[selectedWO.work_order.priority]?.label }}
                </span>
              </div>
            </div>
            <button class="modal-close" @click="selectedWO = null">&#x2715;</button>
          </div>

          <!-- Visual workflow stepper -->
          <div class="wo-stepper">
            <template v-if="!specialStatuses.includes(selectedWO.work_order.status)">
              <template v-for="(step, idx) in stepperStatuses" :key="step">
                <div class="step-item">
                  <div class="step-dot"
                    :class="{
                      'step-dot--completed': getStepState(selectedWO.work_order.status, step) === 'completed',
                      'step-dot--current': getStepState(selectedWO.work_order.status, step) === 'current',
                      'step-dot--future': getStepState(selectedWO.work_order.status, step) === 'future',
                    }"></div>
                  <span class="step-label" :class="{
                    'step-label--current': getStepState(selectedWO.work_order.status, step) === 'current'
                  }">{{ stepperLabels[step] }}</span>
                </div>
                <div v-if="idx < stepperStatuses.length - 1" class="step-line"
                  :class="{ 'step-line--done': getStepState(selectedWO.work_order.status, stepperStatuses[idx + 1]) !== 'future' }"></div>
              </template>
            </template>
            <template v-else>
              <!-- Special status: show mini stepper grayed + special badge -->
              <template v-for="(step, idx) in stepperStatuses" :key="step">
                <div class="step-item">
                  <div class="step-dot step-dot--future"></div>
                  <span class="step-label">{{ stepperLabels[step] }}</span>
                </div>
                <div v-if="idx < stepperStatuses.length - 1" class="step-line"></div>
              </template>
            </template>
          </div>
          <div v-if="specialStatuses.includes(selectedWO.work_order.status)" class="stepper-special-badge"
            :style="{ color: WO_STATUS_CONFIG[selectedWO.work_order.status]?.color, background: WO_STATUS_CONFIG[selectedWO.work_order.status]?.color + '15', borderColor: WO_STATUS_CONFIG[selectedWO.work_order.status]?.color + '40' }">
            {{ WO_STATUS_CONFIG[selectedWO.work_order.status]?.label }}
          </div>

          <div class="status-actions">
            <span v-if="transitions.length" class="status-actions-label">Acciones:</span>
            <button v-for="t in transitions" :key="t.to" class="btn-transition" @click="doTransition(t)" :disabled="!canWrite">
              {{ t.label }}
            </button>
            <button v-if="isManager" class="btn-pdf" @click="openPDF(selectedWO.work_order.id)">PDF</button>
            <button v-if="isSupervisor && selectedWO.work_order.assigned_name"
              class="btn-score" @click="openScore(selectedWO.work_order)" :disabled="!canWrite">Puntuar</button>
            <button v-if="selectedWO.work_order.wo_type === 'corrective' && !selectedWO.work_order.root_cause"
              class="btn-suggest" @click="getSuggestion(selectedWO.work_order.id)">
              &#x25C8; Diagnosticar con IA
            </button>
          </div>

          <div class="detail-tabs">
            <button v-for="tab in detailTabs" :key="tab.id" class="detail-tab"
              :class="{ 'detail-tab--active': activeDetailTab === tab.id }"
              @click="activeDetailTab = tab.id">{{ tab.label }}</button>
          </div>

          <div class="detail-body">
            <div v-if="activeDetailTab === 'info'" class="detail-info">
              <div class="info-grid-2">
                <div class="info-block"><span class="info-label">Tipo</span><span>{{ WO_TYPE_CONFIG[selectedWO.work_order.wo_type]?.label }}</span></div>
                <div class="info-block">
                  <span class="info-label">Asignado a</span>
                  <template v-if="!reassignMode">
                    <span>{{ selectedWO.work_order.assigned_name ?? 'Sin asignar' }}</span>
                    <span v-if="isManager && !['closed', 'cancelled'].includes(selectedWO.work_order.status)" class="assign-actions">
                      <button class="btn-ghost small" @click="openReassign">&#x25C8; Cambiar</button>
                      <button v-if="selectedWO.work_order.assigned_to" class="btn-ghost small text-muted" @click="unassignTechnician">Desasignar</button>
                    </span>
                    <button v-if="!selectedWO.work_order.assigned_to && !isManager && (authStore.user?.role === 'technician' || authStore.user?.role === 'operator')"
                      class="btn-ghost small" @click="selfAssign">Tomar OT</button>
                  </template>
                  <template v-else>
                    <select v-model="reassignUserId" class="field-input field-input--inline">
                      <option :value="null">Sin asignar</option>
                      <option v-for="t in availableTechnicians" :key="t.id" :value="t.id">{{ t.full_name }} ({{ t.role }})</option>
                    </select>
                    <button class="btn-primary small" :disabled="reassigning" @click="confirmReassign">{{ reassigning ? '...' : 'Confirmar' }}</button>
                    <button class="btn-ghost small" @click="reassignMode = false">Cancelar</button>
                  </template>
                </div>
                <div v-if="!reassignMode && !selectedWO.work_order.assigned_to && isManager" class="tech-suggest-row">
                  <button class="btn-ghost small" :disabled="loadingSuggestTech" @click="suggestTechnician(selectedWO.work_order.id)">
                    {{ loadingSuggestTech ? 'Buscando...' : '◈ Sugerir técnico (IA)' }}
                  </button>
                </div>
                <div v-if="techSuggestions.length" class="tech-suggestions">
                  <div v-for="s in techSuggestions" :key="s.user_id" class="tech-sug-row" :class="{ 'tech-sug-match': s.matching_tags }">
                    <span class="tech-sug-name">{{ s.full_name }}</span>
                    <span v-if="s.avg_score" class="tech-sug-score">★ {{ s.avg_score }}</span>
                    <span class="tech-sug-load text-muted small">{{ s.current_load }} OTs activas</span>
                    <button class="btn-ghost small" @click="assignTechnician(selectedWO.work_order.id, s.user_id)">Asignar</button>
                  </div>
                </div>
                <div class="info-block"><span class="info-label">Horas est.</span><span class="mono">{{ selectedWO.work_order.estimated_hours ?? '—' }}</span></div>
                <div class="info-block"><span class="info-label">Tiempo trabajado</span><span class="mono">{{ formatWorkedTime(selectedWO.work_order.accumulated_minutes) }}</span></div>
                <div v-if="selectedWO.work_order.hours_edited_by_name" class="info-block info-block--alert"><span class="info-label">Horas editadas por</span><span class="mono">{{ selectedWO.work_order.hours_edited_by_name }}</span></div>
                <div class="info-block"><span class="info-label">Inicio planif.</span><span class="mono small">{{ formatDate(selectedWO.work_order.planned_start) }}</span></div>
                <div class="info-block"><span class="info-label">Fin planif.</span><span class="mono small">{{ formatDate(selectedWO.work_order.planned_end) }}</span></div>
              </div>
              <div v-if="selectedWO.work_order.description" class="desc-block">
                <span class="info-label">Descripción</span>
                <p>{{ selectedWO.work_order.description }}</p>
              </div>
              <div v-if="selectedWO.work_order.root_cause_code || selectedWO.work_order.root_cause" class="desc-block">
                <span class="info-label">Causa raíz</span>
                <p>
                  <span v-if="selectedWO.work_order.root_cause_code" class="root-cause-badge">{{ rootCauseLabel(selectedWO.work_order.root_cause_code) }}</span>
                  <span v-if="selectedWO.work_order.root_cause">{{ selectedWO.work_order.root_cause }}</span>
                </p>
              </div>
              <div v-if="selectedWO.work_order.solution" class="desc-block">
                <span class="info-label">Solución</span><p>{{ selectedWO.work_order.solution }}</p>
              </div>
              <div v-if="signaturesInfo" class="desc-block">
                <span class="info-label">Firmas digitales</span>
                <div class="signatures-info">
                  <div v-if="signaturesInfo.signed_by" class="sig-row sig-row--ok">
                    <span class="sig-icon">✓</span>
                    <div class="sig-detail">
                      <span class="sig-name">{{ signaturesInfo.signed_by_name }}</span>
                      <span class="sig-role">Ejecutor</span>
                    </div>
                    <span class="mono small text-muted">{{ formatDate(signaturesInfo.signed_at) }}</span>
                  </div>
                  <div v-else class="sig-row sig-row--pending">
                    <span class="sig-icon">○</span>
                    <span class="sig-pending">Pendiente — se firma al completar la OT</span>
                  </div>
                  <div v-if="signaturesInfo.supervisor_signed_by" class="sig-row sig-row--ok">
                    <span class="sig-icon">✓</span>
                    <div class="sig-detail">
                      <span class="sig-name">{{ signaturesInfo.supervisor_signed_name }}</span>
                      <span class="sig-role">Supervisor</span>
                    </div>
                    <span class="mono small text-muted">{{ formatDate(signaturesInfo.supervisor_signed_at) }}</span>
                  </div>
                  <div v-else class="sig-row sig-row--pending">
                    <span class="sig-icon">○</span>
                    <span class="sig-pending">Pendiente — se firma al cerrar la OT</span>
                  </div>
                </div>
              </div>
            </div>

            <!-- Photographic evidence (before / after) -->
            <div v-else-if="activeDetailTab === 'evidence'" class="evidence-section">
              <div v-if="photosLoading" class="loading-inline">Cargando evidencia...</div>
              <div v-else class="evidence-grid">
                <!-- BEFORE -->
                <div class="evidence-col">
                  <div class="evidence-col-head">
                    <span class="evidence-col-title">◷ Antes</span>
                    <label v-if="canWrite" class="evidence-add">
                      {{ photoUploading === 'before' ? 'Subiendo...' : '+ Añadir foto' }}
                      <input
                        type="file"
                        accept="image/*"
                        capture="environment"
                        :disabled="photoUploading !== null"
                        @change="(e) => uploadPhoto('before', e)" />
                    </label>
                  </div>
                  <div v-if="!photoBefore.length" class="section-empty small">Sin fotos del estado inicial.</div>
                  <div v-else class="evidence-thumbs">
                    <a
                      v-for="p in photoBefore"
                      :key="p.id"
                      class="evidence-thumb"
                      :href="`/api/v1/library/${p.id}/download`"
                      target="_blank"
                      :title="`${p.original_name} · ${p.uploaded_by ?? 'Sistema'}`">
                      <span class="evidence-thumb-name">{{ p.original_name }}</span>
                      <span class="evidence-thumb-meta small text-muted">{{ formatSmart(p.created_at) }}</span>
                    </a>
                  </div>
                </div>
                <!-- AFTER -->
                <div class="evidence-col">
                  <div class="evidence-col-head">
                    <span class="evidence-col-title">✓ Después</span>
                    <label v-if="canWrite" class="evidence-add">
                      {{ photoUploading === 'after' ? 'Subiendo...' : '+ Añadir foto' }}
                      <input
                        type="file"
                        accept="image/*"
                        capture="environment"
                        :disabled="photoUploading !== null"
                        @change="(e) => uploadPhoto('after', e)" />
                    </label>
                  </div>
                  <div v-if="!photoAfter.length" class="section-empty small">Sin fotos del estado final.</div>
                  <div v-else class="evidence-thumbs">
                    <a
                      v-for="p in photoAfter"
                      :key="p.id"
                      class="evidence-thumb"
                      :href="`/api/v1/library/${p.id}/download`"
                      target="_blank"
                      :title="`${p.original_name} · ${p.uploaded_by ?? 'Sistema'}`">
                      <span class="evidence-thumb-name">{{ p.original_name }}</span>
                      <span class="evidence-thumb-meta small text-muted">{{ formatSmart(p.created_at) }}</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <!-- Procedures (SOP) -->
            <div v-else-if="activeDetailTab === 'procedures'" class="procedures-section">
              <div v-if="loadingProcedures" class="loading-inline">Cargando procedimientos...</div>
              <template v-else>
                <div v-if="woProcedures.length === 0 && !activeExecId" class="section-empty">
                  <p>No hay procedimientos asignados a esta OT.</p>
                  <div v-if="procSuggestions.length > 0" class="proc-suggestions">
                    <span class="proc-suggestions-title">Procedimientos sugeridos:</span>
                    <div v-for="s in procSuggestions" :key="s.id" class="proc-suggestion" @click="startProcedure(s.id)">
                      <span class="proc-suggestion-title">{{ s.title }}</span>
                      <span class="proc-suggestion-meta">{{ s.step_count }} pasos · {{ s.category }}</span>
                    </div>
                  </div>
                </div>
                <div v-for="p in woProcedures" :key="p.id" class="proc-card">
                  <div class="proc-card-header">
                    <span class="proc-card-title">{{ p.title }}</span>
                    <span :class="['proc-status', 'proc-status--' + p.status]">{{ p.status === 'completed' ? 'Completado' : p.status === 'in_progress' ? 'En progreso' : p.status }}</span>
                  </div>
                  <div class="proc-card-progress">
                    <div class="proc-card-bar"><div class="proc-card-fill" :style="{ width: (p.total_steps ? (p.completed_steps / p.total_steps) * 100 : 0) + '%' }"></div></div>
                    <span class="proc-card-count">{{ p.completed_steps }}/{{ p.total_steps }}</span>
                  </div>
                  <button v-if="p.status === 'in_progress'" class="sop-btn sop-btn--primary" @click="activeExecId = p.id">Continuar</button>
                </div>
                <ProcedureWizard v-if="activeExecId" :execution-id="activeExecId" @completed="onProcedureCompleted" @step-submitted="onStepSubmitted" />
              </template>
            </div>

            <!-- Work log (intervals) -->
            <div v-else-if="activeDetailTab === 'intervals'" class="intervals-section">
              <div v-if="loadingIntervals" class="loading-inline">Cargando registro...</div>
              <div v-else-if="!woIntervals.length" class="section-empty">No hay registro de trabajo aún. El cronómetro se inicia al presionar "Comenzar".</div>
              <template v-else>
                <table class="intervals-table">
                  <thead>
                    <tr><th>Inicio</th><th>Fin</th><th>Duración</th><th>Motivo fin</th></tr>
                  </thead>
                  <tbody>
                    <tr v-for="iv in woIntervals" :key="iv.id" :class="{ 'interval-active': !iv.ended_at }">
                      <td class="mono small">{{ formatDateTime(iv.started_at) }}</td>
                      <td class="mono small">{{ iv.ended_at ? formatDateTime(iv.ended_at) : 'En curso...' }}</td>
                      <td class="mono">{{ formatDurationMinutes(iv.duration_minutes) }}</td>
                      <td>
                        <span v-if="!iv.ended_at" class="badge-interval badge-interval--active">En curso</span>
                        <span v-else-if="iv.ended_reason === 'paused'" class="badge-interval badge-interval--paused">Pausado</span>
                        <span v-else-if="iv.ended_reason === 'completed'" class="badge-interval badge-interval--completed">Completado</span>
                        <span v-else>—</span>
                      </td>
                    </tr>
                  </tbody>
                </table>
                <div class="intervals-total">
                  <span class="intervals-total-label">Tiempo total trabajado:</span>
                  <span class="intervals-total-value mono">{{ intervalsTotalHours }}</span>
                </div>
              </template>
            </div>

            <div v-else-if="activeDetailTab === 'log'" class="log-list">
              <div v-for="entry in selectedWO.log" :key="entry.id" class="log-entry">
                <div class="log-dot"></div>
                <div class="log-content">
                  <div class="log-transition">
                    <span v-if="entry.from_status" class="log-status old">{{ WO_STATUS_CONFIG[entry.from_status]?.label }}</span>
                    <span v-if="entry.from_status" class="log-arrow">→</span>
                    <span class="log-status new" :style="{ color: WO_STATUS_CONFIG[entry.to_status]?.color }">{{ WO_STATUS_CONFIG[entry.to_status]?.label }}</span>
                  </div>
                  <p v-if="entry.comment" class="log-comment">{{ entry.comment }}</p>
                  <div class="log-meta"><span>{{ entry.user_name ?? 'Sistema' }}</span><span class="small" :title="formatDate(entry.created_at)">{{ formatSmart(entry.created_at) }}</span></div>
                </div>
              </div>
            </div>

            <div v-else-if="activeDetailTab === 'comments'" class="comments-section">
              <div class="comments-list">
                <div v-for="cm in selectedWO.comments" :key="cm.id" class="comment-item">
                  <div class="comment-avatar">{{ (cm.user_name ?? 'S')[0] }}</div>
                  <div class="comment-body">
                    <div class="comment-meta"><span class="comment-author">{{ cm.user_name ?? 'Sistema' }}</span><span class="small text-muted" :title="formatDate(cm.created_at)">{{ formatSmart(cm.created_at) }}</span></div>
                    <p class="comment-content">{{ cm.content }}</p>
                  </div>
                </div>
              </div>
              <div class="comment-form">
                <textarea v-model="newComment" class="comment-input" placeholder="Escribe un comentario..." rows="2" />
                <button class="btn-primary small" :disabled="!canWrite || !newComment.trim()" @click="submitComment">Enviar</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Create WO modal -->
    <Teleport to="body">
      <div v-if="showCreateModal" class="modal-overlay" @click.self="showCreateModal = false">
        <div class="create-modal">
          <div class="modal-header"><h3>Nueva Orden de Trabajo</h3><button class="modal-close" @click="showCreateModal = false">✕</button></div>
          <div class="modal-body">
            <div class="field"><label class="field-label">Título *</label><input v-model="createForm.title" class="field-input" /></div>
            <div class="field">
              <label class="field-label">Equipo / Nodo *</label>
              <div class="node-search-wrap">
                <input
                  v-model="nodeSearchQ"
                  class="field-input"
                  placeholder="Buscar nodo por nombre o código..."
                  autocomplete="off"
                  @focus="onNodeSearchFocus"
                  @blur="onNodeSearchBlur" />
                <div v-if="nodeSearchOpen && filteredCreateNodes.length" class="node-search-dropdown">
                  <div v-for="n in filteredCreateNodes" :key="n.id" class="node-search-item" @mousedown.prevent="selectCreateNode(n)">
                    <span class="node-search-name">{{ n.name }}</span>
                    <span v-if="n.code" class="node-search-code mono">{{ n.code }}</span>
                  </div>
                </div>
                <div v-if="nodeSearchOpen && nodeSearchQ && !filteredCreateNodes.length" class="node-search-dropdown">
                  <div class="node-search-empty">Sin resultados</div>
                </div>
              </div>
            </div>
            <div class="field-row">
              <div class="field"><label class="field-label">Tipo</label>
                <select v-model="createForm.wo_type" class="field-input">
                  <option v-for="(cfg, key) in WO_TYPE_CONFIG" :key="key" :value="key">{{ cfg.label }}</option>
                </select>
              </div>
              <div class="field"><label class="field-label">Prioridad</label>
                <select v-model="createForm.priority" class="field-input">
                  <option v-for="(cfg, key) in WO_PRIORITY_CONFIG" :key="key" :value="key">{{ cfg.label }}</option>
                </select>
              </div>
            </div>
            <div class="field"><label class="field-label">Descripción</label><textarea v-model="createForm.description" class="field-input" rows="3" /></div>
            <div class="field">
              <label class="field-label">Asignar a (opcional)</label>
              <select v-model="createForm.assigned_to" class="field-input">
                <option :value="null">Sin asignar — cualquiera puede tomarla</option>
                <option v-for="t in availableTechnicians" :key="t.id" :value="t.id">{{ t.full_name }} ({{ t.role }})</option>
              </select>
            </div>
            <!-- Spare part suggestions based on the node's history -->
            <div v-if="createForm.node_id && partsSuggestions.length" class="field">
              <label class="field-label">Repuestos sugeridos</label>
              <div class="parts-suggestions">
                <span
                  v-for="p in partsSuggestions"
                  :key="p.id"
                  class="parts-chip"
                  :class="{ 'parts-chip--linked': p.is_linked, 'parts-chip--history': p.in_history && !p.is_linked, 'parts-chip--lowstock': p.current_stock != null && p.min_stock != null && p.current_stock <= p.min_stock }"
                  :title="`${p.is_linked ? 'Asociado al equipo' : ''}${p.is_linked && p.in_history ? ' · ' : ''}${p.in_history ? `Usado ${p.score}× en este equipo` : ''}${p.current_stock != null && p.min_stock != null && p.current_stock <= p.min_stock ? ' · Stock bajo' : ''}`">
                  <span v-if="p.code" class="parts-chip-code mono">{{ p.code }}</span>
                  <span class="parts-chip-name">{{ p.name }}</span>
                  <span v-if="p.current_stock != null" class="parts-chip-stock">{{ p.current_stock }}{{ p.unit ?? '' }}</span>
                </span>
              </div>
              <span class="field-hint">Sugeridos por: equipo asociado o historial reciente. El técnico los confirmará al consumirlos.</span>
            </div>

            <div v-if="createError" class="modal-error">{{ createError }}</div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary" @click="showCreateModal = false">Cancelar</button>
            <button class="btn-primary" :disabled="!canWrite || creating" @click="submitCreate">{{ creating ? 'Creando...' : 'Crear OT' }}</button>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Transition modal -->
    <Teleport to="body">
      <div v-if="transitionModal" class="modal-overlay" @click.self="transitionModal = null">
        <div class="create-modal small-modal">
          <div class="modal-header"><h3>{{ transitionModal.label }}</h3><button class="modal-close" @click="transitionModal = null">✕</button></div>
          <div class="modal-body">
            <div v-if="transitionModal.to === 'completed'" class="field">
              <label class="field-label">Tipo de causa</label>
              <select v-model="transitionData.root_cause_code" class="field-input">
                <option value="">— Selecciona —</option>
                <option v-for="c in ROOT_CAUSE_CODES" :key="c.code" :value="c.code">
                  {{ c.label }}{{ c.hint ? ` — ${c.hint}` : '' }}
                </option>
              </select>
              <span class="field-hint">Clasificación estándar para métricas. Puedes detallar abajo.</span>
            </div>
            <div v-if="transitionModal.to === 'completed'" class="field"><label class="field-label">Causa raíz (descripción)</label><textarea v-model="transitionData.root_cause" class="field-input" rows="2" placeholder="Describe la causa del fallo..." /></div>
            <div v-if="transitionModal.to === 'completed'" class="field"><label class="field-label">Solución</label><textarea v-model="transitionData.solution" class="field-input" rows="2" placeholder="Describe la solución aplicada..." /></div>
            <div v-if="transitionModal.to === 'completed'" class="field"><label class="field-label">Horas reales (ajuste manual)</label><input v-model="transitionData.actual_hours_raw" class="field-input mono" placeholder="Ej: 5:30 o 5.5 — se calcula desde cronómetro" @blur="validateHoursInput" /><span class="field-hint">Formato: 5:30 (horas:minutos) o 5.5 (decimal). Si modifica este valor, quedará registrado quién lo cambió</span></div>
            <div class="field"><label class="field-label">{{ transitionModal.requireComment ? 'Comentario *' : 'Comentario (opcional)' }}</label><textarea v-model="transitionData.comment" class="field-input" rows="2" /></div>
            <div v-if="transitionError" class="modal-error">{{ transitionError }}</div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary" @click="transitionModal = null">Cancelar</button>
            <button class="btn-primary" :disabled="!canWrite || transitioning" @click="confirmTransition">{{ transitioning ? 'Procesando...' : 'Confirmar' }}</button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>

  <!-- Scoring modal -->
  <Teleport to="body">
    <div v-if="scoreModal" class="modal-overlay" @click.self="scoreModal = null">
      <div class="score-modal">
        <div class="modal-header">
          <h3>Puntuar trabajo</h3>
          <button class="modal-close" @click="scoreModal = null">✕</button>
        </div>
        <div class="modal-body">
          <p class="score-wo-info">{{ scoreModal.wo_number }} — {{ scoreModal.title }}</p>
          <div class="field">
            <label class="field-label">Puntuación del trabajo (1-5)</label>
            <div class="star-selector">
              <button v-for="n in 5" :key="n"
                class="star-btn" :class="{ 'star-btn--active': scoreForm.score >= n }"
                @click="scoreForm.score = n">★</button>
            </div>
            <p class="score-labels">
              <span>{{ ['','Deficiente','Mejorable','Aceptable','Bueno','Excelente'][scoreForm.score] }}</span>
            </p>
          </div>
          <div class="field">
            <label class="field-label">Comentario (opcional)</label>
            <textarea v-model="scoreForm.comment" class="field-input" rows="2"
              placeholder="Observaciones sobre el trabajo realizado..." />
          </div>
          <div v-if="scoreError" class="modal-error">{{ scoreError }}</div>
        </div>
        <div class="modal-footer">
          <button class="btn-secondary" @click="scoreModal = null">Cancelar</button>
          <button class="btn-primary" :disabled="!canWrite || !scoreForm.score || savingScore" @click="submitScore">
            {{ savingScore ? 'Guardando...' : 'Guardar puntuación' }}
          </button>
        </div>
      </div>
    </div>
  </Teleport>

</template>

<script setup lang="ts">
import { useToast, apiErrorMsg } from '@/composables/useToast'
import { formatDate, formatDateTime, formatSmart, formatDurationMinutes } from '@/utils/time'
const toast = useToast()
import { ref, computed, onMounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { workOrdersApi, usersApi } from '@/api/phase2'
import client from '@/api/client'
import { useAuthStore } from '@/stores/auth'
import { reportsApi } from '@/api/reports'
import ExportButton from '@/components/reports/ExportButton.vue'
import { nodesApi } from '@/api/nodes'
import { directoriesApi } from '@/api/directories'
import { useDirectoriesStore } from '@/stores/directories'
import { WO_TYPE_CONFIG, WO_PRIORITY_CONFIG, WO_STATUS_CONFIG, WO_TRANSITIONS } from '@/types/workorders'
import type { WorkOrder, WOStatus } from '@/types/workorders'
import DirectoryPanel from '@/components/directories/DirectoryPanel.vue'
import SaveToDir from '@/components/directories/SaveToDir.vue'
import EmptyState from '@/components/layout/EmptyState.vue'
import InlinePicker from '@/components/work-orders/InlinePicker.vue'
import { ROOT_CAUSE_CODES, rootCauseLabel } from '@/types/rootCause'
import { useActiveWO } from '@/composables/useActiveWO'
const { refresh: activeWORefresh } = useActiveWO()
import { useShortcuts } from '@/composables/useShortcuts'
const { registerShortcut } = useShortcuts()
import { useSystemPause } from '@/composables/useSystemPause'
import { useAIStore } from '@/stores/ai'
import { useIsMobile } from '@/composables/useIsMobile'
import { useOfflineStore } from '@/stores/offline'
import { useOffline } from '@/composables/useOffline'
import { proceduresApi } from '@/api/phase2'
import type { ProcedureExecution, ProcedureSuggestion } from '@/types/procedures'
import ProcedureWizard from '@/components/procedures/ProcedureWizard.vue'

const { canWrite } = useSystemPause()
const offlineStore = useOfflineStore()
const { isOnline } = useOffline()
const aiStore = useAIStore()
const isMobile = useIsMobile()

const workOrders = ref<WorkOrder[]>([])
const total = ref(0)
const loading = ref(false)
const filters = ref({ status: '', type: '', priority: '' })
const dirStore = useDirectoriesStore()
const authStore = useAuthStore()
const activeSmartFilter = ref<string | null>(null)

// Empty state text, chosen from the user's context and the active filters.
const emptyTitle = computed(() => {
  if (selectedDirId.value) return 'Carpeta vacía'
  if (activeSmartFilter.value === 'my_active') return 'No tienes OTs activas'
  if (activeSmartFilter.value === 'pending') return 'No hay OTs pendientes'
  if (activeSmartFilter.value === 'overdue')  return 'Ninguna OT vencida'
  if (filters.value.status || filters.value.type || filters.value.priority) {
    return 'Ningún resultado con estos filtros'
  }
  return 'No hay órdenes de trabajo'
})

const emptyHint = computed(() => {
  if (selectedDirId.value) return 'Arrastra OTs aquí o crea una nueva.'
  if (activeSmartFilter.value === 'my_active') return 'Cuando se te asigne una OT aparecerá aquí.'
  if (activeSmartFilter.value === 'overdue')  return 'Buen trabajo: todas las OTs están al día.'
  if (filters.value.status || filters.value.type || filters.value.priority) {
    return 'Prueba a limpiar los filtros o crear una nueva OT.'
  }
  return 'Crea la primera OT para empezar a trabajar.'
})

// ─── View mode: table / kanban ────────────────────────────────────────────────
const viewMode = ref<'table' | 'kanban'>('table')

// ─── Kanban columns ───────────────────────────────────────────────────────────
const kanbanStatuses = ['pending', 'assigned', 'in_progress', 'completed'] as const
const kanbanColumns = computed(() => {
  return kanbanStatuses.map(status => ({
    status,
    label: WO_STATUS_CONFIG[status]?.label ?? status,
    color: WO_STATUS_CONFIG[status]?.color ?? '#6B7280',
    items: displayedWOs.value.filter(wo => wo.status === status),
  }))
})

// ─── Visual stepper helpers ───────────────────────────────────────────────────
const stepperStatuses: WOStatus[] = ['pending', 'assigned', 'approved', 'in_progress', 'completed', 'verified', 'closed']
const stepperLabels: Record<string, string> = {
  pending: 'Pendiente', assigned: 'Asignada', approved: 'Aprobada',
  in_progress: 'En progreso', completed: 'Completada', verified: 'Verificada', closed: 'Cerrada'
}
const specialStatuses: WOStatus[] = ['draft', 'rejected', 'paused', 'cancelled']

function getStepState(currentStatus: WOStatus, stepStatus: WOStatus): 'completed' | 'current' | 'future' {
  const idx = stepperStatuses.indexOf(currentStatus)
  const stepIdx = stepperStatuses.indexOf(stepStatus)
  if (idx < 0) return 'future' // special status — all steps future
  if (stepIdx < idx) return 'completed'
  if (stepIdx === idx) return 'current'
  return 'future'
}

// ─── Node search for create form ──────────────────────────────────────────────
const nodeSearchQ = ref('')
const nodeSearchOpen = ref(false)
const selectedNodeLabel = ref('')

const filteredCreateNodes = computed(() => {
  const q = nodeSearchQ.value.toLowerCase().trim()
  if (!q) return availableNodes.value
  return availableNodes.value.filter(n =>
    n.name.toLowerCase().includes(q) || (n.code && n.code.toLowerCase().includes(q))
  )
})

function selectCreateNode(node: { id: number; name: string; code?: string }) {
  createForm.value.node_id = node.id
  selectedNodeLabel.value = node.code ? `${node.name} (${node.code})` : node.name
  nodeSearchQ.value = selectedNodeLabel.value
  nodeSearchOpen.value = false
}

function onNodeSearchFocus() {
  nodeSearchOpen.value = true
  if (nodeSearchQ.value === selectedNodeLabel.value) nodeSearchQ.value = ''
}

function onNodeSearchBlur() {
  // Delay to allow click on dropdown item
  setTimeout(() => {
    nodeSearchOpen.value = false
    if (!createForm.value.node_id) { nodeSearchQ.value = '' }
    else if (nodeSearchQ.value !== selectedNodeLabel.value) { nodeSearchQ.value = selectedNodeLabel.value }
  }, 200)
}

watch(nodeSearchQ, (val) => {
  // If user clears or changes text, reset selection
  if (val !== selectedNodeLabel.value && createForm.value.node_id) {
    createForm.value.node_id = 0
    selectedNodeLabel.value = ''
  }
})

// Smart filters: predefined quick filters
const smartFilters = computed(() => {
  const all = workOrders.value
  const userId = authStore.user?.id
  const now = new Date()
  const items: { id: string; label: string; count?: number; filter: Record<string, string> }[] = []

  // Technicians and operators: the "My active WOs" filter as the first chip
  if (authStore.isFieldWorker) {
    items.push({
      id: 'my_active', label: 'Mis OTs activas',
      count: all.filter(w => w.assigned_to === userId && !['completed', 'closed', 'cancelled', 'rejected'].includes(w.status)).length,
      filter: { assigned_to: String(userId), exclude_completed: 'true' }
    })
  }
  if (authStore.isSupervisor) {
    items.push({
      id: 'pending', label: 'Pendientes',
      count: all.filter(w => w.status === 'pending').length,
      filter: { status: 'pending' }
    })
  }
  items.push({
    id: 'my_assigned', label: 'Mis asignadas',
    count: all.filter(w => w.assigned_to === userId && !['closed', 'cancelled'].includes(w.status)).length,
    filter: { assigned_to: String(userId) }
  })
  items.push({
    id: 'in_progress', label: 'En ejecución',
    count: all.filter(w => w.status === 'in_progress').length,
    filter: { status: 'in_progress' }
  })
  items.push({
    id: 'overdue', label: 'Vencidas',
    count: all.filter(w => w.planned_end && new Date(w.planned_end) < now && !['completed', 'verified', 'closed', 'cancelled'].includes(w.status)).length,
    filter: { overdue: 'true' }
  })
  items.push({
    id: 'critical', label: 'Críticas',
    count: all.filter(w => w.priority === 'critical' && !['closed', 'cancelled'].includes(w.status)).length,
    filter: { priority: 'critical' }
  })
  if (authStore.isSupervisor) {
    items.push({
      id: 'needs_verify', label: 'Sin verificar',
      count: all.filter(w => w.status === 'completed').length,
      filter: { status: 'completed' }
    })
  }
  return items
})

function applySmartFilter(sf: { id: string; filter: Record<string, string> }) {
  if (activeSmartFilter.value === sf.id) {
    activeSmartFilter.value = null
    clearFilters()
    return
  }
  activeSmartFilter.value = sf.id
  // "My active WOs" is filtered client-side, so load them all
  if (sf.id === 'my_active') {
    filters.value = { status: '', type: '', priority: '' }
  } else {
    filters.value.status = sf.filter.status ?? ''
    filters.value.type = ''
    filters.value.priority = sf.filter.priority ?? ''
  }
  loadWOs()
}

// ─── Directories ─────────────────────────────────────────────────────────────
const selectedDirId = ref<number | null>(null)
const selectedDirName = ref<string | null>(null)
const dirItems = ref<number[]>([]) // IDs of the items in the selected folder

const dirFullItems = ref<any[]>([]) // Full items returned by the folder API

async function onDirSelect(id: number | null) {
  selectedDirId.value = id
  selectedDirName.value = null
  dirItems.value = []
  dirFullItems.value = []
  if (id === null) return
  try {
    const data = await directoriesApi.getItems(id)
    dirItems.value = data.items.map(i => i.item_id)
    dirFullItems.value = data.items
    selectedDirName.value = dirStore.findDirInSection('work_orders', id)?.name ?? null
  } catch { dirItems.value = []; dirFullItems.value = [] }
}

const displayedWOs = computed(() => {
  let result: any[]
  if (selectedDirId.value !== null) {
    const fromLoaded = workOrders.value.filter(wo => dirItems.value.includes(wo.id))
    if (fromLoaded.length === dirItems.value.length) {
      result = fromLoaded
    } else {
      const loadedIds = new Set(fromLoaded.map(wo => wo.id))
      const fromDir = dirFullItems.value
        .filter(item => !loadedIds.has(item.item_id))
        .map(item => ({
          id: item.item_id,
          wo_number: item.ref ?? '',
          title: item.name ?? '',
          status: item.status ?? '',
          priority: item.extra ?? '',
          node_name: '',
          wo_type: '',
          assigned_name: null,
          created_at: '',
        }))
      result = [...fromLoaded, ...fromDir]
    }
  } else {
    result = workOrders.value
  }

  // Client-side filter: "My active WOs"
  if (activeSmartFilter.value === 'my_active') {
    const userId = authStore.user?.id
    result = result.filter(wo =>
      wo.assigned_to === userId &&
      !['completed', 'closed', 'cancelled', 'rejected'].includes(wo.status)
    )
  }

  return result
})

function onItemSaved() {
  if (selectedDirId.value) onDirSelect(selectedDirId.value)
}

function startDrag(e: DragEvent, itemType: string, itemId: number) {
  if (!e.dataTransfer) return
  e.dataTransfer.setData('application/x-dir-item', JSON.stringify({ item_type: itemType, item_id: itemId }))
  e.dataTransfer.effectAllowed = 'copy'
}

// ─── WOs ─────────────────────────────────────────────────────────────────────
const isManager = computed(() => authStore.isManager)
const isSupervisor = computed(() => authStore.isSupervisor)

// Inline table editing: id of the row currently being saved.
const rowSaving = ref<number | null>(null)

// ─── Bulk selection ────────────────────────────────────────────────────────
const selectedIds = ref<Set<number>>(new Set())
const bulkRunning = ref(false)
const bulkPriorityValue = ref<string>('')
const bulkAssigneeValue = ref<number | string | null>('__none')

const allSelected = computed(() => {
  const list = displayedWOs.value
  return list.length > 0 && list.every(w => selectedIds.value.has(w.id))
})
const someSelected = computed(() => {
  const list = displayedWOs.value
  return list.some(w => selectedIds.value.has(w.id))
})

function toggleSelect(id: number) {
  if (selectedIds.value.has(id)) selectedIds.value.delete(id)
  else selectedIds.value.add(id)
  selectedIds.value = new Set(selectedIds.value)  // force reactivity
}
function toggleSelectAll() {
  if (allSelected.value) {
    selectedIds.value = new Set()
  } else {
    selectedIds.value = new Set(displayedWOs.value.map(w => w.id))
  }
}
function clearSelection() {
  selectedIds.value = new Set()
  bulkPriorityValue.value = ''
  bulkAssigneeValue.value = '__none'
}

// Helper: apply a transformation to every selected WO, one after another.
async function bulkApply(label: string, mutator: (wo: WorkOrder) => Partial<any>) {
  if (!selectedIds.value.size) return
  bulkRunning.value = true
  let ok = 0, fail = 0
  for (const id of Array.from(selectedIds.value)) {
    const wo = workOrders.value.find(w => w.id === id)
    if (!wo) continue
    try {
      const patch = mutator(wo)
      await workOrdersApi.update(wo.id, {
        title: wo.title,
        description: wo.description,
        priority: wo.priority,
        assigned_to: wo.assigned_to,
        estimated_hours: wo.estimated_hours,
        planned_start: wo.planned_start,
        planned_end: wo.planned_end,
        version: wo.version,
        ...patch,
      } as any)
      ok++
    } catch {
      fail++
    }
  }
  bulkRunning.value = false
  if (ok > 0) {
    toast.success(`${ok} OT${ok > 1 ? 's' : ''} ${label}`,
      fail > 0 ? { detail: `${fail} fallaron — recarga para ver el estado actual.` } : undefined)
  } else if (fail > 0) {
    toast.error(`No se pudo procesar ninguna OT`)
  }
  clearSelection()
  await loadWOs()
}

async function bulkApplyPriority() {
  const v = bulkPriorityValue.value
  if (!v) return
  await bulkApply('actualizadas', () => ({ priority: v }))
}

async function bulkApplyAssignee() {
  if (bulkAssigneeValue.value === '__none') return
  const v = bulkAssigneeValue.value as number | null
  await bulkApply('reasignadas', () => ({ assigned_to: v }))
}

async function bulkCancel() {
  if (!selectedIds.value.size) return
  if (!confirm(`¿Cancelar ${selectedIds.value.size} OT(s)? Esta acción registra el cambio en el historial.`)) return
  bulkRunning.value = true
  let ok = 0, fail = 0
  for (const id of Array.from(selectedIds.value)) {
    const wo = workOrders.value.find(w => w.id === id)
    if (!wo) continue
    try {
      await workOrdersApi.changeStatus(wo.id, {
        status: 'cancelled',
        comment: 'Cancelada masivamente',
        version: wo.version,
      } as any)
      ok++
    } catch {
      fail++
    }
  }
  bulkRunning.value = false
  if (ok > 0) toast.success(`${ok} OT${ok > 1 ? 's' : ''} cancelada${ok > 1 ? 's' : ''}`)
  if (fail > 0) toast.error(`${fail} OT${fail > 1 ? 's' : ''} no pudieron cancelarse`)
  clearSelection()
  await loadWOs()
}

// When the displayed list changes, prune the selection down to the visible IDs
watch(displayedWOs, (list) => {
  const visible = new Set(list.map(w => w.id))
  let changed = false
  for (const id of Array.from(selectedIds.value)) {
    if (!visible.has(id)) { selectedIds.value.delete(id); changed = true }
  }
  if (changed) selectedIds.value = new Set(selectedIds.value)
})

// Shortcuts: index of the row highlighted with j/k.
const highlightIndex = ref<number>(-1)
const highlightedWO = computed(() => {
  if (highlightIndex.value < 0) return null
  return displayedWOs.value[highlightIndex.value] ?? null
})

function moveHighlight(delta: number) {
  if (selectedWO.value || transitionModal.value || showCreateModal.value) return
  const list = displayedWOs.value
  if (!list.length) return
  let next = highlightIndex.value + delta
  if (highlightIndex.value < 0) next = delta > 0 ? 0 : list.length - 1
  if (next < 0) next = 0
  if (next >= list.length) next = list.length - 1
  highlightIndex.value = next
  // Scroll to the row when it is outside the viewport
  requestAnimationFrame(() => {
    const id = list[next]?.id
    if (id != null) {
      const el = document.querySelector(`[data-wo-row="${id}"]`)
      el?.scrollIntoView({ block: 'nearest', behavior: 'smooth' })
    }
  })
}

// Reset the highlight when the filters change
watch([displayedWOs, activeSmartFilter, () => filters.value], () => {
  highlightIndex.value = -1
})

// Load technicians in the background (when not loaded yet) — used by the assignee
// InlinePicker and by the reassignment modal.
async function ensureTechniciansLoaded() {
  if (availableTechnicians.value.length) return
  try {
    const data = await usersApi.list({ status: 'active' })
    availableTechnicians.value = (data.users ?? [])
      .filter((u: any) => ['technician', 'operator', 'supervisor'].includes(u.role))
      .map((u: any) => ({ id: u.id, full_name: u.full_name, role: u.role }))
  } catch { /* the toast already fired when there was a network error */ }
}

const priorityOptions = computed(() => Object.entries(WO_PRIORITY_CONFIG).map(([v, cfg]) => ({
  value: v, label: cfg.label, color: cfg.color,
})))

const assigneeOptions = computed(() => {
  const opts: { value: number | null; label: string }[] = [{ value: null, label: 'Sin asignar' }]
  for (const t of availableTechnicians.value) {
    opts.push({ value: t.id, label: `${t.full_name} (${t.role})` })
  }
  return opts
})

async function quickEditPriority(wo: WorkOrder, newValue: string) {
  if (newValue === wo.priority) return
  if (!isManager.value) return
  rowSaving.value = wo.id
  const prev = wo.priority
  ;(wo as any).priority = newValue  // optimistic
  try {
    await workOrdersApi.update(wo.id, {
      title: wo.title,
      description: wo.description,
      priority: newValue,
      assigned_to: wo.assigned_to,
      estimated_hours: wo.estimated_hours,
      planned_start: wo.planned_start,
      planned_end: wo.planned_end,
      version: wo.version,
    } as any)
    ;(wo as any).version += 1  // The backend bumps version; refresh the client
    toast.success(`Prioridad actualizada en ${wo.wo_number}`)
  } catch (err: unknown) {
    ;(wo as any).priority = prev  // revert
    toast.fromError(err, 'No se pudo actualizar la prioridad')
  } finally {
    rowSaving.value = null
  }
}

async function quickEditAssignee(wo: WorkOrder, newAssignedTo: number | null) {
  if (newAssignedTo === (wo.assigned_to ?? null)) return
  if (!isManager.value) return
  rowSaving.value = wo.id
  const prevId = wo.assigned_to
  const prevName = (wo as any).assigned_name
  // Optimistic
  ;(wo as any).assigned_to = newAssignedTo
  ;(wo as any).assigned_name = newAssignedTo
    ? availableTechnicians.value.find(t => t.id === newAssignedTo)?.full_name ?? null
    : null
  try {
    await workOrdersApi.update(wo.id, {
      title: wo.title,
      description: wo.description,
      priority: wo.priority,
      assigned_to: newAssignedTo,
      estimated_hours: wo.estimated_hours,
      planned_start: wo.planned_start,
      planned_end: wo.planned_end,
      version: wo.version,
    } as any)
    ;(wo as any).version += 1
    toast.success(newAssignedTo
      ? `Asignada a ${(wo as any).assigned_name}`
      : `OT ${wo.wo_number} desasignada`)
  } catch (err: unknown) {
    ;(wo as any).assigned_to = prevId
    ;(wo as any).assigned_name = prevName
    toast.fromError(err, 'No se pudo reasignar la OT')
  } finally {
    rowSaving.value = null
  }
}
const selectedWO = ref<any>(null)
const signaturesInfo = ref<any>(null)
const activeDetailTab = ref('info')
const detailTabs = [
  { id: 'info', label: 'Información' },
  { id: 'evidence', label: 'Evidencia' },
  { id: 'procedures', label: 'Procedimientos' },
  { id: 'intervals', label: 'Registro de trabajo' },
  { id: 'log', label: 'Historial' },
  { id: 'comments', label: 'Comentarios' },
]

// ─── Photographic evidence (before / after) ─────────────────────────────────
interface PhotoAttachment {
  id: number
  original_name: string
  mime_type: string
  file_size: number
  category: string
  description: string | null
  photo_phase: 'before' | 'after' | null
  uploaded_by: string | null
  created_at: string
  url?: string  // Local URL generated through a blob for the preview
}
const photoBefore = ref<PhotoAttachment[]>([])
const photoAfter  = ref<PhotoAttachment[]>([])
const photosLoading = ref(false)
const photoUploading = ref<'before' | 'after' | null>(null)

async function loadPhotos(woId: number) {
  photosLoading.value = true
  try {
    const { data } = await client.get<{ attachments: PhotoAttachment[] }>(`/work-orders/${woId}/library`)
    const all = data.attachments ?? []
    photoBefore.value = all.filter(a => a.photo_phase === 'before')
    photoAfter.value  = all.filter(a => a.photo_phase === 'after')
  } catch (err) {
    toast.fromError(err, 'No se pudieron cargar las fotos')
  } finally {
    photosLoading.value = false
  }
}

async function uploadPhoto(phase: 'before' | 'after', ev: Event) {
  const input = ev.target as HTMLInputElement
  const file = input.files?.[0]
  if (!file || !selectedWO.value) return
  const wo = selectedWO.value.work_order
  // Client-side validation: images only, and under 10MB
  if (!file.type.startsWith('image/')) {
    toast.error('Solo se admiten imágenes')
    input.value = ''
    return
  }
  if (file.size > 10 * 1024 * 1024) {
    toast.error('La imagen supera el límite de 10MB')
    input.value = ''
    return
  }
  photoUploading.value = phase
  try {
    const fd = new FormData()
    fd.append('file', file)
    fd.append('category', 'evidence')
    fd.append('phase', phase)
    fd.append('wo_id', String(wo.id))
    await client.post(`/factory/nodes/${wo.node_id}/library/upload`, fd, {
      headers: { 'Content-Type': 'multipart/form-data' },
    })
    toast.success(phase === 'before' ? 'Foto "antes" subida' : 'Foto "después" subida')
    await loadPhotos(wo.id)
  } catch (err) {
    toast.fromError(err, 'No se pudo subir la foto')
  } finally {
    photoUploading.value = null
    input.value = ''
  }
}

watch(activeDetailTab, (tab) => {
  if (tab === 'evidence' && selectedWO.value) {
    loadPhotos(selectedWO.value.work_order.id)
  }
})
const showCreateModal = ref(false)
const creating = ref(false)
const createError = ref('')
const availableNodes = ref<{ id: number; name: string; code?: string }[]>([])
const createForm = ref({ title: '', node_id: 0, wo_type: 'corrective', priority: 'medium', description: '', assigned_to: null as number | null })
const availableTechnicians = ref<{ id: number; full_name: string; role: string }[]>([])
const transitionModal = ref<any>(null)
const transitionData = ref({
  comment: '',
  actual_hours: undefined as number | undefined,
  actual_hours_raw: '',
  root_cause: '',
  root_cause_code: '',
  solution: ''
})

// Spare part suggestions for the node currently selected in Create.
interface PartSuggestion {
  id: number
  code: string | null
  name: string
  unit: string | null
  current_stock: number | null
  min_stock: number | null
  score: number
  is_linked: boolean
  in_history: boolean
}
const partsSuggestions = ref<PartSuggestion[]>([])
let partsSuggestAbort: AbortController | null = null

async function loadPartsSuggestions(nodeId: number) {
  if (partsSuggestAbort) partsSuggestAbort.abort()
  partsSuggestAbort = new AbortController()
  partsSuggestions.value = []
  if (!nodeId) return
  try {
    const { data } = await client.get<{ suggestions: PartSuggestion[] }>(
      '/work-orders/suggest-parts',
      { params: { node_id: nodeId }, signal: partsSuggestAbort.signal as any },
    )
    partsSuggestions.value = data.suggestions ?? []
  } catch (err: unknown) {
    if (err?.name === 'CanceledError' || err?.code === 'ERR_CANCELED') return
    // The endpoint is optional; an error must not break the modal
  }
}

watch(() => createForm.value.node_id, (id) => {
  if (showCreateModal.value && id) loadPartsSuggestions(id as number)
  else partsSuggestions.value = []
})

watch(showCreateModal, (open) => {
  if (!open) partsSuggestions.value = []
})
const transitionError = ref('')
const transitioning = ref(false)
const newComment = ref('')
const detailLoading = ref(false)

const transitions = computed(() => {
  if (!selectedWO.value) return []
  const role = authStore.user?.role ?? ''
  return (WO_TRANSITIONS[selectedWO.value.work_order.status] ?? [])
    .filter(t => t.roles.includes(role))
})

async function openPDF(id: number) {
  try {
    // Fetch the data and the HTML in parallel (the 401 interceptor works here)
    const [dataResp, htmlResp] = await Promise.all([
      client.get<any>(`/reports/wo/${id}/data`),
      client.get<string>(`/reports/wo/${id}/html`, { responseType: 'text' as const })
    ])
    const woData = dataResp.data
    let html = htmlResp.data
    const dataScript = `<script>window.WO_DATA = ${JSON.stringify(woData)};<` + `/script>`
    html = html.replace('</head>', dataScript + '</head>')
    const blob = new Blob([html], { type: 'text/html' })
    const blobUrl = URL.createObjectURL(blob)
    const win = window.open(blobUrl, '_blank')
    if (win) setTimeout(() => URL.revokeObjectURL(blobUrl), 15000)
  } catch (err: unknown) {
    toast.fromError(err, 'Error generando el informe')
    console.error('[WO] openPDF', err)
  }
}


const techSuggestions = ref<any[]>([])
const loadingSuggestTech = ref(false)
const reassignMode = ref(false)
const reassignUserId = ref<number | null>(null)
const reassigning = ref(false)

async function openReassign() {
  reassignMode.value = true
  reassignUserId.value = selectedWO.value?.work_order?.assigned_to ?? null
  techSuggestions.value = []
  if (!availableTechnicians.value.length) {
    try {
      const data = await usersApi.list({ status: 'active' })
      availableTechnicians.value = (data.users ?? [])
        .filter((u: any) => ['technician', 'operator', 'supervisor'].includes(u.role))
        .map((u: any) => ({ id: u.id, full_name: u.full_name, role: u.role }))
    } catch { /* silent */ }
  }
}

async function confirmReassign() {
  if (!selectedWO.value) return
  reassigning.value = true
  try {
    const wo = selectedWO.value.work_order
    await workOrdersApi.update(wo.id, {
      title: wo.title, description: wo.description, priority: wo.priority,
      assigned_to: reassignUserId.value, estimated_hours: wo.estimated_hours,
      planned_start: wo.planned_start, planned_end: wo.planned_end, version: wo.version,
    } as any)
    reassignMode.value = false
    await openDetail(wo)
    await loadWOs()
  } catch (e: unknown) { toast.fromError(e, 'Error reasignando')
  } finally { reassigning.value = false }
}

async function unassignTechnician() {
  if (!selectedWO.value) return
  const wo = selectedWO.value.work_order
  try {
    await workOrdersApi.update(wo.id, {
      title: wo.title, description: wo.description, priority: wo.priority,
      assigned_to: null, estimated_hours: wo.estimated_hours,
      planned_start: wo.planned_start, planned_end: wo.planned_end, version: wo.version,
    } as any)
    await openDetail(wo)
    await loadWOs()
  } catch (e: unknown) { toast.fromError(e, 'Error desasignando') }
}

async function selfAssign() {
  if (!selectedWO.value || !authStore.user) return
  const wo = selectedWO.value.work_order
  try {
    await workOrdersApi.update(wo.id, {
      title: wo.title, description: wo.description, priority: wo.priority,
      assigned_to: authStore.user.id, estimated_hours: wo.estimated_hours,
      planned_start: wo.planned_start, planned_end: wo.planned_end, version: wo.version,
    } as any)
    await openDetail(wo)
    await loadWOs()
  } catch (e: unknown) { toast.fromError(e, 'Error tomando OT') }
}

async function suggestTechnician(woId: number) {
  loadingSuggestTech.value = true
  techSuggestions.value = []
  try {
    const { data } = await client.get(`/technicians/suggest/${woId}`)
    if (data.auto_assigned && selectedWO.value) {
      // The node's only technician was auto-assigned — reload the WO
      await openDetail(selectedWO.value.work_order)
      return
    }
    techSuggestions.value = data.suggestions ?? []
  } catch { /* silent */ }
  finally { loadingSuggestTech.value = false }
}

async function assignTechnician(woId: number, userId: number) {
  if (!selectedWO.value) return
  try {
    const wo = selectedWO.value.work_order
    await workOrdersApi.update(woId, {
      title: wo.title,
      description: wo.description,
      priority: wo.priority,
      assigned_to: userId,
      estimated_hours: wo.estimated_hours,
      planned_start: wo.planned_start,
      planned_end: wo.planned_end,
      version: wo.version,
    } as any)
    techSuggestions.value = []
    await openDetail(wo)
    await loadWOs()
  } catch { toast.error('Error asignando técnico') }
}

function getSuggestion(_woId: number) {
  if (!selectedWO.value) return
  const wo = selectedWO.value.work_order
  const nodeName = wo.node_name ?? 'Equipo'
  const nodeId = wo.node_id

  let msg = `Necesito diagnosticar esta avería y encontrar la causa raíz:\n`
  msg += `- Equipo: ${nodeName}\n`
  msg += `- OT: ${wo.wo_number} — ${wo.title}\n`
  if (wo.description) msg += `- Descripción: ${wo.description}\n`
  if (wo.priority) msg += `- Prioridad: ${wo.priority}\n`
  msg += `\n¿Cuáles son las causas más probables? Hazme las preguntas necesarias para llegar a un diagnóstico preciso.`

  aiStore.openDiagnostic(nodeId, nodeName, msg)
}


const scoreModal = ref<any>(null)
const scoreForm = ref({ score: 0, comment: '' })
const scoreError = ref('')
const savingScore = ref(false)

function openScore(wo: any) {
  scoreModal.value = wo
  scoreForm.value = { score: 0, comment: '' }
  scoreError.value = ''
}

async function submitScore() {
  if (!scoreForm.value.score || !scoreModal.value) return
  savingScore.value = true; scoreError.value = ''
  try {
    await client.post(`/technicians/${scoreModal.value.assigned_to}/scores`, {
      wo_id: scoreModal.value.id,
      score: scoreForm.value.score,
      comment: scoreForm.value.comment || null
    })
    scoreModal.value = null
    toast.success('Puntuación guardada correctamente')
  } catch (err: unknown) {
    scoreError.value = err?.response?.data?.error ?? 'Error guardando puntuación'
  } finally { savingScore.value = false }
}



async function loadWOs() {
  loading.value = true
  try {
    if (!isOnline.value) {
      let cached = await offlineStore.getWorkOrders()
      if (filters.value.status) cached = cached.filter(w => w.status === filters.value.status)
      if (filters.value.type) cached = cached.filter(w => w.wo_type === filters.value.type)
      if (filters.value.priority) cached = cached.filter(w => w.priority === filters.value.priority)
      workOrders.value = cached as WorkOrder[]
      total.value = cached.length
      return
    }

    const params: Record<string, string> = {}
    if (filters.value.status) params.status = filters.value.status
    if (filters.value.type) params.type = filters.value.type
    if (filters.value.priority) params.priority = filters.value.priority

    const sf = smartFilters.value.find(f => f.id === activeSmartFilter.value)
    if (sf?.filter) {
      Object.entries(sf.filter).forEach(([k, v]) => { if (v) params[k] = v })
    }

    const data = await workOrdersApi.list(params)
    workOrders.value = data.work_orders ?? []
    total.value = data.total ?? 0
  } catch {
    const cached = await offlineStore.getWorkOrders()
    workOrders.value = cached as WorkOrder[]
    total.value = cached.length
  } finally { loading.value = false }
}

async function openDetail(wo: WorkOrder) {
  detailLoading.value = true
  try {
    if (!isOnline.value) {
      const cached = await offlineStore.getWorkOrder(wo.id)
      if (cached) {
        selectedWO.value = { work_order: cached, log: cached.log, comments: cached.comments }
      }
      signaturesInfo.value = null
      activeDetailTab.value = 'info'
      newComment.value = ''
      techSuggestions.value = []
      reassignMode.value = false
      woIntervals.value = []
      woProcedures.value = []
      procSuggestions.value = []
      activeExecId.value = null
      return
    }
    const data = await workOrdersApi.getOne(wo.id)
    selectedWO.value = data
    signaturesInfo.value = null
    activeDetailTab.value = 'info'
    newComment.value = ''
    techSuggestions.value = []
    reassignMode.value = false
    woIntervals.value = []
    woProcedures.value = []
    procSuggestions.value = []
    activeExecId.value = null
    loadIntervals(wo.id)
    loadProcedures(wo.id)
    client.get(`/work-orders/${wo.id}/signatures`)
      .then(r => { signaturesInfo.value = r.data })
      .catch(err => console.error('[WO] signatures', err))
  } catch (err: unknown) {
    const cached = await offlineStore.getWorkOrder(wo.id)
    if (cached) {
      selectedWO.value = { work_order: cached, log: cached.log, comments: cached.comments }
    } else {
      toast.fromError(err, 'Error cargando OT')
    }
  } finally {
    detailLoading.value = false
  }
}

async function openCreateModal() {
  createForm.value = { title: '', node_id: 0, wo_type: 'corrective', priority: 'medium', description: '', assigned_to: null }
  createError.value = ''
  nodeSearchQ.value = ''
  selectedNodeLabel.value = ''
  nodeSearchOpen.value = false
  try {
    const [treeData, usersData] = await Promise.all([
      nodesApi.getTree(),
      usersApi.list({ status: 'active' }),
    ])
    const flat: { id: number; name: string; code?: string }[] = []
    const flatten = (nodes: any[]) => nodes.forEach(n => { flat.push({ id: n.id, name: n.name, code: n.code }); if (n.children) flatten(n.children) })
    flatten(treeData.nodes ?? [])
    availableNodes.value = flat
    availableTechnicians.value = (usersData.users ?? [])
      .filter((u: any) => ['technician', 'operator', 'supervisor'].includes(u.role))
      .map((u: any) => ({ id: u.id, full_name: u.full_name, role: u.role }))
  } catch { availableNodes.value = []; availableTechnicians.value = [] }
  showCreateModal.value = true
}

async function submitCreate() {
  if (!createForm.value.title || !createForm.value.node_id) { createError.value = 'Título y nodo son requeridos'; return }
  creating.value = true; createError.value = ''
  try {
    await workOrdersApi.create({ node_id: createForm.value.node_id, title: createForm.value.title, wo_type: createForm.value.wo_type as any, priority: createForm.value.priority as any, description: createForm.value.description || undefined, assigned_to: createForm.value.assigned_to || undefined } as any)
    showCreateModal.value = false
    await loadWOs()
  } catch (err: unknown) { createError.value = apiErrorMsg(err, 'Error creando la OT')
  } finally { creating.value = false }
}

function doTransition(t: any) {
  transitionModal.value = t
  transitionData.value = {
    comment: '',
    actual_hours: undefined,
    actual_hours_raw: '',
    root_cause: selectedWO.value?.work_order?.root_cause ?? '',
    root_cause_code: selectedWO.value?.work_order?.root_cause_code ?? '',
    solution: selectedWO.value?.work_order?.solution ?? '',
  }
  transitionError.value = ''
}

async function confirmTransition() {
  if (!selectedWO.value || !transitionModal.value) return
  if (transitionModal.value.requireComment && !transitionData.value.comment.trim()) { transitionError.value = 'El comentario es obligatorio'; return }
  if (transitionData.value.actual_hours_raw) {
    const parsed = parseHoursInput(transitionData.value.actual_hours_raw)
    if (parsed === undefined) { transitionError.value = 'Formato de horas inválido. Use 5:30 o 5.5'; return }
    transitionData.value.actual_hours = Math.round(parsed * 100) / 100
  }
  const wo = selectedWO.value.work_order
  transitioning.value = true; transitionError.value = ''
  try {
    if (!isOnline.value) {
      await offlineStore.changeStatusOffline(
        wo.id,
        transitionModal.value.to,
        transitionData.value.comment || undefined,
        {
          actual_hours: transitionData.value.actual_hours,
          root_cause: transitionData.value.root_cause || undefined,
          solution: transitionData.value.solution || undefined,
        }
      )
      transitionModal.value = null
      const updated = await offlineStore.getWorkOrder(wo.id)
      if (updated) {
        selectedWO.value = { work_order: updated, log: updated.log, comments: updated.comments }
      }
      await loadWOs()
    } else {
      await workOrdersApi.changeStatus(wo.id, {
        status: transitionModal.value.to,
        comment: transitionData.value.comment || undefined,
        actual_hours: transitionData.value.actual_hours,
        root_cause: transitionData.value.root_cause || undefined,
        root_cause_code: transitionData.value.root_cause_code || undefined,
        solution: transitionData.value.solution || undefined,
        version: wo.version,
      } as any)
      transitionModal.value = null
      await openDetail(wo)
      await loadWOs()
      // Refresh the active WO banner (it entered/left in_progress)
      activeWORefresh()
    }
  } catch (err: unknown) { transitionError.value = apiErrorMsg(err, 'Error')
  } finally { transitioning.value = false }
}

async function submitComment() {
  if (!selectedWO.value || !newComment.value.trim()) return
  const wo = selectedWO.value.work_order
  try {
    if (!isOnline.value) {
      await offlineStore.addCommentOffline(wo.id, newComment.value)
      newComment.value = ''
      const updated = await offlineStore.getWorkOrder(wo.id)
      if (updated) {
        selectedWO.value = { work_order: updated, log: updated.log, comments: updated.comments }
      }
    } else {
      await workOrdersApi.addComment(wo.id, newComment.value)
      newComment.value = ''
      if (selectedWO.value) await openDetail(wo)
    }
  } catch { /* ignore — the comment shows up on reopen */ }
}

function clearFilters() { filters.value = { status: '', type: '', priority: '' }; activeSmartFilter.value = null; loadWOs() }

// Parses the hours input: accepts "5:30" (HH:MM) or "5.5" (decimal)
function parseHoursInput(raw: string): number | undefined {
  if (!raw || !raw.trim()) return undefined
  const trimmed = raw.trim()
  // HH:MM format
  if (trimmed.includes(':')) {
    const parts = trimmed.split(':')
    const h = parseInt(parts[0], 10)
    const m = parseInt(parts[1], 10)
    if (isNaN(h) || isNaN(m) || h < 0 || m < 0 || m >= 60) return undefined
    return h + m / 60
  }
  // Decimal format (with a dot or a comma)
  const num = parseFloat(trimmed.replace(',', '.'))
  if (isNaN(num) || num < 0) return undefined
  return num
}

function validateHoursInput() {
  const raw = transitionData.value.actual_hours_raw
  if (!raw.trim()) { transitionData.value.actual_hours = undefined; return }
  const parsed = parseHoursInput(raw)
  if (parsed !== undefined) {
    transitionData.value.actual_hours = Math.round(parsed * 100) / 100
  }
}

function formatWorkedTime(mins: number | undefined) {
  if (!mins) return '—'
  return formatDurationMinutes(mins)
}

// ─── Work intervals ──────────────────────────────────────────────────
const woIntervals = ref<any[]>([])
const loadingIntervals = ref(false)
const intervalsTotalHours = ref('—')

// ─── Procedures (SOP) ───────────────────────────────────────────────────
const woProcedures = ref<ProcedureExecution[]>([])
const procSuggestions = ref<ProcedureSuggestion[]>([])
const loadingProcedures = ref(false)
const activeExecId = ref<number | null>(null)

async function loadProcedures(woId: number) {
  if (!isOnline.value) return
  loadingProcedures.value = true
  try {
    const data = await proceduresApi.getWOProcedures(woId)
    woProcedures.value = data.procedures ?? []
    if (woProcedures.value.length === 0 && selectedWO.value) {
      const wo = selectedWO.value.work_order
      const sug = await proceduresApi.suggest({ node_id: wo.node_id, wo_type: wo.wo_type })
      procSuggestions.value = sug.suggestions ?? []
    }
  } catch { woProcedures.value = [] }
  loadingProcedures.value = false
}

async function startProcedure(templateId: number) {
  if (!selectedWO.value) return
  try {
    const wo = selectedWO.value.work_order
    const res = await proceduresApi.startExecution(templateId, { wo_id: wo.id, node_id: wo.node_id })
    activeExecId.value = res.execution_id
    await loadProcedures(wo.id)
  } catch { /* silent */ }
}

function onProcedureCompleted() {
  activeExecId.value = null
  if (selectedWO.value) loadProcedures(selectedWO.value.work_order.id)
}

function onStepSubmitted(_data: { step: number; out_of_range: boolean }) {
  // out_of_range alerts could be shown here
}

async function loadIntervals(woId: number) {
  loadingIntervals.value = true
  try {
    const resp = await client.get<any>(`/work-orders/${woId}/intervals`)
    woIntervals.value = resp.data.intervals ?? []
    intervalsTotalHours.value = resp.data.total_hours ? `${resp.data.total_hours}h` : '—'
  } catch (e) {
    console.error('[WO] intervals', e)
    woIntervals.value = []
  }
  loadingIntervals.value = false
}

const route = useRoute()
const router = useRouter()

onMounted(async () => {
  // Technicians/operators: turn "My active WOs" on by default
  if (authStore.isFieldWorker) {
    activeSmartFilter.value = 'my_active'
  }
  await loadWOs()
  // Preload technicians when the user can inline-edit assignees
  if (isManager.value) ensureTechniciansLoaded()

  // ─── Shortcuts ───────────────────────────────────────────────────────────────
  registerShortcut('n', () => {
    if (canWrite.value) openCreateModal()
  }, { description: 'Nueva orden de trabajo', scope: 'Órdenes de trabajo' })

  registerShortcut('j', () => moveHighlight(1),
    { description: 'Siguiente OT en la lista', scope: 'Órdenes de trabajo' })
  registerShortcut('k', () => moveHighlight(-1),
    { description: 'OT anterior en la lista', scope: 'Órdenes de trabajo' })
  registerShortcut('enter', () => {
    const wo = highlightedWO.value
    if (wo) openDetail(wo)
  }, { description: 'Abrir OT seleccionada', scope: 'Órdenes de trabajo' })

  // When we arrive with ?open=ID (e.g. from the active WO banner), open the detail view.
  const openId = Number(route.query.open)
  if (openId > 0) {
    const wo = workOrders.value.find(w => w.id === openId)
    if (wo) {
      await openDetail(wo)
    } else {
      // Outside the current listing (filters applied): load it directly.
      try {
        const data = await workOrdersApi.getOne(openId)
        if (data?.work_order) {
          await openDetail(data.work_order)
        }
      } catch { /* silent */ }
    }
    // Clear the query param so a refresh does not reopen the modal
    router.replace({ query: { ...route.query, open: undefined } })
  }
})
</script>

<style scoped>
.wo-page { display: flex; height: calc(100vh - var(--header-height)); margin: calc(-1 * var(--space-6)); overflow: hidden; }
.wo-content { flex: 1; overflow-y: auto; padding: var(--space-6); display: flex; flex-direction: column; gap: var(--space-5); }
.page-header { display: flex; align-items: flex-start; justify-content: space-between; }
.page-title { font-size: 1.4rem; font-weight: 700; color: var(--color-primary); }
.page-title-dir { font-size: 1rem; font-weight: 400; color: var(--color-text-muted); }
.page-sub { font-size: 0.8rem; color: var(--color-text-muted); }
/* Smart filters */
.smart-filters { display: flex; gap: var(--space-2); flex-wrap: wrap; }
.smart-chip {
  height: 30px; padding: 0 var(--space-3);
  display: flex; align-items: center; gap: var(--space-2);
  background: var(--color-surface); border: 1px solid var(--color-border);
  border-radius: 20px; font-size: 0.75rem; font-weight: 500;
  color: var(--color-text-muted); cursor: pointer;
  transition: all var(--transition);
}
.smart-chip:hover { border-color: var(--color-accent); color: var(--color-accent); }
.smart-chip--active { background: var(--color-primary); border-color: var(--color-primary); color: #fff; }
.smart-chip-count {
  min-width: 16px; height: 16px; padding: 0 4px;
  background: rgba(0,0,0,0.15); border-radius: 8px;
  font-size: 0.65rem; font-weight: 700;
  display: flex; align-items: center; justify-content: center;
}
.smart-chip--active .smart-chip-count { background: rgba(255,255,255,0.25); }

.filters-bar { display: flex; gap: var(--space-3); flex-wrap: wrap; }
.filter-select { height: 36px; padding: 0 var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.8rem; background: var(--color-surface); }
.btn-ghost { height: 36px; padding: 0 var(--space-4); background: none; border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.8rem; cursor: pointer; color: var(--color-text-muted); }
.btn-ghost:hover { background: var(--color-surface-2); }
.table-wrap { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); overflow: hidden; }
.table-empty { padding: var(--space-8); text-align: center; color: var(--color-text-muted); font-size: 0.875rem; }
.wo-table { width: 100%; border-collapse: collapse; }
.wo-table th { padding: var(--space-3) var(--space-4); font-size: 0.68rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); background: var(--color-surface-2); border-bottom: 1px solid var(--color-border-light); text-align: left; }
.wo-row { cursor: pointer; border-bottom: 1px solid var(--color-border-light); transition: background var(--transition); }
.wo-row:hover { background: var(--color-surface-2); }
.wo-row--highlight {
  background: rgba(59, 130, 246, 0.10);
  box-shadow: inset 3px 0 0 var(--color-primary);
}
.wo-row--highlight:hover { background: rgba(59, 130, 246, 0.16); }
.wo-row--selected { background: rgba(15, 52, 96, 0.10); }
.wo-row--selected:hover { background: rgba(15, 52, 96, 0.18); }
.check-col { width: 32px; padding: 0 var(--space-2) !important; text-align: center; }
.check-col input { cursor: pointer; }
.wo-row td { padding: var(--space-3) var(--space-4); font-size: 0.8rem; }
.wo-title-cell { font-weight: 500; max-width: 260px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.priority-pill, .status-pill { font-size: 0.7rem; font-weight: 600; padding: 2px 8px; border-radius: 20px; white-space: nowrap; }
.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; padding: var(--space-4); }
.detail-modal { background: var(--color-surface); border-radius: var(--radius-lg); width: 100%; max-width: 760px; max-height: 90vh; display: flex; flex-direction: column; box-shadow: var(--shadow-lg); position: relative; overflow: hidden; }
.detail-modal--loading { opacity: 0.7; pointer-events: none; }
.detail-loading-bar { position: absolute; top: 0; left: 0; width: 100%; height: 3px; background: linear-gradient(90deg, transparent, var(--color-accent), transparent); animation: detail-loading-slide 1s infinite; z-index: 10; }
@keyframes detail-loading-slide { 0% { transform: translateX(-100%); } 100% { transform: translateX(100%); } }
.detail-header { display: flex; justify-content: space-between; align-items: flex-start; padding: var(--space-5) var(--space-6); border-bottom: 1px solid var(--color-border-light); gap: var(--space-4); }
.detail-title { font-size: 1.1rem; font-weight: 700; color: var(--color-primary); margin: var(--space-1) 0; }
.detail-meta { display: flex; align-items: center; gap: var(--space-2); font-size: 0.8rem; color: var(--color-text-muted); flex-wrap: wrap; }
.meta-sep { color: var(--color-border); }
.modal-close { background: none; border: none; font-size: 1rem; cursor: pointer; color: var(--color-text-muted); }
.status-actions { display: flex; align-items: center; gap: var(--space-2); padding: var(--space-3) var(--space-6); background: var(--color-surface-2); flex-wrap: wrap; }
.status-actions-label { font-size: 0.72rem; font-weight: 600; text-transform: uppercase; color: var(--color-text-muted); }
.btn-transition { height: 30px; padding: 0 var(--space-3); background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); font-size: 0.75rem; font-weight: 500; cursor: pointer; }
.btn-transition:hover { background: var(--color-accent); }
.detail-tabs { display: flex; border-bottom: 1px solid var(--color-border-light); padding: 0 var(--space-6); }
.detail-tab { height: 40px; padding: 0 var(--space-4); background: none; border: none; border-bottom: 2px solid transparent; font-size: 0.8rem; font-weight: 500; color: var(--color-text-muted); cursor: pointer; }
.detail-tab--active { color: var(--color-primary); border-bottom-color: var(--color-primary); }
.detail-body { flex: 1; overflow-y: auto; padding: var(--space-5) var(--space-6); }
.info-grid-2 { display: grid; grid-template-columns: repeat(3, 1fr); gap: var(--space-4); margin-bottom: var(--space-5); }
.info-block { display: flex; flex-direction: column; gap: 3px; }
.info-block--alert { background: rgba(233,69,96,0.08); border: 1px solid rgba(233,69,96,0.2); border-radius: var(--radius); padding: var(--space-2); }
.info-block--alert .info-label { color: var(--color-alert); }
.info-label { font-size: 0.65rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-light); }
.field-hint { font-size: 0.68rem; color: var(--color-text-muted); font-style: italic; margin-top: 2px; }
.desc-block { margin-bottom: var(--space-4); display: flex; flex-direction: column; gap: var(--space-2); }
.desc-block p { font-size: 0.875rem; color: var(--color-text-muted); background: var(--color-surface-2); padding: var(--space-3) var(--space-4); border-radius: var(--radius); line-height: 1.6; }
.root-cause-badge {
  display: inline-block;
  font-size: 0.72rem;
  font-weight: 600;
  padding: 2px 8px;
  margin-right: var(--space-2);
  border-radius: 20px;
  background: rgba(59, 130, 246, 0.15);
  color: #3b82f6;
}

/* Spare part suggestions in the create modal */
.parts-suggestions {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 4px;
}
.parts-chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 4px 10px;
  border: 1px solid var(--color-border-light);
  border-radius: 14px;
  background: var(--color-surface-2);
  font-size: 0.78rem;
  color: var(--color-text);
}
.parts-chip--linked  { border-color: rgba(39, 174, 96, 0.4);  background: rgba(39, 174, 96, 0.08); }
.parts-chip--history { border-color: rgba(243, 156, 18, 0.4); background: rgba(243, 156, 18, 0.08); }
.parts-chip--lowstock { box-shadow: inset 0 -2px 0 rgba(233, 69, 96, 0.5); }
.parts-chip-code { font-size: 0.72rem; color: var(--color-text-muted); }
.parts-chip-name { font-weight: 500; }
.parts-chip-stock {
  font-size: 0.7rem;
  font-variant-numeric: tabular-nums;
  color: var(--color-text-muted);
  margin-left: 2px;
}

/* Before/after evidence */
.evidence-section { display: flex; flex-direction: column; gap: var(--space-4); }
.evidence-grid { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-4); }
.evidence-col {
  display: flex; flex-direction: column; gap: var(--space-2);
  padding: var(--space-3);
  background: var(--color-surface-2);
  border: 1px solid var(--color-border-light);
  border-radius: var(--radius-md);
}
.evidence-col-head {
  display: flex; align-items: center; justify-content: space-between;
  gap: var(--space-2);
}
.evidence-col-title {
  font-size: 0.8rem; font-weight: 600;
  color: var(--color-text);
}
.evidence-add {
  font-size: 0.74rem; font-weight: 500;
  color: var(--color-primary);
  cursor: pointer;
  padding: 4px 10px;
  border: 1px dashed var(--color-border-light);
  border-radius: var(--radius);
  background: transparent;
  transition: background 120ms ease;
}
.evidence-add:hover { background: var(--color-surface); }
.evidence-add input[type=file] { display: none; }
.evidence-thumbs {
  display: flex; flex-direction: column; gap: 4px;
}
.evidence-thumb {
  display: flex; flex-direction: column; gap: 2px;
  padding: 6px 10px;
  background: var(--color-surface);
  border: 1px solid var(--color-border-light);
  border-radius: var(--radius);
  text-decoration: none; color: var(--color-text);
  font-size: 0.78rem;
}
.evidence-thumb:hover { background: var(--color-border-light); }
.evidence-thumb-name { font-weight: 500; word-break: break-all; }
.evidence-thumb-meta { font-size: 0.72rem; }
.section-empty.small { font-size: 0.78rem; padding: var(--space-3); }
@media (max-width: 640px) {
  .evidence-grid { grid-template-columns: 1fr; }
}

/* ─── Floating bulk action bar ─────────────────────────────────────── */
.bulkbar {
  position: fixed;
  bottom: var(--space-5, 20px);
  left: 50%;
  transform: translateX(-50%);
  z-index: 9000;
  display: flex; align-items: center; gap: var(--space-3, 12px);
  padding: 8px 14px;
  background: var(--color-primary, #0f3460);
  color: #fff;
  border-radius: 28px;
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.45);
  max-width: calc(100vw - var(--space-6, 24px));
}
.bulkbar-count { font-weight: 600; font-size: 0.84rem; flex-shrink: 0; }
.bulkbar-actions {
  display: flex; align-items: center; gap: 6px;
  flex-wrap: wrap;
}
.bulkbar-select {
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.25);
  color: #fff;
  padding: 4px 8px;
  border-radius: var(--radius, 4px);
  font-size: 0.78rem;
  max-width: 160px;
}
.bulkbar-select:focus { outline: 2px solid rgba(255, 255, 255, 0.35); }
.bulkbar-btn {
  background: rgba(255, 255, 255, 0.18);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #fff;
  padding: 5px 12px;
  border-radius: var(--radius, 4px);
  font-size: 0.78rem; font-weight: 600;
  cursor: pointer;
  transition: background 120ms;
}
.bulkbar-btn:hover:not(:disabled) { background: rgba(255, 255, 255, 0.3); }
.bulkbar-btn:disabled { opacity: 0.5; cursor: not-allowed; }
.bulkbar-btn--danger {
  background: rgba(233, 69, 96, 0.85);
  border-color: rgba(233, 69, 96, 0.95);
}
.bulkbar-btn--danger:hover:not(:disabled) { background: #e94560; }
.bulkbar-close {
  background: transparent;
  border: none;
  color: rgba(255, 255, 255, 0.7);
  font-size: 0.95rem;
  cursor: pointer;
  padding: 4px 6px;
}
.bulkbar-close:hover { color: #fff; }

.bulkbar-slide-enter-active, .bulkbar-slide-leave-active {
  transition: opacity 200ms ease, transform 200ms ease;
}
.bulkbar-slide-enter-from, .bulkbar-slide-leave-to {
  opacity: 0;
  transform: translate(-50%, 20px);
}

@media (max-width: 640px) {
  .bulkbar { flex-direction: column; align-items: stretch; gap: 8px; padding: 12px; border-radius: 12px; }
  .bulkbar-actions { flex-direction: column; align-items: stretch; }
  .bulkbar-select, .bulkbar-btn { width: 100%; max-width: none; }
}
.log-list { display: flex; flex-direction: column; gap: var(--space-4); }
.log-entry { display: flex; gap: var(--space-3); }
.log-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--color-border); flex-shrink: 0; margin-top: 6px; }
.log-content { flex: 1; }
.log-transition { display: flex; align-items: center; gap: var(--space-2); margin-bottom: 4px; }
.log-status.old { font-size: 0.75rem; color: var(--color-text-muted); }
.log-arrow { color: var(--color-border); }
.log-status.new { font-size: 0.8rem; font-weight: 600; }
.log-comment { font-size: 0.8rem; color: var(--color-text-muted); margin-bottom: 4px; }
.log-meta { display: flex; gap: var(--space-3); font-size: 0.72rem; color: var(--color-text-light); }
.comments-section { display: flex; flex-direction: column; gap: var(--space-4); }
.comments-list { display: flex; flex-direction: column; gap: var(--space-3); }
.comment-item { display: flex; gap: var(--space-3); }
.comment-avatar { width: 28px; height: 28px; border-radius: 50%; background: var(--color-accent); color: #fff; font-size: 0.7rem; font-weight: 600; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.comment-body { flex: 1; }
.comment-meta { display: flex; gap: var(--space-3); align-items: center; margin-bottom: 4px; }
.comment-author { font-size: 0.8rem; font-weight: 600; }
.comment-content { font-size: 0.8rem; color: var(--color-text-muted); line-height: 1.6; }
.comment-form { display: flex; gap: var(--space-3); align-items: flex-end; border-top: 1px solid var(--color-border-light); padding-top: var(--space-4); }
.comment-input { flex: 1; padding: var(--space-2) var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; resize: none; outline: none; font-family: var(--font-ui); }
.comment-input:focus { border-color: var(--color-accent); }
.create-modal { background: var(--color-surface); border-radius: var(--radius-lg); width: 100%; max-width: 520px; box-shadow: var(--shadow-lg); }
.small-modal { max-width: 440px; }
.modal-header { display: flex; justify-content: space-between; align-items: center; padding: var(--space-5) var(--space-6); border-bottom: 1px solid var(--color-border-light); }
.modal-header h3 { font-size: 1rem; font-weight: 600; color: var(--color-primary); }
.modal-body { padding: var(--space-5) var(--space-6); display: flex; flex-direction: column; gap: var(--space-4); }
.modal-footer { display: flex; justify-content: flex-end; gap: var(--space-3); padding: var(--space-4) var(--space-6); border-top: 1px solid var(--color-border-light); }
.modal-error { background: rgba(233,69,96,0.08); border: 1px solid rgba(233,69,96,0.3); border-radius: var(--radius); padding: var(--space-3); font-size: 0.875rem; color: var(--color-alert); }
.field { display: flex; flex-direction: column; gap: var(--space-1); }
.field-row { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-3); }
.field-label { font-size: 0.68rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); }
.field-input { padding: 0 var(--space-3); height: 38px; border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; background: var(--color-surface); outline: none; width: 100%; }
.field-input:focus { border-color: var(--color-accent); }
textarea.field-input { height: auto; padding: var(--space-2) var(--space-3); resize: vertical; font-family: var(--font-ui); }
.btn-primary { height: 38px; padding: 0 var(--space-5); background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); font-size: 0.875rem; font-weight: 500; cursor: pointer; }
.btn-primary:hover:not(:disabled) { background: var(--color-accent); }
.btn-primary:disabled { opacity: 0.65; cursor: not-allowed; }
.btn-primary.small { height: 32px; font-size: 0.8rem; }
.btn-secondary { height: 38px; padding: 0 var(--space-5); background: var(--color-surface-2); color: var(--color-text); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; cursor: pointer; }
.mono { font-family: var(--font-mono); }
.small { font-size: 0.75rem; }
.text-muted { color: var(--color-text-muted); }
.btn-pdf { height: 30px; padding: 0 var(--space-3); background: rgba(233,69,96,0.08); border: 1px solid rgba(233,69,96,0.3); color: var(--color-alert); border-radius: var(--radius-sm); font-size: 0.78rem; cursor: pointer; }
.btn-pdf:hover { background: rgba(233,69,96,0.15); }

.btn-suggest { height: 30px; padding: 0 var(--space-3); background: rgba(15,52,96,0.08); border: 1px solid rgba(15,52,96,0.3); color: var(--color-accent); border-radius: var(--radius-sm); font-size: 0.78rem; cursor: pointer; }
.btn-suggest:hover:not(:disabled) { background: rgba(15,52,96,0.15); }
.btn-suggest:disabled { opacity: 0.6; cursor: not-allowed; }



.signatures-info { display: flex; flex-direction: column; gap: 8px; margin-top: 8px; }
.sig-row { display: flex; align-items: center; gap: 10px; font-size: 0.82rem; padding: 8px 12px; border-radius: var(--radius); }
.sig-row--ok { background: rgba(39,174,96,0.06); border: 1px solid rgba(39,174,96,0.2); }
.sig-row--pending { background: var(--color-surface-2); border: 1px solid var(--color-border-light); }
.sig-icon { font-size: 1rem; flex-shrink: 0; }
.sig-row--ok .sig-icon { color: #27AE60; font-weight: 700; }
.sig-row--pending .sig-icon { color: var(--color-text-light); }
.sig-detail { display: flex; flex-direction: column; gap: 1px; flex: 1; }
.sig-name { font-weight: 600; color: var(--color-text); }
.sig-role { font-size: 0.68rem; color: var(--color-text-muted); text-transform: uppercase; letter-spacing: 0.5px; }
.sig-pending { color: var(--color-text-light); font-size: 0.78rem; }
.assign-actions { display: inline-flex; gap: 4px; margin-left: 4px; }
.tech-suggest-row { margin-top: 4px; }
.field-input--inline { display: inline-block; width: auto; min-width: 180px; padding: 4px 8px; font-size: 0.82rem; }
.tech-suggestions { display: flex; flex-direction: column; gap: 4px; margin-top: 6px; padding: 8px; background: var(--color-surface-2); border-radius: var(--radius); }
.tech-sug-row { display: flex; align-items: center; gap: 8px; font-size: 0.82rem; padding: 4px 0; }
.tech-sug-match { font-weight: 600; }
.tech-sug-name { flex: 1; }
.tech-sug-score { color: #f59e0b; font-size: 0.78rem; }
.tech-sug-load { min-width: 80px; text-align: right; }

/* ─── Header actions row ───────────────────────────────────────────────────── */
.header-actions { display: flex; align-items: center; gap: var(--space-3); }

/* ─── View mode toggle ─────────────────────────────────────────────────────── */
.view-toggle { display: flex; border: 1px solid var(--color-border); border-radius: var(--radius); overflow: hidden; }
.view-toggle-btn {
  width: 34px; height: 34px; display: flex; align-items: center; justify-content: center;
  background: var(--color-surface); border: none; font-size: 1.1rem; cursor: pointer;
  color: var(--color-text-muted); transition: all var(--transition);
}
.view-toggle-btn:first-child { border-right: 1px solid var(--color-border); }
.view-toggle-btn:hover { background: var(--color-surface-2); }
.view-toggle-btn--active { background: var(--color-primary); color: #fff; }
.view-toggle-btn--active:hover { background: var(--color-accent); }

/* ─── Kanban board ─────────────────────────────────────────────────────────── */
.kanban-board { display: flex; gap: var(--space-4); overflow-x: auto; padding-bottom: var(--space-3); flex: 1; min-height: 0; }
.kanban-column {
  min-width: 280px; max-width: 320px; flex-shrink: 0;
  background: var(--color-surface); border: 1px solid var(--color-border-light);
  border-radius: var(--radius-md); display: flex; flex-direction: column;
  max-height: calc(100vh - 260px);
}
.kanban-header {
  position: sticky; top: 0; z-index: 1;
  display: flex; align-items: center; justify-content: space-between;
  padding: var(--space-3) var(--space-4);
  background: var(--color-surface); border-bottom: 2px solid var(--color-border-light);
  border-radius: var(--radius-md) var(--radius-md) 0 0;
}
.kanban-header-label { font-size: 0.78rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); }
.kanban-header-count {
  min-width: 22px; height: 22px; padding: 0 6px;
  display: flex; align-items: center; justify-content: center;
  border-radius: 12px; font-size: 0.7rem; font-weight: 700;
}
.kanban-body { flex: 1; overflow-y: auto; padding: var(--space-3); display: flex; flex-direction: column; gap: var(--space-2); }
.kanban-empty { font-size: 0.78rem; color: var(--color-text-light); text-align: center; padding: var(--space-4) 0; }
.kanban-card {
  background: var(--color-surface); border: 1px solid var(--color-border-light);
  border-radius: var(--radius); padding: var(--space-3);
  cursor: pointer; transition: all var(--transition);
}
.kanban-card:hover { box-shadow: var(--shadow-sm); border-color: var(--color-border); }
.kanban-card-number { font-size: 0.68rem; color: var(--color-text-light); margin-bottom: 2px; }
.kanban-card-title { font-size: 0.8rem; font-weight: 500; color: var(--color-text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-bottom: var(--space-2); }
.kanban-card-footer { display: flex; align-items: center; gap: var(--space-2); font-size: 0.7rem; }
.kanban-card-priority { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
.kanban-card-node { flex: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.kanban-card-assign { white-space: nowrap; }

/* ─── Visual stepper ───────────────────────────────────────────────────────── */
.wo-stepper {
  display: flex; align-items: flex-start; justify-content: center;
  padding: var(--space-3) var(--space-6); gap: 0;
  background: var(--color-surface); border-bottom: 1px solid var(--color-border-light);
  overflow-x: auto;
}
.step-item { display: flex; flex-direction: column; align-items: center; gap: 4px; flex-shrink: 0; }
.step-dot {
  width: 10px; height: 10px; border-radius: 50%;
  border: 2px solid var(--color-border); background: transparent;
  transition: all var(--transition); flex-shrink: 0;
}
.step-dot--completed { background: #27AE60; border-color: #27AE60; }
.step-dot--current { background: var(--color-primary); border-color: var(--color-primary); box-shadow: 0 0 0 3px rgba(26,26,46,0.15); }
.step-dot--future { background: transparent; border-color: var(--color-border); }
.step-label { font-size: 0.58rem; color: var(--color-text-light); text-align: center; white-space: nowrap; }
.step-label--current { color: var(--color-primary); font-weight: 700; }
.step-line {
  width: 28px; height: 2px; margin-top: 4px;
  background: var(--color-border); flex-shrink: 0;
  transition: background var(--transition);
}
.step-line--done { background: #27AE60; }
.stepper-special-badge {
  display: flex; align-items: center; justify-content: center;
  padding: 4px var(--space-4);
  font-size: 0.72rem; font-weight: 600;
  border: 1px solid; border-radius: var(--radius);
  margin: 0 var(--space-6) var(--space-2);
  text-align: center;
}

/* ─── Node search dropdown ─────────────────────────────────────────────────── */
.node-search-wrap { position: relative; }
.node-search-dropdown {
  position: absolute; top: 100%; left: 0; right: 0; z-index: 50;
  max-height: 200px; overflow-y: auto;
  background: var(--color-surface); border: 1px solid var(--color-border);
  border-top: none; border-radius: 0 0 var(--radius) var(--radius);
  box-shadow: var(--shadow-sm);
}
.node-search-item {
  display: flex; align-items: center; justify-content: space-between;
  padding: var(--space-2) var(--space-3); cursor: pointer;
  font-size: 0.82rem; transition: background var(--transition);
}
.node-search-item:hover { background: var(--color-surface-2); }
.node-search-name { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.node-search-code { font-size: 0.7rem; color: var(--color-text-light); margin-left: var(--space-2); flex-shrink: 0; }
.node-search-empty { padding: var(--space-3); font-size: 0.8rem; color: var(--color-text-light); text-align: center; }

/* ─── Mobile cards ────────────────────────────────────────────────────────── */
.wo-mobile-cards {
  display: none;
  flex-direction: column;
  gap: var(--space-2);
  padding: 0;
}
.wo-mcard {
  background: var(--color-surface);
  border: 1px solid var(--color-border-light);
  border-radius: var(--radius-md);
  padding: var(--space-3);
  cursor: pointer;
  transition: border-color var(--transition);
}
.wo-mcard:active { border-color: var(--color-accent); }
.wo-mcard-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 4px;
}
.wo-mcard-number { font-size: 0.7rem; color: var(--color-text-light); }
.wo-mcard-title {
  font-size: 0.88rem;
  font-weight: 600;
  color: var(--color-text);
  margin-bottom: 6px;
  line-height: 1.3;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.wo-mcard-meta {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  margin-bottom: 8px;
  font-size: 0.75rem;
  color: var(--color-text-muted);
}
.wo-mcard-node {
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.wo-mcard-type {
  flex-shrink: 0;
  background: var(--color-surface-2);
  padding: 1px 6px;
  border-radius: var(--radius-sm);
  font-size: 0.68rem;
}
.wo-mcard-bottom {
  display: flex;
  align-items: center;
  gap: var(--space-2);
}
.wo-mcard-assign {
  flex: 1;
  text-align: right;
  font-size: 0.75rem;
  color: var(--color-text-muted);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* ─── Responsive: tablet 768px ────────────────────────────────────────────── */
@media (max-width: 768px) {
  .wo-table-desktop { display: none !important; }
  .wo-mobile-cards { display: flex !important; }
  .kanban-board { display: none !important; }
  .view-toggle { display: none !important; }

  .page-header { flex-direction: column; gap: var(--space-3); }
  .page-title { font-size: 1.15rem; }
  .header-actions { width: 100%; justify-content: flex-end; }

  .smart-filters { gap: var(--space-1); }
  .smart-chip { height: 34px; font-size: 0.78rem; }

  .filters-bar { gap: var(--space-2); }
  .filter-select { height: 40px; font-size: 0.82rem; flex: 1; min-width: 0; }
  .btn-ghost { height: 40px; font-size: 0.82rem; }

  /* ─── Detail modal: full-screen on mobile ─── */
  .modal-overlay { padding: 0; align-items: stretch; }
  .detail-modal {
    max-width: 100%; max-height: 100%;
    border-radius: 0;
    height: 100vh; height: 100dvh;
    overflow-y: auto;
    display: flex; flex-direction: column;
  }

  .detail-header { padding: var(--space-3) var(--space-4); gap: var(--space-3); }
  .detail-title { font-size: 0.95rem; }
  .detail-meta { font-size: 0.78rem; }

  /* Hide stepper on mobile — it causes the text cutoff */
  .wo-stepper { display: none; }
  .stepper-special-badge { margin: 0; border-radius: 0; font-size: 0.78rem; padding: var(--space-2) var(--space-4); }

  .status-actions {
    padding: var(--space-2) var(--space-4);
    gap: var(--space-2);
    flex-wrap: wrap;
  }
  .status-actions-label { font-size: 0.75rem; width: 100%; }
  .btn-transition { height: 40px; padding: 0 var(--space-4); font-size: 0.82rem; flex: 1; min-width: 0; }
  .btn-pdf, .btn-score, .btn-suggest { height: 40px; font-size: 0.78rem; }

  .detail-tabs { padding: 0 var(--space-4); overflow-x: auto; -webkit-overflow-scrolling: touch; gap: 0; flex-shrink: 0; }
  .detail-tab { height: 42px; font-size: 0.82rem; padding: 0 var(--space-3); white-space: nowrap; flex-shrink: 0; }

  .detail-body { padding: var(--space-4); flex: 1; min-height: 0; }

  .info-grid-2 { grid-template-columns: 1fr 1fr; gap: var(--space-3); }
  .info-label { font-size: 0.7rem; }
  .info-block span:not(.info-label) { font-size: 0.82rem; }

  .desc-block p { font-size: 0.82rem; padding: var(--space-3); }

  /* Comments */
  .comment-form { flex-direction: column; }
  .comment-input { font-size: 1rem; }

  /* Intervals table scroll */
  .intervals-section { padding: var(--space-3); overflow-x: auto; }
  .intervals-table { font-size: 0.78rem; min-width: 420px; }

  /* Create/Edit modal */
  .create-modal { max-width: 100%; border-radius: 0; max-height: 100vh; max-height: 100dvh; overflow-y: auto; }
  .small-modal { max-width: 100%; }
  .modal-body { padding: var(--space-4); }
  .modal-header { padding: var(--space-4); }
  .modal-footer { padding: var(--space-3) var(--space-4); }
  .field-row { grid-template-columns: 1fr; }
  .field-input { height: 42px; font-size: 1rem; }
  textarea.field-input { font-size: 1rem; }
  .btn-primary, .btn-secondary { height: 44px; font-size: 0.9rem; }

  /* Transition comment modal */
  .node-search-dropdown { max-height: 180px; }
}

/* ─── Responsive: phone 480px ────────────────────────────────────────────── */
@media (max-width: 480px) {
  .info-grid-2 { grid-template-columns: 1fr; }
  .smart-filters { overflow-x: auto; flex-wrap: nowrap; -webkit-overflow-scrolling: touch; }
  .smart-chip { flex-shrink: 0; }
  .wo-mcard { padding: var(--space-3); }
  .wo-mcard-title { font-size: 0.85rem; }
  .status-actions-label { font-size: 0.72rem; }
  .btn-transition { font-size: 0.78rem; }
  .detail-header { padding: var(--space-2) var(--space-3); }
  .detail-title { font-size: 0.88rem; }
  .detail-body { padding: var(--space-3); }
  .detail-tabs { padding: 0 var(--space-3); }
}

/* ─── Work intervals ─────────────────────────────────────────────── */
.intervals-section { padding: var(--space-4) var(--space-6); }
.intervals-table { width: 100%; border-collapse: collapse; font-size: 0.82rem; }
.intervals-table th { text-align: left; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); padding: 6px 10px; border-bottom: 2px solid var(--color-border-light); letter-spacing: 0.5px; }
.intervals-table td { padding: 8px 10px; border-bottom: 1px solid var(--color-border-light); }
.interval-active { background: rgba(59, 130, 246, 0.06); }
.interval-active td { font-weight: 600; }
.badge-interval { font-size: 0.68rem; font-weight: 600; padding: 2px 8px; border-radius: 10px; }
.badge-interval--active { background: #3B82F615; color: #3B82F6; }
.badge-interval--paused { background: #F59E0B15; color: #F59E0B; }
.badge-interval--completed { background: #10B98115; color: #10B981; }
.intervals-total { margin-top: 12px; padding: 10px 12px; background: var(--color-bg-secondary); border-radius: 8px; display: flex; align-items: center; justify-content: space-between; }
.intervals-total-label { font-size: 0.82rem; font-weight: 600; color: var(--color-text-secondary); }
.intervals-total-value { font-size: 1.1rem; font-weight: 700; color: var(--color-primary); }

/* ─── Procedures (SOP) ─────────────────────────────────────────────── */
.procedures-section { padding: var(--space-4) var(--space-6); }
.proc-card { background: var(--color-bg-secondary); border: 1px solid var(--color-border-light); border-radius: 8px; padding: 14px 16px; margin-bottom: 10px; }
.proc-card-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; }
.proc-card-title { font-size: 0.88rem; font-weight: 600; color: var(--color-text-primary); }
.proc-status { font-size: 0.68rem; font-weight: 600; padding: 2px 8px; border-radius: 10px; text-transform: uppercase; letter-spacing: 0.3px; }
.proc-status--completed { background: #10B98115; color: #10B981; }
.proc-status--in_progress { background: #3B82F615; color: #3B82F6; }
.proc-status--pending { background: #F59E0B15; color: #F59E0B; }
.proc-status--cancelled { background: #EF444415; color: #EF4444; }
.proc-card-progress { display: flex; align-items: center; gap: 10px; margin-bottom: 8px; }
.proc-card-bar { flex: 1; height: 6px; background: var(--color-border-light); border-radius: 3px; overflow: hidden; }
.proc-card-fill { height: 100%; background: var(--color-accent); border-radius: 3px; transition: width 0.3s ease; }
.proc-card-count { font-size: 0.75rem; font-weight: 600; color: var(--color-text-muted); white-space: nowrap; }
.proc-suggestions { margin-top: 12px; }
.proc-suggestions-title { font-size: 0.78rem; font-weight: 600; color: var(--color-text-secondary); display: block; margin-bottom: 8px; }
.proc-suggestion { display: flex; align-items: center; justify-content: space-between; padding: 10px 14px; background: var(--color-bg-secondary); border: 1px dashed var(--color-border-light); border-radius: 8px; margin-bottom: 6px; cursor: pointer; transition: border-color 0.2s; }
.proc-suggestion:hover { border-color: var(--color-accent); }
.proc-suggestion-title { font-size: 0.84rem; font-weight: 500; color: var(--color-text-primary); }
.proc-suggestion-meta { font-size: 0.72rem; color: var(--color-text-muted); }
.sop-btn { border: none; padding: 6px 14px; border-radius: 6px; font-size: 0.78rem; font-weight: 600; cursor: pointer; transition: opacity 0.2s; }
.sop-btn:hover { opacity: 0.85; }
.sop-btn--primary { background: var(--color-accent); color: #fff; }

</style>
