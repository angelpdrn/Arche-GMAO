<template>
  <div class="ai-admin-layout">
    <div class="page-header">
      <div>
        <h1 class="page-title">◬ Arche IA — Administración</h1>
        <p class="page-sub">Configuración, conocimiento y estadísticas de uso</p>
      </div>
    </div>

    <div class="admin-tabs">
      <button v-for="t in TABS" :key="t.id" class="admin-tab"
        :class="{ 'admin-tab--active': activeTab === t.id }"
        @click="activeTab = t.id; onTabChange(t.id)">
        {{ t.icon }} {{ t.label }}
      </button>
    </div>

    <!-- ─── Models ──────────────────────────────────────────────────────── -->
    <div v-if="activeTab === 'models'" class="tab-content">

      <div class="card">
        <div class="card-header"><span class="card-title">Modelo de chat</span></div>
        <div class="card-body">
          <div class="models-grid">
            <div v-for="m in modelsData?.models ?? []" :key="m.name"
              class="model-card" :class="{ 'model-card--active': chatModel === m.name }"
              @click="chatModel = m.name">
              <div class="model-card-top">
                <span class="model-name">{{ m.name }}</span>
                <span class="model-size">{{ formatSize(m.size) }}</span>
                <span v-if="chatModel === m.name" class="model-active-badge">Activo</span>
              </div>
              <p class="model-desc">{{ getModelDescription(m.name) }}</p>
            </div>
          </div>
          <div v-if="!modelsData?.models?.length" class="empty-state">
            <p>Ollama no disponible o sin modelos instalados.</p>
            <code class="code-block">ollama pull llama3<br>ollama pull nomic-embed-text</code>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header"><span class="card-title">Modelo de embeddings (indexación)</span></div>
        <div class="card-body">
          <div class="models-grid">
            <div v-for="m in modelsData?.models ?? []" :key="m.name"
              class="model-card" :class="{ 'model-card--active': embedModel === m.name }"
              @click="embedModel = m.name">
              <div class="model-card-top">
                <span class="model-name">{{ m.name }}</span>
                <span v-if="embedModel === m.name" class="model-active-badge">Activo</span>
              </div>
              <p class="model-desc">{{ getEmbedDescription(m.name) }}</p>
            </div>
          </div>
          <p class="field-hint" style="margin-top:8px">⚠ Cambiar el modelo de embeddings requiere re-indexar todo el conocimiento.</p>
          <button class="btn-primary" style="margin-top:12px" @click="saveModels" :disabled="!canWrite || savingModels">
            {{ savingModels ? 'Guardando...' : 'Guardar configuración de modelos' }}
          </button>
        </div>
      </div>

      <div class="card">
        <div class="card-header"><span class="card-title">Acceso a la IA por rol</span></div>
        <div class="card-body">
          <p class="field-hint" style="margin-bottom:16px">Selecciona qué roles pueden usar Arche IA. Administrador siempre tiene acceso.</p>
          <div class="roles-grid">
            <label v-for="role in ALL_ROLES" :key="role.value"
              class="role-toggle" :class="{ 'role-toggle--active': enabledRoles.includes(role.value) }">
              <input type="checkbox" :value="role.value" v-model="enabledRoles" :disabled="role.value === 'admin'" />

              <div>
                <span class="role-name">{{ role.label }}</span>
                <span class="role-desc">{{ role.desc }}</span>
              </div>
            </label>
          </div>
          <button class="btn-primary" style="margin-top:16px" @click="saveRoles" :disabled="!canWrite">Guardar permisos</button>

          <!-- Permission change log -->
          <div v-if="permissionLog.length" style="margin-top:24px">
            <p class="card-title" style="margin-bottom:8px">Historial de cambios de permisos</p>
            <div class="audit-list">
              <div v-for="e in permissionLog" :key="e.id" class="audit-row">
                <span class="audit-action audit-action--updated">{{ e.action }}</span>
                <span class="audit-user text-muted">{{ e.user_name }}</span>
                <span class="audit-date mono text-muted small">{{ formatDate(e.created_at) }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header"><span class="card-title">Prompt personalizado del sistema</span></div>
        <div class="card-body">
          <p class="field-hint" style="margin-bottom:8px">Instrucciones adicionales para la IA en todas las conversaciones. Deja vacío para usar el predeterminado.</p>
          <textarea v-model="systemPrompt" class="field-input" rows="4"
            placeholder="Ejemplo: Responde siempre en español formal. Menciona siempre la referencia del equipo afectado." />
          <button class="btn-primary" style="margin-top:10px" @click="saveSystemPrompt" :disabled="!canWrite">Guardar prompt</button>
        </div>
      </div>
    </div>

    <!-- ─── Knowledge ──────────────────────────────────────────────────── -->
    <div v-if="activeTab === 'knowledge'" class="tab-content">
      <div class="knowledge-toolbar">
        <div class="knowledge-filters">
          <!-- Folder selector -->
          <select v-model="activeFolder" class="filter-select" @change="loadKnowledge">
            <option value="">◇ Todas las carpetas</option>
            <option v-for="f in folders" :key="f" :value="f">◆ {{ f }}</option>
          </select>
          <select v-model="activeCategory" class="filter-select" @change="loadKnowledge">
            <option value="">Todas las categorías</option>
            <option v-for="c in CATEGORIES" :key="c.value" :value="c.value">{{ c.label }}</option>
          </select>
        </div>
        <div class="knowledge-actions-right">
          <button class="btn-secondary" @click="showFolderModal = true" :disabled="!canWrite">+ Carpeta</button>
          <button class="btn-secondary" @click="showUploadModal = true" :disabled="!canWrite">↑ Subir archivo</button>
          <button class="btn-primary" @click="openCreateKnowledge" :disabled="!canWrite">+ Añadir texto</button>
        </div>
      </div>

      <div class="card">
        <div class="knowledge-list">
          <template v-for="f in allFolders" :key="f">
            <div class="folder-header">
              <span class="folder-icon">◆</span>
              <span class="folder-name">{{ f }}</span>
              <span class="folder-count">{{ (knowledgeByFolder[f] ?? []).length }}</span>
              <div class="folder-header-actions" v-if="f !== 'General'">
                <button class="folder-action-btn" @click.stop="openRenameFolder(f)" title="Renombrar">✎</button>
                <button class="folder-action-btn folder-action-btn--del" @click.stop="confirmDeleteFolder(f)" title="Eliminar">✕</button>
              </div>
            </div>
            <div v-if="!(knowledgeByFolder[f] ?? []).length" class="folder-empty">
              Carpeta vacía — añade conocimiento aquí
            </div>
            <div v-for="k in (knowledgeByFolder[f] ?? [])" :key="k.id" class="knowledge-item"
              :class="{ 'knowledge-item--inactive': !k.is_active }">
              <div class="knowledge-icon">{{ CATEGORY_ICONS[k.category] ?? '◻' }}</div>
              <div class="knowledge-body">
                <div class="knowledge-title-row">
                  <span class="knowledge-title">{{ k.title }}</span>
                  <span class="knowledge-cat">{{ k.category }}</span>
                  <span v-if="!k.is_active" class="inactive-badge">Inactivo</span>
                </div>
                <div class="knowledge-meta text-muted small">
                  {{ k.content_length }} caracteres
                  <template v-if="k.source"> · {{ k.source }}</template>
                  <template v-if="k.created_by_name"> · {{ k.created_by_name }}</template>
                </div>
              </div>
              <div class="k-actions">
                <button class="action-btn" @click="openEditKnowledge(k)">✎</button>
                <button class="action-btn action-btn--del" @click="deleteKnowledge(k.id)">✕</button>
              </div>
            </div>
          </template>
          <div v-if="!knowledge.length && !allFolders.length" class="card-empty">
            No hay conocimiento indexado. Crea una carpeta y añade contenido.
          </div>
        </div>
      </div>
    </div>

    <!-- ─── Calculations ──────────────────────────────────────────────────────── -->
    <div v-if="activeTab === 'calculate'" class="tab-content">
      <div class="calc-layout">
        <!-- Calculation list -->
        <div class="calc-sidebar-panel">
          <div class="calc-panel-header">
            <span class="card-title">Cálculos disponibles</span>
            <button class="btn-sm-primary" @click="openCreateCalc">+ Nuevo</button>
          </div>
          <div class="calc-list">
            <div v-for="ct in calcs" :key="ct.id"
              class="calc-item" :class="{ 'calc-item--active': selectedCalc?.id === ct.id }"
              @click="selectCalc(ct)">
              <div class="calc-item-info">
                <span class="calc-item-title">{{ ct.title }}</span>
                <span class="calc-item-desc text-muted small">{{ ct.description }}</span>
              </div>
              <div class="calc-item-actions" v-if="!ct.is_builtin">
                <button class="action-btn-sm" @click.stop="openEditCalc(ct)">✎</button>
                <button class="action-btn-sm action-btn-sm--del" @click.stop="deleteCalc(ct.id)">✕</button>
              </div>
              <span v-if="ct.is_builtin" class="builtin-badge">predefinido</span>
            </div>
          </div>
        </div>

        <!-- Calculation form -->
        <div class="card" style="flex:1">
          <div v-if="!selectedCalc" class="card-empty">
            Selecciona un tipo de cálculo para comenzar.
          </div>
          <template v-else>
            <div class="card-header">
              <span class="card-title">{{ selectedCalc.title }}</span>
            </div>
            <div class="card-body">
              <p v-if="selectedCalc.description" class="calc-desc">{{ selectedCalc.description }}</p>
              <div v-for="param in selectedCalcParams" :key="param.key" class="field">
                <label class="field-label">{{ param.label }}</label>
                <input v-model="calcInputs[param.key]" class="field-input mono"
                  :placeholder="param.placeholder" />
              </div>
              <div v-if="!selectedCalcParams.length" class="field">
                <label class="field-label">Pregunta técnica</label>
                <textarea v-model="calcInputs['question']" class="field-input" rows="3"
                  placeholder="Describe el cálculo que necesitas..." />
              </div>
              <button class="btn-primary" style="margin-top:12px"
                :disabled="calculating" @click="runCalc">
                {{ calculating ? '◬ Calculando...' : '▶ Calcular' }}
              </button>
            </div>
            <div v-if="calcResult" class="calc-result">
              <div class="calc-result-header">◬ Resultado — Arche IA</div>
              <pre class="calc-result-text">{{ calcResult }}</pre>
            </div>
          </template>
        </div>
      </div>
    </div>

    <!-- ─── Statistics ─────────────────────────────────────────────────── -->
    <div v-if="activeTab === 'stats'" class="tab-content">
      <div v-if="stats" class="stats-grid">
        <div class="stat-card"><span class="stat-value">{{ stats.stats.total_queries }}</span><span class="stat-label">Consultas (30 días)</span></div>
        <div class="stat-card"><span class="stat-value">{{ stats.stats.queries_with_sources }}</span><span class="stat-label">Con fuentes verificadas</span></div>
        <div class="stat-card"><span class="stat-value">{{ stats.stats.indexed_chunks }}</span><span class="stat-label">Fragmentos indexados</span></div>
        <div class="stat-card"><span class="stat-value">{{ stats.stats.knowledge_items }}</span><span class="stat-label">Conocimiento activo</span></div>
        <div class="stat-card"><span class="stat-value">{{ stats.stats.avg_response_ms?.toFixed(0) }}ms</span><span class="stat-label">Tiempo medio</span></div>
      </div>
      <div class="card" v-if="stats?.top_users?.length">
        <div class="card-header"><span class="card-title">Top usuarios (30 días)</span></div>
        <div class="top-users">
          <div v-for="(u, i) in stats.top_users" :key="i" class="top-user-row">
            <span class="top-user-rank">#{{ i+1 }}</span>
            <span class="top-user-name">{{ u.full_name }}</span>
            <span class="top-user-count text-muted">{{ u.queries }} consultas</span>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><span class="card-title">Log de auditoría de conocimiento</span></div>
        <div v-if="!auditLog.length" class="card-empty">Sin actividad registrada</div>
        <div v-else class="audit-list">
          <div v-for="e in auditLog" :key="e.id" class="audit-row">
            <span class="audit-action" :class="`audit-action--${e.action}`">{{ e.action }}</span>
            <span class="audit-title">{{ e.knowledge_title ?? '—' }}</span>
            <span class="audit-user text-muted">{{ e.user_name }}</span>
            <span class="audit-date mono text-muted small">{{ formatDate(e.created_at) }}</span>
          </div>
        </div>
      </div>
    </div>

    <!-- ─── Knowledge modal ────────────────────────────────────────────── -->
    <Teleport to="body">
      <div v-if="showKnowledgeModal" class="modal-overlay" @click.self="showKnowledgeModal = false">
        <div class="knowledge-modal">
          <div class="modal-header">
            <h3>{{ editKnowledge ? 'Editar conocimiento' : 'Añadir conocimiento' }}</h3>
            <button class="modal-close" @click="showKnowledgeModal = false">✕</button>
          </div>
          <div class="modal-body">
            <div class="field-row">
              <div class="field">
                <label class="field-label">Título *</label>
                <input v-model="kForm.title" class="field-input" placeholder="Nombre descriptivo" />
              </div>
              <div class="field">
                <label class="field-label">Carpeta</label>
                <input v-model="kForm.folder" class="field-input" list="folders-list" placeholder="General" />
                <datalist id="folders-list">
                  <option v-for="f in folders" :key="f" :value="f" />
                </datalist>
              </div>
            </div>
            <div class="field-row">
              <div class="field">
                <label class="field-label">Categoría</label>
                <select v-model="kForm.category" class="field-input">
                  <option v-for="c in CATEGORIES" :key="c.value" :value="c.value">{{ c.label }}</option>
                </select>
              </div>
              <div class="field">
                <label class="field-label">Fuente (opcional)</label>
                <input v-model="kForm.source" class="field-input" placeholder="Manual, normativa..." />
              </div>
            </div>
            <div class="field">
              <label class="field-label">Contenido *</label>
              <textarea v-model="kForm.content" class="field-input" rows="9"
                placeholder="Introduce el texto que quieres que Arche IA aprenda y pueda usar en sus respuestas..." />
              <p class="field-hint">{{ kForm.content.length }} caracteres</p>
            </div>
            <div v-if="kError" class="modal-error">{{ kError }}</div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary" @click="showKnowledgeModal = false">Cancelar</button>
            <button class="btn-primary" :disabled="!canWrite || kSaving" @click="submitKnowledge">
              {{ kSaving ? 'Guardando...' : (editKnowledge ? 'Guardar cambios' : 'Añadir e indexar') }}
            </button>
          </div>
        </div>
      </div>

      <!-- Upload file modal -->
      <div v-if="showUploadModal" class="modal-overlay" @click.self="showUploadModal = false">
        <div class="upload-modal">
          <div class="modal-header">
            <h3>↑ Subir archivo de conocimiento</h3>
            <button class="modal-close" @click="showUploadModal = false">✕</button>
          </div>
          <div class="modal-body">
            <div class="upload-zone" @dragover.prevent @drop.prevent="onFileDrop"
              :class="{ 'upload-zone--active': uploadFile }">
              <template v-if="!uploadFile">
                <span class="upload-icon">◻</span>
                <p class="upload-label">Arrastra un PDF o .txt aquí</p>
                <p class="upload-sub">o</p>
                <label class="btn-secondary" style="cursor:pointer">
                  Seleccionar archivo
                  <input type="file" accept=".pdf,.txt" style="display:none" @change="onFileSelect" />
                </label>
                <p class="upload-hint">Máximo 5 MB — PDF con texto incrustado o .txt</p>
              </template>
              <template v-else>
                <span class="upload-file-icon">{{ uploadFile.name.endsWith('.pdf') ? '▤' : '◻' }}</span>
                <span class="upload-file-name">{{ uploadFile.name }}</span>
                <span class="upload-file-size text-muted small">{{ (uploadFile.size/1024).toFixed(0) }} KB</span>
                <button class="btn-sm-secondary" @click="uploadFile = null">Cambiar</button>
              </template>
            </div>
            <div class="field-row" style="margin-top:16px">
              <div class="field">
                <label class="field-label">Título</label>
                <input v-model="uploadTitle" class="field-input" placeholder="Nombre del documento" />
              </div>
              <div class="field">
                <label class="field-label">Carpeta</label>
                <input v-model="uploadFolder" class="field-input" list="folders-list" placeholder="General" />
              </div>
            </div>
            <div class="field">
              <label class="field-label">Categoría</label>
              <select v-model="uploadCategory" class="field-input">
                <option v-for="c in CATEGORIES" :key="c.value" :value="c.value">{{ c.label }}</option>
              </select>
            </div>
            <div v-if="uploadError" class="modal-error">{{ uploadError }}</div>
            <div v-if="uploadSuccess" class="modal-success">{{ uploadSuccess }}</div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary" @click="showUploadModal = false">Cancelar</button>
            <button class="btn-primary" :disabled="!canWrite || !uploadFile || uploading" @click="submitUpload">
              {{ uploading ? 'Procesando...' : '↑ Subir e indexar' }}
            </button>
          </div>
        </div>
      </div>

      <!-- Create folder modal -->
      <div v-if="showFolderModal" class="modal-overlay" @click.self="showFolderModal = false">
        <div class="folder-modal">
          <div class="modal-header">
            <h3>+ Nueva carpeta</h3>
            <button class="modal-close" @click="showFolderModal = false">✕</button>
          </div>
          <div class="modal-body">
            <div class="field">
              <label class="field-label">Nombre de la carpeta</label>
              <input v-model="newFolderName" class="field-input" placeholder="Ej: Manuales hidráulicos" autofocus
                @keydown.enter="createFolder" />
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary" @click="showFolderModal = false">Cancelar</button>
            <button class="btn-primary" :disabled="!canWrite || !newFolderName.trim()" @click="createFolder">Crear carpeta</button>
          </div>
        </div>
      </div>

      <!-- Rename folder modal -->
      <div v-if="showRenameFolderModal" class="modal-overlay" @click.self="showRenameFolderModal = false">
        <div class="folder-modal">
          <div class="modal-header">
            <h3>Renombrar carpeta</h3>
            <button class="modal-close" @click="showRenameFolderModal = false">✕</button>
          </div>
          <div class="modal-body">
            <div class="field">
              <label class="field-label">Nuevo nombre</label>
              <input v-model="renameFolderValue" class="field-input" autofocus
                @keydown.enter="submitRenameFolder" />
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary" @click="showRenameFolderModal = false">Cancelar</button>
            <button class="btn-primary" :disabled="!renameFolderValue.trim() || renamingFolder"
              @click="submitRenameFolder">
              {{ renamingFolder ? 'Guardando...' : 'Renombrar' }}
            </button>
          </div>
        </div>
      </div>

      <!-- Create/edit calculation modal -->
      <div v-if="showCalcModal" class="modal-overlay" @click.self="showCalcModal = false">
        <div class="knowledge-modal">
          <div class="modal-header">
            <h3>{{ editCalc ? 'Editar cálculo' : 'Nuevo cálculo personalizado' }}</h3>
            <button class="modal-close" @click="showCalcModal = false">✕</button>
          </div>
          <div class="modal-body">
            <div class="field">
              <label class="field-label">Título *</label>
              <input v-model="cForm.title" class="field-input" placeholder="Ej: Cálculo de ventilación industrial" />
            </div>
            <div class="field">
              <label class="field-label">Descripción</label>
              <input v-model="cForm.description" class="field-input" placeholder="Breve descripción de cuándo usar este cálculo" />
            </div>
            <div class="field">
              <label class="field-label">Plantilla del prompt *</label>
              <textarea v-model="cForm.prompt_template" class="field-input" rows="5"
                placeholder="Usa {nombre_param} para referenciar los parámetros. Ej: Calcula la ventilación para un volumen de {volumen} m³ con {personas} personas." />
              <p class="field-hint">Usa {nombre} para los campos del formulario. La IA los sustituirá al ejecutar el cálculo.</p>
            </div>
            <div class="field">
              <label class="field-label">Parámetros (JSON)</label>
              <textarea v-model="cForm.params_json" class="field-input mono" rows="5"
                placeholder='[{"key":"volumen","label":"Volumen (m³)","placeholder":"200"},{"key":"personas","label":"Número de personas","placeholder":"10"}]' />
              <p class="field-hint">Array de objetos con key, label y placeholder.</p>
            </div>
            <div v-if="cError" class="modal-error">{{ cError }}</div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary" @click="showCalcModal = false">Cancelar</button>
            <button class="btn-primary" :disabled="!canWrite || cSaving" @click="submitCalc">
              {{ cSaving ? 'Guardando...' : (editCalc ? 'Guardar' : 'Crear cálculo') }}
            </button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import { useToast, apiErrorMsg } from '@/composables/useToast'
const toast = useToast()
import { ref, computed, onMounted } from 'vue'
import client from '@/api/client'
import { useSystemPause } from '@/composables/useSystemPause'

const { canWrite } = useSystemPause()
const activeTab = ref('models')
const TABS = [
  { id: 'models',    icon: '⚙',  label: 'Modelos y permisos' },
  { id: 'knowledge', icon: '◈', label: 'Conocimiento' },
  { id: 'calculate', icon: '▦', label: 'Cálculos técnicos' },
  { id: 'stats',     icon: '▤', label: 'Estadísticas' },
]

// Descriptions by model name prefix
function getModelDescription(name: string): string {
  const n = name.toLowerCase().replace(':latest','').replace(':','')
  if (n.startsWith('llama3.2') || n.startsWith('llama3-2'))
    return 'Última versión de Llama3. La más equilibrada para uso industrial: buena comprensión técnica, respuestas precisas en español y tiempos de respuesta aceptables. Recomendada como opción principal.'
  if (n.startsWith('llama3.1') || n.startsWith('llama3-1'))
    return 'Versión mejorada de Llama3. Mayor capacidad de razonamiento en cadena. Útil para analizar averías complejas con múltiples causas. Algo más lento que Llama3 base.'
  if (n.startsWith('llama3') || n === 'llama3')
    return 'Modelo de propósito general sólido. Buen equilibrio entre velocidad y calidad. Funciona bien para consultas de mantenimiento cotidianas, historial de OTs y recomendaciones generales.'
  if (n.startsWith('mistral-nemo'))
    return 'Versión compacta y muy rápida de Mistral. Ideal cuando la velocidad es prioritaria y las consultas son simples o directas. Menor profundidad de análisis que los modelos más grandes.'
  if (n.startsWith('mistral'))
    return 'Modelo rápido y eficiente. Buenas respuestas para consultas directas. Recomendado si notas que Llama3 es demasiado lento en tu hardware. Ocupa menos recursos (4GB RAM).'
  if (n.startsWith('deepseek-r1'))
    return 'Especializado en razonamiento paso a paso. Excelente para diagnósticos de averías complejas y análisis de causa raíz. Más lento pero con mayor profundidad analítica.'
  if (n.startsWith('deepseek'))
    return 'Familia DeepSeek. Fuerte en razonamiento técnico y cálculos. Adecuado para análisis de fallos recurrentes y generación de informes detallados.'
  if (n.startsWith('phi3.5') || n.startsWith('phi-3.5'))
    return 'Versión mejorada de Phi3. Sorprendentemente capaz para su tamaño. Buena opción si el servidor tiene recursos limitados (menos de 8GB RAM disponibles).'
  if (n.startsWith('phi3') || n.startsWith('phi-3'))
    return 'Modelo compacto pero funcional. Consume muy pocos recursos. Recomendado solo si el hardware es muy limitado, ya que su comprensión técnica es menor que Llama3.'
  if (n.startsWith('gemma2') || n.startsWith('gemma-2'))
    return 'Modelo de Google. Alta precisión en respuestas técnicas estructuradas. Requiere más VRAM. Buena opción si dispones de GPU dedicada.'
  if (n.startsWith('gemma'))
    return 'Familia Gemma de Google. Respuestas claras y bien estructuradas. Requiere hardware con al menos 8GB RAM.'
  if (n.startsWith('qwen2.5') || n.startsWith('qwen-2.5'))
    return 'Fuerte en análisis técnico y razonamiento matemático. Muy adecuado para interpretar datos de sensores, tendencias de fallos y cálculos de mantenimiento.'
  if (n.startsWith('qwen'))
    return 'Familia Qwen. Buen rendimiento en tareas técnicas y analíticas. Multilingüe con buen soporte para español.'
  return 'Modelo de lenguaje local. Úsalo si es el único disponible o para comparar resultados con otros modelos.'
}

function getEmbedDescription(name: string): string {
  const n = name.toLowerCase().replace(':latest','')
  if (n.includes('nomic-embed'))
    return 'Recomendado para Arche IA. Optimizado para texto técnico en varios idiomas, incluyendo español. Buen equilibrio entre precisión semántica y velocidad de indexación.'
  if (n.includes('mxbai-embed'))
    return 'Alta precisión en búsqueda semántica. Encuentra mejor los documentos relevantes pero es más lento al indexar. Recomendado si tienes mucha documentación técnica cargada.'
  if (n.includes('all-minilm'))
    return 'Muy rápido y ligero. Menor precisión semántica pero indexa grandes volúmenes rápidamente. Útil si el rendimiento del servidor es limitado.'
  if (n.includes('llama3') || n.includes('mistral'))
    return 'Este es un modelo de chat, no está diseñado para embeddings. Se puede usar pero los resultados de búsqueda serán menos precisos que con nomic-embed-text.'
  return 'Modelo de vectorización de texto. Úsalo para indexar el conocimiento que Arche IA usará en sus respuestas.'
}

const CATEGORIES = [
  { value: 'procedure',   label: 'Procedimiento' },
  { value: 'equipment',  label: 'Equipo/Máquina' },
  { value: 'regulation', label: 'Normativa' },
  { value: 'calculation',label: 'Cálculo técnico' },
  { value: 'general',    label: 'General' },
]
const CATEGORY_ICONS: Record<string, string> = {
  procedure: '▤', equipment: '⚙', regulation: '≡', calculation: '▦', general: '◻'
}
const ALL_ROLES = [
  { value: 'admin',      label: 'Administrador', icon: '', desc: 'Acceso completo siempre' },
  { value: 'supervisor', label: 'Supervisor',    icon: '', desc: 'Supervisión y gestión' },
  { value: 'technician', label: 'Técnico',       icon: '', desc: 'Ejecución de OTs' },
  { value: 'operator',   label: 'Operario',      icon: '', desc: 'Operación en planta' },
  { value: 'warehouse',  label: 'Almacén',       icon: '', desc: 'Gestión de inventario' },
  { value: 'auditor',    label: 'Auditor',       icon: '', desc: 'Solo lectura' },
]

// ─── Models ──────────────────────────────────────────────────────────────────
const modelsData   = ref<any>(null)
const chatModel    = ref('llama3')
const embedModel   = ref('nomic-embed-text')
const savingModels = ref(false)
const enabledRoles = ref<string[]>(['admin','supervisor','technician','operator','warehouse','auditor'])
const systemPrompt = ref('')
const permissionLog = ref<any[]>([])

async function loadModels() {
  try {
    const { data } = await client.get('/ai/admin/models')
    modelsData.value = data
    if (data.chat_model)  chatModel.value = data.chat_model
    if (data.embed_model) embedModel.value = data.embed_model
  } catch { modelsData.value = { models: [] } }
}

async function loadRoles() {
  try {
    const { data } = await client.get('/ai/admin/roles')
    enabledRoles.value = JSON.parse(data.enabled_roles)
  } catch { /* silent */ }
}

async function loadPermissionLog() {
  try {
    const { data } = await client.get('/ai/admin/permission-log')
    permissionLog.value = data.log ?? []
  } catch { /* silent */ }
}

async function saveModels() {
  savingModels.value = true
  try {
    await client.put('/ai/admin/models', { chat_model: chatModel.value, embed_model: embedModel.value })
    toast.success('Modelos actualizados correctamente')
  } catch { toast.error('Error guardando') }
  finally { savingModels.value = false }
}

async function saveRoles() {
  try {
    await client.put('/ai/admin/roles', { enabled_roles: enabledRoles.value })
    await loadPermissionLog()
    toast.success('Permisos actualizados correctamente')
  } catch { toast.error('Error') }
}

async function saveSystemPrompt() {
  try {
    await client.post('/ai/admin/system-prompt', { prompt: systemPrompt.value })
    toast.success('Prompt guardado correctamente')
  } catch { toast.error('Error') }
}

// ─── Knowledge ─────────────────────────────────────────────────────────────
const knowledge        = ref<any[]>([])
const folders          = ref<string[]>([])
const activeFolder     = ref('')
const activeCategory   = ref('')
const showKnowledgeModal = ref(false)
const showUploadModal  = ref(false)
const showFolderModal        = ref(false)
const newFolderName          = ref('')
const showRenameFolderModal  = ref(false)
const renameFolderOldName    = ref('')
const renameFolderValue      = ref('')
const renamingFolder         = ref(false)
const editKnowledge    = ref<any>(null)
const kSaving          = ref(false)
const kError           = ref('')
const kForm            = ref({ title: '', content: '', category: 'general', folder: 'General', source: '' })
const uploadFile       = ref<File | null>(null)
const uploadTitle      = ref('')
const uploadFolder     = ref('General')
const uploadCategory   = ref('general')
const uploading        = ref(false)
const uploadError      = ref('')
const uploadSuccess    = ref('')

const allFolders = computed(() => {
  return [...folders.value].sort()
})

const knowledgeByFolder = computed(() => {
  const grouped: Record<string, any[]> = {}
  for (const k of knowledge.value) {
    const f = k.folder || 'General'
    if (!grouped[f]) grouped[f] = []
    grouped[f].push(k)
  }
  return grouped
})

async function loadKnowledge() {
  try {
    const [kData, fData] = await Promise.all([
      client.get('/ai/admin/knowledge', { params: { folder: activeFolder.value, category: activeCategory.value } }),
      client.get('/ai/admin/folders'),
    ])
    knowledge.value = kData.data.knowledge ?? []
    folders.value = (fData.data.folders ?? []).map((f: any) => f.name)
    if (!folders.value.includes('General')) folders.value.unshift('General')
  } catch { knowledge.value = [] }
}

function openCreateKnowledge() {
  editKnowledge.value = null
  kForm.value = { title: '', content: '', category: 'general', folder: activeFolder.value || 'General', source: '' }
  kError.value = ''
  showKnowledgeModal.value = true
}

async function openEditKnowledge(k: any) {
  editKnowledge.value = k
  try {
    const { data } = await client.get(`/ai/admin/knowledge/${k.id}`)
    kForm.value = { title: data.title, content: data.content, category: data.category, folder: data.folder ?? 'General', source: data.source ?? '' }
  } catch { kForm.value = { title: k.title, content: '', category: k.category, folder: k.folder ?? 'General', source: '' } }
  kError.value = ''
  showKnowledgeModal.value = true
}

async function submitKnowledge() {
  if (!kForm.value.title || !kForm.value.content) { kError.value = 'Título y contenido son obligatorios'; return }
  kSaving.value = true; kError.value = ''
  try {
    const payload = { ...kForm.value, source: kForm.value.source || null }
    if (editKnowledge.value) {
      await client.put(`/ai/admin/knowledge/${editKnowledge.value.id}`, { ...payload, is_active: true })
    } else {
      await client.post('/ai/admin/knowledge', payload)
    }
    showKnowledgeModal.value = false
    await loadKnowledge()
  } catch (err: unknown) {
    kError.value = apiErrorMsg(err, 'Error')
  } finally { kSaving.value = false }
}

async function deleteKnowledge(id: number) {
  if (!confirm('¿Eliminar este conocimiento del índice de la IA?')) return
  await client.delete(`/ai/admin/knowledge/${id}`)
  await loadKnowledge()
}

function openRenameFolder(name: string) {
  renameFolderOldName.value = name
  renameFolderValue.value = name
  showRenameFolderModal.value = true
}

async function submitRenameFolder() {
  const newName = renameFolderValue.value.trim()
  if (!newName || newName === renameFolderOldName.value) return
  renamingFolder.value = true
  try {
    // Get the folder ID
    const { data } = await client.get('/ai/admin/folders')
    const folder = (data.folders ?? []).find((f: any) => f.name === renameFolderOldName.value)
    if (!folder) { toast.error('Carpeta no encontrada'); return }
    await client.put(`/ai/admin/folders/${folder.id}`, { name: newName })
    showRenameFolderModal.value = false
    await loadKnowledge()
  } catch (err: unknown) {
    toast.fromError(err, 'Error renombrando carpeta')
  } finally { renamingFolder.value = false }
}

async function confirmDeleteFolder(name: string) {
  if (!confirm(`¿Eliminar la carpeta "${name}"? El conocimiento que contiene se moverá a General.`)) return
  try {
    const { data } = await client.get('/ai/admin/folders')
    const folder = (data.folders ?? []).find((f: any) => f.name === name)
    if (!folder) { toast.error('Carpeta no encontrada'); return }
    await client.delete(`/ai/admin/folders/${folder.id}`)
    await loadKnowledge()
  } catch (err: unknown) {
    toast.fromError(err, 'Error eliminando carpeta')
  }
}

async function createFolder() {
  const name = newFolderName.value.trim()
  if (!name) return
  try {
    await client.post('/ai/admin/folders', { name })
    await loadKnowledge()
    kForm.value.folder = name
    newFolderName.value = ''
    showFolderModal.value = false
  } catch (err: unknown) {
    toast.fromError(err, 'Error creando carpeta')
  }
}

function onFileSelect(e: Event) {
  const input = e.target as HTMLInputElement
  if (input.files?.[0]) {
    uploadFile.value = input.files[0]
    if (!uploadTitle.value) uploadTitle.value = input.files[0].name.replace(/\.[^.]+$/, '')
  }
}

function onFileDrop(e: DragEvent) {
  const file = e.dataTransfer?.files?.[0]
  if (file) {
    uploadFile.value = file
    if (!uploadTitle.value) uploadTitle.value = file.name.replace(/\.[^.]+$/, '')
  }
}

async function submitUpload() {
  if (!uploadFile.value) return
  uploading.value = true; uploadError.value = ''; uploadSuccess.value = ''
  try {
    const form = new FormData()
    form.append('file', uploadFile.value)
    form.append('title', uploadTitle.value || uploadFile.value.name)
    form.append('folder', uploadFolder.value || 'General')
    form.append('category', uploadCategory.value)
    const { data } = await client.post('/ai/admin/knowledge/upload', form, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })
    uploadSuccess.value = data.message
    uploadFile.value = null
    uploadTitle.value = ''
    await loadKnowledge()
    setTimeout(() => { showUploadModal.value = false; uploadSuccess.value = '' }, 2000)
  } catch (err: unknown) {
    uploadError.value = apiErrorMsg(err, 'Error procesando el archivo')
  } finally { uploading.value = false }
}

// ─── Calculations ─────────────────────────────────────────────────────────────────
const calcs          = ref<any[]>([])
const selectedCalc   = ref<any>(null)
const calcInputs     = ref<Record<string, string>>({})
const calcResult     = ref('')
const calculating    = ref(false)
const showCalcModal  = ref(false)
const editCalc       = ref<any>(null)
const cSaving        = ref(false)
const cError         = ref('')
const cForm          = ref({ title: '', description: '', prompt_template: '', params_json: '[]' })

const selectedCalcParams = computed(() => {
  if (!selectedCalc.value) return []
  try {
    return typeof selectedCalc.value.params === 'string'
      ? JSON.parse(selectedCalc.value.params)
      : selectedCalc.value.params ?? []
  } catch { return [] }
})

async function loadCalcs() {
  try {
    const { data } = await client.get('/ai/calcs')
    calcs.value = data.calcs ?? []
    if (calcs.value.length) selectedCalc.value = calcs.value[0]
  } catch { calcs.value = [] }
}

function selectCalc(c: any) {
  selectedCalc.value = c
  calcInputs.value = {}
  calcResult.value = ''
}

async function runCalc() {
  if (!selectedCalc.value) return
  calculating.value = true; calcResult.value = ''
  try {
    const { data } = await client.post('/ai/calculate', {
      calc_id: selectedCalc.value.id,
      params: calcInputs.value
    })
    calcResult.value = data.result
  } catch (err: unknown) {
    calcResult.value = apiErrorMsg(err, 'Error ejecutando el cálculo')
  } finally { calculating.value = false }
}

function openCreateCalc() {
  editCalc.value = null
  cForm.value = { title: '', description: '', prompt_template: '', params_json: '[]' }
  cError.value = ''
  showCalcModal.value = true
}

function openEditCalc(c: any) {
  editCalc.value = c
  cForm.value = {
    title: c.title,
    description: c.description ?? '',
    prompt_template: c.prompt_template ?? '',
    params_json: typeof c.params === 'string' ? c.params : JSON.stringify(c.params, null, 2)
  }
  cError.value = ''
  showCalcModal.value = true
}

async function submitCalc() {
  if (!cForm.value.title || !cForm.value.prompt_template) {
    cError.value = 'Título y plantilla son obligatorios'; return
  }
  let params
  try { params = JSON.parse(cForm.value.params_json) }
  catch { cError.value = 'Los parámetros no son JSON válido'; return }

  cSaving.value = true; cError.value = ''
  try {
    if (editCalc.value) {
      await client.put(`/ai/admin/calcs/${editCalc.value.id}`, { ...cForm.value, params })
    } else {
      await client.post('/ai/admin/calcs', { ...cForm.value, params })
    }
    showCalcModal.value = false
    await loadCalcs()
  } catch (err: unknown) {
    cError.value = apiErrorMsg(err, 'Error')
  } finally { cSaving.value = false }
}

async function deleteCalc(id: number) {
  if (!confirm('¿Eliminar este cálculo?')) return
  await client.delete(`/ai/admin/calcs/${id}`)
  await loadCalcs()
  if (selectedCalc.value?.id === id) selectedCalc.value = calcs.value[0] ?? null
}

// ─── Stats ────────────────────────────────────────────────────────────────────
const stats    = ref<any>(null)
const auditLog = ref<any[]>([])

async function loadStats() {
  try {
    const [s, l] = await Promise.all([
      client.get('/ai/admin/stats'),
      client.get('/ai/admin/log'),
    ])
    stats.value = s.data
    auditLog.value = l.data.log ?? []
  } catch { /* silent */ }
}

function onTabChange(tab: string) {
  if (tab === 'knowledge') loadKnowledge()
  if (tab === 'stats') loadStats()
  if (tab === 'calculate') loadCalcs()
}

function formatDate(iso: string) {
  try { return new Date(iso).toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) }
  catch { return iso }
}
function formatSize(b: number) { return b ? (b/1024/1024/1024).toFixed(1)+'GB' : '' }

onMounted(async () => {
  await Promise.all([loadModels(), loadRoles(), loadPermissionLog(), loadKnowledge(), loadCalcs()])
})
</script>

<style scoped>
.ai-admin-layout { display: flex; flex-direction: column; gap: var(--space-5); }
.page-title { font-size: 1.4rem; font-weight: 700; color: var(--color-primary); }
.page-sub { font-size: 0.8rem; color: var(--color-text-muted); }
.admin-tabs { display: flex; border-bottom: 2px solid var(--color-border-light); }
.admin-tab { height: 42px; padding: 0 var(--space-5); background: none; border: none; font-size: 0.875rem; color: var(--color-text-muted); cursor: pointer; border-bottom: 2px solid transparent; margin-bottom: -2px; transition: all var(--transition); }
.admin-tab:hover { color: var(--color-text); }
.admin-tab--active { color: var(--color-primary); border-bottom-color: var(--color-primary); font-weight: 600; }
.tab-content { display: flex; flex-direction: column; gap: var(--space-4); }
.card { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); overflow: hidden; }
.card-header { display: flex; align-items: center; justify-content: space-between; padding: var(--space-3) var(--space-5); border-bottom: 1px solid var(--color-border-light); background: var(--color-surface-2); }
.card-title { font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--color-text-muted); }
.card-body { padding: var(--space-5); display: flex; flex-direction: column; gap: var(--space-4); }
.card-empty { padding: var(--space-8); text-align: center; font-size: 0.875rem; color: var(--color-text-muted); }

/* Models */
.models-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: var(--space-3); }
.model-card { border: 2px solid var(--color-border-light); border-radius: var(--radius-md); padding: var(--space-4); cursor: pointer; transition: all var(--transition); }
.model-card:hover { border-color: var(--color-accent); }
.model-card--active { border-color: var(--color-primary); background: rgba(15,52,96,0.04); }
.model-card-top { display: flex; align-items: center; gap: var(--space-2); margin-bottom: var(--space-2); flex-wrap: wrap; }
.model-name { font-size: 0.875rem; font-weight: 600; font-family: var(--font-mono); }
.model-size { font-size: 0.68rem; color: var(--color-text-muted); margin-left: auto; }
.model-active-badge { font-size: 0.65rem; background: rgba(15,52,96,0.1); color: var(--color-primary); padding: 2px 6px; border-radius: 10px; font-weight: 600; }
.model-desc { font-size: 0.78rem; color: var(--color-text-muted); line-height: 1.5; }
.code-block { display: block; background: var(--color-surface-2); border: 1px solid var(--color-border); border-radius: var(--radius); padding: var(--space-3); font-family: var(--font-mono); font-size: 0.82rem; margin-top: var(--space-3); white-space: pre; }
.empty-state { text-align: center; color: var(--color-text-muted); font-size: 0.875rem; }

/* Roles */
.roles-grid { display: flex; flex-wrap: wrap; gap: var(--space-2); }
.role-toggle { display: flex; align-items: center; gap: var(--space-3); padding: var(--space-3) var(--space-4); border: 1.5px solid var(--color-border); border-radius: var(--radius-md); cursor: pointer; transition: all var(--transition); }
.role-toggle--active { border-color: var(--color-accent); background: rgba(15,52,96,0.05); }
.role-toggle input { display: none; }
.role-icon { font-size: 1.1rem; }
.role-name { display: block; font-size: 0.82rem; font-weight: 600; }
.role-desc { display: block; font-size: 0.68rem; color: var(--color-text-muted); }

/* Knowledge */
.knowledge-toolbar { display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: var(--space-3); }
.knowledge-filters { display: flex; gap: var(--space-2); }
.knowledge-actions-right { display: flex; gap: var(--space-2); }
.filter-select { height: 36px; padding: 0 var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.82rem; background: var(--color-surface); }
.folder-header-actions { margin-left: var(--space-2); display: flex; gap: 2px; }
.folder-action-btn { width: 22px; height: 22px; background: none; border: 1px solid var(--color-border); border-radius: var(--radius-sm); cursor: pointer; font-size: 0.65rem; color: var(--color-text-muted); display: flex; align-items: center; justify-content: center; }
.folder-action-btn:hover { background: var(--color-border-light); color: var(--color-text); }
.folder-action-btn--del:hover { color: var(--color-alert); }
.folder-header { display: flex; align-items: center; gap: var(--space-2); padding: var(--space-2) var(--space-4); background: var(--color-surface-2); border-bottom: 1px solid var(--color-border-light); }
.folder-icon { font-size: 0.9rem; }
.folder-name { font-size: 0.75rem; font-weight: 600; color: var(--color-text-muted); text-transform: uppercase; letter-spacing: 0.5px; }
.folder-count { margin-left: auto; font-size: 0.72rem; color: var(--color-text-muted); background: var(--color-border-light); border-radius: 10px; padding: 1px 6px; }
.knowledge-list { display: flex; flex-direction: column; }
.folder-empty { padding: var(--space-3) var(--space-5); font-size: 0.78rem; color: var(--color-text-muted); font-style: italic; border-bottom: 1px solid var(--color-border-light); }
.knowledge-item { display: flex; align-items: flex-start; gap: var(--space-4); padding: var(--space-3) var(--space-5); border-bottom: 1px solid var(--color-border-light); }
.knowledge-item:last-child { border-bottom: none; }
.knowledge-item--inactive { opacity: 0.45; }
.knowledge-icon { font-size: 1.2rem; flex-shrink: 0; }
.knowledge-body { flex: 1; min-width: 0; }
.knowledge-title-row { display: flex; align-items: center; gap: var(--space-2); flex-wrap: wrap; margin-bottom: 2px; }
.knowledge-title { font-size: 0.875rem; font-weight: 500; }
.knowledge-cat { font-size: 0.65rem; background: rgba(15,52,96,0.08); color: var(--color-accent); padding: 2px 6px; border-radius: 10px; }
.inactive-badge { font-size: 0.65rem; background: rgba(233,69,96,0.1); color: var(--color-alert); padding: 2px 6px; border-radius: 10px; }
.knowledge-meta { font-size: 0.75rem; }
.k-actions { display: flex; gap: var(--space-1); flex-shrink: 0; }
.action-btn { width: 28px; height: 28px; background: var(--color-surface-2); border: 1px solid var(--color-border); border-radius: var(--radius-sm); cursor: pointer; font-size: 0.75rem; color: var(--color-text-muted); }
.action-btn:hover { background: var(--color-border-light); }
.action-btn--del:hover { color: var(--color-alert); }

/* Upload */
.upload-zone { border: 2px dashed var(--color-border); border-radius: var(--radius-md); padding: var(--space-8); text-align: center; cursor: pointer; display: flex; flex-direction: column; align-items: center; gap: var(--space-2); transition: border-color var(--transition); }
.upload-zone--active { border-color: var(--color-accent); background: rgba(15,52,96,0.03); }
.upload-icon { font-size: 2.5rem; }
.upload-label { font-size: 0.9rem; font-weight: 500; color: var(--color-text); }
.upload-sub { font-size: 0.75rem; color: var(--color-text-muted); }
.upload-hint { font-size: 0.72rem; color: var(--color-text-muted); }
.upload-file-icon { font-size: 2rem; }
.upload-file-name { font-size: 0.875rem; font-weight: 600; }
.upload-file-size { font-size: 0.75rem; }
.modal-success { background: rgba(39,174,96,0.08); border: 1px solid rgba(39,174,96,0.3); border-radius: var(--radius); padding: var(--space-3); font-size: 0.875rem; color: #27AE60; }

/* Calculations */
.calc-layout { display: grid; grid-template-columns: 280px 1fr; gap: var(--space-4); align-items: start; }
.calc-sidebar-panel { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); overflow: hidden; }
.calc-panel-header { display: flex; align-items: center; justify-content: space-between; padding: var(--space-3) var(--space-4); border-bottom: 1px solid var(--color-border-light); background: var(--color-surface-2); }
.calc-list { display: flex; flex-direction: column; max-height: 60vh; overflow-y: auto; }
.calc-item { display: flex; align-items: flex-start; gap: var(--space-3); padding: var(--space-3) var(--space-4); border-bottom: 1px solid var(--color-border-light); cursor: pointer; transition: background var(--transition); }
.calc-item:last-child { border-bottom: none; }
.calc-item:hover { background: var(--color-surface-2); }
.calc-item--active { background: rgba(15,52,96,0.06); border-right: 2px solid var(--color-primary); }
.calc-item-info { flex: 1; min-width: 0; }
.calc-item-title { display: block; font-size: 0.82rem; font-weight: 500; }
.calc-item-desc { display: block; font-size: 0.72rem; margin-top: 1px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.calc-item-actions { display: flex; gap: 2px; flex-shrink: 0; }
.action-btn-sm { width: 22px; height: 22px; background: none; border: 1px solid var(--color-border); border-radius: var(--radius-sm); cursor: pointer; font-size: 0.65rem; color: var(--color-text-muted); display: flex; align-items: center; justify-content: center; }
.action-btn-sm:hover { background: var(--color-surface-2); }
.action-btn-sm--del:hover { color: var(--color-alert); }
.builtin-badge { font-size: 0.6rem; color: var(--color-text-muted); background: var(--color-surface-2); border: 1px solid var(--color-border); padding: 1px 5px; border-radius: 10px; white-space: nowrap; flex-shrink: 0; }
.calc-desc { font-size: 0.82rem; color: var(--color-text-muted); background: var(--color-surface-2); padding: var(--space-3); border-radius: var(--radius); line-height: 1.5; }
.calc-result { margin: 0 var(--space-5) var(--space-5); background: rgba(15,52,96,0.04); border: 1px solid rgba(15,52,96,0.2); border-radius: var(--radius-md); padding: var(--space-4); }
.calc-result-header { font-size: 0.7rem; font-weight: 700; text-transform: uppercase; color: var(--color-accent); margin-bottom: var(--space-3); }
.calc-result-text { font-size: 0.875rem; line-height: 1.8; white-space: pre-wrap; font-family: var(--font-ui); }

/* Stats */
.stats-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: var(--space-4); }
.stat-card { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); padding: var(--space-5); text-align: center; }
.stat-value { display: block; font-size: 1.8rem; font-weight: 700; font-family: var(--font-mono); color: var(--color-primary); }
.stat-label { display: block; font-size: 0.72rem; color: var(--color-text-muted); margin-top: 4px; }
.top-users { display: flex; flex-direction: column; }
.top-user-row { display: flex; align-items: center; gap: var(--space-4); padding: var(--space-3) var(--space-5); border-bottom: 1px solid var(--color-border-light); }
.top-user-row:last-child { border-bottom: none; }
.top-user-rank { font-size: 0.75rem; color: var(--color-text-muted); width: 24px; }
.top-user-name { flex: 1; font-size: 0.875rem; font-weight: 500; }
.top-user-count { font-size: 0.75rem; }
.audit-list { display: flex; flex-direction: column; max-height: 400px; overflow-y: auto; }
.audit-row { display: flex; align-items: center; gap: var(--space-4); padding: var(--space-2) var(--space-5); border-bottom: 1px solid var(--color-border-light); }
.audit-row:last-child { border-bottom: none; }
.audit-action { font-size: 0.65rem; font-weight: 700; padding: 2px 7px; border-radius: 10px; text-transform: uppercase; flex-shrink: 0; }
.audit-action--created    { background: rgba(39,174,96,0.1);  color: #27AE60; }
.audit-action--updated    { background: rgba(59,130,246,0.1);  color: #3B82F6; }
.audit-action--deactivated{ background: rgba(243,156,18,0.1);  color: #F39C12; }
.audit-action--indexed    { background: rgba(139,92,246,0.1);  color: #8B5CF6; }
.audit-action--roles_changed { background: rgba(233,69,96,0.1); color: var(--color-alert); }
.audit-action--model_changed { background: rgba(15,52,96,0.1);  color: var(--color-primary); }
.audit-title { flex: 1; font-size: 0.82rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.audit-user { font-size: 0.75rem; white-space: nowrap; }
.audit-date { font-size: 0.72rem; white-space: nowrap; }

/* Modals */
.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; padding: var(--space-4); }
.knowledge-modal, .upload-modal, .folder-modal { background: var(--color-surface); border-radius: var(--radius-lg); width: 100%; max-width: 600px; max-height: 90vh; display: flex; flex-direction: column; box-shadow: var(--shadow-lg); }
.folder-modal { max-width: 380px; }
.modal-header { display: flex; justify-content: space-between; align-items: center; padding: var(--space-4) var(--space-5); border-bottom: 1px solid var(--color-border-light); }
.modal-header h3 { font-size: 1rem; font-weight: 600; color: var(--color-primary); }
.modal-close { background: none; border: none; font-size: 1rem; cursor: pointer; color: var(--color-text-muted); }
.modal-body { flex: 1; overflow-y: auto; padding: var(--space-5); display: flex; flex-direction: column; gap: var(--space-4); }
.modal-footer { display: flex; justify-content: flex-end; gap: var(--space-3); padding: var(--space-4) var(--space-5); border-top: 1px solid var(--color-border-light); }
.modal-error { background: rgba(233,69,96,0.08); border: 1px solid rgba(233,69,96,0.3); border-radius: var(--radius); padding: var(--space-3); font-size: 0.875rem; color: var(--color-alert); }

/* Fields */
.field { display: flex; flex-direction: column; gap: var(--space-1); }
.field-row { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-3); }
.field-label { font-size: 0.68rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); }
.field-input { height: 38px; padding: 0 var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; background: var(--color-surface); outline: none; width: 100%; }
.field-input:focus { border-color: var(--color-accent); }
textarea.field-input { height: auto; padding: var(--space-2) var(--space-3); resize: vertical; font-family: var(--font-ui); }
.field-hint { font-size: 0.72rem; color: var(--color-text-muted); }
.btn-primary { height: 36px; padding: 0 var(--space-5); background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); font-size: 0.875rem; font-weight: 500; cursor: pointer; white-space: nowrap; }
.btn-primary:hover:not(:disabled) { background: var(--color-accent); }
.btn-primary:disabled { opacity: 0.65; cursor: not-allowed; }
.btn-secondary { height: 36px; padding: 0 var(--space-4); background: var(--color-surface-2); color: var(--color-text); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; cursor: pointer; white-space: nowrap; }
.btn-sm-primary { height: 28px; padding: 0 var(--space-3); background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius-sm); font-size: 0.75rem; cursor: pointer; }
.btn-sm-secondary { height: 28px; padding: 0 var(--space-3); background: var(--color-surface-2); color: var(--color-text); border: 1px solid var(--color-border); border-radius: var(--radius-sm); font-size: 0.75rem; cursor: pointer; }
.text-muted { color: var(--color-text-muted); }
.small { font-size: 0.75rem; }
.mono { font-family: var(--font-mono); }

@media (max-width: 768px) {
  .page-header { flex-direction: column; gap: var(--space-3); }
  .page-title { font-size: 1.15rem; }
  .admin-tabs { overflow-x: auto; -webkit-overflow-scrolling: touch; padding: 0 var(--space-3); }
  .admin-tab { height: 44px; font-size: 0.82rem; padding: 0 var(--space-3); white-space: nowrap; flex-shrink: 0; }
  .tab-content { padding: var(--space-4); }

  .modal-overlay { padding: 0; }
  .create-modal { max-width: 100%; border-radius: 0; max-height: 100vh; max-height: 100dvh; overflow-y: auto; }
  .modal-body { padding: var(--space-4); }
  .field-input { height: 42px; }
  textarea.field-input { font-size: 1rem; }
  .btn-primary, .btn-secondary { height: 44px; font-size: 0.9rem; }
  .btn-sm-primary, .btn-sm-secondary { height: 36px; font-size: 0.78rem; }
}
</style>
