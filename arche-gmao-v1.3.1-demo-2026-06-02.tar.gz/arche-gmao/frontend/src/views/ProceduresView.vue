<template>
  <div class="proc-page">
    <div class="page-header">
      <div>
        <h1 class="page-title">Procedimientos (SOP)</h1>
        <p class="page-sub">{{ templates.length }} plantillas</p>
      </div>
      <div class="header-actions">
        <select v-model="filterCategory" class="filter-select" @change="loadTemplates">
          <option value="">Todas las categorías</option>
          <option v-for="(label, key) in CATEGORY_LABELS" :key="key" :value="key">{{ label }}</option>
        </select>
        <button class="btn-primary" @click="openCreate">+ Nuevo procedimiento</button>
      </div>
    </div>

    <div v-if="loading" class="loading-state">Cargando procedimientos...</div>

    <div v-else-if="!templates.length" class="empty-state">
      <p>No hay procedimientos creados.</p>
      <p class="text-muted">Cree uno manualmente o genere uno con IA.</p>
    </div>

    <div v-else class="proc-grid">
      <div v-for="t in templates" :key="t.id" class="proc-tcard" @click="openEdit(t)">
        <div class="proc-tcard-header">
          <span class="proc-tcard-title">{{ t.title }}</span>
          <span :class="['proc-cat-badge', 'proc-cat--' + t.category]">{{ CATEGORY_LABELS[t.category] ?? t.category }}</span>
        </div>
        <p v-if="t.description" class="proc-tcard-desc">{{ t.description }}</p>
        <div class="proc-tcard-meta">
          <span>{{ t.step_count }} pasos</span>
          <span v-if="t.node_type_target" class="proc-tcard-target">{{ t.node_type_target }}</span>
          <span>{{ t.execution_count }} ejecuciones</span>
          <span :class="['proc-active-dot', t.is_active ? 'proc-active-dot--on' : 'proc-active-dot--off']">{{ t.is_active ? 'Activo' : 'Inactivo' }}</span>
        </div>
      </div>
    </div>

    <!-- ─── Create/edit modal ──────────────────────────────────────────── -->
    <Teleport to="body">
      <div v-if="showEditor" class="modal-overlay" @click.self="showEditor = false">
        <div class="proc-editor-modal">
          <div class="proc-editor-header">
            <h3>{{ editingId ? 'Editar procedimiento' : 'Nuevo procedimiento' }}</h3>
            <div class="proc-editor-actions">
              <button v-if="!editingId" class="btn-ai" @click="openAIGenerator" :disabled="generating" title="Generar con IA">
                ◆ Generar con IA
              </button>
              <button class="modal-close" @click="showEditor = false">&#x2715;</button>
            </div>
          </div>

          <div class="proc-editor-body">
            <!-- Basic data -->
            <div class="proc-editor-basics">
              <div class="field">
                <label class="field-label">Título *</label>
                <input v-model="form.title" class="field-input" placeholder="Ej: Inspección mensual bomba hidráulica" />
              </div>
              <div class="field-row">
                <div class="field">
                  <label class="field-label">Categoría</label>
                  <select v-model="form.category" class="field-input">
                    <option v-for="(label, key) in CATEGORY_LABELS" :key="key" :value="key">{{ label }}</option>
                  </select>
                </div>
                <div class="field">
                  <label class="field-label">Tipo de equipo objetivo</label>
                  <select v-model="form.node_type_target" class="field-input">
                    <option value="">Sin restricción</option>
                    <option value="equipment">Equipo</option>
                    <option value="machine">Máquina</option>
                    <option value="line">Línea</option>
                    <option value="area">Área</option>
                  </select>
                </div>
              </div>
              <div class="field">
                <label class="field-label">Descripción</label>
                <textarea v-model="form.description" class="field-input" rows="2" placeholder="Descripción opcional del procedimiento"></textarea>
              </div>
              <div v-if="editingId" class="field">
                <label class="field-label-inline">
                  <input type="checkbox" v-model="form.is_active" />
                  Activo
                </label>
              </div>
            </div>

            <!-- Step editor -->
            <div class="steps-editor">
              <div class="steps-editor-header">
                <span class="steps-editor-title">Pasos ({{ form.steps.length }})</span>
                <button class="btn-ghost btn-sm" @click="addStep">+ Agregar paso</button>
              </div>

              <div v-if="!form.steps.length" class="steps-empty">
                Sin pasos. Agregue uno manualmente o genere con IA.
              </div>

              <draggable v-else v-model="form.steps" item-key="uid" handle=".step-drag" @end="renumberSteps" class="steps-list" tag="div">
                <template #item="{ element: step, index }">
                  <div class="step-card">
                    <div class="step-card-header">
                      <span class="step-drag" title="Arrastrar para reordenar">&#x2630;</span>
                      <span class="step-number">{{ index + 1 }}</span>
                      <input v-model="step.title" class="step-title-input" placeholder="Título del paso" />
                      <select v-model="step.step_type" class="step-type-select" @change="resetStepConfig(step)">
                        <option v-for="(label, key) in STEP_TYPE_LABELS" :key="key" :value="key">{{ label }}</option>
                      </select>
                      <label class="step-required-toggle" title="Obligatorio">
                        <input type="checkbox" v-model="step.is_required" />
                        Req.
                      </label>
                      <button class="step-remove" @click="removeStep(index)" title="Eliminar paso">&#x2715;</button>
                    </div>

                    <div class="step-card-body">
                      <div class="field">
                        <input v-model="step.description" class="field-input field-input--sm" placeholder="Descripción opcional del paso" />
                      </div>

                      <!-- Config per type -->
                      <div v-if="step.step_type === 'numeric' || step.step_type === 'meter_reading'" class="step-config-row">
                        <div class="field">
                          <label class="field-label-sm">Unidad</label>
                          <input v-model="step.config.unit" class="field-input field-input--sm" placeholder="°C, bar, mm..." />
                        </div>
                        <div class="field">
                          <label class="field-label-sm">Min</label>
                          <input v-model.number="step.config.min" type="number" class="field-input field-input--sm" />
                        </div>
                        <div class="field">
                          <label class="field-label-sm">Max</label>
                          <input v-model.number="step.config.max" type="number" class="field-input field-input--sm" />
                        </div>
                        <div class="field">
                          <label class="field-label-sm">Alerta min</label>
                          <input v-model.number="step.config.alert_min" type="number" class="field-input field-input--sm" />
                        </div>
                        <div class="field">
                          <label class="field-label-sm">Alerta max</label>
                          <input v-model.number="step.config.alert_max" type="number" class="field-input field-input--sm" />
                        </div>
                      </div>

                      <div v-if="step.step_type === 'selection'" class="step-config-row">
                        <div class="field" style="flex:1">
                          <label class="field-label-sm">Opciones (separadas por coma)</label>
                          <input :value="(step.config.options ?? []).join(', ')"
                                 @input="step.config.options = ($event.target as HTMLInputElement).value.split(',').map((s: string) => s.trim()).filter(Boolean)"
                                 class="field-input field-input--sm" placeholder="Bueno, Regular, Malo" />
                        </div>
                      </div>

                      <div v-if="step.step_type === 'passfail'" class="step-config-row">
                        <div class="field">
                          <label class="field-label-sm">Si falla</label>
                          <select v-model="step.config.fail_action" class="field-input field-input--sm">
                            <option value="warn">Advertir</option>
                            <option value="stop">Detener procedimiento</option>
                            <option value="continue">Continuar</option>
                          </select>
                        </div>
                      </div>

                      <div v-if="step.step_type === 'text'" class="step-config-row">
                        <div class="field">
                          <label class="field-label-sm">Longitud máxima</label>
                          <input v-model.number="step.config.max_length" type="number" class="field-input field-input--sm" placeholder="500" />
                        </div>
                      </div>

                      <div v-if="step.step_type === 'photo'" class="step-config-row">
                        <div class="field">
                          <label class="field-label-sm">Fotos mínimas</label>
                          <input v-model.number="step.config.min_photos" type="number" class="field-input field-input--sm" placeholder="1" />
                        </div>
                        <div class="field">
                          <label class="field-label-sm">Fotos máximas</label>
                          <input v-model.number="step.config.max_photos" type="number" class="field-input field-input--sm" placeholder="3" />
                        </div>
                      </div>
                    </div>
                  </div>
                </template>
              </draggable>
            </div>

            <!-- Links (only while editing) -->
            <div v-if="editingId" class="links-section">
              <div class="steps-editor-header">
                <span class="steps-editor-title">Vinculaciones</span>
                <button class="btn-ghost btn-sm" @click="showLinkForm = !showLinkForm">+ Vincular</button>
              </div>
              <div v-if="editLinks.length" class="links-list">
                <div v-for="link in editLinks" :key="link.id" class="link-item">
                  <span v-if="link.node_name">Equipo: {{ link.node_name }}</span>
                  <span v-else-if="link.plan_title">Plan: {{ link.plan_title }}</span>
                  <span v-else-if="link.wo_type">Tipo OT: {{ link.wo_type }}</span>
                  <button class="link-remove" @click="unlinkTemplate(link.id)">&#x2715;</button>
                </div>
              </div>
              <div v-else class="text-muted" style="font-size:0.8rem">Sin vinculaciones</div>
              <div v-if="showLinkForm" class="link-form">
                <select v-model="linkType" class="field-input field-input--sm">
                  <option value="wo_type">Tipo de OT</option>
                  <option value="node">Equipo / Nodo</option>
                  <option value="plan">Plan de mantenimiento</option>
                </select>
                <select v-if="linkType === 'wo_type'" v-model="linkValue" class="field-input field-input--sm">
                  <option value="">Seleccionar...</option>
                  <option value="corrective">Correctiva</option>
                  <option value="preventive">Preventiva</option>
                  <option value="predictive">Predictiva</option>
                  <option value="improvement">Mejora</option>
                  <option value="installation">Instalación</option>
                </select>
                <select v-else-if="linkType === 'node'" v-model="linkValue" class="field-input field-input--sm">
                  <option value="">Seleccionar nodo...</option>
                  <option v-for="n in linkNodes" :key="n.id" :value="String(n.id)">{{ n.indent }}{{ n.name }} ({{ n.node_type }})</option>
                </select>
                <select v-else-if="linkType === 'plan'" v-model="linkValue" class="field-input field-input--sm">
                  <option value="">Seleccionar plan...</option>
                  <option v-for="p in linkPlans" :key="p.id" :value="String(p.id)">{{ p.title }}</option>
                </select>
                <button class="btn-primary btn-sm" @click="addLink" :disabled="!linkValue">Vincular</button>
              </div>
            </div>
          </div>

          <div v-if="editorError" class="modal-error">{{ editorError }}</div>

          <div class="proc-editor-footer">
            <button v-if="editingId" class="btn-danger btn-sm" @click="deleteTemplate" :disabled="saving">Eliminar</button>
            <div class="proc-editor-footer-right">
              <button class="btn-secondary" @click="showEditor = false">Cancelar</button>
              <button class="btn-primary" @click="saveTemplate" :disabled="saving || !form.title.trim()">
                {{ saving ? 'Guardando...' : editingId ? 'Guardar cambios' : 'Crear procedimiento' }}
              </button>
            </div>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- ─── Generate with AI modal ────────────────────────────────────────── -->
    <Teleport to="body">
      <div v-if="showAIModal" class="modal-overlay" @click.self="showAIModal = false">
        <div class="ai-gen-modal">
          <div class="proc-editor-header">
            <h3>Generar procedimiento con IA</h3>
            <button class="modal-close" @click="showAIModal = false">&#x2715;</button>
          </div>
          <div class="ai-gen-body">
            <p class="ai-gen-hint">Describa qué tipo de procedimiento necesita. La IA generará los pasos automáticamente.</p>
            <div class="field">
              <label class="field-label">Equipo o contexto (opcional)</label>
              <select v-model="aiNodeId" class="field-input">
                <option :value="null">General (sin equipo específico)</option>
                <option v-for="n in linkNodes" :key="n.id" :value="n.id">{{ n.indent }}{{ n.name }}</option>
              </select>
            </div>
            <div class="field">
              <label class="field-label">Descripción del procedimiento *</label>
              <textarea v-model="aiPrompt" class="field-input" rows="4"
                placeholder="Ej: Procedimiento de inspección diaria para un compresor de aire. Debe incluir verificación de presión, temperatura, nivel de aceite, fugas visibles y estado de filtros."></textarea>
            </div>
            <div v-if="aiError" class="modal-error">{{ aiError }}</div>
          </div>
          <div class="proc-editor-footer">
            <button class="btn-secondary" @click="showAIModal = false">Cancelar</button>
            <button class="btn-primary" @click="generateWithAI" :disabled="generating || !aiPrompt.trim()">
              {{ generating ? 'Generando...' : 'Generar procedimiento' }}
            </button>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { proceduresApi } from '@/api/phase2'
import { CATEGORY_LABELS, STEP_TYPE_LABELS } from '@/types/procedures'
import type { ProcedureTemplate, ProcedureTemplateDetail, ProcedureLink, ProcedureCategory, StepType, StepConfig } from '@/types/procedures'
import { nodesApi } from '@/api/nodes'
import client from '@/api/client'
import { apiErrorMsg } from '@/composables/useToast'
import draggable from 'vuedraggable'

const templates = ref<ProcedureTemplate[]>([])
const loading = ref(false)
const filterCategory = ref('')

interface StepForm {
  uid: number
  title: string
  description: string
  step_type: StepType
  is_required: boolean
  config: StepConfig
  estimated_minutes: number | null
}

const showEditor = ref(false)
const editingId = ref<number | null>(null)
const saving = ref(false)
const editorError = ref('')

const form = ref({
  title: '',
  description: '',
  category: 'general' as ProcedureCategory,
  node_type_target: '',
  is_active: true,
  steps: [] as StepForm[],
})

const editLinks = ref<ProcedureLink[]>([])
const showLinkForm = ref(false)
const linkType = ref('wo_type')
const linkValue = ref('')
const linkNodes = ref<{ id: number; name: string; node_type: string; indent: string }[]>([])
const linkPlans = ref<{ id: number; title: string }[]>([])

// AI generation
const showAIModal = ref(false)
const generating = ref(false)
const aiPrompt = ref('')
const aiNodeId = ref<number | null>(null)
const aiError = ref('')

let uidCounter = 0

async function loadTemplates() {
  loading.value = true
  try {
    const params: Record<string, string> = {}
    if (filterCategory.value) params.category = filterCategory.value
    const data = await proceduresApi.list(params)
    templates.value = data.procedures ?? []
  } catch { templates.value = [] }
  loading.value = false
}

async function loadNodes() {
  try {
    const tree = await nodesApi.getTree()
    const flat: { id: number; name: string; node_type: string; indent: string }[] = []
    const flatten = (nodes: any[], depth = 0) => nodes.forEach((n: any) => {
      flat.push({ id: n.id, name: n.name, node_type: n.node_type ?? '', indent: '\u00A0'.repeat(depth * 2) })
      if (n.children) flatten(n.children, depth + 1)
    })
    flatten(tree.nodes ?? [])
    linkNodes.value = flat
  } catch { linkNodes.value = [] }
}

async function loadPlans() {
  try {
    const { data } = await client.get('/maintenance-plans')
    linkPlans.value = (data.plans ?? []).map((p: any) => ({ id: p.id, title: p.title }))
  } catch { linkPlans.value = [] }
}

function openCreate() {
  editingId.value = null
  form.value = { title: '', description: '', category: 'general', node_type_target: '', is_active: true, steps: [] }
  editLinks.value = []
  editorError.value = ''
  showLinkForm.value = false
  showEditor.value = true
}

async function openEdit(t: ProcedureTemplate) {
  editingId.value = t.id
  editorError.value = ''
  showLinkForm.value = false
  try {
    const detail: ProcedureTemplateDetail = await proceduresApi.getOne(t.id)
    form.value = {
      title: detail.title,
      description: detail.description ?? '',
      category: detail.category,
      node_type_target: detail.node_type_target ?? '',
      is_active: detail.is_active,
      steps: detail.steps.map(s => ({
        uid: ++uidCounter,
        title: s.title,
        description: s.description ?? '',
        step_type: s.step_type,
        is_required: s.is_required,
        config: { ...s.config },
        estimated_minutes: s.estimated_minutes,
      })),
    }
    editLinks.value = detail.links ?? []
  } catch {
    editorError.value = 'Error cargando detalle'
  }
  showEditor.value = true
}

function addStep() {
  form.value.steps.push({
    uid: ++uidCounter,
    title: '',
    description: '',
    step_type: 'checkbox',
    is_required: true,
    config: {},
    estimated_minutes: null,
  })
}

function removeStep(index: number) {
  form.value.steps.splice(index, 1)
}

function renumberSteps() {
  // vuedraggable already reorders the array
}

function resetStepConfig(step: StepForm) {
  step.config = {}
  if (step.step_type === 'passfail') step.config.fail_action = 'warn'
  if (step.step_type === 'text') step.config.max_length = 500
}

async function saveTemplate() {
  if (!form.value.title.trim()) return
  saving.value = true
  editorError.value = ''
  try {
    const payload = {
      title: form.value.title.trim(),
      description: form.value.description.trim() || undefined,
      category: form.value.category,
      node_type_target: form.value.node_type_target || undefined,
      is_active: form.value.is_active,
      steps: form.value.steps.map((s, i) => ({
        step_number: i + 1,
        title: s.title.trim(),
        description: s.description.trim() || undefined,
        step_type: s.step_type,
        is_required: s.is_required,
        config: s.config,
        estimated_minutes: s.estimated_minutes,
      })),
    }
    if (editingId.value) {
      await proceduresApi.update(editingId.value, payload)
    } else {
      await proceduresApi.create(payload as any)
    }
    showEditor.value = false
    await loadTemplates()
  } catch (err: unknown) {
    editorError.value = apiErrorMsg(err, 'Error guardando procedimiento')
  }
  saving.value = false
}

async function deleteTemplate() {
  if (!editingId.value) return
  if (!confirm('Eliminar este procedimiento? Las ejecuciones existentes se mantendrán.')) return
  saving.value = true
  try {
    await proceduresApi.delete(editingId.value)
    showEditor.value = false
    await loadTemplates()
  } catch (err: unknown) {
    editorError.value = apiErrorMsg(err, 'Error eliminando')
  }
  saving.value = false
}

async function addLink() {
  if (!editingId.value || !linkValue.value) return
  try {
    const payload: Record<string, any> = {}
    if (linkType.value === 'wo_type') payload.wo_type = linkValue.value
    else if (linkType.value === 'plan') payload.maintenance_plan_id = Number(linkValue.value)
    else payload.node_id = Number(linkValue.value)
    await proceduresApi.link(editingId.value, payload)
    const detail = await proceduresApi.getOne(editingId.value)
    editLinks.value = detail.links ?? []
    linkValue.value = ''
    showLinkForm.value = false
  } catch (err: unknown) {
    editorError.value = apiErrorMsg(err, 'Error vinculando')
  }
}

async function unlinkTemplate(linkId: number) {
  if (!editingId.value) return
  try {
    await proceduresApi.unlink(editingId.value, linkId)
    editLinks.value = editLinks.value.filter(l => l.id !== linkId)
  } catch { editorError.value = 'Error eliminando vinculo' }
}

// ─── AI Generation ──────────────────────────────────────────────────────────

function openAIGenerator() {
  aiPrompt.value = form.value.title ? `Generar procedimiento para: ${form.value.title}` : ''
  aiNodeId.value = null
  aiError.value = ''
  showAIModal.value = true
}

async function generateWithAI() {
  if (!aiPrompt.value.trim()) return
  generating.value = true
  aiError.value = ''

  try {
    const data = await client.post('/procedures/generate', {
      prompt: aiPrompt.value,
      node_id: aiNodeId.value,
    }).then(r => r.data)

    form.value.title = data.title ?? form.value.title
    form.value.description = data.description ?? ''
    form.value.category = data.category ?? 'general'
    form.value.steps = (data.steps ?? []).map((s: any) => ({
      uid: ++uidCounter,
      title: s.title ?? '',
      description: s.description ?? '',
      step_type: s.step_type ?? 'checkbox',
      is_required: s.is_required ?? true,
      config: s.config ?? {},
      estimated_minutes: s.estimated_minutes ?? null,
    }))

    showAIModal.value = false
  } catch (err: unknown) {
    aiError.value = apiErrorMsg(err, 'Error generando procedimiento')
  }
  generating.value = false
}

onMounted(() => {
  loadTemplates()
  loadNodes()
  loadPlans()
})
</script>

<style scoped>
.proc-page { display: flex; flex-direction: column; gap: var(--space-5); }
.page-header { display: flex; align-items: flex-start; justify-content: space-between; flex-wrap: wrap; gap: var(--space-4); }
.page-title { font-size: 1.4rem; font-weight: 700; color: var(--color-primary); }
.page-sub { font-size: 0.8rem; color: var(--color-text-muted); }
.header-actions { display: flex; align-items: center; gap: var(--space-3); }
.loading-state { text-align: center; padding: var(--space-10); color: var(--color-text-muted); }
.empty-state { text-align: center; padding: var(--space-10); color: var(--color-text-muted); }
.filter-select { height: 36px; padding: 0 var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius); background: var(--color-surface); font-size: 0.82rem; color: var(--color-text); }
.btn-primary { height: 36px; padding: 0 var(--space-4); background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); font-size: 0.82rem; font-weight: 600; cursor: pointer; white-space: nowrap; }
.btn-primary:hover { opacity: 0.9; }
.btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }
.btn-secondary { height: 36px; padding: 0 var(--space-4); background: var(--color-surface); color: var(--color-text); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.82rem; cursor: pointer; }
.btn-ghost { background: none; border: none; color: var(--color-accent); font-size: 0.8rem; font-weight: 600; cursor: pointer; padding: 4px 8px; }
.btn-ghost:hover { text-decoration: underline; }
.btn-sm { height: 30px; font-size: 0.75rem; padding: 0 var(--space-3); }
.btn-danger { height: 30px; padding: 0 var(--space-3); background: none; border: 1px solid var(--color-alert); color: var(--color-alert); border-radius: var(--radius); font-size: 0.75rem; cursor: pointer; }
.btn-danger:hover { background: rgba(233,69,96,0.08); }
.btn-ai { height: 32px; padding: 0 var(--space-3); background: linear-gradient(135deg, var(--color-primary), var(--color-accent)); color: #fff; border: none; border-radius: var(--radius); font-size: 0.78rem; font-weight: 600; cursor: pointer; }
.btn-ai:hover { opacity: 0.9; }
.btn-ai:disabled { opacity: 0.5; cursor: not-allowed; }
.text-muted { color: var(--color-text-muted); }

/* Template cards grid */
.proc-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(340px, 1fr)); gap: var(--space-4); }
.proc-tcard { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius); padding: var(--space-4) var(--space-5); cursor: pointer; transition: border-color 0.2s, transform 0.2s; }
.proc-tcard:hover { border-color: var(--color-accent); transform: translateY(-2px); }
.proc-tcard-header { display: flex; align-items: flex-start; justify-content: space-between; gap: var(--space-3); margin-bottom: var(--space-2); }
.proc-tcard-title { font-size: 0.92rem; font-weight: 600; color: var(--color-text-primary); }
.proc-tcard-desc { font-size: 0.78rem; color: var(--color-text-muted); margin-bottom: var(--space-3); line-height: 1.4; }
.proc-tcard-meta { display: flex; gap: var(--space-3); font-size: 0.72rem; color: var(--color-text-muted); flex-wrap: wrap; }
.proc-tcard-target { background: rgba(15,52,96,0.08); padding: 1px 6px; border-radius: 3px; }
.proc-cat-badge { font-size: 0.65rem; font-weight: 600; padding: 2px 8px; border-radius: 10px; text-transform: uppercase; letter-spacing: 0.3px; white-space: nowrap; }
.proc-cat--general { background: #6B728015; color: #6B7280; }
.proc-cat--inspection { background: #3B82F615; color: #3B82F6; }
.proc-cat--preventive { background: #10B98115; color: #10B981; }
.proc-cat--corrective { background: #E9456015; color: #E94560; }
.proc-cat--safety { background: #F59E0B15; color: #F59E0B; }
.proc-cat--commissioning { background: #8B5CF615; color: #8B5CF6; }
.proc-active-dot { display: flex; align-items: center; gap: 4px; }
.proc-active-dot--on::before { content: ''; width: 6px; height: 6px; border-radius: 50%; background: #10B981; }
.proc-active-dot--off::before { content: ''; width: 6px; height: 6px; border-radius: 50%; background: #9CA3AF; }

/* Editor modal */
.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; padding: var(--space-4); overflow-y: auto; }
.proc-editor-modal { background: var(--color-bg); border-radius: var(--radius-lg, 10px); width: 100%; max-width: 800px; height: 90vh; display: flex; flex-direction: column; overflow: hidden; }
.proc-editor-header { display: flex; align-items: center; justify-content: space-between; padding: var(--space-4) var(--space-5); border-bottom: 1px solid var(--color-border-light); }
.proc-editor-header h3 { font-size: 1.1rem; font-weight: 700; color: var(--color-primary); }
.proc-editor-actions { display: flex; align-items: center; gap: var(--space-3); }
.modal-close { background: none; border: none; font-size: 1.2rem; cursor: pointer; color: var(--color-text-muted); padding: 4px; }
.modal-close:hover { color: var(--color-text); }
.proc-editor-body { flex: 1 1 0; overflow-y: auto; padding: var(--space-5); display: block; }
.proc-editor-footer { display: flex; align-items: center; justify-content: space-between; padding: var(--space-4) var(--space-5); border-top: 1px solid var(--color-border-light); }
.proc-editor-footer-right { display: flex; gap: var(--space-3); }
.modal-error { color: var(--color-alert); font-size: 0.8rem; padding: 0 var(--space-5) var(--space-3); }

/* Fields */
.field { display: flex; flex-direction: column; gap: 4px; }
.field-row { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-3); }
.field-label { font-size: 0.75rem; font-weight: 600; color: var(--color-text-secondary); }
.field-label-sm { font-size: 0.68rem; font-weight: 600; color: var(--color-text-muted); }
.field-label-inline { font-size: 0.82rem; display: flex; align-items: center; gap: 6px; cursor: pointer; }
.field-input { height: 36px; padding: 0 var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius); background: var(--color-surface); font-size: 0.82rem; color: var(--color-text); }
.field-input--sm { height: 30px; font-size: 0.78rem; }
textarea.field-input { height: auto; padding: var(--space-2) var(--space-3); resize: vertical; }

/* Steps editor */
.proc-editor-basics { margin-bottom: var(--space-5); }
.steps-editor { border: 1px solid var(--color-border-light); border-radius: var(--radius); margin-bottom: var(--space-5); }
.links-section { border: 1px solid var(--color-border-light); border-radius: var(--radius); padding: var(--space-4); }
.steps-editor-header { display: flex; align-items: center; justify-content: space-between; padding: var(--space-3) var(--space-4); background: var(--color-surface-2); border-bottom: 1px solid var(--color-border-light); }
.steps-editor-title { font-size: 0.82rem; font-weight: 600; color: var(--color-text-secondary); }
.steps-empty { padding: var(--space-6); text-align: center; color: var(--color-text-muted); font-size: 0.82rem; }
.steps-list { display: flex; flex-direction: column; }
.step-card { border-bottom: 1px solid var(--color-border-light); }
.step-card:last-child { border-bottom: none; }
.step-card-header { display: flex; align-items: center; gap: var(--space-2); padding: var(--space-3) var(--space-4); background: var(--color-surface); }
.step-drag { cursor: grab; color: var(--color-text-muted); font-size: 0.9rem; padding: 2px 4px; }
.step-drag:active { cursor: grabbing; }
.step-number { width: 22px; height: 22px; border-radius: 50%; background: var(--color-primary); color: #fff; font-size: 0.68rem; font-weight: 700; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.step-title-input { flex: 1; border: none; background: transparent; font-size: 0.84rem; font-weight: 500; color: var(--color-text); outline: none; min-width: 100px; }
.step-title-input::placeholder { color: var(--color-text-muted); }
.step-type-select { height: 26px; font-size: 0.72rem; border: 1px solid var(--color-border); border-radius: 4px; background: var(--color-surface); color: var(--color-text); padding: 0 4px; }
.step-required-toggle { font-size: 0.68rem; color: var(--color-text-muted); display: flex; align-items: center; gap: 3px; cursor: pointer; white-space: nowrap; }
.step-remove { background: none; border: none; color: var(--color-text-muted); cursor: pointer; font-size: 0.8rem; padding: 2px 4px; }
.step-remove:hover { color: var(--color-alert); }
.step-card-body { padding: var(--space-2) var(--space-4) var(--space-3); background: var(--color-bg); }
.step-config-row { display: flex; gap: var(--space-3); flex-wrap: wrap; margin-top: var(--space-2); }
.step-config-row .field { min-width: 80px; }

/* Links */
.links-section { border: 1px solid var(--color-border-light); border-radius: var(--radius); overflow: hidden; }
.links-list { padding: var(--space-3) var(--space-4); display: flex; flex-direction: column; gap: var(--space-2); }
.link-item { display: flex; align-items: center; justify-content: space-between; padding: 6px 10px; background: var(--color-surface); border-radius: var(--radius); font-size: 0.8rem; }
.link-remove { background: none; border: none; color: var(--color-text-muted); cursor: pointer; font-size: 0.8rem; }
.link-remove:hover { color: var(--color-alert); }
.link-form { display: flex; gap: var(--space-2); padding: var(--space-3) var(--space-4); align-items: center; flex-wrap: wrap; }

/* AI generator modal */
.ai-gen-modal { background: var(--color-bg); border-radius: var(--radius-lg, 10px); width: 100%; max-width: 560px; display: flex; flex-direction: column; }
.ai-gen-body { padding: var(--space-5); display: flex; flex-direction: column; gap: var(--space-4); }
.ai-gen-hint { font-size: 0.82rem; color: var(--color-text-muted); line-height: 1.5; }

/* Responsive */
@media (max-width: 768px) {
  .proc-grid { grid-template-columns: 1fr; }
  .proc-editor-modal { max-width: 100%; max-height: 100vh; border-radius: 0; }
  .step-card-header { flex-wrap: wrap; }
  .field-row { grid-template-columns: 1fr; }
  .header-actions { flex-wrap: wrap; }
}
</style>
