<template>
  <div class="factory-layout" :class="{ 'factory-layout--mobile-detail': isMobile && factoryStore.selectedNode }">
    <!-- ─── Tree ──────────────────────────────────────────────────────────── -->
    <aside class="factory-sidebar">
      <div class="sidebar-top">
        <div class="sidebar-title-row">
          <span class="sidebar-title">Fábrica Virtual</span>
          <button v-if="authStore.isAdmin" class="btn-icon" title="Nuevo nodo raiz" @click="openModal(null)">+</button>
        </div>
        <div class="search-wrap">
          <input v-model="searchQ" class="search-input" placeholder="Buscar nodo..."
            @input="factoryStore.setSearch(searchQ)" />
          <button v-if="searchQ" class="search-clear" @click="clearSearch">✕</button>
        </div>
      </div>

      <div v-if="factoryStore.loading" class="sidebar-loading">
        <span class="loading-text">Cargando árbol...</span>
      </div>
      <div v-else-if="searchQ.length >= 2" class="search-results">
        <div v-if="factoryStore.isSearching" class="sidebar-loading">
          <span class="loading-text">Buscando...</span>
        </div>
        <template v-else>
          <div v-if="!factoryStore.searchResults.length" class="empty-search">Sin resultados</div>
          <div v-for="r in factoryStore.searchResults" :key="r.id"
            class="search-result-item"
            :class="{ 'search-result-item--active': factoryStore.selectedNode?.id === r.id }"
            @click="selectFromSearch(r)">
            <span class="sr-name">{{ r.name }}</span>
            <span class="sr-type">{{ nodeTypeLabel(r.node_type) }}</span>
          </div>
        </template>
      </div>
      <div v-else class="tree-wrap">
        <div v-if="!factoryStore.hasTree" class="empty-tree">
          <p>No hay nodos.</p>
          <button class="btn-create-first" @click="openModal(null)">Crear primer nodo</button>
        </div>
        <TreeNode v-for="root in factoryStore.tree" :key="root.id" :node="root" :depth="0" />
      </div>
    </aside>

    <!-- ─── Main panel ───────────────────────────────────────────────── -->
    <div class="factory-main">
      <div v-if="!factoryStore.selectedNode" class="factory-home">
        <div class="factory-home-header">
          <h2 class="factory-home-title">Fábrica Virtual</h2>
          <p class="factory-home-sub">Selecciona un nodo del árbol para ver su detalle, OTs, preventivo, repuestos y más.</p>
        </div>

        <!-- ── Composition templates ─────────────────────────────── -->
        <div v-if="authStore.isManager" class="factory-home-section">
          <div class="section-header">
            <span class="section-count">Plantillas de composicion</span>
            <div class="section-actions">
              <button class="btn-action" @click="openCreateCompTemplate">+ Crear plantilla</button>
            </div>
          </div>
          <div v-if="!compTemplates.length" class="section-empty">
            No hay plantillas de composición.<br>
            <span class="text-muted small">Las plantillas definen los equipos que forman un grupo funcional (ej: celula de soldadura, estacion de mecanizado).</span>
          </div>
          <div v-else class="comp-list">
            <div v-for="t in compTemplates" :key="t.id" class="comp-template-card">
              <span class="comp-template-name">{{ t.name }}</span>
              <span class="comp-template-meta text-muted small">{{ t.slot_count }} slots · {{ t.usage_count }} usos</span>
              <button class="btn-action btn-action--del btn-action--small" @click="deleteCompTemplate(t.id)">&#10005;</button>
            </div>
          </div>
        </div>
      </div>

      <div v-else class="node-detail">
        <!-- Mobile: back to tree button -->
        <button v-if="isMobile" class="mobile-back-btn" @click="factoryStore.selectedNode = null">
          &#x2190; Arbol
        </button>
        <!-- Node header -->
        <div class="node-header">
          <div class="node-header-left">
            <div class="node-breadcrumb">{{ nodeBreadcrumb }}</div>
            <h2 class="node-name">{{ factoryStore.selectedNode.name }}</h2>
            <div class="node-meta">
              <span class="meta-badge mono">{{ factoryStore.selectedNode.code ?? '—' }}</span>
              <span class="meta-sep">·</span>
              <span class="meta-type">{{ nodeTypeLabel(factoryStore.selectedNode.node_type) }}</span>
              <span class="meta-sep">·</span>
              <span :style="{ color: critColor }">{{ critLabel }}</span>
              <span class="meta-sep">·</span>
              <span :style="{ color: statusColor }">{{ statusLabel }}</span>
            </div>
            <div v-if="factoryStore.selectedNode.tags?.length" class="node-tags">
              <span v-for="tag in factoryStore.selectedNode.tags" :key="tag.id" class="tag-pill"
                :style="{ background: tag.color + '22', color: tag.color, borderColor: tag.color + '44' }">
                {{ tag.name }}
              </span>
            </div>
          </div>
          <div class="node-header-actions">
            <QRButton
              v-if="['equipment','component','composition'].includes(factoryStore.selectedNode?.node_type)"
              :node-id="factoryStore.selectedNode.id"
              :node-code="factoryStore.selectedNode.code ?? factoryStore.selectedNode.id.toString()"
              :node-name="factoryStore.selectedNode.name"
            />
            <button v-if="authStore.isManager" class="btn-action" @click="openModal(null, factoryStore.selectedNode)">Editar</button>
            <button v-if="authStore.isManager" class="btn-action btn-action--child" @click="openModal(factoryStore.selectedNode)">+ Hijo</button>
            <button v-if="authStore.user?.role !== 'auditor'" class="btn-action btn-action--wo" @click="openCreateWO" :disabled="!canWrite">+ OT</button>
            <button v-if="authStore.isAdmin" class="btn-action btn-action--danger" @click="deleteNode(factoryStore.selectedNode)" :disabled="!canWrite">Eliminar</button>
          </div>
        </div>

        <!-- Tabs -->
        <div class="tabs">
          <button v-for="tab in tabs" :key="tab.id" class="tab"
            :class="{ 'tab--active': activeTab === tab.id, 'tab--disabled': tab.disabled }"
            :disabled="tab.disabled"
            @click="!tab.disabled && selectTab(tab.id)">
            {{ tab.label }}
            <span v-if="tab.disabled" class="tab-phase">F{{ tab.phase }}</span>
          </button>
        </div>

        <!-- Tab content -->
        <div class="tab-content">

          <!-- ── Summary ─────────────────────────────────────────────────── -->
          <div v-if="activeTab === 'summary'" class="tab-pane">
            <!-- Quick node KPIs -->
            <div class="node-kpi-bar">
              <div class="node-kpi node-kpi--health" :title="nodeHealth ? 'Health Score: ' + healthLabel(nodeHealth.health_score) : 'Sin datos'">
                <span class="node-kpi-value" :style="{ color: healthColor(nodeHealth?.health_score ?? null) }">{{ nodeHealth ? Math.round(nodeHealth.health_score) : '—' }}</span>
                <span class="node-kpi-label">Salud</span>
                <span v-if="nodeHealth" class="health-bar-mini"><span class="health-bar-mini-fill" :style="{ width: nodeHealth.health_score + '%', background: healthColor(nodeHealth.health_score) }"></span></span>
                <div v-if="nodeHealth?.details" class="health-factors">
                  <div v-for="(label, key) in HEALTH_FACTOR_LABELS" :key="key" class="health-factor-row">
                    <span class="health-factor-name">{{ label }}</span>
                    <span class="health-factor-val">-{{ ((nodeHealth.details as Record<string, any>)[key]?.penalty ?? 0).toFixed(1) }}</span>
                  </div>
                </div>
              </div>
              <div class="node-kpi node-kpi--clickable" @click="kpiGoToWOs('active')">
                <span class="node-kpi-value">{{ nodeWOs.filter(w => ['assigned','in_progress'].includes(w.status)).length }}</span>
                <span class="node-kpi-label">OTs activas</span>
              </div>
              <div class="node-kpi node-kpi--clickable" @click="kpiGoToWOs('pending')">
                <span class="node-kpi-value" :class="{ 'alert-val': nodeWOs.filter(w => w.status === 'pending').length > 0 }">{{ nodeWOs.filter(w => w.status === 'pending').length }}</span>
                <span class="node-kpi-label">Pendientes</span>
              </div>
              <div class="node-kpi node-kpi--clickable" @click="selectTab('parts')">
                <span class="node-kpi-value">{{ nodeParts.filter(p => p.current_stock <= p.min_stock).length }}</span>
                <span class="node-kpi-label">Stock bajo</span>
              </div>
              <div class="node-kpi node-kpi--clickable" @click="selectTab('personnel')">
                <span class="node-kpi-value">{{ nodePersonnel.length }}</span>
                <span class="node-kpi-label">Personal</span>
              </div>
              <div class="node-kpi node-kpi--clickable" @click="selectTab('maintenance')">
                <span class="node-kpi-value" :class="{ 'alert-val': overduePlanCount > 0 }">{{ activePlanCount }}</span>
                <span class="node-kpi-label">Planes PM</span>
              </div>
            </div>

            <div class="info-grid">
              <div class="info-block"><span class="info-label">Nombre</span><span>{{ factoryStore.selectedNode.name }}</span></div>
              <div class="info-block"><span class="info-label">Código</span><span class="mono">{{ factoryStore.selectedNode.code ?? '—' }}</span></div>
              <div class="info-block"><span class="info-label">Tipo</span><span>{{ nodeTypeLabel(factoryStore.selectedNode.node_type) }}</span></div>
              <div class="info-block"><span class="info-label">Criticidad</span><span :style="{ color: critColor }">{{ critLabel }}</span></div>
              <div class="info-block"><span class="info-label">Estado</span><span :style="{ color: statusColor }">{{ statusLabel }}</span></div>
              <div class="info-block"><span class="info-label">Ruta ltree</span><span class="mono small">{{ factoryStore.selectedNode.path }}</span></div>
              <template v-if="factoryStore.selectedNode.manufacturer">
                <div class="info-block"><span class="info-label">Fabricante</span><span>{{ factoryStore.selectedNode.manufacturer }}</span></div>
              </template>
              <template v-if="factoryStore.selectedNode.model">
                <div class="info-block"><span class="info-label">Modelo</span><span>{{ factoryStore.selectedNode.model }}</span></div>
              </template>
              <template v-if="factoryStore.selectedNode.serial_number">
                <div class="info-block"><span class="info-label">N° Serie</span><span class="mono">{{ factoryStore.selectedNode.serial_number }}</span></div>
              </template>
              <template v-if="factoryStore.selectedNode.year_installed">
                <div class="info-block"><span class="info-label">Año instalación</span><span class="mono">{{ factoryStore.selectedNode.year_installed }}</span></div>
              </template>
              <template v-if="factoryStore.selectedNode.rated_power_kw">
                <div class="info-block"><span class="info-label">Potencia nominal</span><span class="mono">{{ factoryStore.selectedNode.rated_power_kw }} kW</span></div>
              </template>
            </div>
            <div v-if="factoryStore.selectedNode.description" class="info-description">
              <span class="info-label">Descripción</span>
              <p class="description-text">{{ factoryStore.selectedNode.description }}</p>
            </div>
            <div class="info-timestamps">
              <span class="timestamp">Creado: {{ formatDate(factoryStore.selectedNode.created_at) }}</span>
              <span class="timestamp">Actualizado: {{ formatDate(factoryStore.selectedNode.updated_at) }}</span>
              <span class="timestamp mono">v{{ factoryStore.selectedNode.version }}</span>
            </div>
          </div>

          <!-- ── Structure ──────────────────────────────────────────────── -->
          <div v-else-if="activeTab === 'structure'" class="tab-pane">
            <div class="section-header">
              <span class="section-count">{{ factoryStore.selectedNode.children?.length ?? 0 }} elemento(s)</span>
              <button class="btn-action btn-action--child" @click="openModal(factoryStore.selectedNode)">+ Añadir hijo</button>
            </div>
            <div v-if="!factoryStore.selectedNode.children?.length" class="section-empty">Este nodo no tiene subelementos.</div>
            <div class="children-list">
              <div v-for="child in factoryStore.selectedNode.children" :key="child.id"
                class="child-item" @click="factoryStore.selectNode(child)">
                <span class="child-crit" :style="{ background: getCritColor(child.criticality) }"></span>
                <div class="child-info">
                  <span class="child-name">{{ child.name }}</span>
                  <span class="child-meta"><span class="mono">{{ child.code ?? '—' }}</span> · {{ nodeTypeLabel(child.node_type) }}</span>
                </div>
                <span class="child-arrow">›</span>
              </div>
            </div>
          </div>

          <!-- ── WOs ─────────────────────────────────────────────────────── -->
          <div v-else-if="activeTab === 'workorders'" class="tab-pane tab-pane--with-dirs">
            <DirectoryPanel
              section="work_orders"
              :selected-id="woDirId"
              @select="onWoDirSelect"
              @item-dropped="refreshWODir"
            />
            <div class="tab-main-content">
              <div class="section-header">
                <span class="section-count">
                  {{ displayedWOs.length }} OTs
                  <span v-if="woDirName" class="dir-filter-label">/ {{ woDirName }}</span>
                </span>
                <button class="btn-action btn-action--wo" @click="openCreateWO" :disabled="!canWrite">+ Nueva OT</button>
              </div>
              <!-- Smart filters for the node's WOs -->
              <div class="smart-filters">
                <button v-for="sf in nodeSmartFilters" :key="sf.id"
                  class="smart-chip" :class="{ 'smart-chip--active': activeNodeWOFilter === sf.id }"
                  @click="toggleNodeWOFilter(sf.id)">
                  {{ sf.label }}
                  <span v-if="sf.count > 0" class="smart-chip-count">{{ sf.count }}</span>
                </button>
              </div>
              <div v-if="loadingWOs" class="loading-inline">Cargando OTs...</div>
              <div v-else-if="!displayedWOs.length" class="section-empty">
                {{ woDirId ? 'Carpeta vacía.' : 'No hay OTs para este nodo.' }}
              </div>
              <div v-else class="wo-list">
                <div v-for="wo in displayedWOs" :key="wo.id" class="wo-card wo-card--clickable" @click="openWODetail(wo)"
                  draggable="true" @dragstart="(e: DragEvent) => startDrag(e, 'work_order', wo.id)">
                  <div class="wo-card-left">
                    <span class="wo-number mono">{{ wo.wo_number }}</span>
                    <span class="wo-title">{{ wo.title }}</span>
                    <span class="wo-meta text-muted">{{ WO_TYPE_CONFIG[wo.wo_type]?.label }} · {{ wo.assigned_name ?? 'Sin asignar' }}</span>
                  </div>
                  <div class="wo-card-right">
                    <span class="priority-pill" :style="{ color: WO_PRIORITY_CONFIG[wo.priority]?.color, background: WO_PRIORITY_CONFIG[wo.priority]?.color + '15' }">
                      {{ WO_PRIORITY_CONFIG[wo.priority]?.label }}
                    </span>
                    <span class="status-pill" :style="{ color: WO_STATUS_CONFIG[wo.status]?.color, background: WO_STATUS_CONFIG[wo.status]?.color + '15' }">
                      {{ WO_STATUS_CONFIG[wo.status]?.label }}
                    </span>
                    <SaveToDir section="work_orders" item-type="work_order" :item-id="wo.id" @saved="refreshWODir" @click.stop />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- ── Preventive ──────────────────────────────────────────────── -->
          <div v-else-if="activeTab === 'maintenance'" class="tab-pane">
            <!-- Header with count + create button -->
            <div class="section-header">
              <span class="section-count">{{ activePlanCount }} plan(es) activo(s)</span>
              <button v-if="authStore.isManager" class="btn-action btn-action--child" @click="openCreatePlan()" :disabled="!canWrite">
                + Crear plan
              </button>
            </div>

            <div v-if="loadingMaint" class="loading-inline">Cargando planes...</div>

            <template v-else>
              <!-- Direct plans -->
              <div v-if="directPlans.length" class="maint-group">
                <h5 class="maint-group-title">Planes directos</h5>
                <div v-for="plan in directPlans" :key="'d'+plan.id" class="maint-plan-card">
                  <div class="maint-plan-info">
                    <span class="maint-plan-title">{{ plan.title }}</span>
                    <span class="maint-plan-meta text-muted small">
                      {{ plan.wo_type }} · Cada {{ plan.frequency_value }} {{ plan.frequency_type === 'days' ? 'dias' : plan.frequency_type === 'weeks' ? 'semanas' : 'meses' }}
                      <template v-if="plan.assigned_name"> · {{ plan.assigned_name }}</template>
                    </span>
                    <div v-if="plan.has_instructions || plan.checklist_count > 0 || plan.tools_count > 0" class="maint-plan-badges">
                      <span v-if="plan.has_instructions" class="maint-badge" title="Con procedimiento">&#x25A4;</span>
                      <span v-if="plan.checklist_count > 0" class="maint-badge" title="Lista de verificación">&#x2611; {{ plan.checklist_count }}</span>
                      <span v-if="plan.tools_count > 0" class="maint-badge" title="Herramientas">&#x2692; {{ plan.tools_count }}</span>
                    </div>
                  </div>
                  <div class="maint-plan-right">
                    <span v-if="plan.next_due_at" class="mono small" :style="{ color: planDueColor(plan.next_due_at) }">{{ plan.next_due_at?.substring(0,10) }}</span>
                  </div>
                </div>
              </div>

              <!-- Inherited plans -->
              <div v-if="inheritedPlans.length" class="maint-group">
                <h5 class="maint-group-title">Planes heredados</h5>
                <div v-for="plan in inheritedPlans" :key="'i'+plan.id"
                  class="maint-plan-card" :class="{ 'maint-plan-card--excluded': plan.is_excluded }">
                  <div class="maint-plan-info">
                    <span class="maint-plan-title">{{ plan.title }}</span>
                    <span class="maint-plan-meta text-muted small">
                      Heredado de {{ plan.source_node_name }}
                      · Cada {{ plan.frequency_value }} {{ plan.frequency_type === 'days' ? 'dias' : plan.frequency_type === 'weeks' ? 'semanas' : 'meses' }}
                      <template v-if="plan.assigned_name"> · {{ plan.assigned_name }}</template>
                    </span>
                    <div v-if="plan.has_instructions || plan.checklist_count > 0 || plan.tools_count > 0" class="maint-plan-badges">
                      <span v-if="plan.has_instructions" class="maint-badge" title="Con procedimiento">&#x25A4;</span>
                      <span v-if="plan.checklist_count > 0" class="maint-badge" title="Lista de verificación">&#x2611; {{ plan.checklist_count }}</span>
                      <span v-if="plan.tools_count > 0" class="maint-badge" title="Herramientas">&#x2692; {{ plan.tools_count }}</span>
                    </div>
                  </div>
                  <div class="maint-plan-right">
                    <span v-if="plan.next_due_at" class="mono small" :style="{ color: planDueColor(plan.next_due_at) }">{{ plan.next_due_at?.substring(0,10) }}</span>
                    <button v-if="authStore.isManager" class="btn-toggle-exclude" @click="toggleExclusion(plan)">
                      {{ plan.is_excluded ? '&#x25A1; Excluido' : '&#x25A0; Activo' }}
                    </button>
                  </div>
                </div>
              </div>

              <!-- Plans by template -->
              <div v-if="templatePlans.length" class="maint-group">
                <h5 class="maint-group-title">Planes por plantilla de equipo</h5>
                <div v-for="plan in templatePlans" :key="'t'+plan.id"
                  class="maint-plan-card" :class="{ 'maint-plan-card--excluded': plan.is_excluded }">
                  <div class="maint-plan-info">
                    <span class="maint-plan-title">{{ plan.title }}</span>
                    <span class="maint-plan-meta text-muted small">
                      Plantilla: {{ plan.manufacturer }} {{ plan.model }}
                      · Cada {{ plan.frequency_value }} {{ plan.frequency_type === 'days' ? 'dias' : plan.frequency_type === 'weeks' ? 'semanas' : 'meses' }}
                      <template v-if="plan.assigned_name"> · {{ plan.assigned_name }}</template>
                    </span>
                    <div v-if="plan.has_instructions || plan.checklist_count > 0 || plan.tools_count > 0" class="maint-plan-badges">
                      <span v-if="plan.has_instructions" class="maint-badge" title="Con procedimiento">&#x25A4;</span>
                      <span v-if="plan.checklist_count > 0" class="maint-badge" title="Lista de verificación">&#x2611; {{ plan.checklist_count }}</span>
                      <span v-if="plan.tools_count > 0" class="maint-badge" title="Herramientas">&#x2692; {{ plan.tools_count }}</span>
                    </div>
                  </div>
                  <div class="maint-plan-right">
                    <span v-if="plan.next_due_at" class="mono small" :style="{ color: planDueColor(plan.next_due_at) }">{{ plan.next_due_at?.substring(0,10) }}</span>
                    <button v-if="authStore.isManager" class="btn-toggle-exclude" @click="toggleExclusion(plan)">
                      {{ plan.is_excluded ? '&#x25A1; Excluido' : '&#x25A0; Activo' }}
                    </button>
                  </div>
                </div>
              </div>

              <div v-if="!effectivePlans.length" class="section-empty">
                Sin planes de mantenimiento para este nodo.
              </div>
            </template>

            <!-- Maintenance manuals -->
            <div class="section-header" style="margin-top: var(--space-5);">
              <span class="section-count">{{ nodeManuals.length }} manual(es) de mantenimiento</span>
              <button v-if="authStore.isManager" class="btn-action btn-action--child" @click="showManualUpload = true">+ Subir manual</button>
            </div>
            <p class="manual-hint">Los manuales (PDF/TXT) son indexados por la IA para dar contexto inteligente al equipo.</p>
            <div v-if="loadingManuals" class="loading-inline">Cargando manuales...</div>
            <div v-else-if="!nodeManuals.length" class="section-empty">No hay manuales de mantenimiento para este nodo.</div>
            <div v-else class="manuals-list">
              <div v-for="m in nodeManuals" :key="m.id" class="manual-card">
                <div class="manual-info">
                  <span class="manual-title">{{ m.title }}</span>
                  <span class="manual-meta text-muted">
                    {{ m.original_name }} · {{ formatFileSize(m.file_size) }}
                    <span v-if="m.uploaded_by"> · {{ m.uploaded_by }}</span>
                  </span>
                </div>
                <div class="manual-actions">
                  <a :href="manualDownloadUrl(m.id)" class="action-btn" title="Descargar" target="_blank">&#x2193;</a>
                  <button v-if="authStore.isManager" class="action-btn action-btn--del"
                    @click="deleteManual(m.id)" title="Eliminar">&#x2715;</button>
                </div>
              </div>
            </div>

            <!-- Upload manual modal -->
            <Teleport to="body">
              <div v-if="showManualUpload" class="modal-overlay" @click.self="showManualUpload = false">
                <div class="small-modal">
                  <div class="modal-header">
                    <h3>Subir manual de mantenimiento</h3>
                    <button class="modal-close" @click="showManualUpload = false">&#x2715;</button>
                  </div>
                  <div class="modal-body">
                    <div class="field">
                      <label class="field-label">Título</label>
                      <input v-model="manualForm.title" class="field-input" placeholder="Nombre del manual..." />
                    </div>
                    <div class="field">
                      <label class="field-label">Descripción (opcional)</label>
                      <textarea v-model="manualForm.description" class="field-input" rows="2" placeholder="Breve descripción..." />
                    </div>
                    <div class="field">
                      <label class="field-label">Archivo (PDF o TXT, max 10MB)</label>
                      <input type="file" accept=".pdf,.txt,.text" @change="onManualFileChange" class="field-input" />
                    </div>
                    <div v-if="manualError" class="modal-error">{{ manualError }}</div>
                  </div>
                  <div class="modal-footer">
                    <button class="btn-secondary" @click="showManualUpload = false">Cancelar</button>
                    <button class="btn-primary" :disabled="!canWrite || uploadingManual" @click="uploadManual">
                      {{ uploadingManual ? 'Subiendo...' : 'Subir manual' }}
                    </button>
                  </div>
                </div>
              </div>
            </Teleport>
          </div>

          <!-- ── Spare parts ───────────────────────────────────────────────── -->
          <div v-else-if="activeTab === 'parts'" class="tab-pane tab-pane--with-dirs">
            <DirectoryPanel
              section="spare_parts"
              :selected-id="partsDirId"
              @select="onPartsDirSelect"
              @item-dropped="refreshPartsDir"
            />
            <div class="tab-main-content">
              <div class="section-header">
                <span class="section-count">
                  {{ displayedParts.length }} repuestos
                  <span v-if="partsDirName" class="dir-filter-label">/ {{ partsDirName }}</span>
                </span>
                <button v-if="authStore.isManager" class="btn-action btn-action--child" @click="showLinkPart = true">+ Asociar repuesto</button>
              </div>
              <div v-if="loadingParts" class="loading-inline">Cargando repuestos...</div>
              <div v-else-if="!displayedParts.length" class="section-empty">
                {{ partsDirId ? 'Carpeta vacía.' : 'No hay repuestos asociados.' }}
              </div>
              <div v-else class="parts-list">
                <div v-for="sp in displayedParts" :key="sp.id" class="part-card"
                  draggable="true" @dragstart="(e: DragEvent) => startDrag(e, 'spare_part', sp.id)">
                  <div class="part-info">
                    <span class="part-code mono">{{ sp.code }}</span>
                    <span class="part-name">{{ sp.name }}</span>
                    <span class="part-cat text-muted">{{ CATEGORY_CONFIG[sp.category]?.label }}</span>
                  </div>
                  <div class="part-stock-row">
                    <span :class="{ 'stock-low': sp.low_stock }" class="stock-value mono">
                      {{ sp.current_stock }} {{ sp.unit }}
                    </span>
                    <span v-if="sp.low_stock" class="low-badge">BAJO</span>
                    <SaveToDir section="spare_parts" item-type="spare_part" :item-id="sp.id" @saved="refreshPartsDir" />
                    <button v-if="authStore.isManager" class="btn-unlink" title="Desasociar repuesto" @click="unlinkPart(sp.id)">✕</button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- ── Personnel ────────────────────────────────────────────────── -->
          <div v-else-if="activeTab === 'personnel'" class="tab-pane tab-pane--with-dirs">
            <DirectoryPanel
              section="personnel"
              :selected-id="personnelDirId"
              @select="onPersonnelDirSelect"
              @item-dropped="refreshPersonnelDir"
            />
            <div class="tab-main-content">
              <div class="section-header">
                <span class="section-count">
                  {{ displayedPersonnel.length }} personas
                  <span v-if="personnelDirName" class="dir-filter-label">/ {{ personnelDirName }}</span>
                </span>
                <button v-if="authStore.isManager" class="btn-action btn-action--child" @click="openAssignPersonnel">+ Asignar personal</button>
              </div>
              <div v-if="loadingPersonnel" class="loading-inline">Cargando personal...</div>
              <div v-else-if="!displayedPersonnel.length" class="section-empty">
                {{ personnelDirId ? 'Carpeta vacía.' : 'No hay personal asignado a este nodo.' }}
              </div>
              <div v-else class="personnel-list">
                <div v-for="p in displayedPersonnel" :key="p.id" class="person-card"
                  :class="{ 'person-card--inherited': !p.is_direct }"
                  draggable="true" @dragstart="(e: DragEvent) => startDrag(e, 'user', p.id)">
                  <div class="person-avatar">{{ p.full_name[0]?.toUpperCase() }}</div>
                  <div class="person-info">
                    <span class="person-name">{{ p.full_name }}</span>
                    <span class="person-role text-muted">{{ ROLE_LABELS[p.role] ?? p.role }}</span>
                    <span v-if="!p.is_direct" class="badge-inherited" :title="'Asignado a: ' + p.assigned_node_name">
                      Heredado de: {{ p.assigned_node_name }}
                    </span>
                    <span v-if="p.assignment_depth" class="badge-rank" :class="'rank-' + getRankLevel(p.assignment_depth)">
                      {{ getRankLabel(p.assigned_node_type) }}
                    </span>
                  </div>
                  <div class="person-meta">
                    <span v-if="p.is_primary" class="badge-primary">Principal</span>
                    <span class="wo-count" :class="{ 'wo-count--busy': p.active_wos > 2 }">{{ p.active_wos }} OTs activas</span>
                    <SaveToDir section="personnel" item-type="user" :item-id="p.id" @saved="refreshPersonnelDir" />
                    <button v-if="authStore.isManager && p.is_direct" class="btn-unlink" title="Desasignar personal" @click="unassignPerson(p.id)">✕</button>
                    <button v-if="authStore.isManager && !p.is_direct && canManageUser(p)" class="btn-exclude" title="Restringir acceso a este nodo" @click="excludePerson(p.id)">Restringir</button>
                  </div>
                </div>
              </div>

              <!-- Excluded (restricted) users -->
              <div v-if="authStore.isManager && excludedPersonnel.length" class="excluded-section">
                <button class="excluded-toggle" @click="showExcluded = !showExcluded">
                  {{ showExcluded ? '▾' : '▸' }} {{ excludedPersonnel.length }} usuario(s) con acceso restringido
                </button>
                <div v-if="showExcluded" class="excluded-list">
                  <div v-for="e in excludedPersonnel" :key="'excl-' + e.id" class="excluded-card">
                    <span class="person-name">{{ e.full_name }}</span>
                    <span class="person-role text-muted">{{ ROLE_LABELS[e.role] ?? e.role }}</span>
                    <button class="btn-restore" @click="restorePerson(e.id)">Restaurar</button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- ── Library ──────────────────────────────────────────────── -->
          <div v-else-if="activeTab === 'library'" class="tab-pane tab-pane--with-dirs">
            <DirectoryPanel
              section="library"
              :selected-id="libraryDirId"
              @select="onLibraryDirSelect"
              @item-dropped="refreshLibraryDir"
            />
            <div class="tab-main-content">
              <div class="section-header">
                <span class="section-count">
                  {{ displayedLibrary.length }} archivos
                  <span v-if="libraryDirName" class="dir-filter-label">/ {{ libraryDirName }}</span>
                </span>
                <label class="btn-action btn-action--upload" :class="{ disabled: uploadingFile }">
                  <input type="file" class="file-input-hidden" @change="handleFileUpload" :disabled="uploadingFile" />
                  {{ uploadingFile ? 'Subiendo...' : '↑ Subir archivo' }}
                </label>
              </div>
              <div v-if="loadingLibrary" class="loading-inline">Cargando biblioteca...</div>
              <div v-else-if="!displayedLibrary.length" class="section-empty">
                {{ libraryDirId ? 'Carpeta vacía.' : 'No hay archivos en la biblioteca.' }}
              </div>
              <div v-else class="library-list">
                <div v-for="att in displayedLibrary" :key="att.id" class="lib-card"
                  draggable="true" @dragstart="(e: DragEvent) => startDrag(e, 'attachment', att.id)">
                  <div class="lib-icon">{{ getFileIcon(att.mime_type) }}</div>
                  <div class="lib-info">
                    <span class="lib-name">{{ att.original_name }}</span>
                    <span class="lib-meta text-muted">{{ att.category }} · {{ formatFileSize(att.file_size) }} · {{ att.uploaded_by ?? 'Sistema' }}</span>
                  </div>
                  <div class="lib-actions">
                    <SaveToDir section="library" item-type="attachment" :item-id="att.id" @saved="refreshLibraryDir" />
                    <button class="btn-delete" @click="deleteFile(att.id)" title="Eliminar">✕</button>
                  </div>
                </div>
              </div>

              <!-- Template files (shared, read-only) -->
              <div v-if="templateLibrary.length || templateFolders.length" class="template-lib-section">
                <div class="section-header section-header--shared">
                  <span class="section-count">
                    ◇ Biblioteca de plantilla (compartida)
                    <span v-if="templateLibraryName" class="tpl-name-label">{{ templateLibraryName }}</span>
                  </span>
                </div>

                <!-- Template folder navigation -->
                <div v-if="tplCurrentFolderId !== null" class="tpl-breadcrumb">
                  <button class="btn-link" @click="tplCurrentFolderId = null">Raiz</button>
                  <span class="breadcrumb-sep">▸</span>
                  <span>{{ templateFolders.find(f => f.id === tplCurrentFolderId)?.name }}</span>
                </div>

                <!-- Folders -->
                <div v-if="visibleTplFolders.length" class="library-list">
                  <div v-for="folder in visibleTplFolders" :key="'tpl-folder-' + folder.id"
                       class="lib-card lib-card--folder lib-card--shared" @click="tplCurrentFolderId = folder.id">
                    <div class="lib-icon">▤</div>
                    <div class="lib-info">
                      <span class="lib-name">{{ folder.name }}</span>
                      <span class="lib-meta text-muted">Carpeta</span>
                    </div>
                    <span class="badge-shared">Plantilla</span>
                  </div>
                </div>

                <!-- Files (filtered by the current folder) -->
                <div v-if="visibleTplFiles.length" class="library-list">
                  <div v-for="att in visibleTplFiles" :key="'tpl-' + att.id" class="lib-card lib-card--shared">
                    <div class="lib-icon">{{ getFileIcon(att.mime_type) }}</div>
                    <div class="lib-info">
                      <span class="lib-name">{{ att.original_name }}</span>
                      <span class="lib-meta text-muted">{{ att.category }} · {{ formatFileSize(att.file_size) }} · {{ att.uploaded_by ?? 'Sistema' }}</span>
                    </div>
                    <span class="badge-shared">Plantilla</span>
                  </div>
                </div>

                <p v-if="!visibleTplFolders.length && !visibleTplFiles.length" class="empty-state text-muted" style="padding:0.5rem">
                  Carpeta vacía
                </p>
              </div>
            </div>
          </div>

          <!-- ── Composition ──────────────────────────────────────────────── -->
          <div v-else-if="activeTab === 'composition'" class="tab-pane">
            <div v-if="loadingCompositions" class="loading-inline">Cargando composiciones...</div>
            <template v-else>

              <!-- ═══ View for COMPOSITION nodes ═══════════════════════ -->
              <template v-if="factoryStore.selectedNode?.node_type === 'composition'">
                <!-- Slots of the linked template -->
                <div v-if="compDetailSlots.length">
                  <div class="section-header">
                    <span class="section-count">
                      {{ compDetailSlots.filter(s => s.assigned_node_id).length }} / {{ compDetailSlots.length }} slots asignados
                    </span>
                  </div>
                  <table class="comp-member-table">
                    <thead>
                      <tr><th>Rol</th><th>Plantilla de equipo</th><th>Equipo (hijo)</th><th>Estado</th></tr>
                    </thead>
                    <tbody>
                      <tr v-for="s in compDetailSlots" :key="s.id"
                        :class="{ 'comp-row--empty': !s.assigned_node_id }">
                        <td class="slot-role">{{ s.role }}</td>
                        <td class="text-muted small">{{ s.equipment_name ?? '(generico)' }}</td>
                        <td>
                          <span v-if="s.assigned_node_id" class="comp-member-name" @click="navigateToNode(s.assigned_node_id)">{{ s.assigned_node_name }}</span>
                          <span v-else class="slot-pending">Sin asignar</span>
                        </td>
                        <td>
                          <span v-if="s.assigned_node_id" class="badge-status badge-status--active">Asignado</span>
                          <span v-else class="badge-status badge-status--pending">Pendiente</span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div v-else class="section-empty">
                  Esta composición no tiene plantilla con slots definidos.<br>
                  <span class="text-muted small">Los equipos hijos se muestran en la pestaña Estructura.</span>
                </div>
              </template>

              <!-- ═══ View for NORMAL nodes (not compositions) ══════════════ -->
              <template v-else>
                <div class="section-header">
                  <span class="section-count">{{ childCompositions.length }} {{ childCompositions.length === 1 ? 'composición' : 'composiciones' }} en este nodo</span>
                  <div class="section-actions" v-if="authStore.isManager">
                    <button class="btn-action" @click="openApplyCompTemplate">Aplicar plantilla</button>
                  </div>
                </div>

                <div v-if="!childCompositions.length && !nodeCompositions.length" class="section-empty">
                  No hay composiciones en este nodo.<br>
                  <span v-if="authStore.isManager" class="text-muted small">Usa "Aplicar plantilla" para crear un nodo composición con equipos hijos.</span>
                </div>

                <div v-if="childCompositions.length" class="comp-list">
                  <div v-for="comp in childCompositions" :key="'child-' + comp.id" class="comp-card"
                    :class="{ 'comp-card--active': selectedComposition?.id === comp.id }"
                    @click="selectComposition(comp)">
                    <div class="comp-card-header">
                      <span class="comp-card-name">{{ comp.name }}</span>
                      <span class="comp-card-count">{{ comp.member_count }} componentes</span>
                      <span @click.stop>
                        <QRButton
                          :node-id="0"
                          :node-code="'comp-' + comp.id"
                          :node-name="comp.name"
                          :composition-id="comp.id"
                        />
                      </span>
                    </div>
                  </div>
                </div>

                <!-- Compositions this node takes part in -->
                <div v-if="nodeCompositions.length" class="comp-membership-section">
                  <div class="section-header">
                    <span class="section-count">Miembro de {{ nodeCompositions.length }} {{ nodeCompositions.length === 1 ? 'composición' : 'composiciones' }}</span>
                  </div>
                  <div class="comp-list">
                    <div v-for="comp in nodeCompositions" :key="comp.id" class="comp-card"
                      :class="{ 'comp-card--active': selectedComposition?.id === comp.id }"
                      @click="selectComposition(comp)">
                      <div class="comp-card-header">
                        <span class="comp-card-name">{{ comp.name }}</span>
                        <span class="comp-card-count">{{ comp.member_count }} componentes</span>
                        <span @click.stop>
                          <QRButton
                            :node-id="0"
                            :node-code="'comp-' + comp.id"
                            :node-name="comp.name"
                            :composition-id="comp.id"
                          />
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Tools -->
                <div v-if="authStore.isManager" class="comp-clone-section">
                  <div class="section-header">
                    <span class="section-count">Herramientas</span>
                  </div>
                  <div class="comp-tools-grid">
                    <button class="btn-action" @click="openCloneEquipment">Clonar equipos desde plantilla</button>
                    <button class="btn-action" @click="openCreateCompTemplate">Crear plantilla de composición</button>
                  </div>
                  <div v-if="compTemplates.length" class="comp-templates-list">
                    <h5 class="comp-templates-title">Plantillas de composicion</h5>
                    <div v-for="t in compTemplates" :key="t.id" class="comp-template-card">
                      <span class="comp-template-name">{{ t.name }}</span>
                      <span class="comp-template-meta text-muted small">{{ t.slot_count }} slots · {{ t.usage_count }} usos</span>
                      <button class="btn-action btn-action--del btn-action--small" @click="deleteCompTemplate(t.id)">&#10005;</button>
                    </div>
                  </div>
                </div>
              </template>

            </template>
          </div>

          <!-- ── Arche AI ────────────────────────────────────────────────── -->
          <div v-else-if="activeTab === 'ai'" class="tab-pane tab-pane--ai">
            <div class="ai-node-chat">
              <div class="ai-node-header">
                <span class="ai-node-icon">◬</span>
                <div>
                  <p class="ai-node-title">Arche IA — {{ factoryStore.selectedNode?.name }}</p>
                  <p class="ai-node-sub">Contexto activo: este equipo. Pregunta sin especificar el nombre.</p>
                </div>
                <button class="btn-open-chat" @click="openNodeChat">Abrir chat completo</button>
              </div>
              <PatternAlerts :node-id="factoryStore.selectedNode?.id" />
              <div class="ai-node-suggestions">
                <button class="suggestion-chip" @click="askNodeQuestion('¿Cuál es el estado actual de este equipo?')">Estado actual</button>
                <button class="suggestion-chip" @click="askNodeQuestion('¿Qué averías ha tenido este equipo?')">Historial de averías</button>
                <button class="suggestion-chip" @click="askNodeQuestion('¿Qué repuestos necesita este equipo?')">Repuestos necesarios</button>
                <button class="suggestion-chip" @click="askNodeQuestion('¿Qué mantenimiento preventivo necesita?')">Mantenimiento preventivo</button>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>

  <!-- Node modal -->
  <NodeModal v-if="showModal" :parent-node="modalParent" :edit-node="modalEdit"
    @close="showModal = false" @saved="onNodeSaved" />

  <!-- Create WO from node modal -->
  <Teleport to="body">
    <div v-if="showCreateWO" class="modal-overlay" @click.self="showCreateWO = false">
      <div class="create-modal">
        <div class="modal-header">
          <h3>Nueva OT — {{ factoryStore.selectedNode?.name }}</h3>
          <button class="modal-close" @click="showCreateWO = false">✕</button>
        </div>
        <div class="modal-body">
          <div class="field"><label class="field-label">Título *</label>
            <input v-model="woForm.title" class="field-input" placeholder="Descripción breve del trabajo" />
          </div>
          <div class="field-row">
            <div class="field"><label class="field-label">Tipo</label>
              <select v-model="woForm.wo_type" class="field-input">
                <option value="corrective">Correctiva</option>
                <option value="preventive">Preventiva</option>
                <option value="improvement">Mejora</option>
                <option value="inspection">Inspección</option>
              </select>
            </div>
            <div class="field"><label class="field-label">Prioridad</label>
              <select v-model="woForm.priority" class="field-input">
                <option value="low">Baja</option>
                <option value="medium">Media</option>
                <option value="high">Alta</option>
                <option value="critical">Crítica</option>
              </select>
            </div>
          </div>
          <div class="field"><label class="field-label">Descripción</label>
            <textarea v-model="woForm.description" class="field-input" rows="3" />
          </div>
          <div class="field"><label class="field-label">Asignar a (opcional)</label>
            <select v-model="woForm.assigned_to" class="field-input">
              <option :value="null">Sin asignar — cualquiera puede tomarla</option>
              <option v-for="t in woAvailableTechs" :key="t.id" :value="t.id">{{ t.full_name }} ({{ t.role }})</option>
            </select>
          </div>
          <div v-if="woError" class="modal-error">{{ woError }}</div>
        </div>
        <div class="modal-footer">
          <button class="btn-secondary" @click="showCreateWO = false">Cancelar</button>
          <button class="btn-primary" :disabled="!canWrite || creatingWO" @click="submitCreateWO">
            {{ creatingWO ? 'Creando...' : 'Crear OT' }}
          </button>
        </div>
      </div>
    </div>
  </Teleport>

  <!-- Attach spare part modal -->
  <Teleport to="body">
    <div v-if="showLinkPart" class="modal-overlay" @click.self="showLinkPart = false">
      <div class="create-modal">
        <div class="modal-header">
          <h3>Asociar repuesto — {{ factoryStore.selectedNode?.name }}</h3>
          <button class="modal-close" @click="showLinkPart = false">✕</button>
        </div>
        <div class="modal-body">
          <div class="field">
            <label class="field-label">Buscar repuesto</label>
            <input v-model="partSearchQ" class="field-input" placeholder="Nombre o código..." @input="searchParts" />
          </div>
          <div v-if="searchingParts" class="loading-inline">Buscando...</div>
          <div v-else-if="partSearchQ.length >= 2 && !availableParts.length" class="section-empty">Sin resultados</div>
          <div v-else class="link-results">
            <div v-for="sp in availableParts" :key="sp.id" class="link-item" @click="linkPart(sp.id)">
              <div class="link-item-info">
                <span class="part-code mono">{{ sp.code }}</span>
                <span class="part-name">{{ sp.name }}</span>
              </div>
              <span class="link-item-action">+ Asociar</span>
            </div>
          </div>
          <div v-if="linkPartError" class="modal-error">{{ linkPartError }}</div>
        </div>
      </div>
    </div>
  </Teleport>

  <!-- Assign staff modal -->
  <Teleport to="body">
    <div v-if="showAssignPerson" class="modal-overlay" @click.self="showAssignPerson = false">
      <div class="create-modal">
        <div class="modal-header">
          <h3>Asignar personal — {{ factoryStore.selectedNode?.name }}</h3>
          <button class="modal-close" @click="showAssignPerson = false">✕</button>
        </div>
        <div class="modal-body">
          <div class="field">
            <label class="field-label">Buscar persona</label>
            <input v-model="personSearchQ" class="field-input" placeholder="Nombre o email..." />
          </div>
          <div v-if="loadingAllPersonnel" class="loading-inline">Cargando personal...</div>
          <div v-else-if="personSearchQ.length >= 2 && !filteredAssignable.length" class="section-empty">Sin resultados</div>
          <div v-else-if="personSearchQ.length < 2" class="section-empty hint-text">Escribe al menos 2 caracteres para buscar</div>
          <div v-else class="link-results">
            <div v-for="p in filteredAssignable" :key="p.id" class="link-item" @click="assignPerson(p.id)">
              <div class="link-item-info">
                <span class="person-name">{{ p.full_name }}</span>
                <span class="person-role text-muted">{{ ROLE_LABELS[p.role] ?? p.role }} · {{ p.email }}</span>
              </div>
              <span class="link-item-action">+ Asignar</span>
            </div>
          </div>
          <div v-if="assignPersonError" class="modal-error">{{ assignPersonError }}</div>
        </div>
      </div>
    </div>
  </Teleport>

  <!-- WO detail from node modal -->
  <Teleport to="body">
    <div v-if="woDetail" class="modal-overlay" @click.self="woDetail = null">
      <div class="wo-detail-modal">
        <div class="modal-header">
          <div>
            <span class="mono small text-muted">{{ woDetail.work_order.wo_number }}</span>
            <h3>{{ woDetail.work_order.title }}</h3>
            <div class="wo-detail-meta">
              <span class="status-pill" :style="{ color: WO_STATUS_CONFIG[woDetail.work_order.status]?.color, background: WO_STATUS_CONFIG[woDetail.work_order.status]?.color + '15' }">
                {{ WO_STATUS_CONFIG[woDetail.work_order.status]?.label }}
              </span>
              <span class="meta-sep">·</span>
              <span :style="{ color: WO_PRIORITY_CONFIG[woDetail.work_order.priority]?.color }">
                {{ WO_PRIORITY_CONFIG[woDetail.work_order.priority]?.label }}
              </span>
              <span class="meta-sep">·</span>
              <span class="text-muted small">{{ woDetail.work_order.assigned_name ?? 'Sin asignar' }}</span>
            </div>
          </div>
          <button class="modal-close" @click="woDetail = null">✕</button>
        </div>

        <!-- Actions -->
        <div class="wo-detail-actions">
          <button v-for="t in woTransitions" :key="t.to" class="btn-transition" @click="openWOTransition(t)">
            {{ t.label }}
          </button>
          <button v-if="isManager" class="btn-pdf" @click="woOpenPDF(woDetail.work_order.id)">PDF</button>
          <span v-if="woDetail.work_order.signed_at" class="signed-badge">✓ Firmada</span>
          <button v-if="isSupervisor && woDetail.work_order.assigned_name"
            class="btn-score" @click="woOpenScore(woDetail.work_order)">Puntuar</button>
          <button v-if="woDetail.work_order.wo_type === 'corrective' && !woDetail.work_order.root_cause"
            class="btn-suggest" @click="woGetSuggestion(woDetail.work_order.id)">
            ◈ Diagnosticar con IA
          </button>
        </div>

        <!-- Info / history / comments tabs -->
        <div class="wo-detail-tabs">
          <button v-for="tab in woDetailTabs" :key="tab.id" class="detail-tab"
            :class="{ 'detail-tab--active': woDetailActiveTab === tab.id }"
            @click="woDetailActiveTab = tab.id">{{ tab.label }}</button>
        </div>

        <div class="wo-detail-body">
          <!-- Info -->
          <div v-if="woDetailActiveTab === 'info'">
            <div class="info-grid">
              <div class="info-block"><span class="info-label">Tipo</span><span>{{ WO_TYPE_CONFIG[woDetail.work_order.wo_type]?.label }}</span></div>
              <div class="info-block">
                <span class="info-label">Asignado a</span>
                <template v-if="!woReassignMode">
                  <span>{{ woDetail.work_order.assigned_name ?? 'Sin asignar' }}</span>
                  <span v-if="authStore.isManager && !['closed', 'cancelled'].includes(woDetail.work_order.status)" class="assign-actions">
                    <button class="btn-ghost small" @click="woOpenReassign">Cambiar</button>
                    <button v-if="woDetail.work_order.assigned_to" class="btn-ghost small text-muted" @click="woUnassignTechnician">Desasignar</button>
                  </span>
                  <button v-if="!woDetail.work_order.assigned_to && !authStore.isManager && authStore.isFieldWorker"
                    class="btn-ghost small" @click="woSelfAssign">Tomar OT</button>
                </template>
                <template v-else>
                  <select v-model="woReassignUserId" class="field-input" style="display:inline-block;width:auto;min-width:180px;padding:4px 8px;font-size:0.82rem;">
                    <option :value="null">Sin asignar</option>
                    <option v-for="t in woAvailableTechs" :key="t.id" :value="t.id">{{ t.full_name }} ({{ t.role }})</option>
                  </select>
                  <button class="btn-primary small" :disabled="woReassigning" @click="woConfirmReassign">{{ woReassigning ? '...' : 'Confirmar' }}</button>
                  <button class="btn-ghost small" @click="woReassignMode = false">Cancelar</button>
                </template>
              </div>
              <div v-if="!woReassignMode && !woDetail.work_order.assigned_to && authStore.isManager" style="margin-top:4px;">
                <button class="btn-ghost small" :disabled="woLoadingSuggestTech" @click="woSuggestTechnician(woDetail.work_order.id)">
                  {{ woLoadingSuggestTech ? 'Buscando...' : 'Sugerir técnico (IA)' }}
                </button>
              </div>
              <div v-if="woTechSuggestions.length" class="tech-suggestions">
                <div v-for="s in woTechSuggestions" :key="s.user_id" class="tech-sug-row">
                  <span class="tech-sug-name">{{ s.full_name }}</span>
                  <span v-if="s.avg_score" class="tech-sug-score">{{ s.avg_score }}</span>
                  <span class="tech-sug-load text-muted small">{{ s.current_load }} OTs activas</span>
                  <button class="btn-ghost small" @click="woAssignTechnician(woDetail.work_order.id, s.user_id)">Asignar</button>
                </div>
              </div>
              <div class="info-block"><span class="info-label">Horas est.</span><span class="mono">{{ woDetail.work_order.estimated_hours ?? '—' }}</span></div>
              <div class="info-block"><span class="info-label">Tiempo trabajado</span><span class="mono">{{ formatWorkedTime(woDetail.work_order.accumulated_minutes) }}</span></div>
              <div class="info-block"><span class="info-label">Inicio planif.</span><span class="mono small">{{ formatDate(woDetail.work_order.planned_start) }}</span></div>
              <div class="info-block"><span class="info-label">Fin planif.</span><span class="mono small">{{ formatDate(woDetail.work_order.planned_end) }}</span></div>
            </div>
            <div v-if="woDetail.work_order.description" class="wo-desc-block">
              <span class="info-label">Descripción</span>
              <p>{{ woDetail.work_order.description }}</p>
            </div>
            <div v-if="woDetail.work_order.root_cause" class="wo-desc-block">
              <span class="info-label">Causa raíz</span><p>{{ woDetail.work_order.root_cause }}</p>
            </div>
            <div v-if="woDetail.work_order.solution" class="wo-desc-block">
              <span class="info-label">Solución</span><p>{{ woDetail.work_order.solution }}</p>
            </div>
            <div v-if="woSignaturesInfo" class="wo-desc-block">
              <span class="info-label">Firmas digitales</span>
              <div class="signatures-info">
                <div v-if="woSignaturesInfo.signed_by" class="sig-row sig-row--ok">
                  <span class="sig-icon">✓</span>
                  <div class="sig-detail">
                    <span class="sig-name">{{ woSignaturesInfo.signed_by_name }}</span>
                    <span class="sig-role">Ejecutor</span>
                  </div>
                  <span class="mono small text-muted">{{ formatDate(woSignaturesInfo.signed_at) }}</span>
                </div>
                <div v-else class="sig-row sig-row--pending">
                  <span class="sig-icon">○</span>
                  <span class="sig-pending">Pendiente — se firma al completar la OT</span>
                </div>
                <div v-if="woSignaturesInfo.supervisor_signed_by" class="sig-row sig-row--ok">
                  <span class="sig-icon">✓</span>
                  <div class="sig-detail">
                    <span class="sig-name">{{ woSignaturesInfo.supervisor_signed_name }}</span>
                    <span class="sig-role">Supervisor</span>
                  </div>
                  <span class="mono small text-muted">{{ formatDate(woSignaturesInfo.supervisor_signed_at) }}</span>
                </div>
                <div v-else class="sig-row sig-row--pending">
                  <span class="sig-icon">○</span>
                  <span class="sig-pending">Pendiente — se firma al cerrar la OT</span>
                </div>
              </div>
            </div>
          </div>

          <!-- History -->
          <div v-else-if="woDetailActiveTab === 'log'" class="wo-log-list">
            <div v-for="entry in woDetail.log" :key="entry.id" class="wo-log-entry">
              <div class="wo-log-dot"></div>
              <div>
                <div class="wo-log-transition">
                  <span v-if="entry.from_status" class="text-muted small">{{ WO_STATUS_CONFIG[entry.from_status]?.label }}</span>
                  <span v-if="entry.from_status"> → </span>
                  <span :style="{ color: WO_STATUS_CONFIG[entry.to_status]?.color }">{{ WO_STATUS_CONFIG[entry.to_status]?.label }}</span>
                </div>
                <p v-if="entry.comment" class="small text-muted">{{ entry.comment }}</p>
                <span class="mono small text-muted">{{ entry.user_name ?? 'Sistema' }} · {{ formatDate(entry.created_at) }}</span>
              </div>
            </div>
          </div>

          <!-- Comments -->
          <div v-else-if="woDetailActiveTab === 'comments'">
            <div class="wo-comments-list">
              <div v-for="cm in woDetail.comments" :key="cm.id" class="wo-comment-item">
                <div class="person-avatar">{{ (cm.user_name ?? 'S')[0] }}</div>
                <div>
                  <span class="small" style="font-weight:600">{{ cm.user_name ?? 'Sistema' }}</span>
                  <span class="mono small text-muted" style="margin-left:8px">{{ formatDate(cm.created_at) }}</span>
                  <p class="small" style="margin-top:4px">{{ cm.content }}</p>
                </div>
              </div>
            </div>
            <div class="wo-comment-form">
              <textarea v-model="woNewComment" class="field-input" placeholder="Escribe un comentario..." rows="2" />
              <button class="btn-primary" :disabled="!canWrite || !woNewComment.trim()" @click="submitWOComment">Enviar</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </Teleport>

  <!-- WO transition from node modal -->
  <Teleport to="body">
    <div v-if="woTransitionModal" class="modal-overlay" @click.self="woTransitionModal = null">
      <div class="create-modal">
        <div class="modal-header">
          <h3>{{ woTransitionModal.label }}</h3>
          <button class="modal-close" @click="woTransitionModal = null">✕</button>
        </div>
        <div class="modal-body">
          <div v-if="woTransitionModal.to === 'completed'" class="field">
            <label class="field-label">Causa raíz</label>
            <textarea v-model="woTransitionData.root_cause" class="field-input" rows="2" />
          </div>
          <div v-if="woTransitionModal.to === 'completed'" class="field">
            <label class="field-label">Solución</label>
            <textarea v-model="woTransitionData.solution" class="field-input" rows="2" />
          </div>
          <div v-if="woTransitionModal.to === 'completed'" class="field">
            <label class="field-label">Horas reales (ajuste manual)</label>
            <input v-model="woTransitionData.actual_hours_raw" class="field-input mono" placeholder="Ej: 5:30 o 5.5 — se calcula desde cronómetro" />
            <span class="field-hint" style="font-size:0.68rem;color:var(--color-text-muted);font-style:italic;margin-top:2px;">Formato: 5:30 (horas:minutos) o 5.5 (decimal). Si modifica este valor, quedara registrado quien lo cambio</span>
          </div>
          <div class="field">
            <label class="field-label">{{ woTransitionModal.requireComment ? 'Comentario *' : 'Comentario (opcional)' }}</label>
            <textarea v-model="woTransitionData.comment" class="field-input" rows="2" />
          </div>
          <div v-if="woTransitionError" class="modal-error">{{ woTransitionError }}</div>
        </div>
        <div class="modal-footer">
          <button class="btn-secondary" @click="woTransitionModal = null">Cancelar</button>
          <button class="btn-primary" :disabled="!canWrite || woTransitioning" @click="confirmWOTransition">
            {{ woTransitioning ? 'Procesando...' : 'Confirmar' }}
          </button>
        </div>
      </div>
    </div>
  </Teleport>


  <!-- WO scoring modal -->
  <Teleport to="body">
    <div v-if="woScoreModal" class="modal-overlay" @click.self="woScoreModal = null">
      <div class="create-modal">
        <div class="modal-header">
          <h3>Puntuar trabajo</h3>
          <button class="modal-close" @click="woScoreModal = null">✕</button>
        </div>
        <div class="modal-body">
          <p class="small text-muted" style="margin-bottom:12px">{{ woScoreModal.wo_number }} — {{ woScoreModal.title }}</p>
          <div class="field">
            <label class="field-label">Puntuación (1-5)</label>
            <div class="star-selector">
              <button v-for="n in 5" :key="n"
                class="star-btn" :class="{ 'star-btn--active': woScoreForm.score >= n }"
                @click="woScoreForm.score = n">&#9733;</button>
            </div>
            <p class="small text-muted">{{ ['','Deficiente','Mejorable','Aceptable','Bueno','Excelente'][woScoreForm.score] }}</p>
          </div>
          <div class="field">
            <label class="field-label">Comentario (opcional)</label>
            <textarea v-model="woScoreForm.comment" class="field-input" rows="2"
              placeholder="Observaciones sobre el trabajo..." />
          </div>
          <div v-if="woScoreError" class="modal-error">{{ woScoreError }}</div>
        </div>
        <div class="modal-footer">
          <button class="btn-secondary" @click="woScoreModal = null">Cancelar</button>
          <button class="btn-primary" :disabled="!canWrite || !woScoreForm.score || woSavingScore" @click="woSubmitScore">
            {{ woSavingScore ? 'Guardando...' : 'Guardar puntuación' }}
          </button>
        </div>
      </div>
    </div>
  </Teleport>

  <!-- Create maintenance plan modal -->
  <Teleport to="body">
    <div v-if="showPlanModal" class="modal-overlay" @click.self="showPlanModal = false">
      <div class="plan-create-modal">
        <div class="modal-header">
          <h3>Nuevo plan preventivo — {{ factoryStore.selectedNode?.name }}</h3>
          <button class="modal-close" @click="showPlanModal = false">&#x2715;</button>
        </div>
        <div class="plan-create-body">
          <!-- Basic data (always open) -->
          <div class="plan-section">
            <div class="plan-section-title" @click="planSectionOpen.basic = !planSectionOpen.basic">
              <span>{{ planSectionOpen.basic ? '&#x25BE;' : '&#x25B8;' }}</span> Datos basicos
            </div>
            <div v-show="planSectionOpen.basic" class="plan-section-body">
              <div class="field">
                <label class="field-label">Título del plan *</label>
                <input v-model="planForm.title" class="field-input" placeholder="Ej: Revision mensual hidraulica" />
              </div>
              <div class="field-row">
                <div class="field">
                  <label class="field-label">Tipo de OT</label>
                  <select v-model="planForm.wo_type" class="field-input">
                    <option value="preventive">Preventiva</option>
                    <option value="inspection">Inspeccion</option>
                    <option value="predictive">Predictiva</option>
                  </select>
                </div>
                <div class="field">
                  <label class="field-label">Prioridad</label>
                  <select v-model="planForm.priority" class="field-input">
                    <option value="low">Baja</option>
                    <option value="medium">Media</option>
                    <option value="high">Alta</option>
                    <option value="critical">Critica</option>
                  </select>
                </div>
              </div>
              <div class="field-row">
                <div class="field">
                  <label class="field-label">Frecuencia *</label>
                  <div class="plan-freq-input">
                    <input v-model.number="planForm.frequency_value" type="number" min="1"
                      class="field-input plan-freq-num" placeholder="1" />
                    <select v-model="planForm.frequency_type" class="field-input plan-freq-type">
                      <option value="days">Dias</option>
                      <option value="weeks">Semanas</option>
                      <option value="months">Meses</option>
                    </select>
                  </div>
                </div>
                <div class="field">
                  <label class="field-label">Anticipacion (dias)</label>
                  <input v-model.number="planForm.advance_days" type="number" min="0"
                    class="field-input" placeholder="3" />
                </div>
              </div>
              <div class="field-row">
                <div class="field">
                  <label class="field-label">Técnico asignado</label>
                  <select v-model="planForm.assigned_to" class="field-input">
                    <option :value="null">Sin asignar</option>
                    <option v-for="t in planTechnicians" :key="t.user_id" :value="t.user_id">
                      {{ t.full_name }}
                    </option>
                  </select>
                </div>
                <div class="field">
                  <label class="field-label">Horas estimadas</label>
                  <input v-model.number="planForm.estimated_hours" type="number" step="0.5"
                    class="field-input mono" placeholder="2.0" />
                </div>
              </div>
              <div class="field field-toggle">
                <label class="toggle-label">
                  <input type="checkbox" v-model="planForm.apply_to_children" />
                  <span class="toggle-text">Aplicar a equipos hijos</span>
                </label>
                <p class="field-hint">Genera una OT individual por cada equipo descendiente</p>
              </div>
            </div>
          </div>

          <!-- Instructions (collapsible) -->
          <div class="plan-section">
            <div class="plan-section-title" @click="planSectionOpen.procedure = !planSectionOpen.procedure">
              <span>{{ planSectionOpen.procedure ? '&#x25BE;' : '&#x25B8;' }}</span> Instrucciones
            </div>
            <div v-show="planSectionOpen.procedure" class="plan-section-body">
              <div class="field">
                <textarea v-model="planForm.instructions" class="field-input" rows="5"
                  placeholder="Describe paso a paso el procedimiento de mantenimiento..." />
              </div>
            </div>
          </div>

          <!-- Checklist (collapsible) -->
          <div class="plan-section">
            <div class="plan-section-title" @click="planSectionOpen.checklist = !planSectionOpen.checklist">
              <span>{{ planSectionOpen.checklist ? '&#x25BE;' : '&#x25B8;' }}</span>
              Lista de verificación
              <span v-if="planForm.checklist.length" class="plan-section-count">{{ planForm.checklist.length }}</span>
            </div>
            <div v-show="planSectionOpen.checklist" class="plan-section-body">
              <div v-for="(item, i) in planForm.checklist" :key="i" class="plan-checklist-row">
                <input v-model="item.step" class="field-input plan-checklist-input" placeholder="Paso..." />
                <label class="plan-checklist-req" :title="item.required ? 'Obligatorio' : 'Opcional'">
                  <input type="checkbox" v-model="item.required" />
                  Oblig.
                </label>
                <button class="plan-checklist-del" @click="planForm.checklist.splice(i, 1)">&#x2715;</button>
              </div>
              <button class="btn-add-checklist" @click="planForm.checklist.push({ step: '', required: false })">
                + Agregar paso
              </button>
            </div>
          </div>

          <div v-if="planError" class="modal-error">{{ planError }}</div>
          <div v-if="planSuccess" class="plan-success-msg">{{ planSuccess }}</div>
        </div>
        <div class="modal-footer">
          <button class="btn-secondary" @click="showPlanModal = false">Cancelar</button>
          <button class="btn-primary" :disabled="!canWrite || planSaving" @click="submitPlan">
            {{ planSaving ? 'Creando...' : 'Crear plan' }}
          </button>
        </div>
      </div>
    </div>
  </Teleport>

  <!-- Create composition modal -->
  <Teleport to="body">
    <div v-if="showCreateComp" class="modal-overlay" @click.self="showCreateComp = false">
      <div class="create-modal">
        <div class="modal-header">
          <h3>Crear composición funcional</h3>
          <button class="modal-close" @click="showCreateComp = false">✕</button>
        </div>
        <div class="modal-body">
          <div class="field">
            <label class="field-label">Nombre *</label>
            <input v-model="compForm.name" class="field-input" placeholder="Ej: Sistema de climatizacion Sala 3" />
          </div>
          <div class="field">
            <label class="field-label">Descripción</label>
            <textarea v-model="compForm.description" class="field-input" rows="2" placeholder="Descripción opcional..." />
          </div>
          <div class="field">
            <label class="field-label">Componentes ({{ compForm.node_ids.length }})</label>
            <div v-if="compForm.node_ids.length" class="comp-form-nodes">
              <div v-for="(nid, i) in compForm.node_ids" :key="nid" class="comp-form-node-row">
                <span class="comp-form-node-name">{{ getNodeName(nid) }}</span>
                <input v-model="compForm.roles[i]" class="field-input comp-role-input" placeholder="Rol (ej: controlador)" />
                <button class="btn-action btn-action--del btn-action--small" @click="removeCompNode(i)">✕</button>
              </div>
            </div>
            <div class="comp-search-row">
              <input v-model="compNodeSearch" class="field-input" placeholder="Buscar equipo..." @input="searchCompNodes" />
            </div>
            <div v-if="compSearchResults.length" class="comp-search-results">
              <div v-for="n in compSearchResults" :key="n.id" class="link-item" @click="addCompNode(n)">
                <span>{{ n.name }} <span class="text-muted small">{{ n.node_type }}</span></span>
                <span class="link-item-action">+ Agregar</span>
              </div>
            </div>
          </div>
          <div v-if="compFormError" class="modal-error">{{ compFormError }}</div>
        </div>
        <div class="modal-footer">
          <button class="btn-secondary" @click="showCreateComp = false">Cancelar</button>
          <button class="btn-primary" @click="submitCreateComposition">Crear composición</button>
        </div>
      </div>
    </div>
  </Teleport>

  <!-- Add member to composition modal -->
  <Teleport to="body">
    <div v-if="showAddCompMember" class="modal-overlay" @click.self="showAddCompMember = false">
      <div class="create-modal">
        <div class="modal-header">
          <h3>Agregar componente</h3>
          <button class="modal-close" @click="showAddCompMember = false">✕</button>
        </div>
        <div class="modal-body">
          <div class="field">
            <input v-model="compNodeSearch" class="field-input" placeholder="Buscar equipo..." @input="searchCompNodes" />
          </div>
          <div v-if="compSearchResults.length" class="comp-search-results">
            <div v-for="n in compSearchResults" :key="n.id" class="link-item" @click="addMemberToComp(n.id)">
              <span>{{ n.name }} <span class="text-muted small">{{ n.node_type }}</span></span>
              <span class="link-item-action">+ Agregar</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </Teleport>

  <!-- Apply composition template modal (creates a composition node) -->
  <Teleport to="body">
    <div v-if="showApplyCompTemplate" class="modal-overlay" @click.self="showApplyCompTemplate = false">
      <div class="create-modal">
        <div class="modal-header">
          <h3>Crear composición desde plantilla</h3>
          <button class="modal-close" @click="showApplyCompTemplate = false">&#10005;</button>
        </div>
        <div class="modal-body">
          <p class="text-muted small" style="margin-bottom:12px">
            Se creará un nodo tipo Composición bajo {{ factoryStore.selectedNode?.name }} con un equipo hijo por cada slot de la plantilla.
          </p>
          <div class="field">
            <label class="field-label">Plantilla de composicion *</label>
            <select v-model="applyTemplateId" class="field-input">
              <option :value="0">Selecciona una plantilla...</option>
              <option v-for="t in compTemplates" :key="t.id" :value="t.id">
                {{ t.name }} ({{ t.slot_count }} slots)
              </option>
            </select>
          </div>
          <div class="field">
            <label class="field-label">Nombre (opcional)</label>
            <input v-model="applyName" class="field-input" placeholder="Usa el de la plantilla por defecto..." />
          </div>
          <div v-if="applyError" class="modal-error">{{ applyError }}</div>
        </div>
        <div class="modal-footer">
          <button class="btn-secondary" @click="showApplyCompTemplate = false">Cancelar</button>
          <button class="btn-primary" :disabled="!applyTemplateId || applying" @click="submitApplyTemplate">
            {{ applying ? 'Creando...' : 'Crear composición' }}
          </button>
        </div>
      </div>
    </div>
  </Teleport>

  <!-- Create composition template modal -->
  <Teleport to="body">
    <div v-if="showCreateCompTemplate" class="modal-overlay" @click.self="showCreateCompTemplate = false">
      <div class="create-modal">
        <div class="modal-header">
          <h3>Crear plantilla de composición</h3>
          <button class="modal-close" @click="showCreateCompTemplate = false">✕</button>
        </div>
        <div class="modal-body">
          <div class="field">
            <label class="field-label">Nombre *</label>
            <input v-model="compTmplForm.name" class="field-input" placeholder="Ej: Sistema de climatizacion" />
          </div>
          <div class="field">
            <label class="field-label">Descripción</label>
            <textarea v-model="compTmplForm.description" class="field-input" rows="2" placeholder="Descripción opcional..." />
          </div>
          <div class="field">
            <label class="field-label">Slots ({{ compTmplForm.slots.length }})</label>
            <div class="comp-form-nodes">
              <div v-for="(slot, i) in compTmplForm.slots" :key="i" class="comp-form-node-row">
                <input v-model="slot.role" class="field-input" placeholder="Rol (ej: controlador)" style="flex:1" />
                <select v-model="slot.equipment_template_id" class="field-input" style="flex:1">
                  <option :value="null">Tipo de equipo (opcional)</option>
                  <option v-for="et in equipmentTemplates" :key="et.id" :value="et.id">
                    {{ et.manufacturer }} {{ et.model }}
                  </option>
                </select>
                <button class="btn-action btn-action--del btn-action--small" @click="compTmplForm.slots.splice(i, 1)">✕</button>
              </div>
            </div>
            <button class="btn-action btn-action--small" @click="compTmplForm.slots.push({ role: '', equipment_template_id: null, sort_order: compTmplForm.slots.length })">+ Agregar slot</button>
          </div>
          <div v-if="compTmplFormError" class="modal-error">{{ compTmplFormError }}</div>
        </div>
        <div class="modal-footer">
          <button class="btn-secondary" @click="showCreateCompTemplate = false">Cancelar</button>
          <button class="btn-primary" @click="submitCreateCompTemplate">Crear plantilla</button>
        </div>
      </div>
    </div>
  </Teleport>

  <!-- Clone equipment modal -->
  <Teleport to="body">
    <div v-if="showCloneEquipment" class="modal-overlay" @click.self="showCloneEquipment = false">
      <div class="create-modal">
        <div class="modal-header">
          <h3>Clonar equipos desde plantilla</h3>
          <button class="modal-close" @click="showCloneEquipment = false">✕</button>
        </div>
        <div class="modal-body">
          <p class="text-muted small" style="margin-bottom:12px">
            Crea multiples equipos identicos bajo {{ factoryStore.selectedNode?.name }},
            todos vinculados a la misma plantilla de equipo.
          </p>
          <div class="field">
            <label class="field-label">Plantilla de equipo *</label>
            <select v-model="cloneForm.equipment_template_id" class="field-input">
              <option :value="0">Selecciona una plantilla...</option>
              <option v-for="t in equipmentTemplates" :key="t.id" :value="t.id">
                {{ t.manufacturer }} {{ t.model }}
              </option>
            </select>
          </div>
          <div class="field-row">
            <div class="field">
              <label class="field-label">Cantidad *</label>
              <input v-model.number="cloneForm.count" type="number" min="1" max="100" class="field-input" />
            </div>
            <div class="field">
              <label class="field-label">Número inicial</label>
              <input v-model.number="cloneForm.start_number" type="number" min="1" class="field-input" />
            </div>
          </div>
          <div class="field">
            <label class="field-label">Prefijo del nombre</label>
            <input v-model="cloneForm.name_prefix" class="field-input" placeholder="Ej: Ventilador XR-200 (si vacío, usa fabricante+modelo)" />
          </div>
          <div v-if="cloneFormError" class="modal-error">{{ cloneFormError }}</div>
        </div>
        <div class="modal-footer">
          <button class="btn-secondary" @click="showCloneEquipment = false">Cancelar</button>
          <button class="btn-primary" :disabled="cloning" @click="submitCloneEquipment">
            {{ cloning ? 'Creando...' : 'Clonar equipos' }}
          </button>
        </div>
      </div>
    </div>
    <!-- ── Edit composition modal ─────────────────────────────────────── -->
    <div v-if="showEditComp" class="modal-overlay" @click.self="showEditComp = false">
      <div class="create-modal small-modal">
        <div class="modal-header">
          <h3>Editar composicion</h3>
          <button class="modal-close" @click="showEditComp = false">&#10005;</button>
        </div>
        <div class="modal-body">
          <div class="field">
            <label class="field-label">Nombre *</label>
            <input v-model="editCompForm.name" class="field-input" />
          </div>
          <div class="field">
            <label class="field-label">Descripción</label>
            <textarea v-model="editCompForm.description" class="field-input" rows="3" />
          </div>
          <div v-if="editCompFormError" class="modal-error">{{ editCompFormError }}</div>
        </div>
        <div class="modal-footer">
          <button class="btn-secondary" @click="showEditComp = false">Cancelar</button>
          <button class="btn-primary" @click="submitEditComposition">Guardar</button>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
import { useToast, apiErrorMsg } from '@/composables/useToast'
const toast = useToast()
import { ref, reactive, computed, onMounted, watch } from 'vue'
import { useFactoryStore } from '@/stores/factory'
import { NODE_TYPE_CONFIG, CRITICALITY_CONFIG, STATUS_CONFIG } from '@/types/factory'
import { ROLE_LABELS } from '@/types'
import { WO_TYPE_CONFIG, WO_PRIORITY_CONFIG, WO_STATUS_CONFIG, WO_TRANSITIONS } from '@/types/workorders'
import { CATEGORY_CONFIG } from '@/types/inventory'
import type { FactoryNode } from '@/types/factory'
import TreeNode from '@/components/factory/TreeNode.vue'
import NodeModal from '@/components/factory/NodeModal.vue'
import DirectoryPanel from '@/components/directories/DirectoryPanel.vue'
import SaveToDir from '@/components/directories/SaveToDir.vue'
import { useRouter, useRoute } from 'vue-router'
import { workOrdersApi, sparePartsApi, usersApi } from '@/api/phase2'
import { formatDate, formatDurationMinutes } from '@/utils/time'
import QRButton from '@/components/qr/QRButton.vue'
import PatternAlerts from '@/components/ai/PatternAlerts.vue'
import { useAuthStore } from '@/stores/auth'
import { useAIStore } from '@/stores/ai'
import { directoriesApi } from '@/api/directories'
import { useDirectoriesStore } from '@/stores/directories'
import { nodesApi } from '@/api/nodes'
import client from '@/api/client'
import { compositionsApi, compTemplatesApi, cloneApi } from '@/api/compositions'
import { maintenancePlansApi, maintenanceManualsApi } from '@/api/maintenance'
import type { EffectivePlan } from '@/api/maintenance'
import { useSystemPause } from '@/composables/useSystemPause'
import { useIsMobile } from '@/composables/useIsMobile'
import { useOfflineStore } from '@/stores/offline'
import { useOffline } from '@/composables/useOffline'
import { healthApi } from '@/api/phase2'
import { healthColor, healthLabel, HEALTH_FACTOR_LABELS } from '@/types/health'
import type { NodeHealth } from '@/types/health'

const { canWrite } = useSystemPause()
const isMobile = useIsMobile()
const offlineStore = useOfflineStore()
const { isOnline } = useOffline()

const factoryStore = useFactoryStore()
const authStore = useAuthStore()
const aiStore = useAIStore()
const router = useRouter()
const route = useRoute()

function openNodeChat() {
  const node = factoryStore.selectedNode
  if (!node) return
  aiStore.openChat(node.id, node.name)
}

function askNodeQuestion(question: string) {
  const node = factoryStore.selectedNode
  if (!node) return
  aiStore.openChat(node.id, node.name)
  setTimeout(() => aiStore.sendMessage(question), 300)
}
const dirStore = useDirectoriesStore()
const activeTab = ref('summary')
const searchQ = ref('')

// Node modal
const showModal = ref(false)
const modalParent = ref<FactoryNode | null>(null)
const modalEdit = ref<FactoryNode | null>(null)
function openModal(parent: FactoryNode | null, editNode?: FactoryNode) {
  modalParent.value = parent; modalEdit.value = editNode ?? null; showModal.value = true
}
function onNodeSaved(node: FactoryNode) { factoryStore.selectNode(node) }

async function deleteNode(node: FactoryNode) {
  const hasChildren = node.children && node.children.length > 0
  const msg = hasChildren
    ? `"${node.name}" tiene hijos. Elimina los hijos primero.`
    : `¿Eliminar "${node.name}"? Esta acción dará de baja el nodo.`

  if (hasChildren) { toast.error(msg); return }
  if (!confirm(msg)) return

  try {
    await nodesApi.delete(node.id)
    factoryStore.clearSelection()
    await factoryStore.refreshTree()
  } catch (err: unknown) {
    toast.fromError(err, 'Error eliminando nodo')
  }
}

// ─── Health Score ────────────────────────────────────────────────────────────
const nodeHealth = ref<NodeHealth | null>(null)

async function loadHealth(nodeId: number) {
  try {
    nodeHealth.value = await healthApi.getNodeHealth(nodeId)
  } catch { nodeHealth.value = null }
}

// ─── Data for each tab ────────────────────────────────────────────────────────
const nodeWOs        = ref<any[]>([])
const nodeParts      = ref<any[]>([])
const nodePersonnel  = ref<any[]>([])
const excludedPersonnel = ref<any[]>([])
const showExcluded   = ref(false)
const nodeLibrary    = ref<any[]>([])
const templateLibrary = ref<any[]>([])
const templateFolders = ref<any[]>([])
const tplCurrentFolderId = ref<number | null>(null)
const effectivePlans = ref<EffectivePlan[]>([])
const nodeManuals    = ref<any[]>([])
const loadingManuals = ref(false)
const showManualUpload = ref(false)
const uploadingManual = ref(false)
const manualError    = ref('')
const manualForm     = ref({ title: '', description: '' })
const manualFile     = ref<File | null>(null)
const myAssignmentDepth = ref(999)
const loadingWOs     = ref(false)
const loadingMaint   = ref(false)
const loadingParts   = ref(false)
const loadingPersonnel = ref(false)
const loadingLibrary = ref(false)

// ─── Directories per tab ─────────────────────────────────────────────────────
const woDirId       = ref<number | null>(null)
const woDirName     = ref<string | null>(null)
const woDirItemIds  = ref<number[]>([])
const woDirFullItems = ref<any[]>([])

const partsDirId      = ref<number | null>(null)
const partsDirName    = ref<string | null>(null)
const partsDirItemIds = ref<number[]>([])
const partsDirFullItems = ref<any[]>([])

const personnelDirId      = ref<number | null>(null)
const personnelDirName    = ref<string | null>(null)
const personnelDirItemIds = ref<number[]>([])
const personnelDirFullItems = ref<any[]>([])

const libraryDirId      = ref<number | null>(null)
const libraryDirName    = ref<string | null>(null)
const libraryDirItemIds = ref<number[]>([])
const libraryDirFullItems = ref<any[]>([])

// ─── Smart filters for the node's WOs ─────────────────────────────────────────
const activeNodeWOFilter = ref<string | null>(null)

const nodeSmartFilters = computed(() => {
  const all = nodeWOs.value
  const now = new Date()
  return [
    { id: 'active', label: 'Activas', count: all.filter(w => ['assigned', 'in_progress'].includes(w.status)).length },
    { id: 'pending', label: 'Pendientes', count: all.filter(w => w.status === 'pending').length },
    { id: 'completed', label: 'Completadas', count: all.filter(w => w.status === 'completed').length },
    { id: 'overdue', label: 'Vencidas', count: all.filter(w => w.planned_end && new Date(w.planned_end) < now && !['completed', 'verified', 'closed', 'cancelled'].includes(w.status)).length },
  ].filter(f => f.count > 0 || f.id === 'active')
})

function toggleNodeWOFilter(id: string) {
  activeNodeWOFilter.value = activeNodeWOFilter.value === id ? null : id
}

// ─── Computed: filtered by folder + smart filter ──────────────────────────
const displayedWOs = computed(() => {
  let list = nodeWOs.value
  // Apply the smart filter
  if (activeNodeWOFilter.value) {
    const now = new Date()
    const f = activeNodeWOFilter.value
    if (f === 'active') list = list.filter(w => ['assigned', 'in_progress'].includes(w.status))
    else if (f === 'pending') list = list.filter(w => w.status === 'pending')
    else if (f === 'completed') list = list.filter(w => w.status === 'completed')
    else if (f === 'overdue') list = list.filter(w => w.planned_end && new Date(w.planned_end) < now && !['completed', 'verified', 'closed', 'cancelled'].includes(w.status))
  }
  if (woDirId.value === null) return list
  const fromLoaded = nodeWOs.value.filter(wo => woDirItemIds.value.includes(wo.id))
  if (fromLoaded.length === woDirItemIds.value.length) return fromLoaded
  const loadedIds = new Set(fromLoaded.map(wo => wo.id))
  const fromDir = woDirFullItems.value
    .filter(item => !loadedIds.has(item.item_id))
    .map(item => ({
      id: item.item_id, wo_number: item.ref ?? '', title: item.name ?? '',
      status: item.status ?? '', priority: item.extra ?? '',
      node_name: '', wo_type: '', assigned_name: null, created_at: '',
    }))
  return [...fromLoaded, ...fromDir]
})
const displayedParts = computed(() => {
  if (partsDirId.value === null) return nodeParts.value
  const fromLoaded = nodeParts.value.filter(sp => partsDirItemIds.value.includes(sp.id))
  if (fromLoaded.length === partsDirItemIds.value.length) return fromLoaded
  const loadedIds = new Set(fromLoaded.map(sp => sp.id))
  const fromDir = partsDirFullItems.value
    .filter(item => !loadedIds.has(item.item_id))
    .map(item => ({
      id: item.item_id, code: item.ref ?? '', name: item.name ?? '',
      category: item.status ?? '', current_stock: Number(item.extra) || 0,
      min_stock: 0, unit: '',
    }))
  return [...fromLoaded, ...fromDir]
})
const displayedPersonnel = computed(() => {
  if (personnelDirId.value === null) return nodePersonnel.value
  const fromLoaded = nodePersonnel.value.filter(p => personnelDirItemIds.value.includes(p.id))
  if (fromLoaded.length === personnelDirItemIds.value.length) return fromLoaded
  const loadedIds = new Set(fromLoaded.map(p => p.id))
  const fromDir = personnelDirFullItems.value
    .filter(item => !loadedIds.has(item.item_id))
    .map(item => ({
      id: item.item_id, email: item.ref ?? '', full_name: item.name ?? '',
      role: item.status ?? '', status: item.extra ?? '',
    }))
  return [...fromLoaded, ...fromDir]
})
const displayedLibrary = computed(() => {
  if (libraryDirId.value === null) return nodeLibrary.value
  const fromLoaded = nodeLibrary.value.filter(a => libraryDirItemIds.value.includes(a.id))
  if (fromLoaded.length === libraryDirItemIds.value.length) return fromLoaded
  const loadedIds = new Set(fromLoaded.map(a => a.id))
  const fromDir = libraryDirFullItems.value
    .filter(item => !loadedIds.has(item.item_id))
    .map(item => ({
      id: item.item_id, original_name: item.name ?? '', category: item.status ?? '',
      mime_type: item.extra ?? '', file_size: 0, node_name: '',
    }))
  return [...fromLoaded, ...fromDir]
})

// ─── Folder selection handlers ────────────────────────────────────────
async function onWoDirSelect(id: number | null) {
  woDirId.value = id; woDirName.value = null
  woDirItemIds.value = []; woDirFullItems.value = []
  if (!id) return
  try {
    const data = await directoriesApi.getItems(id)
    woDirItemIds.value = (data.items ?? []).map((i: any) => i.item_id)
    woDirFullItems.value = data.items ?? []
    woDirName.value = dirStore.findDirInSection('work_orders', id)?.name ?? null
  } catch { woDirItemIds.value = []; woDirFullItems.value = [] }
}

async function onPartsDirSelect(id: number | null) {
  partsDirId.value = id; partsDirName.value = null
  partsDirItemIds.value = []; partsDirFullItems.value = []
  if (!id) return
  try {
    const data = await directoriesApi.getItems(id)
    partsDirItemIds.value = (data.items ?? []).map((i: any) => i.item_id)
    partsDirFullItems.value = data.items ?? []
    partsDirName.value = dirStore.findDirInSection('spare_parts', id)?.name ?? null
  } catch { partsDirItemIds.value = []; partsDirFullItems.value = [] }
}

async function onPersonnelDirSelect(id: number | null) {
  personnelDirId.value = id; personnelDirName.value = null
  personnelDirItemIds.value = []; personnelDirFullItems.value = []
  if (!id) return
  try {
    const data = await directoriesApi.getItems(id)
    personnelDirItemIds.value = (data.items ?? []).map((i: any) => i.item_id)
    personnelDirFullItems.value = data.items ?? []
    personnelDirName.value = dirStore.findDirInSection('personnel', id)?.name ?? null
  } catch { personnelDirItemIds.value = []; personnelDirFullItems.value = [] }
}

async function onLibraryDirSelect(id: number | null) {
  libraryDirId.value = id; libraryDirName.value = null
  libraryDirItemIds.value = []; libraryDirFullItems.value = []
  if (!id) return
  try {
    const data = await directoriesApi.getItems(id)
    libraryDirItemIds.value = (data.items ?? []).map((i: any) => i.item_id)
    libraryDirFullItems.value = data.items ?? []
    libraryDirName.value = dirStore.findDirInSection('library', id)?.name ?? null
  } catch { libraryDirItemIds.value = []; libraryDirFullItems.value = [] }
}

// Refresh after saving into a folder
async function refreshWODir() { if (woDirId.value) await onWoDirSelect(woDirId.value) }
async function refreshPartsDir() { if (partsDirId.value) await onPartsDirSelect(partsDirId.value) }
async function refreshPersonnelDir() { if (personnelDirId.value) await onPersonnelDirSelect(personnelDirId.value) }
async function refreshLibraryDir() { if (libraryDirId.value) await onLibraryDirSelect(libraryDirId.value) }

// ─── Drag & drop into folders ──────────────────────────────────────────────────
function startDrag(e: DragEvent, itemType: string, itemId: number) {
  if (!e.dataTransfer) return
  e.dataTransfer.setData('application/x-dir-item', JSON.stringify({ item_type: itemType, item_id: itemId }))
  e.dataTransfer.effectAllowed = 'copy'
}

// ─── Tabs ─────────────────────────────────────────────────────────────────────

const tabs = computed(() => {
  const all = [
    { id: 'summary',     label: 'Resumen',     disabled: false },
    { id: 'structure',   label: 'Estructura',  disabled: false },
    { id: 'workorders',  label: 'OTs',         disabled: false, count: nodeWOs.value.length },
    { id: 'maintenance', label: 'Preventivo',  disabled: false, count: activePlanCount.value },
    { id: 'parts',       label: 'Repuestos',   disabled: false, count: nodeParts.value.length },
    { id: 'personnel',   label: 'Personal',    disabled: false, count: nodePersonnel.value.length },
    { id: 'library',     label: 'Biblioteca',  disabled: false, count: nodeLibrary.value.length },
    { id: 'composition', label: factoryStore.selectedNode?.node_type === 'composition' ? 'Slots' : 'Composición', disabled: false, count: factoryStore.selectedNode?.node_type === 'composition' ? compDetailSlots.value.length : nodeCompositions.value.length + childCompositions.value.length },
    { id: 'ai',          label: 'Arche IA',    disabled: false },
  ]
  if (authStore.isFieldWorker) {
    return all.filter(t => !['structure', 'maintenance'].includes(t.id))
  }
  return all
})

async function selectTab(id: string) {
  activeTab.value = id
  const nodeId = factoryStore.selectedNode?.id
  if (!nodeId) return

  // Reload the tab's data when it is still empty (fallback when the preload failed)
  if (id === 'workorders' && !nodeWOs.value.length) await loadWOs(nodeId)
  if (id === 'parts' && !nodeParts.value.length) await loadParts(nodeId)
  // Personnel: always reload when the tab is selected, to guarantee fresh data
  if (id === 'personnel') await loadPersonnel(nodeId)
  if (id === 'library' && !nodeLibrary.value.length) await loadLibrary(nodeId)
  if (id === 'maintenance' && !effectivePlans.value.length) await loadMaintPlans(nodeId)
  if (id === 'composition') { await loadCompositions(nodeId); loadCompTemplates() }
}

// ─── KPI clickable helpers ──────────────────────────────────────────────────
function kpiGoToWOs(filter: string) {
  activeNodeWOFilter.value = filter
  selectTab('workorders')
}

// ─── Individual load functions ─────────────────────────────────────────
// Guard: keeps late responses from a previous node from overwriting the data
function isStale(nodeId: number) { return factoryStore.selectedNode?.id !== nodeId }

async function loadWOs(nodeId: number) {
  try {
    if (!isOnline.value) {
      const cached = await offlineStore.getWorkOrders()
      if (!isStale(nodeId)) nodeWOs.value = cached.filter(w => w.node_id === nodeId) as any[]
      return
    }
    const d = await workOrdersApi.list({ node_id: nodeId }); if (!isStale(nodeId)) nodeWOs.value = d.work_orders ?? []
  } catch {
    const cached = await offlineStore.getWorkOrders()
    if (!isStale(nodeId)) nodeWOs.value = cached.filter(w => w.node_id === nodeId) as any[]
  }
}
async function loadParts(nodeId: number) {
  try { const d = await sparePartsApi.list({ node_id: nodeId }); if (!isStale(nodeId)) nodeParts.value = d.spare_parts ?? [] }
  catch (e) { console.error('loadParts failed:', e) }
}
async function loadPersonnel(nodeId: number) {
  try {
    const resp = await client.get(`/factory/nodes/${nodeId}/personnel`)
    if (isStale(nodeId)) return
    nodePersonnel.value = resp.data?.personnel ?? []
    excludedPersonnel.value = resp.data?.excluded ?? []
    showExcluded.value = false
  } catch (e) { console.error('loadPersonnel failed:', e) }
}
const templateLibraryName = ref<string | null>(null)

async function loadLibrary(nodeId: number) {
  try {
    const d = await client.get(`/factory/nodes/${nodeId}/library`)
    if (isStale(nodeId)) return
    nodeLibrary.value = d.data?.attachments ?? []
    templateLibrary.value = d.data?.template_attachments ?? []
    templateFolders.value = d.data?.template_folders ?? []
    templateLibraryName.value = d.data?.template_name ?? null
    tplCurrentFolderId.value = null
  } catch (e) { console.error('loadLibrary failed:', e) }
}

const visibleTplFolders = computed(() => {
  return templateFolders.value.filter((f: any) =>
    tplCurrentFolderId.value === null ? f.parent_id == null : f.parent_id === tplCurrentFolderId.value
  )
})

const visibleTplFiles = computed(() => {
  return templateLibrary.value.filter((a: any) =>
    tplCurrentFolderId.value === null ? a.template_folder_id == null : a.template_folder_id === tplCurrentFolderId.value
  )
})
async function loadMaintPlans(nodeId: number) {
  loadingMaint.value = true
  try {
    const r = await maintenancePlansApi.effectivePlans(nodeId)
    if (!isStale(nodeId)) effectivePlans.value = r.plans ?? []
  } catch { if (!isStale(nodeId)) effectivePlans.value = [] }
  finally { loadingMaint.value = false }
  loadManuals(nodeId)
}

const directPlans = computed(() => effectivePlans.value.filter(p => p.plan_source === 'direct'))
const inheritedPlans = computed(() => effectivePlans.value.filter(p => p.plan_source === 'inherited'))
const templatePlans = computed(() => effectivePlans.value.filter(p => p.plan_source === 'template'))
const activePlanCount = computed(() => effectivePlans.value.filter(p => !p.is_excluded).length)
const overduePlanCount = computed(() => effectivePlans.value.filter(p => {
  if (p.is_excluded || !p.next_due_at) return false
  return new Date(p.next_due_at) < new Date()
}).length)

async function toggleExclusion(plan: EffectivePlan) {
  const nodeId = factoryStore.selectedNode?.id
  if (!nodeId) return
  try {
    if (plan.is_excluded) {
      await maintenancePlansApi.removeExclusion(plan.id, nodeId)
    } else {
      await maintenancePlansApi.addExclusion(plan.id, nodeId)
    }
    await loadMaintPlans(nodeId)
  } catch (e) { console.error('toggleExclusion failed:', e) }
}

function openCreatePlanForNode() {
  if (!factoryStore.selectedNode) return
  router.push({ path: '/maintenance-plans', query: { create: '1', node_id: String(factoryStore.selectedNode.id) } })
}

// ─── Plan creation modal (in-situ) ──────────────────────────────────────────
const showPlanModal = ref(false)
const planSaving = ref(false)
const planError = ref('')
const planSuccess = ref('')
const planTechnicians = ref<any[]>([])
const planSectionOpen = reactive({ basic: true, procedure: false, checklist: false })
const planForm = ref({
  node_id: 0,
  title: '',
  wo_type: 'preventive',
  priority: 'medium',
  frequency_type: 'months' as string,
  frequency_value: 1,
  advance_days: 3,
  assigned_to: null as number | null,
  estimated_hours: null as number | null,
  apply_to_children: false,
  instructions: '',
  checklist: [] as { step: string; required: boolean }[],
})

async function openCreatePlan() {
  if (!factoryStore.selectedNode) return
  planForm.value = {
    node_id: factoryStore.selectedNode.id,
    title: '',
    wo_type: 'preventive',
    priority: 'medium',
    frequency_type: 'months',
    frequency_value: 1,
    advance_days: 3,
    assigned_to: null,
    estimated_hours: null,
    apply_to_children: false,
    instructions: '',
    checklist: [],
  }
  planError.value = ''
  planSuccess.value = ''
  planSectionOpen.basic = true
  planSectionOpen.procedure = false
  planSectionOpen.checklist = false
  showPlanModal.value = true
  // Load the available technicians
  if (!planTechnicians.value.length) {
    try {
      const { data } = await client.get('/technicians')
      planTechnicians.value = data.technicians ?? []
    } catch { planTechnicians.value = [] }
  }
}

async function submitPlan() {
  if (!planForm.value.title.trim()) { planError.value = 'El título es obligatorio'; return }
  if (!planForm.value.frequency_value || planForm.value.frequency_value < 1) { planError.value = 'La frecuencia debe ser al menos 1'; return }
  planSaving.value = true
  planError.value = ''
  planSuccess.value = ''
  try {
    const payload: Record<string, any> = {
      node_id: planForm.value.node_id,
      title: planForm.value.title,
      wo_type: planForm.value.wo_type,
      priority: planForm.value.priority,
      frequency_type: planForm.value.frequency_type,
      frequency_value: planForm.value.frequency_value,
      advance_days: planForm.value.advance_days,
      apply_to_children: planForm.value.apply_to_children,
    }
    if (planForm.value.assigned_to) payload.assigned_to = planForm.value.assigned_to
    if (planForm.value.estimated_hours) payload.estimated_hours = planForm.value.estimated_hours
    if (planForm.value.instructions.trim()) payload.instructions = planForm.value.instructions
    if (planForm.value.checklist.length) payload.checklist = planForm.value.checklist.filter(c => c.step.trim())
    await maintenancePlansApi.create(payload)
    showPlanModal.value = false
    // Reload the node's effective plans
    const nodeId = factoryStore.selectedNode?.id
    if (nodeId) await loadMaintPlans(nodeId)
  } catch (err: unknown) {
    planError.value = apiErrorMsg(err, 'Error creando el plan')
  } finally { planSaving.value = false }
}

// ─── Plan card helpers ───────────────────────────────────────────────────────
function planDueColor(nextDue: string | null): string {
  if (!nextDue) return 'var(--color-text-muted)'
  const diff = Math.ceil((new Date(nextDue).getTime() - Date.now()) / (1000 * 60 * 60 * 24))
  if (diff <= 0) return 'var(--color-alert)'
  if (diff <= 7) return '#F39C12'
  return '#27AE60'
}

async function loadManuals(nodeId: number) {
  loadingManuals.value = true
  try {
    const d = await maintenanceManualsApi.listByNode(nodeId)
    if (!isStale(nodeId)) nodeManuals.value = d.manuals ?? []
  } catch { if (!isStale(nodeId)) nodeManuals.value = [] }
  finally { loadingManuals.value = false }
}

function onManualFileChange(e: Event) {
  const input = e.target as HTMLInputElement
  manualFile.value = input.files?.[0] ?? null
}

function manualDownloadUrl(manualId: number) {
  const nodeId = factoryStore.selectedNode?.id
  if (!nodeId) return '#'
  return maintenanceManualsApi.downloadUrl(nodeId, manualId)
}

async function uploadManual() {
  const nodeId = factoryStore.selectedNode?.id
  if (!nodeId || !manualFile.value) { manualError.value = 'Selecciona un archivo'; return }
  uploadingManual.value = true; manualError.value = ''
  try {
    const fd = new FormData()
    fd.append('file', manualFile.value)
    if (manualForm.value.title) fd.append('title', manualForm.value.title)
    if (manualForm.value.description) fd.append('description', manualForm.value.description)
    await maintenanceManualsApi.upload(nodeId, fd)
    showManualUpload.value = false
    manualForm.value = { title: '', description: '' }
    manualFile.value = null
    loadManuals(nodeId)
  } catch (err: unknown) {
    manualError.value = apiErrorMsg(err, 'Error subiendo manual')
  } finally { uploadingManual.value = false }
}

async function deleteManual(manualId: number) {
  const nodeId = factoryStore.selectedNode?.id
  if (!nodeId || !confirm('Eliminar este manual?')) return
  try {
    await maintenanceManualsApi.delete(nodeId, manualId)
    loadManuals(nodeId)
  } catch { /* ignore */ }
}

// Reset and preload the counters when the node changes
watch(() => factoryStore.selectedNode?.id, (nodeId, oldId) => {
  if (nodeId === oldId) return
  activeTab.value = 'summary'
  nodeWOs.value = []; nodeParts.value = []; nodePersonnel.value = []; nodeLibrary.value = []; effectivePlans.value = []; nodeManuals.value = []; nodeCompositions.value = []; childCompositions.value = []; selectedComposition.value = null; nodeHealth.value = null
  loadingWOs.value = false; loadingParts.value = false; loadingPersonnel.value = false; loadingLibrary.value = false; loadingMaint.value = false; loadingManuals.value = false
  activeNodeWOFilter.value = null
  woDirId.value = null; woDirName.value = null; woDirItemIds.value = []
  partsDirId.value = null; partsDirName.value = null; partsDirItemIds.value = []
  personnelDirId.value = null; personnelDirName.value = null; personnelDirItemIds.value = []
  libraryDirId.value = null; libraryDirName.value = null; libraryDirItemIds.value = []

  if (nodeId) {
    loadWOs(nodeId)
    loadParts(nodeId)
    loadPersonnel(nodeId)
    loadLibrary(nodeId)
    loadMaintPlans(nodeId)
    loadHealth(nodeId)
    // For composition nodes, load the slots automatically
    if (factoryStore.selectedNode?.node_type === 'composition') {
      loadCompositionNodeSlots(nodeId)
    }
  } else {
    loadAllCompositions()
  }
})

// ─── Create a WO from the node ─────────────────────────────────────────────────────
const showCreateWO = ref(false)
const creatingWO   = ref(false)
const woError      = ref('')
const woForm       = ref({ title: '', wo_type: 'corrective', priority: 'medium', description: '', assigned_to: null as number | null })

async function openCreateWO() {
  woForm.value = { title: '', wo_type: 'corrective', priority: 'medium', description: '', assigned_to: null }
  woError.value = ''
  if (!woAvailableTechs.value.length) {
    try {
      const data = await usersApi.list({ status: 'active' })
      woAvailableTechs.value = (data.users ?? [])
        .filter((u: any) => ['technician', 'operator', 'supervisor'].includes(u.role))
        .map((u: any) => ({ id: u.id, full_name: u.full_name, role: u.role }))
    } catch { /* silent */ }
  }
  showCreateWO.value = true
}

async function submitCreateWO() {
  if (!woForm.value.title || !factoryStore.selectedNode) { woError.value = 'El título es requerido'; return }
  const nodeId = factoryStore.selectedNode.id
  creatingWO.value = true; woError.value = ''
  try {
    await workOrdersApi.create({ node_id: nodeId, title: woForm.value.title, wo_type: woForm.value.wo_type as any, priority: woForm.value.priority as any, description: woForm.value.description || undefined, assigned_to: woForm.value.assigned_to || undefined } as any)
    showCreateWO.value = false
    if (activeTab.value === 'workorders') {
      const d = await workOrdersApi.list({ node_id: nodeId })
      nodeWOs.value = d.work_orders ?? []
    }
  } catch (err: unknown) { woError.value = apiErrorMsg(err, 'Error creando la OT')
  } finally { creatingWO.value = false }
}

// ─── Library ───────────────────────────────────────────────────────────────
const uploadingFile = ref(false)

async function handleFileUpload(event: Event) {
  const input = event.target as HTMLInputElement
  if (!input.files?.length || !factoryStore.selectedNode) return
  uploadingFile.value = true
  const formData = new FormData()
  formData.append('file', input.files[0])
  formData.append('category', 'other')
  try {
    await client.post(`/factory/nodes/${factoryStore.selectedNode.id}/library/upload`, formData, { headers: { 'Content-Type': 'multipart/form-data' } })
    const d = await client.get(`/factory/nodes/${factoryStore.selectedNode.id}/library`)
    nodeLibrary.value = d.data.attachments ?? []
  } catch (err: unknown) { toast.fromError(err, 'Error subiendo el archivo')
  } finally { uploadingFile.value = false; input.value = '' }
}

async function deleteFile(id: number) {
  if (!confirm('¿Eliminar este archivo?')) return
  try { await client.delete(`/library/${id}`); nodeLibrary.value = nodeLibrary.value.filter(a => a.id !== id) }
  catch { toast.error('Error eliminando archivo') }
}

// ─── WO detail from the node ───────────────────────────────────────────────────
const woDetail = ref<any>(null)
const woDetailActiveTab = ref('info')
const woDetailTabs = [{ id: 'info', label: 'Información' }, { id: 'log', label: 'Historial' }, { id: 'comments', label: 'Comentarios' }]
const woNewComment = ref('')
const woTransitionModal = ref<any>(null)
const woTransitionData = ref({ comment: '', actual_hours: undefined as number | undefined, actual_hours_raw: '', root_cause: '', solution: '' })
const woTransitionError = ref('')
const woTransitioning = ref(false)

const isManager = computed(() => authStore.isManager)
const isSupervisor = computed(() => authStore.isSupervisor)

const woTransitions = computed(() => {
  if (!woDetail.value) return []
  const role = authStore.user?.role ?? ''
  return (WO_TRANSITIONS[woDetail.value.work_order.status] ?? [])
    .filter(t => t.roles.includes(role))
})

const woSignaturesInfo = ref<any>(null)
const woTechSuggestions = ref<any[]>([])
const woLoadingSuggestTech = ref(false)
const woReassignMode = ref(false)
const woReassignUserId = ref<number | null>(null)
const woReassigning = ref(false)
const woAvailableTechs = ref<{ id: number; full_name: string; role: string }[]>([])
const woScoreModal = ref<any>(null)
const woScoreForm = ref({ score: 0, comment: '' })
const woScoreError = ref('')
const woSavingScore = ref(false)

async function openWODetail(wo: any) {
  try {
    if (!isOnline.value) {
      const cached = await offlineStore.getWorkOrder(wo.id)
      if (cached) {
        woDetail.value = { work_order: cached, log: cached.log, comments: cached.comments }
      }
      woDetailActiveTab.value = 'info'
      woNewComment.value = ''
      woSignaturesInfo.value = null
      woTechSuggestions.value = []
      woReassignMode.value = false
      return
    }
    const data = await workOrdersApi.getOne(wo.id)
    woDetail.value = data
    woDetailActiveTab.value = 'info'
    woNewComment.value = ''
    woSignaturesInfo.value = null
    woTechSuggestions.value = []
    woReassignMode.value = false
    client.get(`/work-orders/${wo.id}/signatures`)
      .then(r => { woSignaturesInfo.value = r.data })
      .catch(err => console.error('[Factory] signatures', err))
  } catch (err: unknown) {
    const cached = await offlineStore.getWorkOrder(wo.id)
    if (cached) {
      woDetail.value = { work_order: cached, log: cached.log, comments: cached.comments }
      woDetailActiveTab.value = 'info'
      woNewComment.value = ''
      woSignaturesInfo.value = null
      woTechSuggestions.value = []
      woReassignMode.value = false
    } else {
      toast.fromError(err, 'Error cargando OT')
    }
  }
}

function openWOTransition(t: any) {
  woTransitionModal.value = t
  woTransitionData.value = { comment: '', actual_hours: undefined, actual_hours_raw: '', root_cause: '', solution: '' }
  woTransitionError.value = ''
}

function parseHoursInput(raw: string): number | undefined {
  if (!raw || !raw.trim()) return undefined
  const trimmed = raw.trim()
  if (trimmed.includes(':')) {
    const parts = trimmed.split(':')
    const h = parseInt(parts[0], 10)
    const m = parseInt(parts[1], 10)
    if (isNaN(h) || isNaN(m) || h < 0 || m < 0 || m >= 60) return undefined
    return h + m / 60
  }
  const num = parseFloat(trimmed.replace(',', '.'))
  if (isNaN(num) || num < 0) return undefined
  return num
}

async function confirmWOTransition() {
  if (!woDetail.value || !woTransitionModal.value) return
  if (woTransitionModal.value.requireComment && !woTransitionData.value.comment.trim()) {
    woTransitionError.value = 'El comentario es obligatorio'; return
  }
  if (woTransitionData.value.actual_hours_raw) {
    const parsed = parseHoursInput(woTransitionData.value.actual_hours_raw)
    if (parsed === undefined) { woTransitionError.value = 'Formato de horas inválido. Use 5:30 o 5.5'; return }
    woTransitionData.value.actual_hours = Math.round(parsed * 100) / 100
  }
  const wo = woDetail.value.work_order
  woTransitioning.value = true; woTransitionError.value = ''
  try {
    if (!isOnline.value) {
      await offlineStore.changeStatusOffline(
        wo.id,
        woTransitionModal.value.to,
        woTransitionData.value.comment || undefined,
        {
          actual_hours: woTransitionData.value.actual_hours,
          root_cause: woTransitionData.value.root_cause || undefined,
          solution: woTransitionData.value.solution || undefined,
        }
      )
      woTransitionModal.value = null
      const updated = await offlineStore.getWorkOrder(wo.id)
      if (updated) {
        woDetail.value = { work_order: updated, log: updated.log, comments: updated.comments }
      }
      const nodeId = factoryStore.selectedNode?.id
      if (nodeId) await loadWOs(nodeId)
    } else {
      await workOrdersApi.changeStatus(wo.id, {
        status: woTransitionModal.value.to,
        comment: woTransitionData.value.comment || undefined,
        actual_hours: woTransitionData.value.actual_hours,
        root_cause: woTransitionData.value.root_cause || undefined,
        solution: woTransitionData.value.solution || undefined,
        version: wo.version,
      })
      woTransitionModal.value = null
      await openWODetail(wo)
      const nodeId = factoryStore.selectedNode?.id
      if (nodeId) {
        const d = await workOrdersApi.list({ node_id: nodeId })
        nodeWOs.value = d.work_orders ?? []
      }
    }
  } catch (err: unknown) {
    woTransitionError.value = apiErrorMsg(err, 'Error cambiando estado')
  } finally { woTransitioning.value = false }
}

async function submitWOComment() {
  if (!woDetail.value || !woNewComment.value.trim()) return
  const wo = woDetail.value.work_order
  try {
    if (!isOnline.value) {
      await offlineStore.addCommentOffline(wo.id, woNewComment.value)
      woNewComment.value = ''
      const updated = await offlineStore.getWorkOrder(wo.id)
      if (updated) {
        woDetail.value = { work_order: updated, log: updated.log, comments: updated.comments }
      }
    } else {
      await workOrdersApi.addComment(wo.id, woNewComment.value)
      woNewComment.value = ''
      await openWODetail(wo)
    }
  } catch { /* silent */ }
}

// ─── Advanced WO actions (PDF, signature, scoring, AI) ────────────────────────
async function woOpenPDF(id: number) {
  try {
    const [dataResp, htmlResp] = await Promise.all([
      client.get<any>(`/reports/wo/${id}/data`),
      client.get<string>(`/reports/wo/${id}/html`, { responseType: 'text' as const })
    ])
    let html = htmlResp.data
    const dataScript = `<script>window.WO_DATA = ${JSON.stringify(dataResp.data)};<` + `/script>`
    html = html.replace('</head>', dataScript + '</head>')
    const blob = new Blob([html], { type: 'text/html' })
    const blobUrl = URL.createObjectURL(blob)
    const win = window.open(blobUrl, '_blank')
    if (win) setTimeout(() => URL.revokeObjectURL(blobUrl), 15000)
  } catch (err: unknown) {
    toast.fromError(err, 'Error generando el informe')
    console.error('[Factory] woOpenPDF', err)
  }
}


function woOpenScore(wo: any) {
  woScoreModal.value = wo
  woScoreForm.value = { score: 0, comment: '' }
  woScoreError.value = ''
}

async function woSubmitScore() {
  if (!woScoreForm.value.score || !woScoreModal.value) return
  woSavingScore.value = true; woScoreError.value = ''
  try {
    await client.post(`/technicians/${woScoreModal.value.assigned_to}/scores`, {
      wo_id: woScoreModal.value.id,
      score: woScoreForm.value.score,
      comment: woScoreForm.value.comment || null
    })
    woScoreModal.value = null
    toast.success('Puntuación guardada correctamente')
  } catch (err: unknown) {
    woScoreError.value = err?.response?.data?.error ?? 'Error guardando puntuación'
  } finally { woSavingScore.value = false }
}

async function woSuggestTechnician(woId: number) {
  woLoadingSuggestTech.value = true
  woTechSuggestions.value = []
  try {
    const { data } = await client.get(`/technicians/suggest/${woId}`)
    if (data.auto_assigned && woDetail.value) {
      // The node's only technician was auto-assigned — reload the WO
      await openWODetail(woDetail.value.work_order)
      return
    }
    woTechSuggestions.value = data.suggestions ?? []
  } catch { /* silent */ }
  finally { woLoadingSuggestTech.value = false }
}

async function woAssignTechnician(woId: number, userId: number) {
  if (!woDetail.value) return
  try {
    const wo = woDetail.value.work_order
    await workOrdersApi.update(woId, {
      title: wo.title, description: wo.description, priority: wo.priority,
      assigned_to: userId, estimated_hours: wo.estimated_hours,
      planned_start: wo.planned_start, planned_end: wo.planned_end, version: wo.version,
    } as any)
    woTechSuggestions.value = []
    await openWODetail(wo)
    const nodeId = factoryStore.selectedNode?.id
    if (nodeId) { const d = await workOrdersApi.list({ node_id: nodeId }); nodeWOs.value = d.work_orders ?? [] }
  } catch { toast.error('Error asignando técnico') }
}

async function woOpenReassign() {
  woReassignMode.value = true
  woReassignUserId.value = woDetail.value?.work_order?.assigned_to ?? null
  woTechSuggestions.value = []
  if (!woAvailableTechs.value.length) {
    try {
      const data = await usersApi.list({ status: 'active' })
      woAvailableTechs.value = (data.users ?? [])
        .filter((u: any) => ['technician', 'operator', 'supervisor'].includes(u.role))
        .map((u: any) => ({ id: u.id, full_name: u.full_name, role: u.role }))
    } catch { /* silent */ }
  }
}

async function woConfirmReassign() {
  if (!woDetail.value) return
  woReassigning.value = true
  try {
    const wo = woDetail.value.work_order
    await workOrdersApi.update(wo.id, {
      title: wo.title, description: wo.description, priority: wo.priority,
      assigned_to: woReassignUserId.value, estimated_hours: wo.estimated_hours,
      planned_start: wo.planned_start, planned_end: wo.planned_end, version: wo.version,
    } as any)
    woReassignMode.value = false
    await openWODetail(wo)
    const nodeId = factoryStore.selectedNode?.id
    if (nodeId) { const d = await workOrdersApi.list({ node_id: nodeId }); nodeWOs.value = d.work_orders ?? [] }
  } catch (e: unknown) { toast.fromError(e, 'Error reasignando')
  } finally { woReassigning.value = false }
}

async function woUnassignTechnician() {
  if (!woDetail.value) return
  const wo = woDetail.value.work_order
  try {
    await workOrdersApi.update(wo.id, {
      title: wo.title, description: wo.description, priority: wo.priority,
      assigned_to: null, estimated_hours: wo.estimated_hours,
      planned_start: wo.planned_start, planned_end: wo.planned_end, version: wo.version,
    } as any)
    await openWODetail(wo)
    const nodeId = factoryStore.selectedNode?.id
    if (nodeId) { const d = await workOrdersApi.list({ node_id: nodeId }); nodeWOs.value = d.work_orders ?? [] }
  } catch (e: unknown) { toast.fromError(e, 'Error desasignando') }
}

async function woSelfAssign() {
  if (!woDetail.value || !authStore.user) return
  const wo = woDetail.value.work_order
  try {
    await workOrdersApi.update(wo.id, {
      title: wo.title, description: wo.description, priority: wo.priority,
      assigned_to: authStore.user.id, estimated_hours: wo.estimated_hours,
      planned_start: wo.planned_start, planned_end: wo.planned_end, version: wo.version,
    } as any)
    await openWODetail(wo)
    const nodeId = factoryStore.selectedNode?.id
    if (nodeId) { const d = await workOrdersApi.list({ node_id: nodeId }); nodeWOs.value = d.work_orders ?? [] }
  } catch (e: unknown) { toast.fromError(e, 'Error tomando OT') }
}

function woGetSuggestion(_woId: number) {
  if (!woDetail.value) return
  const wo = woDetail.value.work_order
  const nodeName = factoryStore.selectedNode?.name ?? wo.node_name ?? 'Equipo'
  const nodeId = wo.node_id

  // Build a diagnostic message with the WO's context
  let msg = `Necesito diagnosticar esta avería y encontrar la causa raíz:\n`
  msg += `- Equipo: ${nodeName}\n`
  msg += `- OT: ${wo.wo_number} — ${wo.title}\n`
  if (wo.description) msg += `- Descripción: ${wo.description}\n`
  if (wo.priority) msg += `- Prioridad: ${wo.priority}\n`
  msg += `\n¿Cuáles son las causas más probables? Hazme las preguntas necesarias para llegar a un diagnóstico preciso.`

  // Open the chat (z-index 1100 > modal 1000), then close the modal
  aiStore.openDiagnostic(nodeId, nodeName, msg)
  setTimeout(() => { woDetail.value = null }, 300)
}

// ─── Attach spare parts to the node ────────────────────────────────────────────────
const showLinkPart   = ref(false)
const partSearchQ    = ref('')
const availableParts = ref<any[]>([])
const searchingParts = ref(false)
const linkPartError  = ref('')

let partSearchTimer: ReturnType<typeof setTimeout> | null = null
function searchParts() {
  linkPartError.value = ''
  if (partSearchTimer) clearTimeout(partSearchTimer)
  if (partSearchQ.value.length < 2) { availableParts.value = []; return }
  partSearchTimer = setTimeout(async () => {
    searchingParts.value = true
    try {
      const d = await sparePartsApi.list({})
      const alreadyLinked = new Set(nodeParts.value.map((p: any) => p.id))
      const q = partSearchQ.value.toLowerCase()
      availableParts.value = (d.spare_parts ?? []).filter((sp: any) =>
        !alreadyLinked.has(sp.id) && (sp.name.toLowerCase().includes(q) || sp.code.toLowerCase().includes(q))
      )
    } catch { availableParts.value = [] }
    finally { searchingParts.value = false }
  }, 300)
}

async function linkPart(sparePartId: number) {
  const nodeId = factoryStore.selectedNode?.id
  if (!nodeId) return
  linkPartError.value = ''
  try {
    await client.post(`/factory/nodes/${nodeId}/spare-parts`, { spare_part_id: sparePartId })
    const d = await sparePartsApi.list({ node_id: nodeId })
    nodeParts.value = d.spare_parts ?? []
    // Remove it from the available list
    availableParts.value = availableParts.value.filter(sp => sp.id !== sparePartId)
  } catch (err: unknown) { linkPartError.value = apiErrorMsg(err, 'Error asociando repuesto') }
}

async function unlinkPart(sparePartId: number) {
  const nodeId = factoryStore.selectedNode?.id
  if (!nodeId || !confirm('¿Desasociar este repuesto del nodo?')) return
  try {
    await client.delete(`/factory/nodes/${nodeId}/spare-parts/${sparePartId}`)
    nodeParts.value = nodeParts.value.filter((sp: any) => sp.id !== sparePartId)
  } catch (err: unknown) { toast.fromError(err, 'Error desasociando repuesto') }
}

// ─── Assign staff to the node ────────────────────────────────────────────────
const showAssignPerson    = ref(false)
const personSearchQ       = ref('')
const allPersonnel        = ref<any[]>([])
const loadingAllPersonnel = ref(false)
const assignPersonError   = ref('')

const filteredAssignable = computed(() => {
  const assigned = new Set(nodePersonnel.value.map((p: any) => p.id))
  const q = personSearchQ.value.toLowerCase()
  if (q.length < 2) return []
  return allPersonnel.value.filter(p =>
    !assigned.has(p.id) && p.status === 'active' &&
    (p.full_name.toLowerCase().includes(q) || (p.email ?? '').toLowerCase().includes(q))
  )
})

async function openAssignPersonnel() {
  showAssignPerson.value = true
  assignPersonError.value = ''
  personSearchQ.value = ''
  if (!allPersonnel.value.length) {
    loadingAllPersonnel.value = true
    try {
      const d = await client.get('/personnel/')
      allPersonnel.value = d.data.personnel ?? []
    } catch { allPersonnel.value = [] }
    finally { loadingAllPersonnel.value = false }
  }
}

async function assignPerson(userId: number) {
  const nodeId = factoryStore.selectedNode?.id
  if (!nodeId) return
  assignPersonError.value = ''
  try {
    await client.post(`/personnel/${userId}/assignments`, { node_id: nodeId, is_primary: false })
  } catch (err: unknown) {
    assignPersonError.value = apiErrorMsg(err, 'Error asignando personal')
    return
  }
  // Reload the list and close the modal
  await loadPersonnel(nodeId)
  showAssignPerson.value = false
}

async function unassignPerson(userId: number) {
  const nodeId = factoryStore.selectedNode?.id
  if (!nodeId || !confirm('¿Desasignar esta persona del nodo?')) return
  try {
    await client.delete(`/factory/nodes/${nodeId}/personnel/${userId}`)
    nodePersonnel.value = nodePersonnel.value.filter((p: any) => p.id !== userId)
  } catch (err: unknown) { toast.fromError(err, 'Error desasignando personal') }
}

async function excludePerson(userId: number) {
  const nodeId = factoryStore.selectedNode?.id
  if (!nodeId || !confirm('¿Restringir acceso de esta persona a este nodo?')) return
  try {
    await client.post(`/factory/nodes/${nodeId}/personnel/${userId}/exclude`)
    await loadPersonnel(nodeId)
  } catch (err: unknown) { toast.fromError(err, 'Error restringiendo acceso') }
}

async function restorePerson(userId: number) {
  const nodeId = factoryStore.selectedNode?.id
  if (!nodeId || !confirm('¿Restaurar acceso de esta persona a este nodo?')) return
  try {
    await client.delete(`/factory/nodes/${nodeId}/personnel/${userId}/exclude`)
    await loadPersonnel(nodeId)
  } catch (err: unknown) { toast.fromError(err, 'Error restaurando acceso') }
}

function canManageUser(p: any): boolean {
  const myRole = authStore.user?.role
  if (myRole === 'admin') return true
  // For supervisors: they can only manage users with a greater depth (a lower rank)
  // We need the current user's depth — we take it from myAssignmentDepth
  if (myRole === 'supervisor' && p.assignment_depth > myAssignmentDepth.value) return true
  return false
}

function getRankLevel(depth: number): string {
  if (depth <= 2) return 'high'
  if (depth <= 3) return 'mid'
  return 'low'
}

function getRankLabel(nodeType: string): string {
  const labels: Record<string, string> = {
    organization: 'Organización', plant: 'Planta', area: 'Área',
    line: 'Linea', equipment: 'Equipo', component: 'Componente',
    measurement_point: 'Pto. medicion'
  }
  return labels[nodeType] ?? nodeType
}

// ─── Compositions ─────────────────────────────────────────────────────────
const nodeCompositions = ref<any[]>([])
const childCompositions = ref<any[]>([])
const selectedComposition = ref<any>(null)
const compDetailMembers = ref<any[]>([])
const compDetailSlots = ref<any[]>([])
const loadingCompositions = ref(false)

// Global compositions (panel with no node selected)
const loadingAllComps = ref(false)

// Modals
const showCreateComp = ref(false)
const showAddCompMember = ref(false)
const showApplyCompTemplate = ref(false)
const showCloneEquipment = ref(false)
const showEditComp = ref(false)
const compTemplates = ref<any[]>([])
const equipmentTemplates = ref<any[]>([])

// Edit composition form
const editCompForm = ref({ id: 0, name: '', description: '' })
const editCompFormError = ref('')

// Create composition form
const compForm = ref({ name: '', description: '', node_ids: [] as number[], roles: [] as string[] })
const compNodeSearch = ref('')
const compSearchResults = ref<any[]>([])
const compFormError = ref('')

// Clone equipment form
const cloneForm = ref({ equipment_template_id: 0, count: 1, name_prefix: '', start_number: 1 })
const cloneFormError = ref('')
const cloning = ref(false)

// Apply template form
const applyTemplateId = ref<number>(0)
const applyName = ref('')
const applyError = ref('')
const applying = ref(false)

// Load the slots for a composition node (finds the linked equipment_composition)
async function loadCompositionNodeSlots(nodeId: number) {
  loadingCompositions.value = true
  try {
    // Find the composition linked to this node
    const comps = await compositionsApi.list()
    const linked = comps.find((c: any) => c.node_id === nodeId)
    if (linked) {
      const data = await compositionsApi.getOne(linked.id)
      compDetailSlots.value = data.slots ?? []
      compDetailMembers.value = data.members ?? []
      selectedComposition.value = linked
    } else {
      compDetailSlots.value = []
      compDetailMembers.value = []
    }
  } catch { compDetailSlots.value = []; compDetailMembers.value = [] }
  loadingCompositions.value = false
}

async function loadCompositions(nodeId: number) {
  loadingCompositions.value = true
  try {
    const [byNode, byParent, templates] = await Promise.all([
      compositionsApi.byNode(nodeId),
      compositionsApi.byParent(nodeId),
      compTemplatesApi.list().catch(() => []),
    ])
    nodeCompositions.value = byNode
    childCompositions.value = byParent
    compTemplates.value = templates
    selectedComposition.value = null
    compDetailMembers.value = []
  } catch { /* empty */ }
  loadingCompositions.value = false
}

async function selectComposition(comp: any) {
  selectedComposition.value = comp
  try {
    const data = await compositionsApi.getOne(comp.id)
    compDetailMembers.value = data.members
    compDetailSlots.value = data.slots ?? []
  } catch { compDetailMembers.value = []; compDetailSlots.value = [] }
}

function openCreateComposition() {
  compForm.value = {
    name: '', description: '',
    node_ids: factoryStore.selectedNode ? [factoryStore.selectedNode.id] : [],
    roles: ['']
  }
  compFormError.value = ''
  compNodeSearch.value = ''
  compSearchResults.value = []
  showCreateComp.value = true
}

async function searchCompNodes() {
  if (compNodeSearch.value.length < 2) { compSearchResults.value = []; return }
  try {
    const results = await nodesApi.search(compNodeSearch.value)
    compSearchResults.value = (results || []).filter(
      (n: any) => !compForm.value.node_ids.includes(n.id)
    )
  } catch { compSearchResults.value = [] }
}

function addCompNode(node: any) {
  compForm.value.node_ids.push(node.id)
  compForm.value.roles.push('')
  compSearchResults.value = compSearchResults.value.filter((n: any) => n.id !== node.id)
  compNodeSearch.value = ''
}

function removeCompNode(index: number) {
  compForm.value.node_ids.splice(index, 1)
  compForm.value.roles.splice(index, 1)
}

async function submitCreateComposition() {
  if (!compForm.value.name.trim()) { compFormError.value = 'El nombre es obligatorio'; return }
  if (compForm.value.node_ids.length < 2) { compFormError.value = 'Se necesitan al menos 2 componentes'; return }
  compFormError.value = ''
  try {
    await compositionsApi.create({
      name: compForm.value.name,
      description: compForm.value.description || undefined,
      parent_node_id: factoryStore.selectedNode?.id,
      node_ids: compForm.value.node_ids,
      roles: compForm.value.roles,
    })
    showCreateComp.value = false
    if (factoryStore.selectedNode) await loadCompositions(factoryStore.selectedNode.id)
  } catch (err: unknown) { compFormError.value = apiErrorMsg(err, 'Error creando composición') }
}

function openAddCompMember() {
  compNodeSearch.value = ''
  compSearchResults.value = []
  showAddCompMember.value = true
}

async function addMemberToComp(nodeId: number) {
  if (!selectedComposition.value) return
  try {
    await compositionsApi.addMember(selectedComposition.value.id, nodeId)
    if (factoryStore.selectedNode) {
      await selectComposition(selectedComposition.value)
      await loadCompositions(factoryStore.selectedNode.id)
    } else {
      await selectGlobalComposition(selectedComposition.value)
      await loadAllCompositions()
    }
    showAddCompMember.value = false
  } catch (err: unknown) { toast.fromError(err, 'Error agregando miembro') }
}

async function removeCompMember(compId: number, nodeId: number) {
  if (!confirm('¿Quitar este componente de la composición?')) return
  try {
    await compositionsApi.removeMember(compId, nodeId)
    if (factoryStore.selectedNode) {
      await selectComposition(selectedComposition.value)
      await loadCompositions(factoryStore.selectedNode.id)
    } else {
      await selectGlobalComposition(selectedComposition.value)
      await loadAllCompositions()
    }
  } catch (err: unknown) { toast.fromError(err, 'Error quitando miembro') }
}

async function deleteComposition(compId: number) {
  if (!confirm('¿Eliminar esta composición? Los equipos no se borran.')) return
  try {
    await compositionsApi.delete(compId)
    selectedComposition.value = null
    if (factoryStore.selectedNode) await loadCompositions(factoryStore.selectedNode.id)
  } catch (err: unknown) { toast.fromError(err, 'Error eliminando composición') }
}

function navigateToNode(nodeId: number) {
  factoryStore.selectNode(nodeId)
}

// ─── Apply a composition template ──────────────────────────────────────
async function openApplyCompTemplate() {
  applyTemplateId.value = 0
  applyName.value = ''
  applyError.value = ''
  applying.value = false
  try {
    compTemplates.value = await compTemplatesApi.list()
  } catch { compTemplates.value = [] }
  showApplyCompTemplate.value = true
}

async function submitApplyTemplate() {
  if (!applyTemplateId.value || !factoryStore.selectedNode) return
  applying.value = true
  applyError.value = ''
  try {
    const result = await compTemplatesApi.apply(applyTemplateId.value, factoryStore.selectedNode.id, applyName.value || undefined)
    toast.error(result.message)
    showApplyCompTemplate.value = false
    await factoryStore.refreshTree()
  } catch (err: unknown) {
    applyError.value = apiErrorMsg(err, 'Error creando composición')
  } finally { applying.value = false }
}

// ─── Composition templates ──────────────────────────────────────────────
const showCreateCompTemplate = ref(false)
const compTmplForm = ref<{ name: string; description: string; slots: { role: string; equipment_template_id: number | null; sort_order: number }[] }>({
  name: '', description: '', slots: [{ role: '', equipment_template_id: null, sort_order: 0 }]
})
const compTmplFormError = ref('')

async function openCreateCompTemplate() {
  compTmplForm.value = { name: '', description: '', slots: [{ role: '', equipment_template_id: null, sort_order: 0 }] }
  compTmplFormError.value = ''
  try {
    const { data } = await client.get('/templates')
    equipmentTemplates.value = data ?? []
  } catch { /* empty */ }
  showCreateCompTemplate.value = true
}

async function submitCreateCompTemplate() {
  if (!compTmplForm.value.name.trim()) { compTmplFormError.value = 'El nombre es obligatorio'; return }
  const validSlots = compTmplForm.value.slots.filter(s => s.role.trim())
  if (!validSlots.length) { compTmplFormError.value = 'Se necesita al menos un slot con rol'; return }
  compTmplFormError.value = ''
  try {
    await compTemplatesApi.create({
      name: compTmplForm.value.name,
      description: compTmplForm.value.description || undefined,
      slots: validSlots.map((s, i) => ({ ...s, sort_order: i })),
    })
    showCreateCompTemplate.value = false
    compTemplates.value = await compTemplatesApi.list()
  } catch (err: unknown) { compTmplFormError.value = apiErrorMsg(err, 'Error creando plantilla') }
}

async function deleteCompTemplate(id: number) {
  if (!confirm('¿Eliminar esta plantilla de composición?')) return
  try {
    await compTemplatesApi.delete(id)
    compTemplates.value = await compTemplatesApi.list()
  } catch (err: unknown) { toast.fromError(err, 'Error eliminando plantilla') }
}

// Load composition templates when tab opens
async function loadCompTemplates() {
  try {
    compTemplates.value = await compTemplatesApi.list()
  } catch { compTemplates.value = [] }
}

// ─── Global compositions (panel with no node selected) ──────────────────
async function loadAllCompositions() {
  loadingAllComps.value = true
  try {
    compTemplates.value = await compTemplatesApi.list().catch(() => [])
  } catch { compTemplates.value = [] }
  loadingAllComps.value = false
}

// ─── Edit the composition ───────────────────────────────────────────────────
function openEditComposition() {
  if (!selectedComposition.value) return
  editCompForm.value = {
    id: selectedComposition.value.id,
    name: selectedComposition.value.name,
    description: selectedComposition.value.description ?? '',
  }
  editCompFormError.value = ''
  showEditComp.value = true
}

async function submitEditComposition() {
  if (!editCompForm.value.name.trim()) { editCompFormError.value = 'El nombre es obligatorio'; return }
  editCompFormError.value = ''
  try {
    await compositionsApi.update(editCompForm.value.id, {
      name: editCompForm.value.name,
      description: editCompForm.value.description || undefined,
    })
    showEditComp.value = false
    // Refresh the data
    selectedComposition.value.name = editCompForm.value.name
    selectedComposition.value.description = editCompForm.value.description || null
    if (factoryStore.selectedNode) {
      await loadCompositions(factoryStore.selectedNode.id)
    } else {
      await loadAllCompositions()
    }
  } catch (err: unknown) { editCompFormError.value = apiErrorMsg(err, 'Error actualizando composicion') }
}

// ─── Clone equipment ────────────────────────────────────────────────────────
async function openCloneEquipment() {
  cloneForm.value = { equipment_template_id: 0, count: 1, name_prefix: '', start_number: 1 }
  cloneFormError.value = ''
  cloning.value = false
  try {
    const { data } = await client.get('/templates')
    equipmentTemplates.value = data ?? []
  } catch { equipmentTemplates.value = [] }
  showCloneEquipment.value = true
}

async function submitCloneEquipment() {
  if (!cloneForm.value.equipment_template_id || !factoryStore.selectedNode) {
    cloneFormError.value = 'Selecciona una plantilla de equipo'; return
  }
  if (cloneForm.value.count < 1) { cloneFormError.value = 'Cantidad minima: 1'; return }
  cloning.value = true
  cloneFormError.value = ''
  try {
    const result = await cloneApi.cloneEquipment({
      equipment_template_id: cloneForm.value.equipment_template_id,
      parent_node_id: factoryStore.selectedNode.id,
      count: cloneForm.value.count,
      name_prefix: cloneForm.value.name_prefix || undefined,
      start_number: cloneForm.value.start_number,
    })
    toast.error(result.message)
    showCloneEquipment.value = false
    await factoryStore.refreshTree()
  } catch (err: unknown) {
    cloneFormError.value = apiErrorMsg(err, 'Error clonando equipos')
  } finally { cloning.value = false }
}

function getNodeName(nodeId: number): string {
  // Search in tree for node name
  const find = (nodes: any[]): string => {
    for (const n of nodes) {
      if (n.id === nodeId) return n.name
      if (n.children?.length) {
        const found = find(n.children)
        if (found) return found
      }
    }
    return ''
  }
  return find(factoryStore.tree) || `Nodo #${nodeId}`
}

// ─── Helpers ─────────────────────────────────────────────────────────────────
function nodeTypeLabel(type: string) { return NODE_TYPE_CONFIG[type]?.label ?? type }
function getCritColor(crit: string) { return CRITICALITY_CONFIG[crit]?.color ?? '#B0B8C4' }
function formatWorkedTime(mins: number | undefined) {
  if (!mins) return '—'
  return formatDurationMinutes(mins)
}
function formatFileSize(bytes: number) {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB'
}
function getFileIcon(mimeType: string) {
  if (mimeType?.startsWith('image/')) return '▣'
  if (mimeType === 'application/pdf') return '▤'
  if (mimeType?.includes('video')) return '▶'
  if (mimeType?.includes('spreadsheet') || mimeType?.includes('excel')) return '▦'
  if (mimeType?.includes('word')) return '≡'
  return '◻'
}

const critColor  = computed(() => getCritColor(factoryStore.selectedNode?.criticality ?? ''))
const critLabel  = computed(() => CRITICALITY_CONFIG[factoryStore.selectedNode?.criticality ?? '']?.label ?? '—')
const statusColor = computed(() => STATUS_CONFIG[factoryStore.selectedNode?.status ?? '']?.color ?? '#B0B8C4')
const statusLabel = computed(() => STATUS_CONFIG[factoryStore.selectedNode?.status ?? '']?.label ?? '—')
const nodeBreadcrumb = computed(() => {
  const depth = (factoryStore.selectedNode?.path ?? '').split('.').length
  return depth > 1 ? 'Nodo / Subnodo' : 'Raíz'
})

function clearSearch() { searchQ.value = ''; factoryStore.clearSearch() }
async function selectFromSearch(result: any) {
  clearSearch()
  try { const node = await nodesApi.getOne(result.id); factoryStore.selectedNode = node }
  catch { factoryStore.selectedNode = result }
}

onMounted(async () => {
  factoryStore.loadTree()
  loadAllCompositions()

  // QR: when ?scan=CODE arrives, find the node by code and select it
  const scanCode = route.query.scan as string
  if (scanCode) {
    try {
      const data = await nodesApi.search(scanCode)
      const match = (data.results ?? []).find((r: any) => r.code === scanCode || String(r.id) === scanCode)
      if (match) {
        try { const full = await nodesApi.getOne(match.id); factoryStore.selectedNode = full }
        catch { factoryStore.selectedNode = match }
      }
    } catch { /* silent */ }
    // Clear the query param without reloading
    router.replace({ query: {} })
  }

  // Load the current user's assignment depth (for the rank check)
  if (authStore.user && (authStore.isSupervisor || authStore.isAdmin)) {
    try {
      const { data } = await client.get(`/personnel/${authStore.user.id}/assignments`)
      const depths = (data.assignments ?? []).map((a: any) => {
        // We estimate depth from the node type: org=1, plant=2, area=3, line=4, equipment=5, component=6
        const depthMap: Record<string, number> = { organization: 1, plant: 2, area: 3, line: 4, composition: 5, equipment: 5, component: 6, measurement_point: 7 }
        return depthMap[a.node_type] ?? 99
      })
      myAssignmentDepth.value = depths.length ? Math.min(...depths) : 999
    } catch { /* silent */ }
  }
})
</script>

<style scoped>
.factory-layout { display: flex; height: calc(100vh - var(--header-height)); margin: calc(-1 * var(--space-6)); overflow: hidden; }

/* ─── Tree sidebar ─────────────────────────────────────────────────────── */
.factory-sidebar { width: 280px; flex-shrink: 0; background: var(--color-primary); display: flex; flex-direction: column; overflow: hidden; }
.sidebar-top { padding: var(--space-4); border-bottom: 1px solid rgba(255,255,255,0.08); display: flex; flex-direction: column; gap: var(--space-3); }
.sidebar-title-row { display: flex; align-items: center; justify-content: space-between; }
.sidebar-title { font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; color: rgba(255,255,255,0.4); }
.btn-icon { width: 24px; height: 24px; background: rgba(255,255,255,0.1); border: none; color: rgba(255,255,255,0.6); border-radius: var(--radius-sm); cursor: pointer; font-size: 1.1rem; display: flex; align-items: center; justify-content: center; }
.btn-icon:hover { background: rgba(255,255,255,0.2); color: #fff; }
.search-wrap { position: relative; }
.search-input { width: 100%; height: 32px; background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.1); border-radius: var(--radius); padding: 0 var(--space-3); color: rgba(255,255,255,0.8); font-size: 0.8rem; outline: none; }
.search-input::placeholder { color: rgba(255,255,255,0.3); }
.search-clear { position: absolute; right: 8px; top: 50%; transform: translateY(-50%); background: none; border: none; color: rgba(255,255,255,0.3); cursor: pointer; font-size: 0.75rem; }
.sidebar-loading { padding: var(--space-6); text-align: center; }
.loading-text { font-size: 0.75rem; color: rgba(255,255,255,0.3); }
.empty-tree { padding: var(--space-6); text-align: center; }
.empty-tree p { font-size: 0.8rem; color: rgba(255,255,255,0.3); margin-bottom: var(--space-3); }
.btn-create-first { background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); color: rgba(255,255,255,0.7); border-radius: var(--radius); padding: var(--space-2) var(--space-4); font-size: 0.8rem; cursor: pointer; }
.tree-wrap { flex: 1; overflow-y: auto; padding: var(--space-2) 0; }
.search-results { flex: 1; overflow-y: auto; }
.empty-search { padding: var(--space-4); font-size: 0.78rem; color: rgba(255,255,255,0.3); text-align: center; }
.search-result-item { padding: var(--space-3) var(--space-4); cursor: pointer; display: flex; flex-direction: column; gap: 2px; border-bottom: 1px solid rgba(255,255,255,0.04); }
.search-result-item:hover { background: rgba(255,255,255,0.06); }
.search-result-item--active { background: rgba(255,255,255,0.1); }
.sr-name { font-size: 0.8rem; color: rgba(255,255,255,0.8); }
.sr-type { font-size: 0.7rem; color: rgba(255,255,255,0.35); }

/* ─── Main panel ────────────────────────────────────────────────────── */
.factory-main { flex: 1; overflow-y: auto; background: var(--color-bg); }
.empty-state { display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; text-align: center; padding: var(--space-12); }
.empty-state-icon { font-size: 3rem; color: var(--color-border); margin-bottom: var(--space-4); }
.empty-state-title { font-size: 1.1rem; font-weight: 600; color: var(--color-text-muted); margin-bottom: var(--space-2); }
.empty-state-sub { font-size: 0.875rem; color: var(--color-text-light); max-width: 380px; line-height: 1.7; }

/* ─── Factory Home (no node selected) ─────────────────────────────── */
.factory-home { padding: var(--space-6); overflow-y: auto; height: 100%; }
.factory-home-header { margin-bottom: var(--space-6); }
.factory-home-title { font-size: 1.25rem; font-weight: 700; color: var(--color-text); margin: 0 0 var(--space-1) 0; }
.factory-home-sub { font-size: 0.875rem; color: var(--color-text-muted); margin: 0; }
.factory-home-section { margin-bottom: var(--space-6); background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius); padding: var(--space-4); }

.node-detail { display: flex; flex-direction: column; min-height: 100%; }

/* Header */
.node-header { display: flex; align-items: flex-start; justify-content: space-between; padding: var(--space-6) var(--space-6) var(--space-4); background: var(--color-surface); border-bottom: 1px solid var(--color-border-light); gap: var(--space-4); }
.node-breadcrumb { font-size: 0.7rem; color: var(--color-text-light); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: var(--space-1); }
.node-name { font-size: 1.25rem; font-weight: 700; color: var(--color-primary); margin-bottom: var(--space-2); }
.node-meta { display: flex; align-items: center; gap: var(--space-2); flex-wrap: wrap; margin-bottom: var(--space-2); font-size: 0.8rem; }
.meta-badge { background: var(--color-surface-2); border: 1px solid var(--color-border-light); border-radius: var(--radius-sm); padding: 2px 8px; font-size: 0.75rem; color: var(--color-text-muted); }
.meta-sep { color: var(--color-border); }
.meta-type { color: var(--color-text-muted); }
.node-tags { display: flex; gap: var(--space-2); flex-wrap: wrap; }
.tag-pill { font-size: 0.7rem; font-weight: 500; padding: 2px 10px; border-radius: 20px; border: 1px solid; }
.node-header-actions { display: flex; gap: var(--space-2); flex-shrink: 0; flex-wrap: wrap; }
.btn-action { height: 34px; padding: 0 var(--space-4); background: var(--color-surface-2); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.8rem; font-weight: 500; cursor: pointer; color: var(--color-text); transition: background var(--transition); white-space: nowrap; }
.btn-action:hover { background: var(--color-border-light); }
.btn-action--child { background: var(--color-primary); border-color: var(--color-primary); color: #fff; }
.btn-action--child:hover { background: var(--color-accent); }
.btn-action--wo { background: #27AE60; border-color: #27AE60; color: #fff; }
.btn-action--wo:hover { background: #219A52; }
.btn-action--danger { background: none; border-color: var(--color-alert); color: var(--color-alert); }
.btn-action--danger:hover { background: var(--color-alert); color: #fff; }
.btn-action--upload { display: inline-flex; align-items: center; cursor: pointer; }
.btn-action--upload.disabled { opacity: 0.6; cursor: not-allowed; }
.file-input-hidden { display: none; }

/* Tabs */
.tabs { display: flex; background: var(--color-surface); border-bottom: 1px solid var(--color-border-light); padding: 0 var(--space-6); overflow-x: auto; flex-shrink: 0; }
.tab { height: 42px; padding: 0 var(--space-4); background: none; border: none; border-bottom: 2px solid transparent; font-size: 0.8rem; font-weight: 500; color: var(--color-text-muted); cursor: pointer; display: flex; align-items: center; gap: var(--space-2); white-space: nowrap; transition: color var(--transition), border-color var(--transition); }
.tab:hover:not(.tab--disabled) { color: var(--color-text); }
.tab--active { color: var(--color-primary); border-bottom-color: var(--color-primary); }
.tab--disabled { opacity: 0.4; cursor: not-allowed; }
.tab-count { background: var(--color-surface-2); border: 1px solid var(--color-border-light); border-radius: 10px; font-size: 0.65rem; padding: 1px 6px; color: var(--color-text-muted); }
.tab-phase { font-size: 0.6rem; background: var(--color-surface-2); padding: 1px 5px; border-radius: var(--radius-sm); color: var(--color-border); }

.tab-content { flex: 1; overflow: hidden; }
.tab-pane { padding: var(--space-6); }

/* Tabs with the directory panel */
.tab-pane--with-dirs {
  display: flex;
  height: 100%;
  padding: 0;
  overflow: hidden;
}

.tab-main-content {
  flex: 1;
  overflow-y: auto;
  padding: var(--space-5) var(--space-6);
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
}

/* Active folder filter */
.dir-filter-label {
  font-size: 0.75rem;
  color: var(--color-accent);
  font-weight: 500;
}

/* Summary */
.info-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: var(--space-4); margin-bottom: var(--space-6); }
.info-block { display: flex; flex-direction: column; gap: var(--space-1); }
.info-label { font-size: 0.68rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: var(--color-text-light); }
.info-description { display: flex; flex-direction: column; gap: var(--space-2); margin-bottom: var(--space-5); }
.description-text { font-size: 0.875rem; color: var(--color-text-muted); line-height: 1.7; background: var(--color-surface-2); border-radius: var(--radius); padding: var(--space-4); }
.info-timestamps { display: flex; gap: var(--space-5); }
.timestamp { font-size: 0.7rem; color: var(--color-text-light); }

/* Structure */
.children-list { display: flex; flex-direction: column; gap: var(--space-2); }
.child-item { display: flex; align-items: center; gap: var(--space-3); padding: var(--space-3) var(--space-4); background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius); cursor: pointer; transition: border-color var(--transition); }
.child-item:hover { border-color: var(--color-border); background: var(--color-surface-2); }
.child-crit { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
.child-info { flex: 1; display: flex; flex-direction: column; gap: 2px; }
.child-name { font-size: 0.875rem; font-weight: 500; }
.child-meta { font-size: 0.75rem; color: var(--color-text-muted); }
.child-arrow { color: var(--color-border); font-size: 1.1rem; }

/* Sections */
.section-header { display: flex; justify-content: space-between; align-items: center; }
.section-count { font-size: 0.8rem; color: var(--color-text-muted); }
.section-empty { font-size: 0.875rem; color: var(--color-text-light); padding: var(--space-6); text-align: center; background: var(--color-surface-2); border-radius: var(--radius-md); }
.loading-inline { font-size: 0.8rem; color: var(--color-text-muted); padding: var(--space-4); }

/* Smart filters */
.smart-filters { display: flex; gap: var(--space-2); flex-wrap: wrap; }
.smart-chip {
  height: 26px; padding: 0 var(--space-3);
  display: flex; align-items: center; gap: var(--space-1);
  background: var(--color-surface); border: 1px solid var(--color-border);
  border-radius: 20px; font-size: 0.72rem; font-weight: 500;
  color: var(--color-text-muted); cursor: pointer;
  transition: all var(--transition);
}
.smart-chip:hover { border-color: var(--color-accent); color: var(--color-accent); }
.smart-chip--active { background: var(--color-primary); border-color: var(--color-primary); color: #fff; }
.smart-chip-count {
  min-width: 14px; height: 14px; padding: 0 3px;
  background: rgba(0,0,0,0.12); border-radius: 7px;
  font-size: 0.6rem; font-weight: 700;
  display: flex; align-items: center; justify-content: center;
}
.smart-chip--active .smart-chip-count { background: rgba(255,255,255,0.25); }

/* Node KPI bar */
.node-kpi-bar { display: grid; grid-template-columns: repeat(6, 1fr); gap: var(--space-3); margin-bottom: var(--space-4); }
.node-kpi { background: var(--color-surface-2); border-radius: var(--radius); padding: var(--space-3) var(--space-4); display: flex; flex-direction: column; align-items: center; gap: 2px; }
.node-kpi-value { font-size: 1.2rem; font-weight: 700; font-family: var(--font-mono); color: var(--color-primary); }
.node-kpi-label { font-size: 0.66rem; color: var(--color-text-muted); text-align: center; }
.alert-val { color: var(--color-alert) !important; }
.node-kpi--health { position: relative; }
.health-bar-mini { display: block; width: 100%; height: 4px; background: var(--color-border-light); border-radius: 2px; margin-top: 4px; overflow: hidden; }
.health-bar-mini-fill { display: block; height: 100%; border-radius: 2px; transition: width 0.4s ease; }
.health-factors { margin-top: 6px; display: flex; flex-direction: column; gap: 2px; }
.health-factor-row { display: flex; justify-content: space-between; font-size: 0.65rem; }
.health-factor-name { color: var(--color-text-muted); }
.health-factor-val { color: var(--color-alert); font-family: var(--font-mono, monospace); }

/* Maintenance plans */
.maint-plan-list { display: flex; flex-direction: column; gap: var(--space-2); }
.maint-plan-card { display: flex; justify-content: space-between; align-items: center; padding: var(--space-3) var(--space-4); background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius); }
.maint-plan-info { display: flex; flex-direction: column; gap: 2px; min-width: 0; flex: 1; }
.maint-plan-title { font-size: 0.84rem; font-weight: 500; }
.maint-plan-meta { font-size: 0.72rem; }
.maint-plan-right { display: flex; align-items: center; gap: var(--space-3); flex-shrink: 0; }
.maint-plan-due { font-size: 0.75rem; }
.maint-plan-status { font-size: 0.68rem; font-weight: 600; padding: 2px 8px; border-radius: 20px; }
.maint-plan-status.active { color: var(--color-success); background: rgba(39,174,96,0.1); }
.maint-plan-status.inactive { color: var(--color-text-muted); background: var(--color-surface-2); }

/* Manuals */
.manual-hint { font-size: 0.72rem; color: var(--color-text-muted); margin-top: calc(-1 * var(--space-2)); }
.manuals-list { display: flex; flex-direction: column; gap: var(--space-2); }
.manual-card { display: flex; justify-content: space-between; align-items: center; padding: var(--space-3) var(--space-4); background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius); }
.manual-info { display: flex; flex-direction: column; gap: 2px; min-width: 0; flex: 1; }
.manual-title { font-size: 0.84rem; font-weight: 500; }
.manual-meta { font-size: 0.72rem; }
.manual-actions { display: flex; gap: var(--space-1); flex-shrink: 0; }
.small-modal { background: var(--color-surface); border-radius: var(--radius-lg); width: 100%; max-width: 480px; max-height: 90vh; display: flex; flex-direction: column; box-shadow: var(--shadow-lg); }

/* WOs */
.wo-list { display: flex; flex-direction: column; gap: var(--space-2); }
.wo-card { display: flex; align-items: center; justify-content: space-between; gap: var(--space-4); padding: var(--space-3) var(--space-4); background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius); }
.wo-card-left { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
.wo-number { font-size: 0.72rem; color: var(--color-text-muted); }
.wo-title { font-size: 0.875rem; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.wo-meta { font-size: 0.75rem; }
.wo-card-right { display: flex; align-items: center; gap: var(--space-2); flex-shrink: 0; }
.priority-pill, .status-pill { font-size: 0.7rem; font-weight: 600; padding: 2px 8px; border-radius: 20px; white-space: nowrap; }

/* Spare parts */
.parts-list { display: flex; flex-direction: column; gap: var(--space-2); }
.part-card { display: flex; align-items: center; justify-content: space-between; padding: var(--space-3) var(--space-4); background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius); }
.part-info { display: flex; flex-direction: column; gap: 2px; }
.part-code { font-size: 0.72rem; color: var(--color-text-muted); }
.part-name { font-size: 0.875rem; font-weight: 500; }
.part-cat { font-size: 0.75rem; }
.part-stock-row { display: flex; align-items: center; gap: var(--space-2); }
.stock-value { font-size: 0.875rem; }
.stock-low { color: var(--color-alert); font-weight: 600; }
.low-badge { font-size: 0.65rem; font-weight: 700; color: var(--color-alert); background: rgba(233,69,96,0.1); padding: 1px 5px; border-radius: 3px; }

/* Personnel */
.personnel-list { display: flex; flex-direction: column; gap: var(--space-2); }
.person-card { display: flex; align-items: center; gap: var(--space-3); padding: var(--space-3) var(--space-4); background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius); }
.person-avatar { width: 32px; height: 32px; border-radius: 50%; background: var(--color-accent); color: #fff; font-size: 0.8rem; font-weight: 700; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.person-info { flex: 1; display: flex; flex-direction: column; gap: 2px; }
.person-name { font-size: 0.875rem; font-weight: 500; }
.person-role { font-size: 0.75rem; }
.person-meta { display: flex; align-items: center; gap: var(--space-2); }
.badge-primary { font-size: 0.65rem; font-weight: 700; background: rgba(15,52,96,0.1); color: var(--color-accent); padding: 1px 6px; border-radius: 3px; }
.wo-count { font-size: 0.72rem; color: var(--color-text-muted); }
.wo-count--busy { color: var(--color-alert); font-weight: 600; }
.person-card--inherited { border-left: 3px solid rgba(15,52,96,0.25); background: var(--color-surface-2); }
.badge-inherited { font-size: 0.62rem; color: var(--color-text-muted); background: rgba(15,52,96,0.06); border: 1px solid var(--color-border-light); padding: 1px 6px; border-radius: 3px; }
.badge-rank { font-size: 0.6rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.3px; padding: 1px 5px; border-radius: 3px; }
.rank-high { background: rgba(39,174,96,0.1); color: #27AE60; }
.rank-mid { background: rgba(243,156,18,0.1); color: #F39C12; }
.rank-low { background: rgba(176,184,196,0.1); color: var(--color-text-muted); }
.btn-exclude { height: 24px; padding: 0 var(--space-2); font-size: 0.65rem; font-weight: 600; background: rgba(233,69,96,0.08); color: var(--color-alert); border: 1px solid rgba(233,69,96,0.2); border-radius: var(--radius-sm); cursor: pointer; white-space: nowrap; }
.btn-exclude:hover { background: rgba(233,69,96,0.15); }
.excluded-section { margin-top: var(--space-3); padding-top: var(--space-3); border-top: 1px dashed var(--color-border-light); }
.excluded-toggle { background: none; border: none; cursor: pointer; font-size: 0.72rem; color: var(--color-text-muted); padding: var(--space-1) 0; }
.excluded-toggle:hover { color: var(--color-text); }
.excluded-list { display: flex; flex-direction: column; gap: var(--space-2); margin-top: var(--space-2); }
.excluded-card { display: flex; align-items: center; gap: var(--space-3); padding: var(--space-2) var(--space-3); background: rgba(233,69,96,0.04); border: 1px dashed rgba(233,69,96,0.2); border-radius: var(--radius); }
.btn-restore { height: 24px; padding: 0 var(--space-2); font-size: 0.65rem; font-weight: 600; background: rgba(39,174,96,0.08); color: var(--color-success); border: 1px solid rgba(39,174,96,0.2); border-radius: var(--radius-sm); cursor: pointer; margin-left: auto; }
.btn-restore:hover { background: rgba(39,174,96,0.15); }

/* Library */
.library-list { display: flex; flex-direction: column; gap: var(--space-2); }
.lib-card { display: flex; align-items: center; gap: var(--space-3); padding: var(--space-3) var(--space-4); background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius); }
.lib-icon { font-size: 1.25rem; flex-shrink: 0; }
.lib-info { flex: 1; display: flex; flex-direction: column; gap: 2px; }
.lib-name { font-size: 0.875rem; font-weight: 500; }
.lib-meta { font-size: 0.72rem; }
.lib-actions { display: flex; align-items: center; gap: var(--space-2); }
.btn-delete { background: none; border: none; color: var(--color-text-light); cursor: pointer; font-size: 0.875rem; padding: var(--space-1); border-radius: var(--radius-sm); }
.btn-delete:hover { color: var(--color-alert); background: rgba(233,69,96,0.08); }

/* Template library shared section */
.template-lib-section { margin-top: var(--space-4); padding-top: var(--space-4); border-top: 1px dashed var(--color-border-light); }
.section-header--shared { color: var(--color-accent); }
.tpl-name-label { font-weight: 600; color: var(--color-accent); margin-left: var(--space-1); }
.lib-card--shared { background: rgba(15,52,96,0.03); border: 1px dashed rgba(15,52,96,0.15); }
.badge-shared { font-size: 0.6rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.3px; padding: 2px 6px; border-radius: 3px; background: rgba(15,52,96,0.08); color: var(--color-accent); white-space: nowrap; }
.tpl-breadcrumb { display: flex; align-items: center; gap: 0.35rem; font-size: 0.78rem; padding: 0.35rem 0; color: var(--color-text-light); }
.tpl-breadcrumb .btn-link { background: none; border: none; color: var(--color-accent); cursor: pointer; padding: 0; font-size: 0.78rem; text-decoration: underline; }
.tpl-breadcrumb .breadcrumb-sep { color: var(--color-text-light); opacity: 0.5; }
.lib-card--folder { cursor: pointer; }
.lib-card--folder:hover { background: rgba(15,52,96,0.08); }

/* Placeholder */
.tab-pane--placeholder { display: flex; align-items: center; justify-content: center; min-height: 200px; }
.placeholder-msg { text-align: center; color: var(--color-text-light); }
.placeholder-icon { font-size: 2rem; display: block; margin-bottom: var(--space-3); }

/* Modal */
.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; padding: var(--space-4); }
.create-modal { background: var(--color-surface); border-radius: var(--radius-lg); width: 100%; max-width: 520px; box-shadow: var(--shadow-lg); }
.modal-header { display: flex; justify-content: space-between; align-items: center; padding: var(--space-5) var(--space-6); border-bottom: 1px solid var(--color-border-light); }
.modal-header h3 { font-size: 1rem; font-weight: 600; color: var(--color-primary); }
.modal-close { background: none; border: none; font-size: 1rem; cursor: pointer; color: var(--color-text-muted); }
.modal-body { padding: var(--space-5) var(--space-6); display: flex; flex-direction: column; gap: var(--space-4); }
.modal-footer { display: flex; justify-content: flex-end; gap: var(--space-3); padding: var(--space-4) var(--space-6); border-top: 1px solid var(--color-border-light); }
.modal-error { background: rgba(233,69,96,0.08); border: 1px solid rgba(233,69,96,0.3); border-radius: var(--radius); padding: var(--space-3); font-size: 0.875rem; color: var(--color-alert); }
.field { display: flex; flex-direction: column; gap: var(--space-1); }
.field-row { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-3); }
.field-label { font-size: 0.68rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); }
.field-input { height: 38px; padding: 0 var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; background: var(--color-surface); outline: none; width: 100%; }
.field-input:focus { border-color: var(--color-accent); }
textarea.field-input { height: auto; padding: var(--space-2) var(--space-3); resize: vertical; font-family: var(--font-ui); }
.btn-primary { height: 38px; padding: 0 var(--space-5); background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); font-size: 0.875rem; font-weight: 500; cursor: pointer; }
.btn-primary:hover:not(:disabled) { background: var(--color-accent); }
.btn-primary:disabled { opacity: 0.65; cursor: not-allowed; }
.btn-secondary { height: 38px; padding: 0 var(--space-5); background: var(--color-surface-2); color: var(--color-text); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; cursor: pointer; }
.mono { font-family: var(--font-mono); }
.small { font-size: 0.75rem; }
.text-muted { color: var(--color-text-muted); }

/* Detach/unassign button */
.btn-unlink { background: none; border: none; color: var(--color-text-light); cursor: pointer; font-size: 0.8rem; padding: 2px 6px; border-radius: var(--radius-sm); transition: all var(--transition); }
.btn-unlink:hover { color: var(--color-alert); background: rgba(233,69,96,0.08); }

/* Attach/assign modal - result list */
.link-results { display: flex; flex-direction: column; gap: var(--space-1); max-height: 300px; overflow-y: auto; }
.link-item { display: flex; align-items: center; justify-content: space-between; padding: var(--space-3) var(--space-4); border: 1px solid var(--color-border-light); border-radius: var(--radius); cursor: pointer; transition: all var(--transition); }
.link-item:hover { border-color: var(--color-accent); background: rgba(15,52,96,0.04); }
.link-item-info { display: flex; flex-direction: column; gap: 2px; }
.link-item-action { font-size: 0.75rem; font-weight: 600; color: var(--color-accent); white-space: nowrap; }
.hint-text { font-size: 0.8rem; padding: var(--space-4); background: transparent; border: none; }

/* Clickable WO cards */
.wo-card--clickable { cursor: pointer; transition: border-color var(--transition); }
.wo-card--clickable:hover { border-color: var(--color-accent); }

/* WO detail modal */
.wo-detail-modal { background: var(--color-surface); border-radius: var(--radius-lg); width: 100%; max-width: 680px; max-height: 90vh; display: flex; flex-direction: column; box-shadow: var(--shadow-lg); }
.wo-detail-meta { display: flex; align-items: center; gap: var(--space-2); margin-top: var(--space-2); font-size: 0.82rem; }
.wo-detail-actions { display: flex; flex-wrap: wrap; gap: var(--space-2); padding: var(--space-3) var(--space-6); border-bottom: 1px solid var(--color-border-light); }
.wo-detail-tabs { display: flex; gap: 0; padding: 0 var(--space-6); border-bottom: 1px solid var(--color-border-light); }
.detail-tab { height: 38px; padding: 0 var(--space-4); background: none; border: none; border-bottom: 2px solid transparent; font-size: 0.8rem; font-weight: 500; color: var(--color-text-muted); cursor: pointer; }
.detail-tab--active { color: var(--color-primary); border-bottom-color: var(--color-primary); }
.wo-detail-body { flex: 1; overflow-y: auto; padding: var(--space-5) var(--space-6); }
.wo-desc-block { margin-top: var(--space-4); }
.wo-desc-block p { font-size: 0.875rem; color: var(--color-text-muted); line-height: 1.6; margin-top: var(--space-1); background: var(--color-surface-2); padding: var(--space-3); border-radius: var(--radius); }
.btn-transition { height: 30px; padding: 0 var(--space-3); background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); font-size: 0.75rem; font-weight: 500; cursor: pointer; }
.btn-transition:hover { background: var(--color-accent); }
.btn-pdf, .btn-score, .btn-suggest { height: 30px; padding: 0 var(--space-3); border: 1px solid var(--color-border); background: var(--color-surface); color: var(--color-text); border-radius: var(--radius); font-size: 0.75rem; cursor: pointer; }
.btn-pdf:hover, .btn-score:hover, .btn-suggest:hover { background: var(--color-surface-2); }
.signed-badge { font-size: 0.75rem; color: var(--color-success, #27AE60); font-weight: 500; }
.btn-suggest:disabled { opacity: 0.6; cursor: not-allowed; }
.assign-actions { display: inline-flex; gap: 4px; margin-left: 4px; }
.tech-suggestions { grid-column: 1 / -1; display: flex; flex-direction: column; gap: var(--space-2); background: var(--color-surface-2); padding: var(--space-3); border-radius: var(--radius); }
.tech-sug-row { display: flex; align-items: center; gap: var(--space-3); font-size: 0.82rem; }
.tech-sug-name { font-weight: 500; }
.tech-sug-score { color: #F39C12; font-weight: 600; }
.signatures-info { display: flex; flex-direction: column; gap: var(--space-2); margin-top: var(--space-2); }
.sig-row { display: flex; align-items: center; gap: var(--space-3); font-size: 0.82rem; padding: 6px 8px; border-radius: var(--radius); }
.sig-row--ok { background: rgba(39, 174, 96, 0.08); }
.sig-row--pending { background: var(--color-surface-2); color: var(--color-text-muted); }
.sig-icon { font-size: 1rem; flex-shrink: 0; }
.sig-row--ok .sig-icon { color: var(--color-success, #27AE60); }
.sig-detail { display: flex; flex-direction: column; flex: 1; }
.sig-name { font-weight: 500; }
.sig-role { font-size: 0.72rem; color: var(--color-text-muted); }
.sig-pending { font-size: 0.78rem; font-style: italic; }
.star-selector { display: flex; gap: var(--space-1); }
.star-btn { background: none; border: none; font-size: 1.5rem; cursor: pointer; color: var(--color-border); padding: 0; line-height: 1; }
.star-btn--active { color: #F39C12; }

/* WO log */
.wo-log-list { display: flex; flex-direction: column; gap: var(--space-3); }
.wo-log-entry { display: flex; gap: var(--space-3); }
.wo-log-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--color-border); margin-top: 6px; flex-shrink: 0; }
.wo-log-transition { font-size: 0.82rem; margin-bottom: 2px; }

/* WO comments */
.wo-comments-list { display: flex; flex-direction: column; gap: var(--space-3); margin-bottom: var(--space-4); }
.wo-comment-item { display: flex; gap: var(--space-3); }
.wo-comment-form { display: flex; gap: var(--space-2); align-items: flex-start; }
.wo-comment-form textarea { flex: 1; }
.wo-comment-form .btn-primary { height: 38px; flex-shrink: 0; }

.tab-pane--ai { padding: var(--space-6); }
.ai-node-chat { display: flex; flex-direction: column; gap: var(--space-5); }
.ai-node-header { display: flex; align-items: center; gap: var(--space-4); padding: var(--space-5); background: rgba(15,52,96,0.05); border: 1px solid rgba(15,52,96,0.15); border-radius: var(--radius-md); }
.ai-node-icon { font-size: 1.8rem; flex-shrink: 0; }
.ai-node-title { font-size: 1rem; font-weight: 600; color: var(--color-primary); margin-bottom: 4px; }
.ai-node-sub { font-size: 0.8rem; color: var(--color-text-muted); }
.btn-open-chat { margin-left: auto; height: 38px; padding: 0 var(--space-5); background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); font-size: 0.875rem; font-weight: 500; cursor: pointer; flex-shrink: 0; }
.btn-open-chat:hover { background: var(--color-accent); }
.ai-node-suggestions { display: flex; flex-wrap: wrap; gap: var(--space-3); }
.suggestion-chip { height: 36px; padding: 0 var(--space-4); background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.8rem; color: var(--color-text-muted); cursor: pointer; transition: all var(--transition); }
.suggestion-chip:hover { border-color: var(--color-accent); color: var(--color-accent); background: rgba(15,52,96,0.04); }

/* Effective maintenance plan groups */
.maint-group { margin-bottom: 16px; }
.maint-group-title {
  font-size: 0.82rem;
  font-weight: 600;
  color: var(--color-text-secondary, var(--color-text-muted));
  margin-bottom: 8px;
  padding-bottom: 4px;
  border-bottom: 1px solid var(--color-border);
}
.maint-plan-card--excluded {
  opacity: 0.5;
  text-decoration: line-through;
}
.btn-toggle-exclude {
  background: none;
  border: 1px solid var(--color-border);
  border-radius: 4px;
  padding: 4px 10px;
  font-size: 0.78rem;
  cursor: pointer;
  color: var(--color-text-muted);
}
.btn-toggle-exclude:hover { border-color: var(--color-accent); }

/* Clickable KPI cards */
.node-kpi--clickable {
  cursor: pointer;
  transition: transform var(--transition), box-shadow var(--transition);
}
.node-kpi--clickable:hover {
  transform: translateY(-1px);
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

/* Plan card badges */
.maint-plan-badges {
  display: flex;
  gap: var(--space-1);
  margin-top: 2px;
}
.maint-badge {
  font-size: 0.62rem;
  font-weight: 600;
  padding: 1px 5px;
  border-radius: 3px;
  background: var(--color-surface-2);
  border: 1px solid var(--color-border-light);
  color: var(--color-text-muted);
  white-space: nowrap;
}

/* Plan creation modal */
.plan-create-modal {
  background: var(--color-surface);
  border-radius: var(--radius-lg);
  width: 100%;
  max-width: 640px;
  max-height: 90vh;
  display: flex;
  flex-direction: column;
  box-shadow: var(--shadow-lg);
}
.plan-create-body {
  flex: 1;
  overflow-y: auto;
  padding: var(--space-4) var(--space-6);
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
}
.plan-section {
  border: 1px solid var(--color-border-light);
  border-radius: var(--radius);
  overflow: hidden;
}
.plan-section-title {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-3) var(--space-4);
  font-size: 0.82rem;
  font-weight: 600;
  color: var(--color-text);
  cursor: pointer;
  background: var(--color-surface-2);
  user-select: none;
}
.plan-section-title:hover { background: var(--color-border-light); }
.plan-section-count {
  margin-left: auto;
  font-size: 0.68rem;
  font-weight: 700;
  background: var(--color-primary);
  color: #fff;
  padding: 0 5px;
  border-radius: 8px;
  min-width: 16px;
  text-align: center;
}
.plan-section-body {
  padding: var(--space-4);
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
}
.plan-freq-input { display: flex; gap: var(--space-2); }
.plan-freq-num { width: 80px; flex-shrink: 0; }
.plan-freq-type { flex: 1; }
.plan-checklist-row {
  display: flex;
  align-items: center;
  gap: var(--space-2);
}
.plan-checklist-input { flex: 1; }
.plan-checklist-req {
  display: flex;
  align-items: center;
  gap: 3px;
  font-size: 0.68rem;
  color: var(--color-text-muted);
  white-space: nowrap;
  cursor: pointer;
}
.plan-checklist-del {
  background: none;
  border: none;
  color: var(--color-text-light);
  cursor: pointer;
  font-size: 0.8rem;
  padding: 2px 4px;
  border-radius: var(--radius-sm);
}
.plan-checklist-del:hover { color: var(--color-alert); }
.btn-add-checklist {
  background: none;
  border: 1px dashed var(--color-border);
  border-radius: var(--radius);
  padding: var(--space-2) var(--space-3);
  font-size: 0.78rem;
  color: var(--color-text-muted);
  cursor: pointer;
  text-align: center;
}
.btn-add-checklist:hover { border-color: var(--color-accent); color: var(--color-accent); }
.field-toggle { flex-direction: row; align-items: center; gap: var(--space-3); }
.toggle-label { display: flex; align-items: center; gap: var(--space-2); cursor: pointer; font-size: 0.82rem; }
.toggle-text { font-weight: 500; }
.field-hint { font-size: 0.68rem; color: var(--color-text-light); margin-top: 2px; }
.plan-success-msg {
  background: rgba(39,174,96,0.08);
  border: 1px solid rgba(39,174,96,0.3);
  border-radius: var(--radius);
  padding: var(--space-3);
  font-size: 0.875rem;
  color: var(--color-success, #27AE60);
}

/* ─── Mobile back button ──────────────────────────────────────────────────── */
.mobile-back-btn {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  width: 100%;
  padding: var(--space-3) var(--space-4);
  background: var(--color-surface-2);
  border: none;
  border-bottom: 1px solid var(--color-border-light);
  font-size: 0.875rem;
  font-weight: 600;
  color: var(--color-accent);
  cursor: pointer;
}
.mobile-back-btn:active { background: var(--color-border-light); }

/* ─── Compositions ──────────────────────────────────────────────────────── */
.comp-list { display: flex; flex-direction: column; gap: var(--space-2); }
.comp-card { padding: var(--space-3); border: 1px solid var(--color-border-light); border-radius: var(--radius); cursor: pointer; transition: border-color 0.15s; }
.comp-card:hover { border-color: var(--color-accent); }
.comp-card--active { border-color: var(--color-accent); background: rgba(15, 52, 96, 0.04); }
.comp-card--child { opacity: 0.7; cursor: default; }
.comp-card-header { display: flex; justify-content: space-between; align-items: center; }
.comp-card-name { font-weight: 600; font-size: 0.85rem; }
.comp-card-count { font-size: 0.75rem; color: var(--color-text-muted); }
.comp-card-members { display: flex; flex-wrap: wrap; gap: var(--space-1); margin-top: var(--space-2); }
.comp-member-chip { font-size: 0.75rem; padding: 2px 8px; background: var(--color-surface-2); border-radius: 12px; white-space: nowrap; }
.comp-member-chip--current { background: rgba(15, 52, 96, 0.12); font-weight: 600; }
.comp-member-role { color: var(--color-text-muted); margin-right: 2px; }
.comp-detail { margin-top: var(--space-4); padding: var(--space-4); border: 1px solid var(--color-border); border-radius: var(--radius-md); }
.comp-detail-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--space-3); }
.comp-detail-header h4 { margin: 0; font-size: 0.9rem; }
.comp-detail-actions { display: flex; gap: var(--space-2); }
.comp-detail-desc { margin-bottom: var(--space-3); font-size: 0.82rem; }
.comp-member-table { width: 100%; border-collapse: collapse; font-size: 0.82rem; }
.comp-member-table th { text-align: left; padding: var(--space-2); border-bottom: 2px solid var(--color-border); font-size: 0.75rem; color: var(--color-text-muted); text-transform: uppercase; }
.comp-member-table td { padding: var(--space-2); border-bottom: 1px solid var(--color-border-light); }
.comp-row--current { background: rgba(15, 52, 96, 0.06); }
.comp-row--empty { background: var(--color-surface-2); }
.comp-row--empty td { color: var(--color-text-muted); }
.slot-role { font-weight: 500; }
.slot-pending { font-size: 0.75rem; font-style: italic; color: var(--color-text-light); }
.comp-member-name { cursor: pointer; color: var(--color-accent); }
.comp-member-name:hover { text-decoration: underline; }
.comp-children-section { margin-top: var(--space-5); padding-top: var(--space-4); border-top: 1px solid var(--color-border); }
.comp-clone-section { margin-top: var(--space-5); padding-top: var(--space-4); border-top: 1px solid var(--color-border); }

/* Composition form */
.comp-form-nodes { display: flex; flex-direction: column; gap: var(--space-2); margin-bottom: var(--space-2); }
.comp-form-node-row { display: flex; align-items: center; gap: var(--space-2); }
.comp-form-node-name { flex: 1; font-size: 0.85rem; font-weight: 500; }
.comp-role-input { width: 140px !important; font-size: 0.82rem; }
.comp-search-row { margin-top: var(--space-2); }
.comp-search-results { max-height: 200px; overflow-y: auto; border: 1px solid var(--color-border-light); border-radius: var(--radius); }
.badge-status { font-size: 0.72rem; padding: 1px 6px; border-radius: 8px; font-weight: 500; }
.badge-status--active { background: rgba(39, 174, 96, 0.1); color: #27AE60; }
.badge-status--inactive { background: rgba(149, 165, 166, 0.1); color: #95A5A6; }
.btn-action--primary { background: var(--color-accent); color: white; border-color: var(--color-accent); }
.btn-action--primary:hover { opacity: 0.9; }
.btn-action--small { height: 26px; font-size: 0.72rem; padding: 0 8px; }
.section-actions { display: flex; gap: var(--space-2); align-items: center; }
.comp-tools-grid { display: flex; flex-wrap: wrap; gap: var(--space-2); margin-bottom: var(--space-3); }
.comp-templates-list { margin-top: var(--space-3); }
.comp-templates-title { font-size: 0.8rem; font-weight: 600; color: var(--color-text-muted); margin-bottom: var(--space-2); }
.comp-template-card { display: flex; align-items: center; gap: var(--space-3); padding: var(--space-2) var(--space-3); border: 1px solid var(--color-border-light); border-radius: var(--radius); margin-bottom: var(--space-1); }
.comp-template-name { font-size: 0.82rem; font-weight: 500; flex: 1; }
.comp-template-meta { flex-shrink: 0; }

/* ─── Responsive: tablet 768px ────────────────────────────────────────────── */
@media (max-width: 768px) {
  .factory-layout {
    flex-direction: column;
    height: auto;
    min-height: calc(100vh - var(--header-height));
    overflow: visible;
    margin: calc(-1 * var(--space-4)) calc(-1 * var(--space-3));
  }

  /* By default show sidebar (tree) */
  .factory-sidebar {
    width: 100% !important;
    height: auto;
    max-height: calc(100vh - var(--header-height));
    overflow-y: auto;
    flex-shrink: 0;
  }

  .factory-main { display: none; }

  /* When a node is selected: hide tree, show detail */
  .factory-layout--mobile-detail .factory-sidebar { display: none; }
  .factory-layout--mobile-detail .factory-main { display: block; }

  /* Mobile back button */
  .mobile-back-btn { min-height: 44px; font-size: 0.9rem; }

  /* Node header */
  .node-header { flex-direction: column; padding: var(--space-4); gap: var(--space-3); }
  .node-name { font-size: 1.05rem; }
  .node-header-actions { width: 100%; overflow-x: auto; flex-wrap: nowrap; gap: var(--space-2); }
  .btn-action { height: 40px; font-size: 0.78rem; flex-shrink: 0; }

  /* Tabs horizontal scroll */
  .tabs { padding: 0 var(--space-3); -webkit-overflow-scrolling: touch; }
  .tab { height: 44px; font-size: 0.82rem; padding: 0 var(--space-3); flex-shrink: 0; }

  /* Tab content */
  .tab-pane { padding: var(--space-4); }
  .tab-main-content { padding: var(--space-4); }
  .tab-pane--with-dirs { flex-direction: column; }

  /* Info grid */
  .info-grid { grid-template-columns: 1fr 1fr; gap: var(--space-3); }
  .info-label { font-size: 0.72rem; }
  .info-timestamps { flex-direction: column; gap: var(--space-2); }

  /* KPI cards grid */
  .node-kpi-bar { grid-template-columns: repeat(3, 1fr); }

  /* Modals full-screen */
  .modal-overlay { padding: 0; }
  .create-modal, .plan-create-modal {
    max-width: 100%; border-radius: 0;
    max-height: 100vh; max-height: 100dvh;
  }
  .modal-body { padding: var(--space-4); }
  .field-row { grid-template-columns: 1fr; }
  .field-input { height: 42px; }

  /* WO detail modal from factory */
  .wo-detail-modal { max-width: 100%; border-radius: 0; max-height: 100vh; max-height: 100dvh; }
  .wo-detail-body { padding: var(--space-4); }

  /* Search input */
  .search-input { height: 40px; font-size: 0.875rem; }

  /* Children list */
  .child-item { padding: var(--space-3); }
  .child-name { font-size: 0.9rem; }

  /* Personnel / Library cards */
  .person-card, .lib-card { padding: var(--space-3); }
  .comp-member-table { font-size: 0.78rem; }
}

@media (max-width: 480px) {
  .info-grid { grid-template-columns: 1fr; }
  .node-kpis-grid { grid-template-columns: 1fr; }
  .node-header-actions { flex-wrap: wrap; }
  .node-meta { font-size: 0.75rem; }
}

</style>
