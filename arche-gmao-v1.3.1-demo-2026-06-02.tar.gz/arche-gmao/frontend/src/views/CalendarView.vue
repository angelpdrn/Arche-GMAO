<template>
  <div class="cal-layout">
    <div class="page-header">
      <div>
        <h1 class="page-title">Calendario Personal</h1>
        <p class="page-sub">Tus OTs asignadas, mantenimientos y recordatorios</p>
      </div>
      <div class="header-actions">
        <div class="view-toggle">
          <button class="view-toggle-btn" :class="{ 'view-toggle-btn--active': viewMode === 'month' }" @click="viewMode = 'month'">Mes</button>
          <button class="view-toggle-btn" :class="{ 'view-toggle-btn--active': viewMode === 'agenda' }" @click="viewMode = 'agenda'">Agenda</button>
        </div>
        <button class="btn-primary" @click="openCreate" :disabled="!canWrite">+ Nuevo evento</button>
      </div>
    </div>

    <!-- Highlighted upcoming events -->
    <div v-if="upcomingEvents.length" class="upcoming-strip">
      <span class="upcoming-label">Próximos:</span>
      <div v-for="ev in upcomingEvents" :key="ev.id" class="upcoming-pill"
        :style="{ background: (ev.color || '#0F3460') + '20', borderColor: (ev.color || '#0F3460') + '60', color: ev.color || '#0F3460' }">
        <span class="up-date">{{ formatShort(ev.start_at) }}</span>
        <span class="up-title">{{ ev.title }}</span>
        <span v-if="ev.wo_number" class="up-wo mono">{{ ev.wo_number }}</span>
      </div>
    </div>

    <!-- Month navigation (shared by both views) -->
    <div class="cal-nav-bar">
      <div class="cal-nav">
        <button class="nav-btn" @click="prevMonth">&#8249;</button>
        <h2 class="cal-month-title">{{ monthTitle }}</h2>
        <button class="nav-btn" @click="nextMonth">&#8250;</button>
        <button class="nav-btn-today" @click="goToday">Hoy</button>
      </div>
    </div>

    <!-- Month view (grid) -->
    <template v-if="viewMode === 'month'">
      <div class="cal-wrapper">
        <!-- Weekday header -->
        <div class="cal-weekdays">
          <div v-for="day in weekdays" :key="day" class="cal-weekday">{{ day }}</div>
        </div>

        <!-- Day grid -->
        <div class="cal-grid">
          <div v-for="(cell, idx) in calendarCells" :key="idx"
            class="cal-cell"
            :class="{
              'cal-cell--other': !cell.currentMonth,
              'cal-cell--today': cell.isToday,
            }">
            <div class="cell-number">{{ cell.day }}</div>
            <div class="cell-events">
              <div v-for="ev in cell.events" :key="ev.id"
                class="cell-event"
                :style="{ background: (ev.color || eventTypeColor(ev.event_type)) + '30', borderLeft: `3px solid ${ev.color || eventTypeColor(ev.event_type)}`, color: ev.color || eventTypeColor(ev.event_type) }"
                :title="ev.title"
                @click="openDetail(ev)">
                <span class="event-title">{{ ev.title }}</span>
              </div>
              <div v-if="cell.moreCount > 0" class="cell-more">+{{ cell.moreCount }} más</div>
            </div>
          </div>
        </div>
      </div>

      <!-- List of the month's events -->
      <div class="card">
        <div class="card-header">
          <span class="card-title">Eventos de {{ monthTitle }}</span>
        </div>
        <EmptyState
          v-if="!monthEvents.length"
          icon="◷"
          title="Sin eventos este mes"
          hint="Los preventivos vencidos aparecen aquí automáticamente."
          :action="canWrite ? '+ Añadir evento' : undefined"
          size="sm"
          @action="openCreate" />
        <div v-else class="event-list">
          <div v-for="ev in monthEvents" :key="ev.id"
            class="event-item"
            :class="{ 'event-item--clickable': ev.wo_number || isPMEvent(ev) }"
            @click="navigateToEvent(ev)">
            <div class="event-color-bar" :style="{ background: ev.color || eventTypeColor(ev.event_type) }"></div>
            <div class="event-info">
              <span class="event-title-full">{{ ev.title }}</span>
              <span class="event-meta text-muted">
                {{ EVENT_TYPE_LABELS[ev.event_type] ?? ev.event_type }}
                <template v-if="ev.wo_number"> · OT {{ ev.wo_number }}</template>
              </span>
            </div>
            <div class="event-date mono small text-muted">{{ formatDate(ev.start_at) }}</div>
            <button v-if="!ev.is_auto" class="btn-del-event" @click.stop="deleteEvent(ev.id)" title="Eliminar">&#10005;</button>
          </div>
        </div>
      </div>
    </template>

    <!-- Agenda view (chronological list) -->
    <template v-if="viewMode === 'agenda'">
      <div v-if="!agendaGroups.length" class="card">
        <div class="card-empty">No hay eventos este mes.</div>
      </div>
      <div v-else class="agenda-list">
        <div v-for="group in agendaGroups" :key="group.dateKey" class="agenda-date-group">
          <div class="agenda-date-header">{{ group.label }}</div>
          <div v-for="ev in group.events" :key="ev.id"
            class="agenda-event"
            :class="{ 'agenda-event--clickable': ev.wo_number || isPMEvent(ev) }"
            @click="navigateToEvent(ev)">
            <div class="agenda-event-bar" :style="{ background: ev.color || eventTypeColor(ev.event_type) }"></div>
            <div class="agenda-event-body">
              <div class="agenda-event-top">
                <span class="agenda-event-title">{{ ev.title }}</span>
                <span class="agenda-event-type-badge" :style="{ background: (ev.color || eventTypeColor(ev.event_type)) + '18', color: ev.color || eventTypeColor(ev.event_type) }">
                  {{ EVENT_TYPE_LABELS[ev.event_type] ?? ev.event_type }}
                </span>
              </div>
              <div class="agenda-event-bottom text-muted">
                <span class="mono small">{{ formatTime(ev.start_at) }}</span>
                <template v-if="ev.wo_number">
                  <span class="agenda-separator">&#183;</span>
                  <span class="mono small">OT {{ ev.wo_number }}</span>
                </template>
                <template v-if="ev.description">
                  <span class="agenda-separator">&#183;</span>
                  <span class="agenda-desc small">{{ ev.description.slice(0, 80) }}<template v-if="ev.description.length > 80">...</template></span>
                </template>
              </div>
            </div>
            <button v-if="!ev.is_auto" class="btn-del-event" @click.stop="deleteEvent(ev.id)" title="Eliminar">&#10005;</button>
          </div>
        </div>
      </div>
    </template>

    <!-- Create event modal -->
    <Teleport to="body">
      <div v-if="showCreate" class="modal-overlay" @click.self="showCreate = false">
        <div class="create-modal">
          <div class="modal-header">
            <h3>Nuevo evento</h3>
            <button class="modal-close" @click="showCreate = false">✕</button>
          </div>
          <div class="modal-body">
            <div class="field"><label class="field-label">Título *</label>
              <input v-model="createForm.title" class="field-input" placeholder="Nombre del evento" />
            </div>
            <div class="field-row">
              <div class="field"><label class="field-label">Tipo</label>
                <select v-model="createForm.event_type" class="field-input">
                  <option value="personal">Personal</option>
                  <option value="reminder">Recordatorio</option>
                  <option value="meeting">Reunión</option>
                  <option value="maintenance">Mantenimiento</option>
                </select>
              </div>
              <div class="field"><label class="field-label">Color</label>
                <div class="color-mini-grid">
                  <button v-for="c in EVENT_COLORS" :key="c"
                    class="color-dot" :class="{ 'color-dot--active': createForm.color === c }"
                    :style="{ background: c }" @click="createForm.color = c"></button>
                </div>
              </div>
            </div>
            <div class="field-row">
              <div class="field"><label class="field-label">Inicio *</label>
                <input v-model="createForm.start_at" type="datetime-local" class="field-input mono" />
              </div>
              <div class="field"><label class="field-label">Fin</label>
                <input v-model="createForm.end_at" type="datetime-local" class="field-input mono" />
              </div>
            </div>
            <div class="field"><label class="field-label">
              <input type="checkbox" v-model="createForm.all_day" /> Todo el día
            </label></div>
            <div v-if="createError" class="modal-error">{{ createError }}</div>
          </div>
          <div class="modal-footer">
            <div class="modal-footer-left"></div>
            <div class="modal-footer-right">
              <button class="btn-secondary" @click="showCreate = false">Cancelar</button>
              <button class="btn-primary" :disabled="!canWrite || saving" @click="submitCreate">
                {{ saving ? 'Guardando...' : 'Crear evento' }}
              </button>
            </div>
          </div>
        </div>
      </div>
    </Teleport>

    <!-- Event detail modal -->
    <Teleport to="body">
      <div v-if="detailEvent" class="modal-overlay" @click.self="detailEvent = null">
        <div class="create-modal">
          <div class="modal-header">
            <div class="event-detail-header">
              <div class="event-color-dot" :style="{ background: detailEvent.color || eventTypeColor(detailEvent.event_type) }"></div>
              <h3>{{ detailEvent.title }}</h3>
            </div>
            <button class="modal-close" @click="detailEvent = null">✕</button>
          </div>
          <div class="modal-body">
            <div class="detail-grid">
              <span class="info-label">Tipo</span>
              <span>{{ EVENT_TYPE_LABELS[detailEvent.event_type] }}</span>
              <span class="info-label">Inicio</span>
              <span class="mono">{{ formatDate(detailEvent.start_at) }}</span>
              <span v-if="detailEvent.end_at" class="info-label">Fin</span>
              <span v-if="detailEvent.end_at" class="mono">{{ formatDate(detailEvent.end_at) }}</span>
              <span v-if="detailEvent.wo_number" class="info-label">OT</span>
              <span v-if="detailEvent.wo_number" class="mono">{{ detailEvent.wo_number }}</span>
            </div>
            <div v-if="detailEvent.is_auto" class="auto-badge">Evento generado automáticamente</div>
          </div>
          <div class="modal-footer">
            <div class="modal-footer-left">
              <button v-if="detailEvent.wo_number" class="btn-primary btn-small" @click="router.push('/work-orders'); detailEvent = null">Ver OT</button>
              <button v-if="detailEvent.id < -1000000" class="btn-primary btn-small" @click="router.push('/maintenance-plans'); detailEvent = null">Ver plan</button>
            </div>
            <div class="modal-footer-right">
              <button v-if="!detailEvent.is_auto" class="btn-danger" @click="deleteEvent(detailEvent.id); detailEvent = null">Eliminar</button>
              <button class="btn-secondary" @click="detailEvent = null">Cerrar</button>
            </div>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<script setup lang="ts">
import { useToast, apiErrorMsg } from '@/composables/useToast'
import { formatDate } from '@/utils/time'
import EmptyState from '@/components/layout/EmptyState.vue'
const toast = useToast()
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import client from '@/api/client'
import { useSystemPause } from '@/composables/useSystemPause'
import { useIsMobile } from '@/composables/useIsMobile'

const router = useRouter()
const { canWrite } = useSystemPause()
const isMobile = useIsMobile()

const EVENT_TYPE_LABELS: Record<string, string> = {
  wo_assigned:  'OT Asignada',
  maintenance:  'Mantenimiento',
  personal:     'Personal',
  reminder:     'Recordatorio',
  meeting:      'Reunión',
  other:        'Otro',
}

const EVENT_COLORS = ['#0F3460', '#27AE60', '#E94560', '#F39C12', '#8B5CF6', '#3B82F6']

function eventTypeColor(type: string) {
  const colors: Record<string, string> = {
    wo_assigned: '#0F3460', maintenance: '#F39C12',
    personal: '#27AE60', reminder: '#8B5CF6', meeting: '#3B82F6',
  }
  return colors[type] ?? '#B0B8C4'
}

const weekdays = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom']
const currentDate = ref(new Date())
const events = ref<any[]>([])
const upcomingEvents = ref<any[]>([])

const showCreate = ref(false)
const saving = ref(false)
const createError = ref('')
const createForm = ref({ title: '', event_type: 'personal', color: '#0F3460', start_at: '', end_at: '', all_day: false })
const detailEvent = ref<any>(null)
const viewMode = ref<'month' | 'agenda'>(window.innerWidth < 768 ? 'agenda' : 'month')

const monthTitle = computed(() => {
  return currentDate.value.toLocaleDateString('es-ES', { month: 'long', year: 'numeric' })
    .replace(/^\w/, c => c.toUpperCase())
})

const calendarCells = computed(() => {
  const year = currentDate.value.getFullYear()
  const month = currentDate.value.getMonth()
  const today = new Date()

  const firstDay = new Date(year, month, 1)
  const lastDay  = new Date(year, month + 1, 0)

  // First Monday of the grid
  let startDate = new Date(firstDay)
  const dow = (firstDay.getDay() + 6) % 7 // Mon=0
  startDate.setDate(startDate.getDate() - dow)

  const cells = []
  const d = new Date(startDate)

  for (let i = 0; i < 42; i++) {
    const dateStr = d.toISOString().slice(0, 10)
    const dayEvents = events.value.filter(ev => ev.start_at?.slice(0, 10) === dateStr)
    const visible = dayEvents.slice(0, 3)
    const moreCount = dayEvents.length - visible.length

    cells.push({
      date: new Date(d),
      day: d.getDate(),
      currentMonth: d.getMonth() === month,
      isToday: d.toDateString() === today.toDateString(),
      events: visible,
      moreCount,
    })
    d.setDate(d.getDate() + 1)
  }
  return cells
})

const monthEvents = computed(() => {
  const year = currentDate.value.getFullYear()
  const month = currentDate.value.getMonth()
  return events.value.filter(ev => {
    const d = new Date(ev.start_at)
    return d.getFullYear() === year && d.getMonth() === month
  }).sort((a, b) => new Date(a.start_at).getTime() - new Date(b.start_at).getTime())
})

function prevMonth() { currentDate.value = new Date(currentDate.value.getFullYear(), currentDate.value.getMonth() - 1, 1); loadEvents() }
function nextMonth() { currentDate.value = new Date(currentDate.value.getFullYear(), currentDate.value.getMonth() + 1, 1); loadEvents() }
function goToday() { currentDate.value = new Date(); loadEvents() }

async function loadEvents() {
  const year = currentDate.value.getFullYear()
  const month = currentDate.value.getMonth()
  const from = new Date(year, month, 1).toISOString().slice(0, 10)
  const to   = new Date(year, month + 1, 0).toISOString().slice(0, 10)
  try {
    const { data } = await client.get(`/calendar?from=${from}&to=${to}`)
    events.value = data.events ?? []
  } catch { events.value = [] }
}

async function loadUpcoming() {
  try {
    const { data } = await client.get('/calendar/upcoming')
    upcomingEvents.value = data.events ?? []
  } catch { upcomingEvents.value = [] }
}

function openCreate() {
  const now = new Date()
  now.setMinutes(0, 0, 0)
  createForm.value = {
    title: '', event_type: 'personal', color: '#0F3460',
    start_at: now.toISOString().slice(0, 16),
    end_at: '', all_day: false
  }
  createError.value = ''
  showCreate.value = true
}

async function submitCreate() {
  if (!createForm.value.title || !createForm.value.start_at) {
    createError.value = 'Título y fecha de inicio son requeridos'
    return
  }
  saving.value = true; createError.value = ''
  try {
    await client.post('/calendar', {
      title: createForm.value.title,
      event_type: createForm.value.event_type,
      color: createForm.value.color,
      start_at: createForm.value.start_at,
      end_at: createForm.value.end_at || null,
      all_day: createForm.value.all_day,
    })
    showCreate.value = false
    await loadEvents()
    await loadUpcoming()
  } catch (err: unknown) {
    createError.value = apiErrorMsg(err, 'Error creando evento')
  } finally { saving.value = false }
}

function openDetail(ev: any) { detailEvent.value = ev }

async function deleteEvent(id: number) {
  if (!confirm('¿Eliminar este evento?')) return
  try {
    await client.delete(`/calendar/${id}`)
    events.value = events.value.filter(e => e.id !== id)
    await loadUpcoming()
  } catch (err: unknown) { toast.fromError(err, 'Error eliminando evento') }
}

function formatShort(iso: string) {
  try { return new Date(iso).toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit' }) }
  catch { return iso }
}

function formatTime(iso: string) {
  try { return new Date(iso).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }) }
  catch { return iso }
}

function formatAgendaDate(dateStr: string) {
  try {
    const d = new Date(dateStr + 'T12:00:00')
    return d.toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' })
  } catch { return dateStr }
}

function isPMEvent(ev: any): boolean {
  return ev.title?.startsWith('[PM]') || ev.id < -1000000
}

function navigateToEvent(ev: any) {
  if (ev.wo_number) {
    router.push('/work-orders')
  } else if (isPMEvent(ev)) {
    router.push('/maintenance-plans')
  }
}

const agendaGroups = computed(() => {
  const grouped: Record<string, { dateKey: string; label: string; events: any[] }> = {}
  for (const ev of monthEvents.value) {
    const dateKey = ev.start_at?.slice(0, 10) ?? ''
    if (!grouped[dateKey]) {
      grouped[dateKey] = {
        dateKey,
        label: formatAgendaDate(dateKey),
        events: [],
      }
    }
    grouped[dateKey].events.push(ev)
  }
  return Object.values(grouped).sort((a, b) => a.dateKey.localeCompare(b.dateKey))
})

onMounted(() => { loadEvents(); loadUpcoming() })
</script>

<style scoped>
.cal-layout { display: flex; flex-direction: column; gap: var(--space-5); }
.page-header { display: flex; align-items: flex-start; justify-content: space-between; flex-wrap: wrap; gap: var(--space-3); }
.header-actions { display: flex; align-items: center; gap: var(--space-3); }
.page-title { font-size: 1.4rem; font-weight: 700; color: var(--color-primary); }
.page-sub { font-size: 0.8rem; color: var(--color-text-muted); }

/* Upcoming */
.upcoming-strip { display: flex; align-items: center; gap: var(--space-3); flex-wrap: wrap; padding: var(--space-3) var(--space-4); background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); }
.upcoming-label { font-size: 0.7rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); white-space: nowrap; }
.upcoming-pill { display: flex; align-items: center; gap: var(--space-2); padding: 3px 10px; border-radius: 20px; border: 1px solid; font-size: 0.75rem; }
.up-date { font-family: var(--font-mono); font-size: 0.7rem; opacity: 0.7; }
.up-title { font-weight: 500; }
.up-wo { font-family: var(--font-mono); font-size: 0.68rem; opacity: 0.7; }

/* Calendar */
.cal-nav-bar { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); overflow: hidden; }
.cal-wrapper { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); overflow: hidden; }
.cal-nav { display: flex; align-items: center; gap: var(--space-3); padding: var(--space-4) var(--space-5); }
.cal-month-title { flex: 1; font-size: 1rem; font-weight: 600; color: var(--color-primary); text-align: center; text-transform: capitalize; }
.nav-btn { width: 32px; height: 32px; background: var(--color-surface-2); border: 1px solid var(--color-border); border-radius: var(--radius-sm); cursor: pointer; font-size: 1rem; color: var(--color-text-muted); }
.nav-btn:hover { background: var(--color-border-light); color: var(--color-text); }
.nav-btn-today { height: 32px; padding: 0 var(--space-3); background: var(--color-surface-2); border: 1px solid var(--color-border); border-radius: var(--radius-sm); cursor: pointer; font-size: 0.8rem; color: var(--color-text-muted); }
.nav-btn-today:hover { background: var(--color-border-light); }

.cal-weekdays { display: grid; grid-template-columns: repeat(7, 1fr); border-bottom: 1px solid var(--color-border-light); }
.cal-weekday { padding: var(--space-2); text-align: center; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); letter-spacing: 0.5px; }

.cal-grid { display: grid; grid-template-columns: repeat(7, 1fr); }
.cal-cell { min-height: 90px; border-right: 1px solid var(--color-border-light); border-bottom: 1px solid var(--color-border-light); padding: var(--space-2); position: relative; }
.cal-cell:nth-child(7n) { border-right: none; }
.cal-cell--other { background: var(--color-surface-2); }
.cal-cell--other .cell-number { color: var(--color-text-light); }
.cal-cell--today { background: rgba(15,52,96,0.04); }
.cal-cell--today .cell-number { background: var(--color-primary); color: #fff; border-radius: 50%; width: 22px; height: 22px; display: flex; align-items: center; justify-content: center; font-weight: 700; }
.cell-number { font-size: 0.78rem; font-weight: 500; color: var(--color-text); margin-bottom: 3px; width: 22px; height: 22px; display: flex; align-items: center; justify-content: center; }
.cell-events { display: flex; flex-direction: column; gap: 2px; }
.cell-event { padding: 2px 5px; border-radius: 3px; font-size: 0.68rem; font-weight: 500; cursor: pointer; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.cell-event:hover { filter: brightness(0.9); }
.cell-more { font-size: 0.65rem; color: var(--color-text-muted); padding: 1px 5px; }

/* Event list */
.card { background: var(--color-surface); border: 1px solid var(--color-border-light); border-radius: var(--radius-md); overflow: hidden; }
.card-header { display: flex; justify-content: space-between; align-items: center; padding: var(--space-4) var(--space-5); border-bottom: 1px solid var(--color-border-light); }
.card-title { font-size: 0.78rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--color-text-muted); }
.card-empty { padding: var(--space-5); text-align: center; font-size: 0.875rem; color: var(--color-text-muted); }
.event-list { display: flex; flex-direction: column; }
.event-item { display: flex; align-items: center; gap: var(--space-3); padding: var(--space-3) var(--space-5); border-bottom: 1px solid var(--color-border-light); }
.event-item:last-child { border-bottom: none; }
.event-color-bar { width: 3px; height: 32px; border-radius: 2px; flex-shrink: 0; }
.event-info { flex: 1; display: flex; flex-direction: column; gap: 2px; }
.event-title-full { font-size: 0.875rem; font-weight: 500; }
.event-meta { font-size: 0.72rem; }
.event-date { flex-shrink: 0; }
.btn-del-event { background: none; border: none; color: var(--color-text-light); cursor: pointer; font-size: 0.8rem; padding: var(--space-1); border-radius: var(--radius-sm); }
.btn-del-event:hover { color: var(--color-alert); background: rgba(233,69,96,0.08); }

/* Modal */
.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; padding: var(--space-4); }
.create-modal { background: var(--color-surface); border-radius: var(--radius-lg); width: 100%; max-width: 460px; box-shadow: var(--shadow-lg); }
.modal-header { display: flex; justify-content: space-between; align-items: center; padding: var(--space-5) var(--space-6); border-bottom: 1px solid var(--color-border-light); }
.event-detail-header { display: flex; align-items: center; gap: var(--space-3); }
.event-color-dot { width: 14px; height: 14px; border-radius: 50%; flex-shrink: 0; }
.modal-header h3 { font-size: 1rem; font-weight: 600; color: var(--color-primary); }
.modal-close { background: none; border: none; font-size: 1rem; cursor: pointer; color: var(--color-text-muted); }
.modal-body { padding: var(--space-5) var(--space-6); display: flex; flex-direction: column; gap: var(--space-4); }
.modal-error { background: rgba(233,69,96,0.08); border: 1px solid rgba(233,69,96,0.3); border-radius: var(--radius); padding: var(--space-3); font-size: 0.875rem; color: var(--color-alert); }

.detail-grid { display: grid; grid-template-columns: auto 1fr; gap: var(--space-2) var(--space-4); align-items: baseline; background: var(--color-surface-2); border-radius: var(--radius-md); padding: var(--space-4); }
.info-label { font-size: 0.68rem; font-weight: 700; text-transform: uppercase; color: var(--color-text-muted); }
.auto-badge { font-size: 0.75rem; color: var(--color-text-muted); background: var(--color-surface-2); border-radius: var(--radius); padding: var(--space-2) var(--space-3); text-align: center; }

.field { display: flex; flex-direction: column; gap: var(--space-2); }
.field-row { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-3); }
.field-label { font-size: 0.72rem; font-weight: 600; text-transform: uppercase; color: var(--color-text-muted); display: flex; align-items: center; gap: var(--space-2); }
.field-input { height: 38px; padding: 0 var(--space-3); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; background: var(--color-surface); outline: none; width: 100%; }
.field-input:focus { border-color: var(--color-accent); }
.color-mini-grid { display: flex; gap: 6px; flex-wrap: wrap; }
.color-dot { width: 22px; height: 22px; border-radius: 50%; border: 2px solid transparent; cursor: pointer; transition: transform var(--transition); }
.color-dot:hover { transform: scale(1.2); }
.color-dot--active { border-color: #fff; box-shadow: 0 0 0 2px var(--color-accent); }

.btn-primary { height: 38px; padding: 0 var(--space-5); background: var(--color-primary); color: #fff; border: none; border-radius: var(--radius); font-size: 0.875rem; font-weight: 500; cursor: pointer; }
.btn-primary:hover:not(:disabled) { background: var(--color-accent); }
.btn-primary:disabled { opacity: 0.65; cursor: not-allowed; }
.btn-secondary { height: 38px; padding: 0 var(--space-5); background: var(--color-surface-2); color: var(--color-text); border: 1px solid var(--color-border); border-radius: var(--radius); font-size: 0.875rem; cursor: pointer; }
.btn-danger { height: 38px; padding: 0 var(--space-5); background: rgba(233,69,96,0.1); color: var(--color-alert); border: 1px solid rgba(233,69,96,0.3); border-radius: var(--radius); font-size: 0.875rem; cursor: pointer; }
.btn-danger:hover { background: rgba(233,69,96,0.2); }

/* View toggle */
.view-toggle { display: flex; gap: 0; }
.view-toggle-btn { height: 30px; padding: 0 var(--space-3); background: var(--color-surface-2); border: 1px solid var(--color-border); font-size: 0.75rem; font-weight: 500; color: var(--color-text-muted); cursor: pointer; transition: all var(--transition); }
.view-toggle-btn:first-child { border-radius: var(--radius-sm) 0 0 var(--radius-sm); border-right: none; }
.view-toggle-btn:last-child { border-radius: 0 var(--radius-sm) var(--radius-sm) 0; }
.view-toggle-btn:hover:not(.view-toggle-btn--active) { background: var(--color-border-light); }
.view-toggle-btn--active { background: var(--color-primary); color: #fff; border-color: var(--color-primary); }

/* Clickable event items */
.event-item--clickable { cursor: pointer; }
.event-item--clickable:hover { background: var(--color-surface-2); }

/* Agenda view */
.agenda-list { display: flex; flex-direction: column; gap: var(--space-4); }
.agenda-date-group { display: flex; flex-direction: column; gap: 0; }
.agenda-date-header { font-size: 0.82rem; font-weight: 700; text-transform: capitalize; color: var(--color-primary); padding: var(--space-3) var(--space-4); border-bottom: 2px solid var(--color-border-light); margin-bottom: 0; }
.agenda-event { display: flex; align-items: center; gap: var(--space-3); padding: var(--space-3) var(--space-4); background: var(--color-surface); border: 1px solid var(--color-border-light); border-top: none; transition: background var(--transition); }
.agenda-event:last-child { border-radius: 0 0 var(--radius-md) var(--radius-md); }
.agenda-event--clickable { cursor: pointer; }
.agenda-event--clickable:hover { background: var(--color-surface-2); }
.agenda-event-bar { width: 3px; height: 36px; border-radius: 2px; flex-shrink: 0; }
.agenda-event-body { flex: 1; display: flex; flex-direction: column; gap: 2px; min-width: 0; }
.agenda-event-top { display: flex; align-items: center; gap: var(--space-3); }
.agenda-event-title { font-size: 0.875rem; font-weight: 500; color: var(--color-text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.agenda-event-type-badge { font-size: 0.65rem; font-weight: 600; text-transform: uppercase; padding: 1px 7px; border-radius: 10px; flex-shrink: 0; }
.agenda-event-bottom { display: flex; align-items: center; gap: var(--space-2); font-size: 0.72rem; }
.agenda-separator { opacity: 0.5; }
.agenda-desc { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 250px; }

/* Modal footer with left/right sections */
.modal-footer { display: flex; justify-content: space-between; align-items: center; gap: var(--space-3); padding: var(--space-4) var(--space-6); border-top: 1px solid var(--color-border-light); }
.modal-footer-left { display: flex; gap: var(--space-2); }
.modal-footer-right { display: flex; gap: var(--space-3); }

/* Small button variant */
.btn-small { height: 30px; padding: 0 var(--space-3); font-size: 0.75rem; }

.mono { font-family: var(--font-mono); }
.small { font-size: 0.75rem; }
.text-muted { color: var(--color-text-muted); }

@media (max-width: 768px) {
  .page-header { flex-direction: column; align-items: flex-start; gap: var(--space-3); }
  .page-title { font-size: 1.15rem; }
  .header-actions { width: 100%; display: flex; justify-content: space-between; }
  .upcoming-strip { flex-wrap: wrap; gap: var(--space-2); padding: var(--space-2) var(--space-3); }
  .upcoming-pill { font-size: 0.72rem; }

  /* Calendar fits in viewport — no horizontal scroll */
  .cal-weekday { font-size: 0.6rem; padding: var(--space-1); letter-spacing: 0; }
  .cal-cell { min-height: 52px; padding: 2px; }
  .cell-number { font-size: 0.72rem; width: 20px; height: 20px; }
  .cell-event { font-size: 0.6rem; padding: 1px 3px; }
  .cell-more { font-size: 0.58rem; }

  .cal-nav { padding: var(--space-3); }
  .cal-month-title { font-size: 0.9rem; }
  .nav-btn, .nav-btn-today { height: 36px; min-width: 36px; }

  .view-toggle-btn { height: 36px; font-size: 0.78rem; }

  .agenda-desc { max-width: 140px; }

  /* Modal */
  .modal-overlay { padding: 0; }
  .create-modal { max-width: 100%; border-radius: 0; max-height: 100vh; }
  .modal-body { padding: var(--space-4); }
  .field-input { height: 42px; }
  textarea.field-input { font-size: 1rem; }
  .btn-primary, .btn-secondary, .btn-danger { height: 44px; font-size: 0.9rem; }
  .modal-footer { flex-direction: column; gap: var(--space-2); }
  .modal-footer-left, .modal-footer-right { width: 100%; justify-content: stretch; }
  .modal-footer-right { justify-content: flex-end; }
}

@media (max-width: 480px) {
  .cal-weekday { font-size: 0.55rem; }
  .cal-cell { min-height: 44px; }
  .cell-event { display: none; } /* Only show dot indicator on phones */
  .cell-more { display: none; }
  /* Show colored dots instead of text events */
  .cell-events { flex-direction: row; gap: 2px; flex-wrap: wrap; }
}
</style>
