// ─── Auth ─────────────────────────────────────────────────────────────────────

export interface User {
  id: number
  email: string
  full_name: string
  role: UserRole
  tenant_id: number
  home_node_id: number | null
  is_primary_admin?: boolean
  is_superadmin?: boolean
}

export interface MeResponse extends User {
  system_paused?: boolean
}

export type UserRole =
  | 'admin'
  | 'supervisor'
  | 'technician'
  | 'operator'
  | 'warehouse'
  | 'auditor'

export interface LoginRequest {
  email: string
  password: string
}

export interface LoginResponse {
  access_token: string
  refresh_token?: string
  token_type: string
  expires_in: number
  user: User
  system_paused?: boolean
}

export interface RefreshResponse {
  access_token: string
  token_type: string
  expires_in: number
}

// ─── Role constants ──────────────────────────────────────────────────────

export const ROLE_LABELS: Record<string, string> = {
  admin: 'Administrador',
  supervisor: 'Supervisor',
  technician: 'Técnico',
  operator: 'Operario',
  warehouse: 'Almacén',
  auditor: 'Auditor',
}

export const ROLE_COLORS: Record<string, string> = {
  admin: '#1A1A2E',
  supervisor: '#0F3460',
  technician: '#16813D',
  operator: '#2980B9',
  warehouse: '#8E44AD',
  auditor: '#7F8C8D',
}

// ─── Criticality constants ────────────────────────────────────────────────

export const CRIT_COLORS: Record<string, string> = {
  low: '#27AE60',
  medium: '#F39C12',
  high: '#E67E22',
  critical: '#E94560',
}
