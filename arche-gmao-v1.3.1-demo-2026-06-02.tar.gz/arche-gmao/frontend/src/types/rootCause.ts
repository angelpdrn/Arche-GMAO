// Catalogue of root cause codes. It must match the chk_wo_root_cause_code
// CHECK constraint defined in migration 037.

export interface RootCauseInfo {
  code: string
  label: string
  /** Short hint for the technician, shown in the dropdown */
  hint?: string
}

export const ROOT_CAUSE_CODES: RootCauseInfo[] = [
  { code: 'mechanical',  label: 'Mecánica',          hint: 'Rotura, holgura, vibración, alineación' },
  { code: 'wear',        label: 'Desgaste',          hint: 'Fin de vida útil, uso normal' },
  { code: 'electrical',  label: 'Eléctrica',         hint: 'Cortocircuito, aislamiento, contactos' },
  { code: 'electronic',  label: 'Electrónica',       hint: 'Placa, sensor, lógica, PLC' },
  { code: 'hydraulic',   label: 'Hidráulica',        hint: 'Fugas, presiones, sellos' },
  { code: 'pneumatic',   label: 'Neumática',         hint: 'Aire, válvulas, actuadores' },
  { code: 'lubrication', label: 'Lubricación',       hint: 'Falta o exceso de lubricante' },
  { code: 'parameters',  label: 'Parámetros',        hint: 'Configuración o setpoint incorrecto' },
  { code: 'operation',   label: 'Operación',         hint: 'Error humano u operación incorrecta' },
  { code: 'environment', label: 'Entorno',           hint: 'Temperatura, humedad, polvo' },
  { code: 'supply',      label: 'Suministro',        hint: 'Corriente, aire, agua o materia entrante' },
  { code: 'unknown',     label: 'Sin determinar',    hint: 'Pendiente de análisis' },
  { code: 'other',       label: 'Otra' },
]

export function rootCauseLabel(code: string | null | undefined): string {
  if (!code) return ''
  return ROOT_CAUSE_CODES.find(c => c.code === code)?.label ?? code
}
