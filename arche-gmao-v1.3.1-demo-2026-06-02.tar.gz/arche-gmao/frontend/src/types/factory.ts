// ─── Virtual Factory ─────────────────────────────────────────────────────────

export interface FactoryNode {
  id: number
  parent_id: number | null
  client_id: number | null
  name: string
  code: string | null
  node_type: NodeType
  status: NodeStatus
  criticality: Criticality
  description: string | null
  manufacturer: string | null
  model: string | null
  serial_number: string | null
  year_installed: number | null
  rated_power_kw: number | null
  path: string
  version: number
  created_at: string
  updated_at: string
  children: FactoryNode[]
  tags: Tag[]
}

export type NodeType =
  | 'organization'
  | 'plant'
  | 'area'
  | 'line'
  | 'composition'
  | 'equipment'
  | 'component'
  | 'measurement_point'

export type NodeStatus = 'active' | 'inactive' | 'maintenance' | 'decommissioned'
export type Criticality = 'low' | 'medium' | 'high' | 'critical'

export interface NodeTypeDefinition {
  id: number
  tenant_id: number | null
  type_key: string
  label: string
  icon: string | null
  color: string | null
  sort_order: number
  is_system: boolean
}

// ─── Clients ─────────────────────────────────────────────────────────────────

export interface Client {
  id: number
  tenant_id: number
  name: string
  code: string
  client_type: 'internal' | 'external'
  status: 'active' | 'inactive'
  contact_name: string | null
  contact_email: string | null
  contact_phone: string | null
  notes: string | null
  created_at: string
  updated_at: string
}

// ─── Tags ─────────────────────────────────────────────────────────────────────

export interface Tag {
  id: number
  name: string
  color: string
}

// ─── Search ─────────────────────────────────────────────────────────────────

export interface SearchResult {
  id: number
  parent_id: number | null
  name: string
  code: string | null
  node_type: NodeType
  status: NodeStatus
  criticality: Criticality
  path: string
}

// ─── Forms ─────────────────────────────────────────────────────────────

export interface NodeFormData {
  parent_id: number | null
  client_id: number | null
  name: string
  code: string
  node_type: NodeType
  status: NodeStatus
  criticality: Criticality
  description: string
  manufacturer: string
  model: string
  serial_number: string
  year_installed: number | null
  rated_power_kw: number | null
  version?: number
}

// ─── Visual configuration of the types ───────────────────────────────────────────

export const NODE_TYPE_CONFIG: Record<string, { label: string; symbol: string; depth: number }> = {
  organization:      { label: 'Organización',      symbol: '◈', depth: 0 },
  plant:             { label: 'Planta',             symbol: '▣', depth: 1 },
  area:              { label: 'Área',               symbol: '□', depth: 2 },
  line:              { label: 'Línea',              symbol: '▷', depth: 3 },
  composition:       { label: 'Composición',        symbol: '⬡', depth: 4 },
  equipment:         { label: 'Equipo',             symbol: '⚙', depth: 4 },
  component:         { label: 'Componente',         symbol: '◉', depth: 5 },
  measurement_point: { label: 'Punto de Medición',  symbol: '◦', depth: 6 },
}

export const CRITICALITY_CONFIG: Record<string, { label: string; color: string }> = {
  low:      { label: 'Baja',     color: '#27AE60' },
  medium:   { label: 'Media',    color: '#F39C12' },
  high:     { label: 'Alta',     color: '#E67E22' },
  critical: { label: 'Crítica',  color: '#E94560' },
}

export const STATUS_CONFIG: Record<string, { label: string; color: string }> = {
  active:          { label: 'Activo',           color: '#27AE60' },
  inactive:        { label: 'Inactivo',         color: '#6B7280' },
  maintenance:     { label: 'En Mantenimiento', color: '#F39C12' },
  decommissioned:  { label: 'Dado de Baja',     color: '#E94560' },
}
