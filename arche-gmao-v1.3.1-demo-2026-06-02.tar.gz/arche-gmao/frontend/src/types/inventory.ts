export interface SparePart {
  id: number
  tenant_id: number
  code: string
  name: string
  category: SpareCategory
  unit: string
  current_stock: number
  min_stock: number
  max_stock: number | null
  location: string | null
  supplier: string | null
  supplier_ref: string | null
  unit_price: number | null
  lead_days: number | null
  notes: string | null
  is_active: boolean
  low_stock: boolean
  created_at: string
  updated_at: string
}

export interface StockMovement {
  id: number
  movement_type: MovementType
  quantity: number
  unit_cost: number | null
  stock_before: number
  stock_after: number
  notes: string | null
  created_by: string | null
  created_at: string
}

export type SpareCategory = 'mechanical' | 'electrical' | 'pneumatic' | 'electronic' | 'consumable' | 'other'
export type MovementType = 'purchase' | 'consumption' | 'manual_out' | 'adjustment' | 'return' | 'transfer'

export const CATEGORY_CONFIG: Record<SpareCategory, { label: string; color: string }> = {
  mechanical:  { label: 'Mecánico',     color: '#0F3460' },
  electrical:  { label: 'Eléctrico',    color: '#F39C12' },
  pneumatic:   { label: 'Neumático',    color: '#3B82F6' },
  electronic:  { label: 'Electrónico',  color: '#8B5CF6' },
  consumable:  { label: 'Consumible',   color: '#10B981' },
  other:       { label: 'Otro',         color: '#9CA3AF' },
}

export const MOVEMENT_CONFIG: Record<MovementType, { label: string; sign: string; color: string }> = {
  purchase:    { label: 'Compra',          sign: '+', color: '#27AE60' },
  consumption: { label: 'Consumo OT',      sign: '-', color: '#E94560' },
  manual_out:  { label: 'Salida manual',   sign: '-', color: '#E67E22' },
  adjustment:  { label: 'Ajuste',          sign: '+', color: '#3B82F6' },
  return:      { label: 'Devolución',      sign: '+', color: '#10B981' },
  transfer:    { label: 'Transferencia',   sign: '-', color: '#8B5CF6' },
}
