export type StepType = 'checkbox' | 'numeric' | 'text' | 'photo' | 'signature' | 'selection' | 'meter_reading' | 'passfail'
export type ProcedureCategory = 'general' | 'inspection' | 'preventive' | 'corrective' | 'safety' | 'commissioning'
export type ExecutionStatus = 'pending' | 'in_progress' | 'completed' | 'cancelled'

export interface StepConfig {
  unit?: string
  min?: number
  max?: number
  alert_min?: number
  alert_max?: number
  options?: string[]
  min_photos?: number
  max_photos?: number
  fail_action?: 'stop' | 'warn' | 'continue'
  max_length?: number
}

export interface StepCondition {
  if_step: number
  operator: '>' | '<' | '>=' | '<=' | 'equals' | 'not_equals'
  value: number | string | boolean
  action: 'goto' | 'stop' | 'warn'
  goto_step?: number
}

export interface ProcedureStep {
  id: number
  step_number: number
  title: string
  description: string | null
  step_type: StepType
  is_required: boolean
  config: StepConfig
  condition?: StepCondition
  estimated_minutes: number | null
  result?: StepResult
}

export interface StepResult {
  value_text: string | null
  value_numeric: number | null
  value_bool: boolean | null
  value_selection: string | null
  is_pass: boolean | null
  out_of_range: boolean | null
  completed_by: number | null
  completed_by_name: string | null
  completed_at: string | null
  skipped: boolean
  skip_reason: string | null
  notes: string | null
}

export interface ProcedureTemplate {
  id: number
  title: string
  description: string | null
  category: ProcedureCategory
  node_type_target: string | null
  version: number
  is_active: boolean
  created_by: number | null
  created_by_name: string | null
  created_at: string
  updated_at: string
  step_count: number
  execution_count: number
}

export interface ProcedureTemplateDetail extends ProcedureTemplate {
  steps: ProcedureStep[]
  links: ProcedureLink[]
}

export interface ProcedureLink {
  id: number
  maintenance_plan_id: number | null
  plan_title: string | null
  node_id: number | null
  node_name: string | null
  wo_type: string | null
}

export interface ProcedureExecution {
  id: number
  template_id: number
  title: string
  template_version: number
  wo_id: number | null
  node_id: number | null
  executed_by: number | null
  executed_by_name: string | null
  status: ExecutionStatus
  total_steps: number
  completed_steps: number
  started_at: string | null
  completed_at: string | null
  notes: string | null
  created_at: string
  steps?: ProcedureStep[]
}

export interface ProcedureSuggestion {
  id: number
  title: string
  category: ProcedureCategory
  step_count: number
}

export const STEP_TYPE_LABELS: Record<StepType, string> = {
  checkbox: 'Verificación',
  numeric: 'Valor numérico',
  text: 'Texto libre',
  photo: 'Foto requerida',
  signature: 'Firma',
  selection: 'Selección',
  meter_reading: 'Lectura de medidor',
  passfail: 'Pasa / No pasa',
}

export const CATEGORY_LABELS: Record<ProcedureCategory, string> = {
  general: 'General',
  inspection: 'Inspeccion',
  preventive: 'Preventivo',
  corrective: 'Correctivo',
  safety: 'Seguridad',
  commissioning: 'Puesta en marcha',
}
