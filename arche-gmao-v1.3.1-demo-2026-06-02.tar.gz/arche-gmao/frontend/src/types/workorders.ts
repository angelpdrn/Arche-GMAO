export interface WorkOrder {
  id: number
  tenant_id: number
  node_id: number
  node_name: string
  wo_number: string
  title: string
  description: string | null
  wo_type: WOType
  priority: WOPriority
  status: WOStatus
  assigned_to: number | null
  assigned_name: string | null
  created_by: number | null
  created_by_name: string | null
  estimated_hours: number | null
  actual_hours: number | null
  planned_start: string | null
  planned_end: string | null
  started_at: string | null
  completed_at: string | null
  closed_at: string | null
  root_cause: string | null
  solution: string | null
  version: number
  created_at: string
  updated_at: string
}

export interface WOLogEntry {
  id: number
  user_id: number | null
  user_name: string | null
  from_status: WOStatus | null
  to_status: WOStatus
  comment: string | null
  created_at: string
}

export interface WOComment {
  id: number
  user_id: number | null
  user_name: string | null
  content: string
  created_at: string
}

export type WOType = 'corrective' | 'preventive' | 'predictive' | 'improvement' | 'inspection'
export type WOPriority = 'low' | 'medium' | 'high' | 'critical'
export type WOStatus =
  | 'draft' | 'pending' | 'approved' | 'assigned' | 'in_progress'
  | 'completed' | 'verified' | 'closed' | 'rejected' | 'paused' | 'cancelled'

export const WO_TYPE_CONFIG: Record<WOType, { label: string }> = {
  corrective:   { label: 'Correctiva' },
  preventive:   { label: 'Preventiva' },
  predictive:   { label: 'Predictiva' },
  improvement:  { label: 'Mejora' },
  inspection:   { label: 'Inspección' },
}

export const WO_PRIORITY_CONFIG: Record<WOPriority, { label: string; color: string }> = {
  low:      { label: 'Baja',     color: '#27AE60' },
  medium:   { label: 'Media',    color: '#F39C12' },
  high:     { label: 'Alta',     color: '#E67E22' },
  critical: { label: 'Crítica',  color: '#E94560' },
}

export const WO_STATUS_CONFIG: Record<WOStatus, { label: string; color: string }> = {
  draft:       { label: 'Borrador',          color: '#9CA3AF' },
  pending:     { label: 'Pendiente',          color: '#F39C12' },
  approved:    { label: 'Aprobada',           color: '#3B82F6' },
  assigned:    { label: 'Asignada',           color: '#8B5CF6' },
  in_progress: { label: 'En Ejecución',       color: '#0F3460' },
  completed:   { label: 'Completada',         color: '#10B981' },
  verified:    { label: 'Verificada',         color: '#27AE60' },
  closed:      { label: 'Cerrada',            color: '#6B7280' },
  rejected:    { label: 'Rechazada',          color: '#E94560' },
  paused:      { label: 'En Pausa',           color: '#F59E0B' },
  cancelled:   { label: 'Cancelada',          color: '#EF4444' },
}

// Roles that can perform each transition in the UI
// OPS (supervisor): operational management (approve, reject, verify, close, assign)
// EXEC (supervisor + technician + operator): execution (start, complete, pause, resume)
// The admin does NOT see operational actions in the UI (the backend allows them as a safety net)
export type WOTransition = { to: WOStatus; label: string; requireComment: boolean; roles: string[] }

const ALL_ROLES = ['admin', 'supervisor', 'technician', 'operator', 'warehouse', 'auditor']
const OPS  = ['supervisor']
const EXEC = ['supervisor', 'technician', 'operator']

export const WO_TRANSITIONS: Record<WOStatus, WOTransition[]> = {
  draft:       [{ to: 'pending', label: 'Enviar a revisión', requireComment: false, roles: ALL_ROLES }],
  pending:     [
    { to: 'approved',  label: 'Aprobar',   requireComment: false, roles: OPS },
    { to: 'rejected',  label: 'Rechazar',  requireComment: true,  roles: OPS },
  ],
  approved:    [{ to: 'assigned', label: 'Asignar técnico', requireComment: false, roles: OPS }],
  assigned:    [
    { to: 'in_progress', label: 'Comenzar', requireComment: false, roles: EXEC },
    { to: 'paused',      label: 'Pausar',   requireComment: true,  roles: EXEC },
  ],
  in_progress: [
    { to: 'completed', label: 'Completar', requireComment: false, roles: EXEC },
    { to: 'paused',    label: 'Pausar',    requireComment: true,  roles: EXEC },
  ],
  paused:      [{ to: 'in_progress', label: 'Reanudar', requireComment: false, roles: EXEC }],
  completed:   [{ to: 'closed', label: 'Cerrar', requireComment: false, roles: OPS }],
  verified:    [{ to: 'closed', label: 'Cerrar', requireComment: false, roles: OPS }],
  rejected:    [{ to: 'pending', label: 'Reenviar', requireComment: false, roles: ALL_ROLES }],
  cancelled:   [],
  closed:      [],
}
