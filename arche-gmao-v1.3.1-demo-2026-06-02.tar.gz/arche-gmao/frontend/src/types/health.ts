export interface HealthFactor {
  penalty: number
  weight: number
  raw: number
}

export interface HealthDetails {
  failure_freq: HealthFactor
  pm_compliance: HealthFactor
  age: HealthFactor
  mtbf_trend: HealthFactor
  corrective_ratio: HealthFactor
  parts_consumption: HealthFactor
  criticality_mult: number
  decay_penalty: number
  total_penalty: number
  final_score: number
}

export interface NodeHealth {
  node_id: number
  health_score: number
  details: HealthDetails
}

export interface HealthHistoryEntry {
  score: number
  date: string
  details?: HealthDetails
}

export interface HealthSummaryNode {
  id: number
  name: string
  node_type: string
  criticality: string
  health_score: number | null
  parent_id: number | null
}

export interface HealthDistribution {
  critical: number
  poor: number
  fair: number
  good: number
  excellent: number
}

export interface HealthWeightConfig {
  node_type: string
  weights: Record<string, number>
  expected_life_years: number
  decay_per_day: number
}

export function healthColor(score: number | null): string {
  if (score === null) return '#888'
  if (score >= 85) return '#27AE60'
  if (score >= 70) return '#6BCB77'
  if (score >= 50) return '#E6A817'
  if (score >= 30) return '#E67E22'
  return '#E94560'
}

export function healthLabel(score: number | null): string {
  if (score === null) return 'Sin datos'
  if (score >= 85) return 'Excelente'
  if (score >= 70) return 'Bueno'
  if (score >= 50) return 'Regular'
  if (score >= 30) return 'Pobre'
  return 'Critico'
}

export const HEALTH_FACTOR_LABELS: Record<string, string> = {
  failure_freq: 'Frecuencia de fallos',
  pm_compliance: 'Cumplimiento preventivo',
  age: 'Edad del equipo',
  mtbf_trend: 'Tendencia MTBF',
  corrective_ratio: 'Ratio correctivo',
  parts_consumption: 'Consumo de repuestos',
}
