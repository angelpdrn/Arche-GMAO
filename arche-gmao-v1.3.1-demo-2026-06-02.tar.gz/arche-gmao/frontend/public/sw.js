// Arche GMAO — Service Worker v5.0
// PWA offline + Push notifications + iOS Safari compatibility + Offline mode
const CACHE_VERSION = 'arche-v5'
const APP_SHELL = [
  '/',
  '/manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
]

const API_CACHE_PATTERNS = [
  '/work-orders',
  '/factory/tree',
  '/factory/nodes/',
  '/factory/search',
]

function shouldCacheAPI(pathname) {
  return API_CACHE_PATTERNS.some(p => pathname.includes(p))
}

// ─── Install ──────────────────────────────────────────────────────────────────
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION)
      .then((cache) => cache.addAll(APP_SHELL))
  )
  self.skipWaiting()
})

// ─── Activate ─────────────────────────────────────────────────────────────────
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((k) => k !== CACHE_VERSION)
          .map((k) => caches.delete(k))
      )
    ).then(() => self.clients.claim())
  )
})

// ─── Fetch ────────────────────────────────────────────────────────────────────
self.addEventListener('fetch', (event) => {
  const { request } = event
  const url = new URL(request.url)

  if (url.origin !== self.location.origin) return

  // Navigation (HTML): network-first with a fallback to the app shell.
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (response.status === 200) {
            const clone = response.clone()
            caches.open(CACHE_VERSION).then((cache) => cache.put(request, clone))
          }
          return response
        })
        .catch(() =>
          caches.match(request)
            .then((cached) => cached || caches.match('/'))
        )
    )
    return
  }

  // API: network-first, cache successful GETs from the relevant endpoints
  if (url.pathname.startsWith('/api/')) {
    if (request.method !== 'GET') return

    event.respondWith(
      fetch(request)
        .then((response) => {
          if (response.status === 200 && shouldCacheAPI(url.pathname)) {
            const clone = response.clone()
            caches.open(CACHE_VERSION).then((cache) => cache.put(request, clone))
          }
          return response
        })
        .catch(() =>
          caches.match(request).then((cached) => {
            if (cached) return cached
            return new Response(
              JSON.stringify({
                error: 'Sin conexion. Los datos pueden estar desactualizados.',
                offline: true,
              }),
              { headers: { 'Content-Type': 'application/json' }, status: 503 }
            )
          })
        )
    )
    return
  }

  // Static assets: stale-while-revalidate
  event.respondWith(
    caches.match(request).then((cached) => {
      const fetchPromise = fetch(request)
        .then((response) => {
          if (response && response.status === 200 && response.type === 'basic') {
            const clone = response.clone()
            caches.open(CACHE_VERSION).then((cache) => cache.put(request, clone))
          }
          return response
        })
        .catch(() => cached)

      return cached || fetchPromise
    })
  )
})

// ─── Push Notifications ───────────────────────────────────────────────────────
self.addEventListener('push', (event) => {
  if (!event.data) return

  let data = {}
  try {
    data = event.data.json()
  } catch {
    data = { title: 'Arche GMAO', body: event.data.text() }
  }

  const options = {
    body: data.body || '',
    icon: '/icons/icon-192.png',
    badge: '/icons/icon-96.svg',
    tag: data.tag || 'arche-notif',
    data: { url: data.url || '/work-orders' },
    vibrate: [200, 100, 200],
    actions: data.actions || [],
    requireInteraction: data.urgent || false,
    renotify: !!data.tag,
  }

  event.waitUntil(
    self.registration.showNotification(data.title || 'Arche GMAO', options)
  )
})

// ─── Notification click ───────────────────────────────────────────────────────
self.addEventListener('notificationclick', (event) => {
  event.notification.close()
  const url = event.notification.data?.url || '/'

  event.waitUntil(
    self.clients
      .matchAll({ type: 'window', includeUncontrolled: true })
      .then((windowClients) => {
        for (const client of windowClients) {
          if (client.url.includes(self.location.origin) && 'focus' in client) {
            client.navigate(url)
            return client.focus()
          }
        }
        if (self.clients.openWindow) {
          return self.clients.openWindow(url)
        }
      })
  )
})

// ─── Background sync ─────────────────────────────────────────────────────────
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-wos') {
    event.waitUntil(syncPendingData())
  }
})

async function syncPendingData() {
  // Tell the app to process the offline operation queue
  const clients = await self.clients.matchAll({ type: 'window' })
  for (const client of clients) {
    client.postMessage({ type: 'sync-operations' })
  }

  // Refresh the GET cache
  const cache = await caches.open(CACHE_VERSION)
  const keys = await cache.keys()
  for (const request of keys) {
    if (request.url.includes('/api/') && request.method === 'GET') {
      try {
        const response = await fetch(request)
        if (response.status === 200) {
          await cache.put(request, response)
        }
      } catch {}
    }
  }
}

// ─── Control message from the app ─────────────────────────────────────────
self.addEventListener('message', (event) => {
  if (event.data === 'skipWaiting') {
    self.skipWaiting()
  }
})
