#!/bin/bash
# Generates placeholder SVG->PNG icons for the Arche GMAO PWA.
# Requires Inkscape or rsvg-convert. When neither is available, it emits SVG.
# For production: replace the PNGs in public/icons/ with the real logo.

ICON_DIR="$(dirname "$0")/../public/icons"
mkdir -p "$ICON_DIR"

SIZES=(72 96 128 144 152 192 384 512)
BG="#1A1A2E"
FG="#FFFFFF"
TEXT="AP"

generate_svg() {
  local size=$1
  local file="$ICON_DIR/icon-${size}.svg"
  local font_size=$((size * 38 / 100))
  local sub_size=$((size * 12 / 100))
  local cy=$((size * 45 / 100))
  local sub_y=$((size * 68 / 100))

  cat > "$file" << SVGEOF
<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
  <rect width="${size}" height="${size}" rx="${size:0:1}0" fill="${BG}"/>
  <text x="50%" y="${cy}" text-anchor="middle" dominant-baseline="central" font-family="Inter,Helvetica,Arial,sans-serif" font-weight="800" font-size="${font_size}" fill="${FG}" letter-spacing="2">${TEXT}</text>
  <text x="50%" y="${sub_y}" text-anchor="middle" font-family="Inter,Helvetica,Arial,sans-serif" font-weight="400" font-size="${sub_size}" fill="rgba(255,255,255,0.5)">SYSTEMS</text>
</svg>
SVGEOF
  echo "  SVG: $file"
}

generate_maskable_svg() {
  local size=$1
  local file="$ICON_DIR/icon-maskable-${size}.svg"
  local safe=$((size * 80 / 100))
  local pad=$((size * 10 / 100))
  local font_size=$((safe * 38 / 100))
  local sub_size=$((safe * 12 / 100))
  local cy=$((size * 45 / 100))
  local sub_y=$((size * 65 / 100))

  cat > "$file" << SVGEOF
<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
  <rect width="${size}" height="${size}" fill="${BG}"/>
  <text x="50%" y="${cy}" text-anchor="middle" dominant-baseline="central" font-family="Inter,Helvetica,Arial,sans-serif" font-weight="800" font-size="${font_size}" fill="${FG}" letter-spacing="2">${TEXT}</text>
  <text x="50%" y="${sub_y}" text-anchor="middle" font-family="Inter,Helvetica,Arial,sans-serif" font-weight="400" font-size="${sub_size}" fill="rgba(255,255,255,0.5)">SYSTEMS</text>
</svg>
SVGEOF
  echo "  SVG maskable: $file"
}

convert_to_png() {
  local svg="$1"
  local png="${svg%.svg}.png"
  local size="$2"

  if command -v rsvg-convert &> /dev/null; then
    rsvg-convert -w "$size" -h "$size" "$svg" -o "$png" && rm "$svg"
    echo "  PNG: $png"
  elif command -v inkscape &> /dev/null; then
    inkscape -w "$size" -h "$size" "$svg" -o "$png" 2>/dev/null && rm "$svg"
    echo "  PNG: $png"
  elif command -v convert &> /dev/null; then
    convert -background none -size "${size}x${size}" "$svg" "$png" && rm "$svg"
    echo "  PNG: $png"
  else
    echo "  (sin conversor PNG disponible, se mantiene SVG)"
  fi
}

echo "Generando iconos Arche GMAO..."
echo "Directorio: $ICON_DIR"
echo ""

for size in "${SIZES[@]}"; do
  generate_svg "$size"
  convert_to_png "$ICON_DIR/icon-${size}.svg" "$size"
done

# Maskable icons (192 and 512)
generate_maskable_svg 192
convert_to_png "$ICON_DIR/icon-maskable-192.svg" 192
generate_maskable_svg 512
convert_to_png "$ICON_DIR/icon-maskable-512.svg" 512

# Favicon
if [ -f "$ICON_DIR/icon-96.png" ]; then
  cp "$ICON_DIR/icon-96.png" "$ICON_DIR/favicon.png"
  echo ""
  echo "  Favicon copiado: $ICON_DIR/favicon.png"
fi

echo ""
echo "Iconos generados. Para produccion: sustituir los PNG con el logo real de Arche GMAO."
echo "Todos los archivos estan en: $ICON_DIR/"
