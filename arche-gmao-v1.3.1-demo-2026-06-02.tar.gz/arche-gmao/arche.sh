#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# Arche GMAO — Full deployment script
# Run by the Arche GMAO administrator on the client server.
#
# Usage: sudo ./arche.sh [options]
#
# Options:
#   --domain DOMAIN       Domain for SSL (e.g. cmms.company.com)
#   --ssl auto|self|none  SSL mode (auto=certbot, self=self-signed, none=HTTP)
#   --binary PATH         Path to the arche-server binary (default: ./arche-server)
#   --migrations PATH     Path to the migrations directory (default: ./migrations)
#   --tenant NAME         Client company name
#
# Phases:
#   1. Operating system and SELinux detection
#   2. Port check
#   3. Dependency and Docker installation
#   4. Directory structure and secrets
#   5. PostgreSQL + Redis in Docker
#   6. Binary and systemd service installation
#   7. Ollama + AI model selection
#   8. Nginx + SSL
#   9. DB initialization + Arche GMAO superadmin
#  10. Hardware fingerprint
#  11. Final verification
# ─────────────────────────────────────────────────────────────────────────────

set -euo pipefail

# ─── Constants ─────────────────────────────────────────────────────────────

INSTALL_DIR="/opt/arche-gmao"
CONFIG_DIR="/etc/arche"
CONFIG_FILE="$CONFIG_DIR/config.env"
SUPERADMIN_FILE="/root/.arche-superadmin"
HARDWARE_FILE="$INSTALL_DIR/hardware.conf"
SERVICE_NAME="arche-gmao"
API_PORT=3000
DB_PORT=5432
REDIS_PORT=6379
HEALTH_URL="http://localhost:$API_PORT/api/v1/health"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# ─── Helpers ────────────────────────────────────────────────────────────────

log()   { echo -e "${CYAN}[ARCHE]${NC} $1"; }
ok()    { echo -e "${GREEN}[OK]${NC}    $1"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $1"; }
fail()  { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }
phase() { echo ""; echo -e "${BOLD}════ Fase $1 ════${NC}"; echo ""; }

db_exec()    { docker compose -f "$INSTALL_DIR/docker-compose.yml" exec -T postgres "$@"; }
redis_exec() { docker compose -f "$INSTALL_DIR/docker-compose.yml" exec -T redis "$@"; }

gen_password() {
  openssl rand -base64 "$1" 2>/dev/null | tr -d '/+=\n' | head -c "$1"
}

# ─── Arguments ─────────────────────────────────────────────────────────────

DOMAIN=""
SSL_MODE=""
BINARY_PATH=""
MIGRATIONS_PATH=""
TENANT_NAME=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --domain)     DOMAIN="$2";          shift 2 ;;
    --ssl)        SSL_MODE="$2";        shift 2 ;;
    --binary)     BINARY_PATH="$2";     shift 2 ;;
    --migrations) MIGRATIONS_PATH="$2"; shift 2 ;;
    --tenant)     TENANT_NAME="$2";     shift 2 ;;
    -h|--help)
      sed -n '2,/^# ──/p' "$0" | head -n -1 | sed 's/^# \?//'
      exit 0 ;;
    *) fail "Opcion desconocida: $1. Usa --help para ver opciones." ;;
  esac
done

# ─── Check for root ─────────────────────────────────────────────────────────

if [ "$(id -u)" -ne 0 ]; then
  fail "Este script debe ejecutarse como root: sudo ./arche.sh [opciones]"
fi

# ─── Resolve paths ─────────────────────────────────────────────────────────

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

if [ -z "$BINARY_PATH" ]; then
  if [ -f "$SCRIPT_DIR/arche-server" ]; then
    BINARY_PATH="$SCRIPT_DIR/arche-server"
  elif [ -f "./arche-server" ]; then
    BINARY_PATH="$(pwd)/arche-server"
  else
    fail "Binario arche-server no encontrado. Usa --binary RUTA o coloca el binario junto a este script."
  fi
fi
[[ "$BINARY_PATH" != /* ]] && BINARY_PATH="$(pwd)/$BINARY_PATH"
[ -f "$BINARY_PATH" ] || fail "Binario no encontrado: $BINARY_PATH"

if [ -z "$MIGRATIONS_PATH" ]; then
  if [ -d "$SCRIPT_DIR/migrations" ]; then
    MIGRATIONS_PATH="$SCRIPT_DIR/migrations"
  elif [ -d "./migrations" ]; then
    MIGRATIONS_PATH="$(pwd)/migrations"
  else
    MIGRATIONS_PATH=""
    warn "Directorio migrations/ no encontrado — las migraciones se aplicaran desde el binario"
  fi
fi
if [ -n "$MIGRATIONS_PATH" ]; then
  [[ "$MIGRATIONS_PATH" != /* ]] && MIGRATIONS_PATH="$(pwd)/$MIGRATIONS_PATH"
  [ -d "$MIGRATIONS_PATH" ] || { warn "Directorio de migraciones no encontrado: $MIGRATIONS_PATH"; MIGRATIONS_PATH=""; }
fi

# Check that it is a Linux executable
if ! file "$BINARY_PATH" | grep -q "ELF.*executable"; then
  fail "El archivo no es un ejecutable Linux valido: $BINARY_PATH"
fi

echo ""
echo -e "${BOLD}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}║          Arche GMAO — Instalacion de produccion          ║${NC}"
echo -e "${BOLD}║              Sistema de Mantenimiento Industrial           ║${NC}"
echo -e "${BOLD}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""

# ═══════════════════════════════════════════════════════════════════════════
# PHASE 1: Operating system detection
# ═══════════════════════════════════════════════════════════════════════════

phase "1/11: Deteccion del sistema operativo"

if [ ! -f /etc/os-release ]; then
  fail "No se puede detectar el sistema operativo (/etc/os-release no existe)"
fi

# shellcheck source=/dev/null
source /etc/os-release

DISTRO_ID="$ID"
DISTRO_NAME="$PRETTY_NAME"
DISTRO_VERSION="${VERSION_ID:-unknown}"

case "$ID" in
  ubuntu|debian)
    PKG_MGR="apt"
    PKG_UPDATE="apt-get update -qq"
    PKG_INSTALL="apt-get install -y -qq"
    NGINX_CONF_DIR="/etc/nginx/conf.d"
    NGINX_DEFAULT="/etc/nginx/sites-enabled/default"
    CERTBOT_PKG="certbot python3-certbot-nginx"
    ;;
  fedora)
    PKG_MGR="dnf"
    PKG_UPDATE="dnf check-update || true"
    PKG_INSTALL="dnf install -y -q"
    NGINX_CONF_DIR="/etc/nginx/conf.d"
    NGINX_DEFAULT="/etc/nginx/conf.d/default.conf"
    CERTBOT_PKG="certbot python3-certbot-nginx"
    ;;
  centos|rhel|rocky|almalinux)
    if command -v dnf &>/dev/null; then
      PKG_MGR="dnf"
      PKG_UPDATE="dnf check-update || true"
      PKG_INSTALL="dnf install -y -q"
    else
      PKG_MGR="yum"
      PKG_UPDATE="yum check-update || true"
      PKG_INSTALL="yum install -y -q"
    fi
    NGINX_CONF_DIR="/etc/nginx/conf.d"
    NGINX_DEFAULT="/etc/nginx/conf.d/default.conf"
    CERTBOT_PKG="certbot python3-certbot-nginx"
    ;;
  *)
    fail "Distribucion '$ID' no soportada. Soportadas: Ubuntu, Debian, Fedora, CentOS, RHEL, Rocky Linux, AlmaLinux."
    ;;
esac

ok "Sistema: $DISTRO_NAME"
log "Gestor de paquetes: $PKG_MGR"

# SELinux
SELINUX_ACTIVE=false
if command -v getenforce &>/dev/null; then
  SELINUX_STATUS=$(getenforce)
  if [ "$SELINUX_STATUS" != "Disabled" ]; then
    SELINUX_ACTIVE=true
    ok "SELinux detectado: $SELINUX_STATUS (se configurara sin desactivar)"
  else
    log "SELinux: desactivado"
  fi
else
  log "SELinux: no presente"
fi

# System info
RAM_GB=$(awk '/MemTotal/ {printf "%d", $2/1024/1024}' /proc/meminfo)
CPU_CORES=$(nproc)
GPU_INFO=$(lspci 2>/dev/null | grep -iE 'vga|3d|display' | grep -iv 'virtual' | head -1 | sed 's/.*: //' || echo "")
NVIDIA_GPU=false
if echo "$GPU_INFO" | grep -qi nvidia; then
  NVIDIA_GPU=true
fi

log "Hardware: ${RAM_GB}GB RAM, ${CPU_CORES} nucleos CPU"
if [ -n "$GPU_INFO" ]; then
  log "GPU: $GPU_INFO"
else
  log "GPU: no detectada (IA usara CPU)"
fi


# ═══════════════════════════════════════════════════════════════════════════
# PHASE 2: Port check
# ═══════════════════════════════════════════════════════════════════════════

phase "2/11: Verificacion de puertos"

find_free_port() {
  local BASE=$1
  local PORT=$BASE
  while ss -tlnp 2>/dev/null | grep -q ":${PORT} "; do
    PORT=$((PORT + 1))
    if [ "$PORT" -gt $((BASE + 100)) ]; then
      return 1
    fi
  done
  echo "$PORT"
}

# Auto-reassign internal ports (API, DB, Redis) if they are taken
for PAIR in "API_PORT:$API_PORT" "DB_PORT:$DB_PORT" "REDIS_PORT:$REDIS_PORT"; do
  VARNAME="${PAIR%%:*}"
  PORT="${PAIR##*:}"
  LISTENER=$(ss -tlnp 2>/dev/null | grep ":${PORT} " | head -1 || true)
  if [ -n "$LISTENER" ]; then
    PROC=$(echo "$LISTENER" | grep -oP 'users:\(\("\K[^"]+' || echo "desconocido")
    NEW_PORT=$(find_free_port "$PORT")
    if [ -n "$NEW_PORT" ]; then
      warn "Puerto $PORT ($VARNAME) en uso por $PROC — reasignado automaticamente a $NEW_PORT"
      eval "$VARNAME=$NEW_PORT"
    else
      fail "Puerto $PORT ($VARNAME) en uso y no hay alternativa libre en rango $PORT-$((PORT+100))"
    fi
  else
    ok "Puerto $PORT ($VARNAME): disponible"
  fi
done

# Update HEALTH_URL with the final port
HEALTH_URL="http://localhost:$API_PORT/api/v1/health"

# Check public ports (80, 443) — these require an operator decision
PORTS_BLOCKED=false
for PORT in 80 443; do
  LISTENER=$(ss -tlnp 2>/dev/null | grep ":${PORT} " | head -1 || true)
  if [ -n "$LISTENER" ]; then
    PROC=$(echo "$LISTENER" | grep -oP 'users:\(\("\K[^"]+' || echo "desconocido")
    warn "Puerto $PORT en uso por: $PROC"
    PORTS_BLOCKED=true
  else
    ok "Puerto $PORT: disponible"
  fi
done

if [ "$PORTS_BLOCKED" = true ]; then
  echo ""
  warn "Los puertos 80/443 (Nginx) estan ocupados."
  warn "Si otro servidor web los usa, configura un proxy inverso manualmente."
  read -rp "  Continuar de todos modos? (s/N): " CONTINUE
  if [[ ! "$CONTINUE" =~ ^[sS]$ ]]; then
    fail "Instalacion cancelada por el usuario."
  fi
fi

log "Puertos finales: API=$API_PORT, DB=$DB_PORT, Redis=$REDIS_PORT"


# ═══════════════════════════════════════════════════════════════════════════
# PHASE 3: Dependencies and Docker
# ═══════════════════════════════════════════════════════════════════════════

phase "3/11: Instalacion de dependencias y Docker"

log "Actualizando indice de paquetes..."
$PKG_UPDATE >/dev/null 2>&1

# Base
log "Instalando paquetes base..."
case "$PKG_MGR" in
  apt)
    $PKG_INSTALL curl wget openssl ca-certificates gnupg lsb-release \
      jq file net-tools >/dev/null 2>&1
    ;;
  dnf|yum)
    $PKG_INSTALL curl wget openssl ca-certificates gnupg2 \
      jq file net-tools >/dev/null 2>&1
    ;;
esac
ok "Paquetes base instalados"

# Docker
if command -v docker &>/dev/null && docker compose version &>/dev/null; then
  ok "Docker ya instalado: $(docker --version | cut -d' ' -f3 | tr -d ',')"
else
  log "Instalando Docker desde repositorios oficiales..."

  case "$PKG_MGR" in
    apt)
      # Remove non-official packages
      for pkg in docker.io docker-doc docker-compose podman-docker containerd runc; do
        apt-get remove -y -qq "$pkg" 2>/dev/null || true
      done

      install -m 0755 -d /etc/apt/keyrings
      curl -fsSL "https://download.docker.com/linux/${ID}/gpg" | \
        gpg --dearmor -o /etc/apt/keyrings/docker.gpg 2>/dev/null
      chmod a+r /etc/apt/keyrings/docker.gpg

      # shellcheck disable=SC1091
      CODENAME=$(. /etc/os-release && echo "$VERSION_CODENAME")
      echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
        https://download.docker.com/linux/${ID} ${CODENAME} stable" > \
        /etc/apt/sources.list.d/docker.list

      apt-get update -qq >/dev/null 2>&1
      $PKG_INSTALL docker-ce docker-ce-cli containerd.io docker-compose-plugin >/dev/null 2>&1
      ;;

    dnf|yum)
      $PKG_INSTALL yum-utils >/dev/null 2>&1 || true

      DOCKER_REPO_DISTRO="$ID"
      # Rocky/Alma/RHEL use the CentOS repo
      case "$ID" in
        rocky|almalinux|rhel) DOCKER_REPO_DISTRO="centos" ;;
      esac

      if command -v dnf &>/dev/null; then
        dnf config-manager --add-repo \
          "https://download.docker.com/linux/${DOCKER_REPO_DISTRO}/docker-ce.repo" 2>/dev/null
      else
        yum-config-manager --add-repo \
          "https://download.docker.com/linux/${DOCKER_REPO_DISTRO}/docker-ce.repo" 2>/dev/null
      fi

      $PKG_INSTALL docker-ce docker-ce-cli containerd.io docker-compose-plugin >/dev/null 2>&1
      ;;
  esac

  systemctl enable docker >/dev/null 2>&1
  systemctl start docker

  if ! docker compose version &>/dev/null; then
    fail "Docker Compose no se instalo correctamente."
  fi

  ok "Docker instalado: $(docker --version | cut -d' ' -f3 | tr -d ',')"
fi

# SELinux — set up contexts for Docker and Nginx
if [ "$SELINUX_ACTIVE" = true ]; then
  log "Configurando SELinux para Docker y Nginx..."

  # Allow Nginx to connect to network ports (proxy_pass)
  setsebool -P httpd_can_network_connect 1 2>/dev/null || true

  # Allow containers to manage cgroups
  setsebool -P container_manage_cgroup 1 2>/dev/null || true

  # API port for Nginx
  if command -v semanage &>/dev/null; then
    semanage port -a -t http_port_t -p tcp $API_PORT 2>/dev/null || \
    semanage port -m -t http_port_t -p tcp $API_PORT 2>/dev/null || true
  else
    warn "semanage no disponible — instala policycoreutils-python-utils si hay problemas con SELinux"
  fi

  ok "SELinux configurado (sin desactivar)"
fi


# ═══════════════════════════════════════════════════════════════════════════
# PHASE 4: Directory structure and secrets
# ═══════════════════════════════════════════════════════════════════════════

phase "4/11: Estructura de directorios y secretos"

# Directories
for DIR in \
  "$INSTALL_DIR" \
  "$INSTALL_DIR/data/postgres" \
  "$INSTALL_DIR/data/redis" \
  "$INSTALL_DIR/data/uploads" \
  "$INSTALL_DIR/backups" \
  "$INSTALL_DIR/migrations" \
  "$INSTALL_DIR/logs" \
  "$CONFIG_DIR" \
  "$CONFIG_DIR/ssl"; do
  mkdir -p "$DIR"
done
ok "Directorios creados en $INSTALL_DIR y $CONFIG_DIR"

# Copy migrations (if an external directory is available)
if [ -n "$MIGRATIONS_PATH" ]; then
  cp -r "$MIGRATIONS_PATH"/*.sql "$INSTALL_DIR/migrations/" 2>/dev/null || true
  MIGRATION_COUNT=$(ls -1 "$INSTALL_DIR/migrations/"*.sql 2>/dev/null | wc -l)
  ok "Copiadas $MIGRATION_COUNT migraciones"
else
  ok "Migraciones embebidas en el binario — se aplicaran al arrancar"
fi

# Generate secrets (only if they do not exist)
if [ -f "$CONFIG_FILE" ]; then
  warn "Config existente detectado: $CONFIG_FILE"
  read -rp "  Sobrescribir secretos? Se perderan los actuales. (s/N): " OVERWRITE
  if [[ ! "$OVERWRITE" =~ ^[sS]$ ]]; then
    log "Conservando config existente"
    # Load existing variables
    # shellcheck source=/dev/null
    source "$CONFIG_FILE"
    SECRETS_GENERATED=false
  else
    SECRETS_GENERATED=true
  fi
else
  SECRETS_GENERATED=true
fi

if [ "$SECRETS_GENERATED" = true ]; then
  DB_PASSWORD=$(gen_password 32)
  REDIS_PASSWORD=$(gen_password 32)
  JWT_SECRET=$(gen_password 64)
  JWT_REFRESH_SECRET=$(gen_password 64)

  # Ask for the domain if it was not provided
  if [ -z "$DOMAIN" ]; then
    echo ""
    read -rp "  Dominio del servidor (dejar vacio para usar IP): " DOMAIN
  fi

  # Determine base URL
  if [ -n "$DOMAIN" ]; then
    BASE_URL="https://$DOMAIN"
  else
    SERVER_IP=$(hostname -I | awk '{print $1}')
    BASE_URL="http://$SERVER_IP"
  fi

  cat > "$CONFIG_FILE" << EOF
# ─────────────────────────────────────────────────────────────
# Arche GMAO — Production configuration
# Generado: $(date '+%Y-%m-%d %H:%M:%S')
# NO EDITAR los secretos manualmente a menos que sea necesario.
# ─────────────────────────────────────────────────────────────

# Base de datos
DB_HOST=localhost
DB_PORT=$DB_PORT
DB_NAME=arche
DB_USER=arche
DB_PASSWORD=$DB_PASSWORD
DB_SSLMODE=disable
DATABASE_URL=postgres://arche:${DB_PASSWORD}@localhost:${DB_PORT}/arche?sslmode=disable

# Redis
REDIS_HOST=localhost
REDIS_PORT=$REDIS_PORT
REDIS_PASSWORD=$REDIS_PASSWORD
REDIS_URL=redis://:${REDIS_PASSWORD}@localhost:${REDIS_PORT}

# JWT
JWT_SECRET=$JWT_SECRET
JWT_REFRESH_SECRET=$JWT_REFRESH_SECRET
JWT_EXPIRY=15m
JWT_REFRESH_EXPIRY=7d

# Servidor
PORT=$API_PORT
CORS_ORIGINS=$BASE_URL
APP_BASE_URL=$BASE_URL

# Ollama
OLLAMA_URL=http://localhost:11434
OLLAMA_CHAT_MODEL=llama3
OLLAMA_EMBED_MODEL=nomic-embed-text
EOF

  chmod 600 "$CONFIG_FILE"
  ok "Secretos generados y guardados en $CONFIG_FILE (permisos 600)"
fi

# Load config for use in later phases
# shellcheck source=/dev/null
source "$CONFIG_FILE"


# ═══════════════════════════════════════════════════════════════════════════
# PHASE 5: PostgreSQL + Redis in Docker
# ═══════════════════════════════════════════════════════════════════════════

phase "5/11: PostgreSQL + Redis en Docker"

# Generate docker-compose.yml
cat > "$INSTALL_DIR/docker-compose.yml" << COMPOSE_EOF
services:
  postgres:
    image: pgvector/pgvector:pg16
    restart: unless-stopped
    environment:
      POSTGRES_USER: arche
      POSTGRES_PASSWORD: \${DB_PASSWORD}
      POSTGRES_DB: arche
    volumes:
      - ./data/postgres:/var/lib/postgresql/data
      - ./migrations:/docker-entrypoint-initdb.d:ro
    ports:
      - "127.0.0.1:${DB_PORT}:5432"
    deploy:
      resources:
        limits:
          memory: 512M
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U arche -d arche"]
      interval: 10s
      timeout: 5s
      retries: 10
    security_opt:
      - no-new-privileges:true
    shm_size: '256mb'

  redis:
    image: redis:7-alpine
    restart: unless-stopped
    command: >
      redis-server
      --requirepass \${REDIS_PASSWORD}
      --maxmemory 128mb
      --maxmemory-policy allkeys-lru
      --rename-command FLUSHALL ""
      --rename-command FLUSHDB ""
      --rename-command DEBUG ""
    volumes:
      - ./data/redis:/data
    ports:
      - "127.0.0.1:${REDIS_PORT}:6379"
    deploy:
      resources:
        limits:
          memory: 256M
    healthcheck:
      test: ["CMD-SHELL", "redis-cli -a \$\${REDIS_PASSWORD} ping | grep -q PONG"]
      interval: 10s
      timeout: 5s
      retries: 5
    security_opt:
      - no-new-privileges:true
COMPOSE_EOF

ok "docker-compose.yml generado"

# Create .env for Docker Compose (symlink to the config)
ln -sf "$CONFIG_FILE" "$INSTALL_DIR/.env"

# Bring up containers
log "Descargando imagenes e iniciando contenedores..."
cd "$INSTALL_DIR"
docker compose pull --quiet 2>/dev/null
docker compose up -d 2>/dev/null

# Wait for PostgreSQL to be ready
log "Esperando a PostgreSQL..."
PG_READY=false
for i in $(seq 1 60); do
  if db_exec pg_isready -U arche -d arche -q 2>/dev/null; then
    PG_READY=true
    break
  fi
  sleep 1
done

if [ "$PG_READY" = true ]; then
  ok "PostgreSQL listo (${i}s)"
else
  fail "PostgreSQL no arranco en 60 segundos. Revisar: docker compose -f $INSTALL_DIR/docker-compose.yml logs postgres"
fi

# Wait for Redis
log "Esperando a Redis..."
REDIS_READY=false
for i in $(seq 1 30); do
  if redis_exec redis-cli -a "$REDIS_PASSWORD" ping 2>/dev/null | grep -q PONG; then
    REDIS_READY=true
    break
  fi
  sleep 1
done

if [ "$REDIS_READY" = true ]; then
  ok "Redis listo (${i}s)"
else
  fail "Redis no arranco en 30 segundos. Revisar: docker compose -f $INSTALL_DIR/docker-compose.yml logs redis"
fi


# ═══════════════════════════════════════════════════════════════════════════
# PHASE 6: Binary and systemd service
# ═══════════════════════════════════════════════════════════════════════════

phase "6/11: Instalacion del binario y servicio systemd"

# Copy binary
cp "$BINARY_PATH" "$INSTALL_DIR/arche-server"
chmod 755 "$INSTALL_DIR/arche-server"

# Copy checksum if present
if [ -f "${BINARY_PATH}.sha256" ]; then
  cp "${BINARY_PATH}.sha256" "$INSTALL_DIR/arche-server.sha256"
fi

# Copy update.sh if it sits next to the script or the binary
for UPD_SRC in "$SCRIPT_DIR/update.sh" "$(dirname "$BINARY_PATH")/update.sh"; do
  if [ -f "$UPD_SRC" ]; then
    cp "$UPD_SRC" "$INSTALL_DIR/update.sh"
    chmod 755 "$INSTALL_DIR/update.sh"
    break
  fi
done

ok "Binario instalado en $INSTALL_DIR/arche-server"

# Create the system user (if it does not exist)
if ! id arche &>/dev/null; then
  useradd --system --home-dir "$INSTALL_DIR" --shell /usr/sbin/nologin --no-create-home arche
  usermod -aG docker arche
  ok "Usuario 'arche' creado y añadido al grupo docker"
else
  usermod -aG docker arche 2>/dev/null || true
  ok "Usuario 'arche' ya existe"
fi

# Permissions
chown -R arche:arche "$INSTALL_DIR/data/uploads" "$INSTALL_DIR/logs"
chown arche:arche "$INSTALL_DIR/arche-server"

# systemd service
cat > /etc/systemd/system/${SERVICE_NAME}.service << EOF
[Unit]
Description=Arche GMAO CMMS
Documentation=https://arche-gmao.com
After=network.target docker.service
Wants=docker.service

[Service]
Type=simple
User=arche
Group=arche
WorkingDirectory=$INSTALL_DIR
EnvironmentFile=$CONFIG_FILE
ExecStartPre=/bin/bash -c 'for i in \$(seq 1 30); do docker compose -f $INSTALL_DIR/docker-compose.yml exec -T postgres pg_isready -U arche -q 2>/dev/null && exit 0; sleep 1; done; echo "PostgreSQL no disponible"; exit 1'
ExecStart=$INSTALL_DIR/arche-server
Restart=on-failure
RestartSec=5
LimitNOFILE=65536

# Seguridad
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=$INSTALL_DIR/data/uploads $INSTALL_DIR/logs
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable "$SERVICE_NAME" >/dev/null 2>&1
ok "Servicio systemd '$SERVICE_NAME' creado y habilitado"


# ═══════════════════════════════════════════════════════════════════════════
# PHASE 7: Ollama + AI model selection
# ═══════════════════════════════════════════════════════════════════════════

phase "7/11: Ollama + seleccion de modelo IA"

# Detect hardware to make a suggestion
log "Hardware detectado: ${RAM_GB}GB RAM, ${CPU_CORES} nucleos"
if [ "$NVIDIA_GPU" = true ]; then
  log "GPU NVIDIA detectada — aceleracion GPU disponible"
fi

# Suggest a model
if [ "$RAM_GB" -ge 32 ] && [ "$NVIDIA_GPU" = true ]; then
  SUGGESTED_MODEL="llama3"
  SUGGESTED_NOTE="Optimo — RAM y GPU sobradas"
elif [ "$RAM_GB" -ge 16 ]; then
  SUGGESTED_MODEL="llama3"
  SUGGESTED_NOTE="Recomendado — buen rendimiento"
elif [ "$RAM_GB" -ge 8 ]; then
  SUGGESTED_MODEL="llama3"
  SUGGESTED_NOTE="Funcional — puede ser lento en consultas complejas"
elif [ "$RAM_GB" -ge 4 ]; then
  SUGGESTED_MODEL="phi3:mini"
  SUGGESTED_NOTE="Ligero — capacidad limitada pero funcional"
else
  SUGGESTED_MODEL="tinyllama"
  SUGGESTED_NOTE="Minimo — RAM muy limitada"
fi

# Install Ollama
if command -v ollama &>/dev/null; then
  ok "Ollama ya instalado: $(ollama --version 2>/dev/null | head -1)"
else
  log "Instalando Ollama..."
  curl -fsSL https://ollama.ai/install.sh | sh >/dev/null 2>&1
  ok "Ollama instalado"
fi

# Make sure Ollama listens on localhost (for the local binary)
if systemctl is-active --quiet ollama 2>/dev/null; then
  ok "Servicio Ollama activo"
else
  systemctl enable ollama >/dev/null 2>&1 || true
  systemctl start ollama 2>/dev/null || true
  sleep 2
  if systemctl is-active --quiet ollama 2>/dev/null; then
    ok "Servicio Ollama iniciado"
  else
    warn "Ollama no arranca como servicio. Puede requerir configuracion manual."
  fi
fi

# Model table
echo ""
echo -e "${BOLD}  Modelos de chat disponibles:${NC}"
echo "  ┌─────┬──────────────────┬──────────┬──────────────────────────────────┐"
echo "  │  #  │ Modelo           │ RAM min  │ Descripcion                      │"
echo "  ├─────┼──────────────────┼──────────┼──────────────────────────────────┤"
echo "  │  1  │ tinyllama        │   2 GB   │ Minimalista, respuestas basicas  │"
echo "  │  2  │ phi3:mini        │   4 GB   │ Ligero, buen razonamiento        │"
echo "  │  3  │ llama3           │   8 GB   │ Equilibrio ideal (recomendado)   │"
echo "  │  4  │ mistral          │   8 GB   │ Alternativa rapida y competente  │"
echo "  │  5  │ gemma2           │   8 GB   │ Multilingue, buena comprension   │"
echo "  │  6  │ qwen2.5          │   8 GB   │ Rapido, buen razonamiento tecnico│"
echo "  │  7  │ llama3:70b       │  40 GB   │ Avanzado, requiere GPU potente   │"
echo "  └─────┴──────────────────┴──────────┴──────────────────────────────────┘"
echo ""
echo -e "  ${CYAN}Sugerido para este servidor: ${BOLD}${SUGGESTED_MODEL}${NC} (${SUGGESTED_NOTE})"
echo "  Tambien puedes escribir cualquier nombre de modelo de Ollama (ej: codellama, solar)"
echo ""

read -rp "  Selecciona modelo (1-7) o nombre custom [default: $SUGGESTED_MODEL]: " MODEL_CHOICE

case "${MODEL_CHOICE:-3}" in
  1) CHAT_MODEL="tinyllama" ;;
  2) CHAT_MODEL="phi3:mini" ;;
  3) CHAT_MODEL="llama3" ;;
  4) CHAT_MODEL="mistral" ;;
  5) CHAT_MODEL="gemma2" ;;
  6) CHAT_MODEL="qwen2.5" ;;
  7) CHAT_MODEL="llama3:70b" ;;
  *)
    # Custom name
    if [ -n "$MODEL_CHOICE" ]; then
      CHAT_MODEL="$MODEL_CHOICE"
    else
      CHAT_MODEL="$SUGGESTED_MODEL"
    fi
    ;;
esac

log "Descargando modelo de chat: $CHAT_MODEL (esto puede tardar varios minutos)..."
ollama pull "$CHAT_MODEL" 2>&1 | tail -1
ok "Modelo de chat listo: $CHAT_MODEL"

log "Descargando modelo de embeddings: nomic-embed-text (requerido para RAG)..."
ollama pull nomic-embed-text 2>&1 | tail -1
ok "Modelo de embeddings listo"

# Update config.env with the chosen model
sed -i "s|^OLLAMA_CHAT_MODEL=.*|OLLAMA_CHAT_MODEL=$CHAT_MODEL|" "$CONFIG_FILE"
sed -i "s|^OLLAMA_URL=.*|OLLAMA_URL=http://localhost:11434|" "$CONFIG_FILE"


# ═══════════════════════════════════════════════════════════════════════════
# PHASE 8: Nginx + SSL
# ═══════════════════════════════════════════════════════════════════════════

phase "8/11: Nginx + SSL"

# Install Nginx
if command -v nginx &>/dev/null; then
  ok "Nginx ya instalado"
else
  log "Instalando Nginx..."
  $PKG_INSTALL nginx >/dev/null 2>&1
  ok "Nginx instalado"
fi

# Remove the default site if present
if [ -f "$NGINX_DEFAULT" ]; then
  rm -f "$NGINX_DEFAULT"
  log "Sitio default de Nginx eliminado"
fi

# Determine server_name
if [ -n "$DOMAIN" ]; then
  SERVER_NAME="$DOMAIN"
else
  SERVER_NAME="_"
fi

# Generate Nginx configuration (initial HTTP)
cat > "$NGINX_CONF_DIR/arche.conf" << NGINX_EOF
# Arche GMAO — Nginx reverse proxy
# Generado: $(date '+%Y-%m-%d %H:%M:%S')

# Rate limiting
limit_req_zone \$binary_remote_addr zone=arche_api:10m rate=30r/m;
limit_req_zone \$binary_remote_addr zone=arche_login:10m rate=5r/m;
limit_req_zone \$binary_remote_addr zone=arche_upload:10m rate=10r/m;

upstream arche_backend {
    server 127.0.0.1:$API_PORT;
    keepalive 32;
}

server {
    listen 80;
    server_name $SERVER_NAME;

    client_max_body_size 55m;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Permissions-Policy "camera=(), microphone=(), geolocation=()" always;

    # Gzip
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml image/svg+xml;
    gzip_min_length 1000;
    gzip_comp_level 6;
    gzip_vary on;

    # Health check (sin rate limit)
    location = /api/v1/health {
        proxy_pass http://arche_backend;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    # Login (rate limit estricto)
    location = /api/v1/auth/login {
        limit_req zone=arche_login burst=3 nodelay;
        proxy_pass http://arche_backend;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    # API (rate limit general)
    location /api/ {
        limit_req zone=arche_api burst=20 nodelay;
        proxy_pass http://arche_backend;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_http_version 1.1;
        proxy_set_header Connection "";

        # SSE for the AI chat
        proxy_buffering off;
        proxy_cache off;
        proxy_read_timeout 120s;
    }

    # Upload (rate limit)
    location ~ ^/api/v1/(library|attachments) {
        limit_req zone=arche_upload burst=5 nodelay;
        client_max_body_size 55m;
        proxy_pass http://arche_backend;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    # Frontend (todo lo demas — servido por el binario Go)
    location / {
        proxy_pass http://arche_backend;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
NGINX_EOF

ok "Configuracion Nginx generada"

# SSL
if [ -z "$SSL_MODE" ]; then
  if [ -n "$DOMAIN" ]; then
    SSL_MODE="auto"
  else
    echo ""
    echo "  Opciones SSL:"
    echo "    1) self  — Certificado autofirmado (HTTPS sin dominio)"
    echo "    2) none  — Solo HTTP (sin cifrado)"
    echo ""
    read -rp "  Selecciona opcion SSL (1-2) [default: 1]: " SSL_CHOICE
    case "${SSL_CHOICE:-1}" in
      1) SSL_MODE="self" ;;
      2) SSL_MODE="none" ;;
      *) SSL_MODE="self" ;;
    esac
  fi
fi

case "$SSL_MODE" in
  auto)
    log "Configurando SSL con Certbot para $DOMAIN..."

    # Install certbot
    $PKG_INSTALL $CERTBOT_PKG >/dev/null 2>&1

    # We need Nginx running for certbot --nginx
    nginx -t -q 2>/dev/null && systemctl start nginx 2>/dev/null

    echo ""
    read -rp "  Email para avisos de renovacion SSL: " CERT_EMAIL
    CERT_EMAIL="${CERT_EMAIL:-admin@$DOMAIN}"

    if certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos \
       --email "$CERT_EMAIL" --redirect 2>/dev/null; then
      ok "Certificado SSL obtenido y configurado para $DOMAIN"
      # Certbot sets up auto-renewal via a systemd timer or cron
      BASE_URL="https://$DOMAIN"
    else
      warn "Certbot fallo. El dominio debe apuntar a este servidor y el puerto 80 debe ser accesible."
      warn "Continuando con HTTP. Ejecuta certbot manualmente despues."
      BASE_URL="http://$DOMAIN"
    fi
    ;;

  self)
    log "Generando certificado autofirmado..."
    CERT_CN="${DOMAIN:-$(hostname)}"

    openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
      -keyout "$CONFIG_DIR/ssl/privkey.pem" \
      -out "$CONFIG_DIR/ssl/fullchain.pem" \
      -subj "/C=XX/ST=State/L=City/O=Arche GMAO/CN=$CERT_CN" \
      2>/dev/null

    chmod 600 "$CONFIG_DIR/ssl/privkey.pem"

    # Add HTTPS block to the nginx config
    cat >> "$NGINX_CONF_DIR/arche.conf" << SSLNGINX_EOF

# HTTPS con certificado autofirmado
server {
    listen 443 ssl http2;
    server_name $SERVER_NAME;

    ssl_certificate     $CONFIG_DIR/ssl/fullchain.pem;
    ssl_certificate_key $CONFIG_DIR/ssl/privkey.pem;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_ciphers         HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;
    ssl_session_cache   shared:SSL:10m;
    ssl_session_timeout 10m;

    # HSTS
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    client_max_body_size 55m;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Gzip
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml image/svg+xml;
    gzip_min_length 1000;
    gzip_comp_level 6;
    gzip_vary on;

    location = /api/v1/health {
        proxy_pass http://arche_backend;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    location = /api/v1/auth/login {
        limit_req zone=arche_login burst=3 nodelay;
        proxy_pass http://arche_backend;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    location /api/ {
        limit_req zone=arche_api burst=20 nodelay;
        proxy_pass http://arche_backend;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_http_version 1.1;
        proxy_set_header Connection "";
        proxy_buffering off;
        proxy_cache off;
        proxy_read_timeout 120s;
    }

    location ~ ^/api/v1/(library|attachments) {
        limit_req zone=arche_upload burst=5 nodelay;
        client_max_body_size 55m;
        proxy_pass http://arche_backend;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    location / {
        proxy_pass http://arche_backend;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
SSLNGINX_EOF

    SERVER_IP=$(hostname -I | awk '{print $1}')
    BASE_URL="https://$SERVER_IP"
    ok "Certificado autofirmado generado (valido 365 dias)"
    warn "Los navegadores mostraran advertencia de seguridad — esto es normal sin dominio."
    ;;

  none)
    SERVER_IP=$(hostname -I | awk '{print $1}')
    BASE_URL="http://$SERVER_IP"
    ok "Modo HTTP configurado (sin SSL)"
    warn "Las conexiones no estaran cifradas."
    ;;

  *)
    fail "Modo SSL no valido: $SSL_MODE. Usa: auto, self, none"
    ;;
esac

# Update CORS and BASE_URL in the config
sed -i "s|^CORS_ORIGINS=.*|CORS_ORIGINS=$BASE_URL|" "$CONFIG_FILE"
sed -i "s|^APP_BASE_URL=.*|APP_BASE_URL=$BASE_URL|" "$CONFIG_FILE"

# Validate and start Nginx
if nginx -t -q 2>/dev/null; then
  systemctl enable nginx >/dev/null 2>&1
  systemctl restart nginx 2>/dev/null
  ok "Nginx activo y configurado"
else
  fail "Error en la configuracion de Nginx. Revisar: nginx -t"
fi


# ═══════════════════════════════════════════════════════════════════════════
# PHASE 9: DB initialization + superadmin
# ═══════════════════════════════════════════════════════════════════════════

phase "9/11: Inicializacion de BD + superadmin Arche GMAO"

# Wait for the migrations to be applied (first PostgreSQL run)
log "Verificando que las migraciones se aplicaron..."
TABLES_READY=false
for i in $(seq 1 30); do
  TABLE_COUNT=$(db_exec psql -U arche -d arche -tAc \
    "SELECT count(*) FROM information_schema.tables WHERE table_schema='public';" 2>/dev/null || echo "0")
  if [ "$TABLE_COUNT" -gt 30 ]; then
    TABLES_READY=true
    break
  fi
  sleep 2
done

if [ "$TABLES_READY" = true ]; then
  ok "Base de datos inicializada ($TABLE_COUNT tablas)"
else
  fail "Las migraciones no se aplicaron. Revisar: docker compose -f $INSTALL_DIR/docker-compose.yml logs postgres"
fi

# Ask for the tenant name (client company)
if [ -z "$TENANT_NAME" ]; then
  echo ""
  read -rp "  Nombre de la empresa del cliente: " TENANT_NAME
  TENANT_NAME="${TENANT_NAME:-Mi Empresa}"
fi

# Generate the tenant slug
TENANT_SLUG=$(echo "$TENANT_NAME" | tr '[:upper:]' '[:lower:]' | \
  sed 's/[áà]/a/g; s/[éè]/e/g; s/[íì]/i/g; s/[óò]/o/g; s/[úù]/u/g; s/[ñ]/n/g' | \
  sed 's/[^a-z0-9]/-/g' | sed 's/--*/-/g; s/^-//; s/-$//')

# Generate credentials for the client admin
ADMIN_EMAIL="admin@${TENANT_SLUG}.local"
ADMIN_PASSWORD=$(gen_password 16)

# Generate credentials for the Arche GMAO superadmin
SA_EMAIL="superadmin@arche.local"
SA_PASSWORD=$(gen_password 20)

# Create tenant + client admin + superadmin in a single transaction
log "Creando tenant, admin del cliente y superadmin Arche GMAO..."

db_exec psql -U arche -d arche -v ON_ERROR_STOP=1 << SQLEOF
BEGIN;

-- Crear tenant del cliente (si no existe)
INSERT INTO tenants (name, slug, status, plan)
SELECT '$TENANT_NAME', '$TENANT_SLUG', 'active', 'enterprise'
WHERE NOT EXISTS (SELECT 1 FROM tenants WHERE slug = '$TENANT_SLUG');

-- Obtener tenant_id
DO \$\$
DECLARE
  v_tenant_id BIGINT;
  v_admin_exists BOOLEAN;
BEGIN
  SELECT id INTO v_tenant_id FROM tenants WHERE slug = '$TENANT_SLUG';

  -- Verificar si ya existe un admin para este tenant
  SELECT EXISTS(SELECT 1 FROM users WHERE tenant_id = v_tenant_id AND role = 'admin')
    INTO v_admin_exists;

  IF NOT v_admin_exists THEN
    INSERT INTO users (tenant_id, email, password_hash, full_name, role, status, is_primary_admin)
    VALUES (
      v_tenant_id,
      '$ADMIN_EMAIL',
      crypt('$ADMIN_PASSWORD', gen_salt('bf', 10)),
      'Administrador',
      'admin',
      'active',
      TRUE
    );
  END IF;
END \$\$;

-- Crear superadmin Arche GMAO (si no existe)
INSERT INTO superadmin_accounts (email, password_hash, full_name)
SELECT '$SA_EMAIL', crypt('$SA_PASSWORD', gen_salt('bf', 10)), 'Arche GMAO'
WHERE NOT EXISTS (SELECT 1 FROM superadmin_accounts WHERE email = '$SA_EMAIL');

COMMIT;
SQLEOF

if [ $? -eq 0 ]; then
  ok "Tenant '$TENANT_NAME' creado"
  ok "Admin del cliente creado: $ADMIN_EMAIL"
  ok "Superadmin Arche GMAO creado: $SA_EMAIL"
else
  fail "Error al inicializar la base de datos."
fi

# Save the client admin credentials
cat > "$INSTALL_DIR/admin-credentials.txt" << EOF
# ─────────────────────────────────────────────────────────────
# Arche GMAO — Credenciales del administrador
# Generado: $(date '+%Y-%m-%d %H:%M:%S')
# ENTREGAR AL CLIENTE — ELIMINAR DESPUES DE ENTREGAR
# ─────────────────────────────────────────────────────────────
Empresa:   $TENANT_NAME
Email:     $ADMIN_EMAIL
Password:  $ADMIN_PASSWORD
URL:       $BASE_URL
# ─────────────────────────────────────────────────────────────
EOF
chmod 600 "$INSTALL_DIR/admin-credentials.txt"

# Save the superadmin credentials (root only)
cat > "$SUPERADMIN_FILE" << EOF
# ─────────────────────────────────────────────────────────────
# Arche GMAO — Superadmin Arche GMAO
# Generado: $(date '+%Y-%m-%d %H:%M:%S')
# SOLO PARA USO INTERNO DE AP SYSTEMS — NO COMPARTIR
# ─────────────────────────────────────────────────────────────
Email:     $SA_EMAIL
Password:  $SA_PASSWORD
Servidor:  $(hostname)
URL:       $BASE_URL
# ─────────────────────────────────────────────────────────────
EOF
chmod 600 "$SUPERADMIN_FILE"
ok "Credenciales guardadas (permisos 600)"


# ═══════════════════════════════════════════════════════════════════════════
# PHASE 10: Hardware fingerprint
# ═══════════════════════════════════════════════════════════════════════════

phase "10/11: Fingerprint de hardware"

# Machine ID
MACHINE_ID=""
if [ -f /etc/machine-id ]; then
  MACHINE_ID=$(cat /etc/machine-id)
elif [ -f /var/lib/dbus/machine-id ]; then
  MACHINE_ID=$(cat /var/lib/dbus/machine-id)
else
  MACHINE_ID="unknown-$(hostname)"
fi

# MAC of the main interface
PRIMARY_IFACE=$(ip route show default 2>/dev/null | awk '{print $5}' | head -1)
MAC_ADDRESS=""
if [ -n "$PRIMARY_IFACE" ]; then
  MAC_ADDRESS=$(ip link show "$PRIMARY_IFACE" 2>/dev/null | awk '/link\/ether/ {print $2}')
fi

# Server IP
SERVER_IP=$(hostname -I | awk '{print $1}')

# Allowed host (domain or IP)
ALLOWED_HOST="${DOMAIN:-$SERVER_IP}"

# Write hardware.conf
cat > "$HARDWARE_FILE" << EOF
# ─────────────────────────────────────────────────────────────
# Arche GMAO — Registro de hardware
# Generado durante la instalacion: $(date '+%Y-%m-%d %H:%M:%S')
# Este archivo NO debe modificarse manualmente.
# ─────────────────────────────────────────────────────────────
MACHINE_ID=$MACHINE_ID
MAC_ADDRESS=$MAC_ADDRESS
PRIMARY_INTERFACE=$PRIMARY_IFACE
SERVER_IP=$SERVER_IP
ALLOWED_HOST=$ALLOWED_HOST
HOSTNAME=$(hostname)
INSTALL_DATE=$(date '+%Y-%m-%d %H:%M:%S')
EOF
chmod 644 "$HARDWARE_FILE"
ok "Hardware fingerprint generado: $HARDWARE_FILE"

# Register in the database
db_exec psql -U arche -d arche -q << HWSQL
INSERT INTO hardware_registration (machine_id, mac_address, allowed_hosts)
SELECT '$MACHINE_ID', '$MAC_ADDRESS', ARRAY['$ALLOWED_HOST']
WHERE NOT EXISTS (SELECT 1 FROM hardware_registration);
HWSQL
ok "Hardware registrado en base de datos"


# ═══════════════════════════════════════════════════════════════════════════
# PHASE 11: Final verification
# ═══════════════════════════════════════════════════════════════════════════

phase "11/11: Verificacion final"

# Start the service
log "Iniciando Arche GMAO..."
systemctl start "$SERVICE_NAME" 2>/dev/null

# Check startup
STARTED=false
for i in $(seq 1 30); do
  sleep 1
  if ! systemctl is-active --quiet "$SERVICE_NAME" 2>/dev/null; then
    continue
  fi
  HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$HEALTH_URL" 2>/dev/null || echo "000")
  if [ "$HTTP_CODE" = "200" ]; then
    STARTED=true
    break
  fi
done

if [ "$STARTED" = true ]; then
  ok "API arrancada correctamente (${i}s)"
else
  warn "API no responde al health check. Revisar: journalctl -u $SERVICE_NAME -n 20"
fi

# Check every service
echo ""
log "Estado de servicios:"

# PostgreSQL
if db_exec pg_isready -U arche -q 2>/dev/null; then
  ok "  PostgreSQL: activo"
else
  warn "  PostgreSQL: no responde"
fi

# Redis
if redis_exec redis-cli -a "$REDIS_PASSWORD" ping 2>/dev/null | grep -q PONG; then
  ok "  Redis: activo"
else
  warn "  Redis: no responde"
fi

# Ollama
if curl -s http://localhost:11434/api/tags >/dev/null 2>&1; then
  ok "  Ollama: activo"
else
  warn "  Ollama: no responde"
fi

# Nginx
if systemctl is-active --quiet nginx 2>/dev/null; then
  ok "  Nginx: activo"
else
  warn "  Nginx: no activo"
fi

# Arche API
if [ "$STARTED" = true ]; then
  VERSION=$(curl -s "$HEALTH_URL" 2>/dev/null | jq -r '.version // "unknown"' 2>/dev/null || echo "unknown")
  ok "  Arche API: activo (v$VERSION)"
else
  warn "  Arche API: no responde"
fi

# ─── Final summary ──────────────────────────────────────────────────────

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║         Instalacion completada exitosamente                ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${BOLD}Acceso:${NC}"
echo "    URL:          $BASE_URL"
echo ""
echo -e "  ${BOLD}Admin del cliente:${NC}"
echo "    Email:        $ADMIN_EMAIL"
echo "    Password:     $ADMIN_PASSWORD"
echo "    Credenciales: $INSTALL_DIR/admin-credentials.txt"
echo ""
echo -e "  ${BOLD}Superadmin Arche GMAO:${NC}"
echo "    Email:        $SA_EMAIL"
echo "    Ubicacion:    $SUPERADMIN_FILE (solo root)"
echo ""
echo -e "  ${BOLD}Archivos de configuracion:${NC}"
echo "    Config:       $CONFIG_FILE"
echo "    Hardware:     $HARDWARE_FILE"
echo "    Nginx:        $NGINX_CONF_DIR/arche.conf"
echo "    Systemd:      /etc/systemd/system/${SERVICE_NAME}.service"
echo "    Docker:       $INSTALL_DIR/docker-compose.yml"
echo ""
echo -e "  ${BOLD}Comandos utiles:${NC}"
echo "    Estado:       systemctl status $SERVICE_NAME"
echo "    Logs API:     journalctl -u $SERVICE_NAME -f"
echo "    Logs DB:      docker compose -f $INSTALL_DIR/docker-compose.yml logs -f postgres"
echo "    Reiniciar:    systemctl restart $SERVICE_NAME"
echo "    Actualizar:   ./update.sh /ruta/al/nuevo/arche-server"
echo ""

if [ "$SSL_MODE" = "self" ]; then
  echo -e "  ${YELLOW}Nota: SSL autofirmado — los navegadores mostraran advertencia.${NC}"
  echo -e "  ${YELLOW}Para SSL con dominio: certbot --nginx -d tu-dominio.com${NC}"
  echo ""
fi

echo -e "  ${BOLD}Modelo IA:${NC} $CHAT_MODEL + nomic-embed-text"
echo -e "  ${BOLD}Empresa:${NC}  $TENANT_NAME"
echo ""
