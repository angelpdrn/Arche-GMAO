# Arche GMAO — Guia de instalacion

## Requisitos del servidor

| Recurso | Minimo | Recomendado |
|---------|--------|-------------|
| RAM | 4 GB | 8 GB+ |
| CPU | 2 nucleos | 4 nucleos |
| Disco | 20 GB | 50 GB+ |
| SO | Ubuntu 20.04+, Debian 11+, Fedora 38+, CentOS/Rocky/Alma 8+ | Ubuntu 22.04 LTS |

Requiere acceso a internet durante la instalacion (Docker, Ollama, modelos IA).

## 1. Compilar el binario

En la maquina de desarrollo:

```bash
./build.sh
```

Resultado en `build/`: `arche-server` + `arche-server.sha256`.
Requisitos dev: Node.js 20+, Go 1.24+.

## 2. Copiar al servidor

```bash
scp build/arche-server build/arche-server.sha256 arche.sh usuario@servidor:/tmp/
scp -r migrations/ usuario@servidor:/tmp/migrations/
```

## 3. Ejecutar la instalacion

```bash
cd /tmp && sudo ./arche.sh
```

### Opciones

```
sudo ./arche.sh [opciones]
  --domain DOMINIO      Dominio para SSL (ej: cmms.empresa.com)
  --ssl auto|self|none  Modo SSL (auto=certbot, self=autofirmado, none=HTTP)
  --binary RUTA         Ruta al binario arche-server
  --migrations RUTA     Ruta al directorio de migraciones
  --tenant NOMBRE       Nombre de la empresa del cliente
```

Sin opciones, el script pregunta todo de forma interactiva.

### Las 11 fases

| Fase | Que hace |
|------|----------|
| 1 | Detecta SO, SELinux, RAM, CPU, GPU |
| 2 | Verifica puertos. Internos (API, DB, Redis) se reasignan si estan ocupados |
| 3 | Instala dependencias y Docker (omite si ya estan) |
| 4 | Crea directorios, genera secretos en `/etc/arche/config.env` |
| 5 | Levanta PostgreSQL (pgvector:pg16) + Redis (7-alpine) en Docker |
| 6 | Copia binario, crea usuario `arche`, servicio systemd con hardening |
| 7 | Instala Ollama, sugiere modelo segun hardware, descarga modelos |
| 8 | Nginx: proxy reverso, rate limiting, security headers, SSE, SSL |
| 9 | Aplica migraciones, crea tenant + admin del cliente + superadmin |
| 10 | Fingerprint de hardware (machine-id, MAC, IP) |
| 11 | Arranca servicio, health check, muestra credenciales y URLs |

## 4. Verificar

```bash
systemctl status arche-gmao
curl -s http://localhost:$(grep ^PORT /etc/arche/config.env | cut -d= -f2)/api/v1/health | jq .
```

Credenciales en `/opt/arche-gmao/admin-credentials.txt`.

## 5. Entregar al cliente

1. Entregar credenciales de `/opt/arche-gmao/admin-credentials.txt`
2. `rm /opt/arche-gmao/admin-credentials.txt`
3. Indicar que cambie la contrasena en su primer acceso

## Estructura en produccion

```
/opt/arche-gmao/
  arche-server              Binario
  docker-compose.yml        PostgreSQL + Redis
  .env -> /etc/arche/config.env
  hardware.conf             Fingerprint
  data/{postgres,redis,uploads}/
  backups/  migrations/  logs/

/etc/arche/
  config.env                Variables de entorno (600)
  ssl/                      Certificados SSL

/etc/systemd/system/arche-gmao.service
/root/.arche-superadmin     Credenciales superadmin (600)
```

## Solucion de problemas

```bash
journalctl -u arche-gmao -n 50                          # Logs del servicio
docker compose -f /opt/arche-gmao/docker-compose.yml \
  exec postgres pg_isready -U arche                        # PostgreSQL
systemctl status ollama && ollama list                     # Ollama
```

Nginx 502 = API caida. Verificar con `systemctl status arche-gmao`.
