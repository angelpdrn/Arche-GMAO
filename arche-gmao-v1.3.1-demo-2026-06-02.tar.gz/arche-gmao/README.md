# Arche GMAO

CMMS industrial multi-tenant con IA integrada. V1.3.1.

## Stack

| Capa | Tecnologia |
|------|-----------|
| Backend | Go 1.24 + Fiber v2 |
| Frontend | Vue 3.4 + TypeScript 5.4 + Vite 5.3 |
| BD | PostgreSQL 16 (pgvector, ltree, pg_trgm, RLS) |
| Cache | Redis 7 |
| IA | Ollama (llama3 + nomic-embed-text) |
| Proxy | Nginx (produccion) |

## Funcionalidades

- **Fabrica Virtual** — arbol jerarquico con ltree, busqueda full-text, health score por equipo
- **Ordenes de Trabajo** — ciclo 11 estados, firmas, verificaciones, cronometro, evidencias
- **Inventario** — repuestos, stock, movimientos, vinculacion a equipos, alertas stock bajo
- **Preventivos** — planes con generacion automatica de OTs, escalonamiento, exclusiones
- **Arche IA** — chat contextual RAG, deteccion de patrones, indexacion automatica
- **Metricas KPI** — MTBF, MTTR, ratio correctivo, tendencias
- **Procedimientos SOP** — generacion con IA, vinculacion a nodos/planes
- **Notificaciones** — in-app + Web Push + SMTP
- **QR** — generacion, escaneo publico, hoja imprimible
- **PWA** — modo offline con sync, responsive, instalable
- **Multi-tenant** — aislamiento completo con WHERE tenant_id + RLS + licencia Ed25519

## Inicio rapido

```bash
make up
# Frontend: http://localhost:5173
# API:      http://localhost:3000/api/v1/health
# Login:    admin@arche.local / Admin@1234
```

## Roles

| Rol | Funcion |
|-----|---------|
| admin | Fabrica, usuarios, plantillas, clientes, importacion, config IA |
| supervisor | Aprobar OTs, asignar, verificar, firmar, preventivos |
| technician | Iniciar, completar, pausar OTs asignadas |
| operator | Operacion basica |
| warehouse | Gestion de inventario |
| auditor | Solo lectura |

## Documentacion

| Archivo | Contenido |
|---------|-----------|
| [INSTALACION.md](INSTALACION.md) | Instalacion en servidor cliente |
| [ACTUALIZACION.md](ACTUALIZACION.md) | Actualizacion en produccion |
| [COMANDOS.md](COMANDOS.md) | Referencia de comandos dev y prod |
| [docs/](docs/) | Documentacion tecnica interna para desarrolladores |

## Produccion

```bash
sudo ./arche.sh                    # Instalacion completa
sudo ./update.sh /ruta/binario     # Actualizacion con rollback
```

Ver [INSTALACION.md](INSTALACION.md) para detalles.

## Tests

```bash
cd api && go test ./... -count=1                          # Unit tests
cd api && go test ./internal/handlers/ -tags=integration  # Integration (API viva)
```
