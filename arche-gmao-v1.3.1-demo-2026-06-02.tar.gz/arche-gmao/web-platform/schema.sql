-- Arche GMAO — Web Platform Schema (MariaDB)
-- archesystem.com: internal panel + client portal + phone-home API

SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;

CREATE DATABASE IF NOT EXISTS arche_platform
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE arche_platform;

-- ─── Admin users (Arche GMAO team) ─────────────────────────────────────

CREATE TABLE admin_users (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  email         VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name     VARCHAR(150) NOT NULL,
  role          ENUM('superadmin','admin','support') NOT NULL DEFAULT 'admin',
  is_active     TINYINT(1) NOT NULL DEFAULT 1,
  last_login    DATETIME NULL,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Temporary password: Admin@1234 (change it in setup.php)
INSERT INTO admin_users (email, password_hash, full_name, role) VALUES
('angel@archesystem.com', '$2y$12$LJ3m4ys3Gz8y6E5K1Z5fTeYqJH8OV0q3GzX7wB9kN5vR2uA1dS6Wy', 'Angel Padrino', 'superadmin');

-- ─── Clients (customer companies) ────────────────────────────────────────────

CREATE TABLE clients (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_name    VARCHAR(255) NOT NULL,
  contact_name    VARCHAR(150) NOT NULL,
  contact_email   VARCHAR(255) NOT NULL UNIQUE,
  contact_phone   VARCHAR(50) NULL,
  password_hash   VARCHAR(255) NOT NULL,
  client_code     VARCHAR(50) NOT NULL UNIQUE,  -- e.g. carnicas-demo
  status          ENUM('pending','active','suspended','cancelled') NOT NULL DEFAULT 'pending',
  notes           TEXT NULL,
  approved_by     INT UNSIGNED NULL,
  approved_at     DATETIME NULL,
  last_login      DATETIME NULL,
  created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (approved_by) REFERENCES admin_users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ─── Licenses ──────────────────────────────────────────────────────────────

CREATE TABLE licenses (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  client_id       INT UNSIGNED NOT NULL,
  license_number  VARCHAR(64) NOT NULL UNIQUE,   -- hex ID
  status          ENUM('active','expired','suspended','revoked') NOT NULL DEFAULT 'active',

  -- Limits
  max_users       INT UNSIGNED NOT NULL DEFAULT 50,
  max_equipos     INT UNSIGNED NOT NULL DEFAULT 200,
  max_tenants     INT UNSIGNED NOT NULL DEFAULT 1,
  ia_enabled      TINYINT(1) NOT NULL DEFAULT 0,
  soporte_dedicado TINYINT(1) NOT NULL DEFAULT 0,
  formacion       TINYINT(1) NOT NULL DEFAULT 0,

  -- Crypto
  hardware_id     VARCHAR(128) NULL,
  signed_payload  LONGTEXT NOT NULL,             -- base64 signed license
  public_key_hex  VARCHAR(128) NOT NULL,

  -- Dates
  issued_at       DATETIME NOT NULL,
  expires_at      DATETIME NOT NULL,
  renewed_at      DATETIME NULL,

  -- Penalty state (managed by phone-home logic)
  penalty_level   ENUM('none','aviso','lectura','bloqueo','suspension') NOT NULL DEFAULT 'none',
  penalty_since   DATETIME NULL,

  created_by      INT UNSIGNED NULL,
  created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
  FOREIGN KEY (created_by) REFERENCES admin_users(id) ON DELETE SET NULL,

  INDEX idx_client (client_id),
  INDEX idx_status (status),
  INDEX idx_expires (expires_at)
) ENGINE=InnoDB;

-- ─── License history (renewals, changes) ───────────────────────────────────

CREATE TABLE license_history (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  license_id  INT UNSIGNED NOT NULL,
  action      ENUM('created','renewed','modified','suspended','revoked','reactivated') NOT NULL,
  details     TEXT NULL,
  performed_by INT UNSIGNED NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (license_id) REFERENCES licenses(id) ON DELETE CASCADE,
  FOREIGN KEY (performed_by) REFERENCES admin_users(id) ON DELETE SET NULL,
  INDEX idx_license (license_id)
) ENGINE=InnoDB;

-- ─── Phone-home logs ───────────────────────────────────────────────────────

CREATE TABLE phone_home_logs (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  license_id    INT UNSIGNED NOT NULL,
  client_id     INT UNSIGNED NOT NULL,
  ip_address    VARCHAR(45) NOT NULL,
  hardware_id   VARCHAR(128) NULL,
  app_version   VARCHAR(20) NULL,
  current_users INT UNSIGNED NULL DEFAULT 0,
  current_equipos INT UNSIGNED NULL DEFAULT 0,
  current_tenants INT UNSIGNED NULL DEFAULT 0,
  penalty_level VARCHAR(20) NULL,
  response_code SMALLINT NOT NULL DEFAULT 200,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (license_id) REFERENCES licenses(id) ON DELETE CASCADE,
  FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
  INDEX idx_license_date (license_id, created_at),
  INDEX idx_client (client_id)
) ENGINE=InnoDB;

-- ─── Downloads (binaries per client) ───────────────────────────────────────

CREATE TABLE downloads (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  client_id     INT UNSIGNED NOT NULL,
  license_id    INT UNSIGNED NOT NULL,
  filename      VARCHAR(255) NOT NULL,
  file_path     VARCHAR(500) NOT NULL,
  file_size     BIGINT UNSIGNED NOT NULL DEFAULT 0,
  sha256_hash   VARCHAR(64) NULL,
  version       VARCHAR(20) NOT NULL,
  download_count INT UNSIGNED NOT NULL DEFAULT 0,
  is_active     TINYINT(1) NOT NULL DEFAULT 1,
  uploaded_by   INT UNSIGNED NULL,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
  FOREIGN KEY (license_id) REFERENCES licenses(id) ON DELETE CASCADE,
  FOREIGN KEY (uploaded_by) REFERENCES admin_users(id) ON DELETE SET NULL,
  INDEX idx_client (client_id)
) ENGINE=InnoDB;

-- ─── Download logs ─────────────────────────────────────────────────────────

CREATE TABLE download_logs (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  download_id INT UNSIGNED NOT NULL,
  client_id   INT UNSIGNED NOT NULL,
  ip_address  VARCHAR(45) NOT NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (download_id) REFERENCES downloads(id) ON DELETE CASCADE,
  FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─── Support tickets ───────────────────────────────────────────────────────

CREATE TABLE support_tickets (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  client_id   INT UNSIGNED NOT NULL,
  subject     VARCHAR(255) NOT NULL,
  message     TEXT NOT NULL,
  status      ENUM('open','in_progress','resolved','closed') NOT NULL DEFAULT 'open',
  priority    ENUM('low','normal','high','urgent') NOT NULL DEFAULT 'normal',
  assigned_to INT UNSIGNED NULL,
  resolved_at DATETIME NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
  FOREIGN KEY (assigned_to) REFERENCES admin_users(id) ON DELETE SET NULL,
  INDEX idx_client (client_id),
  INDEX idx_status (status)
) ENGINE=InnoDB;

CREATE TABLE ticket_replies (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ticket_id   INT UNSIGNED NOT NULL,
  author_type ENUM('client','admin') NOT NULL,
  author_id   INT UNSIGNED NOT NULL,
  message     TEXT NOT NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (ticket_id) REFERENCES support_tickets(id) ON DELETE CASCADE,
  INDEX idx_ticket (ticket_id)
) ENGINE=InnoDB;

-- ─── Settings (key-value) ──────────────────────────────────────────────────

CREATE TABLE settings (
  setting_key   VARCHAR(100) PRIMARY KEY,
  setting_value TEXT NOT NULL,
  updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO settings (setting_key, setting_value) VALUES
('ed25519_private_key_enc', ''),
('ed25519_public_key_hex', ''),
('phone_home_interval_hours', '24'),
('penalty_aviso_days', '15'),
('penalty_lectura_days', '0'),
('penalty_bloqueo_days', '7'),
('penalty_suspension_days', '30'),
('company_name', 'Arche GMAO'),
('support_email', 'info@archesystem.com');
