#!/bin/sh
set -e

echo "[ARCHE-WEB] Waiting for DB..."
sleep 3

echo "[ARCHE-WEB] Setting admin password..."
php /app/init_password.php || true

echo "[ARCHE-WEB] Starting PHP dev server on :8888"
exec php -S 0.0.0.0:8888 -t /app
