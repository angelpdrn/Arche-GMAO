<?php
// First-time setup: create initial admin password and generate Ed25519 keys
// Access this once after deploying: https://archesystem.com/setup.php
// Then DELETE this file from the server.

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/license_crypto.php';

$done = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm'] ?? '';

    if (strlen($password) < 8) {
        $error = 'La contrasena debe tener al menos 8 caracteres.';
    } elseif ($password !== $confirm) {
        $error = 'Las contrasenas no coinciden.';
    } else {
        $db = getDB();

        // Update admin password
        $hash = hashPassword($password);
        $db->prepare('UPDATE admin_users SET password_hash = ? WHERE email = "angel@archesystem.com"')
           ->execute([$hash]);

        // Generate Ed25519 keys if not present
        if (!hasKeyPair()) {
            generateKeyPair();
        }

        $keys = getKeyPair();
        $done = true;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Setup — Arche GMAO</title>
  <link rel="stylesheet" href="/assets/css/platform.css">
</head>
<body>
  <div class="login-wrapper">
    <div class="login-box">
      <div class="login-logo">
        <span class="logo-icon">A</span>
        <span class="logo-text">ARCHE<span class="logo-accent">SYSTEM</span></span>
      </div>

      <?php if ($done): ?>
      <h2 class="login-title" style="color:var(--green)">Setup completado</h2>
      <div style="text-align:center;margin:20px 0">
        <p style="font-size:0.9rem;color:var(--text-secondary);margin-bottom:16px">
          Contrasena de admin configurada y claves Ed25519 generadas.
        </p>
        <div style="background:var(--bg-card);padding:12px 16px;border-radius:8px;margin-bottom:16px;text-align:left">
          <div style="font-size:0.72rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.08em;margin-bottom:6px">Clave publica (para build.sh)</div>
          <code style="font-size:0.72rem;word-break:break-all;color:var(--accent-light)"><?= htmlspecialchars($keys['public_hex']) ?></code>
        </div>
        <p style="font-size:0.82rem;color:var(--red);font-weight:600">
          ELIMINA este archivo (setup.php) del servidor ahora.
        </p>
        <a href="/internal/login.php" class="btn btn-primary" style="margin-top:16px;display:inline-flex">
          Ir al panel interno
        </a>
      </div>
      <?php else: ?>
      <h2 class="login-title">Configuracion inicial</h2>
      <p class="login-subtitle">Establece la contrasena del administrador principal</p>

      <?php if ($error): ?>
      <div class="flash flash--error" style="margin-bottom:16px"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <form method="POST">
        <div class="form-group">
          <label class="form-label">Email del admin</label>
          <input type="text" class="form-input" value="angel@archesystem.com" disabled>
        </div>
        <div class="form-group">
          <label class="form-label">Nueva contrasena</label>
          <input type="password" name="password" class="form-input" required minlength="8" autofocus>
        </div>
        <div class="form-group">
          <label class="form-label">Confirmar contrasena</label>
          <input type="password" name="confirm" class="form-input" required>
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;margin-top:8px">
          Configurar y generar claves
        </button>
      </form>
      <?php endif; ?>
    </div>
  </div>
</body>
</html>
