<?php
// Redirect root to the main archesystem.com website
// The platform sections are at /internal and /clientes
header('Location: https://archesystem.com');
exit;
