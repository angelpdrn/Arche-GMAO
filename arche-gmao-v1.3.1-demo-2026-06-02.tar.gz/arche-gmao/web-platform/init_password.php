<?php
// Run once after DB is created to set the admin password
// Usage: php init_password.php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';

$db = getDB();
$hash = hashPassword('Admin@1234');
$db->prepare('UPDATE admin_users SET password_hash = ? WHERE email = ?')
   ->execute([$hash, 'angel@archesystem.com']);

echo "Admin password set to: Admin@1234\n";
echo "Hash: $hash\n";
