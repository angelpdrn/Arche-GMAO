<?php
require_once __DIR__ . '/../includes/layout.php';

$admin = requireAdmin();
$db = getDB();

$clientFilter = (int)($_GET['client_id'] ?? 0);
$where = '';
$params = [];
if ($clientFilter) {
    $where = 'WHERE ph.client_id = ?';
    $params = [$clientFilter];
}

$logs = $db->prepare("
    SELECT ph.*, c.company_name, l.license_number
    FROM phone_home_logs ph
    JOIN clients c ON c.id = ph.client_id
    JOIN licenses l ON l.id = ph.license_id
    $where
    ORDER BY ph.created_at DESC
    LIMIT 200
");
$logs->execute($params);
$logs = $logs->fetchAll();

// Summary per client
$summary = $db->query("
    SELECT c.id, c.company_name,
           COUNT(ph.id) as total_calls,
           MAX(ph.created_at) as last_call,
           MAX(ph.current_users) as last_users,
           MAX(ph.current_equipos) as last_equipos
    FROM clients c
    LEFT JOIN phone_home_logs ph ON ph.client_id = c.id
    WHERE c.status = 'active'
    GROUP BY c.id, c.company_name
    ORDER BY last_call DESC
")->fetchAll();

renderHeader('Phone-Home', 'internal', $admin);
?>

<div class="page-header">
  <span class="page-label">Monitoreo</span>
  <h1>Phone-Home</h1>
  <p>Registro de validaciones de licencia desde instalaciones de clientes</p>
</div>

<!-- Client summary -->
<div class="stats-grid" style="margin-bottom:24px">
  <?php foreach ($summary as $s): ?>
  <?php
    $isOnline = $s['last_call'] && (time() - strtotime($s['last_call'])) < 172800;
  ?>
  <div class="stat-card">
    <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px">
      <span class="phonehome-pulse phonehome-pulse--<?= $isOnline ? 'online' : 'offline' ?>"></span>
      <span style="font-size:0.82rem;font-weight:600"><?= e($s['company_name']) ?></span>
    </div>
    <div style="font-size:0.78rem;color:var(--text-muted)">
      <?= $s['total_calls'] ?> llamadas
      <?php if ($s['last_call']): ?>
        &middot; Ultimo: <?= e(substr($s['last_call'], 0, 16)) ?>
      <?php endif; ?>
    </div>
    <?php if ($s['last_users'] || $s['last_equipos']): ?>
    <div style="font-size:0.78rem;color:var(--text-secondary);margin-top:4px">
      <?= $s['last_users'] ?> usuarios &middot; <?= $s['last_equipos'] ?> equipos
    </div>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>

<!-- Log table -->
<div class="card">
  <div class="card-header">
    <h3 class="card-title">Registro de conexiones</h3>
  </div>
  <?php if (empty($logs)): ?>
  <div class="empty-state">
    <div class="empty-state-icon">&#x25C8;</div>
    <p>Sin registros de phone-home</p>
  </div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="table">
      <thead>
        <tr>
          <th>Fecha</th>
          <th>Cliente</th>
          <th>IP</th>
          <th>Version</th>
          <th>Usuarios</th>
          <th>Equipos</th>
          <th>Tenants</th>
          <th>Penalizacion</th>
          <th>Respuesta</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($logs as $log): ?>
        <tr>
          <td><?= e(substr($log['created_at'], 0, 16)) ?></td>
          <td>
            <a href="/internal/phonehome.php?client_id=<?= $log['client_id'] ?>" style="color:var(--accent-light)">
              <?= e($log['company_name']) ?>
            </a>
          </td>
          <td class="mono"><?= e($log['ip_address']) ?></td>
          <td><?= e($log['app_version'] ?? '—') ?></td>
          <td><?= (int)$log['current_users'] ?></td>
          <td><?= (int)$log['current_equipos'] ?></td>
          <td><?= (int)$log['current_tenants'] ?></td>
          <td>
            <?php if ($log['penalty_level']): ?>
            <span class="badge badge--<?= e($log['penalty_level']) ?>"><?= e(ucfirst($log['penalty_level'])) ?></span>
            <?php else: ?>
            <span class="badge badge--none">OK</span>
            <?php endif; ?>
          </td>
          <td><span class="badge <?= $log['response_code'] === 200 ? 'badge--active' : 'badge--suspended' ?>"><?= $log['response_code'] ?></span></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php renderFooter(); ?>
