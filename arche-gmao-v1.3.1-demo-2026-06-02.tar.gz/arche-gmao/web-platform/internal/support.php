<?php
require_once __DIR__ . '/../includes/layout.php';

$admin = requireAdmin();
$db = getDB();

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';

    if ($action === 'reply' && !empty($_POST['ticket_id'])) {
        $ticketId = (int)$_POST['ticket_id'];
        $message  = trim($_POST['message'] ?? '');
        if ($message) {
            $db->prepare('INSERT INTO ticket_replies (ticket_id, author_type, author_id, message) VALUES (?, "admin", ?, ?)')
               ->execute([$ticketId, $admin['id'], $message]);
            $db->prepare('UPDATE support_tickets SET status = "in_progress", updated_at = NOW() WHERE id = ?')
               ->execute([$ticketId]);
            flash('success', 'Respuesta enviada.');
        }
        header("Location: /internal/support.php?ticket=$ticketId");
        exit;
    }

    if ($action === 'close' && !empty($_POST['ticket_id'])) {
        $db->prepare('UPDATE support_tickets SET status = "closed", resolved_at = NOW() WHERE id = ?')
           ->execute([(int)$_POST['ticket_id']]);
        flash('success', 'Ticket cerrado.');
        header('Location: /internal/support.php');
        exit;
    }

    if ($action === 'resolve' && !empty($_POST['ticket_id'])) {
        $db->prepare('UPDATE support_tickets SET status = "resolved", resolved_at = NOW() WHERE id = ?')
           ->execute([(int)$_POST['ticket_id']]);
        flash('success', 'Ticket resuelto.');
        header('Location: /internal/support.php');
        exit;
    }
}

// View single ticket
$ticketId = (int)($_GET['ticket'] ?? 0);
if ($ticketId) {
    $ticket = $db->prepare('SELECT t.*, c.company_name, c.contact_name FROM support_tickets t JOIN clients c ON c.id = t.client_id WHERE t.id = ?');
    $ticket->execute([$ticketId]);
    $ticket = $ticket->fetch();

    $replies = $db->prepare('
        SELECT r.*,
               CASE WHEN r.author_type = "admin" THEN (SELECT full_name FROM admin_users WHERE id = r.author_id)
                    ELSE (SELECT contact_name FROM clients WHERE id = r.author_id) END as author_name
        FROM ticket_replies r WHERE r.ticket_id = ? ORDER BY r.created_at ASC
    ');
    $replies->execute([$ticketId]);
    $replies = $replies->fetchAll();

    renderHeader("Ticket #{$ticket['id']}", 'internal', $admin);
    ?>
    <div class="page-header">
      <span class="page-label"><a href="/internal/support.php" style="color:var(--accent)">Soporte</a> &rsaquo; Ticket #<?= $ticket['id'] ?></span>
      <h1><?= e($ticket['subject']) ?></h1>
      <p>
        <?= e($ticket['company_name']) ?> &middot; <?= e($ticket['contact_name']) ?> &middot;
        <span class="badge badge--<?= $ticket['status'] === 'open' ? 'pending' : ($ticket['status'] === 'resolved' ? 'active' : 'expired') ?>">
          <?= e(ucfirst($ticket['status'])) ?>
        </span>
        &middot; <?= e($ticket['created_at']) ?>
      </p>
    </div>

    <div class="card" style="margin-bottom:16px">
      <div style="padding:16px;background:var(--bg-card);border-radius:var(--radius-sm);margin-bottom:16px">
        <div style="font-size:0.78rem;color:var(--text-muted);margin-bottom:8px"><?= e($ticket['contact_name']) ?> &middot; <?= e($ticket['created_at']) ?></div>
        <div style="white-space:pre-wrap;font-size:0.9rem;color:var(--text-secondary)"><?= e($ticket['message']) ?></div>
      </div>

      <?php foreach ($replies as $r): ?>
      <div style="padding:16px;background:<?= $r['author_type'] === 'admin' ? 'var(--accent-glow)' : 'var(--bg-card)' ?>;border-radius:var(--radius-sm);margin-bottom:8px;border-left:3px solid <?= $r['author_type'] === 'admin' ? 'var(--accent)' : 'var(--border-light)' ?>">
        <div style="font-size:0.78rem;color:var(--text-muted);margin-bottom:8px">
          <?= e($r['author_name']) ?> (<?= $r['author_type'] === 'admin' ? 'Equipo Arche' : 'Cliente' ?>) &middot; <?= e($r['created_at']) ?>
        </div>
        <div style="white-space:pre-wrap;font-size:0.9rem;color:var(--text-secondary)"><?= e($r['message']) ?></div>
      </div>
      <?php endforeach; ?>

      <?php if ($ticket['status'] !== 'closed'): ?>
      <form method="POST" style="margin-top:16px">
        <?= csrfField() ?>
        <input type="hidden" name="action" value="reply">
        <input type="hidden" name="ticket_id" value="<?= $ticket['id'] ?>">
        <div class="form-group">
          <textarea name="message" class="form-textarea" required placeholder="Escribe tu respuesta..." rows="4"></textarea>
        </div>
        <div class="btn-group">
          <button type="submit" class="btn btn-primary">Responder</button>
        </div>
      </form>
      <?php endif; ?>
    </div>

    <?php if ($ticket['status'] !== 'closed'): ?>
    <div class="btn-group">
      <form method="POST"><input type="hidden" name="action" value="resolve"><input type="hidden" name="ticket_id" value="<?= $ticket['id'] ?>"><?= csrfField() ?><button class="btn btn-secondary">Marcar resuelto</button></form>
      <form method="POST"><input type="hidden" name="action" value="close"><input type="hidden" name="ticket_id" value="<?= $ticket['id'] ?>"><?= csrfField() ?><button class="btn btn-danger">Cerrar</button></form>
    </div>
    <?php endif; ?>

    <?php
    renderFooter();
    exit;
}

// List all tickets
$statusFilter = $_GET['status'] ?? '';
$where = '';
$params = [];
if ($statusFilter && in_array($statusFilter, ['open','in_progress','resolved','closed'])) {
    $where = 'WHERE t.status = ?';
    $params = [$statusFilter];
}

$tickets = $db->prepare("
    SELECT t.*, c.company_name
    FROM support_tickets t
    JOIN clients c ON c.id = t.client_id
    $where
    ORDER BY FIELD(t.status,'open','in_progress','resolved','closed'), t.created_at DESC
");
$tickets->execute($params);
$tickets = $tickets->fetchAll();

renderHeader('Soporte', 'internal', $admin);
?>

<div class="page-header">
  <span class="page-label">Gestion</span>
  <h1>Tickets de soporte</h1>
</div>

<div class="tabs">
  <a href="/internal/support.php" class="tab <?= !$statusFilter ? 'active' : '' ?>">Todos</a>
  <a href="/internal/support.php?status=open" class="tab <?= $statusFilter === 'open' ? 'active' : '' ?>">Abiertos</a>
  <a href="/internal/support.php?status=in_progress" class="tab <?= $statusFilter === 'in_progress' ? 'active' : '' ?>">En curso</a>
  <a href="/internal/support.php?status=resolved" class="tab <?= $statusFilter === 'resolved' ? 'active' : '' ?>">Resueltos</a>
</div>

<?php if (empty($tickets)): ?>
<div class="empty-state">
  <div class="empty-state-icon">&#x2713;</div>
  <p>No hay tickets<?= $statusFilter ? " con estado \"$statusFilter\"" : '' ?></p>
</div>
<?php else: ?>
<div class="table-wrap">
  <table class="table">
    <thead>
      <tr>
        <th>#</th>
        <th>Asunto</th>
        <th>Cliente</th>
        <th>Prioridad</th>
        <th>Estado</th>
        <th>Creado</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($tickets as $t): ?>
      <tr>
        <td><?= $t['id'] ?></td>
        <td><a href="/internal/support.php?ticket=<?= $t['id'] ?>" style="color:var(--accent-light)"><?= e($t['subject']) ?></a></td>
        <td><?= e($t['company_name']) ?></td>
        <td>
          <span class="badge badge--<?= $t['priority'] === 'urgent' ? 'suspended' : ($t['priority'] === 'high' ? 'aviso' : 'none') ?>">
            <?= e(ucfirst($t['priority'])) ?>
          </span>
        </td>
        <td>
          <span class="badge badge--<?= $t['status'] === 'open' ? 'pending' : ($t['status'] === 'resolved' ? 'active' : ($t['status'] === 'closed' ? 'expired' : 'aviso')) ?>">
            <?= e(ucfirst(str_replace('_', ' ', $t['status']))) ?>
          </span>
        </td>
        <td><?= e(substr($t['created_at'], 0, 16)) ?></td>
        <td><a href="/internal/support.php?ticket=<?= $t['id'] ?>" class="btn btn-sm btn-secondary">Ver</a></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

<?php renderFooter(); ?>
