<?php
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/license_crypto.php';

$admin = requireAdmin();
if ($admin['role'] !== 'superadmin') {
    flash('error', 'Solo el superadmin puede acceder a la configuracion.');
    header('Location: /internal/');
    exit;
}

$db = getDB();

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';

    if ($action === 'generate_keys') {
        if (hasKeyPair()) {
            flash('error', 'Ya existen claves Ed25519. Elimina las actuales antes de regenerar.');
        } else {
            $keys = generateKeyPair();
            flash('success', 'Claves Ed25519 generadas. Clave publica: ' . substr($keys['public_hex'], 0, 16) . '...');
        }
        header('Location: /internal/settings.php');
        exit;
    }

    if ($action === 'update_settings') {
        $fields = ['phone_home_interval_hours', 'penalty_aviso_days', 'penalty_lectura_days',
                    'penalty_bloqueo_days', 'penalty_suspension_days', 'support_email'];
        foreach ($fields as $field) {
            if (isset($_POST[$field])) {
                $db->prepare('UPDATE settings SET setting_value = ? WHERE setting_key = ?')
                   ->execute([trim($_POST[$field]), $field]);
            }
        }
        flash('success', 'Configuracion actualizada.');
        header('Location: /internal/settings.php');
        exit;
    }

    if ($action === 'change_password') {
        $current = $_POST['current_password'] ?? '';
        $new     = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        $adminUser = $db->prepare('SELECT * FROM admin_users WHERE id = ?');
        $adminUser->execute([$admin['id']]);
        $adminUser = $adminUser->fetch();

        if (!password_verify($current, $adminUser['password_hash'])) {
            flash('error', 'Contrasena actual incorrecta.');
        } elseif (strlen($new) < 8) {
            flash('error', 'La nueva contrasena debe tener al menos 8 caracteres.');
        } elseif ($new !== $confirm) {
            flash('error', 'Las contrasenas no coinciden.');
        } else {
            $db->prepare('UPDATE admin_users SET password_hash = ? WHERE id = ?')
               ->execute([hashPassword($new), $admin['id']]);
            flash('success', 'Contrasena actualizada.');
        }
        header('Location: /internal/settings.php');
        exit;
    }

    if ($action === 'create_admin') {
        $email = trim($_POST['admin_email'] ?? '');
        $name  = trim($_POST['admin_name'] ?? '');
        $pass  = $_POST['admin_password'] ?? '';
        $role  = $_POST['admin_role'] ?? 'admin';

        if ($email && $name && $pass && strlen($pass) >= 8) {
            $db->prepare('INSERT INTO admin_users (email, password_hash, full_name, role) VALUES (?, ?, ?, ?)')
               ->execute([$email, hashPassword($pass), $name, $role]);
            flash('success', "Administrador '$name' creado.");
        } else {
            flash('error', 'Datos incompletos.');
        }
        header('Location: /internal/settings.php');
        exit;
    }
}

// Load settings
$settings = [];
$rows = $db->query('SELECT * FROM settings')->fetchAll();
foreach ($rows as $r) {
    $settings[$r['setting_key']] = $r['setting_value'];
}

$keysConfigured = hasKeyPair();
$publicKeyHex = $settings['ed25519_public_key_hex'] ?? '';

// Admin users list
$adminUsers = $db->query('SELECT id, email, full_name, role, is_active, last_login, created_at FROM admin_users ORDER BY id')->fetchAll();

renderHeader('Configuracion', 'internal', $admin);
?>

<div class="page-header">
  <span class="page-label">Sistema</span>
  <h1>Configuracion</h1>
</div>

<!-- Ed25519 Keys -->
<div class="card" style="margin-bottom:24px">
  <div class="card-header">
    <h3 class="card-title">Claves Ed25519</h3>
  </div>
  <?php if ($keysConfigured): ?>
  <div style="padding:16px;background:rgba(16,185,129,0.08);border-radius:var(--radius-sm);border:1px solid rgba(16,185,129,0.15)">
    <div style="color:var(--green);font-weight:600;margin-bottom:8px">&#x2713; Claves configuradas</div>
    <div style="font-size:0.82rem;color:var(--text-secondary)">
      Clave publica: <code class="mono"><?= e(substr($publicKeyHex, 0, 32)) ?>...</code>
    </div>
    <div style="font-size:0.78rem;color:var(--text-muted);margin-top:4px">
      Usa este valor hex en build.sh: <code class="mono"><?= e($publicKeyHex) ?></code>
    </div>
  </div>
  <?php else: ?>
  <div style="padding:16px;background:rgba(245,158,11,0.08);border-radius:var(--radius-sm);border:1px solid rgba(245,158,11,0.15)">
    <div style="color:var(--amber);font-weight:600;margin-bottom:8px">&#x25C6; Claves no configuradas</div>
    <p style="font-size:0.86rem;color:var(--text-secondary);margin-bottom:12px">
      Necesitas generar un par de claves para firmar licencias.
    </p>
    <form method="POST">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="generate_keys">
      <button type="submit" class="btn btn-primary">Generar claves Ed25519</button>
    </form>
  </div>
  <?php endif; ?>
</div>

<!-- Penalty settings -->
<div class="card" style="margin-bottom:24px">
  <div class="card-header">
    <h3 class="card-title">Penalizaciones y phone-home</h3>
  </div>
  <form method="POST">
    <?= csrfField() ?>
    <input type="hidden" name="action" value="update_settings">

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Intervalo phone-home (horas)</label>
        <input type="number" name="phone_home_interval_hours" class="form-input" value="<?= e($settings['phone_home_interval_hours'] ?? '24') ?>" min="1">
      </div>
      <div class="form-group">
        <label class="form-label">Email soporte</label>
        <input type="email" name="support_email" class="form-input" value="<?= e($settings['support_email'] ?? '') ?>">
      </div>
    </div>

    <div style="margin:16px 0 8px;font-size:0.82rem;font-weight:600;color:var(--text-secondary)">Niveles de penalizacion (dias)</div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Aviso (antes de caducar)</label>
        <input type="number" name="penalty_aviso_days" class="form-input" value="<?= e($settings['penalty_aviso_days'] ?? '15') ?>" min="1">
      </div>
      <div class="form-group">
        <label class="form-label">Modo lectura (al caducar)</label>
        <input type="number" name="penalty_lectura_days" class="form-input" value="<?= e($settings['penalty_lectura_days'] ?? '0') ?>" min="0">
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Bloqueo (dias despues de caducar)</label>
        <input type="number" name="penalty_bloqueo_days" class="form-input" value="<?= e($settings['penalty_bloqueo_days'] ?? '7') ?>" min="1">
      </div>
      <div class="form-group">
        <label class="form-label">Suspension (dias despues de caducar)</label>
        <input type="number" name="penalty_suspension_days" class="form-input" value="<?= e($settings['penalty_suspension_days'] ?? '30') ?>" min="1">
      </div>
    </div>

    <button type="submit" class="btn btn-primary" style="margin-top:8px">Guardar configuracion</button>
  </form>
</div>

<!-- Admin users -->
<div class="card" style="margin-bottom:24px">
  <div class="card-header">
    <h3 class="card-title">Administradores</h3>
    <button class="btn btn-sm btn-primary" onclick="document.getElementById('modal-admin').classList.add('active')">+ Nuevo admin</button>
  </div>
  <div class="table-wrap">
    <table class="table">
      <thead>
        <tr><th>Nombre</th><th>Email</th><th>Rol</th><th>Ultimo acceso</th></tr>
      </thead>
      <tbody>
        <?php foreach ($adminUsers as $au): ?>
        <tr>
          <td><?= e($au['full_name']) ?></td>
          <td><?= e($au['email']) ?></td>
          <td><span class="badge badge--<?= $au['role'] === 'superadmin' ? 'active' : 'none' ?>"><?= e($au['role']) ?></span></td>
          <td><?= e($au['last_login'] ? substr($au['last_login'], 0, 16) : 'Nunca') ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Change password -->
<div class="card">
  <div class="card-header">
    <h3 class="card-title">Cambiar contrasena</h3>
  </div>
  <form method="POST">
    <?= csrfField() ?>
    <input type="hidden" name="action" value="change_password">
    <div class="form-group">
      <label class="form-label">Contrasena actual</label>
      <input type="password" name="current_password" class="form-input" required>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Nueva contrasena</label>
        <input type="password" name="new_password" class="form-input" required minlength="8">
      </div>
      <div class="form-group">
        <label class="form-label">Confirmar</label>
        <input type="password" name="confirm_password" class="form-input" required>
      </div>
    </div>
    <button type="submit" class="btn btn-secondary">Cambiar contrasena</button>
  </form>
</div>

<!-- New admin modal -->
<div class="modal-overlay" id="modal-admin">
  <div class="modal">
    <h3 class="modal-title">Nuevo administrador</h3>
    <form method="POST">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="create_admin">
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Nombre</label>
          <input type="text" name="admin_name" class="form-input" required>
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <input type="email" name="admin_email" class="form-input" required>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Contrasena</label>
          <input type="password" name="admin_password" class="form-input" required minlength="8">
        </div>
        <div class="form-group">
          <label class="form-label">Rol</label>
          <select name="admin_role" class="form-select">
            <option value="admin">Admin</option>
            <option value="support">Soporte</option>
          </select>
        </div>
      </div>
      <div class="btn-group" style="justify-content:flex-end;margin-top:12px">
        <button type="button" class="btn btn-secondary" onclick="this.closest('.modal-overlay').classList.remove('active')">Cancelar</button>
        <button type="submit" class="btn btn-primary">Crear</button>
      </div>
    </form>
  </div>
</div>

<script>
document.getElementById('modal-admin').addEventListener('click', function(e) {
  if (e.target === this) this.classList.remove('active');
});
</script>

<?php renderFooter(); ?>
