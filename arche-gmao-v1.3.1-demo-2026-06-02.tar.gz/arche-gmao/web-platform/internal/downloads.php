<?php
require_once __DIR__ . '/../includes/layout.php';

$admin = requireAdmin();
$db = getDB();

// Handle upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';

    if ($action === 'upload' && !empty($_FILES['binary']['tmp_name'])) {
        $clientId  = (int)$_POST['client_id'];
        $licenseId = (int)$_POST['license_id'];
        $version   = trim($_POST['version'] ?? '');

        $client = $db->prepare('SELECT client_code FROM clients WHERE id = ?');
        $client->execute([$clientId]);
        $client = $client->fetch();

        if ($client && $version) {
            $uploadDir = BINARIES_PATH . '/' . $client['client_code'];
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

            $origName = basename($_FILES['binary']['name']);
            $safeName = preg_replace('/[^a-zA-Z0-9._-]/', '_', $origName);
            $filePath = $uploadDir . '/' . $safeName;

            if (move_uploaded_file($_FILES['binary']['tmp_name'], $filePath)) {
                $fileSize = filesize($filePath);
                $sha256   = hash_file('sha256', $filePath);

                $db->prepare('INSERT INTO downloads (client_id, license_id, filename, file_path, file_size, sha256_hash, version, uploaded_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
                   ->execute([$clientId, $licenseId, $safeName, $filePath, $fileSize, $sha256, $version, $admin['id']]);

                flash('success', "Binario '$safeName' subido correctamente.");
            } else {
                flash('error', 'Error subiendo el archivo.');
            }
        } else {
            flash('error', 'Datos incompletos.');
        }
        header('Location: /internal/downloads.php');
        exit;
    }

    if ($action === 'deactivate' && !empty($_POST['download_id'])) {
        $db->prepare('UPDATE downloads SET is_active = 0 WHERE id = ?')->execute([(int)$_POST['download_id']]);
        flash('success', 'Descarga desactivada.');
        header('Location: /internal/downloads.php');
        exit;
    }
}

$downloads = $db->query("
    SELECT d.*, c.company_name, c.client_code, l.license_number
    FROM downloads d
    JOIN clients c ON c.id = d.client_id
    JOIN licenses l ON l.id = d.license_id
    ORDER BY d.created_at DESC
")->fetchAll();

// Get clients with active licenses for upload modal
$clientsWithLicenses = $db->query("
    SELECT c.id as client_id, c.company_name, l.id as license_id, l.license_number
    FROM clients c
    JOIN licenses l ON l.client_id = c.id AND l.status = 'active'
    WHERE c.status = 'active'
    ORDER BY c.company_name
")->fetchAll();

renderHeader('Descargas', 'internal', $admin);
?>

<div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between">
  <div>
    <span class="page-label">Gestion</span>
    <h1>Descargas</h1>
    <p>Binarios pre-configurados para cada cliente</p>
  </div>
  <button class="btn btn-primary" onclick="document.getElementById('modal-upload').classList.add('active')">
    + Subir binario
  </button>
</div>

<?php if (empty($downloads)): ?>
<div class="empty-state">
  <div class="empty-state-icon">&#x25A3;</div>
  <p>No hay binarios subidos</p>
</div>
<?php else: ?>
<div class="table-wrap">
  <table class="table">
    <thead>
      <tr>
        <th>Archivo</th>
        <th>Cliente</th>
        <th>Version</th>
        <th>Tamano</th>
        <th>SHA256</th>
        <th>Descargas</th>
        <th>Estado</th>
        <th>Subido</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($downloads as $d): ?>
      <tr>
        <td><strong><?= e($d['filename']) ?></strong></td>
        <td><?= e($d['company_name']) ?></td>
        <td><?= e($d['version']) ?></td>
        <td><?= number_format($d['file_size'] / 1048576, 1) ?> MB</td>
        <td class="mono"><?= e(substr($d['sha256_hash'] ?? '', 0, 12)) ?>...</td>
        <td><?= $d['download_count'] ?></td>
        <td><span class="badge badge--<?= $d['is_active'] ? 'active' : 'expired' ?>"><?= $d['is_active'] ? 'Activo' : 'Inactivo' ?></span></td>
        <td><?= e(substr($d['created_at'], 0, 10)) ?></td>
        <td>
          <?php if ($d['is_active']): ?>
          <form method="POST" style="display:inline" onsubmit="return confirm('Desactivar esta descarga?')">
            <?= csrfField() ?>
            <input type="hidden" name="action" value="deactivate">
            <input type="hidden" name="download_id" value="<?= $d['id'] ?>">
            <button type="submit" class="btn btn-sm btn-danger">Desactivar</button>
          </form>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

<!-- Upload modal -->
<div class="modal-overlay" id="modal-upload">
  <div class="modal">
    <h3 class="modal-title">Subir binario</h3>
    <form method="POST" enctype="multipart/form-data">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="upload">

      <div class="form-group">
        <label class="form-label">Cliente y licencia</label>
        <select name="client_id" class="form-select" id="client-select" required onchange="updateLicenseField()">
          <option value="">Seleccionar...</option>
          <?php foreach ($clientsWithLicenses as $cl): ?>
          <option value="<?= $cl['client_id'] ?>" data-license="<?= $cl['license_id'] ?>">
            <?= e($cl['company_name']) ?> — <?= e(substr($cl['license_number'], 0, 12)) ?>...
          </option>
          <?php endforeach; ?>
        </select>
        <input type="hidden" name="license_id" id="license-id-field">
      </div>

      <div class="form-group">
        <label class="form-label">Version</label>
        <input type="text" name="version" class="form-input" required placeholder="ej: 1.3.1">
      </div>

      <div class="form-group">
        <label class="form-label">Binario (.bin, .tar.gz, .zip)</label>
        <input type="file" name="binary" class="form-input" required>
        <span class="form-hint">Max 200MB. Se calcula SHA256 automaticamente.</span>
      </div>

      <div class="btn-group" style="justify-content:flex-end;margin-top:12px">
        <button type="button" class="btn btn-secondary" onclick="this.closest('.modal-overlay').classList.remove('active')">Cancelar</button>
        <button type="submit" class="btn btn-primary">Subir</button>
      </div>
    </form>
  </div>
</div>

<script>
function updateLicenseField() {
  const sel = document.getElementById('client-select');
  const opt = sel.options[sel.selectedIndex];
  document.getElementById('license-id-field').value = opt.dataset.license || '';
}
document.getElementById('modal-upload').addEventListener('click', function(e) {
  if (e.target === this) this.classList.remove('active');
});
</script>

<?php renderFooter(); ?>
