<?php
require_once __DIR__ . '/../includes/auth.php';

if (isAdminLoggedIn()) {
    header('Location: /internal/');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrf()) {
        $error = 'Token de seguridad invalido. Recarga la pagina.';
    } else {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $user = adminLogin($email, $password);
        if ($user) {
            header('Location: /internal/');
            exit;
        }
        $error = 'Credenciales incorrectas.';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="robots" content="noindex, nofollow">
  <title>Admin — Arche GMAO</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/css/platform.css">
</head>
<body>
  <div class="login-wrapper">
    <div class="login-box">
      <div class="login-logo">
        <span class="logo-icon">A</span>
        <span class="logo-text">ARCHE<span class="logo-accent">SYSTEM</span></span>
      </div>
      <h2 class="login-title">Panel Interno</h2>
      <p class="login-subtitle">Acceso exclusivo para el equipo de Arche GMAO</p>

      <?php if ($error): ?>
      <div class="flash flash--error" style="margin-bottom:20px"><?= e($error) ?></div>
      <?php endif; ?>

      <form method="POST">
        <?= csrfField() ?>
        <div class="form-group">
          <label class="form-label">Email</label>
          <input type="email" name="email" class="form-input" required autofocus
                 value="<?= e($_POST['email'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label class="form-label">Contrasena</label>
          <input type="password" name="password" class="form-input" required>
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;margin-top:8px">
          Acceder
        </button>
      </form>
    </div>
  </div>
</body>
</html>
