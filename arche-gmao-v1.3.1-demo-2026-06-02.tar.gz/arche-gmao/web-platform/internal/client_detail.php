<?php
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/license_crypto.php';

$admin = requireAdmin();
$db = getDB();

$clientId = (int)($_GET['id'] ?? 0);
if (!$clientId) { header('Location: /internal/clients.php'); exit; }

$client = $db->prepare('SELECT * FROM clients WHERE id = ?');
$client->execute([$clientId]);
$client = $client->fetch();
if (!$client) { header('Location: /internal/clients.php'); exit; }

// Handle license creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';

    if ($action === 'create_license') {
        $maxUsers    = max(1, (int)($_POST['max_users'] ?? 50));
        $maxEquipos  = max(1, (int)($_POST['max_equipos'] ?? 200));
        $maxTenants  = max(1, (int)($_POST['max_tenants'] ?? 1));
        $iaEnabled   = !empty($_POST['ia_enabled']);
        $soporte     = !empty($_POST['soporte_dedicado']);
        $formacion   = !empty($_POST['formacion']);
        $hardwareId  = trim($_POST['hardware_id'] ?? '');
        $durationDays = max(30, (int)($_POST['duration_days'] ?? 365));

        $expiresAt = date('c', strtotime("+{$durationDays} days"));

        try {
            $result = createSignedLicense(
                $clientId,
                $client['company_name'],
                $client['client_code'],
                $maxUsers,
                $maxEquipos,
                $maxTenants,
                $iaEnabled,
                $hardwareId,
                $expiresAt,
                $admin['id']
            );

            // Update soporte/formacion flags
            $db->prepare('UPDATE licenses SET soporte_dedicado = ?, formacion = ? WHERE id = ?')
               ->execute([$soporte ? 1 : 0, $formacion ? 1 : 0, $result['id']]);

            flash('success', "Licencia creada: {$result['license_number']}");
        } catch (Exception $e) {
            flash('error', 'Error creando licencia: ' . $e->getMessage());
        }

        header("Location: /internal/client_detail.php?id=$clientId");
        exit;
    }

    if ($action === 'update_client') {
        $db->prepare('UPDATE clients SET company_name = ?, contact_name = ?, contact_email = ?, contact_phone = ?, notes = ? WHERE id = ?')
           ->execute([
               trim($_POST['company_name']),
               trim($_POST['contact_name']),
               trim($_POST['contact_email']),
               trim($_POST['contact_phone'] ?? ''),
               trim($_POST['notes'] ?? ''),
               $clientId,
           ]);
        flash('success', 'Cliente actualizado.');
        header("Location: /internal/client_detail.php?id=$clientId");
        exit;
    }
}

// Get licenses
$licenses = $db->prepare('SELECT * FROM licenses WHERE client_id = ? ORDER BY created_at DESC');
$licenses->execute([$clientId]);
$licenses = $licenses->fetchAll();

// Get license history
$history = $db->prepare('
    SELECT lh.*, a.full_name as admin_name
    FROM license_history lh
    LEFT JOIN admin_users a ON a.id = lh.performed_by
    WHERE lh.license_id IN (SELECT id FROM licenses WHERE client_id = ?)
    ORDER BY lh.created_at DESC LIMIT 20
');
$history->execute([$clientId]);
$history = $history->fetchAll();

// Get phone-home stats
$phoneHomeCount = $db->prepare('SELECT COUNT(*) FROM phone_home_logs WHERE client_id = ?');
$phoneHomeCount->execute([$clientId]);
$phoneHomeCount = $phoneHomeCount->fetchColumn();

$lastPhoneHome = $db->prepare('SELECT * FROM phone_home_logs WHERE client_id = ? ORDER BY created_at DESC LIMIT 1');
$lastPhoneHome->execute([$clientId]);
$lastPhoneHome = $lastPhoneHome->fetch();

renderHeader("Cliente: {$client['company_name']}", 'internal', $admin);
?>

<div class="page-header">
  <span class="page-label">
    <a href="/internal/clients.php" style="color:var(--accent)">Clientes</a> &rsaquo; Detalle
  </span>
  <h1><?= e($client['company_name']) ?></h1>
  <p>
    <span class="badge badge--<?= e($client['status']) ?>"><?= e(ucfirst($client['status'])) ?></span>
    &nbsp; Codigo: <code class="mono"><?= e($client['client_code']) ?></code>
    &nbsp; Creado: <?= e(substr($client['created_at'], 0, 10)) ?>
  </p>
</div>

<!-- Client info -->
<div class="detail-grid" style="margin-bottom:32px">
  <div class="detail-item">
    <div class="detail-label">Contacto</div>
    <div class="detail-value"><?= e($client['contact_name']) ?></div>
  </div>
  <div class="detail-item">
    <div class="detail-label">Email</div>
    <div class="detail-value"><?= e($client['contact_email']) ?></div>
  </div>
  <div class="detail-item">
    <div class="detail-label">Telefono</div>
    <div class="detail-value"><?= e($client['contact_phone'] ?: '—') ?></div>
  </div>
  <div class="detail-item">
    <div class="detail-label">Phone-home</div>
    <div class="detail-value">
      <?php if ($lastPhoneHome): ?>
        <span class="phonehome-pulse phonehome-pulse--<?= (time() - strtotime($lastPhoneHome['created_at'])) < 172800 ? 'online' : 'offline' ?>"></span>
        <?= e(substr($lastPhoneHome['created_at'], 0, 16)) ?> (<?= $phoneHomeCount ?> registros)
      <?php else: ?>
        <span style="color:var(--text-muted)">Sin conexion</span>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Licenses section -->
<div class="card" style="margin-bottom:24px">
  <div class="card-header">
    <h3 class="card-title">Licencias</h3>
    <?php if ($client['status'] === 'active' && hasKeyPair()): ?>
    <button class="btn btn-sm btn-primary" onclick="document.getElementById('modal-license').classList.add('active')">
      + Nueva licencia
    </button>
    <?php endif; ?>
  </div>

  <?php if (empty($licenses)): ?>
  <div class="empty-state">
    <div class="empty-state-icon">&#x25A3;</div>
    <p>Este cliente no tiene licencias</p>
  </div>
  <?php else: ?>
  <?php foreach ($licenses as $lic): ?>
  <div style="padding:16px;background:var(--bg-card);border-radius:var(--radius-sm);border:1px solid var(--border);margin-bottom:12px">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
      <div>
        <code class="mono" style="font-size:0.82rem"><?= e($lic['license_number']) ?></code>
        <span class="badge badge--<?= e($lic['status']) ?>" style="margin-left:8px"><?= e(ucfirst($lic['status'])) ?></span>
        <?php if ($lic['penalty_level'] !== 'none'): ?>
        <span class="badge badge--<?= e($lic['penalty_level']) ?>" style="margin-left:4px">&#x25C6; <?= e(ucfirst($lic['penalty_level'])) ?></span>
        <?php endif; ?>
      </div>
      <div class="btn-group">
        <a href="/internal/license_detail.php?id=<?= $lic['id'] ?>" class="btn btn-sm btn-secondary">Detalle</a>
      </div>
    </div>
    <div class="license-info-grid">
      <div>
        <div class="stat-label">Usuarios</div>
        <div style="font-size:1.1rem;font-weight:700"><?= $lic['max_users'] ?></div>
      </div>
      <div>
        <div class="stat-label">Equipos</div>
        <div style="font-size:1.1rem;font-weight:700"><?= $lic['max_equipos'] ?></div>
      </div>
      <div>
        <div class="stat-label">Tenants</div>
        <div style="font-size:1.1rem;font-weight:700"><?= $lic['max_tenants'] ?></div>
      </div>
      <div>
        <div class="stat-label">IA</div>
        <div style="font-size:1.1rem;font-weight:700;color:<?= $lic['ia_enabled'] ? 'var(--green)' : 'var(--text-muted)' ?>"><?= $lic['ia_enabled'] ? 'Activo' : 'No' ?></div>
      </div>
      <div>
        <div class="stat-label">Soporte dedicado</div>
        <div style="font-size:1.1rem;font-weight:700;color:<?= $lic['soporte_dedicado'] ? 'var(--green)' : 'var(--text-muted)' ?>"><?= $lic['soporte_dedicado'] ? 'Si' : 'No' ?></div>
      </div>
      <div>
        <div class="stat-label">Caduca</div>
        <div style="font-size:1.1rem;font-weight:700"><?= e(substr($lic['expires_at'], 0, 10)) ?></div>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
  <?php endif; ?>
</div>

<!-- History -->
<div class="card">
  <div class="card-header">
    <h3 class="card-title">Historial</h3>
  </div>
  <?php if (empty($history)): ?>
  <div class="empty-state"><p>Sin historial</p></div>
  <?php else: ?>
  <div class="timeline">
    <?php foreach ($history as $h): ?>
    <div class="timeline-item">
      <div class="timeline-date"><?= e($h['created_at']) ?> &middot; <?= e($h['admin_name'] ?? 'Sistema') ?></div>
      <div class="timeline-text"><?= e(ucfirst($h['action'])) ?>: <?= e($h['details'] ?? '') ?></div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<!-- Create license modal -->
<div class="modal-overlay" id="modal-license">
  <div class="modal">
    <h3 class="modal-title">Nueva licencia para <?= e($client['company_name']) ?></h3>
    <form method="POST">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="create_license">

      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Max. usuarios</label>
          <input type="number" name="max_users" class="form-input" value="50" min="1" max="9999">
        </div>
        <div class="form-group">
          <label class="form-label">Max. equipos</label>
          <input type="number" name="max_equipos" class="form-input" value="200" min="1" max="99999">
          <span class="form-hint">Solo cuentan nodos tipo equipo</span>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Max. tenants (fabricas)</label>
          <input type="number" name="max_tenants" class="form-input" value="1" min="1" max="100">
        </div>
        <div class="form-group">
          <label class="form-label">Duracion (dias)</label>
          <input type="number" name="duration_days" class="form-input" value="365" min="30" max="3650">
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Hardware fingerprint</label>
        <input type="text" name="hardware_id" class="form-input" placeholder="Dejar vacio si aun no tienen servidor">
        <span class="form-hint">El cliente puede obtenerlo con: arche-server --fingerprint</span>
      </div>

      <div class="form-group" style="display:flex;gap:24px">
        <label class="form-check">
          <input type="checkbox" name="ia_enabled" value="1">
          <span>Modulo IA</span>
        </label>
        <label class="form-check">
          <input type="checkbox" name="soporte_dedicado" value="1">
          <span>Soporte dedicado</span>
        </label>
        <label class="form-check">
          <input type="checkbox" name="formacion" value="1">
          <span>Formacion</span>
        </label>
      </div>

      <div class="btn-group" style="justify-content:flex-end;margin-top:12px">
        <button type="button" class="btn btn-secondary" onclick="this.closest('.modal-overlay').classList.remove('active')">Cancelar</button>
        <button type="submit" class="btn btn-primary">Crear y firmar licencia</button>
      </div>
    </form>
  </div>
</div>

<script>
document.getElementById('modal-license').addEventListener('click', function(e) {
  if (e.target === this) this.classList.remove('active');
});
</script>

<?php renderFooter(); ?>
