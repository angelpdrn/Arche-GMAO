<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

$admin = requireAdmin();
$db = getDB();

$licenseId = (int)($_GET['id'] ?? 0);
if (!$licenseId) { http_response_code(404); exit; }

$lic = $db->prepare('SELECT l.*, c.client_code FROM licenses l JOIN clients c ON c.id = l.client_id WHERE l.id = ?');
$lic->execute([$licenseId]);
$lic = $lic->fetch();
if (!$lic) { http_response_code(404); exit; }

$filename = "license_{$lic['client_code']}.key";

header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . strlen($lic['signed_payload']));
echo $lic['signed_payload'];
exit;
