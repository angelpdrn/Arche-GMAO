<?php
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/license_crypto.php';

$admin = requireAdmin();
$db = getDB();

// Stats
$totalClients    = $db->query("SELECT COUNT(*) FROM clients")->fetchColumn();
$activeClients   = $db->query("SELECT COUNT(*) FROM clients WHERE status = 'active'")->fetchColumn();
$pendingClients  = $db->query("SELECT COUNT(*) FROM clients WHERE status = 'pending'")->fetchColumn();
$activeLicenses  = $db->query("SELECT COUNT(*) FROM licenses WHERE status = 'active'")->fetchColumn();
$expiringLicenses = $db->query("SELECT COUNT(*) FROM licenses WHERE status = 'active' AND expires_at <= DATE_ADD(NOW(), INTERVAL 30 DAY)")->fetchColumn();
$openTickets     = $db->query("SELECT COUNT(*) FROM support_tickets WHERE status IN ('open','in_progress')")->fetchColumn();

// Recent phone-home activity
$recentActivity = $db->query("
    SELECT ph.created_at, c.company_name, ph.ip_address, ph.app_version, ph.penalty_level
    FROM phone_home_logs ph
    JOIN clients c ON c.id = ph.client_id
    ORDER BY ph.created_at DESC LIMIT 10
")->fetchAll();

// Clients with penalties
$penaltyClients = $db->query("
    SELECT c.company_name, l.penalty_level, l.expires_at, l.license_number
    FROM licenses l
    JOIN clients c ON c.id = l.client_id
    WHERE l.penalty_level != 'none' AND l.status = 'active'
    ORDER BY l.expires_at ASC
")->fetchAll();

// Check if keys are configured
$keysConfigured = hasKeyPair();

renderHeader('Dashboard', 'internal', $admin);
?>

<div class="page-header">
  <span class="page-label">Panel interno</span>
  <h1>Dashboard</h1>
  <p>Vista general del estado de clientes, licencias y actividad</p>
</div>

<?php if (!$keysConfigured): ?>
<div class="flash flash--warning">
  Claves Ed25519 no configuradas.
  <a href="/internal/settings.php" style="color:var(--amber);text-decoration:underline;margin-left:8px">Configurar ahora</a>
</div>
<?php endif; ?>

<div class="stats-grid">
  <div class="stat-card">
    <div class="stat-label">Clientes totales</div>
    <div class="stat-value"><?= $totalClients ?></div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Clientes activos</div>
    <div class="stat-value stat-value--green"><?= $activeClients ?></div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Pendientes de aprobacion</div>
    <div class="stat-value stat-value--amber"><?= $pendingClients ?></div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Licencias activas</div>
    <div class="stat-value stat-value--accent"><?= $activeLicenses ?></div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Caducan en 30 dias</div>
    <div class="stat-value stat-value--amber"><?= $expiringLicenses ?></div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Tickets abiertos</div>
    <div class="stat-value <?= $openTickets > 0 ? 'stat-value--red' : '' ?>"><?= $openTickets ?></div>
  </div>
</div>

<div class="dashboard-grid">
  <!-- Recent phone-home activity -->
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Actividad Phone-Home</h3>
      <a href="/internal/phonehome.php" class="btn btn-sm btn-secondary">Ver todo</a>
    </div>
    <?php if (empty($recentActivity)): ?>
    <div class="empty-state">
      <div class="empty-state-icon">&#x25C8;</div>
      <p>Sin actividad registrada</p>
    </div>
    <?php else: ?>
    <ul class="activity-list">
      <?php foreach ($recentActivity as $activity): ?>
      <li class="activity-item">
        <span class="activity-dot activity-dot--<?= $activity['penalty_level'] === 'none' ? 'green' : ($activity['penalty_level'] === 'aviso' ? 'amber' : 'red') ?>"></span>
        <div>
          <div><?= e($activity['company_name']) ?> <span style="color:var(--text-muted)">v<?= e($activity['app_version'] ?? '?') ?></span></div>
          <div class="activity-time"><?= e($activity['created_at']) ?> &middot; <?= e($activity['ip_address']) ?></div>
        </div>
      </li>
      <?php endforeach; ?>
    </ul>
    <?php endif; ?>
  </div>

  <!-- Penalty alerts -->
  <div class="card">
    <div class="card-header">
      <h3 class="card-title">Alertas de penalizacion</h3>
    </div>
    <?php if (empty($penaltyClients)): ?>
    <div class="empty-state">
      <div class="empty-state-icon">&#x2713;</div>
      <p>Sin penalizaciones activas</p>
    </div>
    <?php else: ?>
    <ul class="activity-list">
      <?php foreach ($penaltyClients as $pc): ?>
      <li class="activity-item">
        <span class="activity-dot activity-dot--<?= in_array($pc['penalty_level'], ['bloqueo','suspension']) ? 'red' : 'amber' ?>"></span>
        <div>
          <div>
            <?= e($pc['company_name']) ?>
            <span class="badge badge--<?= e($pc['penalty_level']) ?>"><?= e(ucfirst($pc['penalty_level'])) ?></span>
          </div>
          <div class="activity-time">Caduca: <?= e(substr($pc['expires_at'], 0, 10)) ?> &middot; <?= e(substr($pc['license_number'], 0, 12)) ?>...</div>
        </div>
      </li>
      <?php endforeach; ?>
    </ul>
    <?php endif; ?>
  </div>
</div>

<?php renderFooter(); ?>
