<?php
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/license_crypto.php';

$admin = requireAdmin();
$db = getDB();

$licenseId = (int)($_GET['id'] ?? 0);
if (!$licenseId) { header('Location: /internal/licenses.php'); exit; }

$lic = $db->prepare('SELECT l.*, c.company_name, c.client_code, c.contact_email FROM licenses l JOIN clients c ON c.id = l.client_id WHERE l.id = ?');
$lic->execute([$licenseId]);
$lic = $lic->fetch();
if (!$lic) { header('Location: /internal/licenses.php'); exit; }

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';

    if ($action === 'modify_limits') {
        $maxUsers   = max(1, (int)$_POST['max_users']);
        $maxEquipos = max(1, (int)$_POST['max_equipos']);
        $maxTenants = max(1, (int)$_POST['max_tenants']);
        $iaEnabled  = !empty($_POST['ia_enabled']);
        $soporte    = !empty($_POST['soporte_dedicado']);
        $formacion  = !empty($_POST['formacion']);

        $db->prepare('UPDATE licenses SET max_users = ?, max_equipos = ?, max_tenants = ?, ia_enabled = ?, soporte_dedicado = ?, formacion = ? WHERE id = ?')
           ->execute([$maxUsers, $maxEquipos, $maxTenants, $iaEnabled ? 1 : 0, $soporte ? 1 : 0, $formacion ? 1 : 0, $licenseId]);

        // Re-sign license with new limits
        $modules = ['core', 'preventive', 'metrics', 'qr', 'reports', 'offline'];
        if ($iaEnabled) $modules[] = 'ai';

        $payload = [
            'license_id'  => $lic['license_number'],
            'client_name' => $lic['company_name'],
            'client_id'   => $lic['client_code'],
            'modules'     => $modules,
            'max_users'   => $maxUsers,
            'max_nodes'   => $maxEquipos,
            'max_tenants' => $maxTenants,
            'hardware_id' => $lic['hardware_id'] ?? '',
            'issued_at'   => date('c', strtotime($lic['issued_at'])),
            'expires_at'  => date('c', strtotime($lic['expires_at'])),
            'version'     => '2.0',
        ];

        $signedPayload = signLicense($payload);
        $db->prepare('UPDATE licenses SET signed_payload = ? WHERE id = ?')->execute([$signedPayload, $licenseId]);

        $db->prepare('INSERT INTO license_history (license_id, action, details, performed_by) VALUES (?, "modified", ?, ?)')
           ->execute([$licenseId, "Limites: $maxUsers usr, $maxEquipos eq, $maxTenants ten, IA:" . ($iaEnabled ? 'si' : 'no'), $admin['id']]);

        flash('success', 'Limites actualizados y licencia re-firmada.');
        header("Location: /internal/license_detail.php?id=$licenseId");
        exit;
    }

    if ($action === 'renew') {
        $days = max(30, (int)$_POST['renew_days']);
        $newExpiry = date('Y-m-d H:i:s', strtotime($lic['expires_at'] . " + $days days"));

        $db->prepare('UPDATE licenses SET expires_at = ?, renewed_at = NOW(), penalty_level = "none", penalty_since = NULL WHERE id = ?')
           ->execute([$newExpiry, $licenseId]);

        // Re-sign
        $modules = ['core', 'preventive', 'metrics', 'qr', 'reports', 'offline'];
        if ($lic['ia_enabled']) $modules[] = 'ai';

        $payload = [
            'license_id'  => $lic['license_number'],
            'client_name' => $lic['company_name'],
            'client_id'   => $lic['client_code'],
            'modules'     => $modules,
            'max_users'   => (int)$lic['max_users'],
            'max_nodes'   => (int)$lic['max_equipos'],
            'max_tenants' => (int)$lic['max_tenants'],
            'hardware_id' => $lic['hardware_id'] ?? '',
            'issued_at'   => date('c'),
            'expires_at'  => date('c', strtotime($newExpiry)),
            'version'     => '2.0',
        ];
        $signedPayload = signLicense($payload);
        $db->prepare('UPDATE licenses SET signed_payload = ? WHERE id = ?')->execute([$signedPayload, $licenseId]);

        $db->prepare('INSERT INTO license_history (license_id, action, details, performed_by) VALUES (?, "renewed", ?, ?)')
           ->execute([$licenseId, "Renovada $days dias. Nueva caducidad: " . substr($newExpiry, 0, 10), $admin['id']]);

        flash('success', "Licencia renovada. Nueva caducidad: " . substr($newExpiry, 0, 10));
        header("Location: /internal/license_detail.php?id=$licenseId");
        exit;
    }

    if ($action === 'suspend') {
        $db->prepare('UPDATE licenses SET status = "suspended", penalty_level = "suspension", penalty_since = NOW() WHERE id = ?')
           ->execute([$licenseId]);
        $db->prepare('INSERT INTO license_history (license_id, action, details, performed_by) VALUES (?, "suspended", "Suspension forzada por admin", ?)')
           ->execute([$licenseId, $admin['id']]);
        flash('warning', 'Licencia suspendida.');
        header("Location: /internal/license_detail.php?id=$licenseId");
        exit;
    }

    if ($action === 'reactivate') {
        $db->prepare('UPDATE licenses SET status = "active", penalty_level = "none", penalty_since = NULL WHERE id = ?')
           ->execute([$licenseId]);
        $db->prepare('INSERT INTO license_history (license_id, action, details, performed_by) VALUES (?, "reactivated", "Reactivada por admin", ?)')
           ->execute([$licenseId, $admin['id']]);
        flash('success', 'Licencia reactivada.');
        header("Location: /internal/license_detail.php?id=$licenseId");
        exit;
    }

    if ($action === 'update_hardware') {
        $hwId = trim($_POST['hardware_id'] ?? '');
        $db->prepare('UPDATE licenses SET hardware_id = ? WHERE id = ?')->execute([$hwId, $licenseId]);

        // Re-sign
        $modules = ['core', 'preventive', 'metrics', 'qr', 'reports', 'offline'];
        if ($lic['ia_enabled']) $modules[] = 'ai';

        $payload = [
            'license_id'  => $lic['license_number'],
            'client_name' => $lic['company_name'],
            'client_id'   => $lic['client_code'],
            'modules'     => $modules,
            'max_users'   => (int)$lic['max_users'],
            'max_nodes'   => (int)$lic['max_equipos'],
            'max_tenants' => (int)$lic['max_tenants'],
            'hardware_id' => $hwId,
            'issued_at'   => date('c', strtotime($lic['issued_at'])),
            'expires_at'  => date('c', strtotime($lic['expires_at'])),
            'version'     => '2.0',
        ];
        $signedPayload = signLicense($payload);
        $db->prepare('UPDATE licenses SET signed_payload = ? WHERE id = ?')->execute([$signedPayload, $licenseId]);

        $db->prepare('INSERT INTO license_history (license_id, action, details, performed_by) VALUES (?, "modified", ?, ?)')
           ->execute([$licenseId, "Hardware ID actualizado", $admin['id']]);

        flash('success', 'Hardware ID actualizado y licencia re-firmada.');
        header("Location: /internal/license_detail.php?id=$licenseId");
        exit;
    }
}

// Reload after potential changes
$lic = $db->prepare('SELECT l.*, c.company_name, c.client_code, c.contact_email FROM licenses l JOIN clients c ON c.id = l.client_id WHERE l.id = ?');
$lic->execute([$licenseId]);
$lic = $lic->fetch();

$daysLeft = (int)((strtotime($lic['expires_at']) - time()) / 86400);

$history = $db->prepare('SELECT lh.*, a.full_name as admin_name FROM license_history lh LEFT JOIN admin_users a ON a.id = lh.performed_by WHERE lh.license_id = ? ORDER BY lh.created_at DESC');
$history->execute([$licenseId]);
$history = $history->fetchAll();

renderHeader("Licencia: {$lic['license_number']}", 'internal', $admin);
?>

<div class="page-header">
  <span class="page-label">
    <a href="/internal/licenses.php" style="color:var(--accent)">Licencias</a> &rsaquo;
    <a href="/internal/client_detail.php?id=<?= $lic['client_id'] ?>" style="color:var(--accent)"><?= e($lic['company_name']) ?></a> &rsaquo; Detalle
  </span>
  <h1 style="font-size:1.4rem">
    <code class="mono"><?= e($lic['license_number']) ?></code>
  </h1>
  <p>
    <span class="badge badge--<?= e($lic['status']) ?>"><?= e(ucfirst($lic['status'])) ?></span>
    <?php if ($lic['penalty_level'] !== 'none'): ?>
    <span class="badge badge--<?= e($lic['penalty_level']) ?>">&#x25C6; <?= e(ucfirst($lic['penalty_level'])) ?></span>
    <?php endif; ?>
    &nbsp; <?= $daysLeft >= 0 ? "$daysLeft dias restantes" : abs($daysLeft) . " dias caducada" ?>
  </p>
</div>

<!-- Summary -->
<div class="stats-grid" style="margin-bottom:24px">
  <div class="stat-card">
    <div class="stat-label">Usuarios</div>
    <div class="stat-value"><?= $lic['max_users'] ?></div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Equipos</div>
    <div class="stat-value"><?= $lic['max_equipos'] ?></div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Tenants</div>
    <div class="stat-value"><?= $lic['max_tenants'] ?></div>
  </div>
  <div class="stat-card">
    <div class="stat-label">IA</div>
    <div class="stat-value <?= $lic['ia_enabled'] ? 'stat-value--green' : '' ?>"><?= $lic['ia_enabled'] ? 'Activo' : 'No' ?></div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Soporte dedicado</div>
    <div class="stat-value <?= $lic['soporte_dedicado'] ? 'stat-value--green' : '' ?>"><?= $lic['soporte_dedicado'] ? 'Si' : 'No' ?></div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Caduca</div>
    <div class="stat-value <?= $daysLeft < 0 ? 'stat-value--red' : ($daysLeft < 30 ? 'stat-value--amber' : '') ?>">
      <?= e(substr($lic['expires_at'], 0, 10)) ?>
    </div>
    <div class="stat-sub"><?= $daysLeft >= 0 ? "$daysLeft dias" : "Caducada hace " . abs($daysLeft) . " dias" ?></div>
  </div>
</div>

<!-- Actions -->
<div class="card" style="margin-bottom:24px">
  <div class="card-header">
    <h3 class="card-title">Acciones</h3>
  </div>
  <div style="display:flex;gap:12px;flex-wrap:wrap">
    <!-- Modify limits -->
    <button class="btn btn-secondary" onclick="document.getElementById('modal-limits').classList.add('active')">Modificar limites</button>
    <!-- Renew -->
    <button class="btn btn-secondary" onclick="document.getElementById('modal-renew').classList.add('active')">Renovar</button>
    <!-- Hardware -->
    <button class="btn btn-secondary" onclick="document.getElementById('modal-hw').classList.add('active')">Actualizar hardware</button>
    <!-- Download .key -->
    <a href="/internal/download_license.php?id=<?= $licenseId ?>" class="btn btn-primary btn-sm">Descargar .key</a>
    <!-- Suspend/reactivate -->
    <?php if ($lic['status'] === 'active'): ?>
    <form method="POST" onsubmit="return confirm('Suspender esta licencia?')">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="suspend">
      <button type="submit" class="btn btn-danger">Suspender</button>
    </form>
    <?php elseif ($lic['status'] === 'suspended'): ?>
    <form method="POST">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="reactivate">
      <button type="submit" class="btn btn-primary">Reactivar</button>
    </form>
    <?php endif; ?>
  </div>
</div>

<!-- Detail info -->
<div class="detail-grid" style="margin-bottom:24px">
  <div class="detail-item">
    <div class="detail-label">Hardware ID</div>
    <div class="detail-value" style="font-family:var(--font-mono);font-size:0.78rem;word-break:break-all"><?= e($lic['hardware_id'] ?: 'No configurado') ?></div>
  </div>
  <div class="detail-item">
    <div class="detail-label">Clave publica</div>
    <div class="detail-value" style="font-family:var(--font-mono);font-size:0.78rem;word-break:break-all"><?= e(substr($lic['public_key_hex'], 0, 32)) ?>...</div>
  </div>
  <div class="detail-item">
    <div class="detail-label">Emitida</div>
    <div class="detail-value"><?= e($lic['issued_at']) ?></div>
  </div>
  <div class="detail-item">
    <div class="detail-label">Renovada</div>
    <div class="detail-value"><?= e($lic['renewed_at'] ?: 'Nunca') ?></div>
  </div>
</div>

<!-- History -->
<div class="card">
  <div class="card-header">
    <h3 class="card-title">Historial de cambios</h3>
  </div>
  <div class="timeline">
    <?php foreach ($history as $h): ?>
    <div class="timeline-item">
      <div class="timeline-date"><?= e($h['created_at']) ?> &middot; <?= e($h['admin_name'] ?? 'Sistema') ?></div>
      <div class="timeline-text"><?= e(ucfirst($h['action'])) ?>: <?= e($h['details'] ?? '') ?></div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- Modify limits modal -->
<div class="modal-overlay" id="modal-limits">
  <div class="modal">
    <h3 class="modal-title">Modificar limites</h3>
    <form method="POST">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="modify_limits">
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Max. usuarios</label>
          <input type="number" name="max_users" class="form-input" value="<?= $lic['max_users'] ?>" min="1">
        </div>
        <div class="form-group">
          <label class="form-label">Max. equipos</label>
          <input type="number" name="max_equipos" class="form-input" value="<?= $lic['max_equipos'] ?>" min="1">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Max. tenants</label>
          <input type="number" name="max_tenants" class="form-input" value="<?= $lic['max_tenants'] ?>" min="1">
        </div>
        <div class="form-group" style="display:flex;flex-direction:column;justify-content:center;gap:8px">
          <label class="form-check">
            <input type="checkbox" name="ia_enabled" value="1" <?= $lic['ia_enabled'] ? 'checked' : '' ?>>
            <span>Modulo IA</span>
          </label>
          <label class="form-check">
            <input type="checkbox" name="soporte_dedicado" value="1" <?= $lic['soporte_dedicado'] ? 'checked' : '' ?>>
            <span>Soporte dedicado</span>
          </label>
          <label class="form-check">
            <input type="checkbox" name="formacion" value="1" <?= $lic['formacion'] ? 'checked' : '' ?>>
            <span>Formacion</span>
          </label>
        </div>
      </div>
      <div class="btn-group" style="justify-content:flex-end;margin-top:12px">
        <button type="button" class="btn btn-secondary" onclick="this.closest('.modal-overlay').classList.remove('active')">Cancelar</button>
        <button type="submit" class="btn btn-primary">Guardar y re-firmar</button>
      </div>
    </form>
  </div>
</div>

<!-- Renew modal -->
<div class="modal-overlay" id="modal-renew">
  <div class="modal">
    <h3 class="modal-title">Renovar licencia</h3>
    <form method="POST">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="renew">
      <div class="form-group">
        <label class="form-label">Dias a anadir</label>
        <input type="number" name="renew_days" class="form-input" value="365" min="30" max="3650">
        <span class="form-hint">Se anadiran a la fecha de caducidad actual (<?= e(substr($lic['expires_at'], 0, 10)) ?>)</span>
      </div>
      <div class="btn-group" style="justify-content:flex-end;margin-top:12px">
        <button type="button" class="btn btn-secondary" onclick="this.closest('.modal-overlay').classList.remove('active')">Cancelar</button>
        <button type="submit" class="btn btn-primary">Renovar y re-firmar</button>
      </div>
    </form>
  </div>
</div>

<!-- Hardware modal -->
<div class="modal-overlay" id="modal-hw">
  <div class="modal">
    <h3 class="modal-title">Actualizar hardware ID</h3>
    <form method="POST">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="update_hardware">
      <div class="form-group">
        <label class="form-label">Hardware fingerprint</label>
        <input type="text" name="hardware_id" class="form-input" value="<?= e($lic['hardware_id'] ?? '') ?>">
        <span class="form-hint">El cliente lo obtiene con: arche-server --fingerprint</span>
      </div>
      <div class="btn-group" style="justify-content:flex-end;margin-top:12px">
        <button type="button" class="btn btn-secondary" onclick="this.closest('.modal-overlay').classList.remove('active')">Cancelar</button>
        <button type="submit" class="btn btn-primary">Actualizar y re-firmar</button>
      </div>
    </form>
  </div>
</div>

<script>
document.querySelectorAll('.modal-overlay').forEach(m => {
  m.addEventListener('click', function(e) { if (e.target === this) this.classList.remove('active'); });
});
</script>

<?php renderFooter(); ?>
