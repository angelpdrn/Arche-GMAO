<?php
require_once __DIR__ . '/../includes/layout.php';

$admin = requireAdmin();
$db = getDB();

$statusFilter = $_GET['status'] ?? '';
$where = '';
$params = [];
if ($statusFilter && in_array($statusFilter, ['active','expired','suspended','revoked'])) {
    $where = 'WHERE l.status = ?';
    $params = [$statusFilter];
}

$licenses = $db->prepare("
    SELECT l.*, c.company_name, c.client_code, c.contact_email
    FROM licenses l
    JOIN clients c ON c.id = l.client_id
    $where
    ORDER BY l.created_at DESC
");
$licenses->execute($params);
$licenses = $licenses->fetchAll();

renderHeader('Licencias', 'internal', $admin);
?>

<div class="page-header">
  <span class="page-label">Gestion</span>
  <h1>Licencias</h1>
  <p>Todas las licencias generadas para clientes</p>
</div>

<div class="tabs">
  <a href="/internal/licenses.php" class="tab <?= !$statusFilter ? 'active' : '' ?>">Todas</a>
  <a href="/internal/licenses.php?status=active" class="tab <?= $statusFilter === 'active' ? 'active' : '' ?>">Activas</a>
  <a href="/internal/licenses.php?status=expired" class="tab <?= $statusFilter === 'expired' ? 'active' : '' ?>">Expiradas</a>
  <a href="/internal/licenses.php?status=suspended" class="tab <?= $statusFilter === 'suspended' ? 'active' : '' ?>">Suspendidas</a>
</div>

<?php if (empty($licenses)): ?>
<div class="empty-state">
  <div class="empty-state-icon">&#x25A3;</div>
  <p>No hay licencias<?= $statusFilter ? " con estado \"$statusFilter\"" : '' ?></p>
</div>
<?php else: ?>
<div class="table-wrap">
  <table class="table">
    <thead>
      <tr>
        <th>Numero</th>
        <th>Cliente</th>
        <th>Estado</th>
        <th>Penalizacion</th>
        <th>Usuarios</th>
        <th>Equipos</th>
        <th>Tenants</th>
        <th>IA</th>
        <th>Caduca</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($licenses as $l): ?>
      <tr>
        <td><code class="mono"><?= e(substr($l['license_number'], 0, 16)) ?>...</code></td>
        <td>
          <a href="/internal/client_detail.php?id=<?= $l['client_id'] ?>" style="color:var(--accent-light)">
            <?= e($l['company_name']) ?>
          </a>
        </td>
        <td><span class="badge badge--<?= e($l['status']) ?>"><?= e(ucfirst($l['status'])) ?></span></td>
        <td><span class="badge badge--<?= e($l['penalty_level']) ?>"><?= e(ucfirst($l['penalty_level'])) ?></span></td>
        <td><?= $l['max_users'] ?></td>
        <td><?= $l['max_equipos'] ?></td>
        <td><?= $l['max_tenants'] ?></td>
        <td style="color:<?= $l['ia_enabled'] ? 'var(--green)' : 'var(--text-muted)' ?>"><?= $l['ia_enabled'] ? 'Si' : 'No' ?></td>
        <td><?= e(substr($l['expires_at'], 0, 10)) ?></td>
        <td><a href="/internal/license_detail.php?id=<?= $l['id'] ?>" class="btn btn-sm btn-secondary">Detalle</a></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

<?php renderFooter(); ?>
