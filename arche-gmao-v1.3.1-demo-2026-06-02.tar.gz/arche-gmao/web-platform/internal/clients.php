<?php
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/license_crypto.php';

$admin = requireAdmin();
$db = getDB();

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $company  = trim($_POST['company_name'] ?? '');
        $contact  = trim($_POST['contact_name'] ?? '');
        $email    = trim($_POST['contact_email'] ?? '');
        $phone    = trim($_POST['contact_phone'] ?? '');
        $code     = trim($_POST['client_code'] ?? '');
        $password = $_POST['password'] ?? '';
        $notes    = trim($_POST['notes'] ?? '');

        if ($company && $contact && $email && $code && $password) {
            $code = preg_replace('/[^a-z0-9-]/', '', strtolower($code));
            $stmt = $db->prepare('INSERT INTO clients (company_name, contact_name, contact_email, contact_phone, password_hash, client_code, status, notes) VALUES (?, ?, ?, ?, ?, ?, "pending", ?)');
            $stmt->execute([$company, $contact, $email, $phone, hashPassword($password), $code, $notes]);
            flash('success', "Cliente '$company' creado correctamente.");
        } else {
            flash('error', 'Todos los campos obligatorios deben completarse.');
        }
        header('Location: /internal/clients.php');
        exit;
    }

    if ($action === 'approve' && !empty($_POST['client_id'])) {
        $clientId = (int)$_POST['client_id'];
        $db->prepare('UPDATE clients SET status = "active", approved_by = ?, approved_at = NOW() WHERE id = ?')
           ->execute([$admin['id'], $clientId]);

        $client = $db->prepare('SELECT * FROM clients WHERE id = ?');
        $client->execute([$clientId]);
        $client = $client->fetch();

        flash('success', "Cliente '{$client['company_name']}' aprobado. Ahora puedes crear su licencia.");
        header('Location: /internal/clients.php');
        exit;
    }

    if ($action === 'suspend' && !empty($_POST['client_id'])) {
        $clientId = (int)$_POST['client_id'];
        $db->prepare('UPDATE clients SET status = "suspended" WHERE id = ?')->execute([$clientId]);
        $db->prepare('UPDATE licenses SET status = "suspended", penalty_level = "suspension", penalty_since = NOW() WHERE client_id = ? AND status = "active"')
           ->execute([$clientId]);
        flash('warning', 'Cliente suspendido.');
        header('Location: /internal/clients.php');
        exit;
    }

    if ($action === 'reactivate' && !empty($_POST['client_id'])) {
        $clientId = (int)$_POST['client_id'];
        $db->prepare('UPDATE clients SET status = "active" WHERE id = ?')->execute([$clientId]);
        $db->prepare('UPDATE licenses SET status = "active", penalty_level = "none", penalty_since = NULL WHERE client_id = ? AND status = "suspended"')
           ->execute([$clientId]);
        flash('success', 'Cliente reactivado.');
        header('Location: /internal/clients.php');
        exit;
    }
}

// Filters
$statusFilter = $_GET['status'] ?? '';
$where = '';
$params = [];
if ($statusFilter && in_array($statusFilter, ['pending','active','suspended','cancelled'])) {
    $where = 'WHERE c.status = ?';
    $params = [$statusFilter];
}

$clients = $db->prepare("
    SELECT c.*,
           (SELECT COUNT(*) FROM licenses l WHERE l.client_id = c.id AND l.status = 'active') as active_licenses,
           (SELECT MAX(ph.created_at) FROM phone_home_logs ph WHERE ph.client_id = c.id) as last_phonehome
    FROM clients c
    $where
    ORDER BY c.created_at DESC
");
$clients->execute($params);
$clients = $clients->fetchAll();

renderHeader('Clientes', 'internal', $admin);
?>

<div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between">
  <div>
    <span class="page-label">Gestion</span>
    <h1>Clientes</h1>
  </div>
  <button class="btn btn-primary" onclick="document.getElementById('modal-create').classList.add('active')">
    + Nuevo cliente
  </button>
</div>

<!-- Filters -->
<div class="tabs">
  <a href="/internal/clients.php" class="tab <?= !$statusFilter ? 'active' : '' ?>">Todos</a>
  <a href="/internal/clients.php?status=pending" class="tab <?= $statusFilter === 'pending' ? 'active' : '' ?>">Pendientes</a>
  <a href="/internal/clients.php?status=active" class="tab <?= $statusFilter === 'active' ? 'active' : '' ?>">Activos</a>
  <a href="/internal/clients.php?status=suspended" class="tab <?= $statusFilter === 'suspended' ? 'active' : '' ?>">Suspendidos</a>
</div>

<?php if (empty($clients)): ?>
<div class="empty-state">
  <div class="empty-state-icon">&#x25C7;</div>
  <p>No hay clientes<?= $statusFilter ? ' con estado "' . e($statusFilter) . '"' : '' ?></p>
</div>
<?php else: ?>
<div class="table-wrap">
  <table class="table">
    <thead>
      <tr>
        <th>Empresa</th>
        <th>Contacto</th>
        <th>Codigo</th>
        <th>Estado</th>
        <th>Licencias</th>
        <th>Ultimo phone-home</th>
        <th>Creado</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($clients as $c): ?>
      <tr>
        <td><strong style="color:var(--text)"><?= e($c['company_name']) ?></strong></td>
        <td>
          <?= e($c['contact_name']) ?><br>
          <span style="font-size:0.78rem;color:var(--text-muted)"><?= e($c['contact_email']) ?></span>
        </td>
        <td><code class="mono"><?= e($c['client_code']) ?></code></td>
        <td><span class="badge badge--<?= e($c['status']) ?>"><?= e(ucfirst($c['status'])) ?></span></td>
        <td><?= (int)$c['active_licenses'] ?></td>
        <td>
          <?php if ($c['last_phonehome']): ?>
            <?php
              $lastPH = new DateTime($c['last_phonehome']);
              $hoursSince = (time() - $lastPH->getTimestamp()) / 3600;
              $isOnline = $hoursSince < 48;
            ?>
            <span class="phonehome-pulse phonehome-pulse--<?= $isOnline ? 'online' : 'offline' ?>"></span>
            <?= e(substr($c['last_phonehome'], 0, 16)) ?>
          <?php else: ?>
            <span style="color:var(--text-muted)">Nunca</span>
          <?php endif; ?>
        </td>
        <td><?= e(substr($c['created_at'], 0, 10)) ?></td>
        <td>
          <div class="client-actions">
            <a href="/internal/client_detail.php?id=<?= $c['id'] ?>" class="btn btn-sm btn-secondary">Ver</a>
            <?php if ($c['status'] === 'pending'): ?>
            <form method="POST" style="display:inline">
              <?= csrfField() ?>
              <input type="hidden" name="action" value="approve">
              <input type="hidden" name="client_id" value="<?= $c['id'] ?>">
              <button type="submit" class="btn btn-sm btn-primary">Aprobar</button>
            </form>
            <?php elseif ($c['status'] === 'active'): ?>
            <form method="POST" style="display:inline" onsubmit="return confirm('Suspender este cliente?')">
              <?= csrfField() ?>
              <input type="hidden" name="action" value="suspend">
              <input type="hidden" name="client_id" value="<?= $c['id'] ?>">
              <button type="submit" class="btn btn-sm btn-danger">Suspender</button>
            </form>
            <?php elseif ($c['status'] === 'suspended'): ?>
            <form method="POST" style="display:inline">
              <?= csrfField() ?>
              <input type="hidden" name="action" value="reactivate">
              <input type="hidden" name="client_id" value="<?= $c['id'] ?>">
              <button type="submit" class="btn btn-sm btn-primary">Reactivar</button>
            </form>
            <?php endif; ?>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

<!-- Create client modal -->
<div class="modal-overlay" id="modal-create">
  <div class="modal">
    <h3 class="modal-title">Nuevo cliente</h3>
    <form method="POST">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="create">

      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Empresa *</label>
          <input type="text" name="company_name" class="form-input" required>
        </div>
        <div class="form-group">
          <label class="form-label">Codigo cliente *</label>
          <input type="text" name="client_code" class="form-input" required placeholder="ej: carnicas-demo"
                 pattern="[a-z0-9\-]+" title="Solo minusculas, numeros y guiones">
          <span class="form-hint">Identificador unico, sin espacios</span>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Nombre de contacto *</label>
          <input type="text" name="contact_name" class="form-input" required>
        </div>
        <div class="form-group">
          <label class="form-label">Email de contacto *</label>
          <input type="email" name="contact_email" class="form-input" required>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Telefono</label>
          <input type="text" name="contact_phone" class="form-input">
        </div>
        <div class="form-group">
          <label class="form-label">Contrasena portal *</label>
          <input type="password" name="password" class="form-input" required minlength="8">
          <span class="form-hint">Min. 8 caracteres. El cliente usara esto para entrar al portal.</span>
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Notas internas</label>
        <textarea name="notes" class="form-textarea" rows="3"></textarea>
      </div>

      <div class="btn-group" style="justify-content:flex-end;margin-top:8px">
        <button type="button" class="btn btn-secondary" onclick="this.closest('.modal-overlay').classList.remove('active')">Cancelar</button>
        <button type="submit" class="btn btn-primary">Crear cliente</button>
      </div>
    </form>
  </div>
</div>

<script>
document.getElementById('modal-create').addEventListener('click', function(e) {
  if (e.target === this) this.classList.remove('active');
});
</script>

<?php renderFooter(); ?>
