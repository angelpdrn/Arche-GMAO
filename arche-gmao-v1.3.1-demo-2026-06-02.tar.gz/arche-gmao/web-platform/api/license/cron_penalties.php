<?php
// Cron job — recalculate penalties for all active licenses
// Run via IONOS cron: curl -s https://archesystem.com/api/license/cron_penalties.php?key=SECRET
//
// This ensures penalties are applied even if clients don't phone home.

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/license_crypto.php';

header('Content-Type: application/json');

// Simple auth via query param (set this in IONOS cron config)
$cronKey = $_GET['key'] ?? '';
$expectedKey = 'arche-cron-2026'; // Change in production

if ($cronKey !== $expectedKey) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$db = getDB();

$licenses = $db->query("SELECT l.*, c.status as client_status FROM licenses l JOIN clients c ON c.id = l.client_id WHERE l.status IN ('active','expired')")->fetchAll();

$updated = 0;
foreach ($licenses as $lic) {
    $forcedSuspension = ($lic['client_status'] === 'suspended' || $lic['client_status'] === 'cancelled') ? 'forced' : null;
    $newLevel = calculatePenaltyLevel($lic['expires_at'], $forcedSuspension);

    if ($newLevel !== $lic['penalty_level']) {
        if ($newLevel !== 'none') {
            $db->prepare('UPDATE licenses SET penalty_level = ?, penalty_since = COALESCE(penalty_since, NOW()) WHERE id = ?')
               ->execute([$newLevel, $lic['id']]);
        } else {
            $db->prepare('UPDATE licenses SET penalty_level = "none", penalty_since = NULL WHERE id = ?')
               ->execute([$lic['id']]);
        }
        $updated++;
    }

    // Auto-expire if past suspension threshold
    if ($newLevel === 'suspension' && $lic['status'] === 'active') {
        $db->prepare('UPDATE licenses SET status = "expired" WHERE id = ?')->execute([$lic['id']]);
    }
}

echo json_encode([
    'ok'      => true,
    'checked' => count($licenses),
    'updated' => $updated,
    'time'    => date('c'),
]);
