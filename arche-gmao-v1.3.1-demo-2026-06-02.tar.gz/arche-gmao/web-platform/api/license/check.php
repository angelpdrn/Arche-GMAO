<?php
// Phone-Home API — Arche GMAO License Validation
// POST /api/license/check
//
// Request:
//   { "license_id": "hex...", "hardware_id": "sha256...", "app_version": "1.3.1",
//     "current_users": 12, "current_equipos": 45, "current_tenants": 1 }
//
// Response:
//   { "status": "ok|warning|readonly|blocked|suspended",
//     "penalty_level": "none|aviso|lectura|bloqueo|suspension",
//     "message": "...",
//     "limits": { "max_users": N, "max_equipos": N, "max_tenants": N, "ia_enabled": bool },
//     "days_left": N,
//     "expires_at": "2027-..." }

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/license_crypto.php';

header('Content-Type: application/json; charset=utf-8');
header('X-Arche-API: 1.0');

// Only POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Rate limit by IP (simple, 60 req/hour)
$ip = $_SERVER['REMOTE_ADDR'];

// Parse request
$raw = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!$data || empty($data['license_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'license_id requerido']);
    exit;
}

$licenseId      = $data['license_id'];
$hardwareId     = $data['hardware_id'] ?? '';
$appVersion     = $data['app_version'] ?? '';
$currentUsers   = (int)($data['current_users'] ?? 0);
$currentEquipos = (int)($data['current_equipos'] ?? 0);
$currentTenants = (int)($data['current_tenants'] ?? 0);

$db = getDB();

// Find license
$stmt = $db->prepare('
    SELECT l.*, c.id as client_id_fk, c.status as client_status, c.company_name
    FROM licenses l
    JOIN clients c ON c.id = l.client_id
    WHERE l.license_number = ?
');
$stmt->execute([$licenseId]);
$license = $stmt->fetch();

if (!$license) {
    logPhoneHome($db, 0, 0, $ip, $hardwareId, $appVersion, $currentUsers, $currentEquipos, $currentTenants, 'unknown', 404);
    http_response_code(404);
    echo json_encode([
        'status'  => 'suspended',
        'penalty_level' => 'suspension',
        'message' => 'Licencia no encontrada',
    ]);
    exit;
}

// Check client status
if ($license['client_status'] === 'suspended' || $license['client_status'] === 'cancelled') {
    $db->prepare('UPDATE licenses SET penalty_level = "suspension", penalty_since = COALESCE(penalty_since, NOW()) WHERE id = ?')
       ->execute([$license['id']]);

    logPhoneHome($db, $license['id'], $license['client_id_fk'], $ip, $hardwareId, $appVersion, $currentUsers, $currentEquipos, $currentTenants, 'suspension', 403);

    echo json_encode([
        'status'        => 'suspended',
        'penalty_level' => 'suspension',
        'message'       => 'Cuenta de cliente suspendida. Contacta con Arche GMAO.',
        'limits'        => getLimits($license),
        'days_left'     => 0,
        'expires_at'    => $license['expires_at'],
    ]);
    exit;
}

// Check license status
if ($license['status'] === 'revoked') {
    logPhoneHome($db, $license['id'], $license['client_id_fk'], $ip, $hardwareId, $appVersion, $currentUsers, $currentEquipos, $currentTenants, 'suspension', 403);
    echo json_encode([
        'status'        => 'suspended',
        'penalty_level' => 'suspension',
        'message'       => 'Licencia revocada.',
        'limits'        => getLimits($license),
        'days_left'     => 0,
        'expires_at'    => $license['expires_at'],
    ]);
    exit;
}

if ($license['status'] === 'suspended') {
    logPhoneHome($db, $license['id'], $license['client_id_fk'], $ip, $hardwareId, $appVersion, $currentUsers, $currentEquipos, $currentTenants, 'suspension', 403);
    echo json_encode([
        'status'        => 'suspended',
        'penalty_level' => 'suspension',
        'message'       => 'Licencia suspendida por el administrador.',
        'limits'        => getLimits($license),
        'days_left'     => 0,
        'expires_at'    => $license['expires_at'],
    ]);
    exit;
}

// Hardware check (if license has hardware_id set)
if (!empty($license['hardware_id']) && $hardwareId && $license['hardware_id'] !== $hardwareId) {
    logPhoneHome($db, $license['id'], $license['client_id_fk'], $ip, $hardwareId, $appVersion, $currentUsers, $currentEquipos, $currentTenants, 'suspension', 403);
    echo json_encode([
        'status'        => 'suspended',
        'penalty_level' => 'suspension',
        'message'       => 'Hardware no coincide con la licencia. Posible clonacion detectada.',
        'limits'        => getLimits($license),
        'days_left'     => 0,
        'expires_at'    => $license['expires_at'],
    ]);
    exit;
}

// Calculate penalty level
$penaltyLevel = calculatePenaltyLevel($license['expires_at']);
$daysLeft = (int)((strtotime($license['expires_at']) - time()) / 86400);

// Update penalty in DB if changed
if ($penaltyLevel !== $license['penalty_level']) {
    $penaltySince = $penaltyLevel !== 'none' ? 'NOW()' : 'NULL';
    if ($penaltyLevel !== 'none') {
        $db->prepare('UPDATE licenses SET penalty_level = ?, penalty_since = COALESCE(penalty_since, NOW()) WHERE id = ?')
           ->execute([$penaltyLevel, $license['id']]);
    } else {
        $db->prepare('UPDATE licenses SET penalty_level = "none", penalty_since = NULL WHERE id = ?')
           ->execute([$license['id']]);
    }

    // Auto-expire license if past suspension
    if ($penaltyLevel === 'suspension' && $license['status'] === 'active') {
        $db->prepare('UPDATE licenses SET status = "expired" WHERE id = ?')->execute([$license['id']]);
    }
}

// Build response
$statusMap = [
    'none'       => 'ok',
    'aviso'      => 'warning',
    'lectura'    => 'readonly',
    'bloqueo'    => 'blocked',
    'suspension' => 'suspended',
];

$messageMap = [
    'none'       => 'Licencia valida.',
    'aviso'      => "Tu licencia caduca en $daysLeft dias. Contacta con Arche GMAO para renovar.",
    'lectura'    => 'Licencia caducada. Sistema en modo solo lectura.',
    'bloqueo'    => 'Licencia caducada. Acceso restringido.',
    'suspension' => 'Licencia suspendida. Sistema bloqueado.',
];

logPhoneHome($db, $license['id'], $license['client_id_fk'], $ip, $hardwareId, $appVersion, $currentUsers, $currentEquipos, $currentTenants, $penaltyLevel, 200);

// Return updated license payload if available (allows remote limit changes)
$response = [
    'status'        => $statusMap[$penaltyLevel] ?? 'ok',
    'penalty_level' => $penaltyLevel,
    'message'       => $messageMap[$penaltyLevel] ?? '',
    'limits'        => getLimits($license),
    'days_left'     => max(0, $daysLeft),
    'expires_at'    => $license['expires_at'],
    'signed_license' => $license['signed_payload'],
];

echo json_encode($response, JSON_UNESCAPED_UNICODE);
exit;

// ─── Helpers ───────────────────────────────────────────────────────────────

function getLimits(array $license): array {
    return [
        'max_users'     => (int)$license['max_users'],
        'max_equipos'   => (int)$license['max_equipos'],
        'max_tenants'   => (int)$license['max_tenants'],
        'ia_enabled'    => (bool)$license['ia_enabled'],
    ];
}

function logPhoneHome(PDO $db, int $licenseId, int $clientId, string $ip, string $hardwareId, string $appVersion, int $users, int $equipos, int $tenants, string $penalty, int $code): void {
    try {
        $db->prepare('INSERT INTO phone_home_logs
            (license_id, client_id, ip_address, hardware_id, app_version, current_users, current_equipos, current_tenants, penalty_level, response_code)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
           ->execute([$licenseId ?: null, $clientId ?: null, $ip, $hardwareId, $appVersion, $users, $equipos, $tenants, $penalty, $code]);
    } catch (Exception $e) {
        // Don't fail the check if logging fails
    }
}
