<?php
// Arche GMAO — Web Platform Config

define('APP_NAME', 'Arche GMAO');
define('APP_VERSION', '1.0.0');
define('APP_URL', 'https://archesystem.com');

// MariaDB
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'arche_platform');
define('DB_USER', getenv('DB_USER') ?: 'arche_web');
define('DB_PASS', getenv('DB_PASS') ?: 'arche-web-dev');
define('DB_CHARSET', 'utf8mb4');

// Session
define('SESSION_LIFETIME', 86400); // 24h
define('SESSION_NAME', 'arche_session');

// Paths
define('BASE_PATH', dirname(__DIR__));
define('UPLOADS_PATH', BASE_PATH . '/uploads');
define('BINARIES_PATH', BASE_PATH . '/uploads/binaries');

// Security
define('CSRF_TOKEN_NAME', 'arche_csrf');
define('BCRYPT_COST', 12);

// Penalty thresholds (days relative to expiration)
define('PENALTY_AVISO_DAYS', 15);    // 15 days before expiry
define('PENALTY_LECTURA_DAYS', 0);   // at expiry
define('PENALTY_BLOQUEO_DAYS', 7);   // 7 days after expiry
define('PENALTY_SUSPENSION_DAYS', 30); // 30 days after expiry

// Timezone
date_default_timezone_set('Europe/Madrid');

// Error reporting
if (getenv('APP_ENV') === 'production') {
    error_reporting(0);
    ini_set('display_errors', '0');
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
}
