<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

function startSession(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_name(SESSION_NAME);
        $isSecure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
        session_start([
            'cookie_lifetime' => SESSION_LIFETIME,
            'cookie_httponly'  => true,
            'cookie_secure'    => $isSecure,
            'cookie_samesite'  => 'Lax',
        ]);
    }
}

// ─── CSRF ──────────────────────────────────────────────────────────────────

function csrfToken(): string {
    startSession();
    if (empty($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

function csrfField(): string {
    return '<input type="hidden" name="' . CSRF_TOKEN_NAME . '" value="' . htmlspecialchars(csrfToken()) . '">';
}

function verifyCsrf(): bool {
    startSession();
    $token = $_POST[CSRF_TOKEN_NAME] ?? '';
    return hash_equals($_SESSION[CSRF_TOKEN_NAME] ?? '', $token);
}

// ─── Admin auth ────────────────────────────────────────────────────────────

function adminLogin(string $email, string $password): ?array {
    $db = getDB();
    $stmt = $db->prepare('SELECT * FROM admin_users WHERE email = ? AND is_active = 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password_hash'])) {
        startSession();
        $_SESSION['admin_id'] = $user['id'];
        $_SESSION['admin_role'] = $user['role'];
        $_SESSION['admin_name'] = $user['full_name'];

        $db->prepare('UPDATE admin_users SET last_login = NOW() WHERE id = ?')
           ->execute([$user['id']]);

        return $user;
    }
    return null;
}

function requireAdmin(): array {
    startSession();
    if (empty($_SESSION['admin_id'])) {
        header('Location: /internal/login.php');
        exit;
    }
    return [
        'id'   => $_SESSION['admin_id'],
        'role' => $_SESSION['admin_role'],
        'name' => $_SESSION['admin_name'],
    ];
}

function isAdminLoggedIn(): bool {
    startSession();
    return !empty($_SESSION['admin_id']);
}

// ─── Client auth ───────────────────────────────────────────────────────────

function clientLogin(string $email, string $password): ?array {
    $db = getDB();
    $stmt = $db->prepare('SELECT * FROM clients WHERE contact_email = ? AND status IN ("active","pending")');
    $stmt->execute([$email]);
    $client = $stmt->fetch();

    if ($client && password_verify($password, $client['password_hash'])) {
        startSession();
        $_SESSION['client_id'] = $client['id'];
        $_SESSION['client_code'] = $client['client_code'];
        $_SESSION['client_name'] = $client['company_name'];
        $_SESSION['client_status'] = $client['status'];

        $db->prepare('UPDATE clients SET last_login = NOW() WHERE id = ?')
           ->execute([$client['id']]);

        return $client;
    }
    return null;
}

function requireClient(): array {
    startSession();
    if (empty($_SESSION['client_id'])) {
        header('Location: /clientes/login.php');
        exit;
    }
    return [
        'id'     => $_SESSION['client_id'],
        'code'   => $_SESSION['client_code'],
        'name'   => $_SESSION['client_name'],
        'status' => $_SESSION['client_status'],
    ];
}

function isClientLoggedIn(): bool {
    startSession();
    return !empty($_SESSION['client_id']);
}

function logout(): void {
    startSession();
    session_destroy();
}

// ─── Helpers ───────────────────────────────────────────────────────────────

function hashPassword(string $password): string {
    return password_hash($password, PASSWORD_BCRYPT, ['cost' => BCRYPT_COST]);
}

function e(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

function jsonResponse(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function flash(string $type, string $message): void {
    startSession();
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function getFlash(): array {
    startSession();
    $messages = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $messages;
}
