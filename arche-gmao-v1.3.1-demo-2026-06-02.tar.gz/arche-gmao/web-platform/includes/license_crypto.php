<?php
// Ed25519 license signing via sodium (PHP 7.2+)

require_once __DIR__ . '/db.php';

function getKeyPair(): array {
    $db = getDB();

    $privEnc = $db->query("SELECT setting_value FROM settings WHERE setting_key = 'ed25519_private_key_enc'")->fetchColumn();
    $pubHex  = $db->query("SELECT setting_value FROM settings WHERE setting_key = 'ed25519_public_key_hex'")->fetchColumn();

    if (empty($privEnc) || empty($pubHex)) {
        throw new RuntimeException('Claves Ed25519 no configuradas. Ejecutar setup.');
    }

    return [
        'private' => base64_decode($privEnc),
        'public'  => hex2bin($pubHex),
        'public_hex' => $pubHex,
    ];
}

function generateKeyPair(): array {
    $keypair = sodium_crypto_sign_keypair();
    $secret  = sodium_crypto_sign_secretkey($keypair);
    $public  = sodium_crypto_sign_publickey($keypair);

    $db = getDB();
    $db->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = 'ed25519_private_key_enc'")
       ->execute([base64_encode($secret)]);
    $db->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = 'ed25519_public_key_hex'")
       ->execute([bin2hex($public)]);

    return [
        'private' => $secret,
        'public'  => $public,
        'public_hex' => bin2hex($public),
    ];
}

function hasKeyPair(): bool {
    $db = getDB();
    $pubHex = $db->query("SELECT setting_value FROM settings WHERE setting_key = 'ed25519_public_key_hex'")->fetchColumn();
    return !empty($pubHex);
}

function generateLicenseNumber(): string {
    return bin2hex(random_bytes(16));
}

function signLicense(array $payload): string {
    $keys = getKeyPair();

    $payloadJson = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    $signature = sodium_crypto_sign_detached($payloadJson, $keys['private']);

    $signed = json_encode([
        'payload'   => json_decode($payloadJson),
        'signature' => base64_encode($signature),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    return base64_encode($signed);
}

function createSignedLicense(
    int $clientId,
    string $clientName,
    string $clientCode,
    int $maxUsers,
    int $maxEquipos,
    int $maxTenants,
    bool $iaEnabled,
    string $hardwareId,
    string $expiresAt,
    int $createdBy
): array {
    $db = getDB();
    $keys = getKeyPair();

    $licenseNumber = generateLicenseNumber();

    $modules = ['core', 'preventive', 'metrics', 'qr', 'reports', 'offline'];
    if ($iaEnabled) {
        $modules[] = 'ai';
    }

    $payload = [
        'license_id'  => $licenseNumber,
        'client_name' => $clientName,
        'client_id'   => $clientCode,
        'modules'     => $modules,
        'max_users'   => $maxUsers,
        'max_nodes'   => $maxEquipos,
        'max_tenants' => $maxTenants,
        'hardware_id' => $hardwareId,
        'issued_at'   => date('c'),
        'expires_at'  => $expiresAt,
        'version'     => '2.0',
    ];

    $signedPayload = signLicense($payload);

    $stmt = $db->prepare('INSERT INTO licenses
        (client_id, license_number, status, max_users, max_equipos, max_tenants,
         ia_enabled, hardware_id, signed_payload, public_key_hex,
         issued_at, expires_at, created_by)
        VALUES (?, ?, "active", ?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?)');

    $expiresAtDb = date('Y-m-d H:i:s', strtotime($expiresAt));

    $stmt->execute([
        $clientId,
        $licenseNumber,
        $maxUsers,
        $maxEquipos,
        $maxTenants,
        $iaEnabled ? 1 : 0,
        $hardwareId,
        $signedPayload,
        $keys['public_hex'],
        $expiresAtDb,
        $createdBy,
    ]);

    $licenseId = $db->lastInsertId();

    $db->prepare('INSERT INTO license_history (license_id, action, details, performed_by) VALUES (?, "created", ?, ?)')
       ->execute([$licenseId, "Licencia creada: $maxUsers usuarios, $maxEquipos equipos, $maxTenants tenants", $createdBy]);

    return [
        'id'             => $licenseId,
        'license_number' => $licenseNumber,
        'signed_payload' => $signedPayload,
        'payload'        => $payload,
    ];
}

function calculatePenaltyLevel(string $expiresAt, ?string $forcedSuspension = null): string {
    if ($forcedSuspension) {
        return 'suspension';
    }

    $now = new DateTime();
    $expires = new DateTime($expiresAt);
    $diff = $now->diff($expires);
    $daysUntil = (int)$diff->format('%r%a');

    if ($daysUntil > PENALTY_AVISO_DAYS) {
        return 'none';
    }
    if ($daysUntil > PENALTY_LECTURA_DAYS) {
        return 'aviso';
    }
    if ($daysUntil > -PENALTY_BLOQUEO_DAYS) {
        return 'lectura';
    }
    if ($daysUntil > -PENALTY_SUSPENSION_DAYS) {
        return 'bloqueo';
    }
    return 'suspension';
}
