<?php
require_once __DIR__ . '/auth.php';

function renderHeader(string $title, string $section = 'public', array $user = []): void {
    $flashMessages = getFlash();
    ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="robots" content="noindex, nofollow">
  <title><?= e($title) ?> — Arche GMAO</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/css/platform.css">
  <?php if ($section === 'internal'): ?>
  <link rel="stylesheet" href="/assets/css/admin.css">
  <?php elseif ($section === 'clientes'): ?>
  <link rel="stylesheet" href="/assets/css/client.css">
  <?php endif; ?>
</head>
<body>
  <nav class="navbar" id="navbar">
    <div class="nav-inner">
      <a href="/" class="nav-logo">
        <span class="logo-icon">A</span>
        <span class="logo-text">ARCHE<span class="logo-accent">SYSTEM</span></span>
      </a>
      <?php if ($section === 'internal' && !empty($user)): ?>
      <div class="nav-links">
        <a href="/internal/" class="nav-link">Dashboard</a>
        <a href="/internal/clients.php" class="nav-link">Clientes</a>
        <a href="/internal/licenses.php" class="nav-link">Licencias</a>
        <a href="/internal/phonehome.php" class="nav-link">Phone-Home</a>
        <a href="/internal/downloads.php" class="nav-link">Descargas</a>
        <a href="/internal/support.php" class="nav-link">Soporte</a>
        <div class="nav-user">
          <span class="nav-user-name"><?= e($user['name']) ?></span>
          <a href="/internal/logout.php" class="nav-link nav-link--logout">Salir</a>
        </div>
      </div>
      <?php elseif ($section === 'clientes' && !empty($user)): ?>
      <div class="nav-links">
        <a href="/clientes/" class="nav-link">Mi Panel</a>
        <a href="/clientes/license.php" class="nav-link">Licencia</a>
        <a href="/clientes/downloads.php" class="nav-link">Descargas</a>
        <a href="/clientes/support.php" class="nav-link">Soporte</a>
        <div class="nav-user">
          <span class="nav-user-name"><?= e($user['name']) ?></span>
          <a href="/clientes/logout.php" class="nav-link nav-link--logout">Salir</a>
        </div>
      </div>
      <?php endif; ?>
      <button class="nav-toggle" id="nav-toggle" aria-label="Menu">
        <span></span><span></span><span></span>
      </button>
    </div>
  </nav>

  <main class="main-content">
    <?php foreach ($flashMessages as $msg): ?>
    <div class="flash flash--<?= e($msg['type']) ?>">
      <?= e($msg['message']) ?>
      <button class="flash-close" onclick="this.parentElement.remove()">&times;</button>
    </div>
    <?php endforeach; ?>
<?php
}

function renderFooter(): void {
    $year = date('Y');
    ?>
  </main>

  <footer class="footer">
    <div class="footer-inner">
      <div class="footer-brand">
        <span class="logo-icon">A</span>
        <span class="logo-text">ARCHE<span class="logo-accent">SYSTEM</span></span>
      </div>
      <span class="footer-copy">&copy; <?= $year ?> Arche GMAO. Todos los derechos reservados.</span>
    </div>
  </footer>

  <script>
    // Mobile nav toggle
    const toggle = document.getElementById('nav-toggle');
    const links = document.querySelector('.nav-links');
    if (toggle && links) {
      toggle.addEventListener('click', () => {
        links.classList.toggle('open');
        toggle.classList.toggle('active');
      });
    }

    // Auto-dismiss flash messages
    document.querySelectorAll('.flash').forEach(el => {
      setTimeout(() => el.remove(), 5000);
    });
  </script>
</body>
</html>
<?php
}
