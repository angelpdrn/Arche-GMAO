<?php
require_once __DIR__ . '/../includes/layout.php';

$client = requireClient();
$db = getDB();

// Get client data
$clientData = $db->prepare('SELECT * FROM clients WHERE id = ?');
$clientData->execute([$client['id']]);
$clientData = $clientData->fetch();

// Get active license
$license = $db->prepare('SELECT * FROM licenses WHERE client_id = ? AND status = "active" ORDER BY created_at DESC LIMIT 1');
$license->execute([$client['id']]);
$license = $license->fetch();

$daysLeft = $license ? (int)((strtotime($license['expires_at']) - time()) / 86400) : 0;
$penaltyLevel = $license['penalty_level'] ?? 'none';

// Open tickets count
$openTickets = $db->prepare('SELECT COUNT(*) FROM support_tickets WHERE client_id = ? AND status IN ("open","in_progress")');
$openTickets->execute([$client['id']]);
$openTickets = $openTickets->fetchColumn();

// Available downloads
$downloads = $db->prepare('SELECT COUNT(*) FROM downloads WHERE client_id = ? AND is_active = 1');
$downloads->execute([$client['id']]);
$downloadCount = $downloads->fetchColumn();

renderHeader('Mi Panel', 'clientes', $client);
?>

<?php if ($clientData['status'] === 'pending'): ?>
<div class="penalty-banner penalty-banner--aviso">
  <span class="penalty-icon">&#x25C6;</span>
  <span class="penalty-text">Tu cuenta esta pendiente de aprobacion. Recibiras un email cuando sea activada.</span>
</div>
<?php endif; ?>

<?php if ($penaltyLevel !== 'none'): ?>
<?php
$penaltyMessages = [
    'aviso'      => 'Tu licencia caduca pronto. Contacta con Arche GMAO para renovar.',
    'lectura'    => 'Tu licencia ha caducado. El sistema esta en modo solo lectura. No se pueden crear ni modificar registros.',
    'bloqueo'    => 'Licencia caducada. El acceso al sistema esta bloqueado excepto para consulta basica. Renueva tu licencia.',
    'suspension' => 'Licencia suspendida. El sistema esta completamente bloqueado. Contacta con Arche GMAO urgentemente.',
];
?>
<div class="penalty-banner penalty-banner--<?= e($penaltyLevel) ?>">
  <span class="penalty-icon">&#x25C6;</span>
  <span class="penalty-text"><?= $penaltyMessages[$penaltyLevel] ?? '' ?></span>
</div>
<?php endif; ?>

<div class="page-header">
  <span class="page-label">Portal de clientes</span>
  <h1>Bienvenido, <?= e($clientData['contact_name']) ?></h1>
  <p><?= e($clientData['company_name']) ?></p>
</div>

<?php if ($license): ?>
<div class="stats-grid">
  <div class="stat-card">
    <div class="stat-label">Dias restantes</div>
    <div class="stat-value <?= $daysLeft < 0 ? 'stat-value--red' : ($daysLeft < 30 ? 'stat-value--amber' : 'stat-value--green') ?>">
      <?= $daysLeft >= 0 ? $daysLeft : 0 ?>
    </div>
    <div class="stat-sub"><?= $daysLeft < 0 ? 'Licencia caducada' : 'hasta caducidad' ?></div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Usuarios</div>
    <div class="stat-value"><?= $license['max_users'] ?></div>
    <div class="stat-sub">limite maximo</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Equipos</div>
    <div class="stat-value"><?= $license['max_equipos'] ?></div>
    <div class="stat-sub">limite maximo</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Fabricas</div>
    <div class="stat-value"><?= $license['max_tenants'] ?></div>
    <div class="stat-sub">tenants</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Modulo IA</div>
    <div class="stat-value <?= $license['ia_enabled'] ? 'stat-value--green' : '' ?>"><?= $license['ia_enabled'] ? 'Activo' : 'No incluido' ?></div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Estado</div>
    <div class="stat-value <?= $penaltyLevel === 'none' ? 'stat-value--green' : 'stat-value--red' ?>">
      <?= $penaltyLevel === 'none' ? 'OK' : ucfirst($penaltyLevel) ?>
    </div>
  </div>
</div>

<!-- Expiry countdown -->
<div class="expiry-countdown">
  <div class="expiry-days" style="color:<?= $daysLeft < 0 ? 'var(--red)' : ($daysLeft < 30 ? 'var(--amber)' : 'var(--green)') ?>">
    <?= abs($daysLeft) ?>
  </div>
  <div class="expiry-label">
    <?php if ($daysLeft < 0): ?>
      dias desde que caduco la licencia
    <?php elseif ($daysLeft === 0): ?>
      La licencia caduca hoy
    <?php else: ?>
      dias hasta la caducidad
    <?php endif; ?>
  </div>
  <div style="font-size:0.82rem;color:var(--text-muted);margin-top:8px">
    Fecha de caducidad: <?= e(substr($license['expires_at'], 0, 10)) ?>
  </div>
</div>
<?php else: ?>
<div class="card">
  <div class="empty-state">
    <div class="empty-state-icon">&#x25A3;</div>
    <p>No tienes ninguna licencia activa.</p>
    <p style="font-size:0.82rem;color:var(--text-muted);margin-top:8px">Contacta con Arche GMAO para solicitar tu licencia.</p>
  </div>
</div>
<?php endif; ?>

<!-- Quick links -->
<div class="stats-grid" style="margin-top:24px">
  <a href="/clientes/license.php" class="stat-card" style="text-decoration:none">
    <div class="stat-label">Licencia</div>
    <div style="font-size:0.9rem;color:var(--accent-light);font-weight:600">Ver detalles completos &#x2192;</div>
  </a>
  <a href="/clientes/downloads.php" class="stat-card" style="text-decoration:none">
    <div class="stat-label">Descargas</div>
    <div style="font-size:0.9rem;color:var(--accent-light);font-weight:600"><?= $downloadCount ?> disponibles &#x2192;</div>
  </a>
  <a href="/clientes/support.php" class="stat-card" style="text-decoration:none">
    <div class="stat-label">Soporte</div>
    <div style="font-size:0.9rem;color:var(--accent-light);font-weight:600"><?= $openTickets ?> tickets abiertos &#x2192;</div>
  </a>
</div>

<?php renderFooter(); ?>
