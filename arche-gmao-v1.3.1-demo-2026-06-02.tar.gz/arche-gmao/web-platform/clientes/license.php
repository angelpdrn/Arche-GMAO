<?php
require_once __DIR__ . '/../includes/layout.php';

$client = requireClient();
$db = getDB();

$clientData = $db->prepare('SELECT * FROM clients WHERE id = ?');
$clientData->execute([$client['id']]);
$clientData = $clientData->fetch();

// All licenses (active + historical)
$licenses = $db->prepare('SELECT * FROM licenses WHERE client_id = ? ORDER BY created_at DESC');
$licenses->execute([$client['id']]);
$licenses = $licenses->fetchAll();

$activeLicense = null;
foreach ($licenses as $l) {
    if ($l['status'] === 'active') { $activeLicense = $l; break; }
}

$daysLeft = $activeLicense ? (int)((strtotime($activeLicense['expires_at']) - time()) / 86400) : 0;

// License history
$history = [];
if ($activeLicense) {
    $stmt = $db->prepare('SELECT action, details, created_at FROM license_history WHERE license_id = ? ORDER BY created_at DESC LIMIT 10');
    $stmt->execute([$activeLicense['id']]);
    $history = $stmt->fetchAll();
}

renderHeader('Mi Licencia', 'clientes', $client);
?>

<div class="page-header">
  <span class="page-label">Mi licencia</span>
  <h1>Informacion de licencia</h1>
  <p>Consulta el estado, limites y modulos de tu licencia de Arche GMAO</p>
</div>

<?php if (!$activeLicense): ?>
<div class="card">
  <div class="empty-state">
    <div class="empty-state-icon">&#x25A3;</div>
    <p>No tienes una licencia activa.</p>
    <p style="font-size:0.86rem;color:var(--text-secondary);margin-top:12px">
      Contacta con nuestro equipo en <a href="mailto:info@archesystem.com" style="color:var(--accent-light)">info@archesystem.com</a>
      para solicitar tu licencia personalizada.
    </p>
  </div>
</div>
<?php else: ?>

<!-- License card -->
<div class="license-card">
  <div class="license-card-header">
    <div>
      <h3 style="font-size:1.1rem;font-weight:700;margin-bottom:4px"><?= e($clientData['company_name']) ?></h3>
      <span class="license-number"><?= e($activeLicense['license_number']) ?></span>
    </div>
    <span class="badge badge--<?= e($activeLicense['status']) ?>" style="font-size:0.82rem;padding:6px 16px">
      <?= e(ucfirst($activeLicense['status'])) ?>
    </span>
  </div>

  <!-- Expiry -->
  <div class="expiry-countdown" style="margin:0 0 24px">
    <div class="expiry-days" style="color:<?= $daysLeft < 0 ? 'var(--red)' : ($daysLeft < 30 ? 'var(--amber)' : 'var(--green)') ?>">
      <?= abs($daysLeft) ?>
    </div>
    <div class="expiry-label">
      <?= $daysLeft < 0 ? 'dias caducada' : ($daysLeft === 0 ? 'caduca hoy' : 'dias restantes') ?>
    </div>
    <div style="font-size:0.82rem;color:var(--text-muted);margin-top:8px">
      Emitida: <?= e(substr($activeLicense['issued_at'], 0, 10)) ?>
      &nbsp;&#x2022;&nbsp;
      Caduca: <?= e(substr($activeLicense['expires_at'], 0, 10)) ?>
      <?php if ($activeLicense['renewed_at']): ?>
      &nbsp;&#x2022;&nbsp;
      Renovada: <?= e(substr($activeLicense['renewed_at'], 0, 10)) ?>
      <?php endif; ?>
    </div>
  </div>

  <!-- Contracted limits -->
  <h4 style="font-size:0.82rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:var(--text-muted);margin-bottom:16px">
    Tu configuracion contratada
  </h4>

  <div class="limits-grid">
    <div class="limit-card">
      <div class="limit-card-label">Usuarios</div>
      <div class="limit-card-value"><?= $activeLicense['max_users'] ?></div>
      <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">usuarios simultaneos</div>
    </div>
    <div class="limit-card">
      <div class="limit-card-label">Equipos</div>
      <div class="limit-card-value"><?= $activeLicense['max_equipos'] ?></div>
      <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">nodos tipo equipo</div>
    </div>
    <div class="limit-card">
      <div class="limit-card-label">Fabricas</div>
      <div class="limit-card-value"><?= $activeLicense['max_tenants'] ?></div>
      <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">tenants independientes</div>
    </div>
    <div class="limit-card">
      <div class="limit-card-label">Arche IA</div>
      <div class="limit-card-value limit-card-value--bool <?= $activeLicense['ia_enabled'] ? 'limit-enabled' : 'limit-disabled' ?>">
        <?= $activeLicense['ia_enabled'] ? '&#x2713; Activo' : '&#x2715; No incluido' ?>
      </div>
    </div>
    <div class="limit-card">
      <div class="limit-card-label">Soporte dedicado</div>
      <div class="limit-card-value limit-card-value--bool <?= $activeLicense['soporte_dedicado'] ? 'limit-enabled' : 'limit-disabled' ?>">
        <?= $activeLicense['soporte_dedicado'] ? '&#x2713; Activo' : '&#x2715; No incluido' ?>
      </div>
    </div>
    <div class="limit-card">
      <div class="limit-card-label">Formacion</div>
      <div class="limit-card-value limit-card-value--bool <?= $activeLicense['formacion'] ? 'limit-enabled' : 'limit-disabled' ?>">
        <?= $activeLicense['formacion'] ? '&#x2713; Contratada' : '&#x2715; No incluida' ?>
      </div>
    </div>
  </div>

  <!-- Modules always included -->
  <div style="margin-top:24px;padding:20px;background:var(--bg-card);border-radius:var(--radius);border:1px solid var(--border)">
    <h4 style="font-size:0.82rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:var(--text-muted);margin-bottom:12px">
      Modulos incluidos en tu licencia
    </h4>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:8px">
      <?php
      $modulosBase = [
          ['Nucleo CMMS', 'OTs, fabrica virtual, inventario, calendario'],
          ['Mantenimiento preventivo', 'Planes, escalonamiento, SOPs'],
          ['Metricas y KPIs', 'OEE, MTBF, MTTR, Health Score'],
          ['Codigos QR', 'Escaneo movil, historial instantaneo'],
          ['Informes', 'Reportes Excel, resumenes diarios'],
          ['Modo offline', 'Trabajo sin conexion, sincronizacion'],
      ];
      foreach ($modulosBase as $mod):
      ?>
      <div style="display:flex;align-items:flex-start;gap:8px;padding:8px">
        <span style="color:var(--green);font-size:0.9rem;flex-shrink:0">&#x2713;</span>
        <div>
          <div style="font-size:0.84rem;font-weight:600"><?= $mod[0] ?></div>
          <div style="font-size:0.72rem;color:var(--text-muted)"><?= $mod[1] ?></div>
        </div>
      </div>
      <?php endforeach; ?>
      <div style="display:flex;align-items:flex-start;gap:8px;padding:8px">
        <span style="color:<?= $activeLicense['ia_enabled'] ? 'var(--green)' : 'var(--text-muted)' ?>;font-size:0.9rem;flex-shrink:0">
          <?= $activeLicense['ia_enabled'] ? '&#x2713;' : '&#x2715;' ?>
        </span>
        <div>
          <div style="font-size:0.84rem;font-weight:600;color:<?= $activeLicense['ia_enabled'] ? 'var(--text)' : 'var(--text-muted)' ?>">Arche IA</div>
          <div style="font-size:0.72rem;color:var(--text-muted)">Chat RAG, patrones, analisis predictivo</div>
        </div>
      </div>
    </div>
  </div>

  <!-- Current penalty, when there is one -->
  <?php if ($activeLicense['penalty_level'] !== 'none'): ?>
  <div style="margin-top:24px;padding:20px;border-radius:var(--radius);background:rgba(233,69,96,0.08);border:1px solid rgba(233,69,96,0.15)">
    <h4 style="font-size:0.82rem;font-weight:700;color:var(--red);margin-bottom:8px">
      &#x25C6; Penalizacion activa: <?= e(ucfirst($activeLicense['penalty_level'])) ?>
    </h4>
    <p style="font-size:0.86rem;color:var(--text-secondary)">
      <?php
      $penaltyDesc = [
          'aviso'      => 'Tu licencia esta proxima a caducar. El sistema funciona con normalidad pero deberias renovar para evitar restricciones.',
          'lectura'    => 'Tu licencia ha caducado. El sistema esta en modo solo lectura: puedes consultar datos pero no crear ni modificar registros.',
          'bloqueo'    => 'El acceso al sistema esta restringido. Solo puedes acceder a consultas basicas. Renueva tu licencia para restaurar el servicio.',
          'suspension' => 'Tu instalacion esta completamente bloqueada. Contacta urgentemente con Arche GMAO para restablecer el servicio.',
      ];
      echo $penaltyDesc[$activeLicense['penalty_level']] ?? '';
      ?>
    </p>
    <p style="font-size:0.82rem;color:var(--text-muted);margin-top:8px">
      Para renovar, contacta con <a href="mailto:info@archesystem.com" style="color:var(--accent-light)">info@archesystem.com</a>
    </p>
  </div>
  <?php endif; ?>
</div>

<!-- Need more? -->
<div class="card" style="margin-bottom:24px">
  <div style="text-align:center;padding:24px">
    <h3 style="font-size:1.05rem;font-weight:700;margin-bottom:8px">Necesitas ajustar tu configuracion?</h3>
    <p style="font-size:0.9rem;color:var(--text-secondary);max-width:500px;margin:0 auto 16px">
      Puedes ampliar o reducir usuarios, equipos y fabricas en cualquier momento.
      Solo pagas por lo que realmente necesitas. Contactanos y ajustamos tu licencia.
    </p>
    <a href="/clientes/support.php?new=1" class="btn btn-primary">Solicitar cambio de limites</a>
  </div>
</div>

<!-- History -->
<?php if (!empty($history)): ?>
<div class="card">
  <div class="card-header">
    <h3 class="card-title">Historial de licencia</h3>
  </div>
  <div class="timeline">
    <?php foreach ($history as $h): ?>
    <div class="timeline-item">
      <div class="timeline-date"><?= e(substr($h['created_at'], 0, 16)) ?></div>
      <div class="timeline-text"><?= e(ucfirst($h['action'])) ?>: <?= e($h['details'] ?? '') ?></div>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<?php endif; ?>

<?php renderFooter(); ?>
