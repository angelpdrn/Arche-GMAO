<?php
require_once __DIR__ . '/../includes/layout.php';

$client = requireClient();
$db = getDB();

// Handle download
if (!empty($_GET['download'])) {
    $downloadId = (int)$_GET['download'];
    $dl = $db->prepare('SELECT * FROM downloads WHERE id = ? AND client_id = ? AND is_active = 1');
    $dl->execute([$downloadId, $client['id']]);
    $dl = $dl->fetch();

    if ($dl && file_exists($dl['file_path'])) {
        $db->prepare('UPDATE downloads SET download_count = download_count + 1 WHERE id = ?')
           ->execute([$downloadId]);
        $db->prepare('INSERT INTO download_logs (download_id, client_id, ip_address) VALUES (?, ?, ?)')
           ->execute([$downloadId, $client['id'], $_SERVER['REMOTE_ADDR']]);

        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $dl['filename'] . '"');
        header('Content-Length: ' . $dl['file_size']);
        readfile($dl['file_path']);
        exit;
    }
    flash('error', 'Descarga no disponible.');
    header('Location: /clientes/downloads.php');
    exit;
}

$downloads = $db->prepare('
    SELECT d.*, l.license_number
    FROM downloads d
    JOIN licenses l ON l.id = d.license_id
    WHERE d.client_id = ? AND d.is_active = 1
    ORDER BY d.created_at DESC
');
$downloads->execute([$client['id']]);
$downloads = $downloads->fetchAll();

renderHeader('Descargas', 'clientes', $client);
?>

<div class="page-header">
  <span class="page-label">Descargas</span>
  <h1>Tus binarios</h1>
  <p>Descarga tu instalador de Arche GMAO pre-configurado con tu licencia</p>
</div>

<?php if (empty($downloads)): ?>
<div class="card">
  <div class="empty-state">
    <div class="empty-state-icon">&#x25A3;</div>
    <p>No hay descargas disponibles para tu cuenta.</p>
    <p style="font-size:0.82rem;color:var(--text-muted);margin-top:8px">
      Tu binario estara disponible cuando el equipo de Arche GMAO lo prepare.
    </p>
  </div>
</div>
<?php else: ?>
<?php foreach ($downloads as $dl): ?>
<div class="download-card">
  <div class="download-info">
    <h4><?= e($dl['filename']) ?></h4>
    <div class="download-meta">
      <span>Version <?= e($dl['version']) ?></span>
      <span><?= number_format($dl['file_size'] / 1048576, 1) ?> MB</span>
      <span>Subido: <?= e(substr($dl['created_at'], 0, 10)) ?></span>
      <?php if ($dl['sha256_hash']): ?>
      <span title="<?= e($dl['sha256_hash']) ?>">SHA256: <?= e(substr($dl['sha256_hash'], 0, 12)) ?>...</span>
      <?php endif; ?>
    </div>
  </div>
  <a href="/clientes/downloads.php?download=<?= $dl['id'] ?>" class="btn btn-primary btn-sm">
    Descargar
  </a>
</div>
<?php endforeach; ?>

<div class="card" style="margin-top:24px">
  <div style="padding:20px;text-align:center">
    <h4 style="font-size:0.95rem;font-weight:600;margin-bottom:8px">Instrucciones de instalacion</h4>
    <p style="font-size:0.86rem;color:var(--text-secondary);max-width:600px;margin:0 auto;line-height:1.7">
      1. Descarga el binario en tu servidor Linux<br>
      2. Dale permisos de ejecucion: <code style="background:var(--bg-card);padding:2px 8px;border-radius:4px;font-size:0.82rem">chmod +x arche-server</code><br>
      3. Ejecuta el instalador: <code style="background:var(--bg-card);padding:2px 8px;border-radius:4px;font-size:0.82rem">./arche-server --setup</code><br>
      4. Sigue el asistente — solo tendras que configurar puertos y directorio
    </p>
    <p style="font-size:0.78rem;color:var(--text-muted);margin-top:12px">
      Tu licencia y limites ya vienen preconfigurados. No necesitas tocar nada mas.
    </p>
  </div>
</div>
<?php endif; ?>

<?php renderFooter(); ?>
