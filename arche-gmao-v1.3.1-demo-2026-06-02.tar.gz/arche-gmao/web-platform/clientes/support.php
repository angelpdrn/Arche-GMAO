<?php
require_once __DIR__ . '/../includes/layout.php';

$client = requireClient();
$db = getDB();

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $subject  = trim($_POST['subject'] ?? '');
        $message  = trim($_POST['message'] ?? '');
        $priority = $_POST['priority'] ?? 'normal';

        if ($subject && $message) {
            $db->prepare('INSERT INTO support_tickets (client_id, subject, message, priority) VALUES (?, ?, ?, ?)')
               ->execute([$client['id'], $subject, $message, $priority]);
            flash('success', 'Ticket creado correctamente. Te responderemos lo antes posible.');
            header('Location: /clientes/support.php');
            exit;
        }
        flash('error', 'Asunto y mensaje son obligatorios.');
    }

    if ($action === 'reply' && !empty($_POST['ticket_id'])) {
        $ticketId = (int)$_POST['ticket_id'];
        $message  = trim($_POST['message'] ?? '');

        // Verify ticket belongs to this client
        $check = $db->prepare('SELECT id FROM support_tickets WHERE id = ? AND client_id = ?');
        $check->execute([$ticketId, $client['id']]);
        if ($check->fetch() && $message) {
            $db->prepare('INSERT INTO ticket_replies (ticket_id, author_type, author_id, message) VALUES (?, "client", ?, ?)')
               ->execute([$ticketId, $client['id'], $message]);
            $db->prepare('UPDATE support_tickets SET status = "open", updated_at = NOW() WHERE id = ? AND status != "closed"')
               ->execute([$ticketId]);
            flash('success', 'Respuesta enviada.');
        }
        header("Location: /clientes/support.php?ticket=$ticketId");
        exit;
    }
}

// View single ticket
$ticketId = (int)($_GET['ticket'] ?? 0);
if ($ticketId) {
    $ticket = $db->prepare('SELECT * FROM support_tickets WHERE id = ? AND client_id = ?');
    $ticket->execute([$ticketId, $client['id']]);
    $ticket = $ticket->fetch();

    if (!$ticket) { header('Location: /clientes/support.php'); exit; }

    $replies = $db->prepare('
        SELECT r.*,
               CASE WHEN r.author_type = "admin" THEN (SELECT full_name FROM admin_users WHERE id = r.author_id)
                    ELSE ? END as author_name
        FROM ticket_replies r WHERE r.ticket_id = ? ORDER BY r.created_at ASC
    ');
    $replies->execute([$client['name'], $ticketId]);
    $replies = $replies->fetchAll();

    renderHeader("Ticket #{$ticket['id']}", 'clientes', $client);
    ?>
    <div class="page-header">
      <span class="page-label"><a href="/clientes/support.php" style="color:var(--accent)">Soporte</a> &rsaquo; Ticket #<?= $ticket['id'] ?></span>
      <h1><?= e($ticket['subject']) ?></h1>
      <p>
        <span class="badge badge--<?= $ticket['status'] === 'open' ? 'pending' : ($ticket['status'] === 'resolved' ? 'active' : 'expired') ?>">
          <?= e(ucfirst(str_replace('_', ' ', $ticket['status']))) ?>
        </span>
        &middot; <?= e(substr($ticket['created_at'], 0, 16)) ?>
      </p>
    </div>

    <div class="card" style="margin-bottom:16px">
      <!-- Original message -->
      <div style="padding:16px;background:var(--bg-card);border-radius:var(--radius-sm);margin-bottom:16px">
        <div style="font-size:0.78rem;color:var(--text-muted);margin-bottom:8px">Tu &middot; <?= e(substr($ticket['created_at'], 0, 16)) ?></div>
        <div style="white-space:pre-wrap;font-size:0.9rem;color:var(--text-secondary)"><?= e($ticket['message']) ?></div>
      </div>

      <!-- Replies -->
      <?php foreach ($replies as $r): ?>
      <div style="padding:16px;background:<?= $r['author_type'] === 'admin' ? 'var(--accent-glow)' : 'var(--bg-card)' ?>;border-radius:var(--radius-sm);margin-bottom:8px;border-left:3px solid <?= $r['author_type'] === 'admin' ? 'var(--accent)' : 'var(--border-light)' ?>">
        <div style="font-size:0.78rem;color:var(--text-muted);margin-bottom:8px">
          <?= e($r['author_name']) ?> (<?= $r['author_type'] === 'admin' ? 'Equipo Arche' : 'Tu' ?>) &middot; <?= e(substr($r['created_at'], 0, 16)) ?>
        </div>
        <div style="white-space:pre-wrap;font-size:0.9rem;color:var(--text-secondary)"><?= e($r['message']) ?></div>
      </div>
      <?php endforeach; ?>

      <!-- Reply form -->
      <?php if ($ticket['status'] !== 'closed'): ?>
      <form method="POST" style="margin-top:16px">
        <?= csrfField() ?>
        <input type="hidden" name="action" value="reply">
        <input type="hidden" name="ticket_id" value="<?= $ticket['id'] ?>">
        <div class="form-group">
          <textarea name="message" class="form-textarea" required placeholder="Escribe tu respuesta..." rows="4"></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Responder</button>
      </form>
      <?php else: ?>
      <div style="text-align:center;padding:16px;color:var(--text-muted);font-size:0.86rem">
        Este ticket esta cerrado. Abre uno nuevo si necesitas mas ayuda.
      </div>
      <?php endif; ?>
    </div>

    <?php
    renderFooter();
    exit;
}

// Check if new ticket form requested
$showNew = !empty($_GET['new']);

// List tickets
$tickets = $db->prepare('SELECT * FROM support_tickets WHERE client_id = ? ORDER BY created_at DESC');
$tickets->execute([$client['id']]);
$tickets = $tickets->fetchAll();

renderHeader('Soporte', 'clientes', $client);
?>

<div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between">
  <div>
    <span class="page-label">Soporte</span>
    <h1>Tus tickets</h1>
    <p>Crea tickets de soporte y consulta el estado de los existentes</p>
  </div>
  <button class="btn btn-primary" onclick="document.getElementById('modal-ticket').classList.add('active')">
    + Nuevo ticket
  </button>
</div>

<?php if (empty($tickets)): ?>
<div class="card">
  <div class="empty-state">
    <div class="empty-state-icon">&#x2713;</div>
    <p>No tienes tickets de soporte.</p>
    <p style="font-size:0.82rem;color:var(--text-muted);margin-top:8px">Crea uno si necesitas ayuda con tu instalacion.</p>
  </div>
</div>
<?php else: ?>
<div class="table-wrap">
  <table class="table">
    <thead>
      <tr>
        <th>#</th>
        <th>Asunto</th>
        <th>Prioridad</th>
        <th>Estado</th>
        <th>Creado</th>
        <th>Actualizado</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($tickets as $t): ?>
      <tr>
        <td><?= $t['id'] ?></td>
        <td><?= e($t['subject']) ?></td>
        <td>
          <span class="badge badge--<?= $t['priority'] === 'urgent' ? 'suspended' : ($t['priority'] === 'high' ? 'aviso' : 'none') ?>">
            <?= e(ucfirst($t['priority'])) ?>
          </span>
        </td>
        <td>
          <span class="badge badge--<?= $t['status'] === 'open' ? 'pending' : ($t['status'] === 'resolved' ? 'active' : ($t['status'] === 'closed' ? 'expired' : 'aviso')) ?>">
            <?= e(ucfirst(str_replace('_', ' ', $t['status']))) ?>
          </span>
        </td>
        <td><?= e(substr($t['created_at'], 0, 16)) ?></td>
        <td><?= e(substr($t['updated_at'], 0, 16)) ?></td>
        <td><a href="/clientes/support.php?ticket=<?= $t['id'] ?>" class="btn btn-sm btn-secondary">Ver</a></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

<!-- New ticket modal -->
<div class="modal-overlay <?= $showNew ? 'active' : '' ?>" id="modal-ticket">
  <div class="modal">
    <h3 class="modal-title">Nuevo ticket de soporte</h3>
    <form method="POST">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="create">

      <div class="form-group">
        <label class="form-label">Asunto</label>
        <input type="text" name="subject" class="form-input" required
               value="<?= e($_GET['subject'] ?? '') ?>"
               placeholder="ej: Solicitud de ampliacion de usuarios">
      </div>

      <div class="form-group">
        <label class="form-label">Prioridad</label>
        <select name="priority" class="form-select">
          <option value="low">Baja</option>
          <option value="normal" selected>Normal</option>
          <option value="high">Alta</option>
          <option value="urgent">Urgente</option>
        </select>
      </div>

      <div class="form-group">
        <label class="form-label">Mensaje</label>
        <textarea name="message" class="form-textarea" required rows="5"
                  placeholder="Describe tu consulta, problema o solicitud..."></textarea>
      </div>

      <div class="btn-group" style="justify-content:flex-end;margin-top:12px">
        <button type="button" class="btn btn-secondary" onclick="this.closest('.modal-overlay').classList.remove('active')">Cancelar</button>
        <button type="submit" class="btn btn-primary">Enviar ticket</button>
      </div>
    </form>
  </div>
</div>

<script>
document.getElementById('modal-ticket').addEventListener('click', function(e) {
  if (e.target === this) this.classList.remove('active');
});
</script>

<?php renderFooter(); ?>
