<?php
require_once __DIR__ . '/../includes/auth.php';

if (isClientLoggedIn()) {
    header('Location: /clientes/');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrf()) {
        $error = 'Token de seguridad invalido.';
    } else {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $client = clientLogin($email, $password);
        if ($client) {
            header('Location: /clientes/');
            exit;
        }
        $error = 'Credenciales incorrectas o cuenta no activa.';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="robots" content="noindex, nofollow">
  <title>Portal de clientes — Arche GMAO</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/css/platform.css">
</head>
<body>
  <div class="login-wrapper">
    <div class="login-box">
      <div class="login-logo">
        <span class="logo-icon">A</span>
        <span class="logo-text">ARCHE<span class="logo-accent">SYSTEM</span></span>
      </div>
      <h2 class="login-title">Portal de clientes</h2>
      <p class="login-subtitle">Accede a tu licencia, descargas y soporte</p>

      <?php if ($error): ?>
      <div class="flash flash--error" style="margin-bottom:20px"><?= e($error) ?></div>
      <?php endif; ?>

      <form method="POST">
        <?= csrfField() ?>
        <div class="form-group">
          <label class="form-label">Email</label>
          <input type="email" name="email" class="form-input" required autofocus
                 value="<?= e($_POST['email'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label class="form-label">Contrasena</label>
          <input type="password" name="password" class="form-input" required>
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;margin-top:8px">
          Acceder
        </button>
      </form>

      <p style="text-align:center;margin-top:20px;font-size:0.82rem;color:var(--text-muted)">
        Si no tienes cuenta, contacta con <a href="mailto:info@archesystem.com" style="color:var(--accent-light)">info@archesystem.com</a>
      </p>
    </div>
  </div>
</body>
</html>
