-- ============================================================
-- Arche GMAO - Migration 018: AI columns for tenants
-- ============================================================
-- Adds the per-tenant AI configuration columns referenced
-- by ai_admin_handler.go (models, roles, system prompt).

ALTER TABLE tenants ADD COLUMN IF NOT EXISTS ai_chat_model    VARCHAR(100) DEFAULT 'llama3';
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS ai_embed_model   VARCHAR(100) DEFAULT 'nomic-embed-text';
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS ai_enabled_roles JSONB DEFAULT '["admin","supervisor","technician","operator","warehouse","auditor"]'::jsonb;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS ai_system_prompt TEXT;
