-- ============================================================
-- Arche GMAO - Migration 004: Initial data
-- ============================================================
-- Creates the tenant and the initial administrator user.
--
-- Access credentials:
--   Email:      admin@arche.local
--   Password:   Admin@1234
--
-- IMPORTANT: change the password after the first login
-- in any environment other than local development.

-- Initial tenant
INSERT INTO tenants (id, name, slug, status, plan)
VALUES (1, 'Arche GMAO', 'arche', 'active', 'enterprise')
ON CONFLICT (slug) DO NOTHING;

SELECT setval('tenants_id_seq', 1, true);

-- Administrator user
INSERT INTO users (tenant_id, email, password_hash, full_name, role, status)
VALUES (
    1,
    'admin@arche.local',
    crypt('Admin@1234', gen_salt('bf', 10)),
    'Administrador del Sistema',
    'admin',
    'active'
)
ON CONFLICT (tenant_id, email) DO NOTHING;
