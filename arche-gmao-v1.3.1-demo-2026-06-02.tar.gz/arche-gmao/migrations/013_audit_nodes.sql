-- ============================================================
-- Arche GMAO - Migration 013: Auditing on factory_nodes
-- ============================================================

ALTER TABLE factory_nodes ADD COLUMN IF NOT EXISTS created_by BIGINT REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE factory_nodes ADD COLUMN IF NOT EXISTS updated_by BIGINT REFERENCES users(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_factory_nodes_created_by ON factory_nodes(created_by) WHERE created_by IS NOT NULL;
