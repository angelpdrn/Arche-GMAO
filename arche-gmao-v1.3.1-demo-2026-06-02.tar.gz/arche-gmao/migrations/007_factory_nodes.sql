-- ============================================================
-- Arche GMAO - Migration 007: Virtual Factory (factory_nodes)
-- ============================================================
-- The core of the system. A hierarchical tree using PostgreSQL's ltree.
-- path is computed automatically by an AFTER INSERT trigger.

CREATE TABLE factory_nodes (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    client_id       BIGINT REFERENCES clients(id) ON DELETE SET NULL,
    parent_id       BIGINT REFERENCES factory_nodes(id) ON DELETE RESTRICT,
    path            LTREE,          -- auto-computed by a trigger
    name            VARCHAR(255) NOT NULL,
    code            VARCHAR(100),
    node_type       VARCHAR(50) NOT NULL DEFAULT 'equipment',
    status          VARCHAR(20) NOT NULL DEFAULT 'active'
                        CHECK (status IN ('active', 'inactive', 'maintenance', 'decommissioned')),
    criticality     VARCHAR(20) NOT NULL DEFAULT 'medium'
                        CHECK (criticality IN ('low', 'medium', 'high', 'critical')),
    description     TEXT,
    -- Equipment-specific fields
    manufacturer    VARCHAR(255),
    model           VARCHAR(255),
    serial_number   VARCHAR(255),
    year_installed  INT,
    rated_power_kw  DECIMAL(10,2),
    -- Optimistic locking (lesson learned)
    version         INT NOT NULL DEFAULT 1,
    -- Full-text search in Spanish
    search_vector   TSVECTOR,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_factory_nodes_tenant   ON factory_nodes(tenant_id);
CREATE INDEX idx_factory_nodes_path     ON factory_nodes USING GIST(path);
CREATE INDEX idx_factory_nodes_parent   ON factory_nodes(parent_id);
CREATE INDEX idx_factory_nodes_client   ON factory_nodes(client_id);
CREATE INDEX idx_factory_nodes_type     ON factory_nodes(node_type);
CREATE INDEX idx_factory_nodes_status   ON factory_nodes(status);
CREATE INDEX idx_factory_nodes_search   ON factory_nodes USING GIN(search_vector);
CREATE INDEX idx_factory_nodes_code     ON factory_nodes(tenant_id, code) WHERE code IS NOT NULL;

-- ─── Trigger: auto-compute path after INSERT ─────────────────────────────────
-- Lesson learned: build it in two phases (map + recursion), not in one.
-- We use AFTER INSERT here so the generated ID is available.

CREATE OR REPLACE FUNCTION set_factory_node_path()
RETURNS TRIGGER AS $$
DECLARE
    v_parent_path LTREE;
BEGIN
    IF NEW.parent_id IS NULL THEN
        UPDATE factory_nodes SET path = NEW.id::text::ltree WHERE id = NEW.id;
    ELSE
        SELECT path INTO v_parent_path FROM factory_nodes WHERE id = NEW.parent_id;
        UPDATE factory_nodes
        SET path = v_parent_path || NEW.id::text::ltree
        WHERE id = NEW.id;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS after_factory_node_insert ON factory_nodes;
CREATE TRIGGER after_factory_node_insert
    AFTER INSERT ON factory_nodes
    FOR EACH ROW EXECUTE FUNCTION set_factory_node_path();

-- ─── Trigger: update search_vector ───────────────────────────────────────

CREATE OR REPLACE FUNCTION update_factory_node_search()
RETURNS TRIGGER AS $$
BEGIN
    NEW.search_vector := to_tsvector('spanish',
        COALESCE(NEW.name, '')          || ' ' ||
        COALESCE(NEW.code, '')          || ' ' ||
        COALESCE(NEW.description, '')   || ' ' ||
        COALESCE(NEW.manufacturer, '')  || ' ' ||
        COALESCE(NEW.model, '')         || ' ' ||
        COALESCE(NEW.serial_number, '')
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS before_factory_node_upsert_search ON factory_nodes;
CREATE TRIGGER before_factory_node_upsert_search
    BEFORE INSERT OR UPDATE ON factory_nodes
    FOR EACH ROW EXECUTE FUNCTION update_factory_node_search();

-- ─── Trigger: version for optimistic locking ─────────────────────────────────

CREATE OR REPLACE FUNCTION increment_node_version()
RETURNS TRIGGER AS $$
BEGIN
    NEW.version := OLD.version + 1;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS before_factory_node_version ON factory_nodes;
CREATE TRIGGER before_factory_node_version
    BEFORE UPDATE ON factory_nodes
    FOR EACH ROW EXECUTE FUNCTION increment_node_version();

-- ─── Trigger: updated_at ─────────────────────────────────────────────────────

DROP TRIGGER IF EXISTS set_updated_at_factory_nodes ON factory_nodes;
CREATE TRIGGER set_updated_at_factory_nodes
    BEFORE UPDATE ON factory_nodes
    FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

-- ─── FK from users.home_node_id (now that factory_nodes exists) ───────────────
ALTER TABLE users ADD CONSTRAINT fk_users_home_node
    FOREIGN KEY (home_node_id) REFERENCES factory_nodes(id) ON DELETE SET NULL;
