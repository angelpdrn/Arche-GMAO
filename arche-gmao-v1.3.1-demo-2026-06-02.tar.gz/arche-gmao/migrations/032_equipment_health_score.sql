-- ============================================================
-- Arche GMAO - Migration 032: Equipment Health Score
-- A 0-100 index per equipment item with a weighted multi-factor formula,
-- daily history and per-node-type weight configuration.
-- ============================================================

-- ─── Health score columns on factory_nodes ──────────────────────────────
ALTER TABLE factory_nodes
    ADD COLUMN IF NOT EXISTS health_score      INT,
    ADD COLUMN IF NOT EXISTS health_details    JSONB,
    ADD COLUMN IF NOT EXISTS health_calculated_at TIMESTAMPTZ;

-- health_details example:
-- {
--   "failure_freq":    { "penalty": 15, "weight": 0.25, "raw": 4 },
--   "pm_compliance":   { "penalty": 10, "weight": 0.25, "raw": 0.80 },
--   "age":             { "penalty": 8,  "weight": 0.15, "raw": 0.6 },
--   "mtbf_trend":      { "penalty": 5,  "weight": 0.15, "raw": -0.1 },
--   "corrective_ratio":{ "penalty": 12, "weight": 0.10, "raw": 0.45 },
--   "parts_consumption":{"penalty": 3,  "weight": 0.10, "raw": 1.2 },
--   "criticality_mult": 1.2,
--   "total_penalty": 53,
--   "final_score": 47
-- }

CREATE INDEX IF NOT EXISTS idx_fn_health ON factory_nodes(tenant_id, health_score)
    WHERE health_score IS NOT NULL;

-- ─── Daily health score history ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS equipment_health_history (
    id          BIGSERIAL PRIMARY KEY,
    tenant_id   BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    node_id     BIGINT NOT NULL REFERENCES factory_nodes(id) ON DELETE CASCADE,
    score       INT NOT NULL,
    details     JSONB,
    recorded_at DATE NOT NULL DEFAULT CURRENT_DATE,

    UNIQUE (node_id, recorded_at)
);

CREATE INDEX IF NOT EXISTS idx_ehh_node ON equipment_health_history(node_id, recorded_at DESC);
CREATE INDEX IF NOT EXISTS idx_ehh_tenant ON equipment_health_history(tenant_id);

-- ─── Per-node-type weight configuration ────────────────────────────────
CREATE TABLE IF NOT EXISTS health_weight_configs (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    node_type       VARCHAR(50) NOT NULL,
    weights         JSONB NOT NULL DEFAULT '{
        "failure_freq": 0.25,
        "pm_compliance": 0.25,
        "age": 0.15,
        "mtbf_trend": 0.15,
        "corrective_ratio": 0.10,
        "parts_consumption": 0.10
    }',
    expected_life_years INT DEFAULT 15,
    decay_per_day   DECIMAL(5,3) DEFAULT 0.1,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),

    UNIQUE (tenant_id, node_type)
);

CREATE INDEX IF NOT EXISTS idx_hwc_tenant ON health_weight_configs(tenant_id);

-- ─── RLS ────────────────────────────────────────────────────────────────────
ALTER TABLE equipment_health_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY ehh_tenant ON equipment_health_history
    USING (tenant_id = current_setting('app.current_tenant_id')::bigint);

ALTER TABLE health_weight_configs ENABLE ROW LEVEL SECURITY;
CREATE POLICY hwc_tenant ON health_weight_configs
    USING (tenant_id = current_setting('app.current_tenant_id')::bigint);

-- ─── Triggers ───────────────────────────────────────────────────────────────
DROP TRIGGER IF EXISTS set_updated_at_health_weight_configs ON health_weight_configs;
CREATE TRIGGER set_updated_at_health_weight_configs
    BEFORE UPDATE ON health_weight_configs
    FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();
