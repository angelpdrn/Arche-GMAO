-- 020: Template attachments — files attached to templates, shared across linked devices
-- Files are stored once and referenced by template_id, avoiding duplication.
-- Also adds folder organization within templates.

-- Template folders for organizing template library
CREATE TABLE IF NOT EXISTS template_folders (
    id          BIGSERIAL PRIMARY KEY,
    tenant_id   BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    template_id BIGINT NOT NULL REFERENCES equipment_templates(id) ON DELETE CASCADE,
    name        VARCHAR(255) NOT NULL,
    parent_id   BIGINT REFERENCES template_folders(id) ON DELETE CASCADE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_template_folders_template ON template_folders(template_id);
CREATE INDEX IF NOT EXISTS idx_template_folders_tenant ON template_folders(tenant_id);

-- Add template_id and template_folder_id to attachments
ALTER TABLE attachments ADD COLUMN IF NOT EXISTS template_id BIGINT REFERENCES equipment_templates(id) ON DELETE SET NULL;
ALTER TABLE attachments ADD COLUMN IF NOT EXISTS template_folder_id BIGINT REFERENCES template_folders(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_attachments_template ON attachments(template_id) WHERE template_id IS NOT NULL;

-- RLS
ALTER TABLE template_folders ENABLE ROW LEVEL SECURITY;
CREATE POLICY tf_tenant_policy ON template_folders
    USING (tenant_id = current_setting('app.current_tenant_id')::bigint);
