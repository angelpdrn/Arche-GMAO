-- Lets the superadmin restrict modules/limits per tenant,
-- independently of the global Ed25519 license.
-- When a tenant has an override, the override RESTRICTS (never extends) the license.

ALTER TABLE tenants ADD COLUMN IF NOT EXISTS max_nodes INT DEFAULT NULL;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS disabled_modules TEXT[] DEFAULT '{}';
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS license_notes TEXT DEFAULT '';
