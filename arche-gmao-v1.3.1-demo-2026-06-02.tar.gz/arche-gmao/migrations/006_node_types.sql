-- ============================================================
-- Arche GMAO - Migration 006: Configurable node types
-- ============================================================
-- This is NOT a fixed enum. Each tenant can create its own types.
-- Types with tenant_id IS NULL are global (system-wide).

CREATE TABLE node_type_definitions (
    id          BIGSERIAL PRIMARY KEY,
    tenant_id   BIGINT REFERENCES tenants(id) ON DELETE CASCADE,  -- NULL = global system type
    type_key    VARCHAR(50) NOT NULL,
    label       VARCHAR(100) NOT NULL,
    icon        VARCHAR(50),
    color       VARCHAR(7),
    sort_order  INT NOT NULL DEFAULT 0,
    is_system   BOOLEAN NOT NULL DEFAULT false,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, type_key)
);

-- The 7 predefined system types (tenant_id NULL = visible to everyone)
INSERT INTO node_type_definitions (tenant_id, type_key, label, icon, color, sort_order, is_system) VALUES
    (NULL, 'organization',      'Organización',       'building',    '#1A1A2E', 0, true),
    (NULL, 'plant',             'Planta',             'factory',     '#0F3460', 1, true),
    (NULL, 'area',              'Área',               'layout',      '#16213E', 2, true),
    (NULL, 'line',              'Línea',              'git-branch',  '#0F3460', 3, true),
    (NULL, 'equipment',         'Equipo',             'cog',         '#1A1A2E', 4, true),
    (NULL, 'component',         'Componente',         'cpu',         '#16213E', 5, true),
    (NULL, 'measurement_point', 'Punto de Medición',  'activity',    '#0F3460', 6, true);
