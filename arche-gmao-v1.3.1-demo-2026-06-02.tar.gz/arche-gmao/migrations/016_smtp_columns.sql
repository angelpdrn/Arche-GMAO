-- ============================================================
-- Arche GMAO - Migration 016: SMTP columns for tenants
-- ============================================================
-- Adds the per-tenant SMTP configuration for sending notification
-- emails. Referenced by notification_handler.go.

ALTER TABLE tenants ADD COLUMN IF NOT EXISTS smtp_host     VARCHAR(255);
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS smtp_port     INT DEFAULT 587;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS smtp_user     VARCHAR(255);
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS smtp_password VARCHAR(255);
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS smtp_from     VARCHAR(255);
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS smtp_enabled  BOOLEAN DEFAULT false;
