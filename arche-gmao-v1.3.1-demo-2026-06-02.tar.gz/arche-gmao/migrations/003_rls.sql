-- ============================================================
-- Arche GMAO - Migration 003: Row Level Security (RLS)
-- ============================================================
-- RLS is the first line of defence at the database level.
-- A tenant can NEVER see another tenant's data.
-- It is switched on by setting: SET app.current_tenant_id = '<id>'
-- before every request.
--
-- PHASE 0 NOTE: the 'arche' user (owner) bypasses RLS by default.
-- Phase 1 introduces the 'arche_app' role, which is subject to RLS.

ALTER TABLE tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE users   ENABLE ROW LEVEL SECURITY;

-- ─── Policy for tenants ────────────────────────────────────────────────────
-- Only your own tenant is visible.

CREATE POLICY tenants_tenant_isolation ON tenants
    USING (
        id = COALESCE(
            current_setting('app.current_tenant_id', true)::BIGINT,
            0
        )
    );

-- ─── Policy for users ──────────────────────────────────────────────────────
-- Only users from your own tenant are visible.

CREATE POLICY users_tenant_isolation ON users
    USING (
        tenant_id = COALESCE(
            current_setting('app.current_tenant_id', true)::BIGINT,
            0
        )
    );
