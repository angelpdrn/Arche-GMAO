-- ============================================================
-- Arche GMAO - Migration 001: PostgreSQL extensions
-- ============================================================
-- The extensions are the foundation of the whole architecture:
--   ltree    → node hierarchy (Virtual Factory)
--   pg_trgm  → fuzzy full-text search
--   pgcrypto → password hashing in the seed
--   uuid-ossp → UUID generation
--
-- pgvector (AI embeddings) is added in Phase 3.

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "ltree";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "vector";
