-- ============================================================
-- Arche GMAO - Migration 008: Tags and virtual folders
-- ============================================================

-- ─── Tags ────────────────────────────────────────────────────────────────────
CREATE TABLE tags (
    id          BIGSERIAL PRIMARY KEY,
    tenant_id   BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name        VARCHAR(100) NOT NULL,
    color       VARCHAR(7) NOT NULL DEFAULT '#0F3460',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, name)
);

CREATE TABLE node_tags (
    node_id BIGINT NOT NULL REFERENCES factory_nodes(id) ON DELETE CASCADE,
    tag_id  BIGINT NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
    PRIMARY KEY (node_id, tag_id)
);

-- ─── Virtual folders ───────────────────────────────────────────────────────
-- They group nodes without changing the physical hierarchy.
CREATE TABLE virtual_folders (
    id          BIGSERIAL PRIMARY KEY,
    tenant_id   BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name        VARCHAR(255) NOT NULL,
    description TEXT,
    parent_id   BIGINT REFERENCES virtual_folders(id) ON DELETE CASCADE,
    created_by  BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE folder_nodes (
    folder_id   BIGINT NOT NULL REFERENCES virtual_folders(id) ON DELETE CASCADE,
    node_id     BIGINT NOT NULL REFERENCES factory_nodes(id) ON DELETE CASCADE,
    PRIMARY KEY (folder_id, node_id)
);

CREATE INDEX idx_tags_tenant        ON tags(tenant_id);
CREATE INDEX idx_node_tags_node     ON node_tags(node_id);
CREATE INDEX idx_node_tags_tag      ON node_tags(tag_id);
CREATE INDEX idx_vfolders_tenant    ON virtual_folders(tenant_id);
CREATE INDEX idx_folder_nodes_folder ON folder_nodes(folder_id);
