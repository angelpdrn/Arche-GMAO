-- 027: Work intervals for WOs (automatic stopwatch)
-- Records every stretch of work with server timestamps.
-- actual_hours is computed automatically; the technician never edits it.

-- Intervals table
CREATE TABLE IF NOT EXISTS work_order_intervals (
    id            BIGSERIAL PRIMARY KEY,
    tenant_id     BIGINT NOT NULL REFERENCES tenants(id),
    wo_id         BIGINT NOT NULL REFERENCES work_orders(id) ON DELETE CASCADE,
    started_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ended_at      TIMESTAMPTZ,
    ended_reason  VARCHAR(20), -- 'paused' | 'completed'
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_wo_intervals_wo ON work_order_intervals(wo_id);
CREATE INDEX idx_wo_intervals_tenant ON work_order_intervals(tenant_id);

-- Field for accumulating worked minutes (quick lookup without summing intervals)
ALTER TABLE work_orders ADD COLUMN IF NOT EXISTS accumulated_minutes INTEGER NOT NULL DEFAULT 0;

-- RLS
ALTER TABLE work_order_intervals ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS work_order_intervals_tenant_policy ON work_order_intervals;
CREATE POLICY work_order_intervals_tenant_policy ON work_order_intervals
    USING (tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::BIGINT, 0));
