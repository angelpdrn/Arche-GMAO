-- ============================================================
-- Arche GMAO - Migration 017: Missing SQL functions and views
-- ============================================================
-- Creates get_sibling_nodes(), cleanup_orphaned_data() and
-- v_technician_profiles, which are referenced by handlers
-- but were never created in earlier migrations.

-- ─── get_sibling_nodes(node_id, tenant_id) ──────────────────
-- Returns the sibling nodes (same parent_id) of the given node.
-- Used by GET /templates/:id/siblings for AI suggestions.

CREATE OR REPLACE FUNCTION get_sibling_nodes(p_node_id BIGINT, p_tenant_id BIGINT)
RETURNS TABLE(node_id BIGINT, node_name TEXT) AS $$
BEGIN
  RETURN QUERY
    SELECT fn.id, fn.name::TEXT
    FROM factory_nodes fn
    WHERE fn.tenant_id = p_tenant_id
      AND fn.parent_id = (
        SELECT parent_id FROM factory_nodes WHERE id = p_node_id AND tenant_id = p_tenant_id
      )
      AND fn.id != p_node_id
      AND fn.status != 'decommissioned'
    ORDER BY fn.name;
END;
$$ LANGUAGE plpgsql STABLE;

-- ─── cleanup_orphaned_data(tenant_id) ───────────────────────
-- Cleans up orphan data after bulk imports.
-- Returns a table of (action, count) describing what was cleaned.

CREATE OR REPLACE FUNCTION cleanup_orphaned_data(p_tenant_id BIGINT)
RETURNS TABLE(action TEXT, count BIGINT) AS $$
DECLARE
  v_count BIGINT;
BEGIN
  -- 1. Tags de nodos que ya no existen
  DELETE FROM node_tags
  WHERE node_id NOT IN (SELECT id FROM factory_nodes WHERE tenant_id = p_tenant_id)
    AND node_id IN (SELECT nt.node_id FROM node_tags nt
                    JOIN factory_nodes fn ON fn.id = nt.node_id
                    WHERE fn.tenant_id = p_tenant_id);
  GET DIAGNOSTICS v_count = ROW_COUNT;
  action := 'node_tags_huérfanos'; count := v_count;
  RETURN NEXT;

  -- 2. Asignaciones a nodos inexistentes
  DELETE FROM node_assignments
  WHERE tenant_id = p_tenant_id
    AND node_id NOT IN (SELECT id FROM factory_nodes WHERE tenant_id = p_tenant_id);
  GET DIAGNOSTICS v_count = ROW_COUNT;
  action := 'asignaciones_huérfanas'; count := v_count;
  RETURN NEXT;

  -- 3. Repuestos vinculados a nodos inexistentes
  DELETE FROM spare_part_nodes
  WHERE node_id NOT IN (SELECT id FROM factory_nodes WHERE tenant_id = p_tenant_id)
    AND spare_part_id IN (SELECT id FROM spare_parts WHERE tenant_id = p_tenant_id);
  GET DIAGNOSTICS v_count = ROW_COUNT;
  action := 'repuestos_nodo_huérfanos'; count := v_count;
  RETURN NEXT;

  -- 4. Items de directorio apuntando a entidades inexistentes
  DELETE FROM directory_items di
  USING user_directories ud
  WHERE di.directory_id = ud.id
    AND ud.tenant_id = p_tenant_id
    AND di.item_type = 'node'
    AND di.item_id::BIGINT NOT IN (SELECT id FROM factory_nodes WHERE tenant_id = p_tenant_id);
  GET DIAGNOSTICS v_count = ROW_COUNT;
  action := 'dir_items_nodo_huérfanos'; count := v_count;
  RETURN NEXT;

  -- 5. Entradas de cola de indexación con source inexistente
  DELETE FROM ai_index_queue
  WHERE tenant_id = p_tenant_id
    AND source_type = 'node'
    AND source_id NOT IN (SELECT id::TEXT FROM factory_nodes WHERE tenant_id = p_tenant_id);
  GET DIAGNOSTICS v_count = ROW_COUNT;
  action := 'cola_indexación_huérfana'; count := v_count;
  RETURN NEXT;

  RETURN;
END;
$$ LANGUAGE plpgsql VOLATILE;

-- ─── v_technician_profiles ──────────────────────────────────
-- View used by technician_handler.go List() and GetOne().
-- It aggregates tags, scores and WO statistics per technician.

CREATE OR REPLACE VIEW v_technician_profiles AS
SELECT
  u.id AS user_id,
  u.tenant_id,
  u.full_name,
  u.email,
  u.role,
  COALESCE(
    ARRAY_AGG(DISTINCT ut.tag) FILTER (WHERE ut.tag IS NOT NULL),
    '{}'
  ) AS tags,
  ROUND(AVG(ws.score)::numeric, 2) AS avg_score,
  COUNT(DISTINCT ws.id) AS scored_wos,
  COUNT(DISTINCT wo.id) FILTER (
    WHERE wo.status IN ('completed','verified','closed')
  ) AS completed_wos,
  COUNT(DISTINCT wo.id) FILTER (
    WHERE wo.wo_type = 'corrective'
      AND wo.status IN ('completed','verified','closed')
  ) AS corrective_completed,
  ROUND(
    AVG(wo.actual_hours) FILTER (
      WHERE wo.actual_hours IS NOT NULL
        AND wo.status IN ('completed','verified','closed')
    )::numeric, 2
  ) AS avg_resolution_hours
FROM users u
LEFT JOIN user_tags ut
  ON ut.user_id = u.id AND ut.tenant_id = u.tenant_id
LEFT JOIN wo_scores ws
  ON ws.user_id = u.id AND ws.tenant_id = u.tenant_id
LEFT JOIN work_orders wo
  ON wo.assigned_to = u.id AND wo.tenant_id = u.tenant_id
WHERE u.role IN ('technician', 'supervisor', 'operator')
  AND u.status = 'active'
GROUP BY u.id, u.tenant_id, u.full_name, u.email, u.role;
