-- ============================================================
-- Arche GMAO - Migration 010: RLS for the Phase 1 tables
-- ============================================================

ALTER TABLE clients               ENABLE ROW LEVEL SECURITY;
ALTER TABLE factory_nodes         ENABLE ROW LEVEL SECURITY;
ALTER TABLE tags                  ENABLE ROW LEVEL SECURITY;
ALTER TABLE node_tags             ENABLE ROW LEVEL SECURITY;
ALTER TABLE virtual_folders       ENABLE ROW LEVEL SECURITY;
ALTER TABLE folder_nodes          ENABLE ROW LEVEL SECURITY;
ALTER TABLE node_type_definitions ENABLE ROW LEVEL SECURITY;

CREATE POLICY clients_tenant_isolation ON clients
    USING (tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::BIGINT, 0));

CREATE POLICY factory_nodes_tenant_isolation ON factory_nodes
    USING (tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::BIGINT, 0));

CREATE POLICY tags_tenant_isolation ON tags
    USING (tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::BIGINT, 0));

CREATE POLICY node_tags_isolation ON node_tags
    USING (node_id IN (
        SELECT id FROM factory_nodes
        WHERE tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::BIGINT, 0)
    ));

CREATE POLICY virtual_folders_tenant_isolation ON virtual_folders
    USING (tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::BIGINT, 0));

CREATE POLICY folder_nodes_isolation ON folder_nodes
    USING (folder_id IN (
        SELECT id FROM virtual_folders
        WHERE tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::BIGINT, 0)
    ));

-- node_type_definitions: system types (NULL) visible to everyone
CREATE POLICY node_types_visibility ON node_type_definitions
    USING (
        tenant_id IS NULL OR
        tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::BIGINT, 0)
    );
