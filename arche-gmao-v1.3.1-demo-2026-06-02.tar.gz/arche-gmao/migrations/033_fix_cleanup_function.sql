-- Fix: cleanup_orphaned_data — remove unnecessary ::TEXT cast on BIGINT comparison
CREATE OR REPLACE FUNCTION cleanup_orphaned_data(p_tenant_id BIGINT)
RETURNS TABLE(action TEXT, count BIGINT) AS $$
DECLARE
  v_count BIGINT;
BEGIN
  -- 1. Tags de nodos que ya no existen
  DELETE FROM node_tags
  WHERE node_id NOT IN (SELECT id FROM factory_nodes WHERE tenant_id = p_tenant_id)
    AND node_id IN (SELECT nt.node_id FROM node_tags nt
                    JOIN factory_nodes fn ON fn.id = nt.node_id
                    WHERE fn.tenant_id = p_tenant_id);
  GET DIAGNOSTICS v_count = ROW_COUNT;
  action := 'node_tags_huérfanos'; count := v_count;
  RETURN NEXT;

  -- 2. Asignaciones a nodos inexistentes
  DELETE FROM node_assignments
  WHERE tenant_id = p_tenant_id
    AND node_id NOT IN (SELECT id FROM factory_nodes WHERE tenant_id = p_tenant_id);
  GET DIAGNOSTICS v_count = ROW_COUNT;
  action := 'asignaciones_huérfanas'; count := v_count;
  RETURN NEXT;

  -- 3. Repuestos vinculados a nodos inexistentes
  DELETE FROM spare_part_nodes
  WHERE node_id NOT IN (SELECT id FROM factory_nodes WHERE tenant_id = p_tenant_id)
    AND spare_part_id IN (SELECT id FROM spare_parts WHERE tenant_id = p_tenant_id);
  GET DIAGNOSTICS v_count = ROW_COUNT;
  action := 'repuestos_nodo_huérfanos'; count := v_count;
  RETURN NEXT;

  -- 4. Items de directorio apuntando a entidades inexistentes
  DELETE FROM directory_items di
  USING user_directories ud
  WHERE di.directory_id = ud.id
    AND ud.tenant_id = p_tenant_id
    AND di.item_type = 'node'
    AND di.item_id::BIGINT NOT IN (SELECT id FROM factory_nodes WHERE tenant_id = p_tenant_id);
  GET DIAGNOSTICS v_count = ROW_COUNT;
  action := 'dir_items_nodo_huérfanos'; count := v_count;
  RETURN NEXT;

  -- 5. Entradas de cola de indexación con source inexistente
  DELETE FROM ai_index_queue
  WHERE tenant_id = p_tenant_id
    AND source_type = 'node'
    AND source_id NOT IN (SELECT id FROM factory_nodes WHERE tenant_id = p_tenant_id);
  GET DIAGNOSTICS v_count = ROW_COUNT;
  action := 'cola_indexación_huérfana'; count := v_count;
  RETURN NEXT;

  RETURN;
END;
$$ LANGUAGE plpgsql VOLATILE;
