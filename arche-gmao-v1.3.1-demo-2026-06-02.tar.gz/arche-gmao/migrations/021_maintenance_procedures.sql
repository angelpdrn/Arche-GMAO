-- ============================================================
-- Arche GMAO - Migration 021: Maintenance Procedures & Manuals
-- Adds structured instructions to maintenance plans and
-- a maintenance manuals table for AI learning (RAG indexing).
-- ============================================================

-- ─── Enhance maintenance_plans with procedure fields ─────────
ALTER TABLE maintenance_plans
    ADD COLUMN IF NOT EXISTS instructions TEXT,
    ADD COLUMN IF NOT EXISTS checklist JSONB DEFAULT '[]',
    ADD COLUMN IF NOT EXISTS safety_notes TEXT,
    ADD COLUMN IF NOT EXISTS tools_required JSONB DEFAULT '[]',
    ADD COLUMN IF NOT EXISTS required_parts JSONB DEFAULT '[]',
    ADD COLUMN IF NOT EXISTS apply_to_children BOOLEAN NOT NULL DEFAULT false;

-- Track which child node each execution targeted (when apply_to_children=true)
ALTER TABLE maintenance_plan_executions
    ADD COLUMN IF NOT EXISTS target_node_id BIGINT REFERENCES factory_nodes(id) ON DELETE SET NULL;

-- ─── Maintenance manuals: PDF/TXT linked to nodes for AI learning ───
CREATE TABLE IF NOT EXISTS maintenance_manuals (
    id            BIGSERIAL PRIMARY KEY,
    tenant_id     BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    node_id       BIGINT NOT NULL REFERENCES factory_nodes(id) ON DELETE CASCADE,
    title         VARCHAR(255) NOT NULL,
    description   TEXT,
    file_name     VARCHAR(255) NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    mime_type     VARCHAR(100),
    file_size     BIGINT DEFAULT 0,
    file_path     TEXT NOT NULL,
    content_text  TEXT,
    is_active     BOOLEAN NOT NULL DEFAULT true,
    uploaded_by   BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_maint_manuals_node ON maintenance_manuals(node_id);
CREATE INDEX IF NOT EXISTS idx_maint_manuals_tenant ON maintenance_manuals(tenant_id);

-- RLS
ALTER TABLE maintenance_manuals ENABLE ROW LEVEL SECURITY;
CREATE POLICY mm_tenant_policy ON maintenance_manuals
    USING (tenant_id = current_setting('app.current_tenant_id')::bigint);
