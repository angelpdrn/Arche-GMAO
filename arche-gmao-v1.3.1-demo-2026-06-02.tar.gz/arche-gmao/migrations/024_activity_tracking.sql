-- 024: Technicians' daily activity log + retention policy

-- Daily activity table per technician
CREATE TABLE IF NOT EXISTS technician_daily_activity (
    id            BIGSERIAL PRIMARY KEY,
    tenant_id     BIGINT NOT NULL,
    user_id       BIGINT NOT NULL,
    activity_date DATE NOT NULL,
    data          JSONB NOT NULL DEFAULT '[]',
    generated_at  TIMESTAMPTZ DEFAULT now(),
    UNIQUE(tenant_id, user_id, activity_date)
);
CREATE INDEX IF NOT EXISTS idx_tda_lookup ON technician_daily_activity(tenant_id, user_id, activity_date);

-- Retention configurable per tenant (days, default 365)
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS activity_retention_days INTEGER DEFAULT 365;

-- Missing unique index for ON CONFLICT on WO scoring
CREATE UNIQUE INDEX IF NOT EXISTS idx_wo_scores_wo_user ON wo_scores(wo_id, user_id);
