-- ============================================================
-- Arche GMAO - Migration 012: Equipment templates
-- ============================================================

CREATE TABLE IF NOT EXISTS equipment_templates (
    id             BIGSERIAL PRIMARY KEY,
    tenant_id      BIGINT REFERENCES tenants(id) ON DELETE CASCADE,
    manufacturer   VARCHAR(255) NOT NULL,
    model          VARCHAR(255) NOT NULL,
    category       VARCHAR(100),
    node_type      VARCHAR(50) NOT NULL DEFAULT 'equipment',
    description    TEXT,
    notes          TEXT,
    tags           TEXT[] DEFAULT '{}',
    is_active      BOOLEAN NOT NULL DEFAULT true,
    created_by     BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX idx_equipment_templates_unique_active ON equipment_templates (tenant_id, manufacturer, model) WHERE is_active = true;
CREATE INDEX idx_equipment_templates_tenant ON equipment_templates(tenant_id);
CREATE INDEX idx_equipment_templates_category ON equipment_templates(category) WHERE category IS NOT NULL;

-- template_id column on factory_nodes
ALTER TABLE factory_nodes ADD COLUMN IF NOT EXISTS template_id BIGINT REFERENCES equipment_templates(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_factory_nodes_template ON factory_nodes(template_id) WHERE template_id IS NOT NULL;

-- updated_at trigger
CREATE OR REPLACE TRIGGER set_updated_at_equipment_templates
    BEFORE UPDATE ON equipment_templates
    FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();
