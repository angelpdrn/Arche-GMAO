-- 019: Hierarchical personnel — exclusions table for restricting inherited access
-- The assignment system now uses ltree hierarchy: assigning a user to a parent node
-- makes them appear as personnel for all descendant nodes automatically.
-- This table allows excluding specific users from specific child nodes.

CREATE TABLE IF NOT EXISTS node_assignment_exclusions (
    id          BIGSERIAL PRIMARY KEY,
    tenant_id   BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    node_id     BIGINT NOT NULL REFERENCES factory_nodes(id) ON DELETE CASCADE,
    excluded_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(tenant_id, user_id, node_id)
);

CREATE INDEX IF NOT EXISTS idx_nae_user ON node_assignment_exclusions(user_id);
CREATE INDEX IF NOT EXISTS idx_nae_node ON node_assignment_exclusions(node_id);
CREATE INDEX IF NOT EXISTS idx_nae_tenant ON node_assignment_exclusions(tenant_id);

-- RLS
ALTER TABLE node_assignment_exclusions ENABLE ROW LEVEL SECURITY;
CREATE POLICY nae_tenant_policy ON node_assignment_exclusions
    USING (tenant_id = current_setting('app.current_tenant_id')::bigint);
