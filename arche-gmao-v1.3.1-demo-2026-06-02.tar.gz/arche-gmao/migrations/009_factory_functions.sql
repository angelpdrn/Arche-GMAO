-- ============================================================
-- Arche GMAO - Migration 009: Critical SQL functions
-- ============================================================

-- ─── user_can_access_node: O(1) access check ───────────────────────

CREATE OR REPLACE FUNCTION user_can_access_node(
    p_user_id   BIGINT,
    p_tenant_id BIGINT,
    p_node_id   BIGINT
) RETURNS BOOLEAN AS $$
DECLARE
    v_home_node_id  BIGINT;
    v_role          VARCHAR(50);
    v_home_path     LTREE;
    v_node_path     LTREE;
BEGIN
    SELECT home_node_id, role
    INTO v_home_node_id, v_role
    FROM users
    WHERE id = p_user_id AND tenant_id = p_tenant_id;

    -- Admin o sin home_node → acceso total
    IF v_role = 'admin' OR v_home_node_id IS NULL THEN
        RETURN true;
    END IF;

    SELECT path INTO v_node_path FROM factory_nodes
    WHERE id = p_node_id AND tenant_id = p_tenant_id;

    IF v_node_path IS NULL THEN
        RETURN false;
    END IF;

    SELECT path INTO v_home_path FROM factory_nodes
    WHERE id = v_home_node_id AND tenant_id = p_tenant_id;

    -- El nodo debe estar dentro del subárbol del home_node
    RETURN v_node_path <@ v_home_path;
END;
$$ LANGUAGE plpgsql STABLE;

-- ─── user_accessible_nodes: every node a user can reach ────────

CREATE OR REPLACE FUNCTION user_accessible_nodes(
    p_user_id   BIGINT,
    p_tenant_id BIGINT
) RETURNS TABLE(node_id BIGINT) AS $$
DECLARE
    v_home_node_id  BIGINT;
    v_role          VARCHAR(50);
    v_home_path     LTREE;
BEGIN
    SELECT home_node_id, role
    INTO v_home_node_id, v_role
    FROM users
    WHERE id = p_user_id AND tenant_id = p_tenant_id;

    IF v_role = 'admin' OR v_home_node_id IS NULL THEN
        RETURN QUERY
            SELECT id FROM factory_nodes
            WHERE tenant_id = p_tenant_id
            AND status != 'decommissioned'
            ORDER BY path;
        RETURN;
    END IF;

    SELECT path INTO v_home_path FROM factory_nodes WHERE id = v_home_node_id;

    RETURN QUERY
        SELECT id FROM factory_nodes
        WHERE tenant_id = p_tenant_id
        AND path <@ v_home_path
        AND status != 'decommissioned'
        ORDER BY path;
END;
$$ LANGUAGE plpgsql STABLE;

-- ─── generate_wo_number: auto-generates the WO number (Phase 2) ───────────────────

CREATE OR REPLACE FUNCTION generate_wo_number_prefix()
RETURNS VARCHAR AS $$
BEGIN
    RETURN 'OT-' || TO_CHAR(NOW(), 'YYYYMMDD') || '-';
END;
$$ LANGUAGE plpgsql;
