-- ============================================================
-- Arche GMAO - Migration 023: V1 Final
-- ============================================================
-- Adds the tables and columns needed for the final version:
--   1. Indestructible primary admin (is_primary_admin + triggers)
--   2. Arche GMAO superadmin (separate table)
--   3. Per-tenant user limit (max_users)
--   4. System stop mode (system_paused)
--   5. Staggered maintenance (staggered_configs, cycles, schedule)
--   6. Hardware registration for binary protection
-- ============================================================

-- ─── 1. PRIMARY ADMIN ─────────────────────────────────────────────────────

-- Field marking the primary admin (one per tenant, indestructible)
ALTER TABLE users
    ADD COLUMN IF NOT EXISTS is_primary_admin BOOLEAN NOT NULL DEFAULT FALSE;

-- There can only be one primary admin per tenant
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_primary_admin_unique
    ON users (tenant_id) WHERE is_primary_admin = TRUE;

-- Mark the initial admin as the primary admin
UPDATE users
SET is_primary_admin = TRUE
WHERE email = 'admin@arche.local'
  AND role = 'admin'
  AND NOT EXISTS (
      SELECT 1 FROM users u2
      WHERE u2.tenant_id = users.tenant_id
        AND u2.is_primary_admin = TRUE
  );

-- Trigger: prevent deletion of the primary admin
CREATE OR REPLACE FUNCTION prevent_primary_admin_delete()
RETURNS TRIGGER AS $$
BEGIN
    IF OLD.is_primary_admin = TRUE THEN
        RAISE EXCEPTION 'No se puede eliminar al administrador principal del sistema'
            USING ERRCODE = 'P0001';
    END IF;
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_prevent_primary_admin_delete ON users;
CREATE TRIGGER trg_prevent_primary_admin_delete
    BEFORE DELETE ON users
    FOR EACH ROW
    EXECUTE FUNCTION prevent_primary_admin_delete();

-- Trigger: prevent changes to the primary admin's critical fields
CREATE OR REPLACE FUNCTION protect_primary_admin_update()
RETURNS TRIGGER AS $$
BEGIN
    IF OLD.is_primary_admin = TRUE THEN
        -- No permitir quitar el flag de primary admin
        IF NEW.is_primary_admin = FALSE THEN
            RAISE EXCEPTION 'No se puede revocar el rol de administrador principal'
                USING ERRCODE = 'P0001';
        END IF;
        -- No permitir cambiar el rol
        IF NEW.role <> OLD.role THEN
            RAISE EXCEPTION 'No se puede cambiar el rol del administrador principal'
                USING ERRCODE = 'P0001';
        END IF;
        -- No permitir desactivar la cuenta
        IF NEW.status <> 'active' AND OLD.status = 'active' THEN
            RAISE EXCEPTION 'No se puede desactivar al administrador principal'
                USING ERRCODE = 'P0001';
        END IF;
    END IF;

    -- No permitir que alguien se asigne is_primary_admin si ya existe uno en el tenant
    IF NEW.is_primary_admin = TRUE AND OLD.is_primary_admin = FALSE THEN
        IF EXISTS (
            SELECT 1 FROM users
            WHERE tenant_id = NEW.tenant_id
              AND is_primary_admin = TRUE
              AND id <> NEW.id
        ) THEN
            RAISE EXCEPTION 'Ya existe un administrador principal en este tenant'
                USING ERRCODE = 'P0001';
        END IF;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_protect_primary_admin_update ON users;
CREATE TRIGGER trg_protect_primary_admin_update
    BEFORE UPDATE ON users
    FOR EACH ROW
    EXECUTE FUNCTION protect_primary_admin_update();


-- ─── 2. AP SYSTEMS SUPERADMIN ───────────────────────────────────────────────

-- A separate table, with no tenant_id and no RLS.
-- Completely invisible to the client's users.
CREATE TABLE IF NOT EXISTS superadmin_accounts (
    id            BIGSERIAL PRIMARY KEY,
    email         VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name     VARCHAR(255) NOT NULL DEFAULT 'Arche GMAO',
    is_active     BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_login_at TIMESTAMPTZ
);

CREATE OR REPLACE TRIGGER set_updated_at_superadmin
    BEFORE UPDATE ON superadmin_accounts
    FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();


-- ─── 3. PER-TENANT USER LIMIT ───────────────────────────────────────

-- NULL = unlimited. Only the superadmin can change it.
ALTER TABLE tenants
    ADD COLUMN IF NOT EXISTS max_users INTEGER DEFAULT NULL;

-- Constraint: max_users must be positive when it is set
DO $$ BEGIN
    ALTER TABLE tenants
        ADD CONSTRAINT chk_max_users_positive CHECK (max_users IS NULL OR max_users > 0);
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;


-- ─── 4. SYSTEM STOP MODE ─────────────────────────────────────────────

ALTER TABLE tenants
    ADD COLUMN IF NOT EXISTS system_paused  BOOLEAN     NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS paused_by      BIGINT      REFERENCES users(id) ON DELETE SET NULL,
    ADD COLUMN IF NOT EXISTS paused_at      TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS paused_contact TEXT;


-- ─── 5. STAGGERED MAINTENANCE ─────────────────────────────────────────────

-- 5A. Per-tenant (or per-area) staggering configuration
CREATE TABLE IF NOT EXISTS staggered_configs (
    id                BIGSERIAL PRIMARY KEY,
    tenant_id         BIGINT      NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    scope             VARCHAR(20) NOT NULL DEFAULT 'global'
                          CHECK (scope IN ('global', 'area', 'line')),
    scope_node_id     BIGINT      REFERENCES factory_nodes(id) ON DELETE CASCADE,
    period            VARCHAR(20) NOT NULL DEFAULT 'monthly'
                          CHECK (period IN ('weekly', 'biweekly', 'monthly')),
    max_daily_per_tech INTEGER    NOT NULL DEFAULT 3
                          CHECK (max_daily_per_tech > 0),
    is_active         BOOLEAN     NOT NULL DEFAULT FALSE,
    created_by        BIGINT      REFERENCES users(id) ON DELETE SET NULL,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, scope, scope_node_id)
);

-- For scope='global', scope_node_id is NULL.
-- The UNIQUE constraint treats NULLs as distinct, so we add a partial index.
CREATE UNIQUE INDEX IF NOT EXISTS idx_staggered_configs_global_unique
    ON staggered_configs (tenant_id) WHERE scope = 'global' AND scope_node_id IS NULL;

CREATE INDEX IF NOT EXISTS idx_staggered_configs_tenant
    ON staggered_configs(tenant_id);

CREATE OR REPLACE TRIGGER set_updated_at_staggered_configs
    BEFORE UPDATE ON staggered_configs
    FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

ALTER TABLE staggered_configs ENABLE ROW LEVEL SECURITY;
DO $$ BEGIN
    CREATE POLICY sc_tenant_policy ON staggered_configs
        USING (tenant_id = current_setting('app.current_tenant_id')::bigint);
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;


-- 5B. Staggering cycles (history)
CREATE TABLE IF NOT EXISTS staggered_cycles (
    id                 BIGSERIAL PRIMARY KEY,
    tenant_id          BIGINT      NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    config_id          BIGINT      NOT NULL REFERENCES staggered_configs(id) ON DELETE CASCADE,
    cycle_start        DATE        NOT NULL,
    cycle_end          DATE        NOT NULL,
    total_planned      INTEGER     NOT NULL DEFAULT 0,
    total_executed     INTEGER     NOT NULL DEFAULT 0,
    total_rescheduled  INTEGER     NOT NULL DEFAULT 0,
    status             VARCHAR(20) NOT NULL DEFAULT 'planned'
                           CHECK (status IN ('planned', 'in_progress', 'completed')),
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (cycle_end > cycle_start)
);

CREATE INDEX IF NOT EXISTS idx_staggered_cycles_tenant
    ON staggered_cycles(tenant_id);
CREATE INDEX IF NOT EXISTS idx_staggered_cycles_config
    ON staggered_cycles(config_id);
CREATE INDEX IF NOT EXISTS idx_staggered_cycles_dates
    ON staggered_cycles(cycle_start, cycle_end);

ALTER TABLE staggered_cycles ENABLE ROW LEVEL SECURITY;
DO $$ BEGIN
    CREATE POLICY scy_tenant_policy ON staggered_cycles
        USING (tenant_id = current_setting('app.current_tenant_id')::bigint);
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;


-- 5C. Schedule: computed distribution of WOs per cycle
CREATE TABLE IF NOT EXISTS staggered_schedule (
    id                BIGSERIAL PRIMARY KEY,
    tenant_id         BIGINT      NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    cycle_id          BIGINT      NOT NULL REFERENCES staggered_cycles(id) ON DELETE CASCADE,
    plan_id           BIGINT      NOT NULL REFERENCES maintenance_plans(id) ON DELETE CASCADE,
    node_id           BIGINT      NOT NULL REFERENCES factory_nodes(id) ON DELETE CASCADE,
    scheduled_date    DATE        NOT NULL,
    technician_id     BIGINT      REFERENCES users(id) ON DELETE SET NULL,
    status            VARCHAR(20) NOT NULL DEFAULT 'scheduled'
                          CHECK (status IN ('scheduled', 'generated', 'rescheduled', 'skipped')),
    rescheduled_from  DATE,
    wo_id             BIGINT      REFERENCES work_orders(id) ON DELETE SET NULL,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_staggered_schedule_tenant
    ON staggered_schedule(tenant_id);
CREATE INDEX IF NOT EXISTS idx_staggered_schedule_cycle
    ON staggered_schedule(cycle_id);
CREATE INDEX IF NOT EXISTS idx_staggered_schedule_date
    ON staggered_schedule(scheduled_date) WHERE status = 'scheduled';
CREATE INDEX IF NOT EXISTS idx_staggered_schedule_plan
    ON staggered_schedule(plan_id);
CREATE INDEX IF NOT EXISTS idx_staggered_schedule_node
    ON staggered_schedule(node_id);
CREATE INDEX IF NOT EXISTS idx_staggered_schedule_tech
    ON staggered_schedule(technician_id) WHERE technician_id IS NOT NULL;

ALTER TABLE staggered_schedule ENABLE ROW LEVEL SECURITY;
DO $$ BEGIN
    CREATE POLICY ss_tenant_policy ON staggered_schedule
        USING (tenant_id = current_setting('app.current_tenant_id')::bigint);
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;


-- 5D. Field on maintenance_plans to enable staggering per plan
ALTER TABLE maintenance_plans
    ADD COLUMN IF NOT EXISTS staggering_enabled BOOLEAN NOT NULL DEFAULT FALSE;


-- ─── 6. HARDWARE REGISTRATION (BINARY PROTECTION) ───────────────────────

-- A single record per installation. Populated by arche.sh during installation.
-- No tenant_id, no RLS — it is server data, not client data.
CREATE TABLE IF NOT EXISTS hardware_registration (
    id             BIGSERIAL PRIMARY KEY,
    machine_id     VARCHAR(255) NOT NULL,
    mac_address    VARCHAR(50),
    allowed_hosts  TEXT[]       NOT NULL DEFAULT '{}',
    registered_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- Make sure only one record exists
CREATE UNIQUE INDEX IF NOT EXISTS idx_hardware_registration_single
    ON hardware_registration ((TRUE));


-- ============================================================
-- END OF MIGRATION 023
-- ============================================================
