-- ============================================================
-- Arche GMAO - Migration 002: Base schema (Phase 0)
-- ============================================================
-- Tables: tenants, users
-- The node, WO, spare part and other tables are added in Phase 1-2.

-- ─── TENANTS ─────────────────────────────────────────────────────────────────
-- Each tenant is an organization that uses Arche GMAO.
-- Complete isolation between tenants through RLS.

CREATE TABLE tenants (
    id          BIGSERIAL PRIMARY KEY,
    name        VARCHAR(255)    NOT NULL,
    slug        VARCHAR(100)    NOT NULL UNIQUE,
    status      VARCHAR(20)     NOT NULL DEFAULT 'active'
                    CHECK (status IN ('active', 'suspended', 'cancelled')),
    plan        VARCHAR(50)     NOT NULL DEFAULT 'standard',
    created_at  TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_tenants_slug   ON tenants(slug);
CREATE INDEX idx_tenants_status ON tenants(status);

-- ─── USERS ───────────────────────────────────────────────────────────────────
-- System users. The home_node_id field defines the user's
-- hierarchical scope (it becomes active in Phase 1, once nodes exist).

CREATE TABLE users (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       BIGINT          NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    email           VARCHAR(255)    NOT NULL,
    password_hash   VARCHAR(255)    NOT NULL,
    full_name       VARCHAR(255)    NOT NULL,
    role            VARCHAR(50)     NOT NULL
                        CHECK (role IN ('admin', 'supervisor', 'technician', 'operator', 'warehouse', 'auditor')),
    status          VARCHAR(20)     NOT NULL DEFAULT 'active'
                        CHECK (status IN ('active', 'inactive', 'suspended')),
    home_node_id    BIGINT,         -- FK to factory_nodes, activated in Phase 1
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    last_login_at   TIMESTAMPTZ,

    -- An email is unique within a tenant
    UNIQUE (tenant_id, email)
);

CREATE INDEX idx_users_tenant_id    ON users(tenant_id);
CREATE INDEX idx_users_email        ON users(email);
CREATE INDEX idx_users_role         ON users(role);
CREATE INDEX idx_users_status       ON users(status);

-- ─── FUNCTION: automatic updated_at ──────────────────────────────────────────

CREATE OR REPLACE FUNCTION trigger_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS set_updated_at_tenants ON tenants;
CREATE TRIGGER set_updated_at_tenants
    BEFORE UPDATE ON tenants
    FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

DROP TRIGGER IF EXISTS set_updated_at_users ON users;
CREATE TRIGGER set_updated_at_users
    BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();
