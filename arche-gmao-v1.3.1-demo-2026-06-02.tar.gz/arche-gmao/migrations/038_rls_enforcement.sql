-- ============================================================
-- Arche GMAO - Migration 038: Turning RLS on for real
-- ============================================================
-- Creates the arche_app role (non-owner, subject to RLS) and enables
-- RLS + policies on tables with tenant_id that did not have them yet.
--
-- The owner (arche) is NOT subject to RLS (no FORCE).
-- Workers use arche directly and bypass RLS.
-- HTTP requests use SET ROLE arche_app through the middleware.
-- ============================================================

-- 1. Create the application role (if it does not exist)
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'arche_app') THEN
    EXECUTE format('CREATE ROLE arche_app LOGIN PASSWORD %L',
      COALESCE(current_setting('app.arche_app_password', true), 'arche_app_secret'));
  END IF;
END
$$;

-- The owner must be able to assume the arche_app role (for SET ROLE)
DO $$
BEGIN
  IF NOT pg_has_role('arche', 'arche_app', 'MEMBER') THEN
    EXECUTE 'GRANT arche_app TO arche';
  END IF;
END
$$;

-- 2. Grants for arche_app
GRANT USAGE ON SCHEMA public TO arche_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO arche_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO arche_app;

ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO arche_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT USAGE, SELECT ON SEQUENCES TO arche_app;

-- 3. Enable RLS + policies on tables that have tenant_id but no policy
DO $$
DECLARE
  tbl TEXT;
  tables_needing_rls TEXT[] := ARRAY[
    'work_orders',
    'maintenance_plans',
    'maintenance_plan_executions',
    'spare_parts',
    'stock_movements',
    'equipment_templates',
    'attachments',
    'calendar_events',
    'push_subscriptions',
    'notification_preferences',
    'qr_scans',
    'user_competencies',
    'user_directories',
    'user_tags',
    'ai_conversations',
    'ai_embeddings',
    'ai_index_queue',
    'ai_patterns',
    'ai_knowledge',
    'ai_knowledge_folders',
    'ai_knowledge_log',
    'ai_custom_calcs',
    'ai_permission_log',
    'ai_usage_stats'
  ];
BEGIN
  FOREACH tbl IN ARRAY tables_needing_rls LOOP
    IF EXISTS (
      SELECT FROM information_schema.tables
      WHERE table_name = tbl AND table_schema = 'public'
    ) THEN
      EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', tbl);
      IF NOT EXISTS (
        SELECT FROM pg_policies WHERE tablename = tbl AND policyname = tbl || '_tenant_isolation'
      ) THEN
        EXECUTE format(
          'CREATE POLICY %I ON %I USING (tenant_id = COALESCE(current_setting(''app.current_tenant_id'', true)::BIGINT, 0))',
          tbl || '_tenant_isolation', tbl
        );
      END IF;
    END IF;
  END LOOP;
END
$$;
