-- 028: Manual daily summaries for technicians + edited hours flag

-- ─── New daily summaries table ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS daily_summaries (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       BIGINT NOT NULL REFERENCES tenants(id),
    user_id         BIGINT NOT NULL REFERENCES users(id),
    summary_date    DATE NOT NULL,
    client_id       BIGINT REFERENCES clients(id) ON DELETE SET NULL,
    wo_id           BIGINT REFERENCES work_orders(id) ON DELETE SET NULL,
    project_number  VARCHAR(100),
    shift           VARCHAR(10) NOT NULL CHECK (shift IN ('mañana', 'tarde', 'noche')),
    shift_extras    TEXT[] DEFAULT '{}',
    hours           DECIMAL(6,2) NOT NULL DEFAULT 0,
    observations    TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ds_tenant_user_date ON daily_summaries(tenant_id, user_id, summary_date);
CREATE INDEX IF NOT EXISTS idx_ds_tenant_date ON daily_summaries(tenant_id, summary_date);

-- RLS
ALTER TABLE daily_summaries ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS daily_summaries_tenant_isolation ON daily_summaries;
CREATE POLICY daily_summaries_tenant_isolation ON daily_summaries
    USING (tenant_id::text = current_setting('app.current_tenant_id', true));

-- ─── Immutable monthly folders ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS monthly_summary_folders (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       BIGINT NOT NULL REFERENCES tenants(id),
    month           VARCHAR(7) NOT NULL,  -- YYYY-MM format
    frozen          BOOLEAN NOT NULL DEFAULT FALSE,
    frozen_at       TIMESTAMPTZ,
    last_compiled   TIMESTAMPTZ,
    file_name       VARCHAR(255),
    file_data       BYTEA,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(tenant_id, month)
);

CREATE INDEX IF NOT EXISTS idx_msf_tenant_month ON monthly_summary_folders(tenant_id, month);

-- RLS
ALTER TABLE monthly_summary_folders ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS msf_tenant_isolation ON monthly_summary_folders;
CREATE POLICY msf_tenant_isolation ON monthly_summary_folders
    USING (tenant_id::text = current_setting('app.current_tenant_id', true));

-- ─── Edited hours flag on work_orders ──────────────────────────────────
ALTER TABLE work_orders ADD COLUMN IF NOT EXISTS hours_edited_by BIGINT REFERENCES users(id);
ALTER TABLE work_orders ADD COLUMN IF NOT EXISTS hours_edited_at TIMESTAMPTZ;

-- ─── Drop the old automatic activity system ────────────────────────────
DROP TABLE IF EXISTS technician_daily_activity CASCADE;
ALTER TABLE tenants DROP COLUMN IF EXISTS activity_retention_days;
