-- ============================================================
-- Arche GMAO - Migration 037: Coded root cause + photo evidence
-- ============================================================
-- Tier 2 UX:
--   • root_cause_code: standardized root cause classification
--     (mechanical, electrical, hydraulic, etc.) to make real metrics possible.
--   • photo_phase: mark image attachments as "before" / "after" the
--     intervention, without breaking the free-form `category` field.
--
-- Idempotent, with IF NOT EXISTS and DO blocks.
-- ============================================================

-- ─── 1. root_cause_code on work_orders ───────────────────────────────────────
ALTER TABLE work_orders ADD COLUMN IF NOT EXISTS root_cause_code VARCHAR(40);

DO $$ BEGIN
    ALTER TABLE work_orders
        ADD CONSTRAINT chk_wo_root_cause_code
        CHECK (root_cause_code IS NULL OR root_cause_code IN (
            'mechanical',     -- desgaste, rotura, holgura, vibración
            'electrical',     -- cortocircuito, fallo de aislamiento
            'electronic',     -- placa, sensor, lógica
            'hydraulic',      -- fugas, presiones, sellos
            'pneumatic',      -- aire comprimido, válvulas
            'lubrication',    -- falta/exceso de lubricación
            'wear',           -- desgaste por uso normal (fin de vida útil)
            'parameters',     -- mala configuración o setpoint
            'operation',      -- error humano u operación incorrecta
            'environment',    -- temperatura, humedad, polvo, vibración externa
            'supply',         -- corriente eléctrica/aire/agua/material entrante
            'unknown',        -- sin determinar
            'other'
        ));
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- Index for Metrics (corrective_ratio + filters by code)
CREATE INDEX IF NOT EXISTS idx_work_orders_root_cause
    ON work_orders(tenant_id, root_cause_code)
    WHERE root_cause_code IS NOT NULL;

-- ─── 2. photo_phase on attachments ───────────────────────────────────────────
ALTER TABLE attachments ADD COLUMN IF NOT EXISTS photo_phase VARCHAR(20);

DO $$ BEGIN
    ALTER TABLE attachments
        ADD CONSTRAINT chk_attachments_photo_phase
        CHECK (photo_phase IS NULL OR photo_phase IN ('before', 'after'));
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- For quickly listing before/after photos of a specific WO.
CREATE INDEX IF NOT EXISTS idx_attachments_wo_phase
    ON attachments(wo_id, photo_phase)
    WHERE wo_id IS NOT NULL AND photo_phase IS NOT NULL;
