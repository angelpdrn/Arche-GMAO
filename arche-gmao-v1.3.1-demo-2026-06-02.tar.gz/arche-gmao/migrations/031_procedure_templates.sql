-- ============================================================
-- Arche GMAO - Migration 031: Guided Procedures (digital SOPs)
-- Reusable procedure templates with interactive steps,
-- conditional logic, per-step evidence and execution linked to WOs.
-- ============================================================

-- ─── Procedure templates ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS procedure_templates (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    title           VARCHAR(255) NOT NULL,
    description     TEXT,
    category        VARCHAR(50) DEFAULT 'general'
                        CHECK (category IN ('general','inspection','preventive','corrective','safety','commissioning')),
    node_type_target VARCHAR(50),
    version         INT NOT NULL DEFAULT 1,
    is_active       BOOLEAN NOT NULL DEFAULT true,
    created_by      BIGINT REFERENCES users(id) ON DELETE SET NULL,
    updated_by      BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_proc_tmpl_tenant ON procedure_templates(tenant_id);
CREATE INDEX IF NOT EXISTS idx_proc_tmpl_category ON procedure_templates(tenant_id, category);
CREATE INDEX IF NOT EXISTS idx_proc_tmpl_active ON procedure_templates(tenant_id, is_active);

-- ─── Procedure steps ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS procedure_steps (
    id              BIGSERIAL PRIMARY KEY,
    template_id     BIGINT NOT NULL REFERENCES procedure_templates(id) ON DELETE CASCADE,
    step_number     INT NOT NULL,
    title           VARCHAR(255) NOT NULL,
    description     TEXT,
    step_type       VARCHAR(30) NOT NULL DEFAULT 'checkbox'
                        CHECK (step_type IN (
                            'checkbox',
                            'numeric',
                            'text',
                            'photo',
                            'signature',
                            'selection',
                            'meter_reading',
                            'passfail'
                        )),
    is_required     BOOLEAN NOT NULL DEFAULT true,
    config          JSONB NOT NULL DEFAULT '{}',
    condition       JSONB,
    estimated_minutes INT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),

    UNIQUE (template_id, step_number)
);

CREATE INDEX IF NOT EXISTS idx_proc_steps_template ON procedure_steps(template_id);

-- config examples per step_type:
--   numeric:       { "unit": "°C", "min": 0, "max": 120, "alert_min": 20, "alert_max": 100 }
--   selection:     { "options": ["Bueno", "Regular", "Malo"] }
--   meter_reading: { "unit": "bar", "min": 0, "max": 10 }
--   photo:         { "min_photos": 1, "max_photos": 3 }
--   passfail:      { "fail_action": "stop" | "warn" | "continue" }
--   checkbox:      {}
--   text:          { "max_length": 500 }
--   signature:     {}
--
-- condition example (conditional logic):
--   { "if_step": 3, "operator": ">", "value": 100, "action": "goto", "goto_step": 7 }
--   { "if_step": 5, "operator": "equals", "value": "Malo", "action": "stop" }

-- ─── Linking templates to preventive plans and equipment ────────────────
CREATE TABLE IF NOT EXISTS procedure_template_links (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    template_id     BIGINT NOT NULL REFERENCES procedure_templates(id) ON DELETE CASCADE,
    maintenance_plan_id BIGINT REFERENCES maintenance_plans(id) ON DELETE CASCADE,
    node_id         BIGINT REFERENCES factory_nodes(id) ON DELETE CASCADE,
    wo_type         VARCHAR(30),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),

    CHECK (maintenance_plan_id IS NOT NULL OR node_id IS NOT NULL OR wo_type IS NOT NULL)
);

CREATE INDEX IF NOT EXISTS idx_proc_links_template ON procedure_template_links(template_id);
CREATE INDEX IF NOT EXISTS idx_proc_links_plan ON procedure_template_links(maintenance_plan_id);
CREATE INDEX IF NOT EXISTS idx_proc_links_node ON procedure_template_links(node_id);

-- ─── Procedure execution (an instance linked to a WO) ─────────────────
CREATE TABLE IF NOT EXISTS procedure_executions (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    template_id     BIGINT NOT NULL REFERENCES procedure_templates(id) ON DELETE RESTRICT,
    template_version INT NOT NULL DEFAULT 1,
    wo_id           BIGINT REFERENCES work_orders(id) ON DELETE SET NULL,
    node_id         BIGINT REFERENCES factory_nodes(id) ON DELETE SET NULL,
    executed_by     BIGINT REFERENCES users(id) ON DELETE SET NULL,
    status          VARCHAR(20) NOT NULL DEFAULT 'pending'
                        CHECK (status IN ('pending','in_progress','completed','cancelled')),
    total_steps     INT NOT NULL DEFAULT 0,
    completed_steps INT NOT NULL DEFAULT 0,
    started_at      TIMESTAMPTZ,
    completed_at    TIMESTAMPTZ,
    notes           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_proc_exec_tenant ON procedure_executions(tenant_id);
CREATE INDEX IF NOT EXISTS idx_proc_exec_wo ON procedure_executions(wo_id);
CREATE INDEX IF NOT EXISTS idx_proc_exec_template ON procedure_executions(template_id);
CREATE INDEX IF NOT EXISTS idx_proc_exec_node ON procedure_executions(node_id);
CREATE INDEX IF NOT EXISTS idx_proc_exec_status ON procedure_executions(tenant_id, status);

-- ─── Per-step result ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS procedure_step_results (
    id              BIGSERIAL PRIMARY KEY,
    execution_id    BIGINT NOT NULL REFERENCES procedure_executions(id) ON DELETE CASCADE,
    step_id         BIGINT NOT NULL REFERENCES procedure_steps(id) ON DELETE CASCADE,
    step_number     INT NOT NULL,
    value_text      TEXT,
    value_numeric   DECIMAL(12,4),
    value_bool      BOOLEAN,
    value_selection VARCHAR(255),
    is_pass         BOOLEAN,
    out_of_range    BOOLEAN DEFAULT false,
    completed_by    BIGINT REFERENCES users(id) ON DELETE SET NULL,
    completed_at    TIMESTAMPTZ,
    skipped         BOOLEAN NOT NULL DEFAULT false,
    skip_reason     TEXT,
    notes           TEXT,

    UNIQUE (execution_id, step_id)
);

CREATE INDEX IF NOT EXISTS idx_proc_results_exec ON procedure_step_results(execution_id);
CREATE INDEX IF NOT EXISTS idx_proc_results_oor ON procedure_step_results(out_of_range) WHERE out_of_range = true;

-- ─── Per-step evidence (photos, signatures) ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS procedure_step_evidence (
    id              BIGSERIAL PRIMARY KEY,
    result_id       BIGINT NOT NULL REFERENCES procedure_step_results(id) ON DELETE CASCADE,
    evidence_type   VARCHAR(20) NOT NULL CHECK (evidence_type IN ('photo','signature','document')),
    file_name       VARCHAR(255) NOT NULL,
    original_name   VARCHAR(255),
    mime_type       VARCHAR(100),
    file_size       BIGINT DEFAULT 0,
    file_path       TEXT NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_proc_evidence_result ON procedure_step_evidence(result_id);

-- ─── RLS ────────────────────────────────────────────────────────────────────
ALTER TABLE procedure_templates ENABLE ROW LEVEL SECURITY;
CREATE POLICY pt_tenant ON procedure_templates
    USING (tenant_id = current_setting('app.current_tenant_id')::bigint);

ALTER TABLE procedure_template_links ENABLE ROW LEVEL SECURITY;
CREATE POLICY ptl_tenant ON procedure_template_links
    USING (tenant_id = current_setting('app.current_tenant_id')::bigint);

ALTER TABLE procedure_executions ENABLE ROW LEVEL SECURITY;
CREATE POLICY pe_tenant ON procedure_executions
    USING (tenant_id = current_setting('app.current_tenant_id')::bigint);

-- step_results and step_evidence need no RLS of their own (access goes through the execution)

-- ─── updated_at trigger ─────────────────────────────────────────────────────
DROP TRIGGER IF EXISTS set_updated_at_procedure_templates ON procedure_templates;
CREATE TRIGGER set_updated_at_procedure_templates
    BEFORE UPDATE ON procedure_templates
    FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();
