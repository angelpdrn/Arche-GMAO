-- ============================================================
-- Arche GMAO - Migration 030: Composition as a node type
-- Compositions go from being a separate entity to being a
-- fully fledged node type in the virtual factory.
-- ============================================================

-- 1. New node type: composition
INSERT INTO node_type_definitions (tenant_id, type_key, label, icon, color, sort_order, is_system)
VALUES (NULL, 'composition', 'Composición', 'layers', '#0F3460', 4, true)
ON CONFLICT (tenant_id, type_key) DO NOTHING;

-- 2. Allow composition as a child of organization, plant, area, line
UPDATE node_type_definitions SET sort_order = 5 WHERE type_key = 'equipment';
UPDATE node_type_definitions SET sort_order = 6 WHERE type_key = 'component';
UPDATE node_type_definitions SET sort_order = 7 WHERE type_key = 'measurement_point';

-- 3. Link equipment_compositions to factory_nodes
ALTER TABLE equipment_compositions ADD COLUMN IF NOT EXISTS node_id BIGINT REFERENCES factory_nodes(id) ON DELETE CASCADE;
CREATE INDEX IF NOT EXISTS idx_equipment_compositions_node_id ON equipment_compositions(node_id) WHERE node_id IS NOT NULL;
