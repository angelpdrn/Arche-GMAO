-- ============================================================
-- Arche GMAO - Migration 015: Every missing table
-- ============================================================

-- ─── Node assignments to users ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS node_assignments (
    id          BIGSERIAL PRIMARY KEY,
    tenant_id   BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    node_id     BIGINT NOT NULL REFERENCES factory_nodes(id) ON DELETE CASCADE,
    is_primary  BOOLEAN NOT NULL DEFAULT false,
    assigned_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
    assigned_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, user_id, node_id)
);
CREATE INDEX IF NOT EXISTS idx_node_assignments_user ON node_assignments(user_id);
CREATE INDEX IF NOT EXISTS idx_node_assignments_node ON node_assignments(node_id);

-- ─── Work orders ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS work_orders (
    id                    BIGSERIAL PRIMARY KEY,
    tenant_id             BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    node_id               BIGINT NOT NULL REFERENCES factory_nodes(id) ON DELETE RESTRICT,
    wo_number             VARCHAR(50) NOT NULL,
    title                 VARCHAR(255) NOT NULL,
    description           TEXT,
    wo_type               VARCHAR(50) NOT NULL DEFAULT 'corrective',
    priority              VARCHAR(20) NOT NULL DEFAULT 'medium',
    status                VARCHAR(30) NOT NULL DEFAULT 'pending',
    assigned_to           BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_by            BIGINT REFERENCES users(id) ON DELETE SET NULL,
    estimated_hours       NUMERIC(8,2),
    actual_hours          NUMERIC(8,2),
    planned_start         TIMESTAMPTZ,
    planned_end           TIMESTAMPTZ,
    started_at            TIMESTAMPTZ,
    completed_at          TIMESTAMPTZ,
    closed_at             TIMESTAMPTZ,
    root_cause            TEXT,
    solution              TEXT,
    signed_by             BIGINT REFERENCES users(id) ON DELETE SET NULL,
    signed_at             TIMESTAMPTZ,
    supervisor_signed_by  BIGINT REFERENCES users(id) ON DELETE SET NULL,
    supervisor_signed_at  TIMESTAMPTZ,
    version               INTEGER NOT NULL DEFAULT 1,
    created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, wo_number)
);
CREATE INDEX IF NOT EXISTS idx_work_orders_tenant ON work_orders(tenant_id);
CREATE INDEX IF NOT EXISTS idx_work_orders_node ON work_orders(node_id);
CREATE INDEX IF NOT EXISTS idx_work_orders_status ON work_orders(status);
CREATE INDEX IF NOT EXISTS idx_work_orders_assigned ON work_orders(assigned_to);
CREATE INDEX IF NOT EXISTS idx_work_orders_type ON work_orders(wo_type);

CREATE OR REPLACE TRIGGER set_updated_at_work_orders
    BEFORE UPDATE ON work_orders
    FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

-- ─── WO state change log ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS work_order_log (
    id          BIGSERIAL PRIMARY KEY,
    wo_id       BIGINT NOT NULL REFERENCES work_orders(id) ON DELETE CASCADE,
    user_id     BIGINT REFERENCES users(id) ON DELETE SET NULL,
    from_status VARCHAR(30),
    to_status   VARCHAR(30) NOT NULL,
    comment     TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_wo_log_wo ON work_order_log(wo_id);

-- ─── WO comments ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS work_order_comments (
    id         BIGSERIAL PRIMARY KEY,
    wo_id      BIGINT NOT NULL REFERENCES work_orders(id) ON DELETE CASCADE,
    user_id    BIGINT REFERENCES users(id) ON DELETE SET NULL,
    content    TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_wo_comments_wo ON work_order_comments(wo_id);

-- ─── WO verification ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS verification_records (
    id               BIGSERIAL PRIMARY KEY,
    tenant_id        BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    wo_id            BIGINT NOT NULL REFERENCES work_orders(id) ON DELETE CASCADE,
    submitted_by     BIGINT REFERENCES users(id) ON DELETE SET NULL,
    verified_by      BIGINT REFERENCES users(id) ON DELETE SET NULL,
    status           VARCHAR(20) NOT NULL DEFAULT 'pending',
    confidence_level INTEGER NOT NULL DEFAULT 0,
    notes            TEXT,
    submitted_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    verified_at      TIMESTAMPTZ
);

-- ─── WO scores ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS wo_scores (
    id         BIGSERIAL PRIMARY KEY,
    tenant_id  BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    wo_id      BIGINT REFERENCES work_orders(id) ON DELETE CASCADE,
    user_id    BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    scored_by  BIGINT REFERENCES users(id) ON DELETE SET NULL,
    score      INTEGER NOT NULL CHECK (score BETWEEN 1 AND 5),
    comment    TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_wo_scores_user ON wo_scores(user_id);
CREATE INDEX IF NOT EXISTS idx_wo_scores_tenant ON wo_scores(tenant_id);

-- ─── User tags/skills ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS user_tags (
    id         BIGSERIAL PRIMARY KEY,
    tenant_id  BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id    BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    tag        VARCHAR(100) NOT NULL,
    added_by   BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, user_id, tag)
);

-- ─── User competencies ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS user_competencies (
    id           BIGSERIAL PRIMARY KEY,
    tenant_id    BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id      BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name         VARCHAR(255) NOT NULL,
    level        VARCHAR(50),
    is_certified BOOLEAN DEFAULT false,
    expires_at   DATE,
    notes        TEXT,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ─── Notifications ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications (
    id         BIGSERIAL PRIMARY KEY,
    tenant_id  BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id    BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type       VARCHAR(50) NOT NULL DEFAULT 'info',
    title      VARCHAR(255) NOT NULL,
    body       TEXT,
    link       VARCHAR(500),
    is_read    BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read);
CREATE INDEX IF NOT EXISTS idx_notifications_tenant ON notifications(tenant_id);

-- ─── Notification preferences ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notification_preferences (
    id         BIGSERIAL PRIMARY KEY,
    tenant_id  BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id    BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    event_type VARCHAR(100) NOT NULL,
    in_app     BOOLEAN NOT NULL DEFAULT true,
    email      BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, user_id, event_type)
);

-- ─── Push subscriptions ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS push_subscriptions (
    id         BIGSERIAL PRIMARY KEY,
    tenant_id  BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id    BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    endpoint   TEXT NOT NULL UNIQUE,
    p256dh     TEXT NOT NULL,
    auth       TEXT NOT NULL,
    user_agent TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ─── Spare parts ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS spare_parts (
    id            BIGSERIAL PRIMARY KEY,
    tenant_id     BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    code          VARCHAR(100) NOT NULL,
    name          VARCHAR(255) NOT NULL,
    category      VARCHAR(100),
    unit          VARCHAR(20) DEFAULT 'ud',
    current_stock NUMERIC(12,2) NOT NULL DEFAULT 0,
    min_stock     NUMERIC(12,2) DEFAULT 0,
    max_stock     NUMERIC(12,2),
    location      VARCHAR(255),
    supplier      VARCHAR(255),
    supplier_ref  VARCHAR(100),
    unit_price    NUMERIC(12,2),
    lead_days     INTEGER,
    notes         TEXT,
    is_active     BOOLEAN NOT NULL DEFAULT true,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, code)
);

-- ─── Spare parts ↔ nodes relation ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS spare_part_nodes (
    id            BIGSERIAL PRIMARY KEY,
    spare_part_id BIGINT NOT NULL REFERENCES spare_parts(id) ON DELETE CASCADE,
    node_id       BIGINT NOT NULL REFERENCES factory_nodes(id) ON DELETE CASCADE,
    UNIQUE (spare_part_id, node_id)
);

-- ─── Spare parts ↔ WOs relation ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS work_order_parts (
    id            BIGSERIAL PRIMARY KEY,
    wo_id         BIGINT NOT NULL REFERENCES work_orders(id) ON DELETE CASCADE,
    spare_part_id BIGINT NOT NULL REFERENCES spare_parts(id) ON DELETE RESTRICT,
    quantity      NUMERIC(12,2) NOT NULL DEFAULT 1,
    UNIQUE (wo_id, spare_part_id)
);

-- ─── Stock movements ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS stock_movements (
    id            BIGSERIAL PRIMARY KEY,
    tenant_id     BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    spare_part_id BIGINT NOT NULL REFERENCES spare_parts(id) ON DELETE CASCADE,
    movement_type VARCHAR(20) NOT NULL,
    quantity      NUMERIC(12,2) NOT NULL,
    unit_cost     NUMERIC(12,2),
    stock_before  NUMERIC(12,2),
    stock_after   NUMERIC(12,2),
    notes         TEXT,
    created_by    BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_stock_movements_part ON stock_movements(spare_part_id);

-- ─── Attachments / library ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS attachments (
    id            BIGSERIAL PRIMARY KEY,
    tenant_id     BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    node_id       BIGINT REFERENCES factory_nodes(id) ON DELETE SET NULL,
    wo_id         BIGINT REFERENCES work_orders(id) ON DELETE SET NULL,
    file_name     VARCHAR(255) NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    mime_type     VARCHAR(100),
    file_size     BIGINT,
    file_path     TEXT NOT NULL,
    category      VARCHAR(50),
    description   TEXT,
    version       INTEGER NOT NULL DEFAULT 1,
    tags          TEXT[] DEFAULT '{}',
    uploaded_by   BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_attachments_node ON attachments(node_id);
CREATE INDEX IF NOT EXISTS idx_attachments_wo ON attachments(wo_id);
CREATE INDEX IF NOT EXISTS idx_attachments_tenant ON attachments(tenant_id);

-- ─── Calendar ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS calendar_events (
    id          BIGSERIAL PRIMARY KEY,
    tenant_id   BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id     BIGINT REFERENCES users(id) ON DELETE CASCADE,
    wo_id       BIGINT REFERENCES work_orders(id) ON DELETE CASCADE,
    title       VARCHAR(255) NOT NULL,
    description TEXT,
    event_type  VARCHAR(50) DEFAULT 'task',
    color       VARCHAR(20),
    start_at    TIMESTAMPTZ NOT NULL,
    end_at      TIMESTAMPTZ,
    all_day     BOOLEAN DEFAULT false,
    is_auto     BOOLEAN DEFAULT false,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_calendar_user ON calendar_events(user_id);
CREATE INDEX IF NOT EXISTS idx_calendar_tenant ON calendar_events(tenant_id);

-- ─── Preventive maintenance plans ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS maintenance_plans (
    id               BIGSERIAL PRIMARY KEY,
    tenant_id        BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    node_id          BIGINT NOT NULL REFERENCES factory_nodes(id) ON DELETE CASCADE,
    title            VARCHAR(255) NOT NULL,
    description      TEXT,
    wo_type          VARCHAR(50) DEFAULT 'preventive',
    priority         VARCHAR(20) DEFAULT 'medium',
    frequency_type   VARCHAR(20) NOT NULL DEFAULT 'days',
    frequency_value  INTEGER NOT NULL DEFAULT 30,
    advance_days     INTEGER DEFAULT 7,
    assigned_to      BIGINT REFERENCES users(id) ON DELETE SET NULL,
    estimated_hours  NUMERIC(8,2),
    is_active        BOOLEAN NOT NULL DEFAULT true,
    last_executed_at TIMESTAMPTZ,
    next_due_at      TIMESTAMPTZ,
    total_executions INTEGER NOT NULL DEFAULT 0,
    created_by       BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_maint_plans_tenant ON maintenance_plans(tenant_id);
CREATE INDEX IF NOT EXISTS idx_maint_plans_node ON maintenance_plans(node_id);
CREATE INDEX IF NOT EXISTS idx_maint_plans_next_due ON maintenance_plans(next_due_at) WHERE is_active = true;

-- ─── Maintenance plan executions ─────────────────────────────────
CREATE TABLE IF NOT EXISTS maintenance_plan_executions (
    id         BIGSERIAL PRIMARY KEY,
    tenant_id  BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    plan_id    BIGINT NOT NULL REFERENCES maintenance_plans(id) ON DELETE CASCADE,
    wo_id      BIGINT REFERENCES work_orders(id) ON DELETE SET NULL,
    executed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    notes      TEXT,
    created_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ─── QR Scans ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS qr_scans (
    id         BIGSERIAL PRIMARY KEY,
    tenant_id  BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    node_id    BIGINT NOT NULL REFERENCES factory_nodes(id) ON DELETE CASCADE,
    scanned_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
    ip_address VARCHAR(50),
    user_agent TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ─── User directories ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS user_directories (
    id          BIGSERIAL PRIMARY KEY,
    tenant_id   BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name        VARCHAR(255) NOT NULL,
    section     VARCHAR(50) DEFAULT 'personal',
    parent_id   BIGINT REFERENCES user_directories(id) ON DELETE CASCADE,
    is_public   BOOLEAN DEFAULT false,
    access_pin  VARCHAR(100),
    description TEXT,
    color       VARCHAR(20),
    icon        VARCHAR(50),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ─── Items inside directories ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS directory_items (
    id           BIGSERIAL PRIMARY KEY,
    directory_id BIGINT NOT NULL REFERENCES user_directories(id) ON DELETE CASCADE,
    item_type    VARCHAR(50) NOT NULL,
    item_id      BIGINT NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (directory_id, item_type, item_id)
);

-- ─── AI: Conversations ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ai_conversations (
    id         BIGSERIAL PRIMARY KEY,
    tenant_id  BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id    BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    node_id    BIGINT REFERENCES factory_nodes(id) ON DELETE SET NULL,
    title      VARCHAR(120),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ─── AI: Messages ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ai_messages (
    id              BIGSERIAL PRIMARY KEY,
    conversation_id BIGINT NOT NULL REFERENCES ai_conversations(id) ON DELETE CASCADE,
    role            VARCHAR(20) NOT NULL,
    content         TEXT NOT NULL,
    sources         JSONB DEFAULT '[]',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_ai_messages_conv ON ai_messages(conversation_id);

-- ─── AI: Embeddings ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ai_embeddings (
    id                  BIGSERIAL PRIMARY KEY,
    tenant_id           BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    node_id             BIGINT REFERENCES factory_nodes(id) ON DELETE SET NULL,
    template_id         BIGINT REFERENCES equipment_templates(id) ON DELETE SET NULL,
    source_type         VARCHAR(50) NOT NULL,
    source_id           BIGINT NOT NULL,
    chunk_text          TEXT,
    chunk_index         INTEGER NOT NULL DEFAULT 0,
    embedding           vector(768),
    verification_status VARCHAR(30) DEFAULT 'verified',
    confidence_level    INTEGER DEFAULT 0,
    data_type           VARCHAR(50),
    indexed_at          TIMESTAMPTZ DEFAULT now(),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, source_type, source_id, chunk_index)
);
CREATE INDEX IF NOT EXISTS idx_ai_embeddings_source ON ai_embeddings(source_type, source_id);
CREATE INDEX IF NOT EXISTS idx_ai_embeddings_vector ON ai_embeddings USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);
CREATE INDEX IF NOT EXISTS idx_ai_embeddings_tenant ON ai_embeddings(tenant_id);
CREATE INDEX IF NOT EXISTS idx_ai_embeddings_node ON ai_embeddings(node_id);
CREATE INDEX IF NOT EXISTS idx_ai_embeddings_template ON ai_embeddings(template_id);

-- ─── AI: Indexing queue ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ai_index_queue (
    id          BIGSERIAL PRIMARY KEY,
    tenant_id   BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    source_type VARCHAR(50) NOT NULL,
    source_id   BIGINT NOT NULL,
    action      VARCHAR(20) NOT NULL DEFAULT 'index',
    status      VARCHAR(20) NOT NULL DEFAULT 'pending',
    priority    INTEGER DEFAULT 0,
    error_msg   TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    processed_at TIMESTAMPTZ
);

-- ─── AI: Knowledge base ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ai_knowledge_folders (
    id         BIGSERIAL PRIMARY KEY,
    tenant_id  BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name       VARCHAR(255) NOT NULL,
    created_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, name)
);

CREATE TABLE IF NOT EXISTS ai_knowledge (
    id         BIGSERIAL PRIMARY KEY,
    tenant_id  BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    title      VARCHAR(255) NOT NULL,
    content    TEXT NOT NULL,
    category   VARCHAR(100),
    folder     VARCHAR(255),
    source     VARCHAR(100),
    is_active  BOOLEAN NOT NULL DEFAULT true,
    created_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
    updated_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_ai_knowledge_tenant ON ai_knowledge(tenant_id);

-- ─── AI: Knowledge log ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ai_knowledge_log (
    id           BIGSERIAL PRIMARY KEY,
    tenant_id    BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    knowledge_id BIGINT REFERENCES ai_knowledge(id) ON DELETE CASCADE,
    action       VARCHAR(50) NOT NULL,
    user_id      BIGINT REFERENCES users(id) ON DELETE SET NULL,
    details      TEXT,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ─── AI: Detected patterns ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ai_patterns (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    node_id         BIGINT REFERENCES factory_nodes(id) ON DELETE CASCADE,
    pattern_type    VARCHAR(50),
    title           VARCHAR(255),
    description     TEXT,
    recommendation  TEXT,
    severity        VARCHAR(20) DEFAULT 'info',
    status          VARCHAR(20) NOT NULL DEFAULT 'active',
    pattern_data    JSONB DEFAULT '{}',
    pattern_hash    VARCHAR(64),
    valid_until     TIMESTAMPTZ,
    detected_at     TIMESTAMPTZ DEFAULT now(),
    data            JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, node_id, pattern_type, pattern_hash)
);

-- ─── AI: Custom calculations ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ai_custom_calcs (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    title           VARCHAR(255) NOT NULL,
    description     TEXT,
    prompt_template TEXT NOT NULL,
    params          JSONB DEFAULT '[]',
    is_active       BOOLEAN NOT NULL DEFAULT true,
    is_builtin      BOOLEAN NOT NULL DEFAULT false,
    created_by      BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ─── AI: Usage statistics ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ai_usage_stats (
    id          BIGSERIAL PRIMARY KEY,
    tenant_id   BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id     BIGINT REFERENCES users(id) ON DELETE SET NULL,
    model       VARCHAR(100),
    had_sources BOOLEAN DEFAULT false,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ─── AI: Permission log ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ai_permission_log (
    id         BIGSERIAL PRIMARY KEY,
    tenant_id  BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    changed_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
    action     VARCHAR(100) NOT NULL,
    old_value  TEXT,
    new_value  TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
