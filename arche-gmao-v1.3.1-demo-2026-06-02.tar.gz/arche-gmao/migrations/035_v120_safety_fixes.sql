-- 035: Security fixes for v1.2.0
-- - RLS policies with a safe COALESCE
-- - Missing FKs with ON DELETE CASCADE
-- - Missing updated_at trigger on daily_summaries

BEGIN;

-- ══════════════════════════════════════════════════════════════════════════════
-- 1. Fix unsafe RLS policies (migration 031 — procedure_templates)
-- ══════════════════════════════════════════════════════════════════════════════

DROP POLICY IF EXISTS tenant_isolation ON procedure_templates;
CREATE POLICY tenant_isolation ON procedure_templates
    USING (tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::BIGINT, 0));

DROP POLICY IF EXISTS tenant_isolation ON procedure_template_links;
CREATE POLICY tenant_isolation ON procedure_template_links
    USING (tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::BIGINT, 0));

DROP POLICY IF EXISTS tenant_isolation ON procedure_executions;
CREATE POLICY tenant_isolation ON procedure_executions
    USING (tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::BIGINT, 0));

-- ══════════════════════════════════════════════════════════════════════════════
-- 2. Fix unsafe RLS policies (migration 032 — equipment_health)
-- ══════════════════════════════════════════════════════════════════════════════

DROP POLICY IF EXISTS tenant_isolation ON equipment_health_history;
CREATE POLICY tenant_isolation ON equipment_health_history
    USING (tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::BIGINT, 0));

DROP POLICY IF EXISTS tenant_isolation ON health_weight_configs;
CREATE POLICY tenant_isolation ON health_weight_configs
    USING (tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::BIGINT, 0));

-- ══════════════════════════════════════════════════════════════════════════════
-- 3. Add ON DELETE CASCADE to the missing tenant_id FKs
-- ══════════════════════════════════════════════════════════════════════════════

ALTER TABLE work_order_intervals
    DROP CONSTRAINT IF EXISTS work_order_intervals_tenant_id_fkey,
    ADD CONSTRAINT work_order_intervals_tenant_id_fkey
        FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE;

ALTER TABLE daily_summaries
    DROP CONSTRAINT IF EXISTS daily_summaries_tenant_id_fkey,
    ADD CONSTRAINT daily_summaries_tenant_id_fkey
        FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE;

ALTER TABLE monthly_summary_folders
    DROP CONSTRAINT IF EXISTS monthly_summary_folders_tenant_id_fkey,
    ADD CONSTRAINT monthly_summary_folders_tenant_id_fkey
        FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE;

-- ══════════════════════════════════════════════════════════════════════════════
-- 4. updated_at trigger for daily_summaries
-- ══════════════════════════════════════════════════════════════════════════════

CREATE OR REPLACE TRIGGER set_updated_at_daily_summaries
    BEFORE UPDATE ON daily_summaries
    FOR EACH ROW
    EXECUTE FUNCTION trigger_set_updated_at();

-- ══════════════════════════════════════════════════════════════════════════════
-- 5. Index on procedure_executions.wo_id for frequent lookups
-- ══════════════════════════════════════════════════════════════════════════════

CREATE INDEX IF NOT EXISTS idx_procedure_executions_wo_id
    ON procedure_executions(wo_id);

COMMIT;
