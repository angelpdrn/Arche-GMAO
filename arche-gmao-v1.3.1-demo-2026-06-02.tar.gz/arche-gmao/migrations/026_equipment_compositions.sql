-- ============================================================
-- Arche GMAO - Migration 026: Equipment compositions
-- Linking system for functional components
-- ============================================================

-- Composition templates (reusable moulds)
CREATE TABLE IF NOT EXISTS composition_templates (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name            VARCHAR(255) NOT NULL,
    description     TEXT,
    created_by      BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_composition_templates_tenant ON composition_templates(tenant_id);

-- Slots of a template (each slot = one required equipment type)
CREATE TABLE IF NOT EXISTS composition_template_slots (
    id                      BIGSERIAL PRIMARY KEY,
    template_id             BIGINT NOT NULL REFERENCES composition_templates(id) ON DELETE CASCADE,
    role                    VARCHAR(255) NOT NULL,
    equipment_template_id   BIGINT REFERENCES equipment_templates(id) ON DELETE SET NULL,
    sort_order              INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX idx_comp_template_slots_template ON composition_template_slots(template_id);

-- Instantiated compositions (real groups of linked nodes)
CREATE TABLE IF NOT EXISTS equipment_compositions (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name            VARCHAR(255) NOT NULL,
    description     TEXT,
    template_id     BIGINT REFERENCES composition_templates(id) ON DELETE SET NULL,
    parent_node_id  BIGINT REFERENCES factory_nodes(id) ON DELETE SET NULL,
    created_by      BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_equipment_compositions_tenant ON equipment_compositions(tenant_id);
CREATE INDEX idx_equipment_compositions_parent ON equipment_compositions(parent_node_id);
CREATE INDEX idx_equipment_compositions_template ON equipment_compositions(template_id);

-- Members of a composition (linked nodes)
CREATE TABLE IF NOT EXISTS equipment_composition_members (
    id              BIGSERIAL PRIMARY KEY,
    composition_id  BIGINT NOT NULL REFERENCES equipment_compositions(id) ON DELETE CASCADE,
    node_id         BIGINT NOT NULL REFERENCES factory_nodes(id) ON DELETE CASCADE,
    role            VARCHAR(255),
    slot_id         BIGINT REFERENCES composition_template_slots(id) ON DELETE SET NULL,
    UNIQUE(composition_id, node_id)
);

CREATE INDEX idx_comp_members_composition ON equipment_composition_members(composition_id);
CREATE INDEX idx_comp_members_node ON equipment_composition_members(node_id);

-- ============================================================
-- RLS
-- ============================================================

ALTER TABLE composition_templates         ENABLE ROW LEVEL SECURITY;
ALTER TABLE composition_template_slots    ENABLE ROW LEVEL SECURITY;
ALTER TABLE equipment_compositions        ENABLE ROW LEVEL SECURITY;
ALTER TABLE equipment_composition_members ENABLE ROW LEVEL SECURITY;

CREATE POLICY comp_templates_tenant_isolation ON composition_templates
    USING (tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::BIGINT, 0));

CREATE POLICY comp_template_slots_isolation ON composition_template_slots
    USING (template_id IN (
        SELECT id FROM composition_templates
        WHERE tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::BIGINT, 0)
    ));

CREATE POLICY equipment_compositions_tenant_isolation ON equipment_compositions
    USING (tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::BIGINT, 0));

CREATE POLICY comp_members_isolation ON equipment_composition_members
    USING (composition_id IN (
        SELECT id FROM equipment_compositions
        WHERE tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::BIGINT, 0)
    ));

-- ============================================================
-- updated_at triggers
-- ============================================================

CREATE OR REPLACE TRIGGER set_updated_at_composition_templates
    BEFORE UPDATE ON composition_templates
    FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

CREATE OR REPLACE TRIGGER set_updated_at_equipment_compositions
    BEFORE UPDATE ON equipment_compositions
    FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();
