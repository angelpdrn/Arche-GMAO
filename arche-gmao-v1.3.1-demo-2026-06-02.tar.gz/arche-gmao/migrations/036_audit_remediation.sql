-- ============================================================
-- Arche GMAO - Migration 036: Audit remediation V1.3.0
-- ============================================================
-- Closes the gaps found in the V1.2.1 audit:
--   • node_type validation through a CHECK constraint
--   • Missing RLS on 6 tables
--   • Backfill of tenant_id in work_order_log and work_order_comments
--   • Missing composite indexes on work_orders
--   • Retroactive CHECK constraints (actual_hours>=0, quantity!=0)
--
-- Idempotent: uses IF NOT EXISTS / DO blocks with duplicate_object.
-- ============================================================

-- ─── 1. Allow-list for node_type (aligned with backend/nodes_handler) ──────
DO $$ BEGIN
    ALTER TABLE factory_nodes
        ADD CONSTRAINT factory_nodes_node_type_check
        CHECK (node_type IN (
            'organization', 'plant', 'area', 'line',
            'equipment', 'subassembly', 'component', 'sensor',
            'instrument', 'measurement_point', 'composition'
        )) NOT VALID;
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;

-- Validate the constraint only when no value falls outside the allow-list
DO $$
DECLARE
    bad_count INT;
BEGIN
    SELECT COUNT(*) INTO bad_count
    FROM factory_nodes
    WHERE node_type NOT IN (
        'plant', 'area', 'line', 'equipment',
        'subassembly', 'component', 'sensor',
        'instrument', 'composition'
    );

    IF bad_count = 0 THEN
        BEGIN
            ALTER TABLE factory_nodes VALIDATE CONSTRAINT factory_nodes_node_type_check;
        EXCEPTION
            WHEN OTHERS THEN NULL;
        END;
    ELSE
        RAISE NOTICE '[ARCHE-036] % nodos con node_type fuera de la lista blanca; constraint queda NOT VALID hasta limpieza manual', bad_count;
    END IF;
END $$;

-- ─── 2. Backfill tenant_id in work_order_log ─────────────────────────────────
ALTER TABLE work_order_log ADD COLUMN IF NOT EXISTS tenant_id BIGINT;

UPDATE work_order_log wol
   SET tenant_id = wo.tenant_id
  FROM work_orders wo
 WHERE wol.wo_id = wo.id
   AND wol.tenant_id IS NULL;

-- Only apply NOT NULL when the backfill covered every row
DO $$
DECLARE
    nulls INT;
BEGIN
    SELECT COUNT(*) INTO nulls FROM work_order_log WHERE tenant_id IS NULL;
    IF nulls = 0 THEN
        BEGIN
            ALTER TABLE work_order_log ALTER COLUMN tenant_id SET NOT NULL;
        EXCEPTION WHEN OTHERS THEN NULL;
        END;
        BEGIN
            ALTER TABLE work_order_log
                ADD CONSTRAINT fk_wol_tenant
                FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE;
        EXCEPTION WHEN duplicate_object THEN NULL;
        END;
    END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_work_order_log_tenant ON work_order_log(tenant_id);

-- ─── 3. Backfill tenant_id in work_order_comments ────────────────────────────
ALTER TABLE work_order_comments ADD COLUMN IF NOT EXISTS tenant_id BIGINT;

UPDATE work_order_comments woc
   SET tenant_id = wo.tenant_id
  FROM work_orders wo
 WHERE woc.wo_id = wo.id
   AND woc.tenant_id IS NULL;

DO $$
DECLARE
    nulls INT;
BEGIN
    SELECT COUNT(*) INTO nulls FROM work_order_comments WHERE tenant_id IS NULL;
    IF nulls = 0 THEN
        BEGIN
            ALTER TABLE work_order_comments ALTER COLUMN tenant_id SET NOT NULL;
        EXCEPTION WHEN OTHERS THEN NULL;
        END;
        BEGIN
            ALTER TABLE work_order_comments
                ADD CONSTRAINT fk_woc_tenant
                FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE;
        EXCEPTION WHEN duplicate_object THEN NULL;
        END;
    END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_work_order_comments_tenant ON work_order_comments(tenant_id);

-- ─── 4. RLS on the 6 missing tables ────────────────────────────────────────────
-- Tables that already had tenant_id but were missing RLS
DO $$
DECLARE
    tbl TEXT;
    tables TEXT[] := ARRAY[
        'node_assignments',
        'verification_records',
        'wo_scores',
        'notifications',
        'work_order_log',
        'work_order_comments'
    ];
BEGIN
    FOREACH tbl IN ARRAY tables LOOP
        IF EXISTS (SELECT 1 FROM information_schema.columns
                   WHERE table_name = tbl AND column_name = 'tenant_id') THEN
            EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', tbl);

            EXECUTE format('DROP POLICY IF EXISTS %I ON %I',
                tbl || '_tenant_isolation', tbl);

            EXECUTE format(
                'CREATE POLICY %I ON %I USING (
                    tenant_id = COALESCE(NULLIF(current_setting(''app.current_tenant_id'', true), '''')::bigint, 0)
                )',
                tbl || '_tenant_isolation', tbl);
        END IF;
    END LOOP;
END $$;

-- ─── 5. Missing composite indexes on work_orders ──────────────────────────
CREATE INDEX IF NOT EXISTS idx_work_orders_tenant_status
    ON work_orders(tenant_id, status);

CREATE INDEX IF NOT EXISTS idx_work_orders_tenant_assigned
    ON work_orders(tenant_id, assigned_to)
    WHERE assigned_to IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_work_orders_tenant_created
    ON work_orders(tenant_id, created_at DESC);

-- ─── 6. Retroactive CHECK constraints on work_orders ────────────────────
DO $$ BEGIN
    ALTER TABLE work_orders
        ADD CONSTRAINT chk_actual_hours_non_negative
        CHECK (actual_hours IS NULL OR actual_hours >= 0);
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
    ALTER TABLE work_orders
        ADD CONSTRAINT chk_estimated_hours_non_negative
        CHECK (estimated_hours IS NULL OR estimated_hours >= 0);
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- ─── 7. No zero-quantity inventory movements ─────────────────────────
DO $$ BEGIN
    ALTER TABLE part_movements
        ADD CONSTRAINT chk_movement_quantity_nonzero
        CHECK (quantity <> 0);
EXCEPTION
    WHEN duplicate_object THEN NULL;
    WHEN undefined_table THEN NULL;
END $$;

-- ─── 8. Basic email format on users (defence in depth) ───────────────
DO $$ BEGIN
    ALTER TABLE users
        ADD CONSTRAINT chk_users_email_format
        CHECK (
            email ~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'
        ) NOT VALID;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$
DECLARE bad_emails INT;
BEGIN
    SELECT COUNT(*) INTO bad_emails FROM users
    WHERE email !~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$';
    IF bad_emails = 0 THEN
        BEGIN
            ALTER TABLE users VALIDATE CONSTRAINT chk_users_email_format;
        EXCEPTION WHEN OTHERS THEN NULL;
        END;
    ELSE
        RAISE NOTICE '[ARCHE-036] % usuarios con email inválido; ejecutar limpieza antes de validar el constraint', bad_emails;
    END IF;
END $$;
