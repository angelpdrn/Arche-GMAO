-- 022_maintenance_enhancements.sql
-- Maintenance templates, per-node exclusions, plans by equipment template

-- ─── 1A. Maintenance plan templates ──────────────────────────────

CREATE TABLE IF NOT EXISTS maintenance_plan_templates (
    id                BIGSERIAL PRIMARY KEY,
    tenant_id         BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name              VARCHAR(255) NOT NULL,
    description       TEXT,
    wo_type           VARCHAR(50) DEFAULT 'preventive',
    priority          VARCHAR(20) DEFAULT 'medium',
    frequency_type    VARCHAR(20) NOT NULL DEFAULT 'months',
    frequency_value   INTEGER NOT NULL DEFAULT 1,
    advance_days      INTEGER DEFAULT 3,
    estimated_hours   NUMERIC(8,2),
    instructions      TEXT,
    checklist         JSONB DEFAULT '[]',
    safety_notes      TEXT,
    tools_required    JSONB DEFAULT '[]',
    required_parts    JSONB DEFAULT '[]',
    apply_to_children BOOLEAN NOT NULL DEFAULT false,
    created_by        BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(tenant_id, name)
);

CREATE INDEX IF NOT EXISTS idx_mpt_tenant ON maintenance_plan_templates(tenant_id);

ALTER TABLE maintenance_plan_templates ENABLE ROW LEVEL SECURITY;
DO $$ BEGIN
    CREATE POLICY mpt_tenant_policy ON maintenance_plan_templates
        USING (tenant_id = current_setting('app.current_tenant_id')::bigint);
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- ─── 1B. Per-node exclusions ────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS maintenance_plan_exclusions (
    id          BIGSERIAL PRIMARY KEY,
    tenant_id   BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    plan_id     BIGINT NOT NULL REFERENCES maintenance_plans(id) ON DELETE CASCADE,
    node_id     BIGINT NOT NULL REFERENCES factory_nodes(id) ON DELETE CASCADE,
    excluded_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(tenant_id, plan_id, node_id)
);

CREATE INDEX IF NOT EXISTS idx_mpe_plan ON maintenance_plan_exclusions(plan_id);
CREATE INDEX IF NOT EXISTS idx_mpe_node ON maintenance_plan_exclusions(node_id);

ALTER TABLE maintenance_plan_exclusions ENABLE ROW LEVEL SECURITY;
DO $$ BEGIN
    CREATE POLICY mpex_tenant_policy ON maintenance_plan_exclusions
        USING (tenant_id = current_setting('app.current_tenant_id')::bigint);
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- ─── 1C. New columns on maintenance_plans ───────────────────────────────

ALTER TABLE maintenance_plans ALTER COLUMN node_id DROP NOT NULL;

ALTER TABLE maintenance_plans
    ADD COLUMN IF NOT EXISTS equipment_template_id BIGINT REFERENCES equipment_templates(id) ON DELETE SET NULL,
    ADD COLUMN IF NOT EXISTS source_template_id BIGINT REFERENCES maintenance_plan_templates(id) ON DELETE SET NULL;

-- CHECK: at least one target
DO $$ BEGIN
    ALTER TABLE maintenance_plans
        ADD CONSTRAINT chk_plan_target CHECK (node_id IS NOT NULL OR equipment_template_id IS NOT NULL);
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

CREATE INDEX IF NOT EXISTS idx_maint_plans_eq_template
    ON maintenance_plans(equipment_template_id) WHERE equipment_template_id IS NOT NULL;
