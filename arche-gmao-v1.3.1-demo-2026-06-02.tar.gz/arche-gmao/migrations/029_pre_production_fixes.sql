-- ============================================================
-- 029_pre_production_fixes.sql
-- Pre-production integrity fixes:
-- - Missing indexes on frequently used columns
-- - CHECK constraints on status/type/numeric
-- - FK fix: hours_edited_by ON DELETE SET NULL
-- - RLS policies with a safe cast
-- ============================================================

-- ─── MISSING INDEXES ─────────────────────────────────────────────────────

-- High priority (worker polls, frequent queries)
CREATE INDEX IF NOT EXISTS idx_ai_index_queue_status ON ai_index_queue(status) WHERE status = 'pending';
CREATE INDEX IF NOT EXISTS idx_ai_index_queue_tenant ON ai_index_queue(tenant_id);
CREATE INDEX IF NOT EXISTS idx_work_orders_created_at ON work_orders(created_at);
CREATE INDEX IF NOT EXISTS idx_work_orders_created_by ON work_orders(created_by);
CREATE INDEX IF NOT EXISTS idx_work_orders_priority ON work_orders(priority);
CREATE INDEX IF NOT EXISTS idx_verification_records_wo ON verification_records(wo_id);
CREATE INDEX IF NOT EXISTS idx_verification_records_tenant ON verification_records(tenant_id);

-- Medium priority (user queries)
CREATE INDEX IF NOT EXISTS idx_ai_conversations_user ON ai_conversations(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_conversations_tenant ON ai_conversations(tenant_id);
CREATE INDEX IF NOT EXISTS idx_maint_plan_exec_plan ON maintenance_plan_executions(plan_id);
CREATE INDEX IF NOT EXISTS idx_maint_plan_exec_tenant ON maintenance_plan_executions(tenant_id);
CREATE INDEX IF NOT EXISTS idx_stock_movements_tenant ON stock_movements(tenant_id);
CREATE INDEX IF NOT EXISTS idx_stock_movements_created ON stock_movements(created_at);
CREATE INDEX IF NOT EXISTS idx_qr_scans_node ON qr_scans(node_id);
CREATE INDEX IF NOT EXISTS idx_qr_scans_tenant ON qr_scans(tenant_id);
CREATE INDEX IF NOT EXISTS idx_user_competencies_user ON user_competencies(user_id);
CREATE INDEX IF NOT EXISTS idx_user_competencies_tenant ON user_competencies(tenant_id);
CREATE INDEX IF NOT EXISTS idx_user_directories_user ON user_directories(user_id);
CREATE INDEX IF NOT EXISTS idx_user_directories_tenant ON user_directories(tenant_id);
CREATE INDEX IF NOT EXISTS idx_push_subscriptions_user ON push_subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_knowledge_log_tenant ON ai_knowledge_log(tenant_id);
CREATE INDEX IF NOT EXISTS idx_spare_parts_tenant ON spare_parts(tenant_id);
CREATE INDEX IF NOT EXISTS idx_work_order_log_user ON work_order_log(user_id);

-- ─── CHECK CONSTRAINTS ────────────────────────────────────────────────────

-- Status/type constraints (they prevent invalid data)
DO $$ BEGIN
  ALTER TABLE work_orders ADD CONSTRAINT chk_wo_status
    CHECK (status IN ('pending','assigned','approved','in_progress','completed','verified','closed','draft','rejected','paused','cancelled'));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  ALTER TABLE work_orders ADD CONSTRAINT chk_wo_type
    CHECK (wo_type IN ('corrective','preventive','predictive','improvement','inspection'));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  ALTER TABLE work_orders ADD CONSTRAINT chk_wo_priority
    CHECK (priority IN ('low','medium','high','critical'));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- Numeric constraints (they prevent negative values)
DO $$ BEGIN
  ALTER TABLE spare_parts ADD CONSTRAINT chk_current_stock_positive CHECK (current_stock >= 0);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  ALTER TABLE spare_parts ADD CONSTRAINT chk_min_stock_positive CHECK (min_stock IS NULL OR min_stock >= 0);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  ALTER TABLE spare_parts ADD CONSTRAINT chk_unit_price_positive CHECK (unit_price IS NULL OR unit_price >= 0);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  ALTER TABLE work_orders ADD CONSTRAINT chk_estimated_hours_positive CHECK (estimated_hours IS NULL OR estimated_hours >= 0);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  ALTER TABLE work_orders ADD CONSTRAINT chk_actual_hours_positive CHECK (actual_hours IS NULL OR actual_hours >= 0);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  ALTER TABLE work_order_parts ADD CONSTRAINT chk_wo_parts_quantity_positive CHECK (quantity > 0);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ─── FK FIX: hours_edited_by ON DELETE SET NULL ───────────────────────────

DO $$ BEGIN
  ALTER TABLE work_orders DROP CONSTRAINT IF EXISTS work_orders_hours_edited_by_fkey;
  ALTER TABLE work_orders ADD CONSTRAINT work_orders_hours_edited_by_fkey
    FOREIGN KEY (hours_edited_by) REFERENCES users(id) ON DELETE SET NULL;
EXCEPTION WHEN undefined_object THEN NULL; END $$;

-- ─── RLS POLICIES: fix the unsafe cast ─────────────────────────────────
-- The original policies use COALESCE(current_setting(..., true)::bigint, 0::bigint)
-- The new tables cast directly without COALESCE → ERROR when the setting is missing

-- daily_summaries
DO $$ BEGIN
  DROP POLICY IF EXISTS daily_summaries_tenant_isolation ON daily_summaries;
  ALTER TABLE daily_summaries ENABLE ROW LEVEL SECURITY;
  CREATE POLICY daily_summaries_tenant_isolation ON daily_summaries
    FOR ALL USING (tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::bigint, 0::bigint));
EXCEPTION WHEN undefined_table THEN NULL; END $$;

-- monthly_summary_folders
DO $$ BEGIN
  DROP POLICY IF EXISTS msf_tenant_isolation ON monthly_summary_folders;
  ALTER TABLE monthly_summary_folders ENABLE ROW LEVEL SECURITY;
  CREATE POLICY msf_tenant_isolation ON monthly_summary_folders
    FOR ALL USING (tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::bigint, 0::bigint));
EXCEPTION WHEN undefined_table THEN NULL; END $$;

-- Tables from recent migrations with an unsafe cast
DO $$ BEGIN
  DROP POLICY IF EXISTS mm_tenant_policy ON maintenance_manuals;
  CREATE POLICY mm_tenant_policy ON maintenance_manuals
    FOR ALL USING (tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::bigint, 0::bigint));
EXCEPTION WHEN undefined_table THEN NULL; WHEN undefined_object THEN NULL; END $$;

DO $$ BEGIN
  DROP POLICY IF EXISTS mpe_tenant_policy ON maintenance_plan_exclusions;
  CREATE POLICY mpe_tenant_policy ON maintenance_plan_exclusions
    FOR ALL USING (tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::bigint, 0::bigint));
EXCEPTION WHEN undefined_table THEN NULL; WHEN undefined_object THEN NULL; END $$;

DO $$ BEGIN
  DROP POLICY IF EXISTS mpt_tenant_policy ON maintenance_plan_templates;
  CREATE POLICY mpt_tenant_policy ON maintenance_plan_templates
    FOR ALL USING (tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::bigint, 0::bigint));
EXCEPTION WHEN undefined_table THEN NULL; WHEN undefined_object THEN NULL; END $$;

DO $$ BEGIN
  DROP POLICY IF EXISTS nae_tenant_policy ON node_assignment_exclusions;
  CREATE POLICY nae_tenant_policy ON node_assignment_exclusions
    FOR ALL USING (tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::bigint, 0::bigint));
EXCEPTION WHEN undefined_table THEN NULL; WHEN undefined_object THEN NULL; END $$;

DO $$ BEGIN
  DROP POLICY IF EXISTS sc_tenant_policy ON staggered_configs;
  CREATE POLICY sc_tenant_policy ON staggered_configs
    FOR ALL USING (tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::bigint, 0::bigint));
EXCEPTION WHEN undefined_table THEN NULL; WHEN undefined_object THEN NULL; END $$;

DO $$ BEGIN
  DROP POLICY IF EXISTS scy_tenant_policy ON staggered_cycles;
  CREATE POLICY scy_tenant_policy ON staggered_cycles
    FOR ALL USING (tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::bigint, 0::bigint));
EXCEPTION WHEN undefined_table THEN NULL; WHEN undefined_object THEN NULL; END $$;

DO $$ BEGIN
  DROP POLICY IF EXISTS ss_tenant_policy ON staggered_schedule;
  CREATE POLICY ss_tenant_policy ON staggered_schedule
    FOR ALL USING (tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::bigint, 0::bigint));
EXCEPTION WHEN undefined_table THEN NULL; WHEN undefined_object THEN NULL; END $$;

DO $$ BEGIN
  DROP POLICY IF EXISTS tf_tenant_policy ON template_folders;
  CREATE POLICY tf_tenant_policy ON template_folders
    FOR ALL USING (tenant_id = COALESCE(current_setting('app.current_tenant_id', true)::bigint, 0::bigint));
EXCEPTION WHEN undefined_table THEN NULL; WHEN undefined_object THEN NULL; END $$;
