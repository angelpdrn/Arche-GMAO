#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# Arche GMAO — Server update
# Runs ON THE CLIENT SERVER, by Angel.
#
# Usage: ./update.sh arche-server
#   or: ./update.sh /path/to/arche-server
#
# Flow:
#   1. Verify the SHA256 checksum of the new binary
#   2. Pre-checks: disk, database, Redis
#   3. Automatic DB backup
#   4. Backup of the current binary
#   5. Stop, replace, restart the service
#   6. Health check with automatic rollback on failure
# ─────────────────────────────────────────────────────────────────────────────

set -euo pipefail

INSTALL_DIR="/opt/arche-gmao"
SERVICE_NAME="arche-gmao"
BINARY_NAME="arche-server"
BACKUP_DIR="$INSTALL_DIR/backups"
CONFIG_DIR="$INSTALL_DIR/config"
API_PORT="${PORT:-3000}"
HEALTH_URL="http://localhost:${API_PORT}/api/v1/health"
MAX_WAIT=30           # seconds for the health check
MIN_DISK_MB=500       # minimum free disk space (MB)
DB_BACKUP_TIMEOUT=300 # seconds for the DB backup

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

mkdir -p "$INSTALL_DIR/logs" "$BACKUP_DIR"
LOG_FILE="$INSTALL_DIR/logs/update.log"

log()  { echo -e "${CYAN}[UPDATE]${NC} $1" | tee -a "$LOG_FILE"; }
ok()   { echo -e "${GREEN}[OK]${NC} $1" | tee -a "$LOG_FILE"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1" | tee -a "$LOG_FILE"; }
fail() { echo -e "${RED}[ERROR]${NC} $1" | tee -a "$LOG_FILE"; exit 1; }

echo "" >> "$LOG_FILE"
echo "═══════════════════════════════════════════════════════════" >> "$LOG_FILE"
echo "Actualizacion iniciada: $(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"
echo "═══════════════════════════════════════════════════════════" >> "$LOG_FILE"

# ─── Check permissions ─────────────────────────────────────────────────────

if [ "$(id -u)" -ne 0 ]; then
  fail "Este script debe ejecutarse como root (sudo ./update.sh ...)"
fi

# ─── Check arguments ───────────────────────────────────────────────────

NEW_BINARY="${1:-}"
if [ -z "$NEW_BINARY" ]; then
  echo ""
  echo "  Uso: sudo $0 <ruta-al-nuevo-binario>"
  echo "  Ejemplo: sudo $0 ./arche-server"
  echo ""
  echo "  Copiar el binario y su .sha256 al servidor:"
  echo "    scp arche-server arche-server.sha256 usuario@servidor:$INSTALL_DIR/"
  echo ""
  exit 1
fi

# Resolve absolute path
if [[ "$NEW_BINARY" != /* ]]; then
  NEW_BINARY="$(pwd)/$NEW_BINARY"
fi

if [ ! -f "$NEW_BINARY" ]; then
  fail "Binario no encontrado: $NEW_BINARY"
fi

CURRENT_BINARY="$INSTALL_DIR/$BINARY_NAME"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

echo ""
echo -e "${CYAN}════════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}  Arche GMAO — Actualizacion${NC}"
echo -e "${CYAN}════════════════════════════════════════════════════════════════${NC}"
echo ""

# ─── Step 1: Verify checksum ─────────────────────────────────────────────

log "Paso 1/6: Verificando integridad del nuevo binario..."

CHECKSUM_FILE="${NEW_BINARY}.sha256"
if [ -f "$CHECKSUM_FILE" ]; then
  cd "$(dirname "$NEW_BINARY")"
  if sha256sum -c "$(basename "$CHECKSUM_FILE")" --status 2>/dev/null; then
    ok "Checksum SHA256 verificado"
  else
    fail "Checksum SHA256 no coincide. Binario corrupto o modificado."
  fi
  cd - >/dev/null
else
  warn "No se encontro archivo .sha256 — omitiendo verificacion de integridad"
fi

# Check that it is a Linux executable
if ! file "$NEW_BINARY" | grep -q "ELF.*executable"; then
  fail "El archivo no es un ejecutable Linux valido"
fi

# ─── Step 2: Pre-checks ────────────────────────────────────────────────────

log "Paso 2/6: Verificaciones previas..."

# 2a. Disk space
AVAIL_MB=$(df -m "$INSTALL_DIR" | tail -1 | awk '{print $4}')
if [ "$AVAIL_MB" -lt "$MIN_DISK_MB" ]; then
  fail "Espacio insuficiente: ${AVAIL_MB}MB disponibles, se requieren al menos ${MIN_DISK_MB}MB"
fi
ok "Disco: ${AVAIL_MB}MB disponibles"

# 2b. Docker
if ! command -v docker >/dev/null 2>&1 || ! docker info >/dev/null 2>&1; then
  fail "Docker no esta disponible o no esta funcionando"
fi
ok "Docker operativo"

# 2c. Load environment variables
ENV_FILE="$CONFIG_DIR/.env"
if [ -f "$ENV_FILE" ]; then
  set +u
  source "$ENV_FILE" 2>/dev/null || true
  set -u
fi

# 2d. PostgreSQL
DB_CONTAINER=$(docker ps --filter "name=postgres" --filter "status=running" --format "{{.Names}}" | head -1)
if [ -z "$DB_CONTAINER" ]; then
  DB_CONTAINER=$(docker ps --filter "ancestor=pgvector/pgvector:pg16" --filter "status=running" --format "{{.Names}}" | head -1)
fi
if [ -z "$DB_CONTAINER" ]; then
  fail "Contenedor PostgreSQL no encontrado o no esta corriendo"
fi
if ! docker exec "$DB_CONTAINER" pg_isready -U "${POSTGRES_USER:-arche}" -d "${POSTGRES_DB:-arche}" >/dev/null 2>&1; then
  fail "PostgreSQL no responde en contenedor $DB_CONTAINER"
fi
ok "PostgreSQL operativo ($DB_CONTAINER)"

# 2e. Redis
REDIS_CONTAINER=$(docker ps --filter "name=redis" --filter "status=running" --format "{{.Names}}" | head -1)
if [ -n "$REDIS_CONTAINER" ]; then
  if docker exec "$REDIS_CONTAINER" redis-cli -a "${REDIS_PASSWORD:-}" ping >/dev/null 2>&1; then
    ok "Redis operativo ($REDIS_CONTAINER)"
  else
    warn "Redis no responde — continuando"
  fi
else
  warn "Contenedor Redis no encontrado — continuando"
fi

# 2f. Current version
CURRENT_VERSION="desconocida"
HEALTH_RESPONSE=$(curl -s --connect-timeout 3 "$HEALTH_URL" 2>/dev/null || true)
if [ -n "$HEALTH_RESPONSE" ]; then
  CURRENT_VERSION=$(echo "$HEALTH_RESPONSE" | grep -oP '"version"\s*:\s*"[^"]*"' | head -1 | cut -d'"' -f4 || echo "desconocida")
fi
log "  Version actual: $CURRENT_VERSION"

# ─── Step 3: Database backup ────────────────────────────────────

log "Paso 3/6: Backup de la base de datos..."

DB_BACKUP="$BACKUP_DIR/arche_pre_update_${TIMESTAMP}.sql.gz"

if timeout "$DB_BACKUP_TIMEOUT" docker exec "$DB_CONTAINER" \
    pg_dump -U "${POSTGRES_USER:-arche}" -d "${POSTGRES_DB:-arche}" --no-owner --no-privileges \
    2>/dev/null | gzip > "$DB_BACKUP"; then

  # Check that the file is not empty
  DB_SIZE=$(stat -c%s "$DB_BACKUP" 2>/dev/null || echo "0")
  if [ "$DB_SIZE" -gt 100 ]; then
    DB_SIZE_H=$(du -sh "$DB_BACKUP" | cut -f1)
    ok "Backup BD creado: $DB_BACKUP ($DB_SIZE_H)"
  else
    rm -f "$DB_BACKUP"
    DB_BACKUP=""
    warn "Backup BD vacio o fallido"
  fi
else
  rm -f "$DB_BACKUP"
  DB_BACKUP=""
  warn "No se pudo crear backup de la BD"
fi

# Prune old backups (keep the last 5)
ls -1t "$BACKUP_DIR"/arche_pre_update_*.sql.gz 2>/dev/null | tail -n +6 | xargs rm -f 2>/dev/null || true

# ─── Step 4: Backup of the current binary ─────────────────────────────────────

log "Paso 4/6: Creando backup del binario actual..."

BINARY_BACKUP=""
if [ -f "$CURRENT_BINARY" ]; then
  BINARY_BACKUP="$BACKUP_DIR/${BINARY_NAME}.${TIMESTAMP}.bak"
  cp "$CURRENT_BINARY" "$BINARY_BACKUP"
  ok "Backup binario: $BINARY_BACKUP"
else
  warn "No existe binario anterior — primera instalacion"
fi

# ─── Step 5: Stop, replace, restart ────────────────────────────────

log "Paso 5/6: Instalando nuevo binario..."

# Stop the service if it is running
if systemctl is-active --quiet "$SERVICE_NAME" 2>/dev/null; then
  log "  Deteniendo servicio $SERVICE_NAME..."
  systemctl stop "$SERVICE_NAME"
  sleep 1
fi

cp "$NEW_BINARY" "$CURRENT_BINARY"
chmod 755 "$CURRENT_BINARY"
ok "Binario instalado en $CURRENT_BINARY"

log "  Iniciando servicio $SERVICE_NAME..."
systemctl start "$SERVICE_NAME"

# ─── Step 6: Health check with rollback ─────────────────────────────────────

log "Paso 6/6: Verificando arranque (max ${MAX_WAIT}s)..."

STARTED=false
for i in $(seq 1 "$MAX_WAIT"); do
  sleep 1
  # Check that the process is still running
  if ! systemctl is-active --quiet "$SERVICE_NAME" 2>/dev/null; then
    break
  fi
  # Check the health endpoint
  HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$HEALTH_URL" 2>/dev/null || echo "000")
  if [ "$HTTP_CODE" = "200" ]; then
    STARTED=true
    break
  fi
  printf "."
done
echo ""

if [ "$STARTED" = true ]; then
  # Get the new version
  NEW_VERSION=$(curl -s "$HEALTH_URL" 2>/dev/null | grep -oP '"version"\s*:\s*"[^"]*"' | head -1 | cut -d'"' -f4 || echo "desconocida")
  ok "Servicio arrancado correctamente (${i}s)"

  # Prune old binary backups (keep the last 5)
  BACKUP_COUNT=$(ls -1 "$BACKUP_DIR"/${BINARY_NAME}.*.bak 2>/dev/null | wc -l)
  if [ "$BACKUP_COUNT" -gt 5 ]; then
    ls -1t "$BACKUP_DIR"/${BINARY_NAME}.*.bak | tail -n +6 | xargs rm -f
    log "Limpiados backups antiguos (manteniendo ultimos 5)"
  fi

  echo ""
  echo -e "${GREEN}════════════════════════════════════════════════════════════════${NC}"
  echo -e "${GREEN}  Actualizacion completada exitosamente${NC}"
  echo -e "${GREEN}════════════════════════════════════════════════════════════════${NC}"
  echo ""
  echo "  Version anterior:  $CURRENT_VERSION"
  echo "  Version nueva:     $NEW_VERSION"
  if [ -n "$DB_BACKUP" ]; then
  echo "  Backup BD:         $DB_BACKUP"
  fi
  if [ -n "$BINARY_BACKUP" ]; then
  echo "  Backup binario:    $BINARY_BACKUP"
  fi
  echo "  Log:               $LOG_FILE"
  echo ""
  echo "  Para verificar: curl $HEALTH_URL"
  echo ""

  log "Actualizacion completada: $CURRENT_VERSION -> $NEW_VERSION"
else
  # ─── Automatic rollback ───────────────────────────────────────────────
  echo ""
  echo -e "${RED}════════════════════════════════════════════════════════════════${NC}"
  echo -e "${RED}  HEALTH CHECK FALLIDO — Rollback automatico${NC}"
  echo -e "${RED}════════════════════════════════════════════════════════════════${NC}"
  echo ""

  log "ROLLBACK: Health check fallo tras ${MAX_WAIT}s"

  # Show the failure logs
  log "Ultimas lineas del journal:"
  journalctl -u "$SERVICE_NAME" --no-pager -n 15 2>/dev/null || true
  echo ""

  if [ -n "$BINARY_BACKUP" ] && [ -f "$BINARY_BACKUP" ]; then
    systemctl stop "$SERVICE_NAME" 2>/dev/null || true
    sleep 1
    cp "$BINARY_BACKUP" "$CURRENT_BINARY"
    chmod 755 "$CURRENT_BINARY"
    systemctl start "$SERVICE_NAME"

    # Check that the backup starts up
    sleep 3
    if systemctl is-active --quiet "$SERVICE_NAME" 2>/dev/null; then
      ok "ROLLBACK: Version anterior restaurada y servicio funcionando"
    else
      fail "ROLLBACK: La version anterior tampoco arranca. Revision manual necesaria."
    fi
  else
    fail "ROLLBACK: No hay backup para restaurar. Revision manual necesaria."
  fi

  echo ""
  echo -e "${RED}  La actualizacion fallo. Se restauro la version anterior.${NC}"
  echo ""
  echo "  Diagnosticar:"
  echo "    journalctl -u $SERVICE_NAME --no-pager -n 50"
  echo "    cat $LOG_FILE"
  echo ""

  log "ROLLBACK completado: restaurada version $CURRENT_VERSION"
  exit 1
fi
