#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# Arche GMAO — Production build
# Runs on Angel's development machine, NOT on the client server.
#
# Usage: ./build.sh [version]
#   Example: ./build.sh 1.2.0
#   Without a parameter: uses the latest git tag, or "1.1.0" as a fallback
#
# Strict order:
#   1. Build the frontend with Vite
#   2. Obfuscation with javascript-obfuscator (optional)
#   3. Copy dist/ to api/internal/static/dist/
#   4. Compile Go with -tags production -ldflags "-s -w"
#   5. Generate SHA256 checksum
#
# Result: build/arche-server + build/arche-server.sha256
# ─────────────────────────────────────────────────────────────────────────────

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BUILD_DIR="$SCRIPT_DIR/build"
FRONTEND_DIR="$SCRIPT_DIR/frontend"
API_DIR="$SCRIPT_DIR/api"
STATIC_DIR="$API_DIR/internal/static"
BINARY_NAME="arche-server"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

log()  { echo -e "${CYAN}[BUILD]${NC} $1"; }
ok()   { echo -e "${GREEN}[OK]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
fail() { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

# ─── Check dependencies ──────────────────────────────────────────────────

log "Verificando dependencias..."

command -v node  >/dev/null 2>&1 || fail "node no encontrado. Instalar Node.js 20+"
command -v npm   >/dev/null 2>&1 || fail "npm no encontrado"
command -v go    >/dev/null 2>&1 || fail "go no encontrado. Instalar Go 1.24+"

NODE_VERSION=$(node -v | sed 's/v//' | cut -d. -f1)
GO_VERSION=$(go version | grep -oP '\d+\.\d+')

log "  Node.js: v$(node -v | sed 's/v//')"
log "  Go:      $GO_VERSION"

# ─── Prepare the build directory ────────────────────────────────────────────

mkdir -p "$BUILD_DIR"

# ─── Step 1: Build the frontend ─────────────────────────────────────────────────

log "Paso 1/5: Compilando frontend con Vite..."
cd "$FRONTEND_DIR"

# Install dependencies if node_modules is missing
if [ ! -d "node_modules" ]; then
  log "  Instalando dependencias npm..."
  npm ci --silent
fi

# Production build
npm run build 2>&1 | tail -5

if [ ! -d "dist" ] || [ ! -f "dist/index.html" ]; then
  fail "Build del frontend fallo: dist/index.html no encontrado"
fi

FRONTEND_SIZE=$(du -sh dist | cut -f1)
ok "Frontend compilado ($FRONTEND_SIZE)"

# ─── Step 2: Obfuscation (optional) ──────────────────────────────────────────

log "Paso 2/5: Ofuscacion de JavaScript..."

if command -v javascript-obfuscator >/dev/null 2>&1; then
  JS_COUNT=0
  for jsfile in dist/assets/*.js; do
    [ -f "$jsfile" ] || continue
    # Only obfuscate files > 1KB (skip tiny chunks)
    FILE_SIZE=$(stat -f%z "$jsfile" 2>/dev/null || stat -c%s "$jsfile" 2>/dev/null)
    if [ "$FILE_SIZE" -gt 1024 ]; then
      javascript-obfuscator "$jsfile" \
        --output "$jsfile" \
        --compact true \
        --control-flow-flattening false \
        --dead-code-injection false \
        --string-array true \
        --string-array-threshold 0.5 \
        --self-defending false \
        --disable-console-output true \
        --identifier-names-generator hexadecimal \
        2>/dev/null
      JS_COUNT=$((JS_COUNT + 1))
    fi
  done
  ok "Ofuscados $JS_COUNT archivos JavaScript"
else
  warn "javascript-obfuscator no instalado — omitiendo ofuscacion"
  warn "  Instalar con: npm install -g javascript-obfuscator"
fi

# ─── Step 3: Copy dist/ into the embed directory ────────────────────────────

log "Paso 3/5: Copiando frontend a api/internal/static/dist/..."

# Clean the previous dist if present
rm -rf "$STATIC_DIR/dist"

# Copy
cp -r "$FRONTEND_DIR/dist" "$STATIC_DIR/dist"

DIST_FILES=$(find "$STATIC_DIR/dist" -type f | wc -l)
ok "Copiados $DIST_FILES archivos a static/dist/"

# ─── Step 3b: Copy migrations for embedding ────────────────────────────────

log "  Copiando migraciones SQL para embed en binario..."

MIGRATIONS_SRC="$SCRIPT_DIR/migrations"
MIGRATIONS_DST="$API_DIR/internal/database/migrations"

rm -rf "$MIGRATIONS_DST"
mkdir -p "$MIGRATIONS_DST"
cp "$MIGRATIONS_SRC"/*.sql "$MIGRATIONS_DST/"

MIG_COUNT=$(ls "$MIGRATIONS_DST"/*.sql 2>/dev/null | wc -l)
ok "Copiadas $MIG_COUNT migraciones para embed"

# ─── Step 4: Compile the Go binary ────────────────────────────────────────────

log "Paso 4/5: Compilando binario Go (produccion)..."
cd "$API_DIR"

# Make sure dependencies are in place
go mod tidy 2>/dev/null

# Determine version: parameter > git tag > fallback
APP_VERSION="${1:-}"
if [ -z "$APP_VERSION" ]; then
  APP_VERSION=$(git describe --tags --abbrev=0 2>/dev/null || echo "")
fi
if [ -z "$APP_VERSION" ]; then
  APP_VERSION="1.1.0"
  warn "Sin tag git — usando version por defecto: $APP_VERSION"
fi
log "  Version: $APP_VERSION"

# Read the Ed25519 public key to embed in the binary
PUBKEY_FILE="$HOME/.arche/public.key"
if [ ! -f "$PUBKEY_FILE" ]; then
  fail "Clave publica no encontrada en $PUBKEY_FILE"
  fail "Ejecuta: go run ./cmd/arche init"
fi
PUBKEY_HEX=$(cat "$PUBKEY_FILE" | tr -d '[:space:]')
log "  Clave publica: ${PUBKEY_HEX:0:16}..."

# Compile with:
#   -tags production  → enables embed.FS + hwcheck + license check
#   -ldflags "-s -w"  → strip symbols + debug info
#   -X license.publicKeyHex  → embeds the Ed25519 public key
#   -X handlers.Version      → embeds the system version
#   CGO_ENABLED=0     → static binary (no libc)
#   GOOS=linux        → always compile for Linux
LDFLAGS="-s -w -X arche-gmao/api/internal/license.publicKeyHex=${PUBKEY_HEX} -X arche-gmao/api/internal/handlers.Version=${APP_VERSION}"

CGO_ENABLED=0 GOOS=linux GOARCH=amd64 \
  go build \
    -tags production \
    -ldflags "$LDFLAGS" \
    -o "$BUILD_DIR/$BINARY_NAME" \
    ./cmd/server

if [ ! -f "$BUILD_DIR/$BINARY_NAME" ]; then
  fail "Compilacion fallo: binario no generado"
fi

BINARY_SIZE=$(du -sh "$BUILD_DIR/$BINARY_NAME" | cut -f1)
ok "Binario servidor: $BUILD_DIR/$BINARY_NAME ($BINARY_SIZE)"

# Compile the administration CLI (no production tags, for the AP machine)
log "  Compilando CLI de administracion..."
go build -ldflags "-s -w" -o "$BUILD_DIR/arche" ./cmd/arche
ok "CLI compilado: $BUILD_DIR/arche"

# Compile the fingerprint tool for clients (linux static)
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 \
  go build -ldflags "-s -w" -o "$BUILD_DIR/arche-fingerprint" ./cmd/arche
ok "Fingerprint tool: $BUILD_DIR/arche-fingerprint (para clientes)"

# ─── Step 5: Generate checksum ───────────────────────────────────────────────

log "Paso 5/5: Generando checksum SHA256..."

cd "$BUILD_DIR"
sha256sum "$BINARY_NAME" > "${BINARY_NAME}.sha256"

CHECKSUM=$(cat "${BINARY_NAME}.sha256" | cut -d' ' -f1)
ok "SHA256: $CHECKSUM"

# ─── Clean up embedded files (do not leave them in the repo) ───────────────────────

rm -rf "$STATIC_DIR/dist"
rm -rf "$MIGRATIONS_DST"

# ─── Summary ─────────────────────────────────────────────────────────────────

echo ""
echo -e "${GREEN}════════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  Build completado exitosamente${NC}"
echo -e "${GREEN}════════════════════════════════════════════════════════════════${NC}"
echo ""
echo "  Version:   $APP_VERSION"
echo "  Binario:   $BUILD_DIR/$BINARY_NAME"
echo "  Tamano:    $BINARY_SIZE"
echo "  Checksum:  $BUILD_DIR/${BINARY_NAME}.sha256"
echo "  SHA256:    $CHECKSUM"
echo ""
echo "  Actualizar servidor remoto:"
echo "    scp $BUILD_DIR/$BINARY_NAME $BUILD_DIR/${BINARY_NAME}.sha256 usuario@servidor:/opt/arche-gmao/"
echo "    ssh usuario@servidor 'cd /opt/arche-gmao && sudo ./update.sh $BINARY_NAME'"
echo ""
