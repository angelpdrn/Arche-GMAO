//go:build !production

package hwcheck

// Verify does nothing in development builds.
// In production (build tag "production") it is swapped for the real check.
func Verify(configPath string) {}
