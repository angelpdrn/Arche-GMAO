//go:build production

package hwcheck

import (
	"bufio"
	"fmt"
	"log"
	"net"
	"os"
	"strings"
)

// hwConfig holds the values recorded during installation.
type hwConfig struct {
	MachineID    string
	MACAddress   string
	AllowedHosts []string
}

// Verify reads /etc/arche/hardware.conf and compares it against the current hardware.
// If any check fails, it terminates the process with log.Fatalf.
// It runs before connecting to the database.
func Verify(configPath string) {
	registered, err := readConfig(configPath)
	if err != nil {
		log.Fatalf("[ARCHE] Error leyendo configuración de hardware (%s): %v", configPath, err)
	}

	// 1. Check machine-id
	currentMachineID, err := readMachineID()
	if err != nil {
		log.Fatalf("[ARCHE] Error leyendo machine-id del servidor: %v", err)
	}
	if registered.MachineID != "" && currentMachineID != registered.MachineID {
		log.Fatalf("[ARCHE] Error de verificación: este servidor no coincide con la instalación registrada (machine-id)")
	}

	// 2. Check the MAC address
	currentMAC, err := readPrimaryMAC()
	if err != nil {
		log.Fatalf("[ARCHE] Error leyendo dirección MAC del servidor: %v", err)
	}
	if registered.MACAddress != "" && !strings.EqualFold(currentMAC, registered.MACAddress) {
		log.Fatalf("[ARCHE] Error de verificación: la interfaz de red no coincide con la instalación registrada (MAC)")
	}

	// 3. Check hostname/IP
	if len(registered.AllowedHosts) > 0 {
		if !matchesAnyHost(registered.AllowedHosts) {
			log.Fatalf("[ARCHE] Error de verificación: el dominio o IP de este servidor no está autorizado")
		}
	}

	log.Printf("[ARCHE] Verificación de hardware correcta")
}

// readConfig parses the hardware.conf file.
// A simple key=value format, one per line. Lines starting with # are comments.
func readConfig(path string) (*hwConfig, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, fmt.Errorf("no se pudo abrir %s: %w", path, err)
	}
	defer f.Close()

	cfg := &hwConfig{}
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		parts := strings.SplitN(line, "=", 2)
		if len(parts) != 2 {
			continue
		}
		key := strings.TrimSpace(parts[0])
		val := strings.TrimSpace(parts[1])

		switch key {
		case "MACHINE_ID":
			cfg.MachineID = val
		case "MAC_ADDRESS":
			cfg.MACAddress = val
		case "ALLOWED_HOSTS":
			for _, h := range strings.Split(val, ",") {
				h = strings.TrimSpace(h)
				if h != "" {
					cfg.AllowedHosts = append(cfg.AllowedHosts, h)
				}
			}
		}
	}

	if cfg.MachineID == "" {
		return nil, fmt.Errorf("MACHINE_ID no encontrado en %s", path)
	}

	return cfg, scanner.Err()
}

// readMachineID reads /etc/machine-id (standard under systemd).
func readMachineID() (string, error) {
	data, err := os.ReadFile("/etc/machine-id")
	if err != nil {
		return "", fmt.Errorf("no se pudo leer /etc/machine-id: %w", err)
	}
	id := strings.TrimSpace(string(data))
	if id == "" {
		return "", fmt.Errorf("/etc/machine-id está vacío")
	}
	return id, nil
}

// readPrimaryMAC gets the MAC of the first active non-loopback network interface.
func readPrimaryMAC() (string, error) {
	ifaces, err := net.Interfaces()
	if err != nil {
		return "", fmt.Errorf("error listando interfaces de red: %w", err)
	}

	for _, iface := range ifaces {
		// Skip loopback and interfaces without a MAC
		if iface.Flags&net.FlagLoopback != 0 {
			continue
		}
		if iface.Flags&net.FlagUp == 0 {
			continue
		}
		mac := iface.HardwareAddr.String()
		if mac != "" {
			return mac, nil
		}
	}

	return "", fmt.Errorf("no se encontró una interfaz de red activa con dirección MAC")
}

// matchesAnyHost checks whether the hostname or any server IP is in the allowed list.
func matchesAnyHost(allowed []string) bool {
	hostname, _ := os.Hostname()

	// Get every IP of the server
	var serverIPs []string
	addrs, err := net.InterfaceAddrs()
	if err == nil {
		for _, addr := range addrs {
			if ipnet, ok := addr.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
				serverIPs = append(serverIPs, ipnet.IP.String())
			}
		}
	}

	for _, host := range allowed {
		host = strings.ToLower(host)
		// Compare against the hostname
		if strings.ToLower(hostname) == host {
			return true
		}
		// Compare against the server IPs
		for _, ip := range serverIPs {
			if ip == host {
				return true
			}
		}
	}

	return false
}
