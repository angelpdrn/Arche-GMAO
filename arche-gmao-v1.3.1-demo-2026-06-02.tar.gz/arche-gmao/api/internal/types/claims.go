package types

import "github.com/golang-jwt/jwt/v5"

// Claims is the payload of an Arche GMAO JWT.
// It carries the user ID, tenant, role and JTI for revocation.
type Claims struct {
	UserID       int64  `json:"user_id"`
	TenantID     int64  `json:"tenant_id"`
	Role         string `json:"role"`
	IsSuperadmin bool   `json:"is_superadmin,omitempty"`
	JTI          string `json:"jti,omitempty"`
	jwt.RegisteredClaims
}
