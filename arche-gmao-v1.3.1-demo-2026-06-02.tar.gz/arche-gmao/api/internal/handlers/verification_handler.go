package handlers

import (
	"strconv"

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type VerificationHandler struct {
	db *pgxpool.Pool
}

func NewVerificationHandler(db *pgxpool.Pool) *VerificationHandler {
	return &VerificationHandler{db: db}
}

type VerificationResponse struct {
	ID              int64   `json:"id"`
	WONumber        *string `json:"wo_number"`
	WOTitle         *string `json:"wo_title"`
	SubmittedBy     *string `json:"submitted_by"`
	VerifiedBy      *string `json:"verified_by"`
	Status          string  `json:"status"`
	ConfidenceLevel int     `json:"confidence_level"`
	Notes           *string `json:"notes"`
	SubmittedAt     string  `json:"submitted_at"`
	VerifiedAt      *string `json:"verified_at"`
}

// ─── GET /verifications ───────────────────────────────────────────────────────

func (h *VerificationHandler) List(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	status := c.Query("status")

	query := `
		SELECT vr.id, wo.wo_number, wo.title,
		       us.full_name, uv.full_name,
		       vr.status, vr.confidence_level, vr.notes,
		       vr.submitted_at::text, vr.verified_at::text
		FROM verification_records vr
		LEFT JOIN work_orders wo ON wo.id = vr.wo_id
		LEFT JOIN users us ON us.id = vr.submitted_by
		LEFT JOIN users uv ON uv.id = vr.verified_by
		WHERE vr.tenant_id = $1`

	args := []interface{}{claims.TenantID}
	argIdx := 2

	if status != "" {
		query += ` AND vr.status = $` + strconv.Itoa(argIdx)
		args = append(args, status)
		argIdx++
	}

	// Supervisor, technician and operator: only verifications of WOs on their assigned nodes
	if claims.Role == "supervisor" || claims.Role == "technician" || claims.Role == "operator" {
		query += ` AND wo.node_id IN (
			SELECT fn.id FROM factory_nodes fn
			JOIN node_assignments na ON na.user_id = $` + strconv.Itoa(argIdx) + ` AND na.tenant_id = $1
			JOIN factory_nodes assigned ON assigned.id = na.node_id AND assigned.tenant_id = $1
			WHERE fn.tenant_id = $1 AND fn.path <@ assigned.path
		)`
		args = append(args, claims.UserID)
		argIdx++
	}

	query += ` ORDER BY vr.submitted_at DESC LIMIT 50`

	rows, err := h.db.Query(c.UserContext(), query, args...)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando verificaciones")
	}
	defer rows.Close()

	var records []VerificationResponse
	for rows.Next() {
		var vr VerificationResponse
		if err := rows.Scan(&vr.ID, &vr.WONumber, &vr.WOTitle,
			&vr.SubmittedBy, &vr.VerifiedBy, &vr.Status,
			&vr.ConfidenceLevel, &vr.Notes,
			&vr.SubmittedAt, &vr.VerifiedAt); err == nil {
			records = append(records, vr)
		}
	}

	return c.JSON(fiber.Map{"records": records, "total": len(records)})
}

// ─── PATCH /verifications/:id — verify or reject ─────────────────────────

func (h *VerificationHandler) Update(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req struct {
		Status          string  `json:"status"`
		ConfidenceLevel int     `json:"confidence_level"`
		Notes           *string `json:"notes"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	validStatuses := map[string]bool{
		"verified": true, "verified_featured": true, "rejected": true, "revoked": true,
	}
	if !validStatuses[req.Status] {
		return fiber.NewError(fiber.StatusBadRequest, "Estado no válido")
	}

	// RN-VER-01: a supervisor cannot verify their own records
	result, err := h.db.Exec(c.UserContext(),
		`UPDATE verification_records
		 SET status=$1, confidence_level=$2, notes=$3,
		     verified_by=$4, verified_at=NOW()
		 WHERE id=$5 AND tenant_id=$6
		   AND submitted_by != $4`,
		req.Status, req.ConfidenceLevel, req.Notes,
		claims.UserID, id, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error actualizando verificación")
	}
	if result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusForbidden,
			"No puedes verificar tus propios registros (RN-VER-01) o registro no encontrado")
	}

	return c.JSON(fiber.Map{"message": "Verificación actualizada", "status": req.Status})
}
