package handlers

import (
	"context"
	"strconv"

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type PersonnelHandler struct {
	db *pgxpool.Pool
}

func NewPersonnelHandler(db *pgxpool.Pool) *PersonnelHandler {
	return &PersonnelHandler{db: db}
}

// ─── Helper: get a user's minimum assignment depth ──────────
// Lower depth = higher rank (plant < line < equipment)

func (h *PersonnelHandler) getUserAssignmentDepth(ctx context.Context, userID, tenantID int64) (int, error) {
	var depth int
	err := h.db.QueryRow(ctx,
		`SELECT COALESCE(MIN(nlevel(fn.path)), 999)
		 FROM node_assignments na
		 JOIN factory_nodes fn ON fn.id = na.node_id
		 WHERE na.user_id = $1 AND na.tenant_id = $2`,
		userID, tenantID,
	).Scan(&depth)
	return depth, err
}

// ─── GET /personnel — list of technicians with their workload ─────────────────

func (h *PersonnelHandler) List(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	role := c.Query("role")

	query := `
		SELECT u.id, u.full_name, u.email, u.role, u.status, u.home_node_id,
		       fn.name AS home_node_name,
		       COUNT(wo.id) FILTER (WHERE wo.status IN ('assigned','in_progress')) AS active_wos
		FROM users u
		LEFT JOIN factory_nodes fn ON fn.id = u.home_node_id
		LEFT JOIN work_orders wo ON wo.assigned_to = u.id AND wo.tenant_id = u.tenant_id
		WHERE u.tenant_id = $1`

	args := []interface{}{claims.TenantID}
	if role != "" {
		query += ` AND u.role = $2`
		args = append(args, role)
	}
	query += ` GROUP BY u.id, fn.name ORDER BY u.role, u.full_name`

	rows, err := h.db.Query(c.UserContext(), query, args...)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando personal")
	}
	defer rows.Close()

	type PersonnelEntry struct {
		ID           int64   `json:"id"`
		FullName     string  `json:"full_name"`
		Email        string  `json:"email"`
		Role         string  `json:"role"`
		Status       string  `json:"status"`
		HomeNodeID   *int64  `json:"home_node_id"`
		HomeNodeName *string `json:"home_node_name"`
		ActiveWOs    int     `json:"active_wos"`
	}

	var personnel []PersonnelEntry
	for rows.Next() {
		var p PersonnelEntry
		if err := rows.Scan(&p.ID, &p.FullName, &p.Email, &p.Role, &p.Status,
			&p.HomeNodeID, &p.HomeNodeName, &p.ActiveWOs); err == nil {
			personnel = append(personnel, p)
		}
	}

	return c.JSON(fiber.Map{"personnel": personnel, "total": len(personnel)})
}

// ─── GET /personnel/:id/competencies ─────────────────────────────────────────

func (h *PersonnelHandler) GetCompetencies(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	userID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	rows, err := h.db.Query(c.UserContext(),
		`SELECT id, name, level, is_certified, expires_at::text, notes, created_at::text
		 FROM user_competencies
		 WHERE user_id=$1 AND tenant_id=$2
		 ORDER BY name`,
		userID, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando competencias")
	}
	defer rows.Close()

	type Competency struct {
		ID          int64   `json:"id"`
		Name        string  `json:"name"`
		Level       string  `json:"level"`
		IsCertified bool    `json:"is_certified"`
		ExpiresAt   *string `json:"expires_at"`
		Notes       *string `json:"notes"`
		CreatedAt   string  `json:"created_at"`
	}

	var competencies []Competency
	for rows.Next() {
		var comp Competency
		if err := rows.Scan(&comp.ID, &comp.Name, &comp.Level, &comp.IsCertified,
			&comp.ExpiresAt, &comp.Notes, &comp.CreatedAt); err == nil {
			competencies = append(competencies, comp)
		}
	}

	return c.JSON(fiber.Map{"competencies": competencies})
}

// ─── POST /personnel/:id/competencies ────────────────────────────────────────

func (h *PersonnelHandler) AddCompetency(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	userID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req struct {
		Name        string  `json:"name"`
		Level       string  `json:"level"`
		IsCertified bool    `json:"is_certified"`
		ExpiresAt   *string `json:"expires_at"`
		Notes       *string `json:"notes"`
	}
	if err := c.BodyParser(&req); err != nil || req.Name == "" {
		return fiber.NewError(fiber.StatusBadRequest, "El nombre de la competencia es requerido")
	}
	if req.Level == "" {
		req.Level = "basic"
	}

	var newID int64
	err = h.db.QueryRow(c.UserContext(),
		`INSERT INTO user_competencies (user_id, tenant_id, name, level, is_certified, expires_at, notes)
		 VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
		userID, claims.TenantID, req.Name, req.Level, req.IsCertified,
		req.ExpiresAt, req.Notes,
	).Scan(&newID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error añadiendo competencia")
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": newID, "message": "Competencia añadida"})
}

// ─── DELETE /personnel/competencies/:id ──────────────────────────────────────

func (h *PersonnelHandler) DeleteCompetency(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	result, err := h.db.Exec(c.UserContext(),
		`DELETE FROM user_competencies WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Competencia no encontrada")
	}

	return c.JSON(fiber.Map{"message": "Competencia eliminada"})
}

// ─── GET /personnel/:id/assignments ──────────────────────────────────────────

func (h *PersonnelHandler) GetAssignments(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	userID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	rows, err := h.db.Query(c.UserContext(),
		`SELECT na.id, na.node_id, fn.name, fn.node_type, na.is_primary, na.assigned_at::text
		 FROM node_assignments na
		 JOIN factory_nodes fn ON fn.id = na.node_id
		 WHERE na.user_id=$1 AND na.tenant_id=$2
		 ORDER BY na.is_primary DESC, fn.name`,
		userID, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando asignaciones")
	}
	defer rows.Close()

	type Assignment struct {
		ID         int64  `json:"id"`
		NodeID     int64  `json:"node_id"`
		NodeName   string `json:"node_name"`
		NodeType   string `json:"node_type"`
		IsPrimary  bool   `json:"is_primary"`
		AssignedAt string `json:"assigned_at"`
	}

	var assignments []Assignment
	for rows.Next() {
		var a Assignment
		if err := rows.Scan(&a.ID, &a.NodeID, &a.NodeName, &a.NodeType,
			&a.IsPrimary, &a.AssignedAt); err == nil {
			assignments = append(assignments, a)
		}
	}

	return c.JSON(fiber.Map{"assignments": assignments})
}

// ─── POST /personnel/:id/assignments ─────────────────────────────────────────

func (h *PersonnelHandler) AddAssignment(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	userID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req struct {
		NodeID    int64 `json:"node_id"`
		IsPrimary bool  `json:"is_primary"`
	}
	if err := c.BodyParser(&req); err != nil || req.NodeID == 0 {
		return fiber.NewError(fiber.StatusBadRequest, "El nodo es requerido")
	}

	// Rank check: a supervisor can only assign when outranking the target
	if claims.Role == "supervisor" {
		myDepth, err := h.getUserAssignmentDepth(c.UserContext(), claims.UserID, claims.TenantID)
		if err != nil {
			return fiber.NewError(fiber.StatusInternalServerError, "Error verificando rango")
		}
		targetDepth, err := h.getUserAssignmentDepth(c.UserContext(), userID, claims.TenantID)
		if err != nil {
			return fiber.NewError(fiber.StatusInternalServerError, "Error verificando rango del objetivo")
		}
		// If the target already has assignments and an equal or lower depth (higher rank), block it
		if targetDepth <= myDepth && targetDepth < 999 {
			return fiber.NewError(fiber.StatusForbidden, "No tienes rango suficiente para gestionar a este usuario")
		}
	}

	var newID int64
	err = h.db.QueryRow(c.UserContext(),
		`INSERT INTO node_assignments (user_id, node_id, tenant_id, is_primary, assigned_by)
		 VALUES ($1,$2,$3,$4,$5) RETURNING id`,
		userID, req.NodeID, claims.TenantID, req.IsPrimary, claims.UserID,
	).Scan(&newID)
	if err != nil {
		return fiber.NewError(fiber.StatusConflict, "El usuario ya está asignado a ese nodo")
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": newID, "message": "Asignación creada"})
}

// ─── DELETE /factory/nodes/:id/personnel/:userId — unassign staff from a node

func (h *PersonnelHandler) RemoveFromNode(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID de nodo inválido")
	}
	userID, err := strconv.ParseInt(c.Params("userId"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID de usuario inválido")
	}

	// Rank check for supervisors
	if claims.Role == "supervisor" {
		myDepth, err := h.getUserAssignmentDepth(c.UserContext(), claims.UserID, claims.TenantID)
		if err != nil {
			return fiber.NewError(fiber.StatusInternalServerError, "Error verificando rango")
		}
		targetDepth, err := h.getUserAssignmentDepth(c.UserContext(), userID, claims.TenantID)
		if err != nil {
			return fiber.NewError(fiber.StatusInternalServerError, "Error verificando rango del objetivo")
		}
		if targetDepth <= myDepth && targetDepth < 999 {
			return fiber.NewError(fiber.StatusForbidden, "No tienes rango suficiente para desasignar a este usuario")
		}
	}

	result, err := h.db.Exec(c.UserContext(),
		`DELETE FROM node_assignments WHERE user_id=$1 AND node_id=$2 AND tenant_id=$3`,
		userID, nodeID, claims.TenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Asignación no encontrada")
	}

	return c.JSON(fiber.Map{"message": "Personal desasignado del nodo"})
}

// ─── GET /nodes/:id/personnel — staff with hierarchical inheritance through ltree ──

func (h *PersonnelHandler) GetNodePersonnel(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	// Query with inheritance: shows staff assigned to this node OR to any ancestor,
	// excluding users explicitly excluded on this node.
	// DISTINCT ON (u.id) picks the most relevant assignment (primary first, then lowest depth).
	rows, err := h.db.Query(c.UserContext(),
		`SELECT DISTINCT ON (u.id)
		    u.id, u.full_name, u.role, na.is_primary,
		    (na.node_id = $1) AS is_direct,
		    fn_assigned.name AS assigned_node_name,
		    fn_assigned.node_type AS assigned_node_type,
		    nlevel(fn_assigned.path) AS assignment_depth,
		    (SELECT COUNT(*) FROM work_orders wo
		     WHERE wo.assigned_to = u.id AND wo.tenant_id = $2
		       AND wo.status IN ('assigned','in_progress')) AS active_wos
		 FROM node_assignments na
		 JOIN users u ON u.id = na.user_id
		 JOIN factory_nodes fn_assigned ON fn_assigned.id = na.node_id
		 JOIN factory_nodes fn_target ON fn_target.id = $1
		 LEFT JOIN node_assignment_exclusions nae
		     ON nae.user_id = u.id AND nae.node_id = $1 AND nae.tenant_id = $2
		 WHERE na.tenant_id = $2
		   AND u.status = 'active'
		   AND fn_target.path <@ fn_assigned.path
		   AND nae.id IS NULL
		 ORDER BY u.id, na.is_primary DESC, nlevel(fn_assigned.path) ASC`,
		nodeID, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando personal del nodo")
	}
	defer rows.Close()

	type NodePersonnel struct {
		ID               int64  `json:"id"`
		FullName         string `json:"full_name"`
		Role             string `json:"role"`
		IsPrimary        bool   `json:"is_primary"`
		IsDirect         bool   `json:"is_direct"`
		AssignedNodeName string `json:"assigned_node_name"`
		AssignedNodeType string `json:"assigned_node_type"`
		AssignmentDepth  int    `json:"assignment_depth"`
		ActiveWOs        int    `json:"active_wos"`
	}

	var personnel []NodePersonnel
	for rows.Next() {
		var p NodePersonnel
		if err := rows.Scan(&p.ID, &p.FullName, &p.Role, &p.IsPrimary,
			&p.IsDirect, &p.AssignedNodeName, &p.AssignedNodeType,
			&p.AssignmentDepth, &p.ActiveWOs); err == nil {
			personnel = append(personnel, p)
		}
	}

	// Users excluded from this node (so they can be restored)
	type ExcludedUser struct {
		ID       int64  `json:"id"`
		FullName string `json:"full_name"`
		Role     string `json:"role"`
	}
	var excluded []ExcludedUser
	exclRows, exclErr := h.db.Query(c.UserContext(),
		`SELECT u.id, u.full_name, u.role
		 FROM node_assignment_exclusions nae
		 JOIN users u ON u.id = nae.user_id
		 WHERE nae.node_id = $1 AND nae.tenant_id = $2
		 ORDER BY u.full_name`,
		nodeID, claims.TenantID,
	)
	if exclErr == nil {
		defer exclRows.Close()
		for exclRows.Next() {
			var e ExcludedUser
			if exclRows.Scan(&e.ID, &e.FullName, &e.Role) == nil {
				excluded = append(excluded, e)
			}
		}
	}

	return c.JSON(fiber.Map{"personnel": personnel, "excluded": excluded, "total": len(personnel)})
}

// ─── POST /factory/nodes/:id/personnel/:userId/exclude — restrict access ──

func (h *PersonnelHandler) ExcludeFromNode(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID de nodo inválido")
	}
	userID, err := strconv.ParseInt(c.Params("userId"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID de usuario inválido")
	}

	// Rank check for supervisors
	if claims.Role == "supervisor" {
		myDepth, err := h.getUserAssignmentDepth(c.UserContext(), claims.UserID, claims.TenantID)
		if err != nil {
			return fiber.NewError(fiber.StatusInternalServerError, "Error verificando rango")
		}
		targetDepth, err := h.getUserAssignmentDepth(c.UserContext(), userID, claims.TenantID)
		if err != nil {
			return fiber.NewError(fiber.StatusInternalServerError, "Error verificando rango del objetivo")
		}
		if targetDepth <= myDepth && targetDepth < 999 {
			return fiber.NewError(fiber.StatusForbidden, "No tienes rango suficiente para restringir a este usuario")
		}
	}

	// Check that the user has inherited access to this node (excluding them would be pointless otherwise)
	var hasAccess bool
	h.db.QueryRow(c.UserContext(),
		`SELECT EXISTS(
		    SELECT 1 FROM node_assignments na
		    JOIN factory_nodes fn_assigned ON fn_assigned.id = na.node_id
		    JOIN factory_nodes fn_target ON fn_target.id = $1
		    WHERE na.user_id = $2 AND na.tenant_id = $3
		      AND fn_target.path <@ fn_assigned.path
		 )`,
		nodeID, userID, claims.TenantID,
	).Scan(&hasAccess)
	if !hasAccess {
		return fiber.NewError(fiber.StatusBadRequest, "El usuario no tiene acceso heredado a este nodo")
	}

	var newID int64
	err = h.db.QueryRow(c.UserContext(),
		`INSERT INTO node_assignment_exclusions (tenant_id, user_id, node_id, excluded_by)
		 VALUES ($1, $2, $3, $4) RETURNING id`,
		claims.TenantID, userID, nodeID, claims.UserID,
	).Scan(&newID)
	if err != nil {
		return fiber.NewError(fiber.StatusConflict, "El usuario ya está excluido de este nodo")
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": newID, "message": "Acceso restringido al nodo"})
}

// ─── DELETE /factory/nodes/:id/personnel/:userId/exclude — restore access ─

func (h *PersonnelHandler) RestoreToNode(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID de nodo inválido")
	}
	userID, err := strconv.ParseInt(c.Params("userId"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID de usuario inválido")
	}

	// Rank check for supervisors
	if claims.Role == "supervisor" {
		myDepth, err := h.getUserAssignmentDepth(c.UserContext(), claims.UserID, claims.TenantID)
		if err != nil {
			return fiber.NewError(fiber.StatusInternalServerError, "Error verificando rango")
		}
		targetDepth, err := h.getUserAssignmentDepth(c.UserContext(), userID, claims.TenantID)
		if err != nil {
			return fiber.NewError(fiber.StatusInternalServerError, "Error verificando rango del objetivo")
		}
		if targetDepth <= myDepth && targetDepth < 999 {
			return fiber.NewError(fiber.StatusForbidden, "No tienes rango suficiente para restaurar acceso de este usuario")
		}
	}

	result, err := h.db.Exec(c.UserContext(),
		`DELETE FROM node_assignment_exclusions
		 WHERE user_id=$1 AND node_id=$2 AND tenant_id=$3`,
		userID, nodeID, claims.TenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "No se encontró restricción para este usuario en este nodo")
	}

	return c.JSON(fiber.Map{"message": "Acceso restaurado al nodo"})
}
