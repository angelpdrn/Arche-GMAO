package handlers

import (

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type NodeTypesHandler struct {
	db *pgxpool.Pool
}

func NewNodeTypesHandler(db *pgxpool.Pool) *NodeTypesHandler {
	return &NodeTypesHandler{db: db}
}

type NodeTypeResponse struct {
	ID        int64   `json:"id"`
	TenantID  *int64  `json:"tenant_id"`
	TypeKey   string  `json:"type_key"`
	Label     string  `json:"label"`
	Icon      *string `json:"icon"`
	Color     *string `json:"color"`
	SortOrder int     `json:"sort_order"`
	IsSystem  bool    `json:"is_system"`
}

func (h *NodeTypesHandler) List(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	rows, err := h.db.Query(c.UserContext(),
		`SELECT id, tenant_id, type_key, label, icon, color, sort_order, is_system
		 FROM node_type_definitions
		 WHERE tenant_id IS NULL OR tenant_id = $1
		 ORDER BY sort_order, label`,
		claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando tipos de nodo")
	}
	defer rows.Close()

	var types []NodeTypeResponse
	for rows.Next() {
		var t NodeTypeResponse
		if err := rows.Scan(&t.ID, &t.TenantID, &t.TypeKey, &t.Label,
			&t.Icon, &t.Color, &t.SortOrder, &t.IsSystem); err == nil {
			types = append(types, t)
		}
	}

	return c.JSON(fiber.Map{"node_types": types})
}
