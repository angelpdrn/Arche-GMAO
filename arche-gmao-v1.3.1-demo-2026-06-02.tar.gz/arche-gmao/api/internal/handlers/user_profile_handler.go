package handlers

import (
	"fmt"
	"strconv"

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/redis/go-redis/v9"
	"golang.org/x/crypto/bcrypt"
)

type UserProfileHandler struct {
	db  *pgxpool.Pool
	rdb *redis.Client
}

func NewUserProfileHandler(db *pgxpool.Pool, rdb ...*redis.Client) *UserProfileHandler {
	h := &UserProfileHandler{db: db}
	if len(rdb) > 0 {
		h.rdb = rdb[0]
	}
	return h
}

// ─── GET /users/:id/profile — full profile with statistics ───────────────

func (h *UserProfileHandler) GetProfile(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	// Basic user info
	type UserInfo struct {
		ID           int64   `json:"id"`
		FullName     string  `json:"full_name"`
		Email        string  `json:"email"`
		Role         string  `json:"role"`
		Status       string  `json:"status"`
		Phone        *string `json:"phone"`
		Department   *string `json:"department"`
		Position     *string `json:"position"`
		Bio          *string `json:"bio"`
		HireDate     *string `json:"hire_date"`
		CertificationsRaw string `json:"certifications"`
		AvatarColor  string  `json:"avatar_color"`
		CreatedAt    string  `json:"created_at"`
	}

	var u UserInfo
	err = h.db.QueryRow(c.UserContext(),
		`SELECT id, full_name, email, role, status,
		        phone, department, position, bio, hire_date::text,
		        COALESCE(certifications::text,'[]'),
		        COALESCE(avatar_color,'#0f3460'),
		        created_at::text
		 FROM users WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	).Scan(
		&u.ID, &u.FullName, &u.Email, &u.Role, &u.Status,
		&u.Phone, &u.Department, &u.Position, &u.Bio, &u.HireDate,
		&u.CertificationsRaw, &u.AvatarColor, &u.CreatedAt,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Usuario no encontrado")
	}

	// ─── WO statistics ──────────────────────────────────────────────────
	type WOStats struct {
		Assigned    int     `json:"assigned"`
		InProgress  int     `json:"in_progress"`
		Paused      int     `json:"paused"`
		Completed   int     `json:"completed"`
		Total       int     `json:"total"`
		AvgHours    float64 `json:"avg_hours"`
		OnTimeRate  float64 `json:"on_time_rate"`
	}
	var woStats WOStats
	h.db.QueryRow(c.UserContext(),
		`SELECT
		    COUNT(*) FILTER (WHERE status IN ('assigned','approved')) AS assigned,
		    COUNT(*) FILTER (WHERE status='in_progress') AS in_progress,
		    COUNT(*) FILTER (WHERE status='paused') AS paused,
		    COUNT(*) FILTER (WHERE status IN ('completed','verified','closed')) AS completed,
		    COUNT(*) AS total,
		    COALESCE(AVG(actual_hours) FILTER (WHERE actual_hours IS NOT NULL AND actual_hours > 0), 0) AS avg_hours,
		    CASE WHEN COUNT(*) FILTER (WHERE status IN ('completed','verified','closed')) > 0
		         THEN ROUND(100.0 * COUNT(*) FILTER (
		              WHERE status IN ('completed','verified','closed')
		              AND (planned_end IS NULL OR completed_at <= planned_end)
		         ) / NULLIF(COUNT(*) FILTER (WHERE status IN ('completed','verified','closed')),0), 1)
		         ELSE 0 END AS on_time_rate
		 FROM work_orders
		 WHERE tenant_id=$1 AND assigned_to=$2`,
		claims.TenantID, id,
	).Scan(&woStats.Assigned, &woStats.InProgress, &woStats.Paused,
		&woStats.Completed, &woStats.Total, &woStats.AvgHours, &woStats.OnTimeRate)

	// ─── Breakdown by WO type ─────────────────────────────────────────
	typeRows, _ := h.db.Query(c.UserContext(),
		`SELECT wo_type, COUNT(*) FROM work_orders
		 WHERE tenant_id=$1 AND assigned_to=$2
		 GROUP BY wo_type ORDER BY COUNT(*) DESC`,
		claims.TenantID, id,
	)
	type TypeDist struct {
		Type  string `json:"type"`
		Count int    `json:"count"`
	}
	var typeDistrib []TypeDist
	if typeRows != nil {
		defer typeRows.Close()
		for typeRows.Next() {
			var td TypeDist
			if typeRows.Scan(&td.Type, &td.Count) == nil {
				typeDistrib = append(typeDistrib, td)
			}
		}
	}

	// ─── Latest WOs ─────────────────────────────────────────────────────────
	recentRows, _ := h.db.Query(c.UserContext(),
		`SELECT wo.wo_number, wo.title, wo.status, wo.priority,
		        fn.name AS node_name, wo.completed_at::text
		 FROM work_orders wo
		 JOIN factory_nodes fn ON fn.id=wo.node_id
		 WHERE wo.tenant_id=$1 AND wo.assigned_to=$2
		 ORDER BY wo.created_at DESC LIMIT 8`,
		claims.TenantID, id,
	)
	type RecentWO struct {
		WONumber    string  `json:"wo_number"`
		Title       string  `json:"title"`
		Status      string  `json:"status"`
		Priority    string  `json:"priority"`
		NodeName    string  `json:"node_name"`
		CompletedAt *string `json:"completed_at"`
	}
	var recentWOs []RecentWO
	if recentRows != nil {
		defer recentRows.Close()
		for recentRows.Next() {
			var wo RecentWO
			if recentRows.Scan(&wo.WONumber, &wo.Title, &wo.Status, &wo.Priority,
				&wo.NodeName, &wo.CompletedAt) == nil {
				recentWOs = append(recentWOs, wo)
			}
		}
	}

	// ─── Scores ─────────────────────────────────────────────────────────
	type ScoreStats struct {
		TotalScores int     `json:"total_scores"`
		AvgScore    float64 `json:"avg_score"`
		LastScore   *int    `json:"last_score"`
	}
	var scoreStats ScoreStats
	h.db.QueryRow(c.UserContext(),
		`SELECT COUNT(*), COALESCE(AVG(score),0),
		        (SELECT score FROM wo_scores WHERE user_id=$2 ORDER BY created_at DESC LIMIT 1)
		 FROM wo_scores WHERE tenant_id=$1 AND user_id=$2`,
		claims.TenantID, id,
	).Scan(&scoreStats.TotalScores, &scoreStats.AvgScore, &scoreStats.LastScore)

	// ─── Tags / skills ────────────────────────────────────────────────────
	tagRows, _ := h.db.Query(c.UserContext(),
		`SELECT tag FROM user_tags WHERE user_id=$1 AND tenant_id=$2 ORDER BY tag`,
		id, claims.TenantID,
	)
	var tags []string
	if tagRows != nil {
		defer tagRows.Close()
		for tagRows.Next() {
			var tag string
			if tagRows.Scan(&tag) == nil { tags = append(tags, tag) }
		}
	}

	// ─── Monthly activity (last 6 months) ──────────────────────────────────
	activityRows, _ := h.db.Query(c.UserContext(),
		`SELECT TO_CHAR(DATE_TRUNC('month', created_at), 'Mon YY') AS month,
		        COUNT(*) AS count
		 FROM work_orders
		 WHERE tenant_id=$1 AND assigned_to=$2
		   AND created_at > NOW() - INTERVAL '6 months'
		 GROUP BY DATE_TRUNC('month', created_at)
		 ORDER BY DATE_TRUNC('month', created_at)`,
		claims.TenantID, id,
	)
	type ActivityMonth struct {
		Month string `json:"month"`
		Count int    `json:"count"`
	}
	var activity []ActivityMonth
	if activityRows != nil {
		defer activityRows.Close()
		for activityRows.Next() {
			var a ActivityMonth
			if activityRows.Scan(&a.Month, &a.Count) == nil {
				activity = append(activity, a)
			}
		}
	}

	// ─── Compute the rank ────────────────────────────────────────────────────────
	rank := calculateRank(woStats.Completed, scoreStats.AvgScore)

	return c.JSON(fiber.Map{
		"user":           u,
		"wo_stats":       woStats,
		"type_distrib":   typeDistrib,
		"recent_wos":     recentWOs,
		"score_stats":    scoreStats,
		"tags":           tags,
		"activity":       activity,
		"rank":           rank,
	})
}

// ─── PUT /users/:id/profile — update the profile ───────────────────────────────

func (h *UserProfileHandler) UpdateProfile(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	// Only an admin can edit any profile; a user can edit their own
	if claims.Role != "admin" && claims.UserID != id {
		return fiber.NewError(fiber.StatusForbidden, "Sin permiso para editar este perfil")
	}

	var req struct {
		Phone          *string `json:"phone"`
		Department     *string `json:"department"`
		Position       *string `json:"position"`
		Bio            *string `json:"bio"`
		HireDate       *string `json:"hire_date"`
		Certifications *string `json:"certifications"`
		AvatarColor    *string `json:"avatar_color"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	_, err = h.db.Exec(c.UserContext(),
		`UPDATE users SET
		    phone=COALESCE($1,phone),
		    department=COALESCE($2,department),
		    position=COALESCE($3,position),
		    bio=COALESCE($4,bio),
		    hire_date=COALESCE($5::date,hire_date),
		    certifications=COALESCE($6::jsonb,certifications),
		    avatar_color=COALESCE($7,avatar_color)
		 WHERE id=$8 AND tenant_id=$9`,
		req.Phone, req.Department, req.Position, req.Bio, req.HireDate,
		req.Certifications, req.AvatarColor, id, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error actualizando perfil")
	}

	return c.JSON(fiber.Map{"message": "Perfil actualizado"})
}

// ─── PATCH /users/:id/change-password — change your own password ─────────────

func (h *UserProfileHandler) ChangeOwnPassword(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	// Only the user themselves can change their password
	if id != claims.UserID {
		return fiber.NewError(fiber.StatusForbidden, "Solo puedes cambiar tu propia contraseña")
	}

	var req struct {
		CurrentPassword string `json:"current_password"`
		NewPassword     string `json:"new_password"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	if req.CurrentPassword == "" {
		return fiber.NewError(fiber.StatusBadRequest, "La contraseña actual es requerida")
	}
	if msg := validatePassword(req.NewPassword); msg != "" {
		return fiber.NewError(fiber.StatusBadRequest, msg)
	}
	if req.CurrentPassword == req.NewPassword {
		return fiber.NewError(fiber.StatusBadRequest, "La nueva contraseña debe ser diferente a la actual")
	}

	// Check the current password
	var currentHash string
	err = h.db.QueryRow(c.UserContext(),
		`SELECT password_hash FROM users WHERE id=$1 AND tenant_id=$2`,
		claims.UserID, claims.TenantID,
	).Scan(&currentHash)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Usuario no encontrado")
	}

	if err := bcrypt.CompareHashAndPassword([]byte(currentHash), []byte(req.CurrentPassword)); err != nil {
		return fiber.NewError(fiber.StatusUnauthorized, "La contraseña actual es incorrecta")
	}

	// Store the new password
	newHash, hashErr := bcrypt.GenerateFromPassword([]byte(req.NewPassword), 12)
	if hashErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error cifrando contraseña")
	}
	_, err = h.db.Exec(c.UserContext(),
		`UPDATE users SET password_hash=$1 WHERE id=$2 AND tenant_id=$3`,
		string(newHash), claims.UserID, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error actualizando contraseña")
	}

	// Invalidate refresh tokens (both prefixes) and every issued access token
	if h.rdb != nil {
		h.rdb.Del(c.UserContext(), fmt.Sprintf("refresh:%d", claims.UserID))
		h.rdb.Del(c.UserContext(), fmt.Sprintf("sa_refresh:%d", claims.UserID))
		RevokeUserSessions(h.rdb, c.UserContext(), claims.UserID, claims.IsSuperadmin)
	}

	return c.JSON(fiber.Map{"message": "Contraseña actualizada correctamente"})
}

// ─── Compute the rank from completed WOs and the average score ───────────────

func calculateRank(completed int, avgScore float64) fiber.Map {
	type Rank struct {
		Name  string
		Icon  string
		Color string
		Min   int
	}

	ranks := []Rank{
		{"Aprendiz",   "◌",  "#888888", 0},
		{"Técnico",    "◎",  "#3B82F6", 5},
		{"Oficial",    "◉",  "#27AE60", 20},
		{"Senior",     "◈",  "#F39C12", 50},
		{"Experto",    "◆",  "#8B5CF6", 100},
		{"Maestro",    "★",  "#E94560", 200},
	}

	current := ranks[0]
	nextMin := 5
	for i, r := range ranks {
		if completed >= r.Min {
			current = r
			if i+1 < len(ranks) {
				nextMin = ranks[i+1].Min
			} else {
				nextMin = completed
			}
		}
	}

	progress := 0
	if nextMin > current.Min {
		progress = int(float64(completed-current.Min) / float64(nextMin-current.Min) * 100)
		if progress > 100 { progress = 100 }
	} else {
		progress = 100
	}

	// Adjustment for the average score
	bonus := ""
	if avgScore >= 4.5 { bonus = "⭐ Alto rendimiento" }

	return fiber.Map{
		"name":      current.Name,
		"icon":      current.Icon,
		"color":     current.Color,
		"completed": completed,
		"next_min":  nextMin,
		"progress":  progress,
		"bonus":     bonus,
	}
}

func sanitizeForFile(name string) string {
	b := []byte(name)
	for i, c := range b {
		if (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-' {
			continue
		}
		b[i] = '_'
	}
	return string(b)
}
