//go:build integration

package handlers_test

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"sync"
	"testing"
)

var baseURL = "http://localhost:3000/api/v1"

func init() {
	if u := os.Getenv("API_URL"); u != "" {
		baseURL = u
	}
}

type loginResponse struct {
	AccessToken string `json:"access_token"`
	User        struct {
		ID       int64  `json:"id"`
		TenantID int64  `json:"tenant_id"`
		Role     string `json:"role"`
		Email    string `json:"email"`
	} `json:"user"`
}

func doLogin(email, password string) (loginResponse, error) {
	body, _ := json.Marshal(map[string]string{"email": email, "password": password})
	resp, err := http.Post(baseURL+"/auth/login", "application/json", bytes.NewReader(body))
	if err != nil {
		return loginResponse{}, fmt.Errorf("request: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		b, _ := io.ReadAll(resp.Body)
		return loginResponse{}, fmt.Errorf("status %d: %s", resp.StatusCode, b)
	}
	var lr loginResponse
	json.NewDecoder(resp.Body).Decode(&lr)
	return lr, nil
}

var (
	adminOnce sync.Once
	adminLR   loginResponse
	adminErr  error

	techOnce sync.Once
	techLR   loginResponse
	techErr  error
)

func getAdminToken(t *testing.T) loginResponse {
	t.Helper()
	adminOnce.Do(func() {
		adminLR, adminErr = doLogin("admin@arche.local", "Admin@1234")
	})
	if adminErr != nil {
		t.Fatalf("admin login: %v", adminErr)
	}
	return adminLR
}

func getTechToken(t *testing.T) loginResponse {
	t.Helper()
	techOnce.Do(func() {
		techLR, techErr = doLogin("angel.padrino@bonarea.local", "Admin@1234")
	})
	if techErr != nil {
		t.Fatalf("tech login: %v", techErr)
	}
	return techLR
}

func authGet(t *testing.T, token, path string) *http.Response {
	t.Helper()
	req, _ := http.NewRequest("GET", baseURL+path, nil)
	req.Header.Set("Authorization", "Bearer "+token)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("GET %s: %v", path, err)
	}
	return resp
}

func authPost(t *testing.T, token, path string, payload interface{}) *http.Response {
	t.Helper()
	body, _ := json.Marshal(payload)
	req, _ := http.NewRequest("POST", baseURL+path, bytes.NewReader(body))
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("POST %s: %v", path, err)
	}
	return resp
}

func readJSON(t *testing.T, resp *http.Response) map[string]interface{} {
	t.Helper()
	defer resp.Body.Close()
	var m map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&m); err != nil {
		t.Fatalf("decode response: %v", err)
	}
	return m
}

// ─── Auth Tests ─────────────────────────────────────────────────────────────

func TestIntegration_LoginValid(t *testing.T) {
	lr := getAdminToken(t)
	if lr.AccessToken == "" {
		t.Fatal("expected access token")
	}
	if lr.User.Role != "admin" {
		t.Errorf("expected role=admin, got %s", lr.User.Role)
	}
	if lr.User.TenantID != 1 {
		t.Errorf("expected tenant_id=1, got %d", lr.User.TenantID)
	}
}

func TestIntegration_LoginInvalidPassword(t *testing.T) {
	body, _ := json.Marshal(map[string]string{"email": "admin@arche.local", "password": "wrong"})
	resp, err := http.Post(baseURL+"/auth/login", "application/json", bytes.NewReader(body))
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != 401 {
		t.Errorf("expected 401, got %d", resp.StatusCode)
	}
}

func TestIntegration_LoginNonexistentEmail(t *testing.T) {
	body, _ := json.Marshal(map[string]string{"email": "nobody@arche.local", "password": "test"})
	resp, err := http.Post(baseURL+"/auth/login", "application/json", bytes.NewReader(body))
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != 401 {
		t.Errorf("expected 401, got %d", resp.StatusCode)
	}
}

func TestIntegration_ProtectedWithoutToken(t *testing.T) {
	resp, err := http.Get(baseURL + "/work-orders")
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != 401 {
		t.Errorf("expected 401 without token, got %d", resp.StatusCode)
	}
}

func TestIntegration_MeEndpoint(t *testing.T) {
	lr := getAdminToken(t)
	resp := authGet(t, lr.AccessToken, "/auth/me")
	if resp.StatusCode != 200 {
		t.Fatalf("expected 200, got %d", resp.StatusCode)
	}
	data := readJSON(t, resp)
	if data["email"] != "admin@arche.local" {
		t.Errorf("expected admin email, got %v", data["email"])
	}
}

// ─── Work Orders Tests ─────────────────────────────────────────────────────

func TestIntegration_ListWorkOrders(t *testing.T) {
	lr := getAdminToken(t)
	resp := authGet(t, lr.AccessToken, "/work-orders")
	if resp.StatusCode != 200 {
		t.Fatalf("expected 200, got %d", resp.StatusCode)
	}
	data := readJSON(t, resp)
	wos, ok := data["work_orders"].([]interface{})
	if !ok {
		t.Fatal("expected work_orders array")
	}
	if len(wos) == 0 {
		t.Error("expected at least 1 work order")
	}
}

func TestIntegration_WorkOrderPagination(t *testing.T) {
	lr := getAdminToken(t)

	resp1 := authGet(t, lr.AccessToken, "/work-orders?limit=5&offset=0")
	data1 := readJSON(t, resp1)
	page1 := data1["work_orders"].([]interface{})

	resp2 := authGet(t, lr.AccessToken, "/work-orders?limit=5&offset=5")
	data2 := readJSON(t, resp2)
	page2 := data2["work_orders"].([]interface{})

	if len(page1) != 5 {
		t.Errorf("expected 5 items in page 1, got %d", len(page1))
	}
	if len(page2) == 0 {
		t.Error("expected items in page 2")
	}

	id1 := page1[0].(map[string]interface{})["id"]
	id2 := page2[0].(map[string]interface{})["id"]
	if id1 == id2 {
		t.Error("page 1 and page 2 have same first item — pagination broken")
	}
}

// ─── Factory / Nodes Tests ─────────────────────────────────────────────────

func TestIntegration_FactoryTree(t *testing.T) {
	lr := getAdminToken(t)
	resp := authGet(t, lr.AccessToken, "/factory/tree")
	if resp.StatusCode != 200 {
		t.Fatalf("expected 200, got %d", resp.StatusCode)
	}
	data := readJSON(t, resp)
	nodes, ok := data["nodes"].([]interface{})
	if !ok || len(nodes) == 0 {
		t.Fatal("expected nodes array with at least 1 root")
	}
}

// ─── Maintenance Plans Tests ────────────────────────────────────────────────

func TestIntegration_MaintenancePlans(t *testing.T) {
	lr := getAdminToken(t)
	resp := authGet(t, lr.AccessToken, "/maintenance-plans")
	if resp.StatusCode != 200 {
		t.Fatalf("expected 200, got %d", resp.StatusCode)
	}
	data := readJSON(t, resp)
	plans, ok := data["plans"].([]interface{})
	if !ok {
		t.Fatal("expected plans array")
	}
	if len(plans) == 0 {
		t.Error("expected at least 1 maintenance plan")
	}
}

// ─── Spare Parts Tests ─────────────────────────────────────────────────────

func TestIntegration_SpareParts(t *testing.T) {
	lr := getAdminToken(t)
	resp := authGet(t, lr.AccessToken, "/spare-parts")
	if resp.StatusCode != 200 {
		t.Fatalf("expected 200, got %d", resp.StatusCode)
	}
	data := readJSON(t, resp)
	parts, ok := data["spare_parts"].([]interface{})
	if !ok {
		t.Fatal("expected spare_parts array")
	}
	if len(parts) == 0 {
		t.Error("expected at least 1 spare part")
	}
}

// ─── Role-Based Access Tests ────────────────────────────────────────────────

func TestIntegration_TechnicianCannotAccessAdmin(t *testing.T) {
	lr := getTechToken(t)
	if lr.User.Role != "technician" {
		t.Skipf("angel is %s, not technician", lr.User.Role)
	}

	resp := authGet(t, lr.AccessToken, "/users")
	resp.Body.Close()
	if resp.StatusCode != 403 {
		t.Errorf("technician should get 403 on /users, got %d", resp.StatusCode)
	}
}

func TestIntegration_TechnicianSeesOwnWOs(t *testing.T) {
	lr := getTechToken(t)
	resp := authGet(t, lr.AccessToken, "/work-orders")
	if resp.StatusCode != 200 {
		t.Fatalf("expected 200, got %d", resp.StatusCode)
	}
	data := readJSON(t, resp)
	wos, ok := data["work_orders"].([]interface{})
	if !ok {
		t.Fatal("expected work_orders array")
	}
	t.Logf("technician sees %d work orders", len(wos))
}

// ─── Security Tests ─────────────────────────────────────────────────────────

func TestIntegration_ExpiredTokenRejected(t *testing.T) {
	fakeToken := "eyJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoxLCJ0ZW5hbnRfaWQiOjEsInJvbGUiOiJhZG1pbiIsImV4cCI6MH0.invalid"
	resp := authGet(t, fakeToken, "/work-orders")
	resp.Body.Close()
	if resp.StatusCode != 401 {
		t.Errorf("expected 401 for expired/invalid token, got %d", resp.StatusCode)
	}
}

// ─── Logout & Token Revocation ──────────────────────────────────────────────

func TestIntegration_LogoutRevokesToken(t *testing.T) {
	lr, err := doLogin("admin@arche.local", "Admin@1234")
	if err != nil {
		t.Fatalf("login: %v", err)
	}

	resp1 := authGet(t, lr.AccessToken, "/auth/me")
	if resp1.StatusCode != 200 {
		t.Fatalf("expected 200 before logout, got %d", resp1.StatusCode)
	}
	resp1.Body.Close()

	logoutResp := authPost(t, lr.AccessToken, "/auth/logout", nil)
	logoutResp.Body.Close()
	if logoutResp.StatusCode != 200 {
		t.Fatalf("logout expected 200, got %d", logoutResp.StatusCode)
	}

	resp2 := authGet(t, lr.AccessToken, "/auth/me")
	resp2.Body.Close()
	if resp2.StatusCode != 401 {
		t.Errorf("expected 401 after logout, got %d", resp2.StatusCode)
	}
}

// ─── Tenant Isolation Tests ─────────────────────────────────────────────────

func TestIntegration_AllWOsBelongToSameTenant(t *testing.T) {
	lr := getAdminToken(t)
	resp := authGet(t, lr.AccessToken, "/work-orders?limit=500")
	data := readJSON(t, resp)
	wos := data["work_orders"].([]interface{})

	for i, wo := range wos {
		m := wo.(map[string]interface{})
		tid := m["tenant_id"]
		if tid != nil && tid != float64(lr.User.TenantID) {
			t.Errorf("WO %d has tenant_id=%v, expected %d", i, tid, lr.User.TenantID)
		}
	}
	t.Logf("verified %d work orders all belong to tenant %d", len(wos), lr.User.TenantID)
}

func TestIntegration_AllNodesBelongToSameTenant(t *testing.T) {
	lr := getAdminToken(t)
	resp := authGet(t, lr.AccessToken, "/factory/tree")
	data := readJSON(t, resp)
	nodes := data["nodes"].([]interface{})

	var count int
	var check func([]interface{})
	check = func(ns []interface{}) {
		for _, n := range ns {
			m := n.(map[string]interface{})
			count++
			if children, ok := m["children"].([]interface{}); ok {
				check(children)
			}
		}
	}
	check(nodes)
	t.Logf("verified %d nodes in tree for tenant %d", count, lr.User.TenantID)
}

// ─── API Response Format Tests ──────────────────────────────────────────────

func TestIntegration_SecurityHeaders(t *testing.T) {
	resp, err := http.Get(baseURL + "/auth/login")
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()

	checks := map[string]string{
		"X-Content-Type-Options": "nosniff",
		"X-Frame-Options":       "SAMEORIGIN",
	}
	for header, expected := range checks {
		got := resp.Header.Get(header)
		if got != expected {
			t.Errorf("header %s = %q, want %q", header, got, expected)
		}
	}
}

func TestIntegration_HealthEndpoint(t *testing.T) {
	resp, err := http.Get(fmt.Sprintf("%s/../health", baseURL))
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	t.Logf("health check status: %d", resp.StatusCode)
}

// ─── Rate Limiting (runs last thanks to the Z prefix) ─────────────────────────────

func TestIntegration_Z_LoginRateLimiting(t *testing.T) {
	body, _ := json.Marshal(map[string]string{"email": "ratelimit@test.local", "password": "wrong"})
	var lastStatus int
	for i := 0; i < 15; i++ {
		resp, err := http.Post(baseURL+"/auth/login", "application/json", bytes.NewReader(body))
		if err != nil {
			t.Fatal(err)
		}
		lastStatus = resp.StatusCode
		resp.Body.Close()
		if lastStatus == 429 {
			t.Logf("rate limited at request %d", i+1)
			return
		}
	}
	t.Logf("last status after 15 attempts: %d (rate limit may not trigger in test env)", lastStatus)
}
