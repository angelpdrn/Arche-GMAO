package handlers

import (
	"context"
	"encoding/json"
	"log"
	"net/http"

	webpush "github.com/SherClockHolmes/webpush-go"
	"github.com/jackc/pgx/v5/pgxpool"
)

// globalPS is the PushService shared by every handler.
var globalPS *PushService

// SetGlobalPushService sets the global PushService used by Notify/NotifyRole.
func SetGlobalPushService(ps *PushService) { globalPS = ps }

// GetGlobalPushService returns the global PushService.
func GetGlobalPushService() *PushService { return globalPS }

// PushService sends real push notifications over the Web Push Protocol.
type PushService struct {
	db         *pgxpool.Pool
	vapidPub   string
	vapidPriv  string
	vapidEmail string
}

// NewPushService creates the service. If the keys are empty, no push is sent.
func NewPushService(db *pgxpool.Pool, vapidPub, vapidPriv, vapidEmail string) *PushService {
	return &PushService{
		db:         db,
		vapidPub:   vapidPub,
		vapidPriv:  vapidPriv,
		vapidEmail: vapidEmail,
	}
}

// Enabled reports whether the service has VAPID keys configured.
func (ps *PushService) Enabled() bool {
	return ps.vapidPub != "" && ps.vapidPriv != ""
}

// PushPayload is the JSON the Service Worker receives.
type PushPayload struct {
	Title   string `json:"title"`
	Body    string `json:"body"`
	URL     string `json:"url,omitempty"`
	Tag     string `json:"tag,omitempty"`
	Urgent  bool   `json:"urgent,omitempty"`
}

// SendToUser sends a push to every active subscription of a user.
func (ps *PushService) SendToUser(tenantID, userID int64, payload PushPayload) {
	if !ps.Enabled() {
		return
	}

	rows, err := ps.db.Query(context.Background(),
		`SELECT endpoint, p256dh, auth FROM push_subscriptions
		 WHERE tenant_id=$1 AND user_id=$2`,
		tenantID, userID,
	)
	if err != nil {
		log.Printf("[PUSH] Error consultando suscripciones: %v", err)
		return
	}
	defer rows.Close()

	data, _ := json.Marshal(payload)

	for rows.Next() {
		var endpoint, p256dh, auth string
		if rows.Scan(&endpoint, &p256dh, &auth) != nil {
			continue
		}
		go ps.sendOne(tenantID, endpoint, p256dh, auth, data)
	}
}

// SendToUsers sends a push to a list of user IDs.
func (ps *PushService) SendToUsers(tenantID int64, userIDs []int64, payload PushPayload) {
	for _, uid := range userIDs {
		ps.SendToUser(tenantID, uid, payload)
	}
}

// SendToRole sends a push to every active user with a role in the tenant.
func (ps *PushService) SendToRole(tenantID int64, role string, payload PushPayload) {
	if !ps.Enabled() {
		return
	}

	rows, err := ps.db.Query(context.Background(),
		`SELECT ps.endpoint, ps.p256dh, ps.auth
		 FROM push_subscriptions ps
		 JOIN users u ON u.id = ps.user_id AND u.tenant_id = ps.tenant_id
		 WHERE ps.tenant_id=$1 AND u.role=$2 AND u.status='active'`,
		tenantID, role,
	)
	if err != nil {
		log.Printf("[PUSH] Error consultando suscripciones por rol: %v", err)
		return
	}
	defer rows.Close()

	data, _ := json.Marshal(payload)

	for rows.Next() {
		var endpoint, p256dh, auth string
		if rows.Scan(&endpoint, &p256dh, &auth) != nil {
			continue
		}
		go ps.sendOne(tenantID, endpoint, p256dh, auth, data)
	}
}

// sendOne sends a push message to a single endpoint.
// On a 410 (Gone) it removes the dead subscription.
func (ps *PushService) sendOne(tenantID int64, endpoint, p256dh, auth string, data []byte) {
	sub := &webpush.Subscription{
		Endpoint: endpoint,
		Keys: webpush.Keys{
			P256dh: p256dh,
			Auth:   auth,
		},
	}

	resp, err := webpush.SendNotification(data, sub, &webpush.Options{
		Subscriber:      ps.vapidEmail,
		VAPIDPublicKey:  ps.vapidPub,
		VAPIDPrivateKey: ps.vapidPriv,
		TTL:             86400,
		Urgency:         webpush.UrgencyHigh,
	})
	if err != nil {
		log.Printf("[PUSH] Error enviando a %s: %v", endpoint[:40], err)
		return
	}
	defer resp.Body.Close()

	// 410 Gone or 404 — expired subscription, remove it
	if resp.StatusCode == http.StatusGone || resp.StatusCode == http.StatusNotFound {
		ps.db.Exec(context.Background(),
			`DELETE FROM push_subscriptions WHERE endpoint=$1 AND tenant_id=$2`,
			endpoint, tenantID,
		)
		log.Printf("[PUSH] Suscripción expirada eliminada: %s", endpoint[:40])
	}
}

// Notify creates an in-app notification in the DB and sends a push to the device.
// It is the main entry point for any handler that wants to notify.
func Notify(db *pgxpool.Pool, ps *PushService, tenantID, userID int64, notifType, title, body string, link *string) {
	// 1. Store in-app
	CreateNotification(db, tenantID, userID, notifType, title, body, link)

	// 2. Send push
	url := "/dashboard"
	if link != nil {
		url = *link
	}
	ps.SendToUser(tenantID, userID, PushPayload{
		Title: title,
		Body:  body,
		URL:   url,
		Tag:   notifType,
	})
}

// NotifyRole creates an in-app notification + push for every user with a role.
func NotifyRole(db *pgxpool.Pool, ps *PushService, tenantID int64, role, notifType, title, body string, link *string) {
	// 1. In-app for each user with the role
	NotifyUsersWithRole(db, tenantID, role, notifType, title, body, link)

	// 2. Push to all of them
	url := "/dashboard"
	if link != nil {
		url = *link
	}
	ps.SendToRole(tenantID, role, PushPayload{
		Title: title,
		Body:  body,
		URL:   url,
		Tag:   notifType,
	})
}
