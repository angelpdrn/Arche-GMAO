package handlers

import (
	"context"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"arche-gmao/api/internal/ai"
	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type LibraryHandler struct {
	db *pgxpool.Pool
}

func NewLibraryHandler(db *pgxpool.Pool) *LibraryHandler {
	return &LibraryHandler{db: db}
}

// ─── GET /library/nodes/:id — attachments of a node ───────────────────

func (h *LibraryHandler) ListByNode(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	category := c.Query("category")

	// Technician reports are only visible to admin/supervisor
	if category == "technician_report" && claims.Role != "admin" && claims.Role != "supervisor" {
		return c.JSON([]interface{}{})
	}

	query := `
		SELECT a.id, a.original_name, a.mime_type, a.file_size,
		       a.category, a.description, a.version,
		       a.tags, u.full_name, a.created_at::text
		FROM attachments a
		LEFT JOIN users u ON u.id = a.uploaded_by
		WHERE a.node_id=$1 AND a.tenant_id=$2`

	args := []interface{}{nodeID, claims.TenantID}
	if category != "" {
		query += ` AND a.category = $3`
		args = append(args, category)
	} else if claims.Role != "admin" && claims.Role != "supervisor" {
		query += ` AND (a.category IS NULL OR a.category != 'technician_report')`
	}
	query += ` ORDER BY a.created_at DESC`

	rows, err := h.db.Query(c.UserContext(), query, args...)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando biblioteca")
	}
	defer rows.Close()

	type AttachmentSummary struct {
		ID           int64    `json:"id"`
		OriginalName string   `json:"original_name"`
		MimeType     string   `json:"mime_type"`
		FileSize     int64    `json:"file_size"`
		Category     string   `json:"category"`
		Description  *string  `json:"description"`
		Version      int      `json:"version"`
		Tags         []string `json:"tags"`
		UploadedBy   *string  `json:"uploaded_by"`
		CreatedAt    string   `json:"created_at"`
		FolderID     *int64   `json:"template_folder_id"`
	}

	var attachments []AttachmentSummary
	for rows.Next() {
		var a AttachmentSummary
		if err := rows.Scan(&a.ID, &a.OriginalName, &a.MimeType, &a.FileSize,
			&a.Category, &a.Description, &a.Version,
			&a.Tags, &a.UploadedBy, &a.CreatedAt); err == nil {
			if a.Tags == nil {
				a.Tags = []string{}
			}
			attachments = append(attachments, a)
		}
	}

	// When the node has a template assigned, also bring in the template's files
	var templateAttachments []AttachmentSummary
	var templateInfo struct {
		ID           *int64
		Manufacturer *string
		Model        *string
	}
	h.db.QueryRow(c.UserContext(),
		`SELECT fn.template_id, et.manufacturer, et.model
		 FROM factory_nodes fn
		 LEFT JOIN equipment_templates et ON et.id = fn.template_id
		 WHERE fn.id = $1 AND fn.tenant_id = $2`,
		nodeID, claims.TenantID,
	).Scan(&templateInfo.ID, &templateInfo.Manufacturer, &templateInfo.Model)

	if templateInfo.ID != nil {
		tplRows, tplErr := h.db.Query(c.UserContext(),
			`SELECT a.id, a.original_name, a.mime_type, a.file_size,
			        a.category, a.description, a.version,
			        a.tags, u.full_name, a.created_at::text,
			        a.template_folder_id
			 FROM attachments a
			 LEFT JOIN users u ON u.id = a.uploaded_by
			 WHERE a.template_id = $1 AND a.tenant_id = $2
			 ORDER BY a.created_at DESC`,
			templateInfo.ID, claims.TenantID,
		)
		if tplErr == nil {
			defer tplRows.Close()
			for tplRows.Next() {
				var a AttachmentSummary
				if tplRows.Scan(&a.ID, &a.OriginalName, &a.MimeType, &a.FileSize,
					&a.Category, &a.Description, &a.Version,
					&a.Tags, &a.UploadedBy, &a.CreatedAt, &a.FolderID) == nil {
					if a.Tags == nil {
						a.Tags = []string{}
					}
					templateAttachments = append(templateAttachments, a)
				}
			}
		}
	}

	// Template folders
	type TemplateFolder struct {
		ID        int64  `json:"id"`
		Name      string `json:"name"`
		ParentID  *int64 `json:"parent_id"`
		CreatedAt string `json:"created_at"`
	}
	var templateFolders []TemplateFolder
	if templateInfo.ID != nil {
		fRows, fErr := h.db.Query(c.UserContext(),
			`SELECT id, name, parent_id, created_at::text
			 FROM template_folders
			 WHERE template_id = $1 AND tenant_id = $2
			 ORDER BY name`,
			templateInfo.ID, claims.TenantID,
		)
		if fErr == nil {
			defer fRows.Close()
			for fRows.Next() {
				var f TemplateFolder
				if fRows.Scan(&f.ID, &f.Name, &f.ParentID, &f.CreatedAt) == nil {
					templateFolders = append(templateFolders, f)
				}
			}
		}
	}

	var templateName *string
	if templateInfo.Manufacturer != nil && templateInfo.Model != nil {
		tn := *templateInfo.Manufacturer + " " + *templateInfo.Model
		templateName = &tn
	}

	return c.JSON(fiber.Map{
		"attachments":          attachments,
		"template_attachments": templateAttachments,
		"template_folders":     templateFolders,
		"template_name":        templateName,
		"total":                len(attachments),
	})
}

// ─── POST /library/nodes/:id/upload — simulate a file upload ──────────────
// Note: in production this integrates with a real file system (S3, local, etc.)
// For development we just record the file metadata.

func (h *LibraryHandler) Upload(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	// Get the file from the multipart form
	file, err := c.FormFile("file")
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "No se encontró el archivo en la solicitud")
	}

	// Validate the size (50MB maximum)
	if file.Size > 50*1024*1024 {
		return fiber.NewError(fiber.StatusBadRequest, "El archivo supera el límite de 50MB")
	}

	category := c.FormValue("category", "other")
	description := c.FormValue("description", "")

	// Optional form values: wo_id to link the attachment to a specific WO,
	// phase to mark a before/after photo within that WO.
	var woIDPtr *int64
	if woStr := c.FormValue("wo_id"); woStr != "" {
		if parsed, perr := strconv.ParseInt(woStr, 10, 64); perr == nil && parsed > 0 {
			// Confirm the WO exists and belongs to the tenant
			var ok int
			_ = h.db.QueryRow(c.UserContext(),
				`SELECT 1 FROM work_orders WHERE id=$1 AND tenant_id=$2`,
				parsed, claims.TenantID,
			).Scan(&ok)
			if ok != 1 {
				return fiber.NewError(fiber.StatusBadRequest, "OT no encontrada")
			}
			woIDPtr = &parsed
		}
	}

	var photoPhase *string
	if ph := c.FormValue("phase"); ph != "" {
		if ph != "before" && ph != "after" {
			return fiber.NewError(fiber.StatusBadRequest, "phase debe ser 'before' o 'after'")
		}
		photoPhase = &ph
	}

	// Generate a unique name for storage
	timestamp := time.Now().Unix()
	safeFileName := fmt.Sprintf("%d_%d_%s", claims.TenantID, timestamp, sanitizeFileName(file.Filename))
	filePath := fmt.Sprintf("/uploads/tenant_%d/%s", claims.TenantID, safeFileName)

	// Store the file under UPLOAD_DIR (configurable). In production it is mounted
	// at /var/lib/arche/uploads as a volume.
	uploadDir := uploadBaseDir()
	dest := filepath.Join(uploadDir, safeFileName)
	if !ensureUnderBase(uploadDir, dest) {
		return fiber.NewError(fiber.StatusBadRequest, "Nombre de archivo inválido")
	}
	if err := c.SaveFile(file, dest); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error guardando el archivo")
	}
	// In production with S3/external storage, the temporary file would be cleaned up here.
	// In development the file stays in /tmp so it can be served locally.

	var newID int64
	err = h.db.QueryRow(c.UserContext(),
		`INSERT INTO attachments
		 (tenant_id, node_id, wo_id, file_name, original_name, mime_type, file_size,
		  file_path, category, description, photo_phase, uploaded_by)
		 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id`,
		claims.TenantID, nodeID, woIDPtr, safeFileName, file.Filename,
		file.Header.Get("Content-Type"), file.Size,
		filePath, category, description, photoPhase, claims.UserID,
	).Scan(&newID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error registrando archivo")
	}

	// Index it for the AI (text and PDF are extracted automatically)
	ai.EnqueueNow(context.Background(), h.db, claims.TenantID, "index", "attachment", newID)

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"id":            newID,
		"original_name": file.Filename,
		"file_size":     file.Size,
		"category":      category,
		"message":       "Archivo subido correctamente",
	})
}

// ─── GET /library/:id/download — serve an attachment to the client ──────────────────
func (h *LibraryHandler) Download(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var fileName, originalName, mimeType string
	err = h.db.QueryRow(c.UserContext(),
		`SELECT file_name, original_name, COALESCE(mime_type,'application/octet-stream')
		 FROM attachments WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	).Scan(&fileName, &originalName, &mimeType)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Archivo no encontrado")
	}

	safeFileName := sanitizePathComponent(fileName)
	if safeFileName == "" {
		return fiber.NewError(fiber.StatusForbidden, "Nombre de archivo inválido")
	}
	uploadDir := uploadBaseDir()
	full := filepath.Join(uploadDir, safeFileName)
	if !ensureUnderBase(uploadDir, full) {
		return fiber.NewError(fiber.StatusForbidden, "Ruta de archivo inválida")
	}
	if _, err := os.Stat(full); os.IsNotExist(err) {
		return fiber.NewError(fiber.StatusNotFound, "Archivo no encontrado en disco")
	}

	c.Set("Content-Disposition", fmt.Sprintf(`inline; filename="%s"`, sanitizeFileName(originalName)))
	c.Set("Content-Type", mimeType)
	return c.SendFile(full)
}

// ─── DELETE /library/:id ──────────────────────────────────────────────────────

func (h *LibraryHandler) Delete(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	// Get file_name before deleting so the physical file can be removed
	var fileName string
	_ = h.db.QueryRow(c.UserContext(),
		`SELECT file_name FROM attachments WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	).Scan(&fileName)

	result, err := h.db.Exec(c.UserContext(),
		`DELETE FROM attachments WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Archivo no encontrado")
	}

	// Delete the physical file and the embeddings in the background.
	tenantID := claims.TenantID
	attID := id
	safeFileName := sanitizePathComponent(fileName)
	uploadDir := uploadBaseDir()
	go func() {
		bgCtx := context.Background()
		if safeFileName != "" {
			fullPath := filepath.Join(uploadDir, safeFileName)
			if ensureUnderBase(uploadDir, fullPath) {
				if err := os.Remove(fullPath); err != nil && !os.IsNotExist(err) {
					log.Printf("[ARCHE-LIB] no se pudo borrar %s: %v", fullPath, err)
				}
			} else {
				log.Printf("[ARCHE-LIB] path traversal bloqueado: %q", fileName)
			}
		}
		logExecErr(h.db.Exec(bgCtx,
			`DELETE FROM ai_embeddings WHERE tenant_id=$1 AND source_type='attachment' AND source_id=$2`,
			tenantID, attID)).Log("lib-del-embed")
		logExecErr(h.db.Exec(bgCtx,
			`DELETE FROM ai_index_queue WHERE tenant_id=$1 AND source_type='attachment' AND source_id=$2 AND status='pending'`,
			tenantID, attID)).Log("lib-del-queue")
	}()

	return c.JSON(fiber.Map{"message": "Archivo eliminado"})
}

// ─── GET /library/wo/:id — attachments of a WO ───────────────────────

func (h *LibraryHandler) ListByWO(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	woID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	rows, err := h.db.Query(c.UserContext(),
		`SELECT a.id, a.original_name, a.mime_type, a.file_size,
		        a.category, a.description, a.photo_phase,
		        u.full_name, a.created_at::text
		 FROM attachments a
		 LEFT JOIN users u ON u.id = a.uploaded_by
		 WHERE a.wo_id=$1 AND a.tenant_id=$2
		 ORDER BY a.created_at DESC`,
		woID, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando adjuntos")
	}
	defer rows.Close()

	type Att struct {
		ID           int64   `json:"id"`
		OriginalName string  `json:"original_name"`
		MimeType     string  `json:"mime_type"`
		FileSize     int64   `json:"file_size"`
		Category     string  `json:"category"`
		Description  *string `json:"description"`
		PhotoPhase   *string `json:"photo_phase"`
		UploadedBy   *string `json:"uploaded_by"`
		CreatedAt    string  `json:"created_at"`
	}

	var atts []Att
	for rows.Next() {
		var a Att
		if err := rows.Scan(&a.ID, &a.OriginalName, &a.MimeType, &a.FileSize,
			&a.Category, &a.Description, &a.PhotoPhase, &a.UploadedBy, &a.CreatedAt); err == nil {
			atts = append(atts, a)
		}
	}

	return c.JSON(fiber.Map{"attachments": atts, "total": len(atts)})
}

// ─── Helper ───────────────────────────────────────────────────────────────────

func sanitizeFileName(name string) string {
	// Strip dangerous segments before replacing characters.
	name = strings.ReplaceAll(name, "..", "_")
	// Replace characters that are troublesome for the path AND for Content-Disposition.
	replacer := strings.NewReplacer(
		" ", "_", "/", "_", "\\", "_",
		":", "_", "*", "_", "?", "_",
		"\"", "_", "<", "_", ">", "_", "|", "_",
		";", "_", "\r", "_", "\n", "_", "'", "_",
	)
	return replacer.Replace(name)
}

// ─── GET /library/all — every attachment in the tenant ────────────────────────

func (h *LibraryHandler) ListAll(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	category := c.Query("category")

	query := `SELECT a.id, a.node_id, fn.name AS node_name, a.original_name,
	                 a.mime_type, a.file_size, a.category, a.created_at::text
	          FROM attachments a
	          JOIN factory_nodes fn ON fn.id = a.node_id
	          WHERE a.tenant_id = $1 AND a.node_id IS NOT NULL`
	args := []interface{}{claims.TenantID}

	if category != "" {
		query += ` AND a.category = $2`
		args = append(args, category)
	}
	query += ` ORDER BY a.created_at DESC LIMIT 200`

	rows, err := h.db.Query(c.UserContext(), query, args...)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando biblioteca")
	}
	defer rows.Close()

	type Attachment struct {
		ID           int64  `json:"id"`
		NodeID       int64  `json:"node_id"`
		NodeName     string `json:"node_name"`
		OriginalName string `json:"original_name"`
		MimeType     string `json:"mime_type"`
		FileSize     int64  `json:"file_size"`
		Category     string `json:"category"`
		CreatedAt    string `json:"created_at"`
	}

	var attachments []Attachment
	for rows.Next() {
		var a Attachment
		if rows.Scan(&a.ID, &a.NodeID, &a.NodeName, &a.OriginalName,
			&a.MimeType, &a.FileSize, &a.Category, &a.CreatedAt) == nil {
			attachments = append(attachments, a)
		}
	}

	return c.JSON(fiber.Map{"attachments": attachments, "total": len(attachments)})
}
