package handlers

import (
	"arche-gmao/api/internal/middleware"
	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/redis/go-redis/v9"
)

type SystemHandler struct {
	db  *pgxpool.Pool
	rdb *redis.Client
}

func NewSystemHandler(db *pgxpool.Pool, rdb *redis.Client) *SystemHandler {
	return &SystemHandler{db: db, rdb: rdb}
}

// Status returns the state of the system: pause, users, etc.
func (h *SystemHandler) Status(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var paused bool
	var pausedBy *int64
	var pausedAt *string
	var pausedContact *string
	var maxUsers *int

	h.db.QueryRow(c.UserContext(),
		`SELECT system_paused, paused_by, paused_at::text, paused_contact, max_users
		 FROM tenants WHERE id = $1`,
		claims.TenantID,
	).Scan(&paused, &pausedBy, &pausedAt, &pausedContact, &maxUsers)

	var activeUsers, totalUsers int
	h.db.QueryRow(c.UserContext(),
		`SELECT COUNT(*), COUNT(*) FILTER (WHERE status='active')
		 FROM users WHERE tenant_id = $1`,
		claims.TenantID,
	).Scan(&totalUsers, &activeUsers)

	// Name of the user who paused it (when applicable)
	var pausedByName *string
	if pausedBy != nil {
		var name string
		err := h.db.QueryRow(c.UserContext(),
			`SELECT full_name FROM users WHERE id = $1 AND tenant_id = $2`, *pausedBy, claims.TenantID,
		).Scan(&name)
		if err == nil {
			pausedByName = &name
		}
	}

	return c.JSON(fiber.Map{
		"system_paused":  paused,
		"paused_by":      pausedBy,
		"paused_by_name": pausedByName,
		"paused_at":      pausedAt,
		"paused_contact": pausedContact,
		"max_users":      maxUsers,
		"active_users":   activeUsers,
		"total_users":    totalUsers,
	})
}

// Pause turns on the system stop mode.
// Only the primary admin or the superadmin can turn it on.
func (h *SystemHandler) Pause(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req struct {
		Contact string `json:"contact"`
	}
	c.BodyParser(&req)

	if req.Contact == "" {
		req.Contact = "Contacte al administrador del sistema"
	}

	_, err := h.db.Exec(c.UserContext(),
		`UPDATE tenants SET system_paused = TRUE, paused_by = $1, paused_at = NOW(), paused_contact = $2
		 WHERE id = $3`,
		claims.UserID, req.Contact, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error activando modo parada")
	}

	// Invalidate the cache immediately
	middleware.InvalidatePauseCache(c.UserContext(), h.rdb, claims.TenantID)

	return c.JSON(fiber.Map{"message": "Sistema pausado correctamente"})
}

// Resume turns off the system stop mode.
func (h *SystemHandler) Resume(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	_, err := h.db.Exec(c.UserContext(),
		`UPDATE tenants SET system_paused = FALSE, paused_by = NULL, paused_at = NULL, paused_contact = NULL
		 WHERE id = $1`,
		claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error desactivando modo parada")
	}

	middleware.InvalidatePauseCache(c.UserContext(), h.rdb, claims.TenantID)

	return c.JSON(fiber.Map{"message": "Sistema reanudado correctamente"})
}

// ─── PUT /system/retention — configure data retention ──────────────────

func (h *SystemHandler) SetRetention(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req struct {
		ActivityRetentionDays int `json:"activity_retention_days"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}
	if req.ActivityRetentionDays < 30 {
		return fiber.NewError(fiber.StatusBadRequest, "Mínimo 30 días de retención")
	}

	_, err := h.db.Exec(c.UserContext(),
		`UPDATE tenants SET activity_retention_days=$1 WHERE id=$2`,
		req.ActivityRetentionDays, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error actualizando retención")
	}

	return c.JSON(fiber.Map{"message": "Retención actualizada", "days": req.ActivityRetentionDays})
}

// ─── GET /system/retention — get the retention configuration ─────────────

func (h *SystemHandler) GetRetention(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	var days int
	h.db.QueryRow(c.UserContext(),
		`SELECT COALESCE(activity_retention_days, 365) FROM tenants WHERE id=$1`,
		claims.TenantID,
	).Scan(&days)
	return c.JSON(fiber.Map{"activity_retention_days": days})
}
