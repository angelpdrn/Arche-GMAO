package handlers

import (
	"strconv"
	"strings"

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type CompositionHandler struct {
	db *pgxpool.Pool
}

func NewCompositionHandler(db *pgxpool.Pool) *CompositionHandler {
	return &CompositionHandler{db: db}
}

// ─── GET /compositions — list compositions ────────────────────────────────
// ?node_id=X  → compositions where the node is a member
// ?parent_id=X → compositions under a parent node
// No filter   → every composition in the tenant

func (h *CompositionHandler) List(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	nodeID, _ := strconv.ParseInt(c.Query("node_id"), 10, 64)
	parentID, _ := strconv.ParseInt(c.Query("parent_id"), 10, 64)

	var rows []map[string]interface{}

	if nodeID > 0 {
		// Compositions where this node is a member
		r, err := h.db.Query(c.UserContext(),
			`SELECT ec.id, ec.name, ec.description, ec.parent_node_id,
			        pn.name AS parent_node_name,
			        ec.template_id, ct.name AS template_name,
			        ec.created_at::text,
			        (SELECT COUNT(*) FROM equipment_composition_members WHERE composition_id = ec.id) AS member_count
			 FROM equipment_compositions ec
			 JOIN equipment_composition_members ecm ON ecm.composition_id = ec.id AND ecm.node_id = $1
			 LEFT JOIN factory_nodes pn ON pn.id = ec.parent_node_id
			 LEFT JOIN composition_templates ct ON ct.id = ec.template_id
			 WHERE ec.tenant_id = $2
			 ORDER BY ec.name`,
			nodeID, claims.TenantID)
		if err != nil {
			return fiber.NewError(500, "Error listando composiciones")
		}
		defer r.Close()
		for r.Next() {
			var id, memberCount int64
			var name, createdAt string
			var desc, parentNodeName, templateName *string
			var parentNodeID, templateID *int64
			if err := r.Scan(&id, &name, &desc, &parentNodeID, &parentNodeName, &templateID, &templateName, &createdAt, &memberCount); err != nil {
				continue
			}
			rows = append(rows, map[string]interface{}{
				"id": id, "name": name, "description": desc,
				"parent_node_id": parentNodeID, "parent_node_name": parentNodeName,
				"template_id": templateID, "template_name": templateName,
				"created_at": createdAt, "member_count": memberCount,
			})
		}
	} else if parentID > 0 {
		r, err := h.db.Query(c.UserContext(),
			`SELECT ec.id, ec.name, ec.description, ec.parent_node_id,
			        pn.name AS parent_node_name,
			        ec.template_id, ct.name AS template_name,
			        ec.created_at::text,
			        (SELECT COUNT(*) FROM equipment_composition_members WHERE composition_id = ec.id) AS member_count
			 FROM equipment_compositions ec
			 LEFT JOIN factory_nodes pn ON pn.id = ec.parent_node_id
			 LEFT JOIN composition_templates ct ON ct.id = ec.template_id
			 WHERE ec.tenant_id = $1 AND ec.parent_node_id = $2
			 ORDER BY ec.name`,
			claims.TenantID, parentID)
		if err != nil {
			return fiber.NewError(500, "Error listando composiciones")
		}
		defer r.Close()
		for r.Next() {
			var id, memberCount int64
			var name, createdAt string
			var desc, parentNodeName, templateName *string
			var parentNodeID, templateID *int64
			if err := r.Scan(&id, &name, &desc, &parentNodeID, &parentNodeName, &templateID, &templateName, &createdAt, &memberCount); err != nil {
				continue
			}
			rows = append(rows, map[string]interface{}{
				"id": id, "name": name, "description": desc,
				"parent_node_id": parentNodeID, "parent_node_name": parentNodeName,
				"template_id": templateID, "template_name": templateName,
				"created_at": createdAt, "member_count": memberCount,
			})
		}
	} else {
		r, err := h.db.Query(c.UserContext(),
			`SELECT ec.id, ec.name, ec.description, ec.parent_node_id,
			        pn.name AS parent_node_name,
			        ec.template_id, ct.name AS template_name,
			        ec.created_at::text,
			        (SELECT COUNT(*) FROM equipment_composition_members WHERE composition_id = ec.id) AS member_count,
			        ec.node_id
			 FROM equipment_compositions ec
			 LEFT JOIN factory_nodes pn ON pn.id = ec.parent_node_id
			 LEFT JOIN composition_templates ct ON ct.id = ec.template_id
			 WHERE ec.tenant_id = $1
			 ORDER BY ec.name`,
			claims.TenantID)
		if err != nil {
			return fiber.NewError(500, "Error listando composiciones")
		}
		defer r.Close()
		for r.Next() {
			var id, memberCount int64
			var name, createdAt string
			var desc, parentNodeName, templateName *string
			var parentNodeID, templateID, nodeID *int64
			if err := r.Scan(&id, &name, &desc, &parentNodeID, &parentNodeName, &templateID, &templateName, &createdAt, &memberCount, &nodeID); err != nil {
				continue
			}
			rows = append(rows, map[string]interface{}{
				"id": id, "name": name, "description": desc,
				"parent_node_id": parentNodeID, "parent_node_name": parentNodeName,
				"template_id": templateID, "template_name": templateName,
				"created_at": createdAt, "member_count": memberCount,
				"node_id": nodeID,
			})
		}
	}

	if rows == nil {
		rows = []map[string]interface{}{}
	}
	return c.JSON(rows)
}

// ─── GET /compositions/:id — detail with members ────────────────────────────

func (h *CompositionHandler) GetOne(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)

	var comp struct {
		ID             int64   `json:"id"`
		Name           string  `json:"name"`
		Description    *string `json:"description"`
		ParentNodeID   *int64  `json:"parent_node_id"`
		ParentNodeName *string `json:"parent_node_name"`
		TemplateID     *int64  `json:"template_id"`
		TemplateName   *string `json:"template_name"`
		CreatedAt      string  `json:"created_at"`
	}

	err := h.db.QueryRow(c.UserContext(),
		`SELECT ec.id, ec.name, ec.description, ec.parent_node_id,
		        pn.name, ec.template_id, ct.name, ec.created_at::text
		 FROM equipment_compositions ec
		 LEFT JOIN factory_nodes pn ON pn.id = ec.parent_node_id
		 LEFT JOIN composition_templates ct ON ct.id = ec.template_id
		 WHERE ec.id = $1 AND ec.tenant_id = $2`,
		id, claims.TenantID,
	).Scan(&comp.ID, &comp.Name, &comp.Description, &comp.ParentNodeID,
		&comp.ParentNodeName, &comp.TemplateID, &comp.TemplateName, &comp.CreatedAt)
	if err != nil {
		return fiber.NewError(404, "Composicion no encontrada")
	}

	// Members
	type Member struct {
		ID           int64   `json:"id"`
		NodeID       int64   `json:"node_id"`
		NodeName     string  `json:"node_name"`
		NodeCode     *string `json:"node_code"`
		NodeType     string  `json:"node_type"`
		Manufacturer *string `json:"manufacturer"`
		Model        *string `json:"model"`
		TemplateName *string `json:"template_name"`
		Role         *string `json:"role"`
		Status       string  `json:"status"`
	}

	var members []Member
	mRows, err := h.db.Query(c.UserContext(),
		`SELECT ecm.id, ecm.node_id, fn.name, fn.code, fn.node_type,
		        COALESCE(fn.manufacturer, et.manufacturer), COALESCE(fn.model, et.model),
		        CASE WHEN et.id IS NOT NULL THEN et.manufacturer || ' ' || et.model END,
		        ecm.role, fn.status
		 FROM equipment_composition_members ecm
		 JOIN factory_nodes fn ON fn.id = ecm.node_id
		 LEFT JOIN equipment_templates et ON et.id = fn.template_id
		 WHERE ecm.composition_id = $1
		 ORDER BY ecm.role, fn.name`,
		id)
	if err == nil {
		defer mRows.Close()
		for mRows.Next() {
			var m Member
			if mRows.Scan(&m.ID, &m.NodeID, &m.NodeName, &m.NodeCode, &m.NodeType,
				&m.Manufacturer, &m.Model, &m.TemplateName, &m.Role, &m.Status) == nil {
				members = append(members, m)
			}
		}
	}
	if members == nil {
		members = []Member{}
	}

	// Template slots (to show what is still unassigned)
	type Slot struct {
		ID                  int64   `json:"id"`
		Role                string  `json:"role"`
		EquipmentTemplateID *int64  `json:"equipment_template_id"`
		EquipmentName       *string `json:"equipment_name"`
		SortOrder           int     `json:"sort_order"`
		AssignedNodeID      *int64  `json:"assigned_node_id"`
		AssignedNodeName    *string `json:"assigned_node_name"`
	}
	var slots []Slot
	if comp.TemplateID != nil {
		sRows, sErr := h.db.Query(c.UserContext(),
			`SELECT cts.id, cts.role, cts.equipment_template_id,
			        CASE WHEN et.id IS NOT NULL THEN et.manufacturer || ' ' || et.model END,
			        cts.sort_order,
			        ecm.node_id, fn.name
			 FROM composition_template_slots cts
			 LEFT JOIN equipment_templates et ON et.id = cts.equipment_template_id
			 LEFT JOIN equipment_composition_members ecm ON ecm.slot_id = cts.id AND ecm.composition_id = $1
			 LEFT JOIN factory_nodes fn ON fn.id = ecm.node_id
			 WHERE cts.template_id = $2
			 ORDER BY cts.sort_order, cts.id`,
			id, *comp.TemplateID)
		if sErr == nil {
			defer sRows.Close()
			for sRows.Next() {
				var s Slot
				if sRows.Scan(&s.ID, &s.Role, &s.EquipmentTemplateID, &s.EquipmentName,
					&s.SortOrder, &s.AssignedNodeID, &s.AssignedNodeName) == nil {
					slots = append(slots, s)
				}
			}
		}
	}
	if slots == nil {
		slots = []Slot{}
	}

	return c.JSON(fiber.Map{
		"composition": comp,
		"members":     members,
		"slots":       slots,
	})
}

// ─── POST /compositions — create a composition ──────────────────────────────────

func (h *CompositionHandler) Create(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req struct {
		Name         string  `json:"name"`
		Description  *string `json:"description"`
		ParentNodeID *int64  `json:"parent_node_id"`
		NodeIDs      []int64 `json:"node_ids"`
		Roles        []string `json:"roles"` // parallel array with node_ids
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(400, "JSON invalido")
	}
	if strings.TrimSpace(req.Name) == "" {
		return fiber.NewError(400, "El nombre es obligatorio")
	}

	tx, err := h.db.Begin(c.UserContext())
	if err != nil {
		return fiber.NewError(500, "Error iniciando transaccion")
	}
	defer tx.Rollback(c.UserContext())

	var compID int64
	err = tx.QueryRow(c.UserContext(),
		`INSERT INTO equipment_compositions (tenant_id, name, description, parent_node_id, created_by)
		 VALUES ($1, $2, $3, $4, $5) RETURNING id`,
		claims.TenantID, strings.TrimSpace(req.Name), req.Description, req.ParentNodeID, claims.UserID,
	).Scan(&compID)
	if err != nil {
		return fiber.NewError(500, "Error creando composicion")
	}

	// Add members
	for i, nid := range req.NodeIDs {
		var role *string
		if i < len(req.Roles) && req.Roles[i] != "" {
			r := req.Roles[i]
			role = &r
		}
		_, err := tx.Exec(c.UserContext(),
			`INSERT INTO equipment_composition_members (composition_id, node_id, role)
			 VALUES ($1, $2, $3) ON CONFLICT DO NOTHING`,
			compID, nid, role)
		if err != nil {
			return fiber.NewError(500, "Error agregando miembro")
		}
	}

	if err := tx.Commit(c.UserContext()); err != nil {
		return fiber.NewError(500, "Error guardando composicion")
	}

	return c.Status(201).JSON(fiber.Map{"id": compID, "message": "Composicion creada"})
}

// ─── PUT /compositions/:id — update name/description ───────────────────

func (h *CompositionHandler) Update(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)

	var req struct {
		Name        string  `json:"name"`
		Description *string `json:"description"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(400, "JSON invalido")
	}
	if strings.TrimSpace(req.Name) == "" {
		return fiber.NewError(400, "El nombre es obligatorio")
	}

	tag, err := h.db.Exec(c.UserContext(),
		`UPDATE equipment_compositions SET name=$1, description=$2
		 WHERE id=$3 AND tenant_id=$4`,
		strings.TrimSpace(req.Name), req.Description, id, claims.TenantID)
	if err != nil || tag.RowsAffected() == 0 {
		return fiber.NewError(404, "Composicion no encontrada")
	}
	return c.JSON(fiber.Map{"message": "Composicion actualizada"})
}

// ─── DELETE /compositions/:id ────────────────────────────────────────────────

func (h *CompositionHandler) Delete(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)

	tag, err := h.db.Exec(c.UserContext(),
		`DELETE FROM equipment_compositions WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID)
	if err != nil || tag.RowsAffected() == 0 {
		return fiber.NewError(404, "Composicion no encontrada")
	}
	return c.JSON(fiber.Map{"message": "Composicion eliminada"})
}

// ─── POST /compositions/:id/members — add a member ────────────────────────

func (h *CompositionHandler) AddMember(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	compID, _ := strconv.ParseInt(c.Params("id"), 10, 64)

	var req struct {
		NodeID int64  `json:"node_id"`
		Role   string `json:"role"`
	}
	if err := c.BodyParser(&req); err != nil || req.NodeID == 0 {
		return fiber.NewError(400, "node_id es obligatorio")
	}

	// Check that the composition belongs to the tenant
	var exists bool
	h.db.QueryRow(c.UserContext(),
		`SELECT EXISTS(SELECT 1 FROM equipment_compositions WHERE id=$1 AND tenant_id=$2)`,
		compID, claims.TenantID).Scan(&exists)
	if !exists {
		return fiber.NewError(404, "Composicion no encontrada")
	}

	var role *string
	if req.Role != "" {
		role = &req.Role
	}

	_, err := h.db.Exec(c.UserContext(),
		`INSERT INTO equipment_composition_members (composition_id, node_id, role)
		 VALUES ($1, $2, $3) ON CONFLICT (composition_id, node_id) DO UPDATE SET role = $3`,
		compID, req.NodeID, role)
	if err != nil {
		return fiber.NewError(500, "Error agregando miembro")
	}
	return c.Status(201).JSON(fiber.Map{"message": "Miembro agregado"})
}

// ─── DELETE /compositions/:id/members/:nodeId — remove a member ───────────────

func (h *CompositionHandler) RemoveMember(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	compID, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	nodeID, _ := strconv.ParseInt(c.Params("nodeId"), 10, 64)

	// Check that the composition belongs to the tenant
	var exists bool
	h.db.QueryRow(c.UserContext(),
		`SELECT EXISTS(SELECT 1 FROM equipment_compositions WHERE id=$1 AND tenant_id=$2)`,
		compID, claims.TenantID).Scan(&exists)
	if !exists {
		return fiber.NewError(404, "Composicion no encontrada")
	}

	result, err := h.db.Exec(c.UserContext(),
		`DELETE FROM equipment_composition_members WHERE composition_id=$1 AND node_id=$2`,
		compID, nodeID)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Miembro no encontrado")
	}
	return c.JSON(fiber.Map{"message": "Miembro eliminado"})
}

// ─── GET /compositions/by-node/:nodeId — compositions of a node ────────────

func (h *CompositionHandler) GetNodeCompositions(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID, _ := strconv.ParseInt(c.Params("nodeId"), 10, 64)

	type CompWithMembers struct {
		ID          int64  `json:"id"`
		Name        string `json:"name"`
		Description *string `json:"description"`
		MemberCount int64  `json:"member_count"`
		Members     []map[string]interface{} `json:"members"`
	}

	var comps []CompWithMembers

	// First get the compositions where this node is a member
	cRows, err := h.db.Query(c.UserContext(),
		`SELECT ec.id, ec.name, ec.description,
		        (SELECT COUNT(*) FROM equipment_composition_members WHERE composition_id = ec.id)
		 FROM equipment_compositions ec
		 JOIN equipment_composition_members ecm ON ecm.composition_id = ec.id AND ecm.node_id = $1
		 WHERE ec.tenant_id = $2
		 ORDER BY ec.name`,
		nodeID, claims.TenantID)
	if err != nil {
		return fiber.NewError(500, "Error listando composiciones")
	}
	defer cRows.Close()

	for cRows.Next() {
		var comp CompWithMembers
		if cRows.Scan(&comp.ID, &comp.Name, &comp.Description, &comp.MemberCount) != nil {
			continue
		}
		comps = append(comps, comp)
	}

	// For each composition, get its members
	for i := range comps {
		mRows, err := h.db.Query(c.UserContext(),
			`SELECT ecm.node_id, fn.name, fn.code, fn.node_type, ecm.role, fn.status,
			        COALESCE(fn.manufacturer, et.manufacturer, '') AS manufacturer,
			        COALESCE(fn.model, et.model, '') AS model
			 FROM equipment_composition_members ecm
			 JOIN factory_nodes fn ON fn.id = ecm.node_id
			 LEFT JOIN equipment_templates et ON et.id = fn.template_id
			 WHERE ecm.composition_id = $1
			 ORDER BY ecm.role, fn.name`,
			comps[i].ID)
		if err != nil {
			continue
		}
		for mRows.Next() {
			var nid int64
			var name, nodeType, status, mfr, mdl string
			var code, role *string
			if mRows.Scan(&nid, &name, &code, &nodeType, &role, &status, &mfr, &mdl) == nil {
				comps[i].Members = append(comps[i].Members, map[string]interface{}{
					"node_id": nid, "name": name, "code": code,
					"node_type": nodeType, "role": role, "status": status,
					"manufacturer": mfr, "model": mdl,
				})
			}
		}
		mRows.Close()
		if comps[i].Members == nil {
			comps[i].Members = []map[string]interface{}{}
		}
	}

	if comps == nil {
		comps = []CompWithMembers{}
	}
	return c.JSON(comps)
}
