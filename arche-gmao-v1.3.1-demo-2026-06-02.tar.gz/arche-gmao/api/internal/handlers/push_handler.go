package handlers

import (
	"arche-gmao/api/internal/config"
	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type PushHandler struct {
	db  *pgxpool.Pool
	cfg *config.Config
}

func NewPushHandler(db *pgxpool.Pool, cfg *config.Config) *PushHandler {
	return &PushHandler{db: db, cfg: cfg}
}

// ─── GET /push/vapid-public-key — VAPID public key ────────────────────────

func (h *PushHandler) GetVAPIDPublicKey(c *fiber.Ctx) error {
	key := h.cfg.VAPIDPublicKey
	if key == "" {
		return fiber.NewError(fiber.StatusServiceUnavailable, "Push notifications no configuradas")
	}
	return c.JSON(fiber.Map{"public_key": key})
}

// ─── POST /push/subscribe — register a push subscription ───────────────────────

func (h *PushHandler) Subscribe(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req struct {
		Endpoint string `json:"endpoint"`
		Keys     struct {
			P256dh string `json:"p256dh"`
			Auth   string `json:"auth"`
		} `json:"keys"`
		UserAgent string `json:"user_agent"`
	}
	if err := c.BodyParser(&req); err != nil || req.Endpoint == "" {
		return fiber.NewError(fiber.StatusBadRequest, "Suscripcion invalida")
	}

	// Store the subscription — upsert by endpoint
	_, err := h.db.Exec(c.UserContext(),
		`INSERT INTO push_subscriptions
		 (tenant_id, user_id, endpoint, p256dh, auth, user_agent)
		 VALUES ($1,$2,$3,$4,$5,$6)
		 ON CONFLICT (endpoint) DO UPDATE
		 SET p256dh=$4, auth=$5, user_id=$2, updated_at=NOW()`,
		claims.TenantID, claims.UserID,
		req.Endpoint, req.Keys.P256dh, req.Keys.Auth, req.UserAgent,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error guardando suscripcion")
	}

	return c.JSON(fiber.Map{"message": "Suscripcion registrada"})
}

// ─── DELETE /push/unsubscribe — remove a subscription ─────────────────────────

func (h *PushHandler) Unsubscribe(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req struct {
		Endpoint string `json:"endpoint"`
	}
	if err := c.BodyParser(&req); err != nil || req.Endpoint == "" {
		return fiber.NewError(fiber.StatusBadRequest, "Endpoint requerido")
	}

	_, err := h.db.Exec(c.UserContext(),
		`DELETE FROM push_subscriptions WHERE user_id=$1 AND endpoint=$2 AND tenant_id=$3`,
		claims.UserID, req.Endpoint, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error eliminando suscripcion")
	}
	return c.JSON(fiber.Map{"message": "Suscripcion eliminada"})
}
