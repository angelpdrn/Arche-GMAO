package handlers

import (
	"encoding/json"
	"strconv"

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type MaintenancePlanTemplateHandler struct {
	db *pgxpool.Pool
}

func NewMaintenancePlanTemplateHandler(db *pgxpool.Pool) *MaintenancePlanTemplateHandler {
	return &MaintenancePlanTemplateHandler{db: db}
}

// ─── GET /maintenance-plan-templates ─────────────────────────────────────────

func (h *MaintenancePlanTemplateHandler) List(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	rows, err := h.db.Query(c.UserContext(),
		`SELECT id, name, description, wo_type, priority,
		        frequency_type, frequency_value, advance_days,
		        estimated_hours, apply_to_children, created_at::text
		 FROM maintenance_plan_templates
		 WHERE tenant_id = $1
		 ORDER BY name`,
		claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando plantillas")
	}
	defer rows.Close()

	type Template struct {
		ID              int64    `json:"id"`
		Name            string   `json:"name"`
		Description     *string  `json:"description"`
		WOType          string   `json:"wo_type"`
		Priority        string   `json:"priority"`
		FrequencyType   string   `json:"frequency_type"`
		FrequencyValue  int      `json:"frequency_value"`
		AdvanceDays     int      `json:"advance_days"`
		EstimatedHours  *float64 `json:"estimated_hours"`
		ApplyToChildren bool     `json:"apply_to_children"`
		CreatedAt       string   `json:"created_at"`
	}

	var templates []Template
	for rows.Next() {
		var t Template
		if rows.Scan(&t.ID, &t.Name, &t.Description, &t.WOType, &t.Priority,
			&t.FrequencyType, &t.FrequencyValue, &t.AdvanceDays,
			&t.EstimatedHours, &t.ApplyToChildren, &t.CreatedAt) == nil {
			templates = append(templates, t)
		}
	}

	return c.JSON(fiber.Map{"templates": templates, "total": len(templates)})
}

// ─── GET /maintenance-plan-templates/:id ─────────────────────────────────────

func (h *MaintenancePlanTemplateHandler) GetOne(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	type TemplateDetail struct {
		ID              int64           `json:"id"`
		Name            string          `json:"name"`
		Description     *string         `json:"description"`
		WOType          string          `json:"wo_type"`
		Priority        string          `json:"priority"`
		FrequencyType   string          `json:"frequency_type"`
		FrequencyValue  int             `json:"frequency_value"`
		AdvanceDays     int             `json:"advance_days"`
		EstimatedHours  *float64        `json:"estimated_hours"`
		Instructions    *string         `json:"instructions"`
		Checklist       json.RawMessage `json:"checklist"`
		SafetyNotes     *string         `json:"safety_notes"`
		ToolsRequired   json.RawMessage `json:"tools_required"`
		RequiredParts   json.RawMessage `json:"required_parts"`
		ApplyToChildren bool            `json:"apply_to_children"`
		CreatedAt       string          `json:"created_at"`
	}

	var t TemplateDetail
	err = h.db.QueryRow(c.UserContext(),
		`SELECT id, name, description, wo_type, priority,
		        frequency_type, frequency_value, advance_days,
		        estimated_hours, instructions,
		        COALESCE(checklist, '[]'), safety_notes,
		        COALESCE(tools_required, '[]'), COALESCE(required_parts, '[]'),
		        apply_to_children, created_at::text
		 FROM maintenance_plan_templates
		 WHERE id = $1 AND tenant_id = $2`,
		id, claims.TenantID,
	).Scan(&t.ID, &t.Name, &t.Description, &t.WOType, &t.Priority,
		&t.FrequencyType, &t.FrequencyValue, &t.AdvanceDays,
		&t.EstimatedHours, &t.Instructions,
		&t.Checklist, &t.SafetyNotes,
		&t.ToolsRequired, &t.RequiredParts,
		&t.ApplyToChildren, &t.CreatedAt,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Plantilla no encontrada")
	}

	return c.JSON(fiber.Map{"template": t})
}

// ─── POST /maintenance-plan-templates ────────────────────────────────────────

func (h *MaintenancePlanTemplateHandler) Create(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req struct {
		Name            string          `json:"name"`
		Description     *string         `json:"description"`
		WOType          string          `json:"wo_type"`
		Priority        string          `json:"priority"`
		FrequencyType   string          `json:"frequency_type"`
		FrequencyValue  int             `json:"frequency_value"`
		AdvanceDays     int             `json:"advance_days"`
		EstimatedHours  *float64        `json:"estimated_hours"`
		Instructions    *string         `json:"instructions"`
		Checklist       json.RawMessage `json:"checklist"`
		SafetyNotes     *string         `json:"safety_notes"`
		ToolsRequired   json.RawMessage `json:"tools_required"`
		RequiredParts   json.RawMessage `json:"required_parts"`
		ApplyToChildren bool            `json:"apply_to_children"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}
	if req.Name == "" {
		return fiber.NewError(fiber.StatusBadRequest, "El nombre es obligatorio")
	}
	if req.WOType == "" {
		req.WOType = "preventive"
	}
	if req.Priority == "" {
		req.Priority = "medium"
	}
	if req.FrequencyType == "" {
		req.FrequencyType = "months"
	}
	if req.FrequencyValue == 0 {
		req.FrequencyValue = 1
	}
	if req.AdvanceDays == 0 {
		req.AdvanceDays = 3
	}

	checklist := normalizeJSON(req.Checklist, "[]")
	toolsReq := normalizeJSON(req.ToolsRequired, "[]")
	reqParts := normalizeJSON(req.RequiredParts, "[]")

	var newID int64
	err := h.db.QueryRow(c.UserContext(),
		`INSERT INTO maintenance_plan_templates
		 (tenant_id, name, description, wo_type, priority,
		  frequency_type, frequency_value, advance_days, estimated_hours,
		  instructions, checklist, safety_notes, tools_required, required_parts,
		  apply_to_children, created_by)
		 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)
		 RETURNING id`,
		claims.TenantID, req.Name, req.Description, req.WOType, req.Priority,
		req.FrequencyType, req.FrequencyValue, req.AdvanceDays, req.EstimatedHours,
		req.Instructions, checklist, req.SafetyNotes, toolsReq, reqParts,
		req.ApplyToChildren, claims.UserID,
	).Scan(&newID)
	if err != nil {
		return fiber.NewError(fiber.StatusConflict, "Ya existe una plantilla con ese nombre")
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"id":      newID,
		"message": "Plantilla de mantenimiento creada",
	})
}

// ─── PUT /maintenance-plan-templates/:id ─────────────────────────────────────

func (h *MaintenancePlanTemplateHandler) Update(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req struct {
		Name            string          `json:"name"`
		Description     *string         `json:"description"`
		WOType          string          `json:"wo_type"`
		Priority        string          `json:"priority"`
		FrequencyType   string          `json:"frequency_type"`
		FrequencyValue  int             `json:"frequency_value"`
		AdvanceDays     int             `json:"advance_days"`
		EstimatedHours  *float64        `json:"estimated_hours"`
		Instructions    *string         `json:"instructions"`
		Checklist       json.RawMessage `json:"checklist"`
		SafetyNotes     *string         `json:"safety_notes"`
		ToolsRequired   json.RawMessage `json:"tools_required"`
		RequiredParts   json.RawMessage `json:"required_parts"`
		ApplyToChildren bool            `json:"apply_to_children"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	checklist := normalizeJSON(req.Checklist, "[]")
	toolsReq := normalizeJSON(req.ToolsRequired, "[]")
	reqParts := normalizeJSON(req.RequiredParts, "[]")

	result, err := h.db.Exec(c.UserContext(),
		`UPDATE maintenance_plan_templates SET
		 name=COALESCE(NULLIF($1,''),name), description=$2, wo_type=$3, priority=$4,
		 frequency_type=$5, frequency_value=$6, advance_days=$7, estimated_hours=$8,
		 instructions=$9, checklist=$10, safety_notes=$11, tools_required=$12, required_parts=$13,
		 apply_to_children=$14
		 WHERE id=$15 AND tenant_id=$16`,
		req.Name, req.Description, req.WOType, req.Priority,
		req.FrequencyType, req.FrequencyValue, req.AdvanceDays, req.EstimatedHours,
		req.Instructions, checklist, req.SafetyNotes, toolsReq, reqParts,
		req.ApplyToChildren, id, claims.TenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Plantilla no encontrada")
	}

	return c.JSON(fiber.Map{"message": "Plantilla actualizada"})
}

// ─── DELETE /maintenance-plan-templates/:id ──────────────────────────────────

func (h *MaintenancePlanTemplateHandler) Delete(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	result, err := h.db.Exec(c.UserContext(),
		`DELETE FROM maintenance_plan_templates WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Plantilla no encontrada")
	}

	return c.JSON(fiber.Map{"message": "Plantilla eliminada"})
}

// ─── POST /maintenance-plan-templates/from-plan/:planId ──────────────────────

func (h *MaintenancePlanTemplateHandler) SaveFromPlan(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	planID, err := strconv.ParseInt(c.Params("planId"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req struct {
		Name string `json:"name"`
	}
	if err := c.BodyParser(&req); err != nil || req.Name == "" {
		return fiber.NewError(fiber.StatusBadRequest, "El nombre es obligatorio")
	}

	var newID int64
	err = h.db.QueryRow(c.UserContext(),
		`INSERT INTO maintenance_plan_templates
		 (tenant_id, name, description, wo_type, priority,
		  frequency_type, frequency_value, advance_days, estimated_hours,
		  instructions, checklist, safety_notes, tools_required, required_parts,
		  apply_to_children, created_by)
		 SELECT $1, $3, mp.description, mp.wo_type, mp.priority,
		        mp.frequency_type, mp.frequency_value, mp.advance_days, mp.estimated_hours,
		        mp.instructions, COALESCE(mp.checklist,'[]'), mp.safety_notes,
		        COALESCE(mp.tools_required,'[]'), COALESCE(mp.required_parts,'[]'),
		        mp.apply_to_children, $4
		 FROM maintenance_plans mp
		 WHERE mp.id = $2 AND mp.tenant_id = $1
		 RETURNING id`,
		claims.TenantID, planID, req.Name, claims.UserID,
	).Scan(&newID)
	if err != nil {
		return fiber.NewError(fiber.StatusConflict, "No se pudo crear la plantilla (nombre duplicado o plan no encontrado)")
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"id":      newID,
		"message": "Plantilla creada desde plan",
	})
}
