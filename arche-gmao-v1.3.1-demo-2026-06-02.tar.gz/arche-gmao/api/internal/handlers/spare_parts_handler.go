package handlers

import (
	"context"
	"strconv"

	"arche-gmao/api/internal/ai"
	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type SparePartsHandler struct {
	db *pgxpool.Pool
}

func NewSparePartsHandler(db *pgxpool.Pool) *SparePartsHandler {
	return &SparePartsHandler{db: db}
}

type SparePartResponse struct {
	ID           int64    `json:"id"`
	TenantID     int64    `json:"tenant_id"`
	Code         string   `json:"code"`
	Name         string   `json:"name"`
	Category     string   `json:"category"`
	Unit         string   `json:"unit"`
	CurrentStock float64  `json:"current_stock"`
	MinStock     float64  `json:"min_stock"`
	MaxStock     *float64 `json:"max_stock"`
	Location     *string  `json:"location"`
	Supplier     *string  `json:"supplier"`
	SupplierRef  *string  `json:"supplier_ref"`
	UnitPrice    *float64 `json:"unit_price"`
	LeadDays     *int     `json:"lead_days"`
	Notes        *string  `json:"notes"`
	IsActive     bool     `json:"is_active"`
	LowStock     bool     `json:"low_stock"`
	CreatedAt    string   `json:"created_at"`
	UpdatedAt    string   `json:"updated_at"`
}

func (h *SparePartsHandler) List(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	category := c.Query("category")
	lowStock := c.Query("low_stock") == "true"
	nodeIDStr := c.Query("node_id")

	query := `SELECT sp.id, sp.tenant_id, sp.code, sp.name, sp.category, sp.unit,
	                 sp.current_stock, sp.min_stock, sp.max_stock,
	                 sp.location, sp.supplier, sp.supplier_ref,
	                 sp.unit_price, sp.lead_days, sp.notes, sp.is_active,
	                 (sp.current_stock <= sp.min_stock) as low_stock,
	                 sp.created_at::text, sp.updated_at::text
	          FROM spare_parts sp`

	args := []interface{}{claims.TenantID}
	argIdx := 2
	conditions := []string{"sp.tenant_id = $1", "sp.is_active = true"}

	if category != "" {
		conditions = append(conditions, "sp.category = $"+strconv.Itoa(argIdx))
		args = append(args, category)
		argIdx++
	}
	if lowStock {
		conditions = append(conditions, "sp.current_stock <= sp.min_stock")
	}
	if nodeIDStr != "" {
		nodeID, err := strconv.ParseInt(nodeIDStr, 10, 64)
		if err != nil {
			return fiber.NewError(fiber.StatusBadRequest, "node_id inválido")
		}
		query += ` JOIN spare_part_nodes spn ON spn.spare_part_id = sp.id`
		conditions = append(conditions, "spn.node_id = $"+strconv.Itoa(argIdx))
		args = append(args, nodeID)
		argIdx++
	}

	query += " WHERE " + conditions[0]
	for _, c := range conditions[1:] {
		query += " AND " + c
	}
	query += " ORDER BY sp.name"

	rows, err := h.db.Query(c.UserContext(), query, args...)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando repuestos")
	}
	defer rows.Close()

	var parts []SparePartResponse
	for rows.Next() {
		var sp SparePartResponse
		if err := rows.Scan(
			&sp.ID, &sp.TenantID, &sp.Code, &sp.Name, &sp.Category, &sp.Unit,
			&sp.CurrentStock, &sp.MinStock, &sp.MaxStock,
			&sp.Location, &sp.Supplier, &sp.SupplierRef,
			&sp.UnitPrice, &sp.LeadDays, &sp.Notes, &sp.IsActive,
			&sp.LowStock, &sp.CreatedAt, &sp.UpdatedAt,
		); err == nil {
			parts = append(parts, sp)
		}
	}

	return c.JSON(fiber.Map{"spare_parts": parts, "total": len(parts)})
}

func (h *SparePartsHandler) GetOne(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var sp SparePartResponse
	err = h.db.QueryRow(c.UserContext(),
		`SELECT id, tenant_id, code, name, category, unit,
		        current_stock, min_stock, max_stock,
		        location, supplier, supplier_ref,
		        unit_price, lead_days, notes, is_active,
		        (current_stock <= min_stock), created_at::text, updated_at::text
		 FROM spare_parts WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	).Scan(
		&sp.ID, &sp.TenantID, &sp.Code, &sp.Name, &sp.Category, &sp.Unit,
		&sp.CurrentStock, &sp.MinStock, &sp.MaxStock,
		&sp.Location, &sp.Supplier, &sp.SupplierRef,
		&sp.UnitPrice, &sp.LeadDays, &sp.Notes, &sp.IsActive,
		&sp.LowStock, &sp.CreatedAt, &sp.UpdatedAt,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Repuesto no encontrado")
	}

	// Recent movements
	movRows, _ := h.db.Query(c.UserContext(),
		`SELECT sm.id, sm.movement_type, sm.quantity, sm.unit_cost,
		        sm.stock_before, sm.stock_after, sm.notes,
		        u.full_name, sm.created_at::text
		 FROM stock_movements sm LEFT JOIN users u ON u.id = sm.created_by AND u.tenant_id = sm.tenant_id
		 WHERE sm.spare_part_id=$1 AND sm.tenant_id=$2 ORDER BY sm.created_at DESC LIMIT 20`,
		id, claims.TenantID,
	)
	type Movement struct {
		ID           int64    `json:"id"`
		MovementType string   `json:"movement_type"`
		Quantity     float64  `json:"quantity"`
		UnitCost     *float64 `json:"unit_cost"`
		StockBefore  float64  `json:"stock_before"`
		StockAfter   float64  `json:"stock_after"`
		Notes        *string  `json:"notes"`
		CreatedBy    *string  `json:"created_by"`
		CreatedAt    string   `json:"created_at"`
	}
	var movements []Movement
	if movRows != nil {
		defer movRows.Close()
		for movRows.Next() {
			var m Movement
			if err := movRows.Scan(&m.ID, &m.MovementType, &m.Quantity, &m.UnitCost,
				&m.StockBefore, &m.StockAfter, &m.Notes, &m.CreatedBy, &m.CreatedAt); err == nil {
				movements = append(movements, m)
			}
		}
	}

	return c.JSON(fiber.Map{"spare_part": sp, "movements": movements})
}

type sparePartRequest struct {
	Code        string   `json:"code"`
	Name        string   `json:"name"`
	Category    string   `json:"category"`
	Unit        string   `json:"unit"`
	MinStock    float64  `json:"min_stock"`
	MaxStock    *float64 `json:"max_stock"`
	Location    *string  `json:"location"`
	Supplier    *string  `json:"supplier"`
	SupplierRef *string  `json:"supplier_ref"`
	UnitPrice   *float64 `json:"unit_price"`
	LeadDays    *int     `json:"lead_days"`
	Notes       *string  `json:"notes"`
}

func (h *SparePartsHandler) Create(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	var req sparePartRequest
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}
	if req.Code == "" || req.Name == "" {
		return fiber.NewError(fiber.StatusBadRequest, "Código y nombre son requeridos")
	}
	if req.Category == "" {
		req.Category = "other"
	}
	if req.Unit == "" {
		req.Unit = "unit"
	}

	var newID int64
	err := h.db.QueryRow(c.UserContext(),
		`INSERT INTO spare_parts (tenant_id, code, name, category, unit, min_stock, max_stock,
		 location, supplier, supplier_ref, unit_price, lead_days, notes)
		 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING id`,
		claims.TenantID, req.Code, req.Name, req.Category, req.Unit, req.MinStock, req.MaxStock,
		req.Location, req.Supplier, req.SupplierRef, req.UnitPrice, req.LeadDays, req.Notes,
	).Scan(&newID)
	if err != nil {
		return fiber.NewError(fiber.StatusConflict, "El código ya existe o datos inválidos")
	}

	// Queue AI indexing (independent context so it is not cancelled with the request)
	ai.EnqueueNow(context.Background(), h.db, claims.TenantID, "index", "spare_part", newID)

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": newID, "message": "Repuesto creado"})
}

func (h *SparePartsHandler) Update(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}
	var req sparePartRequest
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	result, err := h.db.Exec(c.UserContext(),
		`UPDATE spare_parts SET name=$1, category=$2, unit=$3, min_stock=$4, max_stock=$5,
		        location=$6, supplier=$7, supplier_ref=$8, unit_price=$9, lead_days=$10, notes=$11
		 WHERE id=$12 AND tenant_id=$13`,
		req.Name, req.Category, req.Unit, req.MinStock, req.MaxStock,
		req.Location, req.Supplier, req.SupplierRef, req.UnitPrice, req.LeadDays, req.Notes,
		id, claims.TenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Repuesto no encontrado")
	}

	// Queue AI re-indexing
	ai.EnqueueNow(context.Background(), h.db, claims.TenantID, "reindex", "spare_part", id)

	return c.JSON(fiber.Map{"message": "Repuesto actualizado"})
}

// POST /factory/nodes/:id/spare-parts — attach a spare part to a node
func (h *SparePartsHandler) LinkToNode(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID de nodo inválido")
	}

	var req struct {
		SparePartID int64 `json:"spare_part_id"`
	}
	if err := c.BodyParser(&req); err != nil || req.SparePartID == 0 {
		return fiber.NewError(fiber.StatusBadRequest, "El repuesto es requerido")
	}

	// Check that the node belongs to the tenant
	var nodeExists bool
	h.db.QueryRow(c.UserContext(),
		`SELECT EXISTS(SELECT 1 FROM factory_nodes WHERE id=$1 AND tenant_id=$2)`,
		nodeID, claims.TenantID,
	).Scan(&nodeExists)
	if !nodeExists {
		return fiber.NewError(fiber.StatusNotFound, "Nodo no encontrado")
	}

	// Check that the spare part belongs to the tenant
	var exists bool
	h.db.QueryRow(c.UserContext(),
		`SELECT EXISTS(SELECT 1 FROM spare_parts WHERE id=$1 AND tenant_id=$2)`,
		req.SparePartID, claims.TenantID,
	).Scan(&exists)
	if !exists {
		return fiber.NewError(fiber.StatusNotFound, "Repuesto no encontrado")
	}

	_, err = h.db.Exec(c.UserContext(),
		`INSERT INTO spare_part_nodes (spare_part_id, node_id)
		 VALUES ($1,$2) ON CONFLICT DO NOTHING`,
		req.SparePartID, nodeID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error asociando repuesto")
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"message": "Repuesto asociado al nodo"})
}

// DELETE /factory/nodes/:id/spare-parts/:spareId — detach a spare part from a node
func (h *SparePartsHandler) UnlinkFromNode(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID de nodo inválido")
	}
	spareID, err := strconv.ParseInt(c.Params("spareId"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID de repuesto inválido")
	}

	// Check that the node belongs to the tenant
	var nodeExists bool
	h.db.QueryRow(c.UserContext(),
		`SELECT EXISTS(SELECT 1 FROM factory_nodes WHERE id=$1 AND tenant_id=$2)`,
		nodeID, claims.TenantID,
	).Scan(&nodeExists)
	if !nodeExists {
		return fiber.NewError(fiber.StatusNotFound, "Nodo no encontrado")
	}

	result, err := h.db.Exec(c.UserContext(),
		`DELETE FROM spare_part_nodes WHERE spare_part_id=$1 AND node_id=$2`,
		spareID, nodeID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Asociación no encontrada")
	}

	return c.JSON(fiber.Map{"message": "Repuesto desasociado del nodo"})
}

// POST /spare-parts/:id/movements - record a stock movement
func (h *SparePartsHandler) AddMovement(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req struct {
		MovementType string   `json:"movement_type"`
		Quantity     float64  `json:"quantity"`
		UnitCost     *float64 `json:"unit_cost"`
		Notes        *string  `json:"notes"`
	}
	if err := c.BodyParser(&req); err != nil || req.Quantity <= 0 {
		return fiber.NewError(fiber.StatusBadRequest, "Tipo y cantidad son requeridos")
	}

	// Start a transaction so stock is read FOR UPDATE and updated atomically
	tx, err := h.db.Begin(c.UserContext())
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error iniciando transacción")
	}
	defer tx.Rollback(c.UserContext())

	var currentStock float64
	err = tx.QueryRow(c.UserContext(),
		`SELECT current_stock FROM spare_parts WHERE id=$1 AND tenant_id=$2 FOR UPDATE`,
		id, claims.TenantID,
	).Scan(&currentStock)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Repuesto no encontrado")
	}

	var newStock float64
	switch req.MovementType {
	case "purchase", "return", "adjustment":
		newStock = currentStock + req.Quantity
	case "consumption", "manual_out", "transfer":
		if currentStock < req.Quantity {
			return fiber.NewError(fiber.StatusBadRequest,
				"Stock insuficiente. Disponible: "+strconv.FormatFloat(currentStock, 'f', 3, 64))
		}
		newStock = currentStock - req.Quantity
	default:
		return fiber.NewError(fiber.StatusBadRequest, "Tipo de movimiento inválido")
	}

	_, err = tx.Exec(c.UserContext(),
		`UPDATE spare_parts SET current_stock=$1 WHERE id=$2 AND tenant_id=$3`,
		newStock, id, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error actualizando stock")
	}

	var movID int64
	err = tx.QueryRow(c.UserContext(),
		`INSERT INTO stock_movements (tenant_id, spare_part_id, movement_type, quantity,
		 unit_cost, stock_before, stock_after, notes, created_by)
		 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`,
		claims.TenantID, id, req.MovementType, req.Quantity,
		req.UnitCost, currentStock, newStock, req.Notes, claims.UserID,
	).Scan(&movID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error registrando movimiento")
	}

	if err := tx.Commit(c.UserContext()); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error confirmando transacción")
	}
	// Notify when stock dropped below the minimum (in-app + push)
	go func() {
		var minStock float64
		var spName string
		h.db.QueryRow(context.Background(),
			`SELECT min_stock, name FROM spare_parts WHERE id=$1 AND tenant_id=$2`, id, claims.TenantID,
		).Scan(&minStock, &spName)
		if newStock <= minStock {
			link := "/inventory"
			ps := GetGlobalPushService()
			for _, role := range []string{"supervisor", "warehouse"} {
				NotifyRole(h.db, ps, claims.TenantID, role,
					"stock_low",
					"Stock bajo: "+spName,
					"El repuesto '"+spName+"' ha bajado del nivel minimo.",
					&link)
			}
		}
	}()
	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"id":          movID,
		"new_stock":   newStock,
		"stock_delta": newStock - currentStock,
		"message":     "Movimiento registrado",
	})
}
