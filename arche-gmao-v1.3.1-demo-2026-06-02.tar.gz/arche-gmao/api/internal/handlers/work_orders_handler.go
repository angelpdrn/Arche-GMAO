package handlers

import (
	"context"
	"fmt"
	stdlog "log"
	"strconv"
	"time"

	"arche-gmao/api/internal/ai"
	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type WorkOrdersHandler struct {
	db              *pgxpool.Pool
	staggerService  *ai.StaggeringService
}

func NewWorkOrdersHandler(db *pgxpool.Pool, staggerService *ai.StaggeringService) *WorkOrdersHandler {
	return &WorkOrdersHandler{db: db, staggerService: staggerService}
}

type WorkOrderResponse struct {
	ID             int64    `json:"id"`
	TenantID       int64    `json:"tenant_id"`
	NodeID         int64    `json:"node_id"`
	NodeName       string   `json:"node_name"`
	WONumber       string   `json:"wo_number"`
	Title          string   `json:"title"`
	Description    *string  `json:"description"`
	WOType         string   `json:"wo_type"`
	Priority       string   `json:"priority"`
	Status         string   `json:"status"`
	AssignedTo     *int64   `json:"assigned_to"`
	AssignedName   *string  `json:"assigned_name"`
	CreatedBy      *int64   `json:"created_by"`
	CreatedByName  *string  `json:"created_by_name"`
	EstimatedHours *float64 `json:"estimated_hours"`
	ActualHours    *float64 `json:"actual_hours"`
	PlannedStart   *string  `json:"planned_start"`
	PlannedEnd     *string  `json:"planned_end"`
	StartedAt      *string  `json:"started_at"`
	CompletedAt    *string  `json:"completed_at"`
	ClosedAt       *string  `json:"closed_at"`
	RootCause          *string  `json:"root_cause"`
	RootCauseCode      *string  `json:"root_cause_code"`
	Solution           *string  `json:"solution"`
	AccumulatedMinutes int      `json:"accumulated_minutes"`
	HoursEditedBy      *int64   `json:"hours_edited_by"`
	HoursEditedByName  *string  `json:"hours_edited_by_name"`
	HoursEditedAt      *string  `json:"hours_edited_at"`
	Version            int      `json:"version"`
	CreatedAt          string   `json:"created_at"`
	UpdatedAt          string   `json:"updated_at"`
}

// ─── GET /work-orders ─────────────────────────────────────────────────────────

func (h *WorkOrdersHandler) List(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	// Optional filters
	status := c.Query("status")
	woType := c.Query("type")
	priority := c.Query("priority")
	nodeIDStr := c.Query("node_id")

	query := `
		SELECT wo.id, wo.tenant_id, wo.node_id, fn.name,
		       wo.wo_number, wo.title, wo.description,
		       wo.wo_type, wo.priority, wo.status,
		       wo.assigned_to, ua.full_name,
		       wo.created_by, uc.full_name,
		       wo.estimated_hours, wo.actual_hours,
		       wo.planned_start::text, wo.planned_end::text,
		       wo.started_at::text, wo.completed_at::text, wo.closed_at::text,
		       wo.root_cause, wo.solution, wo.accumulated_minutes,
		       wo.hours_edited_by, uhe.full_name, wo.hours_edited_at::text,
		       wo.version, wo.created_at::text, wo.updated_at::text
		FROM work_orders wo
		JOIN factory_nodes fn ON fn.id = wo.node_id
		LEFT JOIN users ua ON ua.id = wo.assigned_to
		LEFT JOIN users uc ON uc.id = wo.created_by
		LEFT JOIN users uhe ON uhe.id = wo.hours_edited_by
		WHERE wo.tenant_id = $1`

	args := []interface{}{claims.TenantID}
	argIdx := 2

	if status != "" {
		query += ` AND wo.status = $` + strconv.Itoa(argIdx)
		args = append(args, status)
		argIdx++
	}
	if woType != "" {
		query += ` AND wo.wo_type = $` + strconv.Itoa(argIdx)
		args = append(args, woType)
		argIdx++
	}
	if priority != "" {
		query += ` AND wo.priority = $` + strconv.Itoa(argIdx)
		args = append(args, priority)
		argIdx++
	}
	if nodeIDStr != "" {
		nodeID, err := strconv.ParseInt(nodeIDStr, 10, 64)
		if err != nil {
			return fiber.NewError(fiber.StatusBadRequest, "node_id inválido")
		}
		query += ` AND wo.node_id = $` + strconv.Itoa(argIdx)
		args = append(args, nodeID)
		argIdx++
	}

	// Filter: assigned_to (for smart filters)
	assignedToStr := c.Query("assigned_to")
	if assignedToStr != "" {
		assignedToID, parseErr := strconv.ParseInt(assignedToStr, 10, 64)
		if parseErr == nil {
			query += ` AND wo.assigned_to = $` + strconv.Itoa(argIdx)
			args = append(args, assignedToID)
			argIdx++
		}
	}

	// Filter: overdue (overdue WOs)
	if c.Query("overdue") == "true" {
		query += ` AND wo.planned_end < NOW() AND wo.status NOT IN ('completed','verified','closed','cancelled') AND wo.planned_end IS NOT NULL`
	}

	// Roles with a limited scope: they only see WOs on their assigned nodes (children included via ltree),
	// or WOs assigned to them, or WOs they created.
	// Admin and auditor see everything.
	if claims.Role != "admin" && claims.Role != "auditor" {
		query += ` AND (wo.assigned_to = $` + strconv.Itoa(argIdx) +
			` OR wo.created_by = $` + strconv.Itoa(argIdx) +
			` OR wo.node_id IN (
				SELECT fn.id FROM factory_nodes fn
				JOIN node_assignments na ON na.user_id = $` + strconv.Itoa(argIdx) + ` AND na.tenant_id = $1
				JOIN factory_nodes assigned ON assigned.id = na.node_id AND assigned.tenant_id = $1
				WHERE fn.tenant_id = $1 AND fn.path <@ assigned.path
			))`
		args = append(args, claims.UserID)
		argIdx++
	}

	limit := 100
	if l, err := strconv.Atoi(c.Query("limit")); err == nil && l > 0 && l <= 500 {
		limit = l
	}
	offset := 0
	if o, err := strconv.Atoi(c.Query("offset")); err == nil && o >= 0 {
		offset = o
	}
	query += ` ORDER BY wo.created_at DESC LIMIT $` + strconv.Itoa(argIdx) + ` OFFSET $` + strconv.Itoa(argIdx+1)
	args = append(args, limit, offset)
	argIdx += 2

	rows, err := h.db.Query(c.UserContext(), query, args...)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando OTs")
	}
	defer rows.Close()

	var wos []WorkOrderResponse
	for rows.Next() {
		var wo WorkOrderResponse
		if err := rows.Scan(
			&wo.ID, &wo.TenantID, &wo.NodeID, &wo.NodeName,
			&wo.WONumber, &wo.Title, &wo.Description,
			&wo.WOType, &wo.Priority, &wo.Status,
			&wo.AssignedTo, &wo.AssignedName,
			&wo.CreatedBy, &wo.CreatedByName,
			&wo.EstimatedHours, &wo.ActualHours,
			&wo.PlannedStart, &wo.PlannedEnd,
			&wo.StartedAt, &wo.CompletedAt, &wo.ClosedAt,
			&wo.RootCause, &wo.Solution, &wo.AccumulatedMinutes,
			&wo.HoursEditedBy, &wo.HoursEditedByName, &wo.HoursEditedAt,
			&wo.Version, &wo.CreatedAt, &wo.UpdatedAt,
		); err == nil {
			wos = append(wos, wo)
		}
	}

	return c.JSON(fiber.Map{"work_orders": wos, "total": len(wos)})
}

// ─── GET /work-orders/:id ─────────────────────────────────────────────────────

func (h *WorkOrdersHandler) GetOne(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	// Check access to the WO for roles with a limited scope
	if claims.Role != "admin" && claims.Role != "auditor" {
		var hasAccess bool
		h.db.QueryRow(c.UserContext(),
			`SELECT EXISTS(
				SELECT 1 FROM work_orders wo
				WHERE wo.id=$1 AND wo.tenant_id=$2
				  AND (wo.assigned_to=$3 OR wo.created_by=$3
				       OR wo.node_id IN (
				           SELECT fn.id FROM factory_nodes fn
				           JOIN node_assignments na ON na.user_id=$3 AND na.tenant_id=$2
				           JOIN factory_nodes assigned ON assigned.id=na.node_id AND assigned.tenant_id=$2
				           WHERE fn.tenant_id=$2 AND fn.path <@ assigned.path
				       ))
			)`, id, claims.TenantID, claims.UserID,
		).Scan(&hasAccess)
		if !hasAccess {
			return fiber.NewError(fiber.StatusForbidden, "No tienes acceso a esta OT")
		}
	}

	var wo WorkOrderResponse
	err = h.db.QueryRow(c.UserContext(),
		`SELECT wo.id, wo.tenant_id, wo.node_id, fn.name,
		        wo.wo_number, wo.title, wo.description,
		        wo.wo_type, wo.priority, wo.status,
		        wo.assigned_to, ua.full_name,
		        wo.created_by, uc.full_name,
		        wo.estimated_hours, wo.actual_hours,
		        wo.planned_start::text, wo.planned_end::text,
		        wo.started_at::text, wo.completed_at::text, wo.closed_at::text,
		        wo.root_cause, wo.root_cause_code, wo.solution, wo.accumulated_minutes,
		        wo.hours_edited_by, uhe.full_name, wo.hours_edited_at::text,
		        wo.version, wo.created_at::text, wo.updated_at::text
		 FROM work_orders wo
		 JOIN factory_nodes fn ON fn.id = wo.node_id
		 LEFT JOIN users ua ON ua.id = wo.assigned_to
		 LEFT JOIN users uc ON uc.id = wo.created_by
		 LEFT JOIN users uhe ON uhe.id = wo.hours_edited_by
		 WHERE wo.id = $1 AND wo.tenant_id = $2`,
		id, claims.TenantID,
	).Scan(
		&wo.ID, &wo.TenantID, &wo.NodeID, &wo.NodeName,
		&wo.WONumber, &wo.Title, &wo.Description,
		&wo.WOType, &wo.Priority, &wo.Status,
		&wo.AssignedTo, &wo.AssignedName,
		&wo.CreatedBy, &wo.CreatedByName,
		&wo.EstimatedHours, &wo.ActualHours,
		&wo.PlannedStart, &wo.PlannedEnd,
		&wo.StartedAt, &wo.CompletedAt, &wo.ClosedAt,
		&wo.RootCause, &wo.RootCauseCode, &wo.Solution, &wo.AccumulatedMinutes,
		&wo.HoursEditedBy, &wo.HoursEditedByName, &wo.HoursEditedAt,
		&wo.Version, &wo.CreatedAt, &wo.UpdatedAt,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "OT no encontrada")
	}

	// WO log
	logRows, err := h.db.Query(c.UserContext(),
		`SELECT wl.id, wl.user_id, u.full_name, wl.from_status, wl.to_status, wl.comment, wl.created_at::text
		 FROM work_order_log wl LEFT JOIN users u ON u.id = wl.user_id
		 WHERE wl.wo_id = $1 AND wl.tenant_id = $2 ORDER BY wl.created_at ASC`, id, claims.TenantID,
	)
	type LogEntry struct {
		ID         int64   `json:"id"`
		UserID     *int64  `json:"user_id"`
		UserName   *string `json:"user_name"`
		FromStatus *string `json:"from_status"`
		ToStatus   string  `json:"to_status"`
		Comment    *string `json:"comment"`
		CreatedAt  string  `json:"created_at"`
	}
	var log []LogEntry
	if logRows != nil {
		defer logRows.Close()
		for logRows.Next() {
			var e LogEntry
			if err := logRows.Scan(&e.ID, &e.UserID, &e.UserName, &e.FromStatus, &e.ToStatus, &e.Comment, &e.CreatedAt); err != nil {
				stdlog.Printf("[ARCHE-WO] WARN: scan log entry: %v", err)
				continue
			}
			log = append(log, e)
		}
	}

	// Comments
	commentRows, err := h.db.Query(c.UserContext(),
		`SELECT wc.id, wc.user_id, u.full_name, wc.content, wc.created_at::text
		 FROM work_order_comments wc LEFT JOIN users u ON u.id = wc.user_id
		 WHERE wc.wo_id = $1 AND wc.tenant_id = $2 ORDER BY wc.created_at ASC`, id, claims.TenantID,
	)
	type Comment struct {
		ID        int64   `json:"id"`
		UserID    *int64  `json:"user_id"`
		UserName  *string `json:"user_name"`
		Content   string  `json:"content"`
		CreatedAt string  `json:"created_at"`
	}
	var comments []Comment
	if commentRows != nil {
		defer commentRows.Close()
		for commentRows.Next() {
			var cm Comment
			if err := commentRows.Scan(&cm.ID, &cm.UserID, &cm.UserName, &cm.Content, &cm.CreatedAt); err != nil {
				stdlog.Printf("[ARCHE-WO] WARN: scan comment: %v", err)
				continue
			}
			comments = append(comments, cm)
		}
	}

	return c.JSON(fiber.Map{
		"work_order": wo,
		"log":        log,
		"comments":   comments,
	})
}

// ─── POST /work-orders ────────────────────────────────────────────────────────

type createWORequest struct {
	NodeID         int64    `json:"node_id"`
	Title          string   `json:"title"`
	Description    *string  `json:"description"`
	WOType         string   `json:"wo_type"`
	Priority       string   `json:"priority"`
	AssignedTo     *int64   `json:"assigned_to"`
	EstimatedHours *float64 `json:"estimated_hours"`
	PlannedStart   *string  `json:"planned_start"`
	PlannedEnd     *string  `json:"planned_end"`
}

func (h *WorkOrdersHandler) Create(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req createWORequest
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}
	if req.Title == "" || req.NodeID == 0 {
		return fiber.NewError(fiber.StatusBadRequest, "Título y nodo son requeridos")
	}
	if req.WOType == "" {
		req.WOType = "corrective"
	}
	if req.Priority == "" {
		req.Priority = "medium"
	}

	// Validate that the node exists in this tenant before going any further
	// (avoids a 500 when the INSERT violates the FK)
	var nodeCriticality string
	if err := h.db.QueryRow(c.UserContext(),
		`SELECT criticality FROM factory_nodes WHERE id=$1 AND tenant_id=$2`,
		req.NodeID, claims.TenantID,
	).Scan(&nodeCriticality); err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Nodo no encontrado o sin acceso")
	}

	// Critical equipment + corrective → automatic critical priority (RN-OT-02)
	if req.WOType == "corrective" && nodeCriticality == "critical" {
		req.Priority = "critical"
	}

	// Validate the assigned technician (when there is one) before continuing
	if req.AssignedTo != nil {
		var assigneeOK int
		_ = h.db.QueryRow(c.UserContext(),
			`SELECT 1 FROM users WHERE id=$1 AND tenant_id=$2 AND status='active'`,
			req.AssignedTo, claims.TenantID,
		).Scan(&assigneeOK)
		if assigneeOK != 1 {
			return fiber.NewError(fiber.StatusBadRequest, "Usuario asignado no encontrado")
		}
	}

	initialStatus := "pending"
	if req.WOType == "preventive" {
		initialStatus = "assigned"
	}

	// Auto-assign to the node's primary staff when assigned_to is not given
	if req.AssignedTo == nil {
		var primaryUserID int64
		err := h.db.QueryRow(c.UserContext(),
			`SELECT na.user_id FROM node_assignments na
			 JOIN users u ON u.id = na.user_id
			 WHERE na.node_id=$1 AND na.tenant_id=$2 AND na.is_primary=true AND u.status='active'
			 LIMIT 1`,
			req.NodeID, claims.TenantID,
		).Scan(&primaryUserID)
		if err == nil && primaryUserID > 0 {
			req.AssignedTo = &primaryUserID
			if initialStatus == "pending" {
				initialStatus = "assigned"
			}
		}
	}

	// Number generation and the INSERT happen in the SAME transaction with
	// pg_advisory_xact_lock, to avoid duplicate wo_numbers under concurrency.
	tx, txErr := h.db.Begin(c.UserContext())
	if txErr != nil {
		stdlog.Printf("[ARCHE-WO] error iniciando tx: %v", txErr)
		return fiber.NewError(fiber.StatusInternalServerError, "Error creando OT")
	}
	defer tx.Rollback(c.UserContext())

	if _, lockErr := tx.Exec(c.UserContext(), `SELECT pg_advisory_xact_lock($1)`, claims.TenantID); lockErr != nil {
		stdlog.Printf("[ARCHE-WO] error en advisory lock: %v", lockErr)
		return fiber.NewError(fiber.StatusInternalServerError, "Error creando OT")
	}

	var woNumber string
	if err := tx.QueryRow(c.UserContext(), `
		SELECT generate_wo_number_prefix() || LPAD(
			(COALESCE((SELECT MAX(CAST(SUBSTRING(wo_number FROM 13) AS INT)) FROM work_orders
			 WHERE tenant_id=$1 AND wo_number LIKE generate_wo_number_prefix() || '%'), 0) + 1)::text, 4, '0')`,
		claims.TenantID,
	).Scan(&woNumber); err != nil {
		stdlog.Printf("[ARCHE-WO] error generando número: %v", err)
		return fiber.NewError(fiber.StatusInternalServerError, "Error generando número de OT")
	}

	var newID int64
	if err := tx.QueryRow(c.UserContext(),
		`INSERT INTO work_orders
		 (tenant_id, node_id, wo_number, title, description, wo_type, priority, status,
		  assigned_to, created_by, estimated_hours, planned_start, planned_end)
		 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
		 RETURNING id`,
		claims.TenantID, req.NodeID, woNumber, req.Title, req.Description,
		req.WOType, req.Priority, initialStatus,
		req.AssignedTo, claims.UserID, req.EstimatedHours,
		req.PlannedStart, req.PlannedEnd,
	).Scan(&newID); err != nil {
		stdlog.Printf("[ARCHE-WO] error INSERT OT: %v", err)
		return fiber.NewError(fiber.StatusInternalServerError, "Error creando OT")
	}

	// Initial log entry inside the same transaction
	if _, err := tx.Exec(c.UserContext(),
		`INSERT INTO work_order_log (tenant_id, wo_id, user_id, to_status, comment)
		 VALUES ($1,$2,$3,$4,$5)`,
		claims.TenantID, newID, claims.UserID, initialStatus, "OT creada",
	); err != nil {
		stdlog.Printf("[ARCHE-WO] error log inicial: %v", err)
		// we do not abort over the log, but it is worth knowing
	}

	if err := tx.Commit(c.UserContext()); err != nil {
		stdlog.Printf("[ARCHE-WO] error commit: %v", err)
		return fiber.NewError(fiber.StatusInternalServerError, "Error creando OT")
	}

	// Automatic re-staggering: when a corrective WO is created, move that node's
	// pending staggered preventive work to the next free slot
	if req.WOType == "corrective" && h.staggerService != nil {
		go func() {
			ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
			defer cancel()
			count, err := h.staggerService.RescheduleNode(ctx, claims.TenantID, req.NodeID)
			if err != nil {
				stdlog.Printf("[ARCHE-STAGGER] Error reescalonando nodo %d: %v", req.NodeID, err)
			} else if count > 0 {
				stdlog.Printf("[ARCHE-STAGGER] %d preventivo(s) reescalonado(s) para nodo %d por OT correctiva", count, req.NodeID)
			}
		}()
	}

	// Notify the assigned technician (in-app + push)
	if req.AssignedTo != nil && *req.AssignedTo != claims.UserID {
		go func() {
			var nodeName string
			h.db.QueryRow(context.Background(),
				`SELECT name FROM factory_nodes WHERE id=$1 AND tenant_id=$2`,
				req.NodeID, claims.TenantID,
			).Scan(&nodeName)
			link := "/work-orders"
			Notify(h.db, GetGlobalPushService(), claims.TenantID, *req.AssignedTo,
				"wo_assigned",
				"Nueva OT asignada: "+woNumber,
				"Se te ha asignado: "+req.Title+" — "+nodeName,
				&link)
		}()
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": newID, "wo_number": woNumber, "message": "OT creada correctamente"})
}

// ─── PATCH /work-orders/:id/status ───────────────────────────────────────────

type changeStatusRequest struct {
	Status        string   `json:"status"`
	Comment       *string  `json:"comment"`
	ActualHours   *float64 `json:"actual_hours"`
	RootCause     *string  `json:"root_cause"`
	RootCauseCode *string  `json:"root_cause_code"`
	Solution      *string  `json:"solution"`
	Version       int      `json:"version"`
}

// rootCauseCodes mirrors the allow-list of the CHECK in migration 037.
var rootCauseCodes = map[string]bool{
	"mechanical": true, "electrical": true, "electronic": true,
	"hydraulic": true, "pneumatic": true, "lubrication": true,
	"wear": true, "parameters": true, "operation": true,
	"environment": true, "supply": true, "unknown": true, "other": true,
}

// Transitions allowed per state
var allowedTransitions = map[string][]string{
	"draft":       {"pending", "cancelled"},
	"pending":     {"approved", "rejected", "cancelled"},
	"approved":    {"assigned", "cancelled"},
	"assigned":    {"in_progress", "paused", "cancelled"},
	"in_progress": {"completed", "paused", "cancelled"},
	"paused":      {"in_progress", "cancelled"},
	"completed":   {"verified", "closed"},
	"verified":    {"closed"},
	"rejected":    {"pending"},
	"cancelled":   {},
	"closed":      {},
}

// Roles allowed for each destination transition
var transitionRoles = map[string][]string{
	"pending":     {"admin", "supervisor", "technician", "operator"},
	"approved":    {"admin", "supervisor"},
	"rejected":    {"admin", "supervisor"},
	"assigned":    {"admin", "supervisor"},
	"in_progress": {"admin", "supervisor", "technician", "operator"},
	"completed":   {"admin", "supervisor", "technician", "operator"},
	"verified":    {"admin", "supervisor"},
	"paused":      {"admin", "supervisor", "technician", "operator"},
	"closed":      {"admin", "supervisor"},
	"cancelled":   {"admin", "supervisor"},
}

func (h *WorkOrdersHandler) ChangeStatus(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	// Check access to the WO for roles with a limited scope
	if claims.Role != "admin" && claims.Role != "auditor" {
		var hasAccess bool
		h.db.QueryRow(c.UserContext(),
			`SELECT EXISTS(
				SELECT 1 FROM work_orders wo
				WHERE wo.id=$1 AND wo.tenant_id=$2
				  AND (wo.assigned_to=$3 OR wo.created_by=$3
				       OR wo.node_id IN (
				           SELECT fn.id FROM factory_nodes fn
				           JOIN node_assignments na ON na.user_id=$3 AND na.tenant_id=$2
				           JOIN factory_nodes assigned ON assigned.id=na.node_id AND assigned.tenant_id=$2
				           WHERE fn.tenant_id=$2 AND fn.path <@ assigned.path
				       ))
			)`, id, claims.TenantID, claims.UserID,
		).Scan(&hasAccess)
		if !hasAccess {
			return fiber.NewError(fiber.StatusForbidden, "No tienes acceso a esta OT")
		}
	}

	var req changeStatusRequest
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	// Get the current state
	var currentStatus string
	err = h.db.QueryRow(c.UserContext(),
		`SELECT status FROM work_orders WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	).Scan(&currentStatus)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "OT no encontrada")
	}

	// Check that the transition is allowed
	allowed := allowedTransitions[currentStatus]
	valid := false
	for _, s := range allowed {
		if s == req.Status {
			valid = true
			break
		}
	}
	if !valid {
		return fiber.NewError(fiber.StatusBadRequest,
			"Transición no permitida: "+currentStatus+" → "+req.Status)
	}

	// Check that the user's role can perform this transition
	rolesForTransition := transitionRoles[req.Status]
	roleAllowed := false
	for _, r := range rolesForTransition {
		if r == claims.Role {
			roleAllowed = true
			break
		}
	}
	if !roleAllowed {
		return fiber.NewError(fiber.StatusForbidden,
			"Tu rol ("+claims.Role+") no puede cambiar a estado: "+req.Status)
	}

	// Compute actual_hours
	const (
		hoursModeAuto   = 0 // accumulated_minutes / 60.0
		hoursModeManual = 1 // explicit value
		hoursModeKeep   = 2 // keep actual_hours
	)
	var (
		hoursMode   int
		hoursManual float64
	)
	switch {
	case req.Status == "completed":
		hoursMode = hoursModeAuto
	case req.ActualHours != nil:
		if *req.ActualHours < 0 {
			return fiber.NewError(fiber.StatusBadRequest, "actual_hours debe ser >= 0")
		}
		hoursMode = hoursModeManual
		hoursManual = *req.ActualHours
	default:
		hoursMode = hoursModeKeep
	}

	var hoursEditor *int64
	if hoursMode == hoursModeManual {
		uid := claims.UserID
		hoursEditor = &uid
	}

	if req.RootCauseCode != nil && *req.RootCauseCode != "" && !rootCauseCodes[*req.RootCauseCode] {
		return fiber.NewError(fiber.StatusBadRequest, "Código de causa raíz no válido")
	}

	// Atomic transaction: intervals + status update together, to avoid inconsistencies
	tx, txErr := h.db.Begin(c.UserContext())
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error iniciando transacción")
	}
	defer tx.Rollback(c.UserContext())

	if req.Status == "in_progress" {
		if _, err := tx.Exec(c.UserContext(),
			`INSERT INTO work_order_intervals (tenant_id, wo_id, started_at)
			 VALUES ($1, $2, NOW())`,
			claims.TenantID, id); err != nil {
			stdlog.Printf("[ARCHE-WO] abrir intervalo wo=%d: %v", id, err)
		}
	}
	if req.Status == "paused" || req.Status == "completed" {
		if _, err := tx.Exec(c.UserContext(),
			`UPDATE work_order_intervals
			 SET ended_at = NOW(), ended_reason = $1
			 WHERE wo_id = $2 AND ended_at IS NULL`,
			req.Status, id); err != nil {
			stdlog.Printf("[ARCHE-WO] cerrar intervalo wo=%d: %v", id, err)
		}
		if _, err := tx.Exec(c.UserContext(),
			`UPDATE work_orders SET accumulated_minutes = COALESCE((
				SELECT SUM(EXTRACT(EPOCH FROM (COALESCE(ended_at, NOW()) - started_at)) / 60)::INTEGER
				FROM work_order_intervals WHERE wo_id = $1
			), 0) WHERE id = $1`, id); err != nil {
			stdlog.Printf("[ARCHE-WO] acumular minutos wo=%d: %v", id, err)
		}
	}

	result, err := tx.Exec(c.UserContext(),
		`UPDATE work_orders SET
			status = $1::varchar,
			actual_hours = CASE
				WHEN $7::int = 0 THEN accumulated_minutes / 60.0
				WHEN $7::int = 1 THEN $8::numeric
				ELSE actual_hours
			END,
			hours_edited_by = CASE
				WHEN $7::int = 1 THEN $9::bigint
				ELSE hours_edited_by
			END,
			hours_edited_at = CASE
				WHEN $7::int = 1 THEN NOW()
				ELSE hours_edited_at
			END,
			root_cause      = COALESCE($2, root_cause),
			root_cause_code = COALESCE($10, root_cause_code),
			solution        = COALESCE($3, solution),
			started_at   = CASE WHEN $1::varchar='in_progress' AND started_at IS NULL THEN NOW() ELSE started_at END,
			completed_at = CASE WHEN $1::varchar='completed' THEN NOW() ELSE completed_at END,
			closed_at    = CASE WHEN $1::varchar='closed' THEN NOW() ELSE closed_at END,
			version      = version + 1
		 WHERE id=$4 AND tenant_id=$5 AND version=$6`,
		req.Status, req.RootCause, req.Solution,
		id, claims.TenantID, req.Version,
		hoursMode, hoursManual, hoursEditor,
		req.RootCauseCode,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error actualizando estado")
	}
	if result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusConflict, "No se pudo actualizar. Puede que la OT haya sido modificada por otro usuario.")
	}

	if err := tx.Commit(c.UserContext()); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error confirmando transacción")
	}

	// Record it in the log (immutable history)
	logExecErr(h.db.Exec(c.UserContext(),
		`INSERT INTO work_order_log (tenant_id, wo_id, user_id, from_status, to_status, comment)
		 VALUES ($1,$2,$3,$4,$5,$6)`,
		claims.TenantID, id, claims.UserID, currentStatus, req.Status, req.Comment,
	)).Log("wo-status-log")

	// On completion, auto-verify (there is no longer a manual verification step)
	if req.Status == "completed" {
		logExecErr(h.db.Exec(c.UserContext(),
			`INSERT INTO verification_records (tenant_id, wo_id, submitted_by, verified_by, verified_at, status, confidence_level)
			 SELECT tenant_id, $1, $2, $2, NOW(), 'verified', 5 FROM work_orders WHERE id=$1
			 ON CONFLICT DO NOTHING`,
			id, claims.UserID,
		)).Log("wo-auto-verify")
	}

	// ── Auto-signature: whoever completes signs as technician, whoever closes signs as supervisor ──
	if req.Status == "completed" {
		logExecErr(h.db.Exec(c.UserContext(),
			`UPDATE work_orders SET signed_by=$1, signed_at=NOW()
			 WHERE id=$2 AND tenant_id=$3 AND signed_by IS NULL`,
			claims.UserID, id, claims.TenantID,
		)).Log("wo-auto-sign")
		logExecErr(h.db.Exec(c.UserContext(),
			`INSERT INTO work_order_log (tenant_id, wo_id, user_id, from_status, to_status, comment)
			 VALUES ($1,$2,$3,'completed','completed','Firma digital automática registrada al completar la OT')`,
			claims.TenantID, id, claims.UserID,
		)).Log("wo-auto-sign-log")
	}
	if req.Status == "closed" && (claims.Role == "admin" || claims.Role == "supervisor") {
		logExecErr(h.db.Exec(c.UserContext(),
			`UPDATE work_orders SET supervisor_signed_by=$1, supervisor_signed_at=NOW()
			 WHERE id=$2 AND tenant_id=$3 AND supervisor_signed_by IS NULL`,
			claims.UserID, id, claims.TenantID,
		)).Log("wo-supervisor-sign")
		logExecErr(h.db.Exec(c.UserContext(),
			`INSERT INTO work_order_log (tenant_id, wo_id, user_id, from_status, to_status, comment)
			 VALUES ($1,$2,$3,'closed','closed','Firma de supervisor automática registrada al cerrar la OT')`,
			claims.TenantID, id, claims.UserID,
		)).Log("wo-supervisor-sign-log")
	}

	// Index the WO in RAG on completion or close (so the AI has the history)
	if req.Status == "completed" || req.Status == "closed" {
		ai.EnqueueNow(context.Background(), h.db, claims.TenantID, "index", "work_order", id)
	}

	// Automatic notifications on state change (in-app + push)
	go func() {
		var assignedTo *int64
		var createdBy int64
		var woNumber, title, nodeName string
		h.db.QueryRow(context.Background(),
			`SELECT wo.assigned_to, wo.created_by, wo.wo_number, wo.title, fn.name
			 FROM work_orders wo JOIN factory_nodes fn ON fn.id=wo.node_id
			 WHERE wo.id=$1 AND wo.tenant_id=$2`, id, claims.TenantID,
		).Scan(&assignedTo, &createdBy, &woNumber, &title, &nodeName)
		link := "/work-orders"
		ps := GetGlobalPushService()
		switch req.Status {
		case "assigned":
			if assignedTo != nil && *assignedTo != claims.UserID {
				Notify(h.db, ps, claims.TenantID, *assignedTo,
					"wo_assigned",
					"OT asignada: "+woNumber,
					"Se te ha asignado: "+title+" — "+nodeName,
					&link)
			}
		case "in_progress":
			// Tell the creator that their WO is being worked on
			if createdBy != 0 && createdBy != claims.UserID {
				Notify(h.db, ps, claims.TenantID, createdBy,
					"wo_status_change",
					"OT en progreso: "+woNumber,
					"La OT '"+title+"' ha comenzado a ejecutarse.",
					&link)
			}
		case "completed":
			NotifyRole(h.db, ps, claims.TenantID, "supervisor",
				"wo_status_change",
				"OT completada: "+woNumber,
				"La OT '"+title+"' en "+nodeName+" ha sido completada.",
				&link)
		case "rejected":
			if assignedTo != nil && *assignedTo != claims.UserID {
				Notify(h.db, ps, claims.TenantID, *assignedTo,
					"wo_status_change",
					"OT rechazada: "+woNumber,
					"La OT '"+title+"' ha sido rechazada.",
					&link)
			}
		}
	}()
	return c.JSON(fiber.Map{"message": "Estado actualizado", "new_status": req.Status})
}

// ─── POST /work-orders/:id/comments ──────────────────────────────────────────

func (h *WorkOrdersHandler) AddComment(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	// Check access to the WO for roles with a limited scope
	if claims.Role != "admin" && claims.Role != "auditor" {
		var hasAccess bool
		h.db.QueryRow(c.UserContext(),
			`SELECT EXISTS(
				SELECT 1 FROM work_orders wo
				WHERE wo.id=$1 AND wo.tenant_id=$2
				  AND (wo.assigned_to=$3 OR wo.created_by=$3
				       OR wo.node_id IN (
				           SELECT fn.id FROM factory_nodes fn
				           JOIN node_assignments na ON na.user_id=$3 AND na.tenant_id=$2
				           JOIN factory_nodes assigned ON assigned.id=na.node_id AND assigned.tenant_id=$2
				           WHERE fn.tenant_id=$2 AND fn.path <@ assigned.path
				       ))
			)`, id, claims.TenantID, claims.UserID,
		).Scan(&hasAccess)
		if !hasAccess {
			return fiber.NewError(fiber.StatusForbidden, "No tienes acceso a esta OT")
		}
	}

	var req struct {
		Content string `json:"content"`
	}
	if err := c.BodyParser(&req); err != nil || req.Content == "" {
		return fiber.NewError(fiber.StatusBadRequest, "El contenido es requerido")
	}

	var commentID int64
	err = h.db.QueryRow(c.UserContext(),
		`INSERT INTO work_order_comments (tenant_id, wo_id, user_id, content)
		 SELECT $4, $1, $2, $3
		 WHERE EXISTS (SELECT 1 FROM work_orders WHERE id=$1 AND tenant_id=$4)
		 RETURNING id`,
		id, claims.UserID, req.Content, claims.TenantID,
	).Scan(&commentID)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "OT no encontrada o sin permiso")
	}

	// Re-index the WO in RAG so the new comment is included
	ai.EnqueueNow(context.Background(), h.db, claims.TenantID, "reindex", "work_order", id)

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": commentID, "message": "Comentario añadido"})
}

// ─── PUT /work-orders/:id ─────────────────────────────────────────────────────

func (h *WorkOrdersHandler) Update(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req struct {
		Title          string   `json:"title"`
		Description    *string  `json:"description"`
		Priority       string   `json:"priority"`
		AssignedTo     *int64   `json:"assigned_to"`
		EstimatedHours *float64 `json:"estimated_hours"`
		PlannedStart   *string  `json:"planned_start"`
		PlannedEnd     *string  `json:"planned_end"`
		Version        int      `json:"version"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	// If the technician is unassigned and the state is "assigned", go back to "pending"
	var statusClause string
	if req.AssignedTo == nil {
		statusClause = ", status = CASE WHEN status = 'assigned' THEN 'pending' ELSE status END"
	} else {
		// If a technician is assigned and the state is "pending", move to "assigned"
		statusClause = ", status = CASE WHEN status = 'pending' THEN 'assigned' ELSE status END"
	}

	result, err := h.db.Exec(c.UserContext(),
		`UPDATE work_orders SET title=$1, description=$2, priority=$3,
		        assigned_to=$4, estimated_hours=$5, planned_start=$6, planned_end=$7,
		        version = version + 1`+statusClause+`
		 WHERE id=$8 AND tenant_id=$9 AND version=$10
		   AND status NOT IN ('closed','cancelled')`,
		req.Title, req.Description, req.Priority,
		req.AssignedTo, req.EstimatedHours, req.PlannedStart, req.PlannedEnd,
		id, claims.TenantID, req.Version,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error actualizando OT")
	}
	if result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusConflict, "Conflicto de versión o OT cerrada/cancelada")
	}

	// Re-index the WO in RAG to keep the embeddings up to date
	ai.EnqueueNow(context.Background(), h.db, claims.TenantID, "reindex", "work_order", id)

	return c.JSON(fiber.Map{"message": "OT actualizada"})
}

// ─── GET /work-orders/:id/intervals — work intervals ─────────────────

func (h *WorkOrdersHandler) GetIntervals(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	rows, err := h.db.Query(c.UserContext(),
		`SELECT wi.id, wi.started_at::text, wi.ended_at::text, wi.ended_reason,
		        CASE WHEN wi.ended_at IS NOT NULL
		             THEN EXTRACT(EPOCH FROM (wi.ended_at - wi.started_at)) / 60
		             ELSE EXTRACT(EPOCH FROM (NOW() - wi.started_at)) / 60
		        END AS duration_minutes
		 FROM work_order_intervals wi
		 JOIN work_orders wo ON wo.id = wi.wo_id AND wo.tenant_id = $2
		 WHERE wi.wo_id = $1 AND wi.tenant_id = $2
		 ORDER BY wi.started_at ASC`,
		id, claims.TenantID)
	if err != nil {
		return fiber.NewError(500, "Error consultando intervalos")
	}
	defer rows.Close()

	type Interval struct {
		ID              int64   `json:"id"`
		StartedAt       string  `json:"started_at"`
		EndedAt         *string `json:"ended_at"`
		EndedReason     *string `json:"ended_reason"`
		DurationMinutes float64 `json:"duration_minutes"`
	}
	var intervals []Interval
	for rows.Next() {
		var iv Interval
		if rows.Scan(&iv.ID, &iv.StartedAt, &iv.EndedAt, &iv.EndedReason, &iv.DurationMinutes) == nil {
			intervals = append(intervals, iv)
		}
	}
	if intervals == nil {
		intervals = []Interval{}
	}

	// Accumulated total
	var totalMinutes float64
	for _, iv := range intervals {
		totalMinutes += iv.DurationMinutes
	}

	return c.JSON(fiber.Map{
		"intervals":     intervals,
		"total_minutes": totalMinutes,
		"total_hours":   fmt.Sprintf("%.1f", totalMinutes/60),
	})
}

// ─── GET /work-orders/offline-bundle ─────────────────────────────────────────
// Returns WOs with their comments and log in a single request, for offline mode.

func (h *WorkOrdersHandler) OfflineBundle(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	woQuery := `
		SELECT wo.id, wo.tenant_id, wo.node_id, fn.name,
		       wo.wo_number, wo.title, wo.description,
		       wo.wo_type, wo.priority, wo.status,
		       wo.assigned_to, ua.full_name,
		       wo.created_by, uc.full_name,
		       wo.estimated_hours, wo.actual_hours,
		       wo.planned_start::text, wo.planned_end::text,
		       wo.started_at::text, wo.completed_at::text, wo.closed_at::text,
		       wo.root_cause, wo.solution, wo.accumulated_minutes,
		       wo.hours_edited_by, uhe.full_name, wo.hours_edited_at::text,
		       wo.version, wo.created_at::text, wo.updated_at::text
		FROM work_orders wo
		JOIN factory_nodes fn ON fn.id = wo.node_id
		LEFT JOIN users ua ON ua.id = wo.assigned_to
		LEFT JOIN users uc ON uc.id = wo.created_by
		LEFT JOIN users uhe ON uhe.id = wo.hours_edited_by
		WHERE wo.tenant_id = $1
		  AND wo.status NOT IN ('closed', 'cancelled')`

	args := []interface{}{claims.TenantID}
	argIdx := 2

	if claims.Role != "admin" && claims.Role != "auditor" {
		woQuery += ` AND (wo.assigned_to = $` + strconv.Itoa(argIdx) +
			` OR wo.created_by = $` + strconv.Itoa(argIdx) +
			` OR wo.node_id IN (
				SELECT fn.id FROM factory_nodes fn
				JOIN node_assignments na ON na.user_id = $` + strconv.Itoa(argIdx) + ` AND na.tenant_id = $1
				JOIN factory_nodes assigned ON assigned.id = na.node_id AND assigned.tenant_id = $1
				WHERE fn.tenant_id = $1 AND fn.path <@ assigned.path
			))`
		args = append(args, claims.UserID)
		argIdx++
	}
	offlineLimit := 200
	if l, err := strconv.Atoi(c.Query("limit")); err == nil && l > 0 && l <= 500 {
		offlineLimit = l
	}
	woQuery += ` ORDER BY wo.created_at DESC LIMIT $` + strconv.Itoa(argIdx)
	args = append(args, offlineLimit)
	argIdx++

	rows, err := h.db.Query(c.UserContext(), woQuery, args...)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando OTs para offline")
	}
	defer rows.Close()

	type bundleWO struct {
		WorkOrderResponse
		Comments []fiber.Map `json:"comments"`
		Log      []fiber.Map `json:"log"`
	}

	var wos []bundleWO
	var woIDs []int64
	woMap := make(map[int64]int)

	for rows.Next() {
		var wo WorkOrderResponse
		if err := rows.Scan(
			&wo.ID, &wo.TenantID, &wo.NodeID, &wo.NodeName,
			&wo.WONumber, &wo.Title, &wo.Description,
			&wo.WOType, &wo.Priority, &wo.Status,
			&wo.AssignedTo, &wo.AssignedName,
			&wo.CreatedBy, &wo.CreatedByName,
			&wo.EstimatedHours, &wo.ActualHours,
			&wo.PlannedStart, &wo.PlannedEnd,
			&wo.StartedAt, &wo.CompletedAt, &wo.ClosedAt,
			&wo.RootCause, &wo.Solution, &wo.AccumulatedMinutes,
			&wo.HoursEditedBy, &wo.HoursEditedByName, &wo.HoursEditedAt,
			&wo.Version, &wo.CreatedAt, &wo.UpdatedAt,
		); err == nil {
			woMap[wo.ID] = len(wos)
			woIDs = append(woIDs, wo.ID)
			wos = append(wos, bundleWO{WorkOrderResponse: wo})
		}
	}

	if len(woIDs) == 0 {
		return c.JSON(fiber.Map{"work_orders": []bundleWO{}, "total": 0})
	}

	// Comments for every WO in a single query
	commentRows, err := h.db.Query(c.UserContext(),
		`SELECT wc.wo_id, wc.id, wc.user_id, u.full_name, wc.content, wc.created_at::text
		 FROM work_order_comments wc
		 LEFT JOIN users u ON u.id = wc.user_id
		 WHERE wc.wo_id = ANY($1) AND wc.tenant_id = $2
		 ORDER BY wc.created_at ASC`, woIDs, claims.TenantID)
	if err == nil && commentRows != nil {
		defer commentRows.Close()
		for commentRows.Next() {
			var woID, id int64
			var userID *int64
			var userName *string
			var content, createdAt string
			if err := commentRows.Scan(&woID, &id, &userID, &userName, &content, &createdAt); err != nil {
				stdlog.Printf("[ARCHE-WO] WARN: scan bulk comment: %v", err)
				continue
			}
			if idx, ok := woMap[woID]; ok {
				wos[idx].Comments = append(wos[idx].Comments, fiber.Map{
					"id": id, "user_id": userID, "user_name": userName,
					"content": content, "created_at": createdAt,
				})
			}
		}
	}

	// Log for every WO in a single query
	logRows, err := h.db.Query(c.UserContext(),
		`SELECT wl.wo_id, wl.id, wl.user_id, u.full_name, wl.from_status, wl.to_status, wl.comment, wl.created_at::text
		 FROM work_order_log wl
		 LEFT JOIN users u ON u.id = wl.user_id
		 WHERE wl.wo_id = ANY($1) AND wl.tenant_id = $2
		 ORDER BY wl.created_at ASC`, woIDs, claims.TenantID)
	if err == nil && logRows != nil {
		defer logRows.Close()
		for logRows.Next() {
			var woID, id int64
			var userID *int64
			var userName, fromStatus, comment *string
			var toStatus, createdAt string
			if err := logRows.Scan(&woID, &id, &userID, &userName, &fromStatus, &toStatus, &comment, &createdAt); err != nil {
				stdlog.Printf("[ARCHE-WO] WARN: scan bulk log: %v", err)
				continue
			}
			if idx, ok := woMap[woID]; ok {
				wos[idx].Log = append(wos[idx].Log, fiber.Map{
					"id": id, "user_id": userID, "user_name": userName,
					"from_status": fromStatus, "to_status": toStatus,
					"comment": comment, "created_at": createdAt,
				})
			}
		}
	}

	return c.JSON(fiber.Map{"work_orders": wos, "total": len(wos)})
}

// ─── GET /work-orders/suggest-parts?node_id=N ──────────────────────────────
// Returns candidate spare parts for a WO on the given node, combining:
//   - spare parts attached to the node (spare_part_nodes)
//   - spare parts consumed in the last N WOs on the same node
//
// Every item carries a score (frequency) and its source, so the frontend
// can show why it is being suggested.
func (h *WorkOrdersHandler) SuggestParts(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	nodeID, err := strconv.ParseInt(c.Query("node_id"), 10, 64)
	if err != nil || nodeID <= 0 {
		return fiber.NewError(fiber.StatusBadRequest, "node_id requerido")
	}

	// Validate that the node belongs to the tenant
	var ok int
	_ = h.db.QueryRow(c.UserContext(),
		`SELECT 1 FROM factory_nodes WHERE id=$1 AND tenant_id=$2`,
		nodeID, claims.TenantID,
	).Scan(&ok)
	if ok != 1 {
		return fiber.NewError(fiber.StatusNotFound, "Nodo no encontrado")
	}

	// A single query: UNION ALL + aggregation by spare_part_id
	rows, err := h.db.Query(c.UserContext(),
		`WITH candidates AS (
			SELECT sp.id AS spare_part_id, 'linked' AS source, 1 AS uses
			FROM spare_part_nodes spn
			JOIN spare_parts sp ON sp.id = spn.spare_part_id
			WHERE spn.node_id = $1 AND sp.tenant_id = $2
			UNION ALL
			SELECT wop.spare_part_id, 'history' AS source, COUNT(*)::int AS uses
			FROM work_order_parts wop
			JOIN work_orders wo ON wo.id = wop.wo_id
			WHERE wo.node_id = $1 AND wo.tenant_id = $2
			  AND wo.status IN ('completed','verified','closed')
			GROUP BY wop.spare_part_id
		)
		SELECT sp.id, sp.code, sp.name, sp.unit, sp.current_stock, sp.min_stock,
		       SUM(c.uses) AS score,
		       BOOL_OR(c.source = 'linked')  AS is_linked,
		       BOOL_OR(c.source = 'history') AS in_history
		FROM candidates c
		JOIN spare_parts sp ON sp.id = c.spare_part_id
		WHERE sp.tenant_id = $2 AND COALESCE(sp.is_active, true) = true
		GROUP BY sp.id, sp.code, sp.name, sp.unit, sp.current_stock, sp.min_stock
		ORDER BY score DESC, sp.name ASC
		LIMIT 8`,
		nodeID, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando sugerencias")
	}
	defer rows.Close()

	type Suggestion struct {
		ID           int64    `json:"id"`
		Code         *string  `json:"code"`
		Name         string   `json:"name"`
		Unit         *string  `json:"unit"`
		CurrentStock *float64 `json:"current_stock"`
		MinStock     *float64 `json:"min_stock"`
		Score        int      `json:"score"`
		IsLinked     bool     `json:"is_linked"`
		InHistory    bool     `json:"in_history"`
	}
	out := []Suggestion{}
	for rows.Next() {
		var s Suggestion
		if err := rows.Scan(
			&s.ID, &s.Code, &s.Name, &s.Unit, &s.CurrentStock, &s.MinStock,
			&s.Score, &s.IsLinked, &s.InHistory,
		); err == nil {
			out = append(out, s)
		}
	}
	return c.JSON(fiber.Map{"suggestions": out})
}
