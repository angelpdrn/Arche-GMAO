package handlers

import (
	"context"
	"fmt"
	"log"
	"net/mail"
	"os"
	"strings"
	"time"

	"arche-gmao/api/internal/config"
	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/golang-jwt/jwt/v5"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/redis/go-redis/v9"
	"golang.org/x/crypto/bcrypt"
)

type AuthHandler struct {
	db  *pgxpool.Pool
	rdb *redis.Client
	cfg *config.Config
}

func NewAuthHandler(db *pgxpool.Pool, rdb *redis.Client, cfg *config.Config) *AuthHandler {
	return &AuthHandler{db: db, rdb: rdb, cfg: cfg}
}

// normalizeEmail trims, lowercases and validates with net/mail.
// It returns the normalized email, or "" when it is not valid.
func normalizeEmail(raw string) string {
	e := strings.TrimSpace(strings.ToLower(raw))
	if e == "" || len(e) > 255 {
		return ""
	}
	addr, err := mail.ParseAddress(e)
	if err != nil {
		return ""
	}
	// mail.ParseAddress accepts "Name <a@b>"; we only want the address.
	parsed := strings.ToLower(strings.TrimSpace(addr.Address))
	if !strings.Contains(parsed, "@") {
		return ""
	}
	return parsed
}

// ─── LOGIN ───────────────────────────────────────────────────────────────────

type loginRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

func (h *AuthHandler) Login(c *fiber.Ctx) error {
	var req loginRequest
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo de la solicitud inválido")
	}

	email := normalizeEmail(req.Email)
	if email == "" || req.Password == "" {
		return fiber.NewError(fiber.StatusBadRequest, "El correo y la contraseña son requeridos")
	}

	var (
		userID         int64
		tenantID       int64
		role           string
		passwordHash   string
		status         string
		fullName       string
		isSuperadmin   bool
		isPrimaryAdmin bool
	)

	// 1. Look in the users table (normal login) — a single query to avoid TOCTOU
	rows, qErr := h.db.Query(c.UserContext(),
		`SELECT id, tenant_id, role, password_hash, status, full_name, is_primary_admin
		 FROM users
		 WHERE email = $1 AND status = 'active'
		 ORDER BY id`, email)
	if qErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando usuarios")
	}
	defer rows.Close()

	var matchCount int
	for rows.Next() {
		matchCount++
		if matchCount == 1 {
			if err := rows.Scan(&userID, &tenantID, &role, &passwordHash, &status, &fullName, &isPrimaryAdmin); err != nil {
				return fiber.NewError(fiber.StatusInternalServerError, "Error leyendo datos de usuario")
			}
		}
	}
	if err := rows.Err(); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando usuarios")
	}

	if matchCount > 1 {
		return fiber.NewError(fiber.StatusConflict,
			"Este email existe en múltiples organizaciones. Contacte al administrador del sistema.")
	}

	err := error(nil)
	if matchCount == 0 {
		err = pgx.ErrNoRows
	}

	if err != nil {
		// 2. If it is not in users, look in superadmin_accounts
		var saID int64
		var saHash string
		var saName string
		var saActive bool
		saErr := h.db.QueryRow(c.UserContext(),
			`SELECT id, password_hash, full_name, is_active
			 FROM superadmin_accounts
			 WHERE email = $1`,
			email,
		).Scan(&saID, &saHash, &saName, &saActive)

		if saErr != nil {
			return fiber.NewError(fiber.StatusUnauthorized, "Credenciales inválidas")
		}
		if !saActive {
			return fiber.NewError(fiber.StatusForbidden, "La cuenta no está activa")
		}
		if err := bcrypt.CompareHashAndPassword([]byte(saHash), []byte(req.Password)); err != nil {
			return fiber.NewError(fiber.StatusUnauthorized, "Credenciales inválidas")
		}

		// Superadmin: get the first active tenant. No hardcoded fallback:
		// if there is none, we return an explicit 503.
		var saTenantID int64
		tErr := h.db.QueryRow(c.UserContext(),
			`SELECT id FROM tenants WHERE status = 'active' ORDER BY id LIMIT 1`,
		).Scan(&saTenantID)
		if tErr != nil {
			log.Printf("[ARCHE-AUTH] ERROR: superadmin %s sin tenant activo: %v", email, tErr)
			return fiber.NewError(fiber.StatusServiceUnavailable,
				"No hay tenants activos en el sistema. Contacte a soporte.")
		}

		userID = saID
		tenantID = saTenantID
		role = "admin"
		fullName = saName
		isSuperadmin = true
		isPrimaryAdmin = false

		if _, lErr := h.db.Exec(c.UserContext(),
			`UPDATE superadmin_accounts SET last_login_at = NOW() WHERE id = $1`, saID); lErr != nil {
			log.Printf("[ARCHE-AUTH] WARN: error registrando login superadmin id=%d: %v", saID, lErr)
		}

	} else {
		if err := bcrypt.CompareHashAndPassword([]byte(passwordHash), []byte(req.Password)); err != nil {
			return fiber.NewError(fiber.StatusUnauthorized, "Credenciales inválidas")
		}
		if _, lErr := h.db.Exec(c.UserContext(),
			`UPDATE users SET last_login_at = NOW() WHERE id = $1 AND tenant_id = $2`,
			userID, tenantID); lErr != nil {
			log.Printf("[ARCHE-AUTH] WARN: error registrando login user id=%d: %v", userID, lErr)
		}
	}

	// Generate distinct JTIs for access and refresh: logout's revoked:{jti}
	// only affects the active access token, not the refresh one (that is deleted from Redis).
	accessJTI := uuid.NewString()
	refreshJTI := uuid.NewString()

	accessToken, err := h.generateAccessToken(userID, tenantID, role, isSuperadmin, accessJTI, 15*time.Minute, h.cfg.JWTSecret)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error generando token de acceso")
	}

	refreshToken, err := h.generateAccessToken(userID, tenantID, role, isSuperadmin, refreshJTI, 7*24*time.Hour, h.cfg.JWTRefreshSecret)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error generando token de refresco")
	}

	prefix := "refresh"
	if isSuperadmin {
		prefix = "sa_refresh"
	}
	key := fmt.Sprintf("%s:%d", prefix, userID)
	if err := h.rdb.Set(c.UserContext(), key, refreshToken, 7*24*time.Hour).Err(); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error guardando sesión")
	}

	var systemPaused bool
	_ = h.db.QueryRow(c.UserContext(),
		`SELECT system_paused FROM tenants WHERE id = $1`, tenantID,
	).Scan(&systemPaused)

	setRefreshCookie(c, refreshToken)

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"access_token": accessToken,
		"token_type":   "Bearer",
		"expires_in":   900,
		"user": fiber.Map{
			"id":               userID,
			"email":            email,
			"full_name":        fullName,
			"role":             role,
			"tenant_id":        tenantID,
			"is_superadmin":    isSuperadmin,
			"is_primary_admin": isPrimaryAdmin,
		},
		"system_paused": systemPaused,
	})
}

// ─── REFRESH ─────────────────────────────────────────────────────────────────

func (h *AuthHandler) Refresh(c *fiber.Ctx) error {
	// CSRF mitigation: reject cross-origin requests on the refresh endpoint.
	// SameSite=Strict covers modern browsers; this protects the legacy ones.
	if origin := c.Get("Origin"); origin != "" {
		allowed := os.Getenv("CORS_ORIGINS")
		if allowed == "" {
			allowed = "http://localhost:5173"
		}
		originAllowed := false
		for _, o := range strings.Split(allowed, ",") {
			if strings.TrimSpace(o) == origin {
				originAllowed = true
				break
			}
		}
		if !originAllowed {
			return fiber.NewError(fiber.StatusForbidden, "Origen no autorizado")
		}
	}

	refreshTokenValue := c.Cookies("refresh_token")
	if refreshTokenValue == "" {
		var req struct {
			RefreshToken string `json:"refresh_token"`
		}
		if err := c.BodyParser(&req); err == nil {
			refreshTokenValue = req.RefreshToken
		}
	}

	if refreshTokenValue == "" {
		return fiber.NewError(fiber.StatusUnauthorized, "No se encontró refresh token")
	}

	claims := &types.Claims{}
	token, err := jwt.ParseWithClaims(refreshTokenValue, claims, func(t *jwt.Token) (interface{}, error) {
		if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("método de firma inesperado: %v", t.Header["alg"])
		}
		return []byte(h.cfg.JWTRefreshSecret), nil
	})

	if err != nil || !token.Valid {
		return fiber.NewError(fiber.StatusUnauthorized, "Refresh token inválido o expirado")
	}

	prefix := "refresh"
	if claims.IsSuperadmin {
		prefix = "sa_refresh"
	}
	key := fmt.Sprintf("%s:%d", prefix, claims.UserID)
	stored, err := h.rdb.Get(c.UserContext(), key).Result()
	if err != nil || stored != refreshTokenValue {
		return fiber.NewError(fiber.StatusUnauthorized, "Sesión expirada o revocada")
	}

	// The new access token's issued-at will be later than any revoked_user marker:
	// that way a password change still invalidates the active refresh token when it
	// tries to renew.
	accessJTI := uuid.NewString()
	accessToken, err := h.generateAccessToken(claims.UserID, claims.TenantID, claims.Role, claims.IsSuperadmin, accessJTI, 15*time.Minute, h.cfg.JWTSecret)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error generando nuevo token")
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"access_token": accessToken,
		"token_type":   "Bearer",
		"expires_in":   900,
	})
}

// ─── LOGOUT ──────────────────────────────────────────────────────────────────

func (h *AuthHandler) Logout(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	// 1) Invalidate the current access token by adding it to the blacklist until it expires.
	if claims.JTI != "" {
		ttl := 15 * time.Minute
		if claims.ExpiresAt != nil {
			remain := time.Until(claims.ExpiresAt.Time)
			if remain > 0 {
				ttl = remain
			}
		}
		if err := h.rdb.Set(c.UserContext(), "revoked:"+claims.JTI, "1", ttl).Err(); err != nil {
			log.Printf("[ARCHE-AUTH] WARN: error revocando JTI %s: %v", claims.JTI, err)
		}
	}

	// 2) Delete the persisted refresh token.
	prefix := "refresh"
	if claims.IsSuperadmin {
		prefix = "sa_refresh"
	}
	key := fmt.Sprintf("%s:%d", prefix, claims.UserID)
	if err := h.rdb.Del(c.UserContext(), key).Err(); err != nil {
		log.Printf("[ARCHE-AUTH] WARN: Error eliminando refresh token de Redis (user %d): %v", claims.UserID, err)
	}

	clearRefreshCookie(c)

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"message": "Sesión cerrada correctamente",
	})
}

// ─── ME ──────────────────────────────────────────────────────────────────────

func (h *AuthHandler) Me(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	if claims.IsSuperadmin {
		var email, fullName string
		err := h.db.QueryRow(c.UserContext(),
			`SELECT email, full_name FROM superadmin_accounts WHERE id = $1`,
			claims.UserID,
		).Scan(&email, &fullName)
		if err != nil {
			return fiber.NewError(fiber.StatusNotFound, "Cuenta no encontrada")
		}

		var systemPaused bool
		_ = h.db.QueryRow(c.UserContext(),
			`SELECT system_paused FROM tenants WHERE id = $1`, claims.TenantID,
		).Scan(&systemPaused)

		return c.Status(fiber.StatusOK).JSON(fiber.Map{
			"id":               claims.UserID,
			"email":            email,
			"full_name":        fullName,
			"role":             "admin",
			"tenant_id":        claims.TenantID,
			"is_superadmin":    true,
			"is_primary_admin": false,
			"system_paused":    systemPaused,
		})
	}

	var (
		email          string
		fullName       string
		role           string
		homeNodeID     *int64
		isPrimaryAdmin bool
	)

	err := h.db.QueryRow(c.UserContext(),
		`SELECT email, full_name, role, home_node_id, is_primary_admin
		 FROM users
		 WHERE id = $1 AND tenant_id = $2`,
		claims.UserID, claims.TenantID,
	).Scan(&email, &fullName, &role, &homeNodeID, &isPrimaryAdmin)

	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Usuario no encontrado")
	}

	var systemPaused bool
	_ = h.db.QueryRow(c.UserContext(),
		`SELECT system_paused FROM tenants WHERE id = $1`, claims.TenantID,
	).Scan(&systemPaused)

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"id":               claims.UserID,
		"email":            email,
		"full_name":        fullName,
		"role":             role,
		"tenant_id":        claims.TenantID,
		"home_node_id":     homeNodeID,
		"is_superadmin":    false,
		"is_primary_admin": isPrimaryAdmin,
		"system_paused":    systemPaused,
	})
}

// ─── HELPERS ─────────────────────────────────────────────────────────────────

func setRefreshCookie(c *fiber.Ctx, token string) {
	secure := os.Getenv("APP_ENV") == "production"
	c.Cookie(&fiber.Cookie{
		Name:     "refresh_token",
		Value:    token,
		Path:     "/api/v1/auth",
		HTTPOnly: true,
		Secure:   secure,
		SameSite: "Strict",
		MaxAge:   7 * 24 * 60 * 60, // 7 days
	})
}

func clearRefreshCookie(c *fiber.Ctx) {
	secure := os.Getenv("APP_ENV") == "production"
	c.Cookie(&fiber.Cookie{
		Name:     "refresh_token",
		Value:    "",
		Path:     "/api/v1/auth",
		HTTPOnly: true,
		Secure:   secure,
		SameSite: "Strict",
		MaxAge:   -1,
	})
}

func (h *AuthHandler) generateAccessToken(userID, tenantID int64, role string, isSuperadmin bool, jti string, duration time.Duration, secret string) (string, error) {
	claims := types.Claims{
		UserID:       userID,
		TenantID:     tenantID,
		Role:         role,
		IsSuperadmin: isSuperadmin,
		JTI:          jti,
		RegisteredClaims: jwt.RegisteredClaims{
			ID:        jti,
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(duration)),
			IssuedAt:  jwt.NewNumericDate(time.Now()),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString([]byte(secret))
}

// RevokeUserSessions marks as revoked every access token issued before
// the current moment, for a given user. Use it after a password change.
// Both the active access token and any parallel ones are invalidated on the
// next request thanks to the IssuedAt < cutoff check in the middleware.
func RevokeUserSessions(rdb *redis.Client, ctx context.Context, userID int64, isSuperadmin bool) {
	if rdb == nil {
		return
	}
	key := fmt.Sprintf("revoked_user:%d", userID)
	if isSuperadmin {
		key = fmt.Sprintf("revoked_sa:%d", userID)
	}
	cutoff := time.Now().Unix()
	// TTL = 15 min (maximum lifetime of an access token)
	if err := rdb.Set(ctx, key, fmt.Sprintf("%d", cutoff), 15*time.Minute).Err(); err != nil {
		log.Printf("[ARCHE-AUTH] WARN: revocación masiva user=%d falló: %v", userID, err)
	}
}
