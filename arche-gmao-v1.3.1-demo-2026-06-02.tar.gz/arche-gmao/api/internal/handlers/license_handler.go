package handlers

import (
	"arche-gmao/api/internal/license"
	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type LicenseHandler struct {
	db *pgxpool.Pool
}

func NewLicenseHandler(db *pgxpool.Pool) *LicenseHandler {
	return &LicenseHandler{db: db}
}

func (h *LicenseHandler) Info(c *fiber.Ctx) error {
	info := license.Current
	if info == nil {
		return c.JSON(fiber.Map{
			"modules":   []string{"all"},
			"max_users": 0,
			"max_nodes": 0,
			"days_left": 0,
		})
	}

	claims := c.Locals("claims").(*types.Claims)

	var disabled []string
	_ = h.db.QueryRow(c.UserContext(),
		`SELECT COALESCE(disabled_modules, '{}') FROM tenants WHERE id = $1`,
		claims.TenantID,
	).Scan(&disabled)

	effectiveModules := make([]string, 0, len(info.Modules))
	disabledSet := make(map[string]bool, len(disabled))
	for _, d := range disabled {
		disabledSet[d] = true
	}

	if len(disabled) > 0 {
		for _, m := range info.Modules {
			if m == "all" {
				for _, possible := range []string{"ai", "preventive", "qr", "reports", "metrics"} {
					if !disabledSet[possible] {
						effectiveModules = append(effectiveModules, possible)
					}
				}
			} else if !disabledSet[m] {
				effectiveModules = append(effectiveModules, m)
			}
		}
	} else {
		effectiveModules = info.Modules
	}

	return c.JSON(fiber.Map{
		"modules":       effectiveModules,
		"max_users":     info.MaxUsers,
		"max_nodes":     info.MaxNodes,
		"max_tenants":   info.MaxTenants,
		"days_left":     info.DaysLeft,
		"penalty_level": license.GetPenaltyLevel(),
		"penalty_msg":   license.FormatPenaltyMessage(),
	})
}
