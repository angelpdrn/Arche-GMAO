package handlers

import (
	"context"
	"strconv"
	"time"

	"arche-gmao/api/internal/ai"
	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type PatternsHandler struct {
	db       *pgxpool.Pool
	detector *ai.PatternDetector
}

func NewPatternsHandler(db *pgxpool.Pool, detector *ai.PatternDetector) *PatternsHandler {
	return &PatternsHandler{db: db, detector: detector}
}

// ─── GET /patterns — list active patterns ─────────────────────────────────

func (h *PatternsHandler) List(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID := c.Query("node_id")
	severity := c.Query("severity")

	query := `SELECT p.id, p.node_id, p.pattern_type, p.severity,
	                 p.title, p.description, p.recommendation,
	                 p.pattern_data, p.detected_at::text,
	                 fn.name AS node_name, fn.code AS node_code
	          FROM ai_patterns p
	          LEFT JOIN factory_nodes fn ON fn.id=p.node_id
	          WHERE p.tenant_id=$1 AND p.status='active'
	            AND (p.valid_until IS NULL OR p.valid_until > NOW())`
	args := []interface{}{claims.TenantID}
	argIdx := 2

	if nodeID != "" {
		query += ` AND p.node_id=$` + strconv.Itoa(argIdx)
		args = append(args, nodeID)
		argIdx++
	}
	if severity != "" {
		query += ` AND p.severity=$` + strconv.Itoa(argIdx)
		args = append(args, severity)
		argIdx++
	}

	// Roles with a limited scope only see patterns from their assigned nodes
	if claims.Role != "admin" && claims.Role != "auditor" {
		query += ` AND p.node_id IN (
			SELECT fn.id FROM factory_nodes fn
			JOIN node_assignments na ON na.user_id = $` + strconv.Itoa(argIdx) + ` AND na.tenant_id = $1
			JOIN factory_nodes assigned ON assigned.id = na.node_id AND assigned.tenant_id = $1
			WHERE fn.tenant_id = $1 AND fn.path <@ assigned.path
		)`
		args = append(args, claims.UserID)
		argIdx++
	}

	query += ` ORDER BY CASE p.severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 ELSE 4 END, p.detected_at DESC`

	rows, err := h.db.Query(c.UserContext(), query, args...)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando patrones")
	}
	defer rows.Close()

	type Pattern struct {
		ID             int64   `json:"id"`
		NodeID         *int64  `json:"node_id"`
		NodeName       *string `json:"node_name"`
		NodeCode       *string `json:"node_code"`
		PatternType    string  `json:"pattern_type"`
		Severity       string  `json:"severity"`
		Title          string  `json:"title"`
		Description    string  `json:"description"`
		Recommendation *string `json:"recommendation"`
		PatternData    []byte  `json:"pattern_data"`
		DetectedAt     string  `json:"detected_at"`
	}

	var patterns []Pattern
	for rows.Next() {
		var p Pattern
		if err := rows.Scan(
			&p.ID, &p.NodeID, &p.PatternType, &p.Severity,
			&p.Title, &p.Description, &p.Recommendation,
			&p.PatternData, &p.DetectedAt,
			&p.NodeName, &p.NodeCode,
		); err == nil {
			patterns = append(patterns, p)
		}
	}

	// Count by severity
	var critical, high, medium int
	for _, p := range patterns {
		switch p.Severity {
		case "critical":
			critical++
		case "high":
			high++
		case "medium":
			medium++
		}
	}

	return c.JSON(fiber.Map{
		"patterns": patterns,
		"total":    len(patterns),
		"summary": fiber.Map{
			"critical": critical,
			"high":     high,
			"medium":   medium,
		},
	})
}

// ─── POST /patterns/detect — run detection manually ──────────────────

func (h *PatternsHandler) Detect(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	ctx, cancel := context.WithTimeout(c.UserContext(), 60*time.Second)
	defer cancel()

	count, err := h.detector.RunDetection(ctx, claims.TenantID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error en detección de patrones")
	}

	return c.JSON(fiber.Map{
		"message":          "Detección completada",
		"patterns_created": count,
	})
}

// ─── PATCH /patterns/:id/acknowledge — mark as seen ─────────────────────

func (h *PatternsHandler) Acknowledge(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	result, err := h.db.Exec(c.UserContext(),
		`UPDATE ai_patterns SET status='acknowledged'
		 WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Patrón no encontrado")
	}

	return c.JSON(fiber.Map{"message": "Patrón marcado como visto"})
}

// ─── GET /patterns/node/:id — patterns for a specific node ─────────────────

func (h *PatternsHandler) GetNodePatterns(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	rows, err := h.db.Query(c.UserContext(),
		`SELECT id, pattern_type, severity, title, description, recommendation,
		        detected_at::text
		 FROM ai_patterns
		 WHERE tenant_id=$1 AND node_id=$2 AND status='active'
		   AND (valid_until IS NULL OR valid_until > NOW())
		 ORDER BY CASE severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2 ELSE 3 END`,
		claims.TenantID, nodeID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error")
	}
	defer rows.Close()

	type P struct {
		ID             int64   `json:"id"`
		PatternType    string  `json:"pattern_type"`
		Severity       string  `json:"severity"`
		Title          string  `json:"title"`
		Description    string  `json:"description"`
		Recommendation *string `json:"recommendation"`
		DetectedAt     string  `json:"detected_at"`
	}

	var patterns []P
	for rows.Next() {
		var p P
		if rows.Scan(&p.ID, &p.PatternType, &p.Severity, &p.Title,
			&p.Description, &p.Recommendation, &p.DetectedAt) == nil {
			patterns = append(patterns, p)
		}
	}

	return c.JSON(fiber.Map{"patterns": patterns, "total": len(patterns)})
}
