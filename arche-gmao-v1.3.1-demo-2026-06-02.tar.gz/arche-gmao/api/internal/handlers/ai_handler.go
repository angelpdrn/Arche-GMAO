package handlers

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"log"
	"strconv"
	"strings"
	"time"

	"arche-gmao/api/internal/ai"
	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type AIHandler struct {
	db      *pgxpool.Pool
	ollama  *ai.OllamaClient
	rag     *ai.RAGService
	builder *ai.PromptBuilder
	worker  *ai.IndexWorker
	sem     *ai.AISemaphore
	web     *ai.WebSearcher
}

func NewAIHandler(
	db *pgxpool.Pool,
	ollama *ai.OllamaClient,
	rag *ai.RAGService,
	builder *ai.PromptBuilder,
	worker *ai.IndexWorker,
	sem *ai.AISemaphore,
) *AIHandler {
	return &AIHandler{db: db, ollama: ollama, rag: rag, builder: builder, worker: worker, sem: sem, web: ai.NewWebSearcher()}
}

// ollamaForTenant returns an OllamaClient using the model configured
// in the tenant's DB, or the global default when there is no configuration.
func (h *AIHandler) ollamaForTenant(ctx context.Context, tenantID int64) *ai.OllamaClient {
	var chatModel string
	_ = h.db.QueryRow(ctx,
		`SELECT COALESCE(ai_chat_model,'') FROM tenants WHERE id=$1`, tenantID,
	).Scan(&chatModel)
	if chatModel != "" && chatModel != h.ollama.ChatModel() {
		return h.ollama.WithModels(chatModel, "")
	}
	return h.ollama
}

// ─── GET /ai/status ───────────────────────────────────────────────────────────

func (h *AIHandler) Status(c *fiber.Ctx) error {
	ctx, cancel := context.WithTimeout(c.UserContext(), 5*time.Second)
	defer cancel()

	available := h.ollama.IsAvailable(ctx)

	if !available {
		return c.JSON(fiber.Map{
			"available": false,
			"message":   "Servicio de IA no disponible temporalmente",
		})
	}

	claims := c.Locals("claims").(*types.Claims)

	var indexedChunks, pendingQueue int
	h.db.QueryRow(c.UserContext(),
		`SELECT COUNT(*) FROM ai_embeddings WHERE tenant_id=$1`, claims.TenantID,
	).Scan(&indexedChunks)
	h.db.QueryRow(c.UserContext(),
		`SELECT COUNT(*) FROM ai_index_queue WHERE status='pending' AND tenant_id=$1`, claims.TenantID,
	).Scan(&pendingQueue)

	models, _ := h.ollama.ListModels(ctx)

	return c.JSON(fiber.Map{
		"available":        true,
		"ollama_available": true,
		"indexed_chunks":   indexedChunks,
		"pending_queue":    pendingQueue,
		"models":           models,
	})
}

// ─── POST /ai/chat — SSE streaming ───────────────────────────────────────────

func (h *AIHandler) Chat(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req struct {
		Message        string `json:"message"`
		ConversationID *int64 `json:"conversation_id"`
		NodeID         *int64 `json:"node_id"`
	}
	if err := c.BodyParser(&req); err != nil || strings.TrimSpace(req.Message) == "" {
		return fiber.NewError(fiber.StatusBadRequest, "El mensaje es requerido")
	}

	ctx := c.UserContext()

	// Detect an action intent in the message
	action := h.detectAction(req.Message)

	convID, err := h.getOrCreateConversation(ctx, claims, req.ConversationID, req.NodeID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error creando conversación")
	}

	var nodeCtx *ai.NodeContext
	var templateID *int64
	if req.NodeID != nil {
		var nErr error
		nodeCtx, nErr = h.builder.GetNodeContext(ctx, *req.NodeID, claims.TenantID, claims.Role)
		if nErr != nil {
			log.Printf("[ARCHE-AI] Error obteniendo contexto de nodo %d: %v", *req.NodeID, nErr)
		}
		h.db.QueryRow(ctx, `SELECT template_id FROM factory_nodes WHERE id=$1 AND tenant_id=$2`, *req.NodeID, claims.TenantID).Scan(&templateID)
	}

	// RAG with a short timeout (if Ollama does not answer for embeddings, it is skipped)
	ragCtx, ragCancel := context.WithTimeout(ctx, 30*time.Second)
	chunks, ragErr := h.rag.Search(ragCtx, req.Message, ai.SearchOptions{
		TenantID:        claims.TenantID,
		NodeID:          req.NodeID,
		TemplateID:      templateID,
		IncludeSiblings: templateID != nil,
		Limit:           10,
		MinSimilarity:   0.15,
		Role:            claims.Role,
		UserID:          claims.UserID,
	})
	ragCancel()
	if ragErr != nil {
		log.Printf("[ARCHE-AI] Error en búsqueda RAG: %v", ragErr)
	}
	log.Printf("[ARCHE-AI] Chat: %d chunks RAG encontrados (nodeID=%v, templateID=%v)", len(chunks), req.NodeID, templateID)

	// Web search: turn it on when the query is generic OR when the equipment is commercial (manufacturer+model)
	var webCtx *ai.WebContext
	shouldWeb := ai.ShouldSearchWeb(req.Message, len(chunks))

	// Search the web automatically for commercial equipment with a known manufacturer+model
	var equipmentMfr, equipmentModel string
	if nodeCtx != nil {
		equipmentMfr = nodeCtx.Manufacturer
		equipmentModel = nodeCtx.Model
		if equipmentMfr == "" && nodeCtx.TemplateName != "" {
			parts := strings.SplitN(nodeCtx.TemplateName, " ", 2)
			if len(parts) == 2 {
				equipmentMfr = parts[0]
				equipmentModel = parts[1]
			}
		}
		// For commercial equipment with not enough RAG, look up manufacturer information
		if equipmentMfr != "" && equipmentModel != "" && len(chunks) < 5 {
			shouldWeb = true
		}
	}

	if shouldWeb {
		webQuery := req.Message
		// When there is commercial equipment, include manufacturer+model in the search
		if equipmentMfr != "" && equipmentModel != "" {
			qLower := strings.ToLower(req.Message)
			mfrLower := strings.ToLower(equipmentMfr)
			mdlLower := strings.ToLower(equipmentModel)
			// Only add them when they are not already in the query
			if !strings.Contains(qLower, mfrLower) || !strings.Contains(qLower, mdlLower) {
				webQuery = equipmentMfr + " " + equipmentModel + " " + req.Message
			}
		}
		webSearchCtx, webCancel := context.WithTimeout(ctx, 8*time.Second)
		webResults, err := h.web.Search(webSearchCtx, webQuery, 4)
		webCancel()
		if err == nil && len(webResults) > 0 {
			webCtx = &ai.WebContext{Results: webResults, Query: webQuery}
		}
	}

	history, _ := h.getConversationHistory(ctx, convID, 8)

	// Resolve the per-tenant chat model (when configured in AI Admin)
	ollamaForTenant := h.ollamaForTenant(ctx, claims.TenantID)

	// When an action was detected, add the instruction to the prompt
	sysPrompt := h.builder.BuildSystemPrompt(claims.Role, nodeCtx, chunks, webCtx)
	if action != "" {
		sysPrompt += "\n\nACCIÓN DETECTADA: El usuario quiere " + action + ". Si tienes suficiente información, ejecuta la acción y confirma. Si te falta información, pregunta lo mínimo necesario."
	}

	messages := []ai.Message{{Role: "system", Content: sysPrompt}}
	messages = append(messages, history...)
	messages = append(messages, ai.Message{Role: "user", Content: req.Message})

	logExecErr(h.db.Exec(ctx,
		`INSERT INTO ai_messages (conversation_id, role, content) VALUES ($1,'user',$2)`,
		convID, req.Message,
	)).Log("ai-msg-user")

	c.Set("Content-Type", "text/event-stream")
	c.Set("Cache-Control", "no-cache")
	c.Set("Connection", "keep-alive")
	c.Set("X-Accel-Buffering", "no")
	c.Set("X-Conversation-ID", strconv.FormatInt(convID, 10))

	// Variables captured explicitly before the closure, to avoid race
	// conditions with the request (which may expire) and so the stream
	// goroutine has its own cancellable context.
	var fullResp strings.Builder
	capturedChunks := chunks
	capturedAction := action
	capturedConvID := convID
	capturedMessage := req.Message
	requestCtx := c.Context()
	streamCtx, cancelStream := context.WithCancel(context.Background())
	go func() {
		<-requestCtx.Done()
		cancelStream()
	}()

	c.Context().SetBodyStreamWriter(func(w *bufio.Writer) {
		defer cancelStream()
		fmt.Fprintf(w, "data: %s\n\n", jstr(map[string]interface{}{
			"type": "conversation_id", "id": capturedConvID,
		}))
		w.Flush()

		// Semaphore: limit the concurrency of requests to Ollama
		if !h.sem.TryAcquire() {
			fmt.Fprintf(w, "data: %s\n\n", jstr(map[string]interface{}{
				"type":    "status",
				"message": "Hay mucho tráfico en este momento. Tu solicitud será procesada en breve.",
			}))
			w.Flush()

			if err := h.sem.Acquire(streamCtx); err != nil {
				fmt.Fprintf(w, "data: %s\n\n", jstr(map[string]interface{}{
					"type":  "error",
					"error": "No se pudo procesar la solicitud. Intenta de nuevo.",
				}))
				w.Flush()
				return
			}
		}
		defer h.sem.Release()

		// Generate the answer with an automatic retry (30s + 15s)
		_, streamErr := ollamaForTenant.GenerateStreamWithRetry(
			streamCtx,
			messages,
			func(token string) {
				fullResp.WriteString(token)
				fmt.Fprintf(w, "data: %s\n\n", jstr(map[string]interface{}{
					"type": "chunk", "content": token,
				}))
				w.Flush()
			},
			func() {
				fmt.Fprintf(w, "data: %s\n\n", jstr(map[string]interface{}{
					"type":    "status",
					"message": "Reconectando con Arché IA...",
				}))
				w.Flush()
			},
		)

		sources := make([]map[string]interface{}, 0, len(capturedChunks))
		for _, ch := range capturedChunks {
			sources = append(sources, map[string]interface{}{
				"source_type": ch.SourceType,
				"source_id":   ch.SourceID,
				"data_type":   ch.DataType,
				"similarity":  fmt.Sprintf("%.0f%%", ch.Similarity*100),
			})
		}

		if streamErr != nil {
			fmt.Fprintf(w, "data: %s\n\n", jstr(map[string]interface{}{
				"type":  "error",
				"error": "Arché IA no pudo procesar tu solicitud. Intenta de nuevo en unos momentos.",
			}))
		} else {
			fmt.Fprintf(w, "data: %s\n\n", jstr(map[string]interface{}{
				"type":    "done",
				"sources": sources,
				"action":  capturedAction,
			}))
		}
		w.Flush()

		if fullResp.Len() > 0 {
			// Post-stream persistence: we use a context detached from the
			// request (which may already have been cancelled) but with a bounded timeout.
			dbCtx, dbCancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer dbCancel()
			srcJSON, jerr := json.Marshal(capturedChunks)
			if jerr != nil {
				log.Printf("[ARCHE-AI] error serializando sources: %v", jerr)
				srcJSON = []byte("[]")
			}
			logExecErr(h.db.Exec(dbCtx,
				`INSERT INTO ai_messages (conversation_id, role, content, sources)
				 VALUES ($1,'assistant',$2,$3)`,
				capturedConvID, fullResp.String(), srcJSON,
			)).Log("ai-msg-assistant")
			logExecErr(h.db.Exec(dbCtx,
				`UPDATE ai_conversations SET updated_at=NOW(),
				 title=CASE WHEN title IS NULL THEN $2 ELSE title END WHERE id=$1`,
				capturedConvID, truncateStr(capturedMessage, 60),
			)).Log("ai-conv-update")
		}
	})

	return nil
}

// ─── POST /ai/create-wo — create a WO from the chat ─────────────────────────────

func (h *AIHandler) CreateWOFromChat(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req struct {
		NodeID      int64   `json:"node_id"`
		Title       string  `json:"title"`
		Description *string `json:"description"`
		WOType      string  `json:"wo_type"`
		Priority    string  `json:"priority"`
	}
	if err := c.BodyParser(&req); err != nil || req.Title == "" || req.NodeID == 0 {
		return fiber.NewError(fiber.StatusBadRequest, "Título y nodo son requeridos")
	}

	if req.WOType == "" {
		req.WOType = "corrective"
	}
	if req.Priority == "" {
		req.Priority = "medium"
	}

	// Automatic critical priority for critical equipment
	if req.WOType == "corrective" {
		var criticality string
		h.db.QueryRow(c.UserContext(),
			`SELECT criticality FROM factory_nodes WHERE id=$1 AND tenant_id=$2`,
			req.NodeID, claims.TenantID,
		).Scan(&criticality)
		if criticality == "critical" {
			req.Priority = "critical"
		}
	}

	// Transaction with an advisory lock to avoid duplicate WO numbers
	tx, txErr := h.db.Begin(c.UserContext())
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error creando OT desde chat")
	}
	defer tx.Rollback(c.UserContext())

	if _, lockErr := tx.Exec(c.UserContext(), `SELECT pg_advisory_xact_lock($1)`, claims.TenantID); lockErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error creando OT desde chat")
	}

	var woNumber string
	if err := tx.QueryRow(c.UserContext(), `
		SELECT generate_wo_number_prefix() || LPAD(
			(COALESCE((SELECT MAX(CAST(SUBSTRING(wo_number FROM 13) AS INT)) FROM work_orders
			 WHERE tenant_id=$1 AND wo_number LIKE generate_wo_number_prefix() || '%'), 0) + 1)::text, 4, '0')`,
		claims.TenantID,
	).Scan(&woNumber); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error generando número de OT")
	}

	var newID int64
	if err := tx.QueryRow(c.UserContext(),
		`INSERT INTO work_orders
		 (tenant_id, node_id, wo_number, title, description, wo_type, priority, status, created_by)
		 VALUES ($1,$2,$3,$4,$5,$6,$7,'pending',$8) RETURNING id`,
		claims.TenantID, req.NodeID, woNumber, req.Title, req.Description,
		req.WOType, req.Priority, claims.UserID,
	).Scan(&newID); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error creando OT desde chat")
	}

	if _, err := tx.Exec(c.UserContext(),
		`INSERT INTO work_order_log (tenant_id, wo_id, user_id, to_status, comment)
		 VALUES ($1,$2,$3,'pending','OT creada desde Arché IA')`,
		claims.TenantID, newID, claims.UserID,
	); err != nil {
		log.Printf("[ARCHE-AI] error log OT desde chat: %v", err)
	}

	if err := tx.Commit(c.UserContext()); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error creando OT desde chat")
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"id":        newID,
		"wo_number": woNumber,
		"message":   "OT creada correctamente desde Arché IA",
	})
}

// ─── GET /ai/suggest-root-cause/:wo_id — suggest a root cause ──────────────────

func (h *AIHandler) SuggestRootCause(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	woID, err := strconv.ParseInt(c.Params("wo_id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	ctx := c.UserContext()

	if !h.ollama.IsAvailable(ctx) {
		return fiber.NewError(fiber.StatusServiceUnavailable, "Arché IA no disponible")
	}

	// Get the WO data
	var title, nodeName, woType, nodeType string
	var description *string
	var nodeID int64
	var templateID *int64

	err = h.db.QueryRow(ctx,
		`SELECT wo.title, COALESCE(wo.description,''), fn.name, fn.id, fn.template_id,
		        wo.wo_type, fn.node_type
		 FROM work_orders wo JOIN factory_nodes fn ON fn.id=wo.node_id
		 WHERE wo.id=$1 AND wo.tenant_id=$2`,
		woID, claims.TenantID,
	).Scan(&title, &description, &nodeName, &nodeID, &templateID, &woType, &nodeType)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "OT no encontrada")
	}

	query := title
	if description != nil && *description != "" {
		query += " " + *description
	}

	// Get the equipment template info for context
	var templateInfo string
	if templateID != nil {
		var manufacturer, model string
		h.db.QueryRow(ctx,
			`SELECT COALESCE(manufacturer,''), COALESCE(model,'') FROM equipment_templates WHERE id=$1`,
			*templateID,
		).Scan(&manufacturer, &model)
		if manufacturer != "" || model != "" {
			templateInfo = manufacturer + " " + model
		}
	}

	// ═══ Cascading strategy: search by TEMPLATE, not by name ═══

	// 1) RAG: the exact node + equipment on the SAME TEMPLATE (same real machine)
	chunks, _ := h.rag.Search(ctx, query, ai.SearchOptions{
		TenantID:        claims.TenantID,
		NodeID:          &nodeID,
		TemplateID:      templateID,
		IncludeSiblings: templateID != nil,
		Limit:           8,
		MinSimilarity:   0.12,
		Role:            claims.Role,
		UserID:          claims.UserID,
	})

	// 2) When there are not enough and it HAS a template, search only in equipment on the same template
	//    (do NOT search the whole tenant — never mix different machines)
	if len(chunks) < 2 && templateID != nil {
		siblingChunks, _ := h.rag.Search(ctx, query, ai.SearchOptions{
			TenantID:      claims.TenantID,
			NodeID:        nil,
			TemplateID:    templateID,
			IncludeSiblings: true,
			Limit:         6,
			MinSimilarity: 0.10,
			Role:          claims.Role,
			UserID:        claims.UserID,
		})
		seen := make(map[int64]bool)
		for _, c := range chunks {
			seen[c.SourceID] = true
		}
		for _, c := range siblingChunks {
			if !seen[c.SourceID] {
				chunks = append(chunks, c)
				seen[c.SourceID] = true
			}
			if len(chunks) >= 8 {
				break
			}
		}
	}

	// 3) Look for WOs on the SAME equipment or on equipment with the SAME TEMPLATE (not by similar name)
	var sqlHistory []string
	var sqlQuery string
	var sqlArgs []interface{}

	if templateID != nil {
		// Look for WOs on equipment with the same template — they are the same machine
		sqlQuery = `SELECT wo.title || ' [' || wo.status || '] — Equipo: ' || fn.name ||
			COALESCE(' — Causa: ' || wo.root_cause, '') ||
			COALESCE(' — Solucion: ' || wo.solution, '')
		 FROM work_orders wo
		 JOIN factory_nodes fn ON fn.id = wo.node_id
		 WHERE wo.tenant_id = $1
		   AND wo.id != $2
		   AND wo.status IN ('completed','closed','verified')
		   AND fn.template_id = $3
		 ORDER BY wo.created_at DESC
		 LIMIT 8`
		sqlArgs = []interface{}{claims.TenantID, woID, *templateID}
	} else {
		// No template: look only for WOs on the SAME node (do not mix in others)
		sqlQuery = `SELECT wo.title || ' [' || wo.status || '] — Equipo: ' || fn.name ||
			COALESCE(' — Causa: ' || wo.root_cause, '') ||
			COALESCE(' — Solucion: ' || wo.solution, '')
		 FROM work_orders wo
		 JOIN factory_nodes fn ON fn.id = wo.node_id
		 WHERE wo.tenant_id = $1
		   AND wo.id != $2
		   AND wo.status IN ('completed','closed','verified')
		   AND wo.node_id = $3
		 ORDER BY wo.created_at DESC
		 LIMIT 8`
		sqlArgs = []interface{}{claims.TenantID, woID, nodeID}
	}

	sqlRows, _ := h.db.Query(ctx, sqlQuery, sqlArgs...)
	if sqlRows != nil {
		defer sqlRows.Close()
		for sqlRows.Next() {
			var s string
			if sqlRows.Scan(&s) == nil {
				sqlHistory = append(sqlHistory, s)
			}
		}
	}

	// 4) Web search: use the template/model when there is one, otherwise the generic name
	var webInfo string
	if len(chunks) < 2 && len(sqlHistory) < 2 {
		webCtx, webCancel := context.WithTimeout(ctx, 8*time.Second)
		webQuery := title + " causa falla avería"
		if templateInfo != "" {
			webQuery = templateInfo + " " + webQuery
		} else {
			webQuery = nodeName + " " + webQuery
		}
		webResults, werr := h.web.Search(webCtx, webQuery, 3)
		webCancel()
		if werr == nil && len(webResults) > 0 {
			var wb strings.Builder
			for i, r := range webResults {
				wb.WriteString(fmt.Sprintf("[Web %d] %s: %s\n", i+1, r.Title, r.Snippet))
			}
			webInfo = wb.String()
		}
	}

	// ═══ Build a smart prompt ═══

	var promptParts strings.Builder

	promptParts.WriteString(fmt.Sprintf(`Eres un experto en mantenimiento industrial. Te piden diagnosticar una avería.

ORDEN DE TRABAJO ACTUAL:
- Equipo: %s (tipo: %s)
- Titulo: %s
- Tipo de OT: %s`, nodeName, nodeType, title, woType))
	if templateInfo != "" {
		promptParts.WriteString(fmt.Sprintf("\n- Modelo/Plantilla: %s", templateInfo))
	}
	if description != nil && *description != "" {
		promptParts.WriteString(fmt.Sprintf("\n- Descripcion: %s", *description))
	}
	promptParts.WriteString("\n")

	if templateInfo != "" {
		promptParts.WriteString(fmt.Sprintf(`
IMPORTANTE: Este equipo pertenece al modelo "%s". Solo se muestran datos de equipos
del MISMO modelo. No confundir con otros equipos que puedan tener nombres parecidos
pero sean de modelo o tipo diferente.
`, templateInfo))
	}

	hasContext := false

	// Include the RAG chunks
	if len(chunks) > 0 {
		hasContext = true
		promptParts.WriteString("\nHISTORIAL DE AVERIAS — mismo equipo o equipos del MISMO MODELO:\n")
		for i, ch := range chunks {
			promptParts.WriteString(fmt.Sprintf("[%d] %s\n\n", i+1, ch.ChunkText))
		}
	}

	// Include WOs for the same model
	if len(sqlHistory) > 0 {
		hasContext = true
		if templateID != nil {
			promptParts.WriteString("\nOTs DE EQUIPOS DEL MISMO MODELO:\n")
		} else {
			promptParts.WriteString("\nOTs ANTERIORES DE ESTE EQUIPO:\n")
		}
		for _, s := range sqlHistory {
			promptParts.WriteString(fmt.Sprintf("- %s\n", s))
		}
		promptParts.WriteString("\n")
	}

	// Include the web results
	if webInfo != "" {
		hasContext = true
		promptParts.WriteString("\nREFERENCIAS TECNICAS (web):\n")
		promptParts.WriteString(webInfo)
		promptParts.WriteString("\n")
	}

	// Final instructions
	if hasContext {
		promptParts.WriteString(`
INSTRUCCIONES:
Basandote en el historial del mismo modelo de equipo y tu conocimiento tecnico:
1. Indica la CAUSA RAIZ mas probable (2-3 lineas)
2. Sugiere la SOLUCION que mejor aplica
3. Si hay un patron de fallo recurrente en equipos del mismo modelo, mencionalo
4. Haz preguntas de diagnostico para afinar si es necesario
Responde en español, conciso y directo.`)
	} else {
		promptParts.WriteString(`
No hay historial previo de este equipo o modelo en el sistema, pero usa tu conocimiento
tecnico general sobre este tipo de equipo/componente.

INSTRUCCIONES:
1. Indica las CAUSAS RAIZ mas probables para este tipo de averia (2-3 lineas)
2. Sugiere PASOS DE DIAGNOSTICO ordenados de lo mas simple a lo mas complejo
3. Recomienda la SOLUCION mas comun para este tipo de fallo
4. Haz preguntas para obtener mas informacion y afinar el diagnostico
Responde en español, conciso y directo.`)
	}

	if err := h.sem.Acquire(ctx); err != nil {
		return fiber.NewError(fiber.StatusTooManyRequests, "Arché IA ocupada, intenta en unos segundos")
	}
	defer h.sem.Release()

	response, err := h.ollamaForTenant(ctx, claims.TenantID).GenerateSimple(ctx, []ai.Message{
		{Role: "user", Content: promptParts.String()},
	})
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error generando sugerencia")
	}

	sources := len(chunks) + len(sqlHistory)
	msg := "Sugerencia basada en conocimiento técnico general"
	if sources > 0 {
		msg = fmt.Sprintf("Sugerencia basada en %d registros del sistema", sources)
	}
	if webInfo != "" {
		msg += " + referencias web"
	}

	return c.JSON(fiber.Map{
		"suggestion": response,
		"based_on":   sources,
		"message":    msg,
	})
}

// ─── Conversations ───────────────────────────────────────────────────────────

func (h *AIHandler) ListConversations(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	rows, err := h.db.Query(c.UserContext(),
		`SELECT ac.id, ac.title, ac.node_id, fn.name, ac.updated_at::text
		 FROM ai_conversations ac
		 LEFT JOIN factory_nodes fn ON fn.id=ac.node_id
		 WHERE ac.tenant_id=$1 AND ac.user_id=$2
		 ORDER BY ac.updated_at DESC LIMIT 20`,
		claims.TenantID, claims.UserID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error")
	}
	defer rows.Close()

	type Conv struct {
		ID        int64   `json:"id"`
		Title     *string `json:"title"`
		NodeID    *int64  `json:"node_id"`
		NodeName  *string `json:"node_name"`
		UpdatedAt string  `json:"updated_at"`
	}
	var convs []Conv
	for rows.Next() {
		var cv Conv
		if rows.Scan(&cv.ID, &cv.Title, &cv.NodeID, &cv.NodeName, &cv.UpdatedAt) == nil {
			convs = append(convs, cv)
		}
	}
	return c.JSON(fiber.Map{"conversations": convs})
}

func (h *AIHandler) GetConversation(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)

	rows, err := h.db.Query(c.UserContext(),
		`SELECT m.id, m.role, m.content, m.sources, m.created_at::text
		 FROM ai_messages m
		 WHERE m.conversation_id=$1
		   AND m.conversation_id IN (SELECT id FROM ai_conversations WHERE tenant_id=$2 AND user_id=$3)
		   AND m.role != 'system'
		 ORDER BY m.created_at ASC`,
		id, claims.TenantID, claims.UserID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Conversación no encontrada")
	}
	defer rows.Close()

	type Msg struct {
		ID        int64           `json:"id"`
		Role      string          `json:"role"`
		Content   string          `json:"content"`
		Sources   json.RawMessage `json:"sources,omitempty"`
		CreatedAt string          `json:"created_at"`
	}
	var msgs []Msg
	for rows.Next() {
		var m Msg
		if rows.Scan(&m.ID, &m.Role, &m.Content, &m.Sources, &m.CreatedAt) == nil {
			msgs = append(msgs, m)
		}
	}
	return c.JSON(fiber.Map{"messages": msgs})
}

func (h *AIHandler) DeleteConversation(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	h.db.Exec(c.UserContext(),
		`DELETE FROM ai_conversations WHERE id=$1 AND user_id=$2 AND tenant_id=$3`,
		id, claims.UserID, claims.TenantID,
	)
	return c.JSON(fiber.Map{"message": "Conversación eliminada"})
}

func (h *AIHandler) IndexManual(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	sourceType := c.Params("source_type")
	sourceID, err := strconv.ParseInt(c.Params("source_id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}
	if err := ai.EnqueueNow(context.Background(), h.db, claims.TenantID, "index", sourceType, sourceID); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error encolando")
	}
	return c.JSON(fiber.Map{"message": "Indexación encolada"})
}

func (h *AIHandler) IndexAllNodes(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	if claims.Role != "admin" && claims.Role != "supervisor" {
		return fiber.NewError(fiber.StatusForbidden, "Solo admin o supervisor")
	}
	ctx := c.UserContext()
	go func() { h.rag.IndexAllNodes(context.Background(), claims.TenantID) }()
	var nodeCount int
	h.db.QueryRow(ctx,
		`SELECT COUNT(*) FROM factory_nodes WHERE tenant_id=$1 AND status!='decommissioned'`,
		claims.TenantID,
	).Scan(&nodeCount)
	return c.JSON(fiber.Map{
		"message": fmt.Sprintf("Indexando %d nodos en background", nodeCount),
		"nodes":   nodeCount,
	})
}

func (h *AIHandler) ReindexAll(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	if claims.Role != "admin" {
		return fiber.NewError(fiber.StatusForbidden, "Solo administradores")
	}
	ctx := c.UserContext()

	// Re-index EVERY completed or closed WO (without filtering by verification)
	woRows, _ := h.db.Query(ctx,
		`SELECT id FROM work_orders
		 WHERE tenant_id=$1 AND status IN ('completed','closed')`,
		claims.TenantID,
	)
	count := 0
	enqueueErrors := 0
	if woRows != nil {
		defer woRows.Close()
		for woRows.Next() {
			var woID int64
			if woRows.Scan(&woID) == nil {
				if err := ai.EnqueueNow(ctx, h.db, claims.TenantID, "reindex", "work_order", woID); err != nil {
					log.Printf("[ARCHE-AI] Error encolando WO %d: %v", woID, err)
					enqueueErrors++
				} else {
					count++
				}
			}
		}
	}

	spRows, _ := h.db.Query(ctx,
		`SELECT id FROM spare_parts WHERE tenant_id=$1`, claims.TenantID)
	if spRows != nil {
		defer spRows.Close()
		for spRows.Next() {
			var spID int64
			if spRows.Scan(&spID) == nil {
				if err := ai.EnqueueNow(ctx, h.db, claims.TenantID, "reindex", "spare_part", spID); err != nil {
					log.Printf("[ARCHE-AI] Error encolando repuesto %d: %v", spID, err)
					enqueueErrors++
				} else {
					count++
				}
			}
		}
	}

	mpRows, _ := h.db.Query(ctx,
		`SELECT id FROM maintenance_plans WHERE tenant_id=$1`, claims.TenantID)
	if mpRows != nil {
		defer mpRows.Close()
		for mpRows.Next() {
			var mpID int64
			if mpRows.Scan(&mpID) == nil {
				if err := ai.EnqueueNow(ctx, h.db, claims.TenantID, "reindex", "maintenance_plan", mpID); err != nil {
					log.Printf("[ARCHE-AI] Error encolando plan %d: %v", mpID, err)
					enqueueErrors++
				} else {
					count++
				}
			}
		}
	}

	go func() { h.rag.IndexAllNodes(context.Background(), claims.TenantID) }()
	msg := fmt.Sprintf("%d items encolados + nodos indexando", count)
	if enqueueErrors > 0 {
		msg += fmt.Sprintf(" (%d errores al encolar)", enqueueErrors)
	}
	return c.JSON(fiber.Map{"message": msg})
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

// detectAction inspects the message to spot action intents
func (h *AIHandler) detectAction(message string) string {
	msg := strings.ToLower(message)
	if strings.Contains(msg, "crea") || strings.Contains(msg, "crear") ||
		strings.Contains(msg, "abre") || strings.Contains(msg, "abrir") ||
		strings.Contains(msg, "genera") || strings.Contains(msg, "generar") {
		if strings.Contains(msg, "ot") || strings.Contains(msg, "orden") {
			return "create_wo"
		}
	}
	return ""
}

func (h *AIHandler) getOrCreateConversation(
	ctx context.Context, claims *types.Claims, convID *int64, nodeID *int64,
) (int64, error) {
	if convID != nil {
		var exists bool
		h.db.QueryRow(ctx,
			`SELECT EXISTS(SELECT 1 FROM ai_conversations WHERE id=$1 AND user_id=$2 AND tenant_id=$3)`,
			*convID, claims.UserID, claims.TenantID,
		).Scan(&exists)
		if exists {
			return *convID, nil
		}
	}
	var newID int64
	err := h.db.QueryRow(ctx,
		`INSERT INTO ai_conversations (tenant_id, user_id, node_id) VALUES ($1,$2,$3) RETURNING id`,
		claims.TenantID, claims.UserID, nodeID,
	).Scan(&newID)
	return newID, err
}

func (h *AIHandler) getConversationHistory(ctx context.Context, convID int64, limit int) ([]ai.Message, error) {
	rows, err := h.db.Query(ctx,
		`SELECT role, content FROM ai_messages
		 WHERE conversation_id=$1 AND role!='system'
		 ORDER BY created_at DESC LIMIT $2`,
		convID, limit,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var msgs []ai.Message
	for rows.Next() {
		var m ai.Message
		if rows.Scan(&m.Role, &m.Content) == nil {
			msgs = append(msgs, m)
		}
	}
	for i, j := 0, len(msgs)-1; i < j; i, j = i+1, j-1 {
		msgs[i], msgs[j] = msgs[j], msgs[i]
	}
	return msgs, nil
}

func jstr(v interface{}) string {
	b, _ := json.Marshal(v)
	return string(b)
}

func truncateStr(s string, n int) string {
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	return string(r[:n]) + "..."
}

