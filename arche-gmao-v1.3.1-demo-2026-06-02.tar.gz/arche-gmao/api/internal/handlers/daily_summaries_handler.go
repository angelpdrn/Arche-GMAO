package handlers

import (
	"archive/zip"
	"bytes"
	"fmt"
	"strconv"
	"strings"
	"time"

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/xuri/excelize/v2"
)

type DailySummariesHandler struct {
	db *pgxpool.Pool
}

func NewDailySummariesHandler(db *pgxpool.Pool) *DailySummariesHandler {
	return &DailySummariesHandler{db: db}
}

// ─── GET /daily-summaries?user_id=&month=YYYY-MM ────────────────────────────

func (h *DailySummariesHandler) List(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	userID, _ := strconv.ParseInt(c.Query("user_id", "0"), 10, 64)
	month := c.Query("month") // YYYY-MM

	// Technicians only see their own
	if claims.Role != "admin" && claims.Role != "supervisor" {
		userID = claims.UserID
	}
	if userID == 0 {
		userID = claims.UserID
	}
	if month == "" {
		month = time.Now().Format("2006-01")
	}

	rows, err := h.db.Query(c.UserContext(),
		`SELECT ds.id, ds.summary_date::text, ds.client_id, COALESCE(cl.name, 'Interno'),
		        ds.wo_id, COALESCE(wo.wo_number, ''), COALESCE(wo.title, ''),
		        COALESCE(ds.project_number, ''), ds.shift, ds.shift_extras,
		        ds.hours, COALESCE(ds.observations, ''),
		        ds.created_at::text, ds.updated_at::text
		 FROM daily_summaries ds
		 LEFT JOIN clients cl ON cl.id = ds.client_id
		 LEFT JOIN work_orders wo ON wo.id = ds.wo_id
		 WHERE ds.tenant_id=$1 AND ds.user_id=$2
		   AND TO_CHAR(ds.summary_date, 'YYYY-MM') = $3
		 ORDER BY ds.summary_date, ds.created_at`,
		claims.TenantID, userID, month,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando resúmenes")
	}
	defer rows.Close()

	type Summary struct {
		ID            int64    `json:"id"`
		SummaryDate   string   `json:"summary_date"`
		ClientID      *int64   `json:"client_id"`
		ClientName    string   `json:"client_name"`
		WOID          *int64   `json:"wo_id"`
		WONumber      string   `json:"wo_number"`
		WOTitle       string   `json:"wo_title"`
		ProjectNumber string   `json:"project_number"`
		Shift         string   `json:"shift"`
		ShiftExtras   []string `json:"shift_extras"`
		Hours         float64  `json:"hours"`
		Observations  string   `json:"observations"`
		CreatedAt     string   `json:"created_at"`
		UpdatedAt     string   `json:"updated_at"`
	}

	var summaries []Summary
	for rows.Next() {
		var s Summary
		if err := rows.Scan(&s.ID, &s.SummaryDate, &s.ClientID, &s.ClientName,
			&s.WOID, &s.WONumber, &s.WOTitle,
			&s.ProjectNumber, &s.Shift, &s.ShiftExtras,
			&s.Hours, &s.Observations,
			&s.CreatedAt, &s.UpdatedAt); err != nil {
			continue
		}
		summaries = append(summaries, s)
	}
	if summaries == nil {
		summaries = []Summary{}
	}

	return c.JSON(fiber.Map{"summaries": summaries})
}

// ─── POST /daily-summaries ──────────────────────────────────────────────────

func (h *DailySummariesHandler) Create(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req struct {
		SummaryDate   string   `json:"summary_date"`
		ClientID      *int64   `json:"client_id"`
		WOID          *int64   `json:"wo_id"`
		ProjectNumber string   `json:"project_number"`
		Shift         string   `json:"shift"`
		ShiftExtras   []string `json:"shift_extras"`
		Hours         float64  `json:"hours"`
		Observations  string   `json:"observations"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Datos inválidos")
	}

	if req.SummaryDate == "" || req.Shift == "" {
		return fiber.NewError(fiber.StatusBadRequest, "Fecha y turno son obligatorios")
	}
	if req.Shift != "mañana" && req.Shift != "tarde" && req.Shift != "noche" {
		return fiber.NewError(fiber.StatusBadRequest, "Turno debe ser: mañana, tarde o noche")
	}

	// Validate shift_extras
	validExtras := map[string]bool{"fin_de_semana": true, "festivo": true, "reten": true, "guardia": true}
	for _, e := range req.ShiftExtras {
		if !validExtras[e] {
			return fiber.NewError(fiber.StatusBadRequest, "Extra de turno inválido: "+e)
		}
	}

	// Check that the month is not frozen
	summaryDate, err := time.Parse("2006-01-02", req.SummaryDate)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Formato de fecha inválido (YYYY-MM-DD)")
	}
	if h.isMonthFrozen(c, claims.TenantID, summaryDate) {
		return fiber.NewError(fiber.StatusForbidden, "El mes está cerrado y no se puede modificar")
	}

	var id int64
	err = h.db.QueryRow(c.UserContext(),
		`INSERT INTO daily_summaries
		 (tenant_id, user_id, summary_date, client_id, wo_id, project_number,
		  shift, shift_extras, hours, observations)
		 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
		claims.TenantID, claims.UserID, req.SummaryDate,
		req.ClientID, req.WOID, nilIfEmpty(req.ProjectNumber),
		req.Shift, req.ShiftExtras, req.Hours, nilIfEmpty(req.Observations),
	).Scan(&id)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error creando resumen: "+err.Error())
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": id, "message": "Resumen creado"})
}

// ─── PUT /daily-summaries/:id ───────────────────────────────────────────────

func (h *DailySummariesHandler) Update(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	// Check ownership and get the date
	var ownerID int64
	var dateStr string
	err = h.db.QueryRow(c.UserContext(),
		`SELECT user_id, summary_date::text FROM daily_summaries WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	).Scan(&ownerID, &dateStr)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Resumen no encontrado")
	}
	if ownerID != claims.UserID && claims.Role != "admin" {
		return fiber.NewError(fiber.StatusForbidden, "Solo puedes editar tus propios resúmenes")
	}

	summaryDate, _ := time.Parse("2006-01-02", dateStr)
	if h.isMonthFrozen(c, claims.TenantID, summaryDate) {
		return fiber.NewError(fiber.StatusForbidden, "El mes está cerrado y no se puede modificar")
	}

	var req struct {
		ClientID      *int64   `json:"client_id"`
		WOID          *int64   `json:"wo_id"`
		ProjectNumber string   `json:"project_number"`
		Shift         string   `json:"shift"`
		ShiftExtras   []string `json:"shift_extras"`
		Hours         float64  `json:"hours"`
		Observations  string   `json:"observations"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Datos inválidos")
	}

	_, err = h.db.Exec(c.UserContext(),
		`UPDATE daily_summaries SET
		 client_id=$3, wo_id=$4, project_number=$5,
		 shift=$6, shift_extras=$7, hours=$8, observations=$9, updated_at=NOW()
		 WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
		req.ClientID, req.WOID, nilIfEmpty(req.ProjectNumber),
		req.Shift, req.ShiftExtras, req.Hours, nilIfEmpty(req.Observations),
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error actualizando resumen")
	}
	return c.JSON(fiber.Map{"message": "Resumen actualizado"})
}

// ─── DELETE /daily-summaries/:id ────────────────────────────────────────────

func (h *DailySummariesHandler) Delete(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	// Check ownership and date
	var ownerID int64
	var dateStr string
	err = h.db.QueryRow(c.UserContext(),
		`SELECT user_id, summary_date::text FROM daily_summaries WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	).Scan(&ownerID, &dateStr)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Resumen no encontrado")
	}
	if ownerID != claims.UserID && claims.Role != "admin" {
		return fiber.NewError(fiber.StatusForbidden, "Solo puedes eliminar tus propios resúmenes")
	}

	summaryDate, _ := time.Parse("2006-01-02", dateStr)
	if h.isMonthFrozen(c, claims.TenantID, summaryDate) {
		return fiber.NewError(fiber.StatusForbidden, "El mes está cerrado y no se puede modificar")
	}

	result, err := h.db.Exec(c.UserContext(),
		`DELETE FROM daily_summaries WHERE id=$1 AND tenant_id=$2`, id, claims.TenantID)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusInternalServerError, "Error eliminando resumen")
	}
	return c.JSON(fiber.Map{"message": "Resumen eliminado"})
}

// ─── GET /daily-summaries/days?user_id=&month=YYYY-MM ───────────────────────

func (h *DailySummariesHandler) GetDays(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	userID, _ := strconv.ParseInt(c.Query("user_id", "0"), 10, 64)
	month := c.Query("month")

	if claims.Role != "admin" && claims.Role != "supervisor" {
		userID = claims.UserID
	}
	if userID == 0 {
		userID = claims.UserID
	}
	if month == "" {
		month = time.Now().Format("2006-01")
	}

	rows, err := h.db.Query(c.UserContext(),
		`SELECT summary_date::text, COUNT(*), SUM(hours)
		 FROM daily_summaries
		 WHERE tenant_id=$1 AND user_id=$2
		   AND TO_CHAR(summary_date, 'YYYY-MM') = $3
		 GROUP BY summary_date
		 ORDER BY summary_date`,
		claims.TenantID, userID, month,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando días")
	}
	defer rows.Close()

	type DayInfo struct {
		Date  string  `json:"date"`
		Count int     `json:"count"`
		Hours float64 `json:"hours"`
	}
	var days []DayInfo
	for rows.Next() {
		var d DayInfo
		if rows.Scan(&d.Date, &d.Count, &d.Hours) == nil {
			days = append(days, d)
		}
	}
	if days == nil {
		days = []DayInfo{}
	}

	// Freeze information for the month
	frozen := false
	var frozenAt *string
	h.db.QueryRow(c.UserContext(),
		`SELECT frozen, frozen_at::text FROM monthly_summary_folders
		 WHERE tenant_id=$1 AND month=$2`,
		claims.TenantID, month,
	).Scan(&frozen, &frozenAt)

	return c.JSON(fiber.Map{"days": days, "frozen": frozen, "frozen_at": frozenAt})
}

// ─── GET /daily-summaries/recent-wos ────────────────────────────────────────

func (h *DailySummariesHandler) RecentWOs(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	dateStr := c.Query("date") // YYYY-MM-DD

	var rows pgx.Rows
	var err error

	if dateStr != "" {
		// Filter WOs where the technician has an interval (start or end) on that day
		rows, err = h.db.Query(c.UserContext(),
			`SELECT DISTINCT wo.id, wo.wo_number, wo.title, COALESCE(fn.name, '')
			 FROM work_orders wo
			 JOIN work_order_intervals woi ON woi.wo_id = wo.id AND woi.tenant_id = wo.tenant_id
			 LEFT JOIN factory_nodes fn ON fn.id = wo.node_id
			 WHERE wo.tenant_id=$1 AND wo.assigned_to=$2
			   AND (woi.started_at::date = $3::date
			        OR (woi.ended_at IS NOT NULL AND woi.ended_at::date = $3::date))
			 ORDER BY wo.wo_number`,
			claims.TenantID, claims.UserID, dateStr,
		)
	} else {
		// Fallback: the last 20 assigned WOs
		rows, err = h.db.Query(c.UserContext(),
			`SELECT wo.id, wo.wo_number, wo.title, COALESCE(fn.name, '')
			 FROM work_orders wo
			 LEFT JOIN factory_nodes fn ON fn.id = wo.node_id
			 WHERE wo.tenant_id=$1 AND wo.assigned_to=$2
			 ORDER BY wo.updated_at DESC NULLS LAST
			 LIMIT 20`,
			claims.TenantID, claims.UserID,
		)
	}
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando OTs")
	}
	defer rows.Close()

	type WOOption struct {
		ID       int64  `json:"id"`
		WONumber string `json:"wo_number"`
		Title    string `json:"title"`
		NodeName string `json:"node_name"`
	}
	var wos []WOOption
	for rows.Next() {
		var w WOOption
		if rows.Scan(&w.ID, &w.WONumber, &w.Title, &w.NodeName) == nil {
			wos = append(wos, w)
		}
	}
	if wos == nil {
		wos = []WOOption{}
	}

	return c.JSON(fiber.Map{"work_orders": wos})
}

// ─── GET /daily-summaries/months — available monthly folders ───────────

func (h *DailySummariesHandler) MonthlyFolders(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	if claims.Role != "admin" && claims.Role != "supervisor" {
		return fiber.NewError(fiber.StatusForbidden, "Acceso denegado")
	}

	rows, err := h.db.Query(c.UserContext(),
		`SELECT DISTINCT TO_CHAR(summary_date, 'YYYY-MM') AS month
		 FROM daily_summaries WHERE tenant_id=$1
		 UNION
		 SELECT month FROM monthly_summary_folders WHERE tenant_id=$1
		 ORDER BY month DESC`,
		claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error")
	}
	defer rows.Close()

	type MonthInfo struct {
		Month  string `json:"month"`
		Frozen bool   `json:"frozen"`
	}
	var months []MonthInfo
	for rows.Next() {
		var m MonthInfo
		if rows.Scan(&m.Month) == nil {
			// Check whether it is frozen
			h.db.QueryRow(c.UserContext(),
				`SELECT frozen FROM monthly_summary_folders WHERE tenant_id=$1 AND month=$2`,
				claims.TenantID, m.Month,
			).Scan(&m.Frozen)
			months = append(months, m)
		}
	}
	if months == nil {
		months = []MonthInfo{}
	}

	return c.JSON(fiber.Map{"months": months})
}

// ─── GET /daily-summaries/export?user_id=&month=YYYY-MM — individual Excel ──

func (h *DailySummariesHandler) ExportUser(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	if claims.Role != "admin" && claims.Role != "supervisor" {
		return fiber.NewError(fiber.StatusForbidden, "Acceso denegado")
	}

	userID, _ := strconv.ParseInt(c.Query("user_id"), 10, 64)
	month := c.Query("month")
	if userID == 0 || month == "" {
		return fiber.NewError(fiber.StatusBadRequest, "Parámetros user_id y month son requeridos")
	}

	var userName, userRole string
	err := h.db.QueryRow(c.UserContext(),
		`SELECT full_name, role FROM users WHERE id=$1 AND tenant_id=$2`,
		userID, claims.TenantID,
	).Scan(&userName, &userRole)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Usuario no encontrado")
	}

	excelBytes, err := h.buildUserMonthlyExcel(c, claims.TenantID, userID, userName, userRole, month)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error generando Excel: "+err.Error())
	}

	fileName := fmt.Sprintf("Resumen_%s_%s.xlsx", sanitizeForFile(userName), month)
	c.Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	c.Set("Content-Disposition", fmt.Sprintf(`attachment; filename="%s"`, sanitizeFileName(fileName)))
	return c.Send(excelBytes)
}

// ─── GET /daily-summaries/export-all?month=YYYY-MM — bulk ZIP ─────────────

func (h *DailySummariesHandler) ExportAll(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	if claims.Role != "admin" && claims.Role != "supervisor" {
		return fiber.NewError(fiber.StatusForbidden, "Acceso denegado")
	}

	month := c.Query("month")
	if month == "" {
		return fiber.NewError(fiber.StatusBadRequest, "Parámetro month requerido")
	}

	// Check whether there is a frozen folder with precomputed data
	var fileData []byte
	err := h.db.QueryRow(c.UserContext(),
		`SELECT file_data FROM monthly_summary_folders
		 WHERE tenant_id=$1 AND month=$2 AND frozen=true AND file_data IS NOT NULL`,
		claims.TenantID, month,
	).Scan(&fileData)
	if err == nil && len(fileData) > 0 {
		fileName := fmt.Sprintf("Resumenes_%s.zip", month)
		c.Set("Content-Type", "application/zip")
		c.Set("Content-Disposition", fmt.Sprintf(`attachment; filename="%s"`, sanitizeFileName(fileName)))
		return c.Send(fileData)
	}

	// Build the ZIP on the fly
	zipBytes, err := h.buildAllUsersZIP(c, claims.TenantID, month)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error generando ZIP: "+err.Error())
	}

	fileName := fmt.Sprintf("Resumenes_%s.zip", month)
	c.Set("Content-Type", "application/zip")
	c.Set("Content-Disposition", fmt.Sprintf(`attachment; filename="%s"`, sanitizeFileName(fileName)))
	return c.Send(zipBytes)
}

// ─── Helpers ────────────────────────────────────────────────────────────────

func (h *DailySummariesHandler) isMonthFrozen(c *fiber.Ctx, tenantID int64, date time.Time) bool {
	monthStr := date.Format("2006-01")
	currentMonth := time.Now().Format("2006-01")

	// Current and future months: never frozen
	if monthStr >= currentMonth {
		return false
	}

	// Check whether there is an explicit freeze
	var frozen bool
	err := h.db.QueryRow(c.UserContext(),
		`SELECT frozen FROM monthly_summary_folders WHERE tenant_id=$1 AND month=$2`,
		tenantID, monthStr,
	).Scan(&frozen)
	if err == nil && frozen {
		return true
	}

	// 10 working day grace period: compute it
	// First day of the next month
	nextMonth := time.Date(date.Year(), date.Month()+1, 1, 0, 0, 0, 0, time.UTC)
	deadline := addBusinessDays(nextMonth, 10)

	return time.Now().After(deadline)
}

func addBusinessDays(start time.Time, days int) time.Time {
	d := start
	added := 0
	for added < days {
		d = d.AddDate(0, 0, 1)
		if d.Weekday() != time.Saturday && d.Weekday() != time.Sunday {
			added++
		}
	}
	return d
}

func (h *DailySummariesHandler) buildUserMonthlyExcel(c *fiber.Ctx, tenantID, userID int64, userName, userRole, month string) ([]byte, error) {
	rows, err := h.db.Query(c.UserContext(),
		`SELECT ds.summary_date::text, COALESCE(cl.name, 'Interno'),
		        COALESCE(wo.wo_number, ''), COALESCE(wo.title, ''),
		        COALESCE(ds.project_number, 'Interno'), ds.shift, ds.shift_extras,
		        ds.hours, COALESCE(ds.observations, ''),
		        COALESCE(fn.name, '')
		 FROM daily_summaries ds
		 LEFT JOIN clients cl ON cl.id = ds.client_id
		 LEFT JOIN work_orders wo ON wo.id = ds.wo_id
		 LEFT JOIN factory_nodes fn ON fn.id = wo.node_id
		 WHERE ds.tenant_id=$1 AND ds.user_id=$2
		   AND TO_CHAR(ds.summary_date, 'YYYY-MM') = $3
		 ORDER BY ds.summary_date, ds.created_at`,
		tenantID, userID, month,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	f := excelize.NewFile()
	defer f.Close()

	headerStyle, _ := f.NewStyle(&excelize.Style{
		Fill:      excelize.Fill{Type: "pattern", Color: []string{"0F3460"}, Pattern: 1},
		Font:      &excelize.Font{Color: "FFFFFF", Bold: true, Size: 10},
		Alignment: &excelize.Alignment{Horizontal: "center", Vertical: "center", WrapText: true},
	})
	dateStyle, _ := f.NewStyle(&excelize.Style{
		Fill: excelize.Fill{Type: "pattern", Color: []string{"E8EAF6"}, Pattern: 1},
		Font: &excelize.Font{Bold: true, Size: 10},
	})

	// ─── Detail sheet ───
	f.SetSheetName("Sheet1", "Detalle")
	headers := []string{"Fecha", "Cliente", "N° OT", "Titulo OT", "Equipo", "Proyecto", "Turno", "Extras", "Horas", "Observaciones"}
	for i, h := range headers {
		col := string(rune('A' + i))
		f.SetCellValue("Detalle", col+"1", h)
	}
	f.SetCellStyle("Detalle", "A1", "J1", headerStyle)
	f.SetColWidth("Detalle", "A", "A", 12)
	f.SetColWidth("Detalle", "B", "B", 18)
	f.SetColWidth("Detalle", "C", "C", 20)
	f.SetColWidth("Detalle", "D", "D", 30)
	f.SetColWidth("Detalle", "E", "E", 22)
	f.SetColWidth("Detalle", "F", "F", 14)
	f.SetColWidth("Detalle", "G", "G", 10)
	f.SetColWidth("Detalle", "H", "H", 28)
	f.SetColWidth("Detalle", "I", "I", 8)
	f.SetColWidth("Detalle", "J", "J", 40)

	row := 2
	var totalHours float64
	var totalEntries int
	daysSet := map[string]bool{}
	shiftCount := map[string]int{}
	lastDate := ""

	for rows.Next() {
		var date, client, woNum, woTitle, project, shift, obs, nodeName string
		var extras []string
		var hours float64
		if rows.Scan(&date, &client, &woNum, &woTitle, &project, &shift, &extras, &hours, &obs, &nodeName) != nil {
			continue
		}

		// Visual separator per day
		if date != lastDate && lastDate != "" {
			f.SetCellStyle("Detalle", fmt.Sprintf("A%d", row), fmt.Sprintf("J%d", row), dateStyle)
			row++
		}
		lastDate = date

		f.SetCellValue("Detalle", fmt.Sprintf("A%d", row), date)
		f.SetCellValue("Detalle", fmt.Sprintf("B%d", row), client)
		f.SetCellValue("Detalle", fmt.Sprintf("C%d", row), woNum)
		f.SetCellValue("Detalle", fmt.Sprintf("D%d", row), woTitle)
		f.SetCellValue("Detalle", fmt.Sprintf("E%d", row), nodeName)
		f.SetCellValue("Detalle", fmt.Sprintf("F%d", row), project)
		f.SetCellValue("Detalle", fmt.Sprintf("G%d", row), shift)
		f.SetCellValue("Detalle", fmt.Sprintf("H%d", row), strings.Join(extras, ", "))
		f.SetCellValue("Detalle", fmt.Sprintf("I%d", row), fmt.Sprintf("%.1f", hours))
		f.SetCellValue("Detalle", fmt.Sprintf("J%d", row), obs)
		row++

		totalHours += hours
		totalEntries++
		daysSet[date] = true
		shiftCount[shift]++
	}

	// ─── Summary sheet ───
	f.NewSheet("Resumen")
	monthLabel := spanishMonthLabel(month)
	f.SetCellValue("Resumen", "A1", "RESUMEN MENSUAL DE HORAS")
	f.SetCellValue("Resumen", "A2", "Tecnico: "+userName)
	f.SetCellValue("Resumen", "A3", "Rol: "+userRole)
	f.SetCellValue("Resumen", "A4", "Periodo: "+monthLabel)
	f.SetCellValue("Resumen", "A5", "Generado: "+time.Now().Format("02/01/2006 15:04"))

	f.SetCellValue("Resumen", "A7", "Dias con registro:")
	f.SetCellValue("Resumen", "B7", len(daysSet))
	f.SetCellValue("Resumen", "A8", "Total entradas:")
	f.SetCellValue("Resumen", "B8", totalEntries)
	f.SetCellValue("Resumen", "A9", "Horas totales:")
	f.SetCellValue("Resumen", "B9", fmt.Sprintf("%.1f", totalHours))

	r := 11
	f.SetCellValue("Resumen", fmt.Sprintf("A%d", r), "Por turno:")
	r++
	for shift, cnt := range shiftCount {
		f.SetCellValue("Resumen", fmt.Sprintf("A%d", r), shift)
		f.SetCellValue("Resumen", fmt.Sprintf("B%d", r), cnt)
		r++
	}

	f.SetCellStyle("Resumen", "A1", "A1", headerStyle)
	f.SetColWidth("Resumen", "A", "A", 22)
	f.SetColWidth("Resumen", "B", "B", 14)

	var buf bytes.Buffer
	if err := f.Write(&buf); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

func (h *DailySummariesHandler) buildAllUsersZIP(c *fiber.Ctx, tenantID int64, month string) ([]byte, error) {
	// Get every user with summaries in that month
	rows, err := h.db.Query(c.UserContext(),
		`SELECT DISTINCT ds.user_id, u.full_name, u.role
		 FROM daily_summaries ds
		 JOIN users u ON u.id = ds.user_id
		 WHERE ds.tenant_id=$1 AND TO_CHAR(ds.summary_date, 'YYYY-MM') = $2
		 ORDER BY u.full_name`,
		tenantID, month,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	type userInfo struct {
		ID   int64
		Name string
		Role string
	}
	var users []userInfo
	for rows.Next() {
		var u userInfo
		if rows.Scan(&u.ID, &u.Name, &u.Role) == nil {
			users = append(users, u)
		}
	}

	if len(users) == 0 {
		return nil, fmt.Errorf("no hay resúmenes para %s", month)
	}

	// Create the ZIP
	var zipBuf bytes.Buffer
	zw := zip.NewWriter(&zipBuf)

	monthLabel := spanishMonthLabel(month)
	folderName := fmt.Sprintf("Resumenes_%s", monthLabel)

	for _, u := range users {
		excelBytes, err := h.buildUserMonthlyExcel(c, tenantID, u.ID, u.Name, u.Role, month)
		if err != nil {
			continue
		}
		fileName := fmt.Sprintf("%s/%s_%s.xlsx", folderName, sanitizeForFile(u.Name), month)
		w, err := zw.Create(fileName)
		if err != nil {
			continue
		}
		w.Write(excelBytes)
	}

	if err := zw.Close(); err != nil {
		return nil, err
	}
	return zipBuf.Bytes(), nil
}

func nilIfEmpty(s string) *string {
	if s == "" {
		return nil
	}
	return &s
}

func spanishMonthLabel(monthStr string) string {
	months := map[string]string{
		"01": "Enero", "02": "Febrero", "03": "Marzo", "04": "Abril",
		"05": "Mayo", "06": "Junio", "07": "Julio", "08": "Agosto",
		"09": "Septiembre", "10": "Octubre", "11": "Noviembre", "12": "Diciembre",
	}
	parts := strings.Split(monthStr, "-")
	if len(parts) == 2 {
		if m, ok := months[parts[1]]; ok {
			return m + " " + parts[0]
		}
	}
	return monthStr
}
