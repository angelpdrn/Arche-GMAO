package handlers

import (
	"testing"
)

func TestNormalizeEmail(t *testing.T) {
	tests := []struct {
		name  string
		input string
		want  string
	}{
		{"valid simple", "user@example.com", "user@example.com"},
		{"uppercase", "User@Example.COM", "user@example.com"},
		{"whitespace", "  user@example.com  ", "user@example.com"},
		{"with name", "John <john@example.com>", "john@example.com"},
		{"empty", "", ""},
		{"no at", "invalid", ""},
		{"only spaces", "   ", ""},
		{"too long", string(make([]byte, 256)), ""},
		{"valid with dots", "a.b.c@example.com", "a.b.c@example.com"},
		{"valid with plus", "user+tag@example.com", "user+tag@example.com"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := normalizeEmail(tt.input)
			if got != tt.want {
				t.Errorf("normalizeEmail(%q) = %q, want %q", tt.input, got, tt.want)
			}
		})
	}
}
