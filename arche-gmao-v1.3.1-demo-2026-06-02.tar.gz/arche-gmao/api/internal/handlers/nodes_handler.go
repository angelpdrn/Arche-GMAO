package handlers

import (
	"context"
	"fmt"
	"log"
	"strconv"

	"arche-gmao/api/internal/ai"
	"arche-gmao/api/internal/license"
	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type NodesHandler struct {
	db *pgxpool.Pool
}

func NewNodesHandler(db *pgxpool.Pool) *NodesHandler {
	return &NodesHandler{db: db}
}

// ─── Response types ───────────────────────────────────────────────────────

type NodeResponse struct {
	ID              int64           `json:"id"`
	ParentID        *int64          `json:"parent_id"`
	ClientID        *int64          `json:"client_id"`
	Name            string          `json:"name"`
	Code            *string         `json:"code"`
	NodeType        string          `json:"node_type"`
	Status          string          `json:"status"`
	Criticality     string          `json:"criticality"`
	Description     *string         `json:"description"`
	Manufacturer    *string         `json:"manufacturer"`
	Model           *string         `json:"model"`
	SerialNumber    *string         `json:"serial_number"`
	YearInstalled   *int            `json:"year_installed"`
	RatedPowerKW    *float64        `json:"rated_power_kw"`
	Path            string          `json:"path"`
	Version         int             `json:"version"`
	CreatedBy       *int64          `json:"created_by"`
	UpdatedBy       *int64          `json:"updated_by"`
	CreatedByName   *string         `json:"created_by_name"`
	UpdatedByName   *string         `json:"updated_by_name"`
	CreatedAt       string          `json:"created_at"`
	UpdatedAt       string          `json:"updated_at"`
	Children        []*NodeResponse `json:"children"`
	Tags            []TagSummary    `json:"tags"`
}

type TagSummary struct {
	ID    int64  `json:"id"`
	Name  string `json:"name"`
	Color string `json:"color"`
}

// ─── GET /factory/tree ────────────────────────────────────────────────────────

func (h *NodesHandler) GetTree(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	// Technicians and operators only see assigned nodes and their ancestors/children
	query := `SELECT
			fn.id, fn.parent_id, fn.client_id, fn.name, fn.code,
			fn.node_type, fn.status, fn.criticality, fn.description,
			fn.manufacturer, fn.model, fn.serial_number, fn.year_installed,
			fn.rated_power_kw, fn.path::text, fn.version,
			fn.created_by, fn.updated_by,
			uc.full_name, uu.full_name,
			fn.created_at::text, fn.updated_at::text
		FROM factory_nodes fn
		LEFT JOIN users uc ON uc.id = fn.created_by
		LEFT JOIN users uu ON uu.id = fn.updated_by
		WHERE fn.tenant_id = $1
		  AND fn.status != 'decommissioned'`
	args := []interface{}{claims.TenantID}

	// Every role except admin and auditor sees only assigned nodes + ancestors/children
	if claims.Role != "admin" && claims.Role != "auditor" {
		query += ` AND EXISTS (
			SELECT 1 FROM node_assignments na
			JOIN factory_nodes assigned ON assigned.id = na.node_id AND assigned.tenant_id = $1
			WHERE na.user_id = $2 AND na.tenant_id = $1
			  AND (fn.path <@ assigned.path OR assigned.path <@ fn.path)
		)`
		args = append(args, claims.UserID)
	}

	query += ` ORDER BY fn.path`

	rows, err := h.db.Query(c.UserContext(), query, args...)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando nodos")
	}
	defer rows.Close()

	// Phase 1: build the node map
	nodeMap := make(map[int64]*NodeResponse)
	var allIDs []int64

	for rows.Next() {
		n := &NodeResponse{Children: []*NodeResponse{}, Tags: []TagSummary{}}
		if err := rows.Scan(
			&n.ID, &n.ParentID, &n.ClientID, &n.Name, &n.Code,
			&n.NodeType, &n.Status, &n.Criticality, &n.Description,
			&n.Manufacturer, &n.Model, &n.SerialNumber, &n.YearInstalled,
			&n.RatedPowerKW, &n.Path, &n.Version,
			&n.CreatedBy, &n.UpdatedBy,
			&n.CreatedByName, &n.UpdatedByName,
			&n.CreatedAt, &n.UpdatedAt,
		); err != nil {
			return fiber.NewError(fiber.StatusInternalServerError, "Error leyendo nodo")
		}
		nodeMap[n.ID] = n
		allIDs = append(allIDs, n.ID)
	}

	// Load the tags of every node in a single query
	if len(allIDs) > 0 {
		tagRows, err := h.db.Query(c.UserContext(),
			`SELECT nt.node_id, t.id, t.name, t.color
			 FROM node_tags nt JOIN tags t ON t.id = nt.tag_id
			 WHERE nt.node_id = ANY($1)`,
			allIDs,
		)
		if err == nil {
			defer tagRows.Close()
			for tagRows.Next() {
				var nodeID int64
				var tag TagSummary
				if err := tagRows.Scan(&nodeID, &tag.ID, &tag.Name, &tag.Color); err != nil {
					log.Printf("[ARCHE-NODES] WARN: scan tag: %v", err)
					continue
				}
				if node, ok := nodeMap[nodeID]; ok {
					node.Tags = append(node.Tags, tag)
				}
			}
		}
	}

	// Phase 2: build the tree (recursion)
	var roots []*NodeResponse
	for _, n := range nodeMap {
		if n.ParentID == nil {
			roots = append(roots, n)
		} else {
			if parent, ok := nodeMap[*n.ParentID]; ok {
				parent.Children = append(parent.Children, n)
			}
		}
	}

	return c.JSON(fiber.Map{"nodes": roots})
}

// ─── GET /factory/nodes/:id ───────────────────────────────────────────────────

func (h *NodesHandler) GetOne(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	n := &NodeResponse{Children: []*NodeResponse{}, Tags: []TagSummary{}}
	err = h.db.QueryRow(c.UserContext(),
		`SELECT
			fn.id, fn.parent_id, fn.client_id, fn.name, fn.code,
			fn.node_type, fn.status, fn.criticality, fn.description,
			fn.manufacturer, fn.model, fn.serial_number, fn.year_installed,
			fn.rated_power_kw, fn.path::text, fn.version,
			fn.created_by, fn.updated_by,
			uc.full_name, uu.full_name,
			fn.created_at::text, fn.updated_at::text
		FROM factory_nodes fn
		LEFT JOIN users uc ON uc.id = fn.created_by
		LEFT JOIN users uu ON uu.id = fn.updated_by
		WHERE fn.id = $1 AND fn.tenant_id = $2`,
		id, claims.TenantID,
	).Scan(
		&n.ID, &n.ParentID, &n.ClientID, &n.Name, &n.Code,
		&n.NodeType, &n.Status, &n.Criticality, &n.Description,
		&n.Manufacturer, &n.Model, &n.SerialNumber, &n.YearInstalled,
		&n.RatedPowerKW, &n.Path, &n.Version,
		&n.CreatedBy, &n.UpdatedBy,
		&n.CreatedByName, &n.UpdatedByName,
		&n.CreatedAt, &n.UpdatedAt,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Nodo no encontrado")
	}

	// Tags
	tagRows, _ := h.db.Query(c.UserContext(),
		`SELECT t.id, t.name, t.color FROM node_tags nt
		 JOIN tags t ON t.id = nt.tag_id
		 WHERE nt.node_id = $1 AND t.tenant_id = $2`, id, claims.TenantID,
	)
	if tagRows != nil {
		defer tagRows.Close()
		for tagRows.Next() {
			var tag TagSummary
			if err := tagRows.Scan(&tag.ID, &tag.Name, &tag.Color); err != nil {
				log.Printf("[ARCHE-NODES] WARN: scan tag: %v", err)
				continue
			}
			n.Tags = append(n.Tags, tag)
		}
	}

	return c.JSON(n)
}

// ─── GET /factory/nodes/:id/children ─────────────────────────────────────────

func (h *NodesHandler) GetChildren(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	childQuery := `SELECT fn.id, fn.parent_id, fn.client_id, fn.name, fn.code,
		        fn.node_type, fn.status, fn.criticality, fn.description,
		        fn.manufacturer, fn.model, fn.serial_number, fn.year_installed,
		        fn.rated_power_kw, fn.path::text, fn.version,
		        fn.created_by, fn.updated_by,
		        uc.full_name, uu.full_name,
		        fn.created_at::text, fn.updated_at::text
		 FROM factory_nodes fn
		 LEFT JOIN users uc ON uc.id = fn.created_by
		 LEFT JOIN users uu ON uu.id = fn.updated_by
		 WHERE fn.parent_id = $1 AND fn.tenant_id = $2 AND fn.status != 'decommissioned'`
	childArgs := []interface{}{id, claims.TenantID}

	// Every role except admin and auditor only sees children within their scope
	if claims.Role != "admin" && claims.Role != "auditor" {
		childQuery += ` AND EXISTS (
			SELECT 1 FROM node_assignments na
			JOIN factory_nodes assigned ON assigned.id = na.node_id AND assigned.tenant_id = $2
			WHERE na.user_id = $3 AND na.tenant_id = $2
			  AND (fn.path <@ assigned.path OR assigned.path <@ fn.path)
		)`
		childArgs = append(childArgs, claims.UserID)
	}

	childQuery += ` ORDER BY fn.name`

	rows, err := h.db.Query(c.UserContext(), childQuery, childArgs...)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando hijos")
	}
	defer rows.Close()

	var children []*NodeResponse
	for rows.Next() {
		n := &NodeResponse{Children: []*NodeResponse{}, Tags: []TagSummary{}}
		if err := rows.Scan(
			&n.ID, &n.ParentID, &n.ClientID, &n.Name, &n.Code,
			&n.NodeType, &n.Status, &n.Criticality, &n.Description,
			&n.Manufacturer, &n.Model, &n.SerialNumber, &n.YearInstalled,
			&n.RatedPowerKW, &n.Path, &n.Version,
			&n.CreatedBy, &n.UpdatedBy,
			&n.CreatedByName, &n.UpdatedByName,
			&n.CreatedAt, &n.UpdatedAt,
		); err == nil {
			children = append(children, n)
		}
	}

	return c.JSON(fiber.Map{"children": children, "total": len(children)})
}

// validNodeTypes is the single source of truth for the allowed types.
// It must match the factory_nodes_node_type_check CHECK constraint (036).
var validNodeTypes = map[string]bool{
	"organization":      true,
	"plant":             true,
	"area":              true,
	"line":              true,
	"equipment":         true,
	"subassembly":       true,
	"component":         true,
	"sensor":            true,
	"instrument":        true,
	"measurement_point": true,
	"composition":       true,
}

func isValidNodeType(t string) bool {
	return validNodeTypes[t]
}

// ─── POST /factory/nodes ──────────────────────────────────────────────────────

type createNodeRequest struct {
	ParentID      *int64   `json:"parent_id"`
	ClientID      *int64   `json:"client_id"`
	Name          string   `json:"name"`
	Code          *string  `json:"code"`
	NodeType      string   `json:"node_type"`
	Status        string   `json:"status"`
	Criticality   string   `json:"criticality"`
	Description   *string  `json:"description"`
	Manufacturer  *string  `json:"manufacturer"`
	Model         *string  `json:"model"`
	SerialNumber  *string  `json:"serial_number"`
	YearInstalled *int     `json:"year_installed"`
	RatedPowerKW  *float64 `json:"rated_power_kw"`
}

func (h *NodesHandler) Create(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req createNodeRequest
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}
	if req.Name == "" {
		return fiber.NewError(fiber.StatusBadRequest, "El nombre es requerido")
	}
	if req.NodeType == "" {
		req.NodeType = "equipment"
	}
	if !isValidNodeType(req.NodeType) {
		return fiber.NewError(fiber.StatusBadRequest, "Tipo de nodo inválido")
	}
	if req.Status == "" {
		req.Status = "active"
	}
	if req.Criticality == "" {
		req.Criticality = "medium"
	}

	// Check the equipment limit: only nodes of type 'equipment' count
	maxNodes := license.GetMaxNodes()
	var tenantMaxNodes *int
	h.db.QueryRow(c.UserContext(),
		`SELECT max_nodes FROM tenants WHERE id=$1`, claims.TenantID,
	).Scan(&tenantMaxNodes)
	effectiveMax := maxNodes
	if tenantMaxNodes != nil && *tenantMaxNodes > 0 {
		if effectiveMax == 0 || *tenantMaxNodes < effectiveMax {
			effectiveMax = *tenantMaxNodes
		}
	}
	if effectiveMax > 0 && req.NodeType == "equipment" {
		var equipmentCount int
		h.db.QueryRow(c.UserContext(),
			`SELECT COUNT(*) FROM factory_nodes WHERE tenant_id=$1 AND node_type='equipment'`, claims.TenantID,
		).Scan(&equipmentCount)
		if equipmentCount >= effectiveMax {
			return fiber.NewError(fiber.StatusConflict,
				fmt.Sprintf("Límite de equipos alcanzado: %d de %d permitidos. Contacte con Arche GMAO para ampliar.", equipmentCount, effectiveMax))
		}
	}

	// Equipment, components and measurement points require a parent node
	needsParent := req.NodeType == "equipment" || req.NodeType == "component" || req.NodeType == "measurement_point"
	if needsParent && req.ParentID == nil {
		return fiber.NewError(fiber.StatusBadRequest,
			"Un nodo de tipo "+req.NodeType+" debe tener un nodo padre")
	}

	// Validate the type hierarchy: the child must sit one level below the parent
	hierarchy := map[string]int{
		"organization": 0, "plant": 1, "area": 2, "line": 3,
		"equipment": 4, "component": 5, "measurement_point": 6,
	}
	if req.ParentID != nil {
		var parentType string
		err := h.db.QueryRow(c.UserContext(),
			`SELECT node_type FROM factory_nodes WHERE id=$1 AND tenant_id=$2`,
			req.ParentID, claims.TenantID,
		).Scan(&parentType)
		if err != nil {
			return fiber.NewError(fiber.StatusNotFound, "Nodo padre no encontrado")
		}
		nodeLevel := hierarchy[req.NodeType]
		parentLevel := hierarchy[parentType]
		if nodeLevel <= parentLevel {
			return fiber.NewError(fiber.StatusBadRequest,
				"Un "+req.NodeType+" no puede estar dentro de un "+parentType)
		}
	}

	var newID int64
	err := h.db.QueryRow(c.UserContext(),
		`INSERT INTO factory_nodes
		 (tenant_id, client_id, parent_id, name, code, node_type, status, criticality,
		  description, manufacturer, model, serial_number, year_installed, rated_power_kw,
		  created_by, updated_by)
		 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$15)
		 RETURNING id`,
		claims.TenantID, req.ClientID, req.ParentID, req.Name, req.Code,
		req.NodeType, req.Status, req.Criticality, req.Description,
		req.Manufacturer, req.Model, req.SerialNumber, req.YearInstalled, req.RatedPowerKW,
		claims.UserID,
	).Scan(&newID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error creando nodo")
	}

	// Index the node in RAG so the AI knows about it
	ai.EnqueueNow(context.Background(), h.db, claims.TenantID, "index", "node_info", newID)

	// Return the freshly created node
	return h.GetOneByID(c, claims.TenantID, newID)
}

// ─── PUT /factory/nodes/:id ───────────────────────────────────────────────────

type updateNodeRequest struct {
	Name          string   `json:"name"`
	Code          *string  `json:"code"`
	NodeType      string   `json:"node_type"`
	Status        string   `json:"status"`
	Criticality   string   `json:"criticality"`
	Description   *string  `json:"description"`
	Manufacturer  *string  `json:"manufacturer"`
	Model         *string  `json:"model"`
	SerialNumber  *string  `json:"serial_number"`
	YearInstalled *int     `json:"year_installed"`
	RatedPowerKW  *float64 `json:"rated_power_kw"`
	Version       int      `json:"version"` // for optimistic locking
}

func (h *NodesHandler) Update(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req updateNodeRequest
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}
	if req.Name == "" {
		return fiber.NewError(fiber.StatusBadRequest, "El nombre es requerido")
	}
	if req.NodeType != "" && !isValidNodeType(req.NodeType) {
		return fiber.NewError(fiber.StatusBadRequest, "Tipo de nodo inválido")
	}

	result, err := h.db.Exec(c.UserContext(),
		`UPDATE factory_nodes SET
			name=$1, code=$2, node_type=$3, status=$4, criticality=$5,
			description=$6, manufacturer=$7, model=$8, serial_number=$9,
			year_installed=$10, rated_power_kw=$11, updated_by=$12,
			version = version + 1
		 WHERE id=$13 AND tenant_id=$14 AND version=$15`,
		req.Name, req.Code, req.NodeType, req.Status, req.Criticality,
		req.Description, req.Manufacturer, req.Model, req.SerialNumber,
		req.YearInstalled, req.RatedPowerKW, claims.UserID,
		id, claims.TenantID, req.Version,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error actualizando nodo")
	}
	if result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusConflict, "Conflicto de versión o nodo no encontrado. Recarga e intenta de nuevo.")
	}

	// Re-index the node in RAG
	ai.EnqueueNow(context.Background(), h.db, claims.TenantID, "reindex", "node_info", id)

	return h.GetOneByID(c, claims.TenantID, id)
}

// ─── PATCH /factory/nodes/:id/move — move a node to another parent ─────────────────

func (h *NodesHandler) Move(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req struct {
		ParentID *int64 `json:"parent_id"`
		Version  int    `json:"version"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	// Get the type of the node being moved
	var nodeType string
	err = h.db.QueryRow(c.UserContext(),
		`SELECT node_type FROM factory_nodes WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	).Scan(&nodeType)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Nodo no encontrado")
	}

	// Types that require a parent
	needsParent := nodeType == "equipment" || nodeType == "component" || nodeType == "measurement_point"
	if needsParent && req.ParentID == nil {
		return fiber.NewError(fiber.StatusBadRequest,
			"Un nodo de tipo "+nodeType+" no puede ser raíz")
	}

	// Validate the hierarchy: the parent must sit at a higher level
	hierarchy := map[string]int{
		"organization": 0, "plant": 1, "area": 2, "line": 3,
		"equipment": 4, "component": 5, "measurement_point": 6,
	}

	if req.ParentID != nil {
		// It cannot be moved inside itself or inside a descendant
		var parentPath, nodePath string
		err = h.db.QueryRow(c.UserContext(),
			`SELECT path::text FROM factory_nodes WHERE id=$1 AND tenant_id=$2`,
			id, claims.TenantID,
		).Scan(&nodePath)
		if err != nil {
			return fiber.NewError(fiber.StatusNotFound, "Nodo no encontrado")
		}

		var parentType string
		err = h.db.QueryRow(c.UserContext(),
			`SELECT node_type, path::text FROM factory_nodes WHERE id=$1 AND tenant_id=$2`,
			req.ParentID, claims.TenantID,
		).Scan(&parentType, &parentPath)
		if err != nil {
			return fiber.NewError(fiber.StatusNotFound, "Nodo padre no encontrado")
		}

		// It cannot be a child of itself or of a descendant
		if *req.ParentID == id {
			return fiber.NewError(fiber.StatusBadRequest, "Un nodo no puede ser hijo de sí mismo")
		}
		// Check that the parent is not a descendant of the node
		// parentPath cannot start with nodePath
		if len(parentPath) >= len(nodePath) && parentPath[:len(nodePath)] == nodePath {
			if len(parentPath) == len(nodePath) || parentPath[len(nodePath)] == '.' {
				return fiber.NewError(fiber.StatusBadRequest,
					"No se puede mover un nodo dentro de su propio subárbol")
			}
		}

		// Validate the type hierarchy
		nodeLevel := hierarchy[nodeType]
		parentLevel := hierarchy[parentType]
		if nodeLevel <= parentLevel {
			return fiber.NewError(fiber.StatusBadRequest,
				"Un "+nodeType+" no puede estar dentro de un "+parentType)
		}
	}

	// Move: update parent_id with optimistic locking
	moveResult, err := h.db.Exec(c.UserContext(),
		`UPDATE factory_nodes SET parent_id=$1, updated_by=$2, version = version + 1
		 WHERE id=$3 AND tenant_id=$4 AND version=$5`,
		req.ParentID, claims.UserID, id, claims.TenantID, req.Version,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error moviendo nodo")
	}
	if moveResult.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusConflict, "Conflicto de versión al mover. Recarga e intenta de nuevo.")
	}

	// Recompute the path of the node and all its descendants
	_, err = h.db.Exec(c.UserContext(),
		`WITH RECURSIVE tree AS (
			SELECT id, parent_id FROM factory_nodes WHERE id=$1
			UNION ALL
			SELECT fn.id, fn.parent_id FROM factory_nodes fn JOIN tree t ON fn.parent_id=t.id
		)
		UPDATE factory_nodes fn SET path = (
			WITH RECURSIVE ancestors AS (
				SELECT id, parent_id, id::text::ltree AS p FROM factory_nodes WHERE parent_id IS NULL AND tenant_id=$2
				UNION ALL
				SELECT c.id, c.parent_id, a.p || c.id::text::ltree
				FROM factory_nodes c JOIN ancestors a ON c.parent_id=a.id
			)
			SELECT p FROM ancestors WHERE ancestors.id=fn.id
		)
		WHERE fn.id IN (SELECT id FROM tree)`,
		id, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error recalculando rutas")
	}

	return h.GetOneByID(c, claims.TenantID, id)
}

// ─── DELETE /factory/nodes/:id ────────────────────────────────────────────────

func (h *NodesHandler) Delete(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	// Check that it has no active children
	var childCount int
	err = h.db.QueryRow(c.UserContext(),
		`SELECT COUNT(*) FROM factory_nodes
		 WHERE parent_id=$1 AND tenant_id=$2 AND status != 'decommissioned'`,
		id, claims.TenantID,
	).Scan(&childCount)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error verificando hijos")
	}

	if childCount > 0 {
		return fiber.NewError(fiber.StatusBadRequest,
			"No se puede eliminar un nodo con hijos activos. Elimina o desactiva los hijos primero.")
	}

	// Soft delete: mark it as decommissioned
	result, err := h.db.Exec(c.UserContext(),
		`UPDATE factory_nodes SET status='decommissioned', updated_by=$3
		 WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID, claims.UserID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Nodo no encontrado")
	}

	// Clear the AI data so RAG does not return data from decommissioned equipment
	go func() {
		bgCtx := context.Background()
		// Delete the node's embeddings
		h.db.Exec(bgCtx,
			`DELETE FROM ai_embeddings WHERE node_id = $1 AND tenant_id = $2`,
			id, claims.TenantID)
		// Delete the embeddings by source_id (node_info)
		h.db.Exec(bgCtx,
			`DELETE FROM ai_embeddings WHERE source_type = 'node_info' AND source_id = $1 AND tenant_id = $2`,
			id, claims.TenantID)
		// Invalidate the node's patterns
		h.db.Exec(bgCtx,
			`UPDATE ai_patterns SET status = 'dismissed' WHERE node_id = $1 AND tenant_id = $2 AND status = 'active'`,
			id, claims.TenantID)
		// Clear the pending indexing queue
		h.db.Exec(bgCtx,
			`DELETE FROM ai_index_queue WHERE source_type = 'node_info' AND source_id = $1 AND tenant_id = $2 AND status = 'pending'`,
			id, claims.TenantID)
		// Delete node assignments (it is no longer operational)
		h.db.Exec(bgCtx,
			`DELETE FROM node_assignments WHERE node_id = $1 AND tenant_id = $2`,
			id, claims.TenantID)
	}()

	return c.JSON(fiber.Map{"message": "Nodo dado de baja correctamente", "id": id})
}

// ─── GET /factory/search ─────────────────────────────────────────────────────

func (h *NodesHandler) Search(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	q := c.Query("q")
	if len(q) < 2 {
		return c.JSON(fiber.Map{"results": []interface{}{}})
	}

	searchQuery := `SELECT id, parent_id, name, code, node_type, status, criticality, path::text
		 FROM factory_nodes
		 WHERE tenant_id=$1
		   AND status != 'decommissioned'
		   AND (
		       search_vector @@ plainto_tsquery('spanish', $2)
		       OR name ILIKE '%' || $2 || '%'
		       OR code ILIKE '%' || $2 || '%'
		   )`
	searchArgs := []interface{}{claims.TenantID, q}

	// Every role except admin and auditor only searches within their assigned nodes
	if claims.Role != "admin" && claims.Role != "auditor" {
		searchQuery += ` AND EXISTS (
			SELECT 1 FROM node_assignments na
			JOIN factory_nodes assigned ON assigned.id = na.node_id AND assigned.tenant_id = $1
			WHERE na.user_id = $3 AND na.tenant_id = $1
			  AND (factory_nodes.path <@ assigned.path OR assigned.path <@ factory_nodes.path)
		)`
		searchArgs = append(searchArgs, claims.UserID)
	}

	searchQuery += ` ORDER BY ts_rank(search_vector, plainto_tsquery('spanish', $2)) DESC
		 LIMIT 20`

	rows, err := h.db.Query(c.UserContext(), searchQuery, searchArgs...)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error en búsqueda")
	}
	defer rows.Close()

	type SearchResult struct {
		ID          int64   `json:"id"`
		ParentID    *int64  `json:"parent_id"`
		Name        string  `json:"name"`
		Code        *string `json:"code"`
		NodeType    string  `json:"node_type"`
		Status      string  `json:"status"`
		Criticality string  `json:"criticality"`
		Path        string  `json:"path"`
	}

	var results []SearchResult
	for rows.Next() {
		var r SearchResult
		if err := rows.Scan(&r.ID, &r.ParentID, &r.Name, &r.Code,
			&r.NodeType, &r.Status, &r.Criticality, &r.Path); err == nil {
			results = append(results, r)
		}
	}

	return c.JSON(fiber.Map{"results": results, "total": len(results)})
}

// ─── Internal helper ───────────────────────────────────────────────────────────

func (h *NodesHandler) GetOneByID(c *fiber.Ctx, tenantID, nodeID int64) error {
	n := &NodeResponse{Children: []*NodeResponse{}, Tags: []TagSummary{}}
	err := h.db.QueryRow(c.UserContext(),
		`SELECT fn.id, fn.parent_id, fn.client_id, fn.name, fn.code,
		        fn.node_type, fn.status, fn.criticality, fn.description,
		        fn.manufacturer, fn.model, fn.serial_number, fn.year_installed,
		        fn.rated_power_kw, fn.path::text, fn.version,
		        fn.created_by, fn.updated_by,
		        uc.full_name, uu.full_name,
		        fn.created_at::text, fn.updated_at::text
		 FROM factory_nodes fn
		 LEFT JOIN users uc ON uc.id = fn.created_by
		 LEFT JOIN users uu ON uu.id = fn.updated_by
		 WHERE fn.id=$1 AND fn.tenant_id=$2`,
		nodeID, tenantID,
	).Scan(
		&n.ID, &n.ParentID, &n.ClientID, &n.Name, &n.Code,
		&n.NodeType, &n.Status, &n.Criticality, &n.Description,
		&n.Manufacturer, &n.Model, &n.SerialNumber, &n.YearInstalled,
		&n.RatedPowerKW, &n.Path, &n.Version,
		&n.CreatedBy, &n.UpdatedBy,
		&n.CreatedByName, &n.UpdatedByName,
		&n.CreatedAt, &n.UpdatedAt,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Nodo no encontrado")
	}
	return c.Status(fiber.StatusOK).JSON(n)
}
