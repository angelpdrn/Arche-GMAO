package handlers

import (
	"testing"
)

func TestAllowedTransitions(t *testing.T) {
	tests := []struct {
		from string
		to   string
		ok   bool
	}{
		// Full happy path
		{"draft", "pending", true},
		{"pending", "approved", true},
		{"approved", "assigned", true},
		{"assigned", "in_progress", true},
		{"in_progress", "completed", true},
		{"completed", "verified", true},
		{"verified", "closed", true},

		// Pause and resume
		{"assigned", "paused", true},
		{"paused", "in_progress", true},
		{"in_progress", "paused", true},

		// Rejection and resubmission
		{"pending", "rejected", true},
		{"rejected", "pending", true},

		// Cancellation from several states
		{"draft", "cancelled", true},
		{"pending", "cancelled", true},
		{"approved", "cancelled", true},
		{"assigned", "cancelled", true},
		{"in_progress", "cancelled", true},
		{"paused", "cancelled", true},

		// Direct close from completed
		{"completed", "closed", true},

		// Transitions that are NOT allowed
		{"draft", "approved", false},
		{"draft", "assigned", false},
		{"pending", "in_progress", false},
		{"approved", "completed", false},
		{"assigned", "completed", false},
		{"completed", "in_progress", false},
		{"closed", "pending", false},
		{"cancelled", "pending", false},
		{"verified", "in_progress", false},
		{"rejected", "approved", false},
		{"in_progress", "assigned", false},
		{"paused", "completed", false},
	}

	for _, tt := range tests {
		name := tt.from + " → " + tt.to
		t.Run(name, func(t *testing.T) {
			targets, exists := allowedTransitions[tt.from]
			if !exists {
				t.Fatalf("estado %q no existe en allowedTransitions", tt.from)
			}
			found := false
			for _, s := range targets {
				if s == tt.to {
					found = true
					break
				}
			}
			if found != tt.ok {
				t.Errorf("allowedTransitions[%q] contiene %q = %v, want %v", tt.from, tt.to, found, tt.ok)
			}
		})
	}
}

func TestTransitionRoles(t *testing.T) {
	tests := []struct {
		target string
		role   string
		ok     bool
	}{
		// A supervisor can approve/reject/close
		{"approved", "supervisor", true},
		{"rejected", "supervisor", true},
		{"closed", "supervisor", true},
		{"verified", "supervisor", true},

		// A technician can start/complete/pause
		{"in_progress", "technician", true},
		{"completed", "technician", true},
		{"paused", "technician", true},

		// A technician can NOT approve/reject/close
		{"approved", "technician", false},
		{"rejected", "technician", false},
		{"closed", "technician", false},
		{"verified", "technician", false},
		{"cancelled", "technician", false},

		// An operator can start/complete
		{"in_progress", "operator", true},
		{"completed", "operator", true},

		// An operator can NOT approve/close
		{"approved", "operator", false},
		{"closed", "operator", false},

		// Warehouse has no transitions
		{"approved", "warehouse", false},
		{"in_progress", "warehouse", false},
		{"completed", "warehouse", false},

		// An auditor has no transitions
		{"approved", "auditor", false},
		{"in_progress", "auditor", false},

		// An admin can do everything
		{"approved", "admin", true},
		{"rejected", "admin", true},
		{"assigned", "admin", true},
		{"in_progress", "admin", true},
		{"completed", "admin", true},
		{"verified", "admin", true},
		{"closed", "admin", true},
		{"cancelled", "admin", true},
	}

	for _, tt := range tests {
		name := tt.role + " → " + tt.target
		t.Run(name, func(t *testing.T) {
			roles, exists := transitionRoles[tt.target]
			if !exists {
				t.Fatalf("target %q no existe en transitionRoles", tt.target)
			}
			found := false
			for _, r := range roles {
				if r == tt.role {
					found = true
					break
				}
			}
			if found != tt.ok {
				t.Errorf("transitionRoles[%q] contiene %q = %v, want %v", tt.target, tt.role, found, tt.ok)
			}
		})
	}
}

func TestAllStatesHaveTransitionEntry(t *testing.T) {
	states := []string{
		"draft", "pending", "approved", "assigned",
		"in_progress", "paused", "completed", "verified",
		"rejected", "cancelled", "closed",
	}
	for _, s := range states {
		if _, ok := allowedTransitions[s]; !ok {
			t.Errorf("estado %q no tiene entrada en allowedTransitions", s)
		}
	}
}

func TestTerminalStatesHaveNoTransitions(t *testing.T) {
	terminals := []string{"cancelled", "closed"}
	for _, s := range terminals {
		targets := allowedTransitions[s]
		if len(targets) != 0 {
			t.Errorf("estado terminal %q tiene transiciones: %v", s, targets)
		}
	}
}
