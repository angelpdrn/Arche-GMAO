package handlers

import (
	"fmt"
	"io"
	"strconv"
	"strings"
	"time"

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/xuri/excelize/v2"
)

type ImportHandler struct {
	db *pgxpool.Pool
}

func NewImportHandler(db *pgxpool.Pool) *ImportHandler {
	return &ImportHandler{db: db}
}

// ─── GET /import/template — download the Excel template ────────────────────────

func (h *ImportHandler) DownloadTemplate(c *fiber.Ctx) error {
	f := excelize.NewFile()
	defer f.Close()
	sheet := "Equipos"
	f.SetSheetName("Sheet1", sheet)

	// Styles
	headerStyle, _ := f.NewStyle(&excelize.Style{
		Fill: excelize.Fill{Type: "pattern", Color: []string{"0F3460"}, Pattern: 1},
		Font: &excelize.Font{Color: "FFFFFF", Bold: true, Size: 11},
		Alignment: &excelize.Alignment{Horizontal: "center"},
		Border: []excelize.Border{{Type: "bottom", Color: "FFFFFF", Style: 2}},
	})
	requiredStyle, _ := f.NewStyle(&excelize.Style{
		Fill: excelize.Fill{Type: "pattern", Color: []string{"FEF3F2"}, Pattern: 1},
		Font: &excelize.Font{Color: "E94560", Bold: true},
		Alignment: &excelize.Alignment{Horizontal: "center"},
	})
	optionalStyle, _ := f.NewStyle(&excelize.Style{
		Fill: excelize.Fill{Type: "pattern", Color: []string{"F8F9FA"}, Pattern: 1},
		Font: &excelize.Font{Color: "888888"},
		Alignment: &excelize.Alignment{Horizontal: "center"},
	})
	exampleStyle, _ := f.NewStyle(&excelize.Style{
		Font: &excelize.Font{Color: "27AE60", Italic: true},
	})

	// Headers
	headers := []struct {
		col, name, note string
		required        bool
	}{
		{"A", "nombre", "Nombre del equipo o componente", true},
		{"B", "codigo", "Código único (ej: EQ-001)", false},
		{"C", "tipo_nodo", "plant / area / line / equipment / component", true},
		{"D", "criticidad", "low / medium / high / critical", true},
		{"E", "estado", "active / inactive / maintenance (default: active)", false},
		{"F", "padre_codigo", "Código del nodo padre (vacío = raíz)", false},
		{"G", "ubicacion", "Ubicación física", false},
		{"H", "fabricante", "Fabricante", false},
		{"I", "modelo", "Modelo del equipo", false},
		{"J", "numero_serie", "Número de serie", false},
		{"K", "año_instalacion", "Año de instalación (ej: 2020)", false},
		{"L", "descripcion", "Descripción adicional", false},
	}

	for _, h2 := range headers {
		cell := h2.col + "1"
		f.SetCellValue(sheet, cell, h2.name)
		f.SetCellStyle(sheet, cell, cell, headerStyle)

		note := h2.col + "2"
		f.SetCellValue(sheet, note, h2.note)
		if h2.required {
			f.SetCellStyle(sheet, note, note, requiredStyle)
		} else {
			f.SetCellStyle(sheet, note, note, optionalStyle)
		}
	}

	// Example row 3
	examples := []string{
		"Llenadora KHS-200", "EQ-LLE-001", "equipment", "critical",
		"active", "LIN-001", "Línea 1 - Zona A", "KHS", "Innofill DMG", "KHS2019-001", "2019",
		"Llenadora de botellas de vidrio",
	}
	cols := []string{"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L"}
	for i, val := range examples {
		cell := cols[i] + "3"
		f.SetCellValue(sheet, cell, val)
		f.SetCellStyle(sheet, cell, cell, exampleStyle)
	}

	// Reference sheet
	refSheet := "Referencia"
	f.NewSheet(refSheet)

	refData := [][]string{
		{"TIPOS DE NODO", ""},
		{"plant", "Planta / Fábrica (nivel raíz)"},
		{"area", "Área de producción"},
		{"line", "Línea de producción"},
		{"equipment", "Equipo / Máquina"},
		{"component", "Componente de un equipo"},
		{"", ""},
		{"CRITICIDAD", ""},
		{"low", "Baja — fallo no afecta producción"},
		{"medium", "Media — fallo causa reducción menor"},
		{"high", "Alta — fallo causa parada significativa"},
		{"critical", "Crítica — fallo causa parada total"},
		{"", ""},
		{"ESTADOS", ""},
		{"active", "Operativo (por defecto)"},
		{"inactive", "Inactivo / fuera de servicio"},
		{"maintenance", "En mantenimiento"},
		{"decommissioned", "Desmantelado"},
		{"", ""},
		{"NOTAS IMPORTANTES", ""},
		{"padre_codigo", "Debe coincidir con el código de otra fila. Se procesan en orden, poner padres antes que hijos."},
		{"codigo", "Si se deja vacío se genera automáticamente. Debe ser único en toda la instalación."},
	}

	titleStyle, _ := f.NewStyle(&excelize.Style{
		Font: &excelize.Font{Bold: true, Color: "0F3460", Size: 12},
	})
	for i, row := range refData {
		rowNum := i + 1
		f.SetCellValue(refSheet, fmt.Sprintf("A%d", rowNum), row[0])
		f.SetCellValue(refSheet, fmt.Sprintf("B%d", rowNum), row[1])
		if row[1] == "" && row[0] != "" {
			f.SetCellStyle(refSheet, fmt.Sprintf("A%d", rowNum), fmt.Sprintf("A%d", rowNum), titleStyle)
		}
	}

	f.SetColWidth(sheet, "A", "A", 30)
	f.SetColWidth(sheet, "B", "B", 15)
	f.SetColWidth(sheet, "C", "L", 20)
	f.SetColWidth(refSheet, "A", "A", 20)
	f.SetColWidth(refSheet, "B", "B", 60)

	// Freeze the first row
	f.SetPanes(sheet, &excelize.Panes{
		Freeze: true, YSplit: 2, TopLeftCell: "A3", ActivePane: "bottomLeft",
	})

	c.Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	c.Set("Content-Disposition", `attachment; filename="plantilla_importacion_equipos.xlsx"`)

	return f.Write(c.Response().BodyWriter())
}

// ─── POST /import/nodes — import nodes from Excel ─────────────────────────

func (h *ImportHandler) ImportNodes(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	file, err := c.FormFile("file")
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Archivo Excel requerido")
	}

	f2, err := file.Open()
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error abriendo archivo")
	}
	defer f2.Close()

	raw, err := io.ReadAll(io.LimitReader(f2, 10*1024*1024))
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error leyendo archivo")
	}

	xlsx, err := excelize.OpenReader(strings.NewReader(string(raw)))
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Archivo Excel inválido")
	}

	// Get the sheet
	sheetName := xlsx.GetSheetName(0)
	rows, err := xlsx.GetRows(sheetName)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Error leyendo hoja Excel")
	}

	type ImportRow struct {
		Line        int
		Name        string
		Code        string
		NodeType    string
		Criticality string
		Status      string
		ParentCode  string
		Location    string
		Manufacturer string
		Model       string
		SerialNo    string
		Year        string
		Description string
	}

	type ImportResult struct {
		Line    int     `json:"line"`
		Name    string  `json:"name"`
		Code    string  `json:"code"`
		Status  string  `json:"status"`
		Error   *string `json:"error,omitempty"`
		NodeID  *int64  `json:"node_id,omitempty"`
	}

	validTypes := map[string]bool{
		"plant": true, "area": true, "line": true,
		"equipment": true, "component": true,
	}
	validCriticality := map[string]bool{
		"low": true, "medium": true, "high": true, "critical": true,
	}
	validStatus := map[string]bool{
		"active": true, "inactive": true, "maintenance": true, "decommissioned": true,
	}

	var importRows []ImportRow
	// Skip the headers (rows 1 and 2 are header + notes)
	startRow := 1
	if len(rows) > 0 && (rows[0][0] == "nombre" || rows[0][0] == "name") {
		startRow = 2 // skip the notes row too when present
	}

	for i := startRow; i < len(rows); i++ {
		row := rows[i]
		if len(row) == 0 || strings.TrimSpace(getCol(row, 0)) == "" {
			continue
		}
		importRows = append(importRows, ImportRow{
			Line:        i + 1,
			Name:        strings.TrimSpace(getCol(row, 0)),
			Code:        strings.TrimSpace(getCol(row, 1)),
			NodeType:    strings.ToLower(strings.TrimSpace(getCol(row, 2))),
			Criticality: strings.ToLower(strings.TrimSpace(getCol(row, 3))),
			Status:      strings.ToLower(strings.TrimSpace(getCol(row, 4))),
			ParentCode:  strings.TrimSpace(getCol(row, 5)),
			Location:    strings.TrimSpace(getCol(row, 6)),
			Manufacturer: strings.TrimSpace(getCol(row, 7)),
			Model:       strings.TrimSpace(getCol(row, 8)),
			SerialNo:    strings.TrimSpace(getCol(row, 9)),
			Year:        strings.TrimSpace(getCol(row, 10)),
			Description: strings.TrimSpace(getCol(row, 11)),
		})
	}

	if len(importRows) == 0 {
		return fiber.NewError(fiber.StatusBadRequest, "No se encontraron filas de datos en el archivo")
	}

	// code → ID map for resolving parents
	codeToID := make(map[string]int64)

	// Load existing nodes to spot duplicates and resolve parents
	existingRows, err := h.db.Query(c.UserContext(),
		`SELECT id, COALESCE(code,'') FROM factory_nodes WHERE tenant_id=$1`,
		claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando nodos existentes")
	}
	if existingRows != nil {
		defer existingRows.Close()
		for existingRows.Next() {
			var id int64
			var code string
			if existingRows.Scan(&id, &code) == nil && code != "" {
				codeToID[code] = id
			}
		}
	}

	var results []ImportResult
	created, failed := 0, 0

	for _, row := range importRows {
		result := ImportResult{Line: row.Line, Name: row.Name, Code: row.Code}

		// Validations
		if row.Name == "" {
			errMsg := "Nombre vacío"
			result.Status = "error"; result.Error = &errMsg; failed++
			results = append(results, result); continue
		}
		if !validTypes[row.NodeType] {
			errMsg := fmt.Sprintf("Tipo '%s' inválido. Usa: plant, area, line, equipment, component", row.NodeType)
			result.Status = "error"; result.Error = &errMsg; failed++
			results = append(results, result); continue
		}
		if !validCriticality[row.Criticality] {
			row.Criticality = "medium"
		}
		if !validStatus[row.Status] {
			row.Status = "active"
		}

		// Detect a duplicate by code
		if row.Code != "" {
			if existingID, exists := codeToID[row.Code]; exists {
				errMsg := fmt.Sprintf("Código '%s' ya existe (ID: %d)", row.Code, existingID)
				result.Status = "duplicado"; result.Error = &errMsg; failed++
				results = append(results, result); continue
			}
		}

		// Resolve the parent
		var parentID *int64
		if row.ParentCode != "" {
			if pid, ok := codeToID[row.ParentCode]; ok {
				parentID = &pid
			} else {
				errMsg := fmt.Sprintf("Padre '%s' no encontrado", row.ParentCode)
				result.Status = "error"; result.Error = &errMsg; failed++
				results = append(results, result); continue
			}
		}

		// Generate a code when there is none
		code := row.Code
		if code == "" {
			code = fmt.Sprintf("%s-%d", strings.ToUpper(row.NodeType[:3]), time.Now().UnixNano()%100000)
		}

		// Prepare the optional fields
		var location, manufacturer, model, serialNo, description *string
		var yearInstalled *int
		if row.Location != "" { location = &row.Location }
		if row.Manufacturer != "" { manufacturer = &row.Manufacturer }
		if row.Model != "" { model = &row.Model }
		if row.SerialNo != "" { serialNo = &row.SerialNo }
		if row.Description != "" { description = &row.Description }
		if row.Year != "" {
			if y, err := strconv.Atoi(row.Year); err == nil {
				yearInstalled = &y
			}
		}

		var newID int64
		err := h.db.QueryRow(c.UserContext(),
			`INSERT INTO factory_nodes
			 (tenant_id, name, code, node_type, criticality, status, parent_id,
			  location, manufacturer, model, serial_number, year_installed, description)
			 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING id`,
			claims.TenantID, row.Name, code, row.NodeType, row.Criticality, row.Status,
			parentID, location, manufacturer, model, serialNo, yearInstalled, description,
		).Scan(&newID)

		if err != nil {
			errMsg := "Error insertando nodo"
			result.Status = "error"; result.Error = &errMsg; failed++
		} else {
			result.Status = "creado"; result.NodeID = &newID
			result.Code = code
			codeToID[code] = newID
			created++
		}
		results = append(results, result)
	}

	return c.JSON(fiber.Map{
		"total":   len(importRows),
		"created": created,
		"failed":  failed,
		"results": results,
	})
}

// ─── POST /import/cleanup — orphan data cleanup ──────────────────────

func (h *ImportHandler) Cleanup(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	rows, err := h.db.Query(c.UserContext(),
		`SELECT action, count FROM cleanup_orphaned_data($1)`,
		claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error ejecutando limpieza")
	}
	defer rows.Close()

	type CleanupResult struct {
		Action string `json:"action"`
		Count  int64  `json:"count"`
	}
	var results []CleanupResult
	for rows.Next() {
		var r CleanupResult
		if rows.Scan(&r.Action, &r.Count) == nil {
			results = append(results, r)
		}
	}

	return c.JSON(fiber.Map{
		"message": "Limpieza completada",
		"results": results,
	})
}

// ─── GET /import/conflicts — optimistic locking conflict statistics ─

func (h *ImportHandler) Conflicts(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	type ConflictEntry struct {
		ID         int64  `json:"id"`
		EntityType string `json:"entity_type"`
		EntityID   int64  `json:"entity_id"`
		ConflictAt string `json:"conflict_at"`
	}

	// Count nodes and WOs with version > 1 as a proxy for resolved concurrent edits
	var woConflicts, nodeConflicts int64
	h.db.QueryRow(c.UserContext(),
		`SELECT COUNT(*) FROM work_orders WHERE tenant_id=$1 AND version > 1`, claims.TenantID,
	).Scan(&woConflicts)
	h.db.QueryRow(c.UserContext(),
		`SELECT COUNT(*) FROM factory_nodes WHERE tenant_id=$1 AND version > 1`, claims.TenantID,
	).Scan(&nodeConflicts)

	return c.JSON(fiber.Map{
		"stats": fiber.Map{
			"total": woConflicts + nodeConflicts,
			"wos":   woConflicts,
			"nodes": nodeConflicts,
		},
		"recent": []ConflictEntry{},
	})
}

// ─── Helper ───────────────────────────────────────────────────────────────────

func getCol(row []string, idx int) string {
	if idx < len(row) { return row[idx] }
	return ""
}
