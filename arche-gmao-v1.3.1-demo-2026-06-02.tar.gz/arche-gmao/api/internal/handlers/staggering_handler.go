package handlers

import (
	"strconv"

	"arche-gmao/api/internal/ai"
	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type StaggeringHandler struct {
	db      *pgxpool.Pool
	service *ai.StaggeringService
}

func NewStaggeringHandler(db *pgxpool.Pool, service *ai.StaggeringService) *StaggeringHandler {
	return &StaggeringHandler{db: db, service: service}
}

// ─── GET /maintenance/staggering/config ─────────────────────────────────────

func (h *StaggeringHandler) GetConfig(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	rows, err := h.db.Query(c.UserContext(), `
		SELECT sc.id, sc.scope, sc.scope_node_id, fn.name AS scope_node_name,
		       sc.period, sc.max_daily_per_tech, sc.is_active, sc.created_at::text
		FROM staggered_configs sc
		LEFT JOIN factory_nodes fn ON fn.id = sc.scope_node_id
		WHERE sc.tenant_id = $1
		ORDER BY sc.scope, sc.id`,
		claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando configuración")
	}
	defer rows.Close()

	var configs []fiber.Map
	for rows.Next() {
		var (
			id                         int64
			scope, period, created     string
			scopeNodeID                *int64
			scopeNodeName              *string
			maxDaily                   int
			isActive                   bool
		)
		if err := rows.Scan(&id, &scope, &scopeNodeID, &scopeNodeName,
			&period, &maxDaily, &isActive, &created); err != nil {
			continue
		}
		configs = append(configs, fiber.Map{
			"id":              id,
			"scope":           scope,
			"scope_node_id":   scopeNodeID,
			"scope_node_name": scopeNodeName,
			"period":          period,
			"max_daily_per_tech": maxDaily,
			"is_active":       isActive,
			"created_at":      created,
		})
	}

	return c.JSON(fiber.Map{"configs": configs})
}

// ─── PUT /maintenance/staggering/config ─────────────────────────────────────

func (h *StaggeringHandler) UpdateConfig(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req struct {
		ID             *int64 `json:"id"`
		Scope          string `json:"scope"`
		ScopeNodeID    *int64 `json:"scope_node_id"`
		Period         string `json:"period"`
		MaxDailyPerTech int   `json:"max_daily_per_tech"`
		IsActive       bool   `json:"is_active"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	validScopes := map[string]bool{"global": true, "area": true, "line": true}
	if !validScopes[req.Scope] {
		return fiber.NewError(fiber.StatusBadRequest, "Ámbito inválido. Usar: global, area, line")
	}
	validPeriods := map[string]bool{"weekly": true, "biweekly": true, "monthly": true}
	if !validPeriods[req.Period] {
		return fiber.NewError(fiber.StatusBadRequest, "Período inválido. Usar: weekly, biweekly, monthly")
	}
	if req.MaxDailyPerTech <= 0 {
		req.MaxDailyPerTech = 3
	}
	if req.Scope != "global" && req.ScopeNodeID == nil {
		return fiber.NewError(fiber.StatusBadRequest, "Se requiere un nodo raíz para ámbito por área o línea")
	}

	if req.ID != nil && *req.ID > 0 {
		// Update
		result, err := h.db.Exec(c.UserContext(),
			`UPDATE staggered_configs
			 SET scope=$1, scope_node_id=$2, period=$3, max_daily_per_tech=$4, is_active=$5
			 WHERE id=$6 AND tenant_id=$7`,
			req.Scope, req.ScopeNodeID, req.Period, req.MaxDailyPerTech, req.IsActive,
			*req.ID, claims.TenantID,
		)
		if err != nil || result.RowsAffected() == 0 {
			return fiber.NewError(fiber.StatusNotFound, "Configuración no encontrada")
		}
		return c.JSON(fiber.Map{"id": *req.ID, "message": "Configuración actualizada"})
	}

	// Create
	var newID int64
	err := h.db.QueryRow(c.UserContext(),
		`INSERT INTO staggered_configs (tenant_id, scope, scope_node_id, period, max_daily_per_tech, is_active, created_by)
		 VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
		claims.TenantID, req.Scope, req.ScopeNodeID, req.Period, req.MaxDailyPerTech, req.IsActive, claims.UserID,
	).Scan(&newID)
	if err != nil {
		return fiber.NewError(fiber.StatusConflict, "Ya existe una configuración para este ámbito")
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": newID, "message": "Configuración creada"})
}

// ─── POST /maintenance/staggering/preview ───────────────────────────────────
// Computes the distribution without saving it. It only returns the preview.

func (h *StaggeringHandler) Preview(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req struct {
		ConfigID int64 `json:"config_id"`
	}
	if err := c.BodyParser(&req); err != nil || req.ConfigID == 0 {
		return fiber.NewError(fiber.StatusBadRequest, "Se requiere config_id")
	}

	preview, err := h.service.CalculatePreview(c.UserContext(), claims.TenantID, req.ConfigID)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, err.Error())
	}

	return c.JSON(preview)
}

// ─── POST /maintenance/staggering/apply ─────────────────────────────────────
// Computes and stores the schedule, creating a new cycle.

func (h *StaggeringHandler) Apply(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req struct {
		ConfigID int64 `json:"config_id"`
	}
	if err := c.BodyParser(&req); err != nil || req.ConfigID == 0 {
		return fiber.NewError(fiber.StatusBadRequest, "Se requiere config_id")
	}

	cycleID, err := h.service.ApplySchedule(c.UserContext(), claims.TenantID, req.ConfigID, claims.UserID)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, err.Error())
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"cycle_id": cycleID,
		"message":  "Escalonado aplicado correctamente",
	})
}

// ─── GET /maintenance/staggering/schedule ───────────────────────────────────
// Returns the schedule of the active cycle, or of the cycle given.

func (h *StaggeringHandler) GetSchedule(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	cycleIDStr := c.Query("cycle_id")

	var cycleQuery string
	var cycleArgs []interface{}

	if cycleIDStr != "" {
		cycleID, err := strconv.ParseInt(cycleIDStr, 10, 64)
		if err != nil {
			return fiber.NewError(fiber.StatusBadRequest, "cycle_id inválido")
		}
		cycleQuery = `SELECT id, config_id, cycle_start::text, cycle_end::text,
		              total_planned, total_executed, total_rescheduled, status
		              FROM staggered_cycles WHERE id=$1 AND tenant_id=$2`
		cycleArgs = []interface{}{cycleID, claims.TenantID}
	} else {
		// Most recent cycle, in progress or planned
		cycleQuery = `SELECT id, config_id, cycle_start::text, cycle_end::text,
		              total_planned, total_executed, total_rescheduled, status
		              FROM staggered_cycles WHERE tenant_id=$1 AND status IN ('planned','in_progress')
		              ORDER BY cycle_start DESC LIMIT 1`
		cycleArgs = []interface{}{claims.TenantID}
	}

	var cycleID, configID int64
	var cycleStart, cycleEnd, status string
	var planned, executed, rescheduled int
	err := h.db.QueryRow(c.UserContext(), cycleQuery, cycleArgs...).Scan(
		&cycleID, &configID, &cycleStart, &cycleEnd, &planned, &executed, &rescheduled, &status,
	)
	if err != nil {
		return c.JSON(fiber.Map{"cycle": nil, "entries": []fiber.Map{}})
	}

	// Get the schedule entries
	rows, err := h.db.Query(c.UserContext(), `
		SELECT ss.id, ss.plan_id, mp.title AS plan_title,
		       ss.node_id, fn.name AS node_name, fn.code AS node_code, fn.criticality,
		       ss.scheduled_date::text, ss.technician_id, COALESCE(u.full_name,'') AS tech_name,
		       ss.status, ss.rescheduled_from::text, ss.wo_id
		FROM staggered_schedule ss
		JOIN maintenance_plans mp ON mp.id = ss.plan_id
		JOIN factory_nodes fn ON fn.id = ss.node_id
		LEFT JOIN users u ON u.id = ss.technician_id
		WHERE ss.cycle_id = $1 AND ss.tenant_id = $2
		ORDER BY ss.scheduled_date, fn.criticality, fn.name`,
		cycleID, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando schedule")
	}
	defer rows.Close()

	var entries []fiber.Map
	for rows.Next() {
		var (
			entryID, planID, nodeID                    int64
			planTitle, nodeName, nodeCode, criticality string
			schedDate, entryStatus                     string
			techID                                     *int64
			techName                                   string
			rescheduledFrom                            *string
			woID                                       *int64
		)
		if err := rows.Scan(&entryID, &planID, &planTitle,
			&nodeID, &nodeName, &nodeCode, &criticality,
			&schedDate, &techID, &techName,
			&entryStatus, &rescheduledFrom, &woID); err != nil {
			continue
		}
		entries = append(entries, fiber.Map{
			"id":               entryID,
			"plan_id":          planID,
			"plan_title":       planTitle,
			"node_id":          nodeID,
			"node_name":        nodeName,
			"node_code":        nodeCode,
			"criticality":      criticality,
			"scheduled_date":   schedDate,
			"technician_id":    techID,
			"technician_name":  techName,
			"status":           entryStatus,
			"rescheduled_from": rescheduledFrom,
			"wo_id":            woID,
		})
	}

	return c.JSON(fiber.Map{
		"cycle": fiber.Map{
			"id":                cycleID,
			"config_id":         configID,
			"cycle_start":       cycleStart,
			"cycle_end":         cycleEnd,
			"total_planned":     planned,
			"total_executed":    executed,
			"total_rescheduled": rescheduled,
			"status":            status,
		},
		"entries": entries,
	})
}

// ─── GET /maintenance/staggering/cycles ─────────────────────────────────────
// Cycle history with compliance metrics.

func (h *StaggeringHandler) ListCycles(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	rows, err := h.db.Query(c.UserContext(), `
		SELECT cy.id, cy.config_id, sc.scope, sc.period,
		       cy.cycle_start::text, cy.cycle_end::text,
		       cy.total_planned, cy.total_executed, cy.total_rescheduled,
		       cy.status, cy.created_at::text,
		       CASE WHEN cy.total_planned > 0
		            THEN ROUND((cy.total_executed::numeric / cy.total_planned) * 100, 1)
		            ELSE 0 END AS compliance_pct
		FROM staggered_cycles cy
		JOIN staggered_configs sc ON sc.id = cy.config_id
		WHERE cy.tenant_id = $1
		ORDER BY cy.cycle_start DESC
		LIMIT 50`,
		claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando ciclos")
	}
	defer rows.Close()

	var cycles []fiber.Map
	for rows.Next() {
		var (
			id, configID                                       int64
			scope, period, start, end, status, created         string
			planned, executed, rescheduled                     int
			compliance                                         float64
		)
		if err := rows.Scan(&id, &configID, &scope, &period,
			&start, &end, &planned, &executed, &rescheduled,
			&status, &created, &compliance); err != nil {
			continue
		}
		cycles = append(cycles, fiber.Map{
			"id":                id,
			"config_id":         configID,
			"scope":             scope,
			"period":            period,
			"cycle_start":       start,
			"cycle_end":         end,
			"total_planned":     planned,
			"total_executed":    executed,
			"total_rescheduled": rescheduled,
			"compliance_pct":    compliance,
			"status":            status,
			"created_at":        created,
		})
	}

	return c.JSON(fiber.Map{"cycles": cycles})
}
