package handlers

import (
	"bytes"
	"context"
	"encoding/base64"
	"fmt"
	"html"
	"net/url"
	"strconv"
	"strings"
	"time"

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/skip2/go-qrcode"
	"github.com/xuri/excelize/v2"
)

type QRHandler struct {
	db      *pgxpool.Pool
	baseURL string
}

func NewQRHandler(db *pgxpool.Pool, baseURL string) *QRHandler {
	if baseURL == "" {
		baseURL = "http://localhost:5173"
	}
	return &QRHandler{db: db, baseURL: baseURL}
}

// ─── GET /factory/nodes/:id/qr — generates the QR PNG ───────────────────────────

func (h *QRHandler) GenerateQR(c *fiber.Ctx) error {
	nodeID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	// Get the node code
	var nodeCode, nodeName string
	var tenantID int64
	claims := c.Locals("claims").(*types.Claims)
	err = h.db.QueryRow(c.UserContext(),
		`SELECT COALESCE(code, id::text), name, tenant_id
		 FROM factory_nodes WHERE id=$1 AND tenant_id=$2`, nodeID, claims.TenantID,
	).Scan(&nodeCode, &nodeName, &tenantID)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Nodo no encontrado")
	}

	// The URL the QR encodes — use the request's Origin/Referer so it works over the network
	base := resolveBaseURL(c, h.baseURL)
	qrURL := fmt.Sprintf("%s/scan/%s", base, url.PathEscape(nodeCode))

	// Configurable size
	size := 256
	if s := c.QueryInt("size", 0); s > 0 && s <= 1024 {
		size = s
	}

	// Generate the QR
	png, err := qrcode.Encode(qrURL, qrcode.Medium, size)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error generando QR")
	}

	c.Set("Content-Type", "image/png")
	c.Set("Content-Disposition", fmt.Sprintf(`inline; filename="qr-%s.png"`, sanitizeFileName(nodeCode)))
	c.Set("Cache-Control", "public, max-age=3600")
	return c.Send(png)
}

// ─── GET /api/v1/scan/:code — QR scan (JSON) ────────────────────────────
// OptionalAuth: without a token it returns only {found: bool}.
// With a token: it returns the full node data.

func (h *QRHandler) ScanPage(c *fiber.Ctx) error {
	code := c.Params("code")
	if code == "" {
		return fiber.NewError(fiber.StatusBadRequest, "Código inválido")
	}
	if decoded, err := url.PathUnescape(code); err == nil {
		code = decoded
	}

	claims, _ := c.Locals("claims").(*types.Claims)

	// ─── Compositions: a code with the "comp-" prefix ──────────────────────────
	if strings.HasPrefix(code, "comp-") {
		compIDStr := strings.TrimPrefix(code, "comp-")
		compID, err := strconv.ParseInt(compIDStr, 10, 64)
		if err != nil {
			return c.JSON(fiber.Map{"found": false, "authenticated": false, "type": "composition"})
		}
		if claims == nil {
			// Only state that it exists — do not expose the tenant or any detail
			var exists bool
			err := h.db.QueryRow(c.UserContext(),
				`SELECT EXISTS(SELECT 1 FROM equipment_compositions WHERE id=$1)`, compID,
			).Scan(&exists)
			if err != nil {
				exists = false
			}
			return c.JSON(fiber.Map{"found": exists, "authenticated": false, "type": "composition"})
		}
		// With auth: full composition data
		var cName string
		var cDesc *string
		var tenantID int64
		err = h.db.QueryRow(c.UserContext(),
			`SELECT id, name, description, tenant_id
			 FROM equipment_compositions WHERE id=$1 AND tenant_id=$2`,
			compID, claims.TenantID,
		).Scan(&compID, &cName, &cDesc, &tenantID)
		if err != nil {
			return c.JSON(fiber.Map{"found": false, "authenticated": true, "type": "composition"})
		}
		// Members
		type memberItem struct {
			NodeID   int64  `json:"node_id"`
			NodeName string `json:"node_name"`
			NodeCode string `json:"node_code"`
			NodeType string `json:"node_type"`
			Role     string `json:"role"`
		}
		var members []memberItem
		mRows, _ := h.db.Query(c.UserContext(),
			`SELECT ecm.node_id, fn.name, COALESCE(fn.code,''), fn.node_type, COALESCE(ecm.role,'')
			 FROM equipment_composition_members ecm
			 JOIN factory_nodes fn ON fn.id = ecm.node_id
			 WHERE ecm.composition_id = $1 AND fn.tenant_id = $2
			 ORDER BY ecm.sort_order, fn.name`,
			compID, tenantID,
		)
		if mRows != nil {
			defer mRows.Close()
			for mRows.Next() {
				var m memberItem
				if mRows.Scan(&m.NodeID, &m.NodeName, &m.NodeCode, &m.NodeType, &m.Role) == nil {
					members = append(members, m)
				}
			}
		}
		return c.JSON(fiber.Map{
			"found":         true,
			"authenticated": true,
			"type":          "composition",
			"composition": fiber.Map{
				"id":          compID,
				"name":        cName,
				"description": cDesc,
			},
			"members": members,
		})
	}

	// ─── Unauthenticated: only state whether it exists ──────────────────────────
	if claims == nil {
		var exists bool
		err := h.db.QueryRow(c.UserContext(),
			`SELECT EXISTS(SELECT 1 FROM factory_nodes WHERE code=$1 OR id::text=$1)`, code,
		).Scan(&exists)
		if err != nil {
			exists = false
		}
		return c.JSON(fiber.Map{"found": exists, "authenticated": false, "type": "node"})
	}

	// ─── Authenticated: return the full info ──────────────────────────
	var nodeID int64
	var tenantID int64
	var name, nodeCode, nodeType, criticality, status string
	err := h.db.QueryRow(c.UserContext(),
		`SELECT id, tenant_id, name, COALESCE(code,''), node_type, criticality, status
		 FROM factory_nodes WHERE (code=$1 OR id::text=$1) AND tenant_id=$2`,
		code, claims.TenantID,
	).Scan(&nodeID, &tenantID, &name, &nodeCode, &nodeType, &criticality, &status)
	if err != nil {
		return c.JSON(fiber.Map{"found": false, "authenticated": true})
	}

	// Record the scan
	uid := int64(claims.UserID)
	ip := c.IP()
	ua := string(c.Request().Header.UserAgent())
	go func() {
		h.db.Exec(context.Background(),
			`INSERT INTO qr_scans (tenant_id, node_id, scanned_by, ip_address, user_agent)
			 VALUES ($1,$2,$3,$4,$5)`,
			tenantID, nodeID, uid, ip, ua,
		)
	}()

	// Active WOs
	type woItem struct {
		WONumber string `json:"wo_number"`
		Title    string `json:"title"`
		Status   string `json:"status"`
		Priority string `json:"priority"`
	}
	var activeWOs []woItem
	woRows, _ := h.db.Query(c.UserContext(),
		`SELECT wo_number, title, status, priority
		 FROM work_orders
		 WHERE node_id=$1 AND tenant_id=$2 AND status NOT IN ('completed','verified','closed','cancelled')
		 ORDER BY created_at DESC LIMIT 5`,
		nodeID, tenantID,
	)
	if woRows != nil {
		defer woRows.Close()
		for woRows.Next() {
			var wo woItem
			if woRows.Scan(&wo.WONumber, &wo.Title, &wo.Status, &wo.Priority) == nil {
				activeWOs = append(activeWOs, wo)
			}
		}
	}

	// Last maintenance
	var lastWONumber, lastWODate *string
	h.db.QueryRow(c.UserContext(),
		`SELECT wo_number, completed_at::text
		 FROM work_orders
		 WHERE node_id=$1 AND tenant_id=$2 AND status IN ('completed','verified','closed')
		 ORDER BY completed_at DESC LIMIT 1`,
		nodeID, tenantID,
	).Scan(&lastWONumber, &lastWODate)

	// Next maintenance
	var nextPlanTitle, nextPlanDate *string
	h.db.QueryRow(c.UserContext(),
		`SELECT title, next_due_at::text
		 FROM maintenance_plans
		 WHERE node_id=$1 AND tenant_id=$2 AND is_active=true
		 ORDER BY next_due_at ASC LIMIT 1`,
		nodeID, tenantID,
	).Scan(&nextPlanTitle, &nextPlanDate)

	// Compositions of the node
	type compItem struct {
		ID   int64  `json:"id"`
		Name string `json:"name"`
	}
	var compositions []compItem
	compRows, _ := h.db.Query(c.UserContext(),
		`SELECT ec.id, ec.name
		 FROM equipment_compositions ec
		 JOIN equipment_composition_members ecm ON ecm.composition_id = ec.id AND ecm.node_id = $1
		 WHERE ec.tenant_id = $2
		 ORDER BY ec.name`,
		nodeID, tenantID,
	)
	if compRows != nil {
		defer compRows.Close()
		for compRows.Next() {
			var comp compItem
			if compRows.Scan(&comp.ID, &comp.Name) == nil {
				compositions = append(compositions, comp)
			}
		}
	}

	return c.JSON(fiber.Map{
		"found":         true,
		"authenticated": true,
		"type":          "node",
		"node": fiber.Map{
			"id":          nodeID,
			"name":        name,
			"code":        nodeCode,
			"node_type":   nodeType,
			"criticality": criticality,
			"status":      status,
		},
		"active_wos":       activeWOs,
		"last_maintenance":  fiber.Map{"wo_number": lastWONumber, "date": lastWODate},
		"next_maintenance":  fiber.Map{"title": nextPlanTitle, "date": nextPlanDate},
		"compositions":      compositions,
	})
}

// ─── GET /compositions/:id/qr — generates the composition QR PNG ────────────

func (h *QRHandler) GenerateCompositionQR(c *fiber.Ctx) error {
	compID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	claims := c.Locals("claims").(*types.Claims)
	var compName string
	err = h.db.QueryRow(c.UserContext(),
		`SELECT name FROM equipment_compositions WHERE id=$1 AND tenant_id=$2`,
		compID, claims.TenantID,
	).Scan(&compName)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Composición no encontrada")
	}

	base := resolveBaseURL(c, h.baseURL)
	qrURL := fmt.Sprintf("%s/scan/comp-%d", base, compID)

	size := 256
	if s := c.QueryInt("size", 0); s > 0 && s <= 1024 {
		size = s
	}

	png, err := qrcode.Encode(qrURL, qrcode.Medium, size)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error generando QR")
	}

	c.Set("Content-Type", "image/png")
	c.Set("Content-Disposition", fmt.Sprintf(`inline; filename="qr-comp-%d.png"`, compID))
	c.Set("Cache-Control", "public, max-age=3600")
	return c.Send(png)
}

// ─── GET /factory/nodes/:id/qr-scans — scan history ─────────────────

func (h *QRHandler) ScanHistory(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID, _ := strconv.ParseInt(c.Params("id"), 10, 64)

	rows, err := h.db.Query(c.UserContext(),
		`SELECT qs.id, u.full_name, qs.ip_address, qs.scanned_at::text
		 FROM qr_scans qs
		 LEFT JOIN users u ON u.id=qs.scanned_by
		 WHERE qs.node_id=$1 AND qs.tenant_id=$2
		 ORDER BY qs.scanned_at DESC LIMIT 50`,
		nodeID, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error")
	}
	defer rows.Close()

	type Scan struct {
		ID         int64   `json:"id"`
		UserName   *string `json:"user_name"`
		IPAddress  *string `json:"ip_address"`
		ScannedAt  string  `json:"scanned_at"`
	}

	var scans []Scan
	for rows.Next() {
		var s Scan
		if rows.Scan(&s.ID, &s.UserName, &s.IPAddress, &s.ScannedAt) == nil {
			scans = append(scans, s)
		}
	}

	return c.JSON(fiber.Map{"scans": scans, "total": len(scans)})
}

// ─── GET /factory/nodes/qr-sheet — printable PDF sheet ─────────────────────

func (h *QRHandler) PrintSheet(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	parentID := c.Query("parent_id")

	// Get the nodes of the selected area/line
	query := `SELECT id, name, COALESCE(code, id::text), node_type, criticality
	          FROM factory_nodes
	          WHERE tenant_id=$1 AND status != 'decommissioned'
	            AND node_type IN ('equipment','component')`
	args := []interface{}{claims.TenantID}

	if parentID != "" {
		query += ` AND parent_id=$2`
		args = append(args, parentID)
	}
	query += ` ORDER BY name LIMIT 50`

	rows, err := h.db.Query(c.UserContext(), query, args...)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando nodos")
	}
	defer rows.Close()

	type NodeQR struct {
		ID          int64
		Name        string
		Code        string
		NodeType    string
		Criticality string
	}

	var nodes []NodeQR
	for rows.Next() {
		var n NodeQR
		if rows.Scan(&n.ID, &n.Name, &n.Code, &n.NodeType, &n.Criticality) == nil {
			nodes = append(nodes, n)
		}
	}

	if len(nodes) == 0 {
		return c.SendString("<html><body><p>No hay equipos en esta área.</p></body></html>")
	}

	// Generate HTML with the QRs embedded as base64
	base := resolveBaseURL(c, h.baseURL)
	qrItems := ""
	for _, n := range nodes {
		qrURL := fmt.Sprintf("%s/scan/%s", base, url.PathEscape(n.Code))
		png, err := qrcode.Encode(qrURL, qrcode.Medium, 180)
		if err != nil {
			continue
		}

		// Convert to base64
		b64 := encodeBase64(png)
		critColor := map[string]string{
			"low": "#27AE60", "medium": "#F39C12",
			"high": "#E67E22", "critical": "#E94560",
		}[n.Criticality]
		if critColor == "" {
			critColor = "#888"
		}

		qrItems += fmt.Sprintf(`
		<div class="qr-item">
			<img src="data:image/png;base64,%s" alt="QR %s" />
			<div class="qr-name">%s</div>
			<div class="qr-code">%s</div>
			<div class="qr-crit" style="background:%s">%s</div>
		</div>`, b64, html.EscapeString(n.Code), html.EscapeString(n.Name), html.EscapeString(n.Code), critColor, html.EscapeString(n.Criticality))
	}

	tenantName := "Arche GMAO"
	html := fmt.Sprintf(`<!DOCTYPE html>
<html lang="es"><head><meta charset="UTF-8"><title>Códigos QR — %s</title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family: 'Segoe UI', Arial, sans-serif; font-size:12px; color:#1a1a2e; }
.header { text-align:center; padding:20px; border-bottom:3px solid #0f3460; margin-bottom:20px; }
.header h1 { font-size:20px; font-weight:900; letter-spacing:4px; color:#0f3460; }
.header p { font-size:10px; color:#888; margin-top:4px; }
.grid { display:grid; grid-template-columns:repeat(4,1fr); gap:16px; padding:0 20px 20px; }
.qr-item { border:1px solid #e5e7eb; border-radius:8px; padding:12px; text-align:center; break-inside:avoid; }
.qr-item img { width:140px; height:140px; display:block; margin:0 auto 8px; }
.qr-name { font-size:11px; font-weight:600; color:#0f3460; margin-bottom:4px; line-height:1.3; }
.qr-code { font-size:9px; font-family:monospace; color:#888; margin-bottom:6px; }
.qr-crit { display:inline-block; font-size:9px; font-weight:700; color:#fff; padding:2px 8px; border-radius:20px; text-transform:uppercase; }
.footer { text-align:center; padding:10px; border-top:1px solid #e5e7eb; font-size:9px; color:#888; }
@media print { .no-print { display:none; } }
</style>
</head><body>
<div class="header">
  <h1>ARCHE GMAO</h1>
  <p>Hoja de códigos QR — %s — Generado: %s</p>
  <button class="no-print" onclick="window.print()" style="margin-top:10px;padding:6px 16px;background:#0f3460;color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:12px">
    🖨 Imprimir / Guardar PDF
  </button>
</div>
<div class="grid">%s</div>
<div class="footer">Escanea con cualquier lector QR para acceder a la ficha del equipo</div>
</body></html>`,
		tenantName, tenantName,
		time.Now().Format("02/01/2006 15:04"),
		qrItems,
	)

	c.Set("Content-Type", "text/html; charset=utf-8")
	return c.SendString(html)
}

// ─── GET /factory/nodes/qr-excel — list of nodes with their QR URLs ────────────────

func (h *QRHandler) QRExcel(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	rows, err := h.db.Query(c.UserContext(),
		`SELECT id, name, COALESCE(code,id::text), node_type, criticality
		 FROM factory_nodes
		 WHERE tenant_id=$1 AND status!='decommissioned'
		   AND node_type IN ('equipment','component')
		 ORDER BY name`,
		claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error")
	}
	defer rows.Close()

	f := excelize.NewFile()
	defer f.Close()
	sheet := "Códigos QR"
	f.SetSheetName("Sheet1", sheet)

	headerStyle, _ := f.NewStyle(&excelize.Style{
		Fill: excelize.Fill{Type: "pattern", Color: []string{"0F3460"}, Pattern: 1},
		Font: &excelize.Font{Color: "FFFFFF", Bold: true},
	})

	headers := []string{"Nombre", "Código", "Tipo", "Criticidad", "URL QR"}
	for i, h2 := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1)
		f.SetCellValue(sheet, cell, h2)
		f.SetCellStyle(sheet, cell, cell, headerStyle)
	}

	base := resolveBaseURL(c, h.baseURL)
	row := 2
	for rows.Next() {
		var id int64
		var name, code, nodeType, criticality string
		if rows.Scan(&id, &name, &code, &nodeType, &criticality) == nil {
			qrURL := fmt.Sprintf("%s/scan/%s", base, url.PathEscape(code))
			for col, val := range []interface{}{name, code, nodeType, criticality, qrURL} {
				cell, _ := excelize.CoordinatesToCellName(col+1, row)
				f.SetCellValue(sheet, cell, val)
			}
			row++
		}
	}

	f.SetColWidth(sheet, "A", "A", 35)
	f.SetColWidth(sheet, "E", "E", 50)

	var buf bytes.Buffer
	f.Write(&buf)

	c.Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	c.Set("Content-Disposition", `attachment; filename="codigos_qr.xlsx"`)
	return c.Send(buf.Bytes())
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

// resolveBaseURL derives the base URL from the request's Origin or Referer.
// This lets the QR codes work from any device on the same network.
func resolveBaseURL(c *fiber.Ctx, fallback string) string {
	if origin := c.Get("Origin"); origin != "" {
		return origin
	}
	if referer := c.Get("Referer"); referer != "" {
		if u, err := url.Parse(referer); err == nil {
			return u.Scheme + "://" + u.Host
		}
	}
	// Use the current request's Host header (works when scanning a QR from a phone)
	if host := c.Get("Host"); host != "" {
		scheme := "http"
		if c.Get("X-Forwarded-Proto") == "https" || c.Secure() {
			scheme = "https"
		}
		return scheme + "://" + host
	}
	return fallback
}

func encodeBase64(data []byte) string {
	return base64.StdEncoding.EncodeToString(data)
}

