package handlers

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"

	"arche-gmao/api/internal/ai"
	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type AIAdminHandler struct {
	db     *pgxpool.Pool
	rag    *ai.RAGService
	ollama *ai.OllamaClient
	sem    *ai.AISemaphore
}

func NewAIAdminHandler(db *pgxpool.Pool, rag *ai.RAGService, ollama *ai.OllamaClient, sem *ai.AISemaphore) *AIAdminHandler {
	return &AIAdminHandler{db: db, rag: rag, ollama: ollama, sem: sem}
}

// ─── GET /ai/admin/models ─────────────────────────────────────────────────────

func (h *AIAdminHandler) ListModels(c *fiber.Ctx) error {
	ctx, cancel := context.WithTimeout(c.UserContext(), 5*time.Second)
	defer cancel()

	models, err := h.ollama.ListModels(ctx)
	if err != nil {
		return c.JSON(fiber.Map{"models": []string{}, "error": "Ollama no disponible"})
	}

	claims := c.Locals("claims").(*types.Claims)
	var chatModel, embedModel string
	h.db.QueryRow(c.UserContext(),
		`SELECT COALESCE(ai_chat_model,'llama3'), COALESCE(ai_embed_model,'nomic-embed-text')
		 FROM tenants WHERE id=$1`, claims.TenantID,
	).Scan(&chatModel, &embedModel)

	return c.JSON(fiber.Map{
		"models": models, "chat_model": chatModel, "embed_model": embedModel,
	})
}

// ─── PUT /ai/admin/models ─────────────────────────────────────────────────────

func (h *AIAdminHandler) SetModel(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	var req struct {
		ChatModel  string `json:"chat_model"`
		EmbedModel string `json:"embed_model"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	if _, err := h.db.Exec(c.UserContext(),
		`UPDATE tenants SET ai_chat_model=COALESCE(NULLIF($1,''),ai_chat_model),
		 ai_embed_model=COALESCE(NULLIF($2,''),ai_embed_model) WHERE id=$3`,
		req.ChatModel, req.EmbedModel, claims.TenantID,
	); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error guardando modelo de IA")
	}

	// Log
	h.db.Exec(c.UserContext(),
		`INSERT INTO ai_permission_log (tenant_id, changed_by, action, new_value)
		 VALUES ($1,$2,'model_changed',$3)`,
		claims.TenantID, claims.UserID,
		fmt.Sprintf("chat=%s embed=%s", req.ChatModel, req.EmbedModel),
	)

	return c.JSON(fiber.Map{"message": "Modelo actualizado"})
}

// ─── GET /ai/admin/roles ─────────────────────────────────────────────────────

func (h *AIAdminHandler) GetRoles(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	var rolesJSON []byte
	h.db.QueryRow(c.UserContext(),
		`SELECT COALESCE(ai_enabled_roles,'["admin","supervisor","technician","operator","warehouse","auditor"]'::jsonb)
		 FROM tenants WHERE id=$1`, claims.TenantID,
	).Scan(&rolesJSON)
	return c.JSON(fiber.Map{"enabled_roles": string(rolesJSON)})
}

// ─── PUT /ai/admin/roles ─────────────────────────────────────────────────────

func (h *AIAdminHandler) SetRoles(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	var req struct {
		EnabledRoles []string `json:"enabled_roles"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	// An admin always has access
	hasAdmin := false
	for _, r := range req.EnabledRoles {
		if r == "admin" { hasAdmin = true; break }
	}
	if !hasAdmin { req.EnabledRoles = append(req.EnabledRoles, "admin") }

	// Get the previous value for the log
	var oldRolesJSON []byte
	h.db.QueryRow(c.UserContext(),
		`SELECT ai_enabled_roles FROM tenants WHERE id=$1`, claims.TenantID,
	).Scan(&oldRolesJSON)

	rolesJSONBytes, _ := json.Marshal(req.EnabledRoles)
	rolesJSON := string(rolesJSONBytes)
	_, err := h.db.Exec(c.UserContext(),
		`UPDATE tenants SET ai_enabled_roles=$1::jsonb WHERE id=$2`,
		rolesJSON, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error actualizando roles de IA")
	}

	// Audit log
	h.db.Exec(c.UserContext(),
		`INSERT INTO ai_permission_log (tenant_id, changed_by, action, old_value, new_value)
		 VALUES ($1,$2,'roles_changed',$3,$4)`,
		claims.TenantID, claims.UserID, string(oldRolesJSON), rolesJSON,
	)

	return c.JSON(fiber.Map{"message": "Permisos actualizados"})
}

// ─── GET /ai/admin/permission-log ─────────────────────────────────────────────

func (h *AIAdminHandler) GetPermissionLog(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	rows, err := h.db.Query(c.UserContext(),
		`SELECT l.id, l.action, l.old_value, l.new_value, u.full_name, l.created_at::text
		 FROM ai_permission_log l
		 LEFT JOIN users u ON u.id=l.changed_by
		 WHERE l.tenant_id=$1 ORDER BY l.created_at DESC LIMIT 50`,
		claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error")
	}
	defer rows.Close()

	type Entry struct {
		ID        int64   `json:"id"`
		Action    string  `json:"action"`
		OldValue  *string `json:"old_value"`
		NewValue  *string `json:"new_value"`
		UserName  *string `json:"user_name"`
		CreatedAt string  `json:"created_at"`
	}
	var entries []Entry
	for rows.Next() {
		var e Entry
		if rows.Scan(&e.ID, &e.Action, &e.OldValue, &e.NewValue, &e.UserName, &e.CreatedAt) == nil {
			entries = append(entries, e)
		}
	}
	return c.JSON(fiber.Map{"log": entries})
}

// ─── GET /ai/admin/knowledge ──────────────────────────────────────────────────

func (h *AIAdminHandler) ListKnowledge(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	folder := c.Query("folder")
	category := c.Query("category")

	query := `SELECT k.id, k.title, k.category, k.folder, k.source, k.is_active,
	                 u.full_name AS created_by_name, k.created_at::text,
	                 LENGTH(k.content) AS content_length
	          FROM ai_knowledge k
	          LEFT JOIN users u ON u.id=k.created_by
	          WHERE k.tenant_id=$1`
	args := []interface{}{claims.TenantID}
	idx := 2

	if folder != "" {
		query += fmt.Sprintf(` AND k.folder=$%d`, idx); args = append(args, folder); idx++
	}
	if category != "" {
		query += fmt.Sprintf(` AND k.category=$%d`, idx); args = append(args, category); idx++
	}
	query += ` ORDER BY k.folder, k.created_at DESC`

	rows, err := h.db.Query(c.UserContext(), query, args...)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error")
	}
	defer rows.Close()

	type Knowledge struct {
		ID            int64   `json:"id"`
		Title         string  `json:"title"`
		Category      string  `json:"category"`
		Folder        string  `json:"folder"`
		Source        *string `json:"source"`
		IsActive      bool    `json:"is_active"`
		CreatedByName *string `json:"created_by_name"`
		CreatedAt     string  `json:"created_at"`
		ContentLength int     `json:"content_length"`
	}

	var items []Knowledge
	for rows.Next() {
		var k Knowledge
		if rows.Scan(&k.ID, &k.Title, &k.Category, &k.Folder, &k.Source,
			&k.IsActive, &k.CreatedByName, &k.CreatedAt, &k.ContentLength) == nil {
			items = append(items, k)
		}
	}

	// Get the folder list
	folderRows, _ := h.db.Query(c.UserContext(),
		`SELECT DISTINCT folder FROM ai_knowledge WHERE tenant_id=$1 ORDER BY folder`,
		claims.TenantID,
	)
	var folders []string
	if folderRows != nil {
		defer folderRows.Close()
		for folderRows.Next() {
			var f string
			if folderRows.Scan(&f) == nil { folders = append(folders, f) }
		}
	}

	return c.JSON(fiber.Map{"knowledge": items, "total": len(items), "folders": folders})
}

// ─── GET /ai/admin/knowledge/:id ─────────────────────────────────────────────

func (h *AIAdminHandler) GetKnowledge(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var title, content, category, folder string
	var source *string
	var isActive bool
	var createdAt string

	err := h.db.QueryRow(c.UserContext(),
		`SELECT title, content, category, COALESCE(folder,'General'), source, is_active, created_at::text
		 FROM ai_knowledge WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	).Scan(&title, &content, &category, &folder, &source, &isActive, &createdAt)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "No encontrado")
	}
	return c.JSON(fiber.Map{
		"id": id, "title": title, "content": content,
		"category": category, "folder": folder, "source": source,
		"is_active": isActive, "created_at": createdAt,
	})
}

// ─── POST /ai/admin/knowledge ─────────────────────────────────────────────────

func (h *AIAdminHandler) CreateKnowledge(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	var req struct {
		Title    string  `json:"title"`
		Content  string  `json:"content"`
		Category string  `json:"category"`
		Folder   string  `json:"folder"`
		Source   *string `json:"source"`
	}
	if err := c.BodyParser(&req); err != nil || req.Title == "" || req.Content == "" {
		return fiber.NewError(fiber.StatusBadRequest, "Título y contenido son obligatorios")
	}
	if req.Category == "" { req.Category = "general" }
	if req.Folder == "" { req.Folder = "General" }

	var newID int64
	err := h.db.QueryRow(c.UserContext(),
		`INSERT INTO ai_knowledge (tenant_id, title, content, category, folder, source, created_by)
		 VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
		claims.TenantID, req.Title, req.Content, req.Category, req.Folder, req.Source, claims.UserID,
	).Scan(&newID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error creando conocimiento")
	}

	h.db.Exec(c.UserContext(),
		`INSERT INTO ai_knowledge_log (tenant_id, knowledge_id, action, user_id, details)
		 VALUES ($1,$2,'created',$3,$4)`,
		claims.TenantID, newID, claims.UserID, req.Title,
	)

	go func() {
		h.db.Exec(context.Background(),
			`INSERT INTO ai_index_queue (tenant_id, action, source_type, source_id, priority)
			 VALUES ($1,'index','knowledge',$2,1) ON CONFLICT DO NOTHING`,
			claims.TenantID, newID,
		)
	}()

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": newID, "message": "Conocimiento creado e indexado"})
}

// ─── POST /ai/admin/knowledge/upload — upload a PDF or TXT ───────────────────────

func (h *AIAdminHandler) UploadKnowledge(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	file, err := c.FormFile("file")
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Archivo requerido")
	}

	title := c.FormValue("title", file.Filename)
	folder := c.FormValue("folder", "General")
	category := c.FormValue("category", "general")

	// Open the file
	f, err := file.Open()
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error leyendo archivo")
	}
	defer f.Close()

	raw, err := io.ReadAll(io.LimitReader(f, 5*1024*1024)) // max 5MB
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error leyendo archivo")
	}

	var content string

	// Detect the type
	contentType := file.Header.Get("Content-Type")
	ext := strings.ToLower(file.Filename)

	if strings.HasSuffix(ext, ".pdf") || strings.Contains(contentType, "pdf") {
		// Extract text from a PDF — search for readable strings
		content = extractTextFromPDF(raw)
		if len(strings.TrimSpace(content)) < 50 {
			return fiber.NewError(fiber.StatusBadRequest, "No se pudo extraer texto del PDF. El PDF puede estar escaneado como imagen.")
		}
	} else {
		// TXT or other plain text
		if !utf8.Valid(raw) {
			return fiber.NewError(fiber.StatusBadRequest, "El archivo debe ser texto UTF-8 o PDF")
		}
		content = string(raw)
	}

	// Clean up the content
	content = cleanText(content)
	if len(content) < 20 {
		return fiber.NewError(fiber.StatusBadRequest, "El archivo no contiene suficiente texto")
	}

	// Truncate when it is very long
	if len(content) > 50000 {
		content = content[:50000] + "\n\n[Contenido truncado — máximo 50.000 caracteres]"
	}

	var newID int64
	err = h.db.QueryRow(c.UserContext(),
		`INSERT INTO ai_knowledge (tenant_id, title, content, category, folder, source, created_by)
		 VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
		claims.TenantID, title, content, category, folder, file.Filename, claims.UserID,
	).Scan(&newID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error guardando conocimiento")
	}

	h.db.Exec(c.UserContext(),
		`INSERT INTO ai_knowledge_log (tenant_id, knowledge_id, action, user_id, details)
		 VALUES ($1,$2,'created',$3,$4)`,
		claims.TenantID, newID, claims.UserID, fmt.Sprintf("Subido desde archivo: %s", file.Filename),
	)

	go func() {
		h.db.Exec(context.Background(),
			`INSERT INTO ai_index_queue (tenant_id, action, source_type, source_id, priority)
			 VALUES ($1,'index','knowledge',$2,1) ON CONFLICT DO NOTHING`,
			claims.TenantID, newID,
		)
	}()

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"id":      newID,
		"message": fmt.Sprintf("Archivo procesado: %d caracteres extraídos e indexados", len(content)),
		"chars":   len(content),
	})
}

// ─── PUT /ai/admin/knowledge/:id ─────────────────────────────────────────────

func (h *AIAdminHandler) UpdateKnowledge(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}
	var req struct {
		Title    string  `json:"title"`
		Content  string  `json:"content"`
		Category string  `json:"category"`
		Folder   string  `json:"folder"`
		Source   *string `json:"source"`
		IsActive bool    `json:"is_active"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}
	if req.Folder == "" { req.Folder = "General" }

	h.db.Exec(c.UserContext(),
		`UPDATE ai_knowledge SET title=$1, content=$2, category=$3, folder=$4, source=$5,
		 is_active=$6, updated_by=$7 WHERE id=$8 AND tenant_id=$9`,
		req.Title, req.Content, req.Category, req.Folder, req.Source,
		req.IsActive, claims.UserID, id, claims.TenantID,
	)
	h.db.Exec(c.UserContext(),
		`INSERT INTO ai_knowledge_log (tenant_id, knowledge_id, action, user_id)
		 VALUES ($1,$2,'updated',$3)`,
		claims.TenantID, id, claims.UserID,
	)
	go func() {
		h.db.Exec(context.Background(),
			`INSERT INTO ai_index_queue (tenant_id, action, source_type, source_id, priority)
			 VALUES ($1,'reindex','knowledge',$2,1) ON CONFLICT DO NOTHING`,
			claims.TenantID, id,
		)
	}()
	return c.JSON(fiber.Map{"message": "Conocimiento actualizado"})
}

// ─── DELETE /ai/admin/knowledge/:id ──────────────────────────────────────────

func (h *AIAdminHandler) DeleteKnowledge(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)

	h.db.Exec(c.UserContext(),
		`UPDATE ai_knowledge SET is_active=false, updated_by=$1 WHERE id=$2 AND tenant_id=$3`,
		claims.UserID, id, claims.TenantID,
	)
	h.db.Exec(c.UserContext(),
		`INSERT INTO ai_knowledge_log (tenant_id, knowledge_id, action, user_id)
		 VALUES ($1,$2,'deactivated',$3)`,
		claims.TenantID, id, claims.UserID,
	)
	h.db.Exec(c.UserContext(),
		`DELETE FROM ai_embeddings WHERE tenant_id=$1 AND source_type='knowledge' AND source_id=$2`,
		claims.TenantID, id,
	)
	return c.JSON(fiber.Map{"message": "Conocimiento eliminado del índice"})
}

// ─── GET /ai/admin/calcs — list calculations ────────────────────────────────────

func (h *AIAdminHandler) ListCalcs(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	rows, err := h.db.Query(c.UserContext(),
		`SELECT id, title, description, params, is_active, is_builtin, sort_order
		 FROM ai_custom_calcs
		 WHERE tenant_id=$1 AND is_active=true
		 ORDER BY sort_order, created_at`,
		claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error")
	}
	defer rows.Close()

	type Calc struct {
		ID          int64           `json:"id"`
		Title       string          `json:"title"`
		Description *string         `json:"description"`
		Params      json.RawMessage `json:"params"`
		IsActive    bool            `json:"is_active"`
		IsBuiltin   bool            `json:"is_builtin"`
		SortOrder   int             `json:"sort_order"`
	}
	var calcs []Calc
	for rows.Next() {
		var ca Calc
		if rows.Scan(&ca.ID, &ca.Title, &ca.Description, &ca.Params,
			&ca.IsActive, &ca.IsBuiltin, &ca.SortOrder) == nil {
			calcs = append(calcs, ca)
		}
	}
	return c.JSON(fiber.Map{"calcs": calcs})
}

// ─── POST /ai/admin/calcs — create a custom calculation ──────────────────────

func (h *AIAdminHandler) CreateCalc(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	var req struct {
		Title          string          `json:"title"`
		Description    string          `json:"description"`
		PromptTemplate string          `json:"prompt_template"`
		Params         json.RawMessage `json:"params"`
	}
	if err := c.BodyParser(&req); err != nil || req.Title == "" || req.PromptTemplate == "" {
		return fiber.NewError(fiber.StatusBadRequest, "Título y plantilla de prompt son obligatorios")
	}
	if req.Params == nil { req.Params = json.RawMessage(`[]`) }

	var newID int64
	err := h.db.QueryRow(c.UserContext(),
		`INSERT INTO ai_custom_calcs (tenant_id, title, description, prompt_template, params, created_by)
		 VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
		claims.TenantID, req.Title, req.Description, req.PromptTemplate, req.Params, claims.UserID,
	).Scan(&newID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error creando cálculo")
	}
	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": newID, "message": "Cálculo creado"})
}

// ─── PUT /ai/admin/calcs/:id ──────────────────────────────────────────────────

func (h *AIAdminHandler) UpdateCalc(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var req struct {
		Title          string          `json:"title"`
		Description    string          `json:"description"`
		PromptTemplate string          `json:"prompt_template"`
		Params         json.RawMessage `json:"params"`
	}
	c.BodyParser(&req)
	h.db.Exec(c.UserContext(),
		`UPDATE ai_custom_calcs SET title=$1, description=$2, prompt_template=$3, params=$4
		 WHERE id=$5 AND tenant_id=$6 AND is_builtin=false`,
		req.Title, req.Description, req.PromptTemplate, req.Params, id, claims.TenantID,
	)
	return c.JSON(fiber.Map{"message": "Cálculo actualizado"})
}

// ─── DELETE /ai/admin/calcs/:id ───────────────────────────────────────────────

func (h *AIAdminHandler) DeleteCalc(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	h.db.Exec(c.UserContext(),
		`UPDATE ai_custom_calcs SET is_active=false WHERE id=$1 AND tenant_id=$2 AND is_builtin=false`,
		id, claims.TenantID,
	)
	return c.JSON(fiber.Map{"message": "Cálculo eliminado"})
}

// ─── POST /ai/calculate — run a calculation ────────────────────────────────────

func (h *AIAdminHandler) Calculate(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	var req struct {
		CalcID int64             `json:"calc_id"`
		Params map[string]string `json:"params"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	ctx, cancel := context.WithTimeout(c.UserContext(), 60*time.Second)
	defer cancel()

	// Get the calculation template
	var promptTemplate, title string
	err := h.db.QueryRow(c.UserContext(),
		`SELECT prompt_template, title FROM ai_custom_calcs WHERE id=$1 AND tenant_id=$2 AND is_active=true`,
		req.CalcID, claims.TenantID,
	).Scan(&promptTemplate, &title)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Cálculo no encontrado")
	}

	// Substitute the parameters into the template
	prompt := promptTemplate
	for k, v := range req.Params {
		prompt = strings.ReplaceAll(prompt, "{"+k+"}", v)
	}

	if err := h.sem.Acquire(ctx); err != nil {
		return fiber.NewError(fiber.StatusTooManyRequests, "Arché IA ocupada, intenta en unos segundos")
	}
	defer h.sem.Release()

	response, err := h.ollama.GenerateSimple(ctx, []ai.Message{
		{Role: "system", Content: `Eres un ingeniero de mantenimiento industrial experto en cálculos técnicos.
Responde SIEMPRE en este formato exacto:
RESULTADO: [valor con unidades]
FÓRMULA: [fórmula usada]
PASOS: [explicación paso a paso en 3-5 líneas]
RECOMENDACIÓN: [recomendación práctica]
No uses markdown, no uses asteriscos. Sé preciso y conciso.`},
		{Role: "user", Content: prompt},
	})
	if err != nil {
		return fiber.NewError(fiber.StatusServiceUnavailable, "Arché IA no disponible")
	}

	go func() {
		h.db.Exec(context.Background(),
			`INSERT INTO ai_usage_stats (tenant_id, user_id, model, had_sources)
			 VALUES ($1,$2,'calculation',false)`,
			claims.TenantID, claims.UserID,
		)
	}()

	return c.JSON(fiber.Map{"result": response, "title": title})
}

// ─── GET /ai/admin/log ────────────────────────────────────────────────────────

func (h *AIAdminHandler) GetLog(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	rows, err := h.db.Query(c.UserContext(),
		`SELECT l.id, l.action, l.details, u.full_name, l.created_at::text, k.title
		 FROM ai_knowledge_log l
		 LEFT JOIN users u ON u.id=l.user_id
		 LEFT JOIN ai_knowledge k ON k.id=l.knowledge_id
		 WHERE l.tenant_id=$1 ORDER BY l.created_at DESC LIMIT 100`,
		claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error")
	}
	defer rows.Close()

	type Entry struct {
		ID             int64   `json:"id"`
		Action         string  `json:"action"`
		Details        *string `json:"details"`
		UserName       *string `json:"user_name"`
		CreatedAt      string  `json:"created_at"`
		KnowledgeTitle *string `json:"knowledge_title"`
	}
	var entries []Entry
	for rows.Next() {
		var e Entry
		if rows.Scan(&e.ID, &e.Action, &e.Details, &e.UserName, &e.CreatedAt, &e.KnowledgeTitle) == nil {
			entries = append(entries, e)
		}
	}
	return c.JSON(fiber.Map{"log": entries, "total": len(entries)})
}

// ─── GET /ai/admin/stats ──────────────────────────────────────────────────────

func (h *AIAdminHandler) GetStats(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	type Stats struct {
		TotalQueries       int     `json:"total_queries"`
		TotalTokensIn      int     `json:"total_tokens_in"`
		TotalTokensOut     int     `json:"total_tokens_out"`
		AvgResponseMs      float64 `json:"avg_response_ms"`
		QueriesWithSources int     `json:"queries_with_sources"`
		IndexedChunks      int     `json:"indexed_chunks"`
		KnowledgeItems     int     `json:"knowledge_items"`
	}
	var s Stats
	h.db.QueryRow(c.UserContext(),
		`SELECT COUNT(*), COALESCE(SUM(tokens_in),0), COALESCE(SUM(tokens_out),0),
		        COALESCE(AVG(response_ms),0), COUNT(*) FILTER (WHERE had_sources=true)
		 FROM ai_usage_stats WHERE tenant_id=$1 AND created_at > NOW() - INTERVAL '30 days'`,
		claims.TenantID,
	).Scan(&s.TotalQueries, &s.TotalTokensIn, &s.TotalTokensOut, &s.AvgResponseMs, &s.QueriesWithSources)
	h.db.QueryRow(c.UserContext(),
		`SELECT COUNT(*) FROM ai_embeddings WHERE tenant_id=$1`, claims.TenantID,
	).Scan(&s.IndexedChunks)
	h.db.QueryRow(c.UserContext(),
		`SELECT COUNT(*) FROM ai_knowledge WHERE tenant_id=$1 AND is_active=true`, claims.TenantID,
	).Scan(&s.KnowledgeItems)

	userRows, _ := h.db.Query(c.UserContext(),
		`SELECT u.full_name, COUNT(*) AS queries
		 FROM ai_usage_stats s JOIN users u ON u.id=s.user_id
		 WHERE s.tenant_id=$1 AND s.created_at > NOW() - INTERVAL '30 days'
		 GROUP BY u.full_name ORDER BY queries DESC LIMIT 5`,
		claims.TenantID,
	)
	type UserStat struct {
		FullName string `json:"full_name"`
		Queries  int    `json:"queries"`
	}
	var topUsers []UserStat
	if userRows != nil {
		defer userRows.Close()
		for userRows.Next() {
			var u UserStat
			if userRows.Scan(&u.FullName, &u.Queries) == nil {
				topUsers = append(topUsers, u)
			}
		}
	}
	return c.JSON(fiber.Map{"stats": s, "top_users": topUsers})
}

// ─── POST /ai/admin/system-prompt ────────────────────────────────────────────

func (h *AIAdminHandler) SetSystemPrompt(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	var req struct{ Prompt string `json:"prompt"` }
	c.BodyParser(&req)
	h.db.Exec(c.UserContext(),
		`UPDATE tenants SET ai_system_prompt=NULLIF($1,'') WHERE id=$2`,
		req.Prompt, claims.TenantID,
	)
	return c.JSON(fiber.Map{"message": "Prompt personalizado guardado"})
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

func extractTextFromPDF(data []byte) string {
	// Basic text extraction from PDFs with embedded text
	// Looks for text streams between BT and ET
	var buf bytes.Buffer
	scanner := bufio.NewScanner(bytes.NewReader(data))
	scanner.Buffer(make([]byte, 64*1024), 64*1024)
	inText := false
	for scanner.Scan() {
		line := scanner.Text()
		if strings.Contains(line, "BT") { inText = true }
		if strings.Contains(line, "ET") { inText = false }
		if inText && strings.Contains(line, "Tj") {
			// Extract the text between parentheses
			start := strings.Index(line, "(")
			end := strings.LastIndex(line, ")")
			if start >= 0 && end > start {
				text := line[start+1 : end]
				// Decode the basic escapes
				text = strings.ReplaceAll(text, `\n`, "\n")
				text = strings.ReplaceAll(text, `\r`, " ")
				text = strings.ReplaceAll(text, `\t`, " ")
				buf.WriteString(text + " ")
			}
		}
	}

	result := buf.String()
	if len(strings.TrimSpace(result)) > 0 {
		return result
	}

	// Fallback: extract any readable ASCII text
	var fallback bytes.Buffer
	for i := 0; i < len(data)-3; i++ {
		if data[i] >= 32 && data[i] < 127 {
			fallback.WriteByte(data[i])
		} else if data[i] == '\n' || data[i] == '\r' {
			fallback.WriteByte('\n')
		}
	}
	return fallback.String()
}

func cleanText(s string) string {
	// Collapse repeated blank lines and extra whitespace
	lines := strings.Split(s, "\n")
	var clean []string
	blank := 0
	for _, line := range lines {
		trimmed := strings.TrimSpace(line)
		if trimmed == "" {
			blank++
			if blank <= 2 { clean = append(clean, "") }
		} else {
			blank = 0
			clean = append(clean, trimmed)
		}
	}
	return strings.Join(clean, "\n")
}

// ─── GET /ai/admin/folders ────────────────────────────────────────────────────

func (h *AIAdminHandler) ListFolders(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	rows, err := h.db.Query(c.UserContext(),
		`SELECT f.id, f.name, f.created_at::text, u.full_name,
		        COUNT(k.id) AS item_count
		 FROM ai_knowledge_folders f
		 LEFT JOIN users u ON u.id=f.created_by
		 LEFT JOIN ai_knowledge k ON k.tenant_id=f.tenant_id AND k.folder=f.name AND k.is_active=true
		 WHERE f.tenant_id=$1
		 GROUP BY f.id, f.name, f.created_at, u.full_name
		 ORDER BY f.name`,
		claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error")
	}
	defer rows.Close()
	type Folder struct {
		ID        int64   `json:"id"`
		Name      string  `json:"name"`
		CreatedAt string  `json:"created_at"`
		CreatedBy *string `json:"created_by"`
		ItemCount int     `json:"item_count"`
	}
	var folders []Folder
	for rows.Next() {
		var f Folder
		if rows.Scan(&f.ID, &f.Name, &f.CreatedAt, &f.CreatedBy, &f.ItemCount) == nil {
			folders = append(folders, f)
		}
	}
	return c.JSON(fiber.Map{"folders": folders})
}

// ─── POST /ai/admin/folders ───────────────────────────────────────────────────

func (h *AIAdminHandler) CreateFolder(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	var req struct{ Name string `json:"name"` }
	if err := c.BodyParser(&req); err != nil || strings.TrimSpace(req.Name) == "" {
		return fiber.NewError(fiber.StatusBadRequest, "Nombre requerido")
	}
	req.Name = strings.TrimSpace(req.Name)
	var newID int64
	err := h.db.QueryRow(c.UserContext(),
		`INSERT INTO ai_knowledge_folders (tenant_id, name, created_by)
		 VALUES ($1,$2,$3) ON CONFLICT (tenant_id, name) DO UPDATE SET name=EXCLUDED.name
		 RETURNING id`,
		claims.TenantID, req.Name, claims.UserID,
	).Scan(&newID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error creando carpeta")
	}
	h.db.Exec(c.UserContext(),
		`INSERT INTO ai_knowledge_log (tenant_id, action, user_id, details)
		 VALUES ($1,'folder_created',$2,$3)`,
		claims.TenantID, claims.UserID, req.Name,
	)
	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": newID, "name": req.Name, "message": "Carpeta creada"})
}

// ─── DELETE /ai/admin/folders/:id ─────────────────────────────────────────────

func (h *AIAdminHandler) DeleteFolder(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var name string
	h.db.QueryRow(c.UserContext(),
		`SELECT name FROM ai_knowledge_folders WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	).Scan(&name)
	if name == "General" {
		return fiber.NewError(fiber.StatusBadRequest, "La carpeta General no se puede eliminar")
	}
	// Move the knowledge to General
	h.db.Exec(c.UserContext(),
		`UPDATE ai_knowledge SET folder='General' WHERE tenant_id=$1 AND folder=$2`,
		claims.TenantID, name,
	)
	h.db.Exec(c.UserContext(),
		`DELETE FROM ai_knowledge_folders WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	)
	h.db.Exec(c.UserContext(),
		`INSERT INTO ai_knowledge_log (tenant_id, action, user_id, details)
		 VALUES ($1,'folder_deleted',$2,$3)`,
		claims.TenantID, claims.UserID, name,
	)
	return c.JSON(fiber.Map{"message": "Carpeta eliminada. El contenido se movió a General."})
}

// ─── PUT /ai/admin/folders/:id ────────────────────────────────────────────────

func (h *AIAdminHandler) RenameFolder(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var req struct{ Name string `json:"name"` }
	if err := c.BodyParser(&req); err != nil || strings.TrimSpace(req.Name) == "" {
		return fiber.NewError(fiber.StatusBadRequest, "Nombre requerido")
	}
	req.Name = strings.TrimSpace(req.Name)

	var oldName string
	h.db.QueryRow(c.UserContext(),
		`SELECT name FROM ai_knowledge_folders WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	).Scan(&oldName)

	if oldName == "General" {
		return fiber.NewError(fiber.StatusBadRequest, "La carpeta General no se puede renombrar")
	}

	// Rename the folder and update the knowledge entries
	h.db.Exec(c.UserContext(),
		`UPDATE ai_knowledge_folders SET name=$1 WHERE id=$2 AND tenant_id=$3`,
		req.Name, id, claims.TenantID,
	)
	h.db.Exec(c.UserContext(),
		`UPDATE ai_knowledge SET folder=$1 WHERE tenant_id=$2 AND folder=$3`,
		req.Name, claims.TenantID, oldName,
	)
	h.db.Exec(c.UserContext(),
		`INSERT INTO ai_knowledge_log (tenant_id, action, user_id, details)
		 VALUES ($1,'folder_renamed',$2,$3)`,
		claims.TenantID, claims.UserID,
		fmt.Sprintf("%s → %s", oldName, req.Name),
	)
	return c.JSON(fiber.Map{"message": "Carpeta renombrada"})
}
