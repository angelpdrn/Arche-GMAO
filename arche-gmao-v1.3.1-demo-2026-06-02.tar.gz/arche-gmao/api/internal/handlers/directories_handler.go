package handlers

import (
	"fmt"
	"strconv"

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
	"golang.org/x/crypto/bcrypt"
)

type DirectoriesHandler struct {
	db *pgxpool.Pool
}

func NewDirectoriesHandler(db *pgxpool.Pool) *DirectoriesHandler {
	return &DirectoriesHandler{db: db}
}

type DirectoryResponse struct {
	ID          int64               `json:"id"`
	Name        string              `json:"name"`
	Section     string              `json:"section"`
	ParentID    *int64              `json:"parent_id"`
	IsPublic    bool                `json:"is_public"`
	HasPin      bool                `json:"has_pin"`    // true when it has a PIN; we never return the hash
	IsOwner     bool                `json:"is_owner"`   // true when it belongs to the current user
	OwnerName   *string             `json:"owner_name"` // owner name (public folders)
	Description *string             `json:"description"`
	Color       *string             `json:"color"`
	Icon        *string             `json:"icon"`
	ItemCount   int                 `json:"item_count"`
	Children    []DirectoryResponse `json:"children"`
}

// ─── GET /directories?section=work_orders ────────────────────────────────────
// Returns the user's own folders plus public folders from other users in the tenant.

func (h *DirectoriesHandler) List(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	section := c.Query("section")
	if section == "" {
		return fiber.NewError(fiber.StatusBadRequest, "El parámetro 'section' es requerido")
	}

	rows, err := h.db.Query(c.UserContext(),
		`SELECT ud.id, ud.name, ud.section, ud.parent_id,
		        ud.is_public, ud.access_pin IS NOT NULL AS has_pin,
		        ud.user_id = $1 AS is_owner,
		        u.full_name,
		        ud.description, ud.color, ud.icon,
		        COUNT(di.id) AS item_count
		 FROM user_directories ud
		 JOIN users u ON u.id = ud.user_id
		 LEFT JOIN directory_items di ON di.directory_id = ud.id
		 WHERE ud.tenant_id = $2 AND ud.section = $3
		   AND (ud.user_id = $1 OR ud.is_public = true)
		 GROUP BY ud.id, u.full_name
		 ORDER BY ud.user_id = $1 DESC, ud.parent_id NULLS FIRST, ud.name`,
		claims.UserID, claims.TenantID, section,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando directorios")
	}
	defer rows.Close()

	nodeMap := make(map[int64]*DirectoryResponse)
	var allIDs []int64

	for rows.Next() {
		var d DirectoryResponse
		d.Children = []DirectoryResponse{}
		var ownerName string
		var accessPinExists bool

		if err := rows.Scan(
			&d.ID, &d.Name, &d.Section, &d.ParentID,
			&d.IsPublic, &accessPinExists, &d.IsOwner,
			&ownerName,
			&d.Description, &d.Color, &d.Icon,
			&d.ItemCount,
		); err == nil {
			d.HasPin = accessPinExists
			if !d.IsOwner {
				d.OwnerName = &ownerName
			}
			nodeMap[d.ID] = &d
			allIDs = append(allIDs, d.ID)
		}
	}

	// Build the tree, keeping own and public folders apart
	var myDirs []DirectoryResponse
	var publicDirs []DirectoryResponse

	for _, d := range nodeMap {
		if d.ParentID == nil {
			if d.IsOwner {
				myDirs = append(myDirs, *d)
			} else {
				publicDirs = append(publicDirs, *d)
			}
		} else if parent, ok := nodeMap[*d.ParentID]; ok {
			parent.Children = append(parent.Children, *d)
		}
	}

	return c.JSON(fiber.Map{
		"my_dirs":     myDirs,
		"public_dirs": publicDirs,
		"total":       len(allIDs),
	})
}

// ─── POST /directories ────────────────────────────────────────────────────────

func (h *DirectoriesHandler) Create(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req struct {
		Name        string  `json:"name"`
		Section     string  `json:"section"`
		ParentID    *int64  `json:"parent_id"`
		IsPublic    bool    `json:"is_public"`
		AccessPin   *string `json:"access_pin"` // PIN in clear text; it is hashed here
		Description *string `json:"description"`
		Color       *string `json:"color"`
		Icon        *string `json:"icon"`
	}
	if err := c.BodyParser(&req); err != nil || req.Name == "" || req.Section == "" {
		return fiber.NewError(fiber.StatusBadRequest, "Nombre y sección son requeridos")
	}

	validSections := map[string]bool{
		"work_orders": true, "spare_parts": true, "nodes": true,
		"history": true, "library": true, "personnel": true,
	}
	if !validSections[req.Section] {
		return fiber.NewError(fiber.StatusBadRequest, "Sección no válida")
	}

	// Hash the PIN when one is provided
	var pinHash *string
	if req.AccessPin != nil && *req.AccessPin != "" {
		if len(*req.AccessPin) < 4 {
			return fiber.NewError(fiber.StatusBadRequest, "El PIN debe tener al menos 4 caracteres")
		}
		hash, err := bcrypt.GenerateFromPassword([]byte(*req.AccessPin), 10)
		if err != nil {
			return fiber.NewError(fiber.StatusInternalServerError, "Error procesando el PIN")
		}
		s := string(hash)
		pinHash = &s
	}

	var newID int64
	err := h.db.QueryRow(c.UserContext(),
		`INSERT INTO user_directories
		 (tenant_id, user_id, name, section, parent_id, is_public, access_pin, description, color, icon)
		 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
		claims.TenantID, claims.UserID, req.Name, req.Section,
		req.ParentID, req.IsPublic, pinHash,
		req.Description, req.Color, req.Icon,
	).Scan(&newID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error creando directorio")
	}

	// Audit log
	h.db.Exec(c.UserContext(),
		`INSERT INTO ai_knowledge_log (tenant_id, action, user_id, details)
		 VALUES ($1,'dir_created',$2,$3)`,
		claims.TenantID, claims.UserID,
		fmt.Sprintf("Carpeta '%s' creada en sección '%s'", req.Name, req.Section),
	)
	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"id":      newID,
		"message": "Carpeta creada",
	})
}

// ─── PUT /directories/:id ─────────────────────────────────────────────────────

func (h *DirectoriesHandler) Update(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req struct {
		Name        string  `json:"name"`
		IsPublic    bool    `json:"is_public"`
		AccessPin   *string `json:"access_pin"` // "" = remove the PIN, nil = leave it unchanged
		RemovePin   bool    `json:"remove_pin"`
		Description *string `json:"description"`
		Color       *string `json:"color"`
		Icon        *string `json:"icon"`
	}
	if err := c.BodyParser(&req); err != nil || req.Name == "" {
		return fiber.NewError(fiber.StatusBadRequest, "El nombre es requerido")
	}

	// Only the owner can edit
	var isOwner bool
	err = h.db.QueryRow(c.UserContext(),
		`SELECT user_id = $1 FROM user_directories WHERE id=$2 AND tenant_id=$3`,
		claims.UserID, id, claims.TenantID,
	).Scan(&isOwner)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Carpeta no encontrada")
	}
	if !isOwner {
		return fiber.NewError(fiber.StatusForbidden, "Solo el creador puede editar esta carpeta")
	}

	// Handle the PIN
	var pinQuery string
	var pinArgs []interface{}
	baseArgs := []interface{}{req.Name, req.IsPublic, req.Description, req.Color, req.Icon, id, claims.UserID, claims.TenantID}

	if req.RemovePin {
		pinQuery = ", access_pin = NULL"
	} else if req.AccessPin != nil && *req.AccessPin != "" {
		hash, _ := bcrypt.GenerateFromPassword([]byte(*req.AccessPin), 10)
		pinQuery = fmt.Sprintf(", access_pin = $%d", len(baseArgs)+1)
		pinArgs = []interface{}{string(hash)}
	}

	args := append(baseArgs, pinArgs...)
	result, err := h.db.Exec(c.UserContext(),
		`UPDATE user_directories
		 SET name=$1, is_public=$2, description=$3, color=$4, icon=$5`+pinQuery+`
		 WHERE id=$6 AND user_id=$7 AND tenant_id=$8`,
		args...,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Carpeta no encontrada")
	}

	h.db.Exec(c.UserContext(),
		`INSERT INTO ai_knowledge_log (tenant_id, action, user_id, details)
		 VALUES ($1,'dir_updated',$2,$3)`,
		claims.TenantID, claims.UserID,
		fmt.Sprintf("Carpeta ID %d renombrada/editada a '%s'", id, req.Name),
	)
	return c.JSON(fiber.Map{"message": "Carpeta actualizada"})
}

// ─── DELETE /directories/:id ──────────────────────────────────────────────────

func (h *DirectoriesHandler) Delete(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	result, err := h.db.Exec(c.UserContext(),
		`DELETE FROM user_directories WHERE id=$1 AND user_id=$2 AND tenant_id=$3`,
		id, claims.UserID, claims.TenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Carpeta no encontrada o sin permiso")
	}

	h.db.Exec(c.UserContext(),
		`INSERT INTO ai_knowledge_log (tenant_id, action, user_id, details)
		 VALUES ($1,'dir_deleted',$2,$3)`,
		claims.TenantID, claims.UserID,
		fmt.Sprintf("Carpeta ID %d eliminada", id),
	)
	return c.JSON(fiber.Map{"message": "Carpeta eliminada"})
}

// ─── POST /directories/:id/verify-pin ────────────────────────────────────────
// The user enters the PIN to reach a protected public folder.
// Returns a folder session token (valid for 1 hour) that the frontend keeps in memory.

func (h *DirectoriesHandler) VerifyPin(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req struct {
		Pin string `json:"pin"`
	}
	if err := c.BodyParser(&req); err != nil || req.Pin == "" {
		return fiber.NewError(fiber.StatusBadRequest, "El PIN es requerido")
	}

	// Get the folder's PIN hash
	var storedHash *string
	var isPublic bool
	err = h.db.QueryRow(c.UserContext(),
		`SELECT access_pin, is_public FROM user_directories
		 WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	).Scan(&storedHash, &isPublic)

	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Carpeta no encontrada")
	}

	if storedHash == nil {
		// No PIN → open access
		return c.JSON(fiber.Map{"verified": true, "message": "Acceso libre"})
	}

	// Verify the PIN
	if err := bcrypt.CompareHashAndPassword([]byte(*storedHash), []byte(req.Pin)); err != nil {
		return fiber.NewError(fiber.StatusUnauthorized, "PIN incorrecto")
	}

	return c.JSON(fiber.Map{
		"verified":     true,
		"directory_id": id,
		"message":      "Acceso concedido",
	})
}

// ─── GET /directories/:id/items ───────────────────────────────────────────────

func (h *DirectoriesHandler) GetItems(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	// Check access (own or public)
	var section string
	var hasPin bool
	err = h.db.QueryRow(c.UserContext(),
		`SELECT section, access_pin IS NOT NULL
		 FROM user_directories
		 WHERE id=$1 AND tenant_id=$2
		   AND (user_id=$3 OR is_public=true)`,
		id, claims.TenantID, claims.UserID,
	).Scan(&section, &hasPin)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Carpeta no encontrada o sin acceso")
	}

	// If it has a PIN, the frontend already verified it before calling here
	// (honour-system check — the PIN is verified in /verify-pin)

	var query string
	switch section {
	case "work_orders":
		query = `SELECT di.id, di.item_id, wo.wo_number, wo.title,
		                wo.status, wo.priority
		         FROM directory_items di
		         JOIN work_orders wo ON wo.id=di.item_id AND wo.tenant_id=$2
		         WHERE di.directory_id=$1 ORDER BY wo.created_at DESC`
	case "spare_parts":
		query = `SELECT di.id, di.item_id, sp.code, sp.name,
		                sp.category, CAST(sp.current_stock AS TEXT)
		         FROM directory_items di
		         JOIN spare_parts sp ON sp.id=di.item_id AND sp.tenant_id=$2
		         WHERE di.directory_id=$1 ORDER BY sp.name`
	case "nodes":
		query = `SELECT di.id, di.item_id, fn.code, fn.name,
		                fn.node_type, fn.criticality
		         FROM directory_items di
		         JOIN factory_nodes fn ON fn.id=di.item_id AND fn.tenant_id=$2
		         WHERE di.directory_id=$1 ORDER BY fn.name`
	case "library":
		query = `SELECT di.id, di.item_id, a.original_name, a.original_name,
		                a.category, a.mime_type
		         FROM directory_items di
		         JOIN attachments a ON a.id=di.item_id AND a.tenant_id=$2
		         WHERE di.directory_id=$1 ORDER BY a.created_at DESC`
	case "personnel":
		query = `SELECT di.id, di.item_id, u.email, u.full_name,
		                u.role, u.status
		         FROM directory_items di
		         JOIN users u ON u.id=di.item_id AND u.tenant_id=$2
		         WHERE di.directory_id=$1 ORDER BY u.full_name`
	default:
		return c.JSON(fiber.Map{"items": []interface{}{}, "section": section})
	}

	rows, err := h.db.Query(c.UserContext(), query, id, claims.TenantID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando items")
	}
	defer rows.Close()

	type Item struct {
		ID     int64   `json:"id"`
		ItemID int64   `json:"item_id"`
		Ref    *string `json:"ref"`
		Name   string  `json:"name"`
		Status *string `json:"status"`
		Extra  *string `json:"extra"`
	}

	var items []Item
	for rows.Next() {
		var item Item
		if err := rows.Scan(&item.ID, &item.ItemID, &item.Ref, &item.Name,
			&item.Status, &item.Extra); err == nil {
			items = append(items, item)
		}
	}

	return c.JSON(fiber.Map{
		"items":   items,
		"section": section,
		"total":   len(items),
	})
}

// ─── POST /directories/:id/items ─────────────────────────────────────────────

func (h *DirectoriesHandler) AddItem(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req struct {
		ItemType string `json:"item_type"`
		ItemID   int64  `json:"item_id"`
	}
	if err := c.BodyParser(&req); err != nil || req.ItemID == 0 {
		return fiber.NewError(fiber.StatusBadRequest, "item_type e item_id son requeridos")
	}

	// Only the owner can add items (even to public folders)
	var isOwner bool
	err = h.db.QueryRow(c.UserContext(),
		`SELECT user_id=$1 FROM user_directories WHERE id=$2 AND tenant_id=$3`,
		claims.UserID, id, claims.TenantID,
	).Scan(&isOwner)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Carpeta no encontrada")
	}
	if !isOwner {
		return fiber.NewError(fiber.StatusForbidden, "Solo el creador puede añadir items a esta carpeta")
	}

	var newID int64
	err = h.db.QueryRow(c.UserContext(),
		`INSERT INTO directory_items (directory_id, item_type, item_id)
		 VALUES ($1,$2,$3) RETURNING id`,
		id, req.ItemType, req.ItemID,
	).Scan(&newID)
	if err != nil {
		return fiber.NewError(fiber.StatusConflict, "El item ya está en esta carpeta")
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": newID, "message": "Item añadido"})
}

// ─── DELETE /directories/items/:id ───────────────────────────────────────────

func (h *DirectoriesHandler) RemoveItem(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	result, err := h.db.Exec(c.UserContext(),
		`DELETE FROM directory_items
		 WHERE id=$1 AND directory_id IN (
		     SELECT id FROM user_directories WHERE user_id=$2 AND tenant_id=$3
		 )`,
		id, claims.UserID, claims.TenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Item no encontrado")
	}

	return c.JSON(fiber.Map{"message": "Item eliminado de la carpeta"})
}
