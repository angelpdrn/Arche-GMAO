package handlers

import (
	"context"
	"encoding/json"
	"strconv"
	"time"

	"arche-gmao/api/internal/ai"
	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type ProcedureHandler struct {
	db     *pgxpool.Pool
	ollama *ai.OllamaClient
}

func NewProcedureHandler(db *pgxpool.Pool, ollama *ai.OllamaClient) *ProcedureHandler {
	return &ProcedureHandler{db: db, ollama: ollama}
}

// ─── GET /procedures — list templates ────────────────────────────────────

func (h *ProcedureHandler) ListTemplates(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	category := c.Query("category")
	active := c.Query("active")

	query := `
		SELECT pt.id, pt.title, pt.description, pt.category, pt.node_type_target,
		       pt.version, pt.is_active,
		       pt.created_by, u.full_name AS created_by_name,
		       pt.created_at::text, pt.updated_at::text,
		       (SELECT COUNT(*) FROM procedure_steps ps WHERE ps.template_id = pt.id) AS step_count,
		       (SELECT COUNT(*) FROM procedure_executions pe WHERE pe.template_id = pt.id AND pe.status = 'completed') AS execution_count
		FROM procedure_templates pt
		LEFT JOIN users u ON u.id = pt.created_by
		WHERE pt.tenant_id = $1`

	args := []interface{}{claims.TenantID}
	argIdx := 2

	if active == "true" {
		query += ` AND pt.is_active = true`
	}
	if category != "" {
		query += ` AND pt.category = $` + strconv.Itoa(argIdx)
		args = append(args, category)
		argIdx++
	}
	_ = argIdx
	query += ` ORDER BY pt.title ASC`

	rows, err := h.db.Query(c.UserContext(), query, args...)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error listando procedimientos")
	}
	defer rows.Close()

	var templates []fiber.Map
	for rows.Next() {
		var id int64
		var title, category, createdAt, updatedAt string
		var description, nodeTypeTarget, createdByName *string
		var createdBy *int64
		var version int
		var isActive bool
		var stepCount, execCount int64

		if err := rows.Scan(&id, &title, &description, &category, &nodeTypeTarget,
			&version, &isActive, &createdBy, &createdByName,
			&createdAt, &updatedAt, &stepCount, &execCount); err != nil {
			continue
		}
		templates = append(templates, fiber.Map{
			"id": id, "title": title, "description": description,
			"category": category, "node_type_target": nodeTypeTarget,
			"version": version, "is_active": isActive,
			"created_by": createdBy, "created_by_name": createdByName,
			"created_at": createdAt, "updated_at": updatedAt,
			"step_count": stepCount, "execution_count": execCount,
		})
	}
	if templates == nil {
		templates = []fiber.Map{}
	}
	return c.JSON(fiber.Map{"procedures": templates, "total": len(templates)})
}

// ─── GET /procedures/:id — detail with steps ───────────────────────────────

func (h *ProcedureHandler) GetTemplate(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)

	var title, category, createdAt, updatedAt string
	var description, nodeTypeTarget *string
	var version int
	var isActive bool

	err := h.db.QueryRow(c.UserContext(), `
		SELECT title, description, category, node_type_target,
		       version, is_active, created_at::text, updated_at::text
		FROM procedure_templates WHERE id = $1 AND tenant_id = $2`,
		id, claims.TenantID).Scan(&title, &description, &category, &nodeTypeTarget,
		&version, &isActive, &createdAt, &updatedAt)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Procedimiento no encontrado")
	}

	stepRows, err := h.db.Query(c.UserContext(), `
		SELECT id, step_number, title, description, step_type, is_required,
		       config, condition, estimated_minutes
		FROM procedure_steps WHERE template_id = $1
		ORDER BY step_number ASC`, id)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error cargando pasos")
	}
	defer stepRows.Close()

	var steps []fiber.Map
	for stepRows.Next() {
		var sID int64
		var stepNum int
		var sTitle, stepType string
		var sDesc *string
		var isReq bool
		var config, cond json.RawMessage
		var estMin *int

		if err := stepRows.Scan(&sID, &stepNum, &sTitle, &sDesc, &stepType, &isReq,
			&config, &cond, &estMin); err != nil {
			continue
		}

		step := fiber.Map{
			"id": sID, "step_number": stepNum, "title": sTitle,
			"description": sDesc, "step_type": stepType,
			"is_required": isReq, "config": json.RawMessage(config),
			"estimated_minutes": estMin,
		}
		if cond != nil {
			step["condition"] = json.RawMessage(cond)
		}
		steps = append(steps, step)
	}
	if steps == nil {
		steps = []fiber.Map{}
	}

	// Links
	linkRows, err := h.db.Query(c.UserContext(), `
		SELECT ptl.id, ptl.maintenance_plan_id, mp.title,
		       ptl.node_id, fn.name, ptl.wo_type
		FROM procedure_template_links ptl
		LEFT JOIN maintenance_plans mp ON mp.id = ptl.maintenance_plan_id
		LEFT JOIN factory_nodes fn ON fn.id = ptl.node_id
		WHERE ptl.template_id = $1 AND ptl.tenant_id = $2`, id, claims.TenantID)
	var links []fiber.Map
	if err == nil {
		defer linkRows.Close()
		for linkRows.Next() {
			var lID int64
			var planID, nodeID *int64
			var planTitle, nodeName, woType *string
			if err := linkRows.Scan(&lID, &planID, &planTitle, &nodeID, &nodeName, &woType); err != nil {
				continue
			}
			links = append(links, fiber.Map{
				"id": lID, "maintenance_plan_id": planID, "plan_title": planTitle,
				"node_id": nodeID, "node_name": nodeName, "wo_type": woType,
			})
		}
	}
	if links == nil {
		links = []fiber.Map{}
	}

	return c.JSON(fiber.Map{
		"id": id, "title": title, "description": description,
		"category": category, "node_type_target": nodeTypeTarget,
		"version": version, "is_active": isActive,
		"created_at": createdAt, "updated_at": updatedAt,
		"steps": steps, "links": links,
	})
}

// ─── POST /procedures — create a template ─────────────────────────────────────

func (h *ProcedureHandler) CreateTemplate(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var body struct {
		Title          string          `json:"title"`
		Description    *string         `json:"description"`
		Category       string          `json:"category"`
		NodeTypeTarget *string         `json:"node_type_target"`
		Steps          []procedureStep `json:"steps"`
	}
	if err := c.BodyParser(&body); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Datos inválidos")
	}
	if body.Title == "" {
		return fiber.NewError(fiber.StatusBadRequest, "El título es obligatorio")
	}
	if body.Category == "" {
		body.Category = "general"
	}

	tx, err := h.db.Begin(c.UserContext())
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error iniciando transacción")
	}
	defer tx.Rollback(c.UserContext())

	var templateID int64
	err = tx.QueryRow(c.UserContext(), `
		INSERT INTO procedure_templates (tenant_id, title, description, category, node_type_target, created_by)
		VALUES ($1, $2, $3, $4, $5, $6)
		RETURNING id`, claims.TenantID, body.Title, body.Description, body.Category,
		body.NodeTypeTarget, claims.UserID).Scan(&templateID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error creando procedimiento")
	}

	for i, step := range body.Steps {
		configBytes, _ := json.Marshal(step.Config)
		var condBytes []byte
		if step.Condition != nil {
			condBytes, _ = json.Marshal(step.Condition)
		}
		_, err := tx.Exec(c.UserContext(), `
			INSERT INTO procedure_steps (template_id, step_number, title, description, step_type, is_required, config, condition, estimated_minutes)
			VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
			templateID, i+1, step.Title, step.Description, step.StepType,
			step.IsRequired, configBytes, condBytes, step.EstimatedMinutes)
		if err != nil {
			return fiber.NewError(fiber.StatusInternalServerError, "Error creando paso "+strconv.Itoa(i+1))
		}
	}

	if err := tx.Commit(c.UserContext()); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error guardando procedimiento")
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": templateID, "step_count": len(body.Steps)})
}

type procedureStep struct {
	Title            string                 `json:"title"`
	Description      *string                `json:"description"`
	StepType         string                 `json:"step_type"`
	IsRequired       bool                   `json:"is_required"`
	Config           map[string]interface{} `json:"config"`
	Condition        map[string]interface{} `json:"condition"`
	EstimatedMinutes *int                   `json:"estimated_minutes"`
}

// ─── PUT /procedures/:id — update the template and its steps ─────────────────────

func (h *ProcedureHandler) UpdateTemplate(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)

	var body struct {
		Title          string          `json:"title"`
		Description    *string         `json:"description"`
		Category       string          `json:"category"`
		NodeTypeTarget *string         `json:"node_type_target"`
		IsActive       *bool           `json:"is_active"`
		Steps          []procedureStep `json:"steps"`
	}
	if err := c.BodyParser(&body); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Datos inválidos")
	}

	tx, err := h.db.Begin(c.UserContext())
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error iniciando transacción")
	}
	defer tx.Rollback(c.UserContext())

	isActive := true
	if body.IsActive != nil {
		isActive = *body.IsActive
	}

	tag, err := tx.Exec(c.UserContext(), `
		UPDATE procedure_templates
		SET title = $1, description = $2, category = $3, node_type_target = $4,
		    is_active = $5, updated_by = $6, version = version + 1
		WHERE id = $7 AND tenant_id = $8`,
		body.Title, body.Description, body.Category, body.NodeTypeTarget,
		isActive, claims.UserID, id, claims.TenantID)
	if err != nil || tag.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Procedimiento no encontrado")
	}

	if body.Steps != nil {
		_, _ = tx.Exec(c.UserContext(), `DELETE FROM procedure_steps WHERE template_id = $1`, id)
		for i, step := range body.Steps {
			configBytes, _ := json.Marshal(step.Config)
			var condBytes []byte
			if step.Condition != nil {
				condBytes, _ = json.Marshal(step.Condition)
			}
			_, err := tx.Exec(c.UserContext(), `
				INSERT INTO procedure_steps (template_id, step_number, title, description, step_type, is_required, config, condition, estimated_minutes)
				VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
				id, i+1, step.Title, step.Description, step.StepType,
				step.IsRequired, configBytes, condBytes, step.EstimatedMinutes)
			if err != nil {
				return fiber.NewError(fiber.StatusInternalServerError, "Error actualizando paso "+strconv.Itoa(i+1))
			}
		}
	}

	if err := tx.Commit(c.UserContext()); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error guardando cambios")
	}

	return c.JSON(fiber.Map{"success": true})
}

// ─── DELETE /procedures/:id ─────────────────────────────────────────────────

func (h *ProcedureHandler) DeleteTemplate(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)

	tag, err := h.db.Exec(c.UserContext(), `
		DELETE FROM procedure_templates WHERE id = $1 AND tenant_id = $2`,
		id, claims.TenantID)
	if err != nil || tag.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Procedimiento no encontrado")
	}
	return c.JSON(fiber.Map{"success": true})
}

// ─── POST /procedures/:id/link — link to a plan or a node ────────────────────

func (h *ProcedureHandler) LinkTemplate(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	templateID, _ := strconv.ParseInt(c.Params("id"), 10, 64)

	var body struct {
		MaintenancePlanID *int64  `json:"maintenance_plan_id"`
		NodeID            *int64  `json:"node_id"`
		WOType            *string `json:"wo_type"`
	}
	if err := c.BodyParser(&body); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Datos inválidos")
	}
	if body.MaintenancePlanID == nil && body.NodeID == nil && (body.WOType == nil || *body.WOType == "") {
		return fiber.NewError(fiber.StatusBadRequest, "Debe indicar un plan de mantenimiento, un nodo o un tipo de OT")
	}

	var linkID int64
	err := h.db.QueryRow(c.UserContext(), `
		INSERT INTO procedure_template_links (tenant_id, template_id, maintenance_plan_id, node_id, wo_type)
		VALUES ($1, $2, $3, $4, $5) RETURNING id`,
		claims.TenantID, templateID, body.MaintenancePlanID, body.NodeID, body.WOType).Scan(&linkID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error vinculando procedimiento")
	}
	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": linkID})
}

// ─── DELETE /procedures/:id/link/:linkId ────────────────────────────────────

func (h *ProcedureHandler) UnlinkTemplate(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	linkID, _ := strconv.ParseInt(c.Params("linkId"), 10, 64)

	_, err := h.db.Exec(c.UserContext(), `
		DELETE FROM procedure_template_links WHERE id = $1 AND tenant_id = $2`,
		linkID, claims.TenantID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error eliminando vínculo")
	}
	return c.JSON(fiber.Map{"success": true})
}

// ─── POST /procedures/:id/execute — start an execution on a WO ────────────

func (h *ProcedureHandler) StartExecution(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	templateID, _ := strconv.ParseInt(c.Params("id"), 10, 64)

	var body struct {
		WOID   *int64 `json:"wo_id"`
		NodeID *int64 `json:"node_id"`
	}
	if err := c.BodyParser(&body); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Datos inválidos")
	}

	var version, totalSteps int
	err := h.db.QueryRow(c.UserContext(), `
		SELECT pt.version, COUNT(ps.id)
		FROM procedure_templates pt
		LEFT JOIN procedure_steps ps ON ps.template_id = pt.id
		WHERE pt.id = $1 AND pt.tenant_id = $2 AND pt.is_active = true
		GROUP BY pt.id`, templateID, claims.TenantID).Scan(&version, &totalSteps)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Procedimiento no encontrado o inactivo")
	}

	now := time.Now()
	var execID int64
	err = h.db.QueryRow(c.UserContext(), `
		INSERT INTO procedure_executions (tenant_id, template_id, template_version, wo_id, node_id, executed_by, status, total_steps, started_at)
		VALUES ($1, $2, $3, $4, $5, $6, 'in_progress', $7, $8)
		RETURNING id`,
		claims.TenantID, templateID, version, body.WOID, body.NodeID,
		claims.UserID, totalSteps, now).Scan(&execID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error iniciando ejecución")
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"execution_id": execID, "total_steps": totalSteps})
}

// ─── GET /procedures/executions/:execId — execution detail ──────────────

func (h *ProcedureHandler) GetExecution(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	execID, _ := strconv.ParseInt(c.Params("execId"), 10, 64)

	var templateID int64
	var templateVersion, totalSteps, completedSteps int
	var status, createdAt string
	var woID, nodeID, executedBy *int64
	var startedAt, completedAt, notes *string

	err := h.db.QueryRow(c.UserContext(), `
		SELECT pe.template_id, pe.template_version, pe.wo_id, pe.node_id,
		       pe.executed_by, pe.status, pe.total_steps, pe.completed_steps,
		       pe.started_at::text, pe.completed_at::text, pe.notes, pe.created_at::text
		FROM procedure_executions pe
		WHERE pe.id = $1 AND pe.tenant_id = $2`,
		execID, claims.TenantID).Scan(&templateID, &templateVersion, &woID, &nodeID,
		&executedBy, &status, &totalSteps, &completedSteps,
		&startedAt, &completedAt, &notes, &createdAt)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Ejecución no encontrada")
	}

	// Template steps
	stepRows, err := h.db.Query(c.UserContext(), `
		SELECT ps.id, ps.step_number, ps.title, ps.description, ps.step_type,
		       ps.is_required, ps.config, ps.condition, ps.estimated_minutes
		FROM procedure_steps ps
		WHERE ps.template_id = $1
		ORDER BY ps.step_number ASC`, templateID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error cargando pasos")
	}
	defer stepRows.Close()

	// Existing results
	resultMap := make(map[int64]fiber.Map)
	resRows, _ := h.db.Query(c.UserContext(), `
		SELECT psr.step_id, psr.value_text, psr.value_numeric, psr.value_bool,
		       psr.value_selection, psr.is_pass, psr.out_of_range,
		       psr.completed_by, u.full_name, psr.completed_at::text,
		       psr.skipped, psr.skip_reason, psr.notes
		FROM procedure_step_results psr
		LEFT JOIN users u ON u.id = psr.completed_by
		WHERE psr.execution_id = $1`, execID)
	if resRows != nil {
		defer resRows.Close()
		for resRows.Next() {
			var stepID int64
			var valText, valSel, skipReason, rNotes, completedByName, rCompletedAt *string
			var valNum *float64
			var valBool, isPass, outOfRange *bool
			var skipped bool
			var rCompletedBy *int64
			if err := resRows.Scan(&stepID, &valText, &valNum, &valBool,
				&valSel, &isPass, &outOfRange, &rCompletedBy, &completedByName,
				&rCompletedAt, &skipped, &skipReason, &rNotes); err != nil {
				continue
			}
			resultMap[stepID] = fiber.Map{
				"value_text": valText, "value_numeric": valNum, "value_bool": valBool,
				"value_selection": valSel, "is_pass": isPass, "out_of_range": outOfRange,
				"completed_by": rCompletedBy, "completed_by_name": completedByName,
				"completed_at": rCompletedAt, "skipped": skipped, "skip_reason": skipReason,
				"notes": rNotes,
			}
		}
	}

	var steps []fiber.Map
	for stepRows.Next() {
		var sID int64
		var stepNum int
		var sTitle, stepType string
		var sDesc *string
		var isReq bool
		var config, cond json.RawMessage
		var estMin *int

		if err := stepRows.Scan(&sID, &stepNum, &sTitle, &sDesc, &stepType, &isReq,
			&config, &cond, &estMin); err != nil {
			continue
		}
		step := fiber.Map{
			"id": sID, "step_number": stepNum, "title": sTitle,
			"description": sDesc, "step_type": stepType,
			"is_required": isReq, "config": json.RawMessage(config),
			"estimated_minutes": estMin,
		}
		if cond != nil {
			step["condition"] = json.RawMessage(cond)
		}
		if result, ok := resultMap[sID]; ok {
			step["result"] = result
		}
		steps = append(steps, step)
	}
	if steps == nil {
		steps = []fiber.Map{}
	}

	return c.JSON(fiber.Map{
		"id": execID, "template_id": templateID, "template_version": templateVersion,
		"wo_id": woID, "node_id": nodeID, "executed_by": executedBy,
		"status": status, "total_steps": totalSteps, "completed_steps": completedSteps,
		"started_at": startedAt, "completed_at": completedAt, "notes": notes,
		"created_at": createdAt, "steps": steps,
	})
}

// ─── POST /procedures/executions/:execId/steps/:stepId — record a result

func (h *ProcedureHandler) SubmitStepResult(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	execID, _ := strconv.ParseInt(c.Params("execId"), 10, 64)
	stepID, _ := strconv.ParseInt(c.Params("stepId"), 10, 64)

	var body struct {
		ValueText      *string  `json:"value_text"`
		ValueNumeric   *float64 `json:"value_numeric"`
		ValueBool      *bool    `json:"value_bool"`
		ValueSelection *string  `json:"value_selection"`
		IsPass         *bool    `json:"is_pass"`
		Skipped        bool     `json:"skipped"`
		SkipReason     *string  `json:"skip_reason"`
		Notes          *string  `json:"notes"`
	}
	if err := c.BodyParser(&body); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Datos inválidos")
	}

	// Check that the execution belongs to the tenant and is in_progress
	var execStatus string
	err := h.db.QueryRow(c.UserContext(), `
		SELECT status FROM procedure_executions WHERE id = $1 AND tenant_id = $2`,
		execID, claims.TenantID).Scan(&execStatus)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Ejecución no encontrada")
	}
	if execStatus != "in_progress" {
		return fiber.NewError(fiber.StatusBadRequest, "Esta ejecución no está en progreso")
	}

	// Get the step config to validate the range
	var stepType string
	var configRaw json.RawMessage
	var stepNumber int
	err = h.db.QueryRow(c.UserContext(), `
		SELECT step_type, config, step_number FROM procedure_steps WHERE id = $1`, stepID).Scan(&stepType, &configRaw, &stepNumber)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Paso no encontrado")
	}

	outOfRange := false
	if body.ValueNumeric != nil && (stepType == "numeric" || stepType == "meter_reading") {
		var config struct {
			Min      *float64 `json:"min"`
			Max      *float64 `json:"max"`
			AlertMin *float64 `json:"alert_min"`
			AlertMax *float64 `json:"alert_max"`
		}
		_ = json.Unmarshal(configRaw, &config)
		v := *body.ValueNumeric
		if config.AlertMin != nil && v < *config.AlertMin {
			outOfRange = true
		}
		if config.AlertMax != nil && v > *config.AlertMax {
			outOfRange = true
		}
	}

	now := time.Now()
	_, err = h.db.Exec(c.UserContext(), `
		INSERT INTO procedure_step_results (execution_id, step_id, step_number, value_text, value_numeric, value_bool, value_selection, is_pass, out_of_range, completed_by, completed_at, skipped, skip_reason, notes)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
		ON CONFLICT (execution_id, step_id)
		DO UPDATE SET value_text = $4, value_numeric = $5, value_bool = $6, value_selection = $7,
		             is_pass = $8, out_of_range = $9, completed_by = $10, completed_at = $11,
		             skipped = $12, skip_reason = $13, notes = $14`,
		execID, stepID, stepNumber, body.ValueText, body.ValueNumeric, body.ValueBool,
		body.ValueSelection, body.IsPass, outOfRange, claims.UserID, now,
		body.Skipped, body.SkipReason, body.Notes)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error registrando resultado")
	}

	// Update completed_steps
	var completed int
	h.db.QueryRow(c.UserContext(), `
		SELECT COUNT(*) FROM procedure_step_results WHERE execution_id = $1 AND skipped = false`,
		execID).Scan(&completed)
	h.db.Exec(c.UserContext(), `
		UPDATE procedure_executions SET completed_steps = $1 WHERE id = $2`, completed, execID)

	return c.JSON(fiber.Map{"success": true, "out_of_range": outOfRange, "completed_steps": completed})
}

// ─── POST /procedures/executions/:execId/complete — finish the execution ─────

func (h *ProcedureHandler) CompleteExecution(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	execID, _ := strconv.ParseInt(c.Params("execId"), 10, 64)

	var body struct {
		Notes *string `json:"notes"`
	}
	_ = c.BodyParser(&body)

	now := time.Now()
	tag, err := h.db.Exec(c.UserContext(), `
		UPDATE procedure_executions
		SET status = 'completed', completed_at = $1, notes = $2,
		    completed_steps = (SELECT COUNT(*) FROM procedure_step_results WHERE execution_id = $3 AND skipped = false)
		WHERE id = $3 AND tenant_id = $4 AND status = 'in_progress'`,
		now, body.Notes, execID, claims.TenantID)
	if err != nil || tag.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusBadRequest, "No se pudo completar la ejecución")
	}

	return c.JSON(fiber.Map{"success": true, "completed_at": now.Format(time.RFC3339)})
}

// ─── GET /work-orders/:woId/procedures — procedures for a WO ───────────

func (h *ProcedureHandler) GetWOProcedures(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	woID, _ := strconv.ParseInt(c.Params("woId"), 10, 64)

	rows, err := h.db.Query(c.UserContext(), `
		SELECT pe.id, pe.template_id, pt.title, pe.template_version,
		       pe.status, pe.total_steps, pe.completed_steps,
		       pe.started_at::text, pe.completed_at::text,
		       pe.executed_by, u.full_name
		FROM procedure_executions pe
		JOIN procedure_templates pt ON pt.id = pe.template_id
		LEFT JOIN users u ON u.id = pe.executed_by
		WHERE pe.wo_id = $1 AND pe.tenant_id = $2
		ORDER BY pe.created_at ASC`, woID, claims.TenantID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error cargando procedimientos de OT")
	}
	defer rows.Close()

	var procedures []fiber.Map
	for rows.Next() {
		var peID, templateID int64
		var title, status string
		var templateVersion, totalSteps, completedSteps int
		var startedAt, completedAt, executedByName *string
		var executedBy *int64

		if err := rows.Scan(&peID, &templateID, &title, &templateVersion,
			&status, &totalSteps, &completedSteps,
			&startedAt, &completedAt, &executedBy, &executedByName); err != nil {
			continue
		}
		procedures = append(procedures, fiber.Map{
			"id": peID, "template_id": templateID, "title": title,
			"template_version": templateVersion, "status": status,
			"total_steps": totalSteps, "completed_steps": completedSteps,
			"started_at": startedAt, "completed_at": completedAt,
			"executed_by": executedBy, "executed_by_name": executedByName,
		})
	}
	if procedures == nil {
		procedures = []fiber.Map{}
	}
	return c.JSON(fiber.Map{"procedures": procedures})
}

// ─── GET /procedures/suggest?node_id=X&wo_type=Y — AI suggests an SOP ──────────

func (h *ProcedureHandler) SuggestForWO(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID := c.Query("node_id")
	woType := c.Query("wo_type")

	query := `
		SELECT DISTINCT pt.id, pt.title, pt.category,
		       (SELECT COUNT(*) FROM procedure_steps ps WHERE ps.template_id = pt.id) AS step_count
		FROM procedure_templates pt
		LEFT JOIN procedure_template_links ptl ON ptl.template_id = pt.id
		LEFT JOIN factory_nodes fn ON fn.id = ptl.node_id
		WHERE pt.tenant_id = $1 AND pt.is_active = true AND (
			ptl.node_id::text = $2
			OR (pt.node_type_target IS NOT NULL AND pt.node_type_target = (
				SELECT node_type FROM factory_nodes WHERE id = $2::bigint AND tenant_id = $1
			))
			OR ptl.wo_type = $3
		)
		ORDER BY pt.title ASC
		LIMIT 10`

	rows, err := h.db.Query(c.UserContext(), query, claims.TenantID, nodeID, woType)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error buscando procedimientos")
	}
	defer rows.Close()

	var suggestions []fiber.Map
	for rows.Next() {
		var id int64
		var title, category string
		var stepCount int
		if err := rows.Scan(&id, &title, &category, &stepCount); err != nil {
			continue
		}
		suggestions = append(suggestions, fiber.Map{
			"id": id, "title": title, "category": category, "step_count": stepCount,
		})
	}
	if suggestions == nil {
		suggestions = []fiber.Map{}
	}
	return c.JSON(fiber.Map{"suggestions": suggestions})
}

// ─── POST /procedures/generate — generate a procedure with AI ──────────────

func (h *ProcedureHandler) GenerateWithAI(c *fiber.Ctx) error {
	if h.ollama == nil {
		return fiber.NewError(fiber.StatusServiceUnavailable, "IA no disponible")
	}

	var body struct {
		Prompt string `json:"prompt"`
		NodeID *int64 `json:"node_id"`
	}
	if err := c.BodyParser(&body); err != nil || body.Prompt == "" {
		return fiber.NewError(fiber.StatusBadRequest, "Debe indicar una descripción del procedimiento")
	}

	claims := c.Locals("claims").(*types.Claims)

	nodeContext := ""
	if body.NodeID != nil {
		var nodeName, nodeType string
		err := h.db.QueryRow(c.UserContext(), `
			SELECT name, node_type FROM factory_nodes WHERE id = $1 AND tenant_id = $2`,
			*body.NodeID, claims.TenantID).Scan(&nodeName, &nodeType)
		if err == nil {
			nodeContext = "\nEquipo de referencia: " + nodeName + " (tipo: " + nodeType + ")"
		}
	}

	systemPrompt := `Eres un ingeniero de mantenimiento industrial con 20 años de experiencia en planta. Tu trabajo es crear procedimientos operativos estándar (SOP) para técnicos de mantenimiento.

INSTRUCCIONES CRÍTICAS:
- Responde ÚNICAMENTE con un JSON válido. Sin texto antes ni después del JSON.
- Los procedimientos deben ser prácticos, claros y seguros.
- Cada paso debe ser una acción concreta que un técnico pueda ejecutar.
- Incluye siempre un paso de seguridad al inicio (EPIs, bloqueo/etiquetado si aplica).
- Incluye verificaciones numéricas con rangos reales cuando sea relevante.
- Incluye un paso final de verificación general (passfail).
- Usa español para todo el contenido.
- Genera entre 5 y 15 pasos según la complejidad.

FORMATO JSON:
{"title":"string","description":"string","category":"general|inspection|preventive|corrective|safety|commissioning","steps":[{"step_number":1,"title":"string","description":"string o null","step_type":"checkbox|numeric|text|selection|passfail|meter_reading","is_required":true,"config":{}}]}

CONFIGS POR TIPO:
- checkbox: {}
- numeric: {"unit":"°C","min":0,"max":120,"alert_min":20,"alert_max":100}
- meter_reading: {"unit":"bar","min":0,"max":10,"alert_min":2,"alert_max":8}
- selection: {"options":["Bueno","Regular","Malo"]}
- passfail: {"fail_action":"warn"}
- text: {"max_length":500}`

	messages := []ai.Message{
		{Role: "system", Content: systemPrompt},
		{Role: "user", Content: body.Prompt + nodeContext},
	}

	ctx, cancel := context.WithTimeout(context.Background(), 120*time.Second)
	defer cancel()

	result, err := h.ollama.GenerateForProcedure(ctx, messages)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error generando con IA: "+err.Error())
	}

	// Extract the JSON from the result
	jsonStart := -1
	jsonEnd := -1
	depth := 0
	for i, ch := range result {
		if ch == '{' {
			if jsonStart == -1 {
				jsonStart = i
			}
			depth++
		} else if ch == '}' {
			depth--
			if depth == 0 {
				jsonEnd = i + 1
				break
			}
		}
	}

	if jsonStart == -1 || jsonEnd == -1 {
		snippet := result
		if len(snippet) > 300 {
			snippet = snippet[:300]
		}
		return fiber.NewError(fiber.StatusInternalServerError, "La IA no generó JSON válido. Respuesta: "+snippet)
	}

	jsonStr := result[jsonStart:jsonEnd]
	var parsed map[string]interface{}
	if err := json.Unmarshal([]byte(jsonStr), &parsed); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "JSON generado no es válido: "+err.Error())
	}

	return c.JSON(parsed)
}
