package handlers

import (
	"bytes"
	"fmt"
	"html"
	"strconv"
	"time"

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/xuri/excelize/v2"
)

type ReportsHandler struct {
	db *pgxpool.Pool
}

func NewReportsHandler(db *pgxpool.Pool) *ReportsHandler {
	return &ReportsHandler{db: db}
}

type WOComment struct{ Author, Content, Date string }
type WOPart struct {
	Name, Code, Unit string
	Quantity         float64
	UnitCost         *float64
}

// ─── GET /reports/wo/:id/html — full server-side report ─────────────────

func (h *ReportsHandler) WorkOrderHTML(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var (
		woNumber, title, woType, priority, status, nodeName, createdAt string
		nodeCode, assignedName, createdByName, rootCause, solution, description *string
		estHours, actualHours *float64
		plannedStart, plannedEnd, startedAt, completedAt *string
	)

	err = h.db.QueryRow(c.UserContext(), `
		SELECT wo.wo_number, wo.title, wo.description, wo.wo_type, wo.priority, wo.status,
		       fn.name, fn.code, ua.full_name, uc.full_name,
		       wo.estimated_hours, wo.actual_hours,
		       wo.planned_start::text, wo.planned_end::text,
		       wo.started_at::text, wo.completed_at::text,
		       wo.root_cause, wo.solution, wo.created_at::text
		FROM work_orders wo
		JOIN factory_nodes fn ON fn.id=wo.node_id
		LEFT JOIN users ua ON ua.id=wo.assigned_to
		LEFT JOIN users uc ON uc.id=wo.created_by
		WHERE wo.id=$1 AND wo.tenant_id=$2`,
		id, claims.TenantID,
	).Scan(
		&woNumber, &title, &description, &woType, &priority, &status,
		&nodeName, &nodeCode, &assignedName, &createdByName,
		&estHours, &actualHours, &plannedStart, &plannedEnd,
		&startedAt, &completedAt, &rootCause, &solution, &createdAt,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "OT no encontrada")
	}

	// Comments
	commentRows, _ := h.db.Query(c.UserContext(),
		`SELECT COALESCE(u.full_name,'Sistema'), wc.content, wc.created_at::text
		 FROM work_order_comments wc LEFT JOIN users u ON u.id=wc.user_id
		 WHERE wc.wo_id=$1 AND wc.tenant_id=$2 ORDER BY wc.created_at`, id, claims.TenantID,
	)
	var comments []WOComment
	if commentRows != nil {
		defer commentRows.Close()
		for commentRows.Next() {
			var cm WOComment
			if commentRows.Scan(&cm.Author, &cm.Content, &cm.Date) == nil {
				comments = append(comments, cm)
			}
		}
	}

	// Spare parts
	partRows, _ := h.db.Query(c.UserContext(),
		`SELECT sp.name, sp.code, wop.quantity, sp.unit, sp.unit_price
		 FROM work_order_parts wop JOIN spare_parts sp ON sp.id=wop.spare_part_id
		 WHERE wop.wo_id=$1 AND sp.tenant_id=$2`, id, claims.TenantID,
	)
	var parts []WOPart
	if partRows != nil {
		defer partRows.Close()
		for partRows.Next() {
			var p WOPart
			if partRows.Scan(&p.Name, &p.Code, &p.Quantity, &p.Unit, &p.UnitCost) == nil {
				parts = append(parts, p)
			}
		}
	}

	// Signatures
	var signedByName, supSignedByName *string
	var signedAt, supSignedAt *string
	h.db.QueryRow(c.UserContext(),
		`SELECT u1.full_name, wo.signed_at::text, u2.full_name, wo.supervisor_signed_at::text
		 FROM work_orders wo
		 LEFT JOIN users u1 ON u1.id=wo.signed_by
		 LEFT JOIN users u2 ON u2.id=wo.supervisor_signed_by
		 WHERE wo.id=$1 AND wo.tenant_id=$2`, id, claims.TenantID,
	).Scan(&signedByName, &signedAt, &supSignedByName, &supSignedAt)

	// Work intervals
	var intervals []ReportInterval
	ivRows, _ := h.db.Query(c.UserContext(),
		`SELECT started_at::text, ended_at::text, ended_reason,
		        EXTRACT(EPOCH FROM (COALESCE(ended_at, NOW()) - started_at)) / 60 AS duration
		 FROM work_order_intervals
		 WHERE wo_id = $1 AND tenant_id = $2
		 ORDER BY started_at ASC`, id, claims.TenantID)
	if ivRows != nil {
		defer ivRows.Close()
		for ivRows.Next() {
			var iv ReportInterval
			if ivRows.Scan(&iv.StartedAt, &iv.EndedAt, &iv.EndedReason, &iv.DurationMinutes) == nil {
				intervals = append(intervals, iv)
			}
		}
	}

	now := time.Now().Format("02/01/2006 15:04")
	htmlOut := buildWOHTML(woNumber, title, woType, priority, status, nodeName,
		nodeCode, assignedName, createdByName, rootCause, solution, description,
		estHours, actualHours, plannedStart, completedAt,
		signedByName, signedAt, supSignedByName, supSignedAt,
		comments, parts, intervals, now)

	c.Set("Content-Type", "text/html; charset=utf-8")
	return c.SendString(htmlOut)
}

func sp(v *string) string {
	if v == nil { return "—" }
	return *v
}
func spSafe(v *string) string {
	if v == nil { return "—" }
	return html.EscapeString(*v)
}
func sf(v *float64) string {
	if v == nil { return "—" }
	return fmt.Sprintf("%.1f", *v)
}
func sd(v *string) string {
	if v == nil { return "—" }
	s := *v
	if len(s) >= 16 { return s[:16] }
	return s
}

type ReportInterval struct {
	StartedAt       string
	EndedAt         *string
	EndedReason     *string
	DurationMinutes float64
}

func buildWOHTML(
	woNumber, title, woType, priority, status, nodeName string,
	nodeCode, assignedName, createdByName, rootCause, solution, description *string,
	estHours, actualHours *float64,
	plannedStart, completedAt *string,
	signedByName, signedAt, supSignedByName, supSignedAt *string,
	comments []WOComment,
	parts []WOPart,
	intervals []ReportInterval,
	now string,
) string {
	// Build the comment rows (escape user content)
	commentsHTML := "<p style='color:#888'>Sin comentarios</p>"
	if len(comments) > 0 {
		commentsHTML = ""
		for _, cm := range comments {
			date := cm.Date
			if len(date) >= 16 { date = date[:16] }
			commentsHTML += fmt.Sprintf(
				`<div class="comment"><div class="comment-meta">%s — %s</div><div>%s</div></div>`,
				html.EscapeString(cm.Author), html.EscapeString(date), html.EscapeString(cm.Content),
			)
		}
	}

	// Build the spare part rows
	partsHTML := `<tr><td colspan="4" style="text-align:center;color:#888">Sin repuestos registrados</td></tr>`
	if len(parts) > 0 {
		partsHTML = ""
		for _, p := range parts {
			cost := "—"
			if p.UnitCost != nil { cost = fmt.Sprintf("%.2f €", *p.UnitCost) }
			partsHTML += fmt.Sprintf(
				`<tr><td>%s</td><td class="mono">%s</td><td>%.1f %s</td><td>%s</td></tr>`,
				html.EscapeString(p.Name), html.EscapeString(p.Code), p.Quantity, html.EscapeString(p.Unit), cost,
			)
		}
	}

	// Build the work interval rows
	intervalsHTML := `<tr><td colspan="4" style="text-align:center;color:#888">Sin registro de trabajo</td></tr>`
	var totalWorkedMins float64
	if len(intervals) > 0 {
		intervalsHTML = ""
		for _, iv := range intervals {
			totalWorkedMins += iv.DurationMinutes
			start := iv.StartedAt
			if len(start) >= 19 { start = start[:19] }
			end := "En curso..."
			if iv.EndedAt != nil {
				end = *iv.EndedAt
				if len(end) >= 19 { end = end[:19] }
			}
			reason := "—"
			if iv.EndedReason != nil {
				switch *iv.EndedReason {
				case "paused":
					reason = "Pausado"
				case "completed":
					reason = "Completado"
				}
			}
			h := int(iv.DurationMinutes) / 60
			m := int(iv.DurationMinutes) % 60
			dur := fmt.Sprintf("%dh %dmin", h, m)
			if h == 0 { dur = fmt.Sprintf("%dmin", m) }
			intervalsHTML += fmt.Sprintf(
				`<tr><td class="mono">%s</td><td class="mono">%s</td><td class="mono">%s</td><td>%s</td></tr>`,
				html.EscapeString(start), html.EscapeString(end), dur, reason,
			)
		}
	}
	totalH := int(totalWorkedMins) / 60
	totalM := int(totalWorkedMins) % 60
	totalWorkedStr := fmt.Sprintf("%dh %dmin", totalH, totalM)
	if totalH == 0 && totalM == 0 { totalWorkedStr = "—" }

	// Technician signature
	firmaHTML := `<div class="signature-box"></div><p style="font-size:10px;color:#888;margin-top:4px">Sin firma</p>`
	if signedByName != nil {
		date := ""
		if signedAt != nil && len(*signedAt) >= 16 { date = (*signedAt)[:16] }
		firmaHTML = fmt.Sprintf(
			`<div class="signature-box signed">✓ Firmado digitalmente</div>
			 <p style="font-size:10px;color:#27AE60;margin-top:4px">%s — %s</p>`,
			html.EscapeString(*signedByName), html.EscapeString(date),
		)
	}

	// Supervisor signature
	supFirmaHTML := `<div class="signature-box"></div><p style="font-size:10px;color:#888;margin-top:4px">Sin firma</p>`
	if supSignedByName != nil {
		date := ""
		if supSignedAt != nil && len(*supSignedAt) >= 16 { date = (*supSignedAt)[:16] }
		supFirmaHTML = fmt.Sprintf(
			`<div class="signature-box signed">✓ Firmado digitalmente</div>
			 <p style="font-size:10px;color:#27AE60;margin-top:4px">%s — %s</p>`,
			html.EscapeString(*supSignedByName), html.EscapeString(date),
		)
	}

	nodeDisplay := html.EscapeString(nodeName)
	if nodeCode != nil { nodeDisplay += " (" + html.EscapeString(*nodeCode) + ")" }

	descHTML := "—"
	if description != nil { descHTML = html.EscapeString(*description) }
	rootHTML := "—"
	if rootCause != nil { rootHTML = html.EscapeString(*rootCause) }
	solHTML := "—"
	if solution != nil { solHTML = html.EscapeString(*solution) }

	typeLabels := map[string]string{
		"corrective": "Correctiva", "preventive": "Preventiva",
		"inspection": "Inspección", "predictive": "Predictiva",
	}
	prioLabels := map[string]string{
		"low": "Baja", "medium": "Media", "high": "Alta", "critical": "Crítica",
	}
	statusLabels := map[string]string{
		"pending": "Pendiente", "assigned": "Asignada", "in_progress": "En progreso",
		"completed": "Completada", "verified": "Verificada", "closed": "Cerrada",
	}

	typeLabel := typeLabels[woType]
	prioLabel := prioLabels[priority]
	statusLabel := statusLabels[status]
	if typeLabel == "" { typeLabel = woType }
	if prioLabel == "" { prioLabel = priority }
	if statusLabel == "" { statusLabel = status }

	return fmt.Sprintf(`<!DOCTYPE html>
<html lang="es"><head><meta charset="UTF-8"><title>Informe %s</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',Arial,sans-serif;font-size:12px;color:#1a1a2e;background:#fff}
.page{max-width:800px;margin:0 auto;padding:40px}
.header{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #0f3460;padding-bottom:20px;margin-bottom:30px}
.logo{font-size:24px;font-weight:900;letter-spacing:4px;color:#0f3460}
.logo-sub{font-size:10px;color:#888;letter-spacing:2px}
.wo-number{font-family:monospace;font-size:20px;font-weight:700;color:#0f3460;text-align:right}
.wo-date{font-size:10px;color:#888;text-align:right}
h1{font-size:18px;font-weight:700;color:#0f3460;margin-bottom:8px}
.badges{display:flex;gap:8px;margin-bottom:24px;flex-wrap:wrap}
.badge{padding:3px 10px;border-radius:20px;font-size:11px;font-weight:600;border:1px solid}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:24px;background:#f8f9fa;padding:16px;border-radius:8px}
.field label{font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#888;display:block;margin-bottom:3px}
.field span{font-size:12px;color:#1a1a2e;font-weight:500}
.section{margin-bottom:20px}
.section-title{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#888;border-bottom:1px solid #e5e7eb;padding-bottom:6px;margin-bottom:12px}
.text-block{background:#f8f9fa;border-left:3px solid #0f3460;padding:12px;border-radius:4px;line-height:1.6;font-size:12px}
.comment{padding:8px 12px;border-bottom:1px solid #f0f0f0}
.comment-meta{font-size:10px;color:#888;margin-bottom:4px}
table{width:100%%;border-collapse:collapse;font-size:11px}
th{background:#0f3460;color:#fff;padding:6px 10px;text-align:left;font-size:10px;font-weight:600;text-transform:uppercase}
td{padding:6px 10px;border-bottom:1px solid #f0f0f0}
tr:nth-child(even) td{background:#f8f9fa}
.footer{margin-top:40px;padding-top:16px;border-top:1px solid #e5e7eb;display:flex;justify-content:space-between}
.signature-box{border:1px solid #ccc;height:50px;width:180px;margin-top:8px;display:flex;align-items:center;justify-content:center;font-size:11px;color:#888}
.signature-box.signed{border-color:#27AE60;background:rgba(39,174,96,0.05);color:#27AE60;font-weight:600}
.mono{font-family:monospace}
@media print{body{-webkit-print-color-adjust:exact}.page{padding:20px}}
</style>
</head><body>
<div class="page">
  <div class="header">
    <div><div class="logo">ARCHE</div><div class="logo-sub">SYSTEM · INFORME DE MANTENIMIENTO</div></div>
    <div><div class="wo-number">%s</div><div class="wo-date">Generado: %s</div></div>
  </div>
  <h1>%s</h1>
  <div class="badges">
    <span class="badge" style="color:#555;border-color:#ccc">%s</span>
    <span class="badge" style="color:#3b82f6;border-color:#3b82f6">%s</span>
    <span class="badge" style="color:#e94560;border-color:#e94560">%s</span>
  </div>
  <div class="grid">
    <div class="field"><label>Equipo</label><span>%s</span></div>
    <div class="field"><label>Asignado a</label><span>%s</span></div>
    <div class="field"><label>Creado por</label><span>%s</span></div>
    <div class="field"><label>Horas estimadas</label><span>%s</span></div>
    <div class="field"><label>Horas reales</label><span>%s</span></div>
    <div class="field"><label>Inicio planif.</label><span>%s</span></div>
    <div class="field"><label>Completada</label><span>%s</span></div>
  </div>
  <div class="section"><div class="section-title">Descripción</div><div class="text-block">%s</div></div>
  <div class="section"><div class="section-title">Causa raíz identificada</div><div class="text-block">%s</div></div>
  <div class="section"><div class="section-title">Solución aplicada</div><div class="text-block">%s</div></div>
  <div class="section"><div class="section-title">Registro de trabajo</div>
    <table><thead><tr><th>Inicio</th><th>Fin</th><th>Duración</th><th>Motivo</th></tr></thead>
    <tbody>%s</tbody></table>
    <div style="margin-top:6px;font-weight:700;font-size:12px">Tiempo total trabajado: %s</div>
  </div>
  <div class="section"><div class="section-title">Repuestos utilizados</div>
    <table><thead><tr><th>Repuesto</th><th>Código</th><th>Cantidad</th><th>Coste unit.</th></tr></thead>
    <tbody>%s</tbody></table>
  </div>
  <div class="section"><div class="section-title">Notas del técnico</div>%s</div>
  <div class="footer">
    <div><div>Firma técnico responsable</div>%s</div>
    <div><div>Firma supervisor</div>%s</div>
    <div style="text-align:right"><div>Arche GMAO</div><div style="font-size:10px;color:#888">%s</div></div>
  </div>
</div>
</body></html>`,
		html.EscapeString(woNumber), html.EscapeString(woNumber), now,
		html.EscapeString(title),
		html.EscapeString(statusLabel), html.EscapeString(typeLabel), html.EscapeString(prioLabel),
		nodeDisplay, spSafe(assignedName), spSafe(createdByName),
		sf(estHours), sf(actualHours), sd(plannedStart), sd(completedAt),
		descHTML, rootHTML, solHTML,
		intervalsHTML, totalWorkedStr,
		partsHTML, commentsHTML,
		firmaHTML, supFirmaHTML,
		now,
	)
}

// ─── GET /reports/wo/:id/data — JSON data ────────────────────────────────────

func (h *ReportsHandler) WorkOrderData(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var woNumber, title, woType, priority, status, nodeName, createdAt string
	var nodeCode, assignedName, createdByName, rootCause, solution, description *string
	var estHours, actualHours *float64
	var plannedStart, plannedEnd, startedAt, completedAt *string

	err = h.db.QueryRow(c.UserContext(), `
		SELECT wo.wo_number, wo.title, wo.description, wo.wo_type, wo.priority, wo.status,
		       fn.name, fn.code, ua.full_name, uc.full_name,
		       wo.estimated_hours, wo.actual_hours,
		       wo.planned_start::text, wo.planned_end::text,
		       wo.started_at::text, wo.completed_at::text,
		       wo.root_cause, wo.solution, wo.created_at::text
		FROM work_orders wo
		JOIN factory_nodes fn ON fn.id=wo.node_id
		LEFT JOIN users ua ON ua.id=wo.assigned_to
		LEFT JOIN users uc ON uc.id=wo.created_by
		WHERE wo.id=$1 AND wo.tenant_id=$2`,
		id, claims.TenantID,
	).Scan(
		&woNumber, &title, &description, &woType, &priority, &status,
		&nodeName, &nodeCode, &assignedName, &createdByName,
		&estHours, &actualHours, &plannedStart, &plannedEnd,
		&startedAt, &completedAt, &rootCause, &solution, &createdAt,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "OT no encontrada")
	}

	commentRows, _ := h.db.Query(c.UserContext(),
		`SELECT COALESCE(u.full_name,'Sistema'), wc.content, wc.created_at::text
		 FROM work_order_comments wc LEFT JOIN users u ON u.id=wc.user_id
		 WHERE wc.wo_id=$1 AND wc.tenant_id=$2 ORDER BY wc.created_at`, id, claims.TenantID,
	)
	type CM struct {
		Author  string `json:"author"`
		Content string `json:"content"`
		Date    string `json:"date"`
	}
	var comments []WOComment
	if commentRows != nil {
		defer commentRows.Close()
		for commentRows.Next() {
			var cm WOComment
			if commentRows.Scan(&cm.Author, &cm.Content, &cm.Date) == nil {
				comments = append(comments, cm)
			}
		}
	}

	partRows, _ := h.db.Query(c.UserContext(),
		`SELECT sp.name, sp.code, wop.quantity, sp.unit, sp.unit_price
		 FROM work_order_parts wop JOIN spare_parts sp ON sp.id=wop.spare_part_id
		 WHERE wop.wo_id=$1 AND sp.tenant_id=$2`, id, claims.TenantID,
	)
	type Part struct {
		Name     string   `json:"name"`
		Code     string   `json:"code"`
		Quantity float64  `json:"quantity"`
		Unit     string   `json:"unit"`
		UnitCost *float64 `json:"unit_cost"`
	}
	var parts []WOPart
	if partRows != nil {
		defer partRows.Close()
		for partRows.Next() {
			var p WOPart
			if partRows.Scan(&p.Name, &p.Code, &p.Quantity, &p.Unit, &p.UnitCost) == nil {
				parts = append(parts, p)
			}
		}
	}

	// Work intervals
	type Interval struct {
		StartedAt       string  `json:"started_at"`
		EndedAt         *string `json:"ended_at"`
		EndedReason     *string `json:"ended_reason"`
		DurationMinutes float64 `json:"duration_minutes"`
	}
	var intervals []Interval
	ivRows, _ := h.db.Query(c.UserContext(),
		`SELECT started_at::text, ended_at::text, ended_reason,
		        EXTRACT(EPOCH FROM (COALESCE(ended_at, NOW()) - started_at)) / 60 AS duration
		 FROM work_order_intervals
		 WHERE wo_id = $1 AND tenant_id = $2
		 ORDER BY started_at ASC`, id, claims.TenantID)
	if ivRows != nil {
		defer ivRows.Close()
		for ivRows.Next() {
			var iv Interval
			if ivRows.Scan(&iv.StartedAt, &iv.EndedAt, &iv.EndedReason, &iv.DurationMinutes) == nil {
				intervals = append(intervals, iv)
			}
		}
	}
	var totalWorkedMinutes float64
	for _, iv := range intervals {
		totalWorkedMinutes += iv.DurationMinutes
	}

	return c.JSON(fiber.Map{
		"wo_number":       woNumber,
		"title":           title,
		"description":     description,
		"wo_type":         woType,
		"priority":        priority,
		"status":          status,
		"node_name":       nodeName,
		"node_code":       nodeCode,
		"assigned_name":   assignedName,
		"created_by_name": createdByName,
		"estimated_hours": estHours,
		"actual_hours":    actualHours,
		"planned_start":   plannedStart,
		"planned_end":     plannedEnd,
		"started_at":      startedAt,
		"completed_at":    completedAt,
		"root_cause":      rootCause,
		"solution":        solution,
		"created_at":      createdAt,
		"comments":        comments,
		"parts":           parts,
		"intervals":       intervals,
		"total_worked_minutes": totalWorkedMinutes,
	})
}

// ─── GET /reports/spare-parts/excel ──────────────────────────────────────────

func (h *ReportsHandler) SparePartsExcel(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	rows, err := h.db.Query(c.UserContext(), `
		SELECT sp.code, sp.name, sp.category, sp.unit,
		       sp.current_stock, sp.min_stock, sp.max_stock,
		       sp.location, sp.supplier, sp.unit_price, sp.lead_days,
		       (sp.current_stock <= sp.min_stock) AS low_stock
		FROM spare_parts sp
		WHERE sp.tenant_id=$1 AND sp.is_active=true
		ORDER BY sp.category, sp.name`, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando repuestos")
	}
	defer rows.Close()

	f := excelize.NewFile()
	defer f.Close()
	sheet := "Inventario"
	f.SetSheetName("Sheet1", sheet)

	headerStyle, _ := f.NewStyle(&excelize.Style{
		Fill: excelize.Fill{Type: "pattern", Color: []string{"0F3460"}, Pattern: 1},
		Font: &excelize.Font{Color: "FFFFFF", Bold: true, Size: 11},
		Alignment: &excelize.Alignment{Horizontal: "center"},
	})
	lowStockStyle, _ := f.NewStyle(&excelize.Style{
		Fill: excelize.Fill{Type: "pattern", Color: []string{"FEF3F2"}, Pattern: 1},
		Font: &excelize.Font{Color: "E94560"},
	})

	headers := []string{"Código", "Nombre", "Categoría", "Unidad", "Stock actual",
		"Stock mínimo", "Stock máximo", "Ubicación", "Proveedor", "Precio unit. (€)", "Plazo (días)", "Estado"}
	for i, h2 := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1)
		f.SetCellValue(sheet, cell, h2)
		f.SetCellStyle(sheet, cell, cell, headerStyle)
	}

	row := 2
	for rows.Next() {
		var code, name, category, unit string
		var currentStock, minStock float64
		var maxStock *float64
		var location, supplier *string
		var unitPrice *float64
		var leadDays *int
		var lowStock bool

		if err := rows.Scan(&code, &name, &category, &unit,
			&currentStock, &minStock, &maxStock,
			&location, &supplier, &unitPrice, &leadDays, &lowStock); err != nil {
			continue
		}

		maxStockStr := "—"
		if maxStock != nil { maxStockStr = fmt.Sprintf("%.1f", *maxStock) }
		locationStr := "—"
		if location != nil { locationStr = *location }
		supplierStr := "—"
		if supplier != nil { supplierStr = *supplier }
		priceStr := "—"
		if unitPrice != nil { priceStr = fmt.Sprintf("%.2f", *unitPrice) }
		leadStr := "—"
		if leadDays != nil { leadStr = fmt.Sprintf("%d", *leadDays) }
		statusStr := "OK"
		if lowStock { statusStr = "⚠ STOCK BAJO" }

		values := []interface{}{code, name, category, unit, currentStock, minStock,
			maxStockStr, locationStr, supplierStr, priceStr, leadStr, statusStr}

		for col, val := range values {
			cell, _ := excelize.CoordinatesToCellName(col+1, row)
			f.SetCellValue(sheet, cell, val)
			if lowStock {
				f.SetCellStyle(sheet, cell, cell, lowStockStyle)
			}
		}
		row++
	}

	f.SetColWidth(sheet, "A", "A", 15)
	f.SetColWidth(sheet, "B", "B", 35)
	f.SetColWidth(sheet, "C", "C", 15)
	f.SetColWidth(sheet, "H", "H", 20)
	f.SetColWidth(sheet, "I", "I", 20)

	// Movements sheet
	mvSheet := "Movimientos recientes"
	f.NewSheet(mvSheet)
	mvHeaders := []string{"Repuesto", "Código", "Tipo", "Cantidad", "Stock antes", "Stock después", "Fecha"}
	for i, h2 := range mvHeaders {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1)
		f.SetCellValue(mvSheet, cell, h2)
		f.SetCellStyle(mvSheet, cell, cell, headerStyle)
	}

	mvRows, _ := h.db.Query(c.UserContext(),
		`SELECT sp.name, sp.code, sm.movement_type, sm.quantity,
		        sm.stock_before, sm.stock_after, sm.created_at::text
		 FROM stock_movements sm JOIN spare_parts sp ON sp.id=sm.spare_part_id
		 WHERE sm.tenant_id=$1 ORDER BY sm.created_at DESC LIMIT 100`,
		claims.TenantID,
	)
	if mvRows != nil {
		defer mvRows.Close()
		mvRow := 2
		for mvRows.Next() {
			var name, code, movType, date string
			var qty, before, after float64
			if mvRows.Scan(&name, &code, &movType, &qty, &before, &after, &date) == nil {
				for col, val := range []interface{}{name, code, movType, qty, before, after, date} {
					cell, _ := excelize.CoordinatesToCellName(col+1, mvRow)
					f.SetCellValue(mvSheet, cell, val)
				}
				mvRow++
			}
		}
	}

	var buf bytes.Buffer
	if err := f.Write(&buf); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error generando Excel")
	}

	filename := fmt.Sprintf("inventario_repuestos_%s.xlsx", time.Now().Format("20060102_1504"))
	c.Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	c.Set("Content-Disposition", fmt.Sprintf(`attachment; filename="%s"`, sanitizeFileName(filename)))
	return c.Send(buf.Bytes())
}

// ─── GET /reports/work-orders/excel ──────────────────────────────────────────

func (h *ReportsHandler) WorkOrdersExcel(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	statusFilter := c.Query("status")
	woTypeFilter := c.Query("type")

	query := `SELECT wo.wo_number, wo.title, fn.name, wo.wo_type, wo.priority, wo.status,
	                 ua.full_name, wo.estimated_hours, wo.actual_hours,
	                 wo.planned_start::text, wo.completed_at::text,
	                 wo.root_cause, wo.solution, wo.created_at::text
	          FROM work_orders wo
	          JOIN factory_nodes fn ON fn.id=wo.node_id
	          LEFT JOIN users ua ON ua.id=wo.assigned_to
	          WHERE wo.tenant_id=$1`
	args := []interface{}{claims.TenantID}
	if statusFilter != "" {
		query += " AND wo.status=$2"
		args = append(args, statusFilter)
	}
	if woTypeFilter != "" {
		n := len(args) + 1
		query += fmt.Sprintf(" AND wo.wo_type=$%d", n)
		args = append(args, woTypeFilter)
	}
	query += " ORDER BY wo.created_at DESC LIMIT 500"

	rows, err := h.db.Query(c.UserContext(), query, args...)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando OTs")
	}
	defer rows.Close()

	f := excelize.NewFile()
	defer f.Close()
	sheet := "Órdenes de Trabajo"
	f.SetSheetName("Sheet1", sheet)

	headerStyle, _ := f.NewStyle(&excelize.Style{
		Fill: excelize.Fill{Type: "pattern", Color: []string{"0F3460"}, Pattern: 1},
		Font: &excelize.Font{Color: "FFFFFF", Bold: true},
	})

	headers := []string{"Número", "Título", "Equipo", "Tipo", "Prioridad", "Estado",
		"Asignado a", "H. estimadas", "H. reales", "Inicio planif.", "Completada",
		"Causa raíz", "Solución", "Creada"}
	for i, h2 := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1)
		f.SetCellValue(sheet, cell, h2)
		f.SetCellStyle(sheet, cell, cell, headerStyle)
	}

	row := 2
	for rows.Next() {
		var woNumber, title, nodeName, woType2, priority2, status2, createdAt string
		var assignedName, rootCause, solution, plannedStart2, completedAt2 *string
		var estHours2, actualHours2 *float64

		if err := rows.Scan(&woNumber, &title, &nodeName, &woType2, &priority2, &status2,
			&assignedName, &estHours2, &actualHours2,
			&plannedStart2, &completedAt2, &rootCause, &solution, &createdAt); err != nil {
			continue
		}

		vals := []interface{}{
			woNumber, title, nodeName, woType2, priority2, status2,
			sp(assignedName), sf(estHours2), sf(actualHours2),
			sd(plannedStart2), sd(completedAt2),
			sp(rootCause), sp(solution), createdAt[:10],
		}
		for col, val := range vals {
			cell, _ := excelize.CoordinatesToCellName(col+1, row)
			f.SetCellValue(sheet, cell, val)
		}
		row++
	}

	f.SetColWidth(sheet, "B", "B", 40)
	f.SetColWidth(sheet, "C", "C", 25)
	f.SetColWidth(sheet, "L", "M", 40)

	var buf bytes.Buffer
	f.Write(&buf)

	filename := fmt.Sprintf("ordenes_trabajo_%s.xlsx", time.Now().Format("20060102_1504"))
	c.Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	c.Set("Content-Disposition", fmt.Sprintf(`attachment; filename="%s"`, sanitizeFileName(filename)))
	return c.Send(buf.Bytes())
}
