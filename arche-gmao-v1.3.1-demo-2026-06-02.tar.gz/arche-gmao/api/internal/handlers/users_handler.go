package handlers

import (
	"fmt"
	"strconv"
	"strings"
	"unicode"

	"arche-gmao/api/internal/license"
	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/redis/go-redis/v9"
	"golang.org/x/crypto/bcrypt"
)

// validatePassword checks the minimum password complexity
func validatePassword(pw string) string {
	if len(pw) < 8 {
		return "La contraseña debe tener al menos 8 caracteres"
	}
	var hasUpper, hasLower, hasDigit bool
	for _, r := range pw {
		switch {
		case unicode.IsUpper(r):
			hasUpper = true
		case unicode.IsLower(r):
			hasLower = true
		case unicode.IsDigit(r):
			hasDigit = true
		}
	}
	if !hasUpper || !hasLower || !hasDigit {
		return "La contraseña debe contener al menos una mayúscula, una minúscula y un número"
	}
	return ""
}

type UsersHandler struct {
	db  *pgxpool.Pool
	rdb *redis.Client
}

func NewUsersHandler(db *pgxpool.Pool, rdb ...*redis.Client) *UsersHandler {
	h := &UsersHandler{db: db}
	if len(rdb) > 0 {
		h.rdb = rdb[0]
	}
	return h
}

type UserResponse struct {
	ID             int64   `json:"id"`
	TenantID       int64   `json:"tenant_id"`
	Email          string  `json:"email"`
	FullName       string  `json:"full_name"`
	Role           string  `json:"role"`
	Status         string  `json:"status"`
	HomeNodeID     *int64  `json:"home_node_id"`
	HomeNodeName   *string `json:"home_node_name"`
	IsPrimaryAdmin bool    `json:"is_primary_admin"`
	LastLoginAt    *string `json:"last_login_at"`
	CreatedAt      string  `json:"created_at"`
}

func (h *UsersHandler) List(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	role := c.Query("role")
	status := c.Query("status")

	query := `SELECT u.id, u.tenant_id, u.email, u.full_name, u.role, u.status,
	                 u.home_node_id, fn.name, u.is_primary_admin,
	                 u.last_login_at::text, u.created_at::text
	          FROM users u
	          LEFT JOIN factory_nodes fn ON fn.id = u.home_node_id
	          WHERE u.tenant_id = $1`
	args := []interface{}{claims.TenantID}
	argIdx := 2

	if role != "" {
		query += ` AND u.role = $` + strconv.Itoa(argIdx)
		args = append(args, role)
		argIdx++
	}
	if status != "" && status != "all" {
		query += ` AND u.status = $` + strconv.Itoa(argIdx)
		args = append(args, status)
		argIdx++
	} else if status == "" {
		query += ` AND u.status = 'active'`
	}

	query += ` ORDER BY u.role, u.full_name`

	rows, err := h.db.Query(c.UserContext(), query, args...)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando usuarios")
	}
	defer rows.Close()

	var users []UserResponse
	for rows.Next() {
		var u UserResponse
		if err := rows.Scan(
			&u.ID, &u.TenantID, &u.Email, &u.FullName, &u.Role, &u.Status,
			&u.HomeNodeID, &u.HomeNodeName, &u.IsPrimaryAdmin,
			&u.LastLoginAt, &u.CreatedAt,
		); err == nil {
			users = append(users, u)
		}
	}

	// Statistics + user limit
	var total, active int
	var maxUsers *int
	h.db.QueryRow(c.UserContext(),
		`SELECT COUNT(*), COUNT(*) FILTER (WHERE status='active') FROM users WHERE tenant_id=$1`,
		claims.TenantID,
	).Scan(&total, &active)
	h.db.QueryRow(c.UserContext(),
		`SELECT max_users FROM tenants WHERE id=$1`, claims.TenantID,
	).Scan(&maxUsers)

	return c.JSON(fiber.Map{
		"users":     users,
		"total":     total,
		"active":    active,
		"max_users": maxUsers,
	})
}

type createUserRequest struct {
	Email      string `json:"email"`
	Password   string `json:"password"`
	FullName   string `json:"full_name"`
	Role       string `json:"role"`
	HomeNodeID *int64 `json:"home_node_id"`
}

func (h *UsersHandler) Create(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	var req createUserRequest
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}
	req.FullName = strings.TrimSpace(req.FullName)
	if req.Email == "" || req.Password == "" || req.FullName == "" || req.Role == "" {
		return fiber.NewError(fiber.StatusBadRequest, "Email, contraseña, nombre y rol son requeridos")
	}
	email := normalizeEmail(req.Email)
	if email == "" {
		return fiber.NewError(fiber.StatusBadRequest, "Email inválido")
	}
	req.Email = email
	if msg := validatePassword(req.Password); msg != "" {
		return fiber.NewError(fiber.StatusBadRequest, msg)
	}
	validRoles := map[string]bool{"admin": true, "supervisor": true, "technician": true, "operator": true, "warehouse": true, "auditor": true}
	if !validRoles[req.Role] {
		return fiber.NewError(fiber.StatusBadRequest, "Rol inválido")
	}

	// Check the user limit: the license takes priority, the DB is the fallback
	var activeCount int
	h.db.QueryRow(c.UserContext(),
		`SELECT COUNT(*) FROM users WHERE tenant_id=$1 AND status='active'`,
		claims.TenantID,
	).Scan(&activeCount)

	maxFromLicense := license.GetMaxUsers()
	if maxFromLicense > 0 && activeCount >= maxFromLicense {
		return fiber.NewError(fiber.StatusConflict,
			fmt.Sprintf("Límite de licencia alcanzado: %d usuarios activos de %d permitidos", activeCount, maxFromLicense))
	}
	// Fallback: per-tenant limit in the DB (set by the superadmin)
	if maxFromLicense == 0 {
		var maxUsers *int
		h.db.QueryRow(c.UserContext(),
			`SELECT max_users FROM tenants WHERE id=$1`, claims.TenantID,
		).Scan(&maxUsers)
		if maxUsers != nil && activeCount >= *maxUsers {
			return fiber.NewError(fiber.StatusConflict,
				fmt.Sprintf("Límite del sistema alcanzado: %d usuarios activos de %d permitidos", activeCount, *maxUsers))
		}
	}

	hash, err := bcrypt.GenerateFromPassword([]byte(req.Password), 12)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error generando contraseña")
	}

	var newID int64
	err = h.db.QueryRow(c.UserContext(),
		`INSERT INTO users (tenant_id, email, password_hash, full_name, role, status, home_node_id)
		 VALUES ($1,$2,$3,$4,$5,'active',$6) RETURNING id`,
		claims.TenantID, req.Email, string(hash), req.FullName, req.Role, req.HomeNodeID,
	).Scan(&newID)
	if err != nil {
		return fiber.NewError(fiber.StatusConflict, "El correo ya está registrado en este tenant")
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": newID, "message": "Usuario creado"})
}

func (h *UsersHandler) Update(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req struct {
		FullName   string `json:"full_name"`
		Role       string `json:"role"`
		Status     string `json:"status"`
		HomeNodeID *int64 `json:"home_node_id"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	// Check whether the target is the primary admin
	var targetIsPrimary bool
	h.db.QueryRow(c.UserContext(),
		`SELECT is_primary_admin FROM users WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	).Scan(&targetIsPrimary)

	if targetIsPrimary && id != claims.UserID {
		// Only the primary admin themselves can edit their basic data (name)
		return fiber.NewError(fiber.StatusForbidden,
			"No se puede modificar al administrador principal del sistema")
	}

	if targetIsPrimary {
		// The primary admin cannot change their own role or deactivate themselves
		if req.Role != "admin" {
			return fiber.NewError(fiber.StatusForbidden,
				"El administrador principal no puede cambiar su propio rol")
		}
		if req.Status != "active" {
			return fiber.NewError(fiber.StatusForbidden,
				"El administrador principal no puede desactivar su propia cuenta")
		}
	}

	result, err := h.db.Exec(c.UserContext(),
		`UPDATE users SET full_name=$1, role=$2, status=$3, home_node_id=$4
		 WHERE id=$5 AND tenant_id=$6`,
		req.FullName, req.Role, req.Status, req.HomeNodeID,
		id, claims.TenantID,
	)
	if err != nil {
		// The SQL trigger also protects this; catch its error
		return fiber.NewError(fiber.StatusForbidden,
			"No se puede modificar al administrador principal del sistema")
	}
	if result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Usuario no encontrado")
	}

	return c.JSON(fiber.Map{"message": "Usuario actualizado"})
}

func (h *UsersHandler) ChangePassword(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	// Only the primary admin themselves or a superadmin can change their password
	if id != claims.UserID {
		var isPrimary bool
		_ = h.db.QueryRow(c.UserContext(),
			`SELECT COALESCE(is_primary_admin, false) FROM users WHERE id=$1 AND tenant_id=$2`,
			id, claims.TenantID,
		).Scan(&isPrimary)
		if isPrimary && !claims.IsSuperadmin {
			return fiber.NewError(fiber.StatusForbidden, "Solo el propio administrador principal puede cambiar su contraseña")
		}
	}

	var req struct {
		Password string `json:"password"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}
	if msg := validatePassword(req.Password); msg != "" {
		return fiber.NewError(fiber.StatusBadRequest, msg)
	}

	hash, hashErr := bcrypt.GenerateFromPassword([]byte(req.Password), 12)
	if hashErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error generando contraseña")
	}
	result, err := h.db.Exec(c.UserContext(),
		`UPDATE users SET password_hash=$1 WHERE id=$2 AND tenant_id=$3`,
		string(hash), id, claims.TenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Usuario no encontrado")
	}

	// Invalidate refresh + access tokens in use (change forced by an admin)
	if h.rdb != nil {
		h.rdb.Del(c.UserContext(), fmt.Sprintf("refresh:%d", id))
		h.rdb.Del(c.UserContext(), fmt.Sprintf("sa_refresh:%d", id))
		RevokeUserSessions(h.rdb, c.UserContext(), id, false)
	}

	return c.JSON(fiber.Map{"message": "Contraseña actualizada"})
}

func (h *UsersHandler) Delete(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}
	if id == claims.UserID {
		return fiber.NewError(fiber.StatusBadRequest, "No puedes desactivar tu propia cuenta")
	}

	// Check whether the target is the primary admin (first line of defence)
	var targetIsPrimary bool
	h.db.QueryRow(c.UserContext(),
		`SELECT is_primary_admin FROM users WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	).Scan(&targetIsPrimary)
	if targetIsPrimary {
		return fiber.NewError(fiber.StatusForbidden,
			"El administrador principal no puede ser eliminado ni desactivado")
	}

	result, err := h.db.Exec(c.UserContext(),
		`UPDATE users SET status='inactive' WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	)
	if err != nil {
		// SQL trigger as the second line of defence
		return fiber.NewError(fiber.StatusForbidden,
			"El administrador principal no puede ser eliminado ni desactivado")
	}
	if result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Usuario no encontrado")
	}

	return c.JSON(fiber.Map{"message": "Usuario desactivado"})
}
