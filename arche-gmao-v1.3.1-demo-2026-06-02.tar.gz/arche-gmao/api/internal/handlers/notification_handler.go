package handlers

import (
	"context"
	"log"
	"strconv"

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type NotificationHandler struct {
	db *pgxpool.Pool
}

func NewNotificationHandler(db *pgxpool.Pool) *NotificationHandler {
	return &NotificationHandler{db: db}
}

// ─── GET /notifications — list the user's notifications ──────────────────

func (h *NotificationHandler) List(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	onlyUnread := c.Query("unread", "false") == "true"

	query := `SELECT id, type, title, body, link, is_read, created_at::text
	          FROM notifications
	          WHERE user_id=$1 AND tenant_id=$2`
	args := []interface{}{claims.UserID, claims.TenantID}

	if onlyUnread {
		query += ` AND is_read=false`
	}
	query += ` ORDER BY created_at DESC LIMIT 50`

	rows, err := h.db.Query(c.UserContext(), query, args...)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando notificaciones")
	}
	defer rows.Close()

	type Notification struct {
		ID        int64   `json:"id"`
		Type      string  `json:"type"`
		Title     string  `json:"title"`
		Body      string  `json:"body"`
		Link      *string `json:"link"`
		IsRead    bool    `json:"is_read"`
		CreatedAt string  `json:"created_at"`
	}

	var notifications []Notification
	for rows.Next() {
		var n Notification
		if rows.Scan(&n.ID, &n.Type, &n.Title, &n.Body, &n.Link, &n.IsRead, &n.CreatedAt) == nil {
			notifications = append(notifications, n)
		}
	}

	// Count unread ones
	var unreadCount int
	h.db.QueryRow(c.UserContext(),
		`SELECT COUNT(*) FROM notifications WHERE user_id=$1 AND tenant_id=$2 AND is_read=false`,
		claims.UserID, claims.TenantID,
	).Scan(&unreadCount)

	return c.JSON(fiber.Map{
		"notifications": notifications,
		"total":         len(notifications),
		"unread_count":  unreadCount,
	})
}

// ─── PATCH /notifications/:id/read — mark as read ───────────────────────

func (h *NotificationHandler) MarkRead(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	result, err := h.db.Exec(c.UserContext(),
		`UPDATE notifications SET is_read=true WHERE id=$1 AND user_id=$2 AND tenant_id=$3`,
		id, claims.UserID, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error marcando notificación")
	}
	if result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Notificación no encontrada")
	}
	return c.JSON(fiber.Map{"message": "Notificación marcada como leída"})
}

// ─── PATCH /notifications/read-all — mark them all as read ────────────────

func (h *NotificationHandler) MarkAllRead(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	_, err := h.db.Exec(c.UserContext(),
		`UPDATE notifications SET is_read=true WHERE user_id=$1 AND tenant_id=$2 AND is_read=false`,
		claims.UserID, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error actualizando notificaciones")
	}
	return c.JSON(fiber.Map{"message": "Todas las notificaciones marcadas como leídas"})
}

// ─── GET /notifications/preferences — user preferences ───────────────

func (h *NotificationHandler) GetPreferences(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	rows, err := h.db.Query(c.UserContext(),
		`SELECT event_type, in_app, email FROM notification_preferences
		 WHERE user_id=$1 AND tenant_id=$2 ORDER BY event_type`,
		claims.UserID, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error")
	}
	defer rows.Close()

	type Pref struct {
		EventType string `json:"event_type"`
		InApp     bool   `json:"in_app"`
		Email     bool   `json:"email"`
	}

	var prefs []Pref
	for rows.Next() {
		var p Pref
		if rows.Scan(&p.EventType, &p.InApp, &p.Email) == nil {
			prefs = append(prefs, p)
		}
	}

	return c.JSON(fiber.Map{"preferences": prefs})
}

// ─── PUT /notifications/preferences — update preferences ────────────────

func (h *NotificationHandler) UpdatePreferences(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req struct {
		Preferences []struct {
			EventType string `json:"event_type"`
			InApp     bool   `json:"in_app"`
			Email     bool   `json:"email"`
		} `json:"preferences"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	for _, p := range req.Preferences {
		if _, err := h.db.Exec(c.UserContext(),
			`INSERT INTO notification_preferences (tenant_id, user_id, event_type, in_app, email)
			 VALUES ($1,$2,$3,$4,$5)
			 ON CONFLICT (tenant_id, user_id, event_type)
			 DO UPDATE SET in_app=EXCLUDED.in_app, email=EXCLUDED.email`,
			claims.TenantID, claims.UserID, p.EventType, p.InApp, p.Email,
		); err != nil {
			return fiber.NewError(fiber.StatusInternalServerError, "Error guardando preferencias")
		}
	}

	return c.JSON(fiber.Map{"message": "Preferencias actualizadas"})
}

// ─── GET /notifications/smtp — SMTP configuration (admin only) ───────────────

func (h *NotificationHandler) GetSMTP(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	type SMTP struct {
		Host    *string `json:"host"`
		Port    *int    `json:"port"`
		User    *string `json:"user"`
		From    *string `json:"from"`
		Enabled bool    `json:"enabled"`
	}

	var s SMTP
	h.db.QueryRow(c.UserContext(),
		`SELECT smtp_host, smtp_port, smtp_user, smtp_from, COALESCE(smtp_enabled,false)
		 FROM tenants WHERE id=$1`,
		claims.TenantID,
	).Scan(&s.Host, &s.Port, &s.User, &s.From, &s.Enabled)

	return c.JSON(s)
}

// ─── PUT /notifications/smtp — save the SMTP configuration ────────────────────

func (h *NotificationHandler) UpdateSMTP(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req struct {
		Host     string `json:"host"`
		Port     int    `json:"port"`
		User     string `json:"user"`
		Password string `json:"password"`
		From     string `json:"from"`
		Enabled  bool   `json:"enabled"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	if req.Port == 0 {
		req.Port = 587
	}

	query := `UPDATE tenants SET smtp_host=$1, smtp_port=$2, smtp_user=$3,
	           smtp_from=$4, smtp_enabled=$5`
	args := []interface{}{req.Host, req.Port, req.User, req.From, req.Enabled}

	if req.Password != "" {
		query += `, smtp_password=$6 WHERE id=$7`
		args = append(args, req.Password, claims.TenantID)
	} else {
		query += ` WHERE id=$6`
		args = append(args, claims.TenantID)
	}

	if _, err := h.db.Exec(c.UserContext(), query, args...); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error guardando configuración SMTP")
	}

	return c.JSON(fiber.Map{"message": "Configuración SMTP guardada"})
}

// ─── CreateNotification — helper function for creating notifications ────────────

func CreateNotification(db *pgxpool.Pool, tenantID, userID int64, notifType, title, body string, link *string) {
	if _, err := db.Exec(context.Background(),
		`INSERT INTO notifications (tenant_id, user_id, type, title, body, link)
		 VALUES ($1,$2,$3,$4,$5,$6)`,
		tenantID, userID, notifType, title, body, link,
	); err != nil {
		log.Printf("[ARCHE] Error creando notificación: %v", err)
	}
}

// ─── NotifyUsersWithRole — notify every user with a role ───────────

func NotifyUsersWithRole(db *pgxpool.Pool, tenantID int64, role, notifType, title, body string, link *string) {
	rows, err := db.Query(context.Background(),
		`SELECT id FROM users WHERE tenant_id=$1 AND role=$2 AND status='active'`,
		tenantID, role,
	)
	if err != nil {
		return
	}
	defer rows.Close()

	for rows.Next() {
		var userID int64
		if rows.Scan(&userID) == nil {
			CreateNotification(db, tenantID, userID, notifType, title, body, link)
		}
	}
}
