package handlers

import (
	"strconv"

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type CalendarHandler struct {
	db *pgxpool.Pool
}

func NewCalendarHandler(db *pgxpool.Pool) *CalendarHandler {
	return &CalendarHandler{db: db}
}

type CalendarEvent struct {
	ID          int64   `json:"id"`
	UserID      int64   `json:"user_id"`
	WONumber    *string `json:"wo_number"`
	Title       string  `json:"title"`
	Description *string `json:"description"`
	EventType   string  `json:"event_type"`
	Color       *string `json:"color"`
	StartAt     string  `json:"start_at"`
	EndAt       *string `json:"end_at"`
	AllDay      bool    `json:"all_day"`
	IsAuto      bool    `json:"is_auto"`
	CreatedAt   string  `json:"created_at"`
}

// ─── GET /calendar — unified events ──────────────────────────────────────
// Combines: calendar_events + WOs + maintenance plans

func (h *CalendarHandler) List(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	from := c.Query("from") // YYYY-MM-DD
	to := c.Query("to")
	isManager := claims.Role == "admin" || claims.Role == "supervisor"

	var events []CalendarEvent

	// ── 1. Manual user events ──────────────────────────────────
	{
		q := `SELECT ce.id, ce.user_id, wo.wo_number,
		             ce.title, ce.description::text, ce.event_type, ce.color,
		             ce.start_at::text, ce.end_at::text, ce.all_day, ce.is_auto,
		             ce.created_at::text
		      FROM calendar_events ce
		      LEFT JOIN work_orders wo ON wo.id = ce.wo_id
		      WHERE ce.user_id = $1 AND ce.tenant_id = $2`
		args := []interface{}{claims.UserID, claims.TenantID}
		idx := 3
		if from != "" {
			q += " AND ce.start_at >= $" + strconv.Itoa(idx) + "::date"
			args = append(args, from)
			idx++
		}
		if to != "" {
			q += " AND ce.start_at <= ($" + strconv.Itoa(idx) + "::date + interval '1 day')"
			args = append(args, to)
			idx++
		}
		q += " ORDER BY ce.start_at"
		rows, err := h.db.Query(c.UserContext(), q, args...)
		if err == nil {
			defer rows.Close()
			for rows.Next() {
				var e CalendarEvent
				if rows.Scan(&e.ID, &e.UserID, &e.WONumber,
					&e.Title, &e.Description, &e.EventType, &e.Color,
					&e.StartAt, &e.EndAt, &e.AllDay, &e.IsAuto,
					&e.CreatedAt) == nil {
					events = append(events, e)
				}
			}
		}
	}

	// ── 2. WOs (filtered by visibility) ───────────────────────────────
	{
		q := `SELECT -wo.id, COALESCE(wo.assigned_to, wo.created_by),
		             wo.wo_number, wo.title, wo.description::text,
		             CASE wo.wo_type
		               WHEN 'preventive' THEN 'maintenance'
		               WHEN 'predictive' THEN 'maintenance'
		               ELSE 'wo_assigned'
		             END,
		             CASE wo.priority
		               WHEN 'critical' THEN '#E94560'
		               WHEN 'high' THEN '#F39C12'
		               WHEN 'medium' THEN '#0F3460'
		               ELSE '#27AE60'
		             END,
		             COALESCE(wo.planned_end, wo.created_at)::text,
		             NULL::text, false, true, wo.created_at::text
		      FROM work_orders wo
		      WHERE wo.tenant_id = $1
		        AND wo.status NOT IN ('cancelled','closed')`
		args := []interface{}{claims.TenantID}
		idx := 2
		if !isManager {
			q += " AND (wo.assigned_to = $" + strconv.Itoa(idx) + " OR wo.created_by = $" + strconv.Itoa(idx) + ")"
			args = append(args, claims.UserID)
			idx++
		}
		if from != "" {
			q += " AND COALESCE(wo.planned_end, wo.created_at) >= $" + strconv.Itoa(idx) + "::date"
			args = append(args, from)
			idx++
		}
		if to != "" {
			q += " AND COALESCE(wo.planned_end, wo.created_at) <= ($" + strconv.Itoa(idx) + "::date + interval '1 day')"
			args = append(args, to)
			idx++
		}
		q += " ORDER BY COALESCE(wo.planned_end, wo.created_at)"
		rows, err := h.db.Query(c.UserContext(), q, args...)
		if err == nil {
			defer rows.Close()
			for rows.Next() {
				var e CalendarEvent
				if rows.Scan(&e.ID, &e.UserID, &e.WONumber,
					&e.Title, &e.Description, &e.EventType, &e.Color,
					&e.StartAt, &e.EndAt, &e.AllDay, &e.IsAuto,
					&e.CreatedAt) == nil {
					events = append(events, e)
				}
			}
		}
	}

	// ── 3. Maintenance plans (admin/supervisor only) ───────────────
	if isManager {
		q := `SELECT -(1000000 + mp.id), 0::bigint,
		             NULL::text,
		             '[PM] ' || mp.title,
		             COALESCE(fn.name, et.manufacturer || ' ' || et.model, 'Sin destino'),
		             'maintenance'::text,
		             '#8B5CF6'::text,
		             mp.next_due_at::text,
		             NULL::text, true, true, mp.created_at::text
		      FROM maintenance_plans mp
		      LEFT JOIN factory_nodes fn ON fn.id = mp.node_id
		      LEFT JOIN equipment_templates et ON et.id = mp.equipment_template_id
		      WHERE mp.tenant_id = $1
		        AND mp.is_active = true
		        AND mp.next_due_at IS NOT NULL`
		args := []interface{}{claims.TenantID}
		idx := 2
		if from != "" {
			q += " AND mp.next_due_at >= $" + strconv.Itoa(idx) + "::date"
			args = append(args, from)
			idx++
		}
		if to != "" {
			q += " AND mp.next_due_at <= ($" + strconv.Itoa(idx) + "::date + interval '1 day')"
			args = append(args, to)
			idx++
		}
		q += " ORDER BY mp.next_due_at"
		rows, err := h.db.Query(c.UserContext(), q, args...)
		if err == nil {
			defer rows.Close()
			for rows.Next() {
				var e CalendarEvent
				if rows.Scan(&e.ID, &e.UserID, &e.WONumber,
					&e.Title, &e.Description, &e.EventType, &e.Color,
					&e.StartAt, &e.EndAt, &e.AllDay, &e.IsAuto,
					&e.CreatedAt) == nil {
					events = append(events, e)
				}
			}
		}
	}

	return c.JSON(fiber.Map{"events": events, "total": len(events)})
}

// ─── GET /calendar/upcoming — upcoming events (widget) ──────────────────────

func (h *CalendarHandler) Upcoming(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	isManager := claims.Role == "admin" || claims.Role == "supervisor"

	type UpcomingEvent struct {
		ID        int64   `json:"id"`
		Title     string  `json:"title"`
		EventType string  `json:"event_type"`
		Color     *string `json:"color"`
		StartAt   string  `json:"start_at"`
		AllDay    bool    `json:"all_day"`
		WONumber  *string `json:"wo_number"`
	}

	var events []UpcomingEvent

	// Future manual events
	{
		rows, err := h.db.Query(c.UserContext(),
			`SELECT ce.id, ce.title, ce.event_type, ce.color,
			        ce.start_at::text, ce.all_day, wo.wo_number
			 FROM calendar_events ce
			 LEFT JOIN work_orders wo ON wo.id = ce.wo_id
			 WHERE ce.user_id=$1 AND ce.tenant_id=$2 AND ce.start_at >= NOW()
			 ORDER BY ce.start_at LIMIT 5`,
			claims.UserID, claims.TenantID)
		if err == nil {
			defer rows.Close()
			for rows.Next() {
				var e UpcomingEvent
				if rows.Scan(&e.ID, &e.Title, &e.EventType, &e.Color,
					&e.StartAt, &e.AllDay, &e.WONumber) == nil {
					events = append(events, e)
				}
			}
		}
	}

	// Future WOs
	{
		q := `SELECT -wo.id, wo.title,
		             CASE wo.wo_type WHEN 'preventive' THEN 'maintenance' WHEN 'predictive' THEN 'maintenance' ELSE 'wo_assigned' END,
		             CASE wo.priority WHEN 'critical' THEN '#E94560' WHEN 'high' THEN '#F39C12' WHEN 'medium' THEN '#0F3460' ELSE '#27AE60' END,
		             COALESCE(wo.planned_end, wo.created_at)::text,
		             false, wo.wo_number
		      FROM work_orders wo
		      WHERE wo.tenant_id=$1 AND wo.status NOT IN ('cancelled','closed','completed','verified')
		        AND COALESCE(wo.planned_end, wo.created_at) >= NOW()`
		args := []interface{}{claims.TenantID}
		if !isManager {
			q += " AND (wo.assigned_to = $2 OR wo.created_by = $2)"
			args = append(args, claims.UserID)
		}
		q += " ORDER BY COALESCE(wo.planned_end, wo.created_at) LIMIT 5"
		rows, err := h.db.Query(c.UserContext(), q, args...)
		if err == nil {
			defer rows.Close()
			for rows.Next() {
				var e UpcomingEvent
				if rows.Scan(&e.ID, &e.Title, &e.EventType, &e.Color,
					&e.StartAt, &e.AllDay, &e.WONumber) == nil {
					events = append(events, e)
				}
			}
		}
	}

	// Future preventive plans (managers only)
	if isManager {
		rows, err := h.db.Query(c.UserContext(),
			`SELECT -(1000000 + mp.id), '[PM] ' || mp.title,
			        'maintenance'::text, '#8B5CF6'::text,
			        mp.next_due_at::text, true, NULL::text
			 FROM maintenance_plans mp
			 WHERE mp.tenant_id=$1 AND mp.is_active=true
			   AND mp.next_due_at IS NOT NULL AND mp.next_due_at >= NOW()
			 ORDER BY mp.next_due_at LIMIT 5`,
			claims.TenantID)
		if err == nil {
			defer rows.Close()
			for rows.Next() {
				var e UpcomingEvent
				if rows.Scan(&e.ID, &e.Title, &e.EventType, &e.Color,
					&e.StartAt, &e.AllDay, &e.WONumber) == nil {
					events = append(events, e)
				}
			}
		}
	}

	return c.JSON(fiber.Map{"events": events})
}

// ─── POST /calendar ───────────────────────────────────────────────────────────

func (h *CalendarHandler) Create(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req struct {
		Title       string  `json:"title"`
		Description *string `json:"description"`
		EventType   string  `json:"event_type"`
		Color       *string `json:"color"`
		StartAt     string  `json:"start_at"`
		EndAt       *string `json:"end_at"`
		AllDay      bool    `json:"all_day"`
	}
	if err := c.BodyParser(&req); err != nil || req.Title == "" || req.StartAt == "" {
		return fiber.NewError(fiber.StatusBadRequest, "Título y fecha de inicio son requeridos")
	}
	if req.EventType == "" {
		req.EventType = "personal"
	}

	var newID int64
	err := h.db.QueryRow(c.UserContext(),
		`INSERT INTO calendar_events
		 (tenant_id, user_id, title, description, event_type, color, start_at, end_at, all_day)
		 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`,
		claims.TenantID, claims.UserID,
		req.Title, req.Description, req.EventType, req.Color,
		req.StartAt, req.EndAt, req.AllDay,
	).Scan(&newID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error creando evento")
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": newID, "message": "Evento creado"})
}

// ─── DELETE /calendar/:id ─────────────────────────────────────────────────────

func (h *CalendarHandler) Delete(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	result, err := h.db.Exec(c.UserContext(),
		`DELETE FROM calendar_events
		 WHERE id=$1 AND user_id=$2 AND tenant_id=$3 AND is_auto=false`,
		id, claims.UserID, claims.TenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Evento no encontrado o es auto-generado")
	}

	return c.JSON(fiber.Map{"message": "Evento eliminado"})
}
