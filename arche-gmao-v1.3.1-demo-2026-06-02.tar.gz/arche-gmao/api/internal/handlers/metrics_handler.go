package handlers

import (
	"fmt"
	"strconv"
	"time"

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

// parseNodeIDFilter reads the node_id query param and returns the ID, or 0 when it does not apply.
func parseNodeIDFilter(nodeIDStr string) int64 {
	if nodeIDStr == "" {
		return 0
	}
	id, err := strconv.ParseInt(nodeIDStr, 10, 64)
	if err != nil {
		return 0
	}
	return id
}

type MetricsHandler struct {
	db *pgxpool.Pool
}

func NewMetricsHandler(db *pgxpool.Pool) *MetricsHandler {
	return &MetricsHandler{db: db}
}

// parsePeriod returns the start of the requested period
func parsePeriod(period string) time.Time {
	now := time.Now()
	switch period {
	case "week":
		return now.AddDate(0, 0, -7)
	case "quarter":
		return now.AddDate(0, -3, 0)
	case "year":
		return now.AddDate(-1, 0, 0)
	default: // month
		return now.AddDate(0, -1, 0)
	}
}

// ─── GET /metrics/summary — global summary ───────────────────────────────────

func (h *MetricsHandler) Summary(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	period := c.Query("period", "month")
	since := parsePeriod(period)

	ctx := c.UserContext()

	type Summary struct {
		TotalWOs          int     `json:"total_wos"`
		CorrectiveWOs     int     `json:"corrective_wos"`
		PreventiveWOs     int     `json:"preventive_wos"`
		CompletedWOs      int     `json:"completed_wos"`
		PendingWOs        int     `json:"pending_wos"`
		OverdueWOs        int     `json:"overdue_wos"`
		AvgResolutionHrs  float64 `json:"avg_resolution_hours"`
		TotalNodes        int     `json:"total_nodes"`
		CriticalNodes     int     `json:"critical_nodes"`
		LowStockParts     int     `json:"low_stock_parts"`
		ActiveAlerts      int     `json:"active_alerts"`
		VerifPending      int     `json:"verif_pending"`
		EstimatedCostMtto float64 `json:"estimated_cost_mtto"`
	}

	var s Summary

	// Subquery for filtering nodes by the user's scope
	nodeScope := ""
	scopeArgs := []interface{}{claims.TenantID, since}
	if claims.Role != "admin" && claims.Role != "auditor" {
		nodeScope = ` AND node_id IN (
			SELECT fn.id FROM factory_nodes fn
			JOIN node_assignments na ON na.user_id = $3 AND na.tenant_id = $1
			JOIN factory_nodes assigned ON assigned.id = na.node_id AND assigned.tenant_id = $1
			WHERE fn.tenant_id = $1 AND fn.path <@ assigned.path
		)`
		scopeArgs = append(scopeArgs, claims.UserID)
	}

	// Optional filter by node subtree (node_id query param)
	filterNodeID := parseNodeIDFilter(c.Query("node_id"))
	if filterNodeID > 0 {
		nodeScope += fmt.Sprintf(` AND node_id IN (
			SELECT fn.id FROM factory_nodes fn
			WHERE fn.tenant_id=$1 AND fn.path <@ (
				SELECT path FROM factory_nodes WHERE id=$%d AND tenant_id=$1
			))`, len(scopeArgs)+1)
		scopeArgs = append(scopeArgs, filterNodeID)
	}

	h.db.QueryRow(ctx, `
		SELECT
			COUNT(*),
			COUNT(*) FILTER (WHERE wo_type='corrective'),
			COUNT(*) FILTER (WHERE wo_type='preventive'),
			COUNT(*) FILTER (WHERE status IN ('completed','verified','closed')),
			COUNT(*) FILTER (WHERE status='pending'),
			COUNT(*) FILTER (WHERE planned_end < NOW() AND status NOT IN ('completed','verified','closed','cancelled') AND planned_end IS NOT NULL),
			COALESCE(AVG(actual_hours) FILTER (WHERE actual_hours IS NOT NULL AND status IN ('completed','verified','closed')), 0)
		FROM work_orders
		WHERE tenant_id=$1 AND created_at >= $2`+nodeScope,
		scopeArgs...,
	).Scan(&s.TotalWOs, &s.CorrectiveWOs, &s.PreventiveWOs,
		&s.CompletedWOs, &s.PendingWOs, &s.OverdueWOs, &s.AvgResolutionHrs)

	// Nodes: scope by assignment
	nodeCountScope := ""
	nodeCountArgs := []interface{}{claims.TenantID}
	if claims.Role != "admin" && claims.Role != "auditor" {
		nodeCountScope = ` AND fn.id IN (
			SELECT fn2.id FROM factory_nodes fn2
			JOIN node_assignments na ON na.user_id = $2 AND na.tenant_id = $1
			JOIN factory_nodes assigned ON assigned.id = na.node_id AND assigned.tenant_id = $1
			WHERE fn2.tenant_id = $1 AND fn2.path <@ assigned.path
		)`
		nodeCountArgs = append(nodeCountArgs, claims.UserID)
	}
	h.db.QueryRow(ctx,
		`SELECT COUNT(*), COUNT(*) FILTER (WHERE fn.criticality='critical')
		 FROM factory_nodes fn WHERE fn.tenant_id=$1 AND fn.status!='decommissioned'`+nodeCountScope,
		nodeCountArgs...,
	).Scan(&s.TotalNodes, &s.CriticalNodes)

	// Low-stock spare parts linked to in-scope nodes
	if claims.Role != "admin" && claims.Role != "auditor" {
		h.db.QueryRow(ctx,
			`SELECT COUNT(DISTINCT sp.id) FROM spare_parts sp
			 JOIN spare_part_nodes spn ON spn.spare_part_id=sp.id
			 JOIN factory_nodes fn ON fn.id=spn.node_id AND fn.tenant_id=$1
			 JOIN node_assignments na ON na.user_id=$2 AND na.tenant_id=$1
			 JOIN factory_nodes assigned ON assigned.id=na.node_id AND assigned.tenant_id=$1
			 WHERE sp.tenant_id=$1 AND sp.is_active=true AND sp.current_stock<=sp.min_stock
			   AND fn.path <@ assigned.path`,
			claims.TenantID, claims.UserID,
		).Scan(&s.LowStockParts)
	} else {
		h.db.QueryRow(ctx,
			`SELECT COUNT(*) FROM spare_parts WHERE tenant_id=$1 AND is_active=true AND current_stock<=min_stock`,
			claims.TenantID,
		).Scan(&s.LowStockParts)
	}

	// Pattern alerts: scope by node
	if claims.Role != "admin" && claims.Role != "auditor" {
		h.db.QueryRow(ctx,
			`SELECT COUNT(*) FROM ai_patterns p
			 WHERE p.tenant_id=$1 AND p.status='active' AND (p.valid_until IS NULL OR p.valid_until>NOW())
			   AND p.node_id IN (
				SELECT fn.id FROM factory_nodes fn
				JOIN node_assignments na ON na.user_id=$2 AND na.tenant_id=$1
				JOIN factory_nodes assigned ON assigned.id=na.node_id AND assigned.tenant_id=$1
				WHERE fn.tenant_id=$1 AND fn.path <@ assigned.path
			)`,
			claims.TenantID, claims.UserID,
		).Scan(&s.ActiveAlerts)
	} else {
		h.db.QueryRow(ctx,
			`SELECT COUNT(*) FROM ai_patterns WHERE tenant_id=$1 AND status='active' AND (valid_until IS NULL OR valid_until>NOW())`,
			claims.TenantID,
		).Scan(&s.ActiveAlerts)
	}

	// Pending verifications: scope by the WO's node
	if claims.Role != "admin" && claims.Role != "auditor" {
		h.db.QueryRow(ctx,
			`SELECT COUNT(*) FROM verification_records vr
			 JOIN work_orders wo ON wo.id=vr.wo_id AND wo.tenant_id=$1
			 WHERE vr.tenant_id=$1 AND vr.status='pending'
			   AND wo.node_id IN (
				SELECT fn.id FROM factory_nodes fn
				JOIN node_assignments na ON na.user_id=$2 AND na.tenant_id=$1
				JOIN factory_nodes assigned ON assigned.id=na.node_id AND assigned.tenant_id=$1
				WHERE fn.tenant_id=$1 AND fn.path <@ assigned.path
			)`,
			claims.TenantID, claims.UserID,
		).Scan(&s.VerifPending)
	} else {
		h.db.QueryRow(ctx,
			`SELECT COUNT(*) FROM verification_records WHERE tenant_id=$1 AND status='pending'`,
			claims.TenantID,
		).Scan(&s.VerifPending)
	}

	h.db.QueryRow(ctx,
		`SELECT COALESCE(SUM(wop.quantity * sp.unit_price), 0)
		 FROM work_order_parts wop
		 JOIN spare_parts sp ON sp.id=wop.spare_part_id
		 JOIN work_orders wo ON wo.id=wop.wo_id
		 WHERE wo.tenant_id=$1 AND wo.created_at>=$2`+nodeScope,
		scopeArgs...,
	).Scan(&s.EstimatedCostMtto)

	return c.JSON(s)
}

// ─── GET /metrics/equipment — MTBF, MTTR, availability per equipment item ──────────

func (h *MetricsHandler) Equipment(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	criticality := c.Query("criticality")
	limit, _ := strconv.Atoi(c.Query("limit", "20"))

	query := `
		SELECT
			fn.id AS node_id,
			fn.name AS node_name,
			fn.code AS node_code,
			fn.criticality,
			fn.node_type,
			COUNT(wo.id) FILTER (WHERE wo.wo_type='corrective') AS total_failures,
			ROUND(AVG(wo.actual_hours) FILTER (
				WHERE wo.wo_type='corrective' AND wo.actual_hours IS NOT NULL
				  AND wo.status IN ('completed','verified','closed')
			)::numeric, 2) AS mttr_hours,
			ROUND(MAX(wo.actual_hours) FILTER (
				WHERE wo.wo_type='corrective' AND wo.actual_hours IS NOT NULL
			)::numeric, 2) AS max_repair_hours,
			CASE WHEN COUNT(wo.id) FILTER (WHERE wo.wo_type='corrective') >= 2
				THEN ROUND((
					EXTRACT(EPOCH FROM (MAX(wo.created_at) FILTER (WHERE wo.wo_type='corrective')
					  - MIN(wo.created_at) FILTER (WHERE wo.wo_type='corrective'))) / 86400.0
					/ NULLIF(COUNT(wo.id) FILTER (WHERE wo.wo_type='corrective') - 1, 0)
				)::numeric, 1)
				ELSE NULL
			END AS mtbf_days,
			CASE WHEN COUNT(wo.id) FILTER (WHERE wo.wo_type='corrective') > 0
				THEN ROUND((1.0 - COALESCE(SUM(wo.actual_hours) FILTER (
					WHERE wo.wo_type='corrective' AND wo.actual_hours IS NOT NULL
				), 0) / NULLIF(EXTRACT(EPOCH FROM (NOW() - MIN(wo.created_at))) / 3600.0, 0)) * 100::numeric, 1)
				ELSE 100.0
			END AS availability_pct
		FROM factory_nodes fn
		LEFT JOIN work_orders wo ON wo.node_id=fn.id AND wo.tenant_id=fn.tenant_id
		WHERE fn.tenant_id=$1 AND fn.status!='decommissioned'
		  AND fn.node_type IN ('equipment','component')`
	args := []interface{}{claims.TenantID}
	argIdx := 2

	if criticality != "" {
		query += ` AND fn.criticality=$` + strconv.Itoa(argIdx)
		args = append(args, criticality)
		argIdx++
	}
	query += ` GROUP BY fn.id, fn.name, fn.code, fn.criticality, fn.node_type
		ORDER BY total_failures DESC NULLS LAST, mttr_hours DESC NULLS LAST LIMIT $` + strconv.Itoa(argIdx)
	args = append(args, limit)

	rows, err := h.db.Query(c.UserContext(), query, args...)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando métricas de equipos")
	}
	defer rows.Close()

	type EquipmentMetric struct {
		NodeID          int64    `json:"node_id"`
		NodeName        string   `json:"node_name"`
		NodeCode        *string  `json:"node_code"`
		Criticality     string   `json:"criticality"`
		NodeType        string   `json:"node_type"`
		TotalFailures   int      `json:"total_failures"`
		MTTRHours       *float64 `json:"mttr_hours"`
		MaxRepairHours  *float64 `json:"max_repair_hours"`
		MTBFDays        *float64 `json:"mtbf_days"`
		AvailabilityPct *float64 `json:"availability_pct"`
	}

	var metrics []EquipmentMetric
	for rows.Next() {
		var m EquipmentMetric
		if err := rows.Scan(
			&m.NodeID, &m.NodeName, &m.NodeCode, &m.Criticality, &m.NodeType,
			&m.TotalFailures, &m.MTTRHours, &m.MaxRepairHours, &m.MTBFDays, &m.AvailabilityPct,
		); err == nil {
			metrics = append(metrics, m)
		}
	}

	return c.JSON(fiber.Map{"metrics": metrics, "total": len(metrics)})
}

// ─── GET /metrics/trends — monthly WO trend ─────────────────────────

func (h *MetricsHandler) Trends(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	months, _ := strconv.Atoi(c.Query("months", "12"))
	since := time.Now().AddDate(0, -months, 0)

	rows, err := h.db.Query(c.UserContext(), `
		SELECT
			TO_CHAR(DATE_TRUNC('month', created_at), 'YYYY-MM') AS month,
			COUNT(*) FILTER (WHERE wo_type='corrective') AS corrective,
			COUNT(*) FILTER (WHERE wo_type='preventive') AS preventive,
			COUNT(*) FILTER (WHERE wo_type='inspection') AS inspection,
			COUNT(*) FILTER (WHERE wo_type='predictive') AS predictive,
			COUNT(*) AS total,
			ROUND(AVG(actual_hours) FILTER (
				WHERE actual_hours IS NOT NULL AND status IN ('completed','verified','closed')
			)::numeric, 2) AS avg_resolution_hours
		FROM work_orders
		WHERE tenant_id=$1 AND created_at >= $2
		GROUP BY DATE_TRUNC('month', created_at)
		ORDER BY DATE_TRUNC('month', created_at) ASC`,
		claims.TenantID, since,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando tendencias")
	}
	defer rows.Close()

	type TrendPoint struct {
		Month              string   `json:"month"`
		Corrective         int      `json:"corrective"`
		Preventive         int      `json:"preventive"`
		Inspection         int      `json:"inspection"`
		Predictive         int      `json:"predictive"`
		Total              int      `json:"total"`
		AvgResolutionHours *float64 `json:"avg_resolution_hours"`
	}

	var trends []TrendPoint
	for rows.Next() {
		var t TrendPoint
		if err := rows.Scan(
			&t.Month, &t.Corrective, &t.Preventive, &t.Inspection,
			&t.Predictive, &t.Total, &t.AvgResolutionHours,
		); err == nil {
			trends = append(trends, t)
		}
	}

	return c.JSON(fiber.Map{"trends": trends})
}

// ─── GET /metrics/technicians — performance per technician ─────────────────────

func (h *MetricsHandler) Technicians(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	period := c.Query("period", "month")
	since := parsePeriod(period)

	techArgs := []interface{}{claims.TenantID, since}
	nodeFilter := ""
	if nid := parseNodeIDFilter(c.Query("node_id")); nid > 0 {
		nodeFilter = fmt.Sprintf(` AND wo.node_id IN (
			SELECT fn.id FROM factory_nodes fn
			WHERE fn.tenant_id=$1 AND fn.path <@ (
				SELECT path FROM factory_nodes WHERE id=$%d AND tenant_id=$1
			))`, len(techArgs)+1)
		techArgs = append(techArgs, nid)
	}

	rows, err := h.db.Query(c.UserContext(), `
		SELECT
			wo.assigned_to AS user_id,
			u.full_name,
			COUNT(*) AS total_assigned,
			COUNT(*) FILTER (WHERE wo.status IN ('completed','verified','closed')) AS completed,
			COUNT(*) FILTER (WHERE wo.wo_type='corrective') AS corrective_count,
			COUNT(*) FILTER (WHERE wo.wo_type='preventive') AS preventive_count,
			ROUND(AVG(wo.actual_hours) FILTER (
				WHERE wo.actual_hours IS NOT NULL AND wo.status IN ('completed','verified','closed')
			)::numeric, 2) AS avg_resolution_hours,
			ROUND(AVG(
				EXTRACT(EPOCH FROM (wo.completed_at - wo.created_at)) / 3600.0
			) FILTER (WHERE wo.completed_at IS NOT NULL)::numeric, 2) AS avg_total_hours
		FROM work_orders wo
		JOIN users u ON u.id = wo.assigned_to
		WHERE wo.tenant_id=$1 AND wo.assigned_to IS NOT NULL AND wo.created_at >= $2`+nodeFilter+`
		GROUP BY wo.assigned_to, u.full_name
		ORDER BY completed DESC`,
		techArgs...,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando técnicos")
	}
	defer rows.Close()

	type TechMetric struct {
		UserID             int64    `json:"user_id"`
		FullName           string   `json:"full_name"`
		TotalAssigned      int      `json:"total_assigned"`
		Completed          int      `json:"completed"`
		CorrectiveCount    int      `json:"corrective_count"`
		PreventiveCount    int      `json:"preventive_count"`
		AvgResolutionHours *float64 `json:"avg_resolution_hours"`
		AvgTotalHours      *float64 `json:"avg_total_hours"`
	}

	var techs []TechMetric
	for rows.Next() {
		var t TechMetric
		if err := rows.Scan(
			&t.UserID, &t.FullName, &t.TotalAssigned, &t.Completed,
			&t.CorrectiveCount, &t.PreventiveCount,
			&t.AvgResolutionHours, &t.AvgTotalHours,
		); err == nil {
			techs = append(techs, t)
		}
	}

	return c.JSON(fiber.Map{"technicians": techs})
}

// ─── GET /metrics/spare-parts — spare part consumption ─────────────────────────

func (h *MetricsHandler) SpareParts(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	period := c.Query("period", "month")
	since := parsePeriod(period)

	rows, err := h.db.Query(c.UserContext(), `
		SELECT
			sp.id, sp.name, sp.code, sp.category, sp.unit,
			sp.current_stock, sp.min_stock, sp.unit_price,
			COALESCE(SUM(sm.quantity) FILTER (WHERE sm.movement_type IN ('consumption','manual_out','transfer')), 0) AS consumed,
			COALESCE(COUNT(*) FILTER (WHERE sm.movement_type IN ('consumption','manual_out','transfer')), 0) AS exits_count,
			COALESCE(SUM(sm.quantity * COALESCE(sp.unit_price,0)) FILTER (WHERE sm.movement_type IN ('consumption','manual_out','transfer')), 0) AS cost
		FROM spare_parts sp
		LEFT JOIN stock_movements sm ON sm.spare_part_id=sp.id AND sm.created_at>=$2
		WHERE sp.tenant_id=$1 AND sp.is_active=true
		GROUP BY sp.id, sp.name, sp.code, sp.category, sp.unit,
		         sp.current_stock, sp.min_stock, sp.unit_price
		HAVING COALESCE(SUM(sm.quantity) FILTER (WHERE sm.movement_type IN ('consumption','manual_out','transfer')), 0) > 0
		   OR sp.current_stock <= sp.min_stock
		ORDER BY consumed DESC NULLS LAST, sp.name`,
		claims.TenantID, since,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando repuestos")
	}
	defer rows.Close()

	type SPMetric struct {
		ID           int64    `json:"id"`
		Name         string   `json:"name"`
		Code         string   `json:"code"`
		Category     string   `json:"category"`
		Unit         string   `json:"unit"`
		CurrentStock float64  `json:"current_stock"`
		MinStock     float64  `json:"min_stock"`
		UnitPrice    *float64 `json:"unit_price"`
		Consumed     float64  `json:"consumed"`
		ExitsCount   int      `json:"exits_count"`
		Cost         float64  `json:"cost"`
		IsLowStock   bool     `json:"is_low_stock"`
	}

	var parts []SPMetric
	for rows.Next() {
		var p SPMetric
		if err := rows.Scan(
			&p.ID, &p.Name, &p.Code, &p.Category, &p.Unit,
			&p.CurrentStock, &p.MinStock, &p.UnitPrice,
			&p.Consumed, &p.ExitsCount, &p.Cost,
		); err == nil {
			p.IsLowStock = p.CurrentStock <= p.MinStock
			parts = append(parts, p)
		}
	}

	// Totals
	var totalCost float64
	for _, p := range parts {
		totalCost += p.Cost
	}

	return c.JSON(fiber.Map{
		"spare_parts": parts,
		"total":       len(parts),
		"total_cost":  totalCost,
	})
}

// ─── GET /metrics/corrective-ratio — corrective vs preventive ratio ──────────

func (h *MetricsHandler) CorrectiveRatio(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	period := c.Query("period", "month")
	since := parsePeriod(period)

	ratioArgs := []interface{}{claims.TenantID, since}
	nodeFilter := ""
	if nid := parseNodeIDFilter(c.Query("node_id")); nid > 0 {
		nodeFilter = fmt.Sprintf(` AND wo.node_id IN (
			SELECT fn2.id FROM factory_nodes fn2
			WHERE fn2.tenant_id=$1 AND fn2.path <@ (
				SELECT path FROM factory_nodes WHERE id=$%d AND tenant_id=$1
			))`, len(ratioArgs)+1)
		ratioArgs = append(ratioArgs, nid)
	}

	rows, err := h.db.Query(c.UserContext(), `
		SELECT
			fn.name AS node_name,
			fn.code AS node_code,
			fn.criticality,
			COUNT(*) FILTER (WHERE wo.wo_type='corrective') AS corrective,
			COUNT(*) FILTER (WHERE wo.wo_type='preventive') AS preventive,
			COUNT(*) AS total,
			CASE WHEN COUNT(*) > 0
				THEN ROUND(COUNT(*) FILTER (WHERE wo.wo_type='corrective')::numeric / COUNT(*) * 100, 1)
				ELSE 0
			END AS corrective_ratio
		FROM work_orders wo
		JOIN factory_nodes fn ON fn.id=wo.node_id
		WHERE wo.tenant_id=$1 AND wo.created_at>=$2
		  AND wo.wo_type IN ('corrective','preventive')`+nodeFilter+`
		GROUP BY fn.id, fn.name, fn.code, fn.criticality
		HAVING COUNT(*) >= 2
		ORDER BY corrective_ratio DESC`,
		ratioArgs...,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando ratios")
	}
	defer rows.Close()

	type RatioPoint struct {
		NodeName        string  `json:"node_name"`
		NodeCode        *string `json:"node_code"`
		Criticality     string  `json:"criticality"`
		Corrective      int     `json:"corrective"`
		Preventive      int     `json:"preventive"`
		Total           int     `json:"total"`
		CorrectiveRatio float64 `json:"corrective_ratio"`
	}

	var ratios []RatioPoint
	for rows.Next() {
		var r RatioPoint
		if err := rows.Scan(
			&r.NodeName, &r.NodeCode, &r.Criticality,
			&r.Corrective, &r.Preventive, &r.Total, &r.CorrectiveRatio,
		); err == nil {
			ratios = append(ratios, r)
		}
	}

	// Global ratio
	var globalCorrective, globalPreventive int
	for _, r := range ratios {
		globalCorrective += r.Corrective
		globalPreventive += r.Preventive
	}
	var globalRatio float64
	if globalCorrective+globalPreventive > 0 {
		globalRatio = float64(globalCorrective) / float64(globalCorrective+globalPreventive) * 100
	}

	return c.JSON(fiber.Map{
		"ratios":           ratios,
		"global_ratio":     globalRatio,
		"global_corrective": globalCorrective,
		"global_preventive": globalPreventive,
	})
}

// ─── GET /metrics/node/:id — metrics for a specific node ─────────────────

func (h *MetricsHandler) NodeMetrics(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	ctx := c.UserContext()

	// Node MTBF/MTTR
	type NodeKPIs struct {
		NodeName        string   `json:"node_name"`
		TotalFailures   int      `json:"total_failures"`
		MTTRHours       *float64 `json:"mttr_hours"`
		MTBFDays        *float64 `json:"mtbf_days"`
		AvailabilityPct *float64 `json:"availability_pct"`
	}

	var kpis NodeKPIs
	h.db.QueryRow(ctx,
		`SELECT
			fn.name AS node_name,
			COUNT(wo.id) FILTER (WHERE wo.wo_type='corrective') AS total_failures,
			ROUND(AVG(wo.actual_hours) FILTER (
				WHERE wo.wo_type='corrective' AND wo.actual_hours IS NOT NULL
				  AND wo.status IN ('completed','verified','closed')
			)::numeric, 2) AS mttr_hours,
			CASE WHEN COUNT(wo.id) FILTER (WHERE wo.wo_type='corrective') >= 2
				THEN ROUND((
					EXTRACT(EPOCH FROM (MAX(wo.created_at) FILTER (WHERE wo.wo_type='corrective')
					  - MIN(wo.created_at) FILTER (WHERE wo.wo_type='corrective'))) / 86400.0
					/ NULLIF(COUNT(wo.id) FILTER (WHERE wo.wo_type='corrective') - 1, 0)
				)::numeric, 1)
				ELSE NULL
			END AS mtbf_days,
			CASE WHEN COUNT(wo.id) FILTER (WHERE wo.wo_type='corrective') > 0
				THEN ROUND((1.0 - COALESCE(SUM(wo.actual_hours) FILTER (
					WHERE wo.wo_type='corrective' AND wo.actual_hours IS NOT NULL
				), 0) / NULLIF(EXTRACT(EPOCH FROM (NOW() - MIN(wo.created_at))) / 3600.0, 0)) * 100::numeric, 1)
				ELSE 100.0
			END AS availability_pct
		 FROM factory_nodes fn
		 LEFT JOIN work_orders wo ON wo.node_id=fn.id AND wo.tenant_id=fn.tenant_id
		 WHERE fn.id=$1 AND fn.tenant_id=$2
		 GROUP BY fn.id, fn.name`,
		nodeID, claims.TenantID,
	).Scan(&kpis.NodeName, &kpis.TotalFailures, &kpis.MTTRHours, &kpis.MTBFDays, &kpis.AvailabilityPct)

	// The node's last 10 WOs
	woRows, _ := h.db.Query(ctx, `
		SELECT wo_number, title, wo_type, status, priority,
		       actual_hours, created_at::text, completed_at::text
		FROM work_orders
		WHERE node_id=$1 AND tenant_id=$2
		ORDER BY created_at DESC LIMIT 10`,
		nodeID, claims.TenantID,
	)

	type WOSummary struct {
		WONumber    string   `json:"wo_number"`
		Title       string   `json:"title"`
		WOType      string   `json:"wo_type"`
		Status      string   `json:"status"`
		Priority    string   `json:"priority"`
		ActualHours *float64 `json:"actual_hours"`
		CreatedAt   string   `json:"created_at"`
		CompletedAt *string  `json:"completed_at"`
	}

	var wos []WOSummary
	if woRows != nil {
		defer woRows.Close()
		for woRows.Next() {
			var w WOSummary
			if woRows.Scan(&w.WONumber, &w.Title, &w.WOType, &w.Status, &w.Priority,
				&w.ActualHours, &w.CreatedAt, &w.CompletedAt) == nil {
				wos = append(wos, w)
			}
		}
	}

	// Spare part consumption for the node
	spRows, _ := h.db.Query(ctx, `
		SELECT sp.name, sp.code, sp.unit, sp.current_stock,
		       COALESCE(SUM(sm.quantity) FILTER (WHERE sm.movement_type IN ('consumption','manual_out','transfer')), 0) AS consumed
		FROM spare_parts sp
		JOIN spare_part_nodes spn ON spn.spare_part_id=sp.id AND spn.node_id=$1
		LEFT JOIN stock_movements sm ON sm.spare_part_id=sp.id
		WHERE sp.tenant_id=$2
		GROUP BY sp.id, sp.name, sp.code, sp.unit, sp.current_stock`,
		nodeID, claims.TenantID,
	)

	type SPNode struct {
		Name         string  `json:"name"`
		Code         string  `json:"code"`
		Unit         string  `json:"unit"`
		CurrentStock float64 `json:"current_stock"`
		Consumed     float64 `json:"consumed"`
	}

	var spares []SPNode
	if spRows != nil {
		defer spRows.Close()
		for spRows.Next() {
			var s SPNode
			if spRows.Scan(&s.Name, &s.Code, &s.Unit, &s.CurrentStock, &s.Consumed) == nil {
				spares = append(spares, s)
			}
		}
	}

	return c.JSON(fiber.Map{
		"kpis":        kpis,
		"work_orders": wos,
		"spare_parts": spares,
	})
}

// ─── GET /metrics/alerts-summary — summary of active alerts ────────────────

func (h *MetricsHandler) AlertsSummary(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	rows, err := h.db.Query(c.UserContext(), `
		SELECT pattern_type, severity, COUNT(*) AS count
		FROM ai_patterns
		WHERE tenant_id=$1 AND status='active'
		  AND (valid_until IS NULL OR valid_until > NOW())
		GROUP BY pattern_type, severity
		ORDER BY CASE severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2 ELSE 3 END`,
		claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error")
	}
	defer rows.Close()

	type AlertCount struct {
		PatternType string `json:"pattern_type"`
		Severity    string `json:"severity"`
		Count       int    `json:"count"`
	}

	var alerts []AlertCount
	for rows.Next() {
		var a AlertCount
		if rows.Scan(&a.PatternType, &a.Severity, &a.Count) == nil {
			alerts = append(alerts, a)
		}
	}

	var total, critical, high int
	for _, a := range alerts {
		total += a.Count
		if a.Severity == "critical" {
			critical += a.Count
		} else if a.Severity == "high" {
			high += a.Count
		}
	}

	return c.JSON(fiber.Map{
		"alerts":   alerts,
		"total":    total,
		"critical": critical,
		"high":     high,
	})
}
