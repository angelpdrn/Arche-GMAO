package handlers

import (
	"context"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"arche-gmao/api/internal/ai"
	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type TemplatesHandler struct {
	db *pgxpool.Pool
}

func NewTemplatesHandler(db *pgxpool.Pool) *TemplatesHandler {
	return &TemplatesHandler{db: db}
}

type TemplateResponse struct {
	ID           int64    `json:"id"`
	TenantID     *int64   `json:"tenant_id"`
	Manufacturer string   `json:"manufacturer"`
	Model        string   `json:"model"`
	Category     *string  `json:"category"`
	NodeType     string   `json:"node_type"`
	Description  *string  `json:"description"`
	Notes        *string  `json:"notes"`
	Tags         []string `json:"tags"`
	IsGlobal     bool     `json:"is_global"`
	IsActive     bool     `json:"is_active"`
	NodeCount    int      `json:"node_count"` // how many nodes use this template
	CreatedAt    string   `json:"created_at"`
}

// ─── GET /templates ───────────────────────────────────────────────────────────

func (h *TemplatesHandler) List(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	search := c.Query("q")
	category := c.Query("category")

	query := `
		SELECT et.id, et.tenant_id, et.manufacturer, et.model,
		       et.category, et.node_type, et.description, et.notes,
		       COALESCE(et.tags, '{}'), et.tenant_id IS NULL AS is_global,
		       et.is_active,
		       COUNT(fn.id) AS node_count,
		       et.created_at::text
		FROM equipment_templates et
		LEFT JOIN factory_nodes fn ON fn.template_id = et.id
		    AND fn.tenant_id = $1 AND fn.status != 'decommissioned'
		WHERE et.is_active = true
		  AND (et.tenant_id IS NULL OR et.tenant_id = $1)`

	args := []interface{}{claims.TenantID}
	argIdx := 2

	if search != "" {
		query += ` AND (et.manufacturer ILIKE $` + strconv.Itoa(argIdx) +
			` OR et.model ILIKE $` + strconv.Itoa(argIdx) +
			` OR et.category ILIKE $` + strconv.Itoa(argIdx) + `)`
		args = append(args, "%"+search+"%")
		argIdx++
	}
	if category != "" {
		query += ` AND et.category = $` + strconv.Itoa(argIdx)
		args = append(args, category)
		argIdx++
	}

	query += ` GROUP BY et.id ORDER BY et.tenant_id NULLS FIRST, et.manufacturer, et.model`

	rows, err := h.db.Query(c.UserContext(), query, args...)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando plantillas")
	}
	defer rows.Close()

	var templates []TemplateResponse
	for rows.Next() {
		var t TemplateResponse
		if err := rows.Scan(
			&t.ID, &t.TenantID, &t.Manufacturer, &t.Model,
			&t.Category, &t.NodeType, &t.Description, &t.Notes,
			&t.Tags, &t.IsGlobal, &t.IsActive,
			&t.NodeCount, &t.CreatedAt,
		); err == nil {
			templates = append(templates, t)
		}
	}

	return c.JSON(fiber.Map{"templates": templates, "total": len(templates)})
}

// ─── GET /templates/:id ───────────────────────────────────────────────────────

func (h *TemplatesHandler) GetOne(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var t TemplateResponse
	err = h.db.QueryRow(c.UserContext(),
		`SELECT id, tenant_id, manufacturer, model, category, node_type,
		        description, notes, COALESCE(tags, '{}'),
		        tenant_id IS NULL, is_active, 0, created_at::text
		 FROM equipment_templates
		 WHERE id = $1 AND (tenant_id IS NULL OR tenant_id = $2)`,
		id, claims.TenantID,
	).Scan(
		&t.ID, &t.TenantID, &t.Manufacturer, &t.Model, &t.Category, &t.NodeType,
		&t.Description, &t.Notes, &t.Tags, &t.IsGlobal, &t.IsActive,
		&t.NodeCount, &t.CreatedAt,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Plantilla no encontrada")
	}

	// Nodes using this template
	nodeRows, _ := h.db.Query(c.UserContext(),
		`SELECT id, name, code, node_type, status, criticality
		 FROM factory_nodes
		 WHERE template_id = $1 AND tenant_id = $2 AND status != 'decommissioned'
		 ORDER BY name`,
		id, claims.TenantID,
	)

	type NodeSummary struct {
		ID          int64   `json:"id"`
		Name        string  `json:"name"`
		Code        *string `json:"code"`
		NodeType    string  `json:"node_type"`
		Status      string  `json:"status"`
		Criticality string  `json:"criticality"`
	}

	var nodes []NodeSummary
	if nodeRows != nil {
		defer nodeRows.Close()
		for nodeRows.Next() {
			var n NodeSummary
			if err := nodeRows.Scan(&n.ID, &n.Name, &n.Code, &n.NodeType,
				&n.Status, &n.Criticality); err == nil {
				nodes = append(nodes, n)
			}
		}
	}

	return c.JSON(fiber.Map{
		"template": t,
		"nodes":    nodes,
	})
}

// ─── POST /templates ──────────────────────────────────────────────────────────

type templateRequest struct {
	Manufacturer string   `json:"manufacturer"`
	Model        string   `json:"model"`
	Category     *string  `json:"category"`
	NodeType     string   `json:"node_type"`
	Description  *string  `json:"description"`
	Notes        *string  `json:"notes"`
	Tags         []string `json:"tags"`
}

func (h *TemplatesHandler) Create(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req templateRequest
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}
	if req.Manufacturer == "" || req.Model == "" {
		return fiber.NewError(fiber.StatusBadRequest, "Fabricante y modelo son requeridos")
	}
	if req.NodeType == "" {
		req.NodeType = "equipment"
	}

	var newID int64
	err := h.db.QueryRow(c.UserContext(),
		`INSERT INTO equipment_templates
		 (tenant_id, manufacturer, model, category, node_type, description, notes, tags, created_by)
		 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`,
		claims.TenantID, req.Manufacturer, req.Model, req.Category,
		req.NodeType, req.Description, req.Notes, req.Tags, claims.UserID,
	).Scan(&newID)
	if err != nil {
		return fiber.NewError(fiber.StatusConflict,
			"Ya existe una plantilla para ese fabricante y modelo")
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"id":      newID,
		"message": "Plantilla creada",
	})
}

// ─── PUT /templates/:id ───────────────────────────────────────────────────────

func (h *TemplatesHandler) Update(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req templateRequest
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	// Only templates owned by the tenant can be edited
	result, err := h.db.Exec(c.UserContext(),
		`UPDATE equipment_templates
		 SET manufacturer=$1, model=$2, category=$3, node_type=$4,
		     description=$5, notes=$6, tags=$7
		 WHERE id=$8 AND tenant_id=$9`,
		req.Manufacturer, req.Model, req.Category, req.NodeType,
		req.Description, req.Notes, req.Tags,
		id, claims.TenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusForbidden,
			"No se puede editar una plantilla global del sistema. Crea una copia para tu tenant.")
	}

	return c.JSON(fiber.Map{"message": "Plantilla actualizada"})
}

// ─── DELETE /templates/:id ────────────────────────────────────────────────────

func (h *TemplatesHandler) Delete(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	// Check that no nodes are using this template
	var nodeCount int
	h.db.QueryRow(c.UserContext(),
		`SELECT COUNT(*) FROM factory_nodes WHERE template_id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	).Scan(&nodeCount)

	if nodeCount > 0 {
		return fiber.NewError(fiber.StatusBadRequest,
			"No se puede eliminar: hay "+strconv.Itoa(nodeCount)+" nodo(s) usando esta plantilla.")
	}

	result, err := h.db.Exec(c.UserContext(),
		`UPDATE equipment_templates SET is_active=false WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusForbidden, "No se puede eliminar una plantilla global")
	}

	return c.JSON(fiber.Map{"message": "Plantilla desactivada"})
}

// ─── GET /templates/:id/siblings — sibling nodes for the AI ─────────────────

func (h *TemplatesHandler) GetSiblings(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	rows, err := h.db.Query(c.UserContext(),
		`SELECT node_id, node_name FROM get_sibling_nodes($1, $2)`,
		nodeID, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando hermanos")
	}
	defer rows.Close()

	type Sibling struct {
		NodeID   int64  `json:"node_id"`
		NodeName string `json:"node_name"`
	}

	var siblings []Sibling
	for rows.Next() {
		var s Sibling
		if err := rows.Scan(&s.NodeID, &s.NodeName); err != nil {
			log.Printf("[ARCHE-TPL] WARN: scan sibling: %v", err)
			continue
		}
		siblings = append(siblings, s)
	}

	return c.JSON(fiber.Map{"siblings": siblings, "total": len(siblings)})
}

// ─── PATCH /factory/nodes/:id/template — assign a template to a node ─────────

func (h *TemplatesHandler) AssignToNode(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req struct {
		TemplateID *int64 `json:"template_id"` // null = detach
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	// Check that the template is reachable
	if req.TemplateID != nil {
		var exists bool
		h.db.QueryRow(c.UserContext(),
			`SELECT EXISTS(SELECT 1 FROM equipment_templates
			 WHERE id=$1 AND (tenant_id IS NULL OR tenant_id=$2) AND is_active=true)`,
			req.TemplateID, claims.TenantID,
		).Scan(&exists)
		if !exists {
			return fiber.NewError(fiber.StatusNotFound, "Plantilla no encontrada")
		}
	}

	result, err := h.db.Exec(c.UserContext(),
		`UPDATE factory_nodes SET template_id=$1
		 WHERE id=$2 AND tenant_id=$3`,
		req.TemplateID, nodeID, claims.TenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Nodo no encontrado")
	}

	msg := "Plantilla asignada al nodo"
	if req.TemplateID == nil {
		msg = "Plantilla desasociada del nodo"
	}

	return c.JSON(fiber.Map{"message": msg})
}

// ─── GET /templates/categories — unique categories for filters ──────────────

func (h *TemplatesHandler) GetCategories(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	rows, err := h.db.Query(c.UserContext(),
		`SELECT DISTINCT category FROM equipment_templates
		 WHERE category IS NOT NULL AND is_active = true
		   AND (tenant_id IS NULL OR tenant_id = $1)
		 ORDER BY category`,
		claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error")
	}
	defer rows.Close()

	var categories []string
	for rows.Next() {
		var cat string
		if err := rows.Scan(&cat); err != nil {
			log.Printf("[ARCHE-TPL] WARN: scan category: %v", err)
			continue
		}
		categories = append(categories, cat)
	}

	return c.JSON(fiber.Map{"categories": categories})
}

// ─── GET /templates/:id/library — attachments of the template ──────────

func (h *TemplatesHandler) ListLibrary(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	templateID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	folderID := c.Query("folder_id")

	query := `
		SELECT a.id, a.original_name, a.mime_type, a.file_size,
		       a.category, a.description, a.template_folder_id,
		       COALESCE(u.full_name, 'Sistema') AS uploaded_by, a.created_at::text
		FROM attachments a
		LEFT JOIN users u ON u.id = a.uploaded_by
		WHERE a.template_id = $1 AND a.tenant_id = $2`

	args := []interface{}{templateID, claims.TenantID}
	if folderID != "" && folderID != "0" {
		fid, _ := strconv.ParseInt(folderID, 10, 64)
		query += ` AND a.template_folder_id = $3`
		args = append(args, fid)
	} else if folderID == "" {
		query += ` AND a.template_folder_id IS NULL`
	}
	query += ` ORDER BY a.created_at DESC`

	rows, err := h.db.Query(c.UserContext(), query, args...)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando biblioteca de plantilla")
	}
	defer rows.Close()

	type TemplateAttachment struct {
		ID         int64   `json:"id"`
		Name       string  `json:"original_name"`
		MimeType   string  `json:"mime_type"`
		FileSize   int64   `json:"file_size"`
		Category   *string `json:"category"`
		Desc       *string `json:"description"`
		FolderID   *int64  `json:"template_folder_id"`
		UploadedBy string  `json:"uploaded_by"`
		CreatedAt  string  `json:"created_at"`
	}

	var attachments []TemplateAttachment
	for rows.Next() {
		var a TemplateAttachment
		if err := rows.Scan(&a.ID, &a.Name, &a.MimeType, &a.FileSize,
			&a.Category, &a.Desc, &a.FolderID, &a.UploadedBy, &a.CreatedAt); err == nil {
			attachments = append(attachments, a)
		}
	}

	// Folders of this template
	folderRows, _ := h.db.Query(c.UserContext(),
		`SELECT id, name, parent_id, created_at::text
		 FROM template_folders
		 WHERE template_id = $1 AND tenant_id = $2
		 ORDER BY name`,
		templateID, claims.TenantID,
	)

	type Folder struct {
		ID        int64  `json:"id"`
		Name      string `json:"name"`
		ParentID  *int64 `json:"parent_id"`
		CreatedAt string `json:"created_at"`
	}

	var folders []Folder
	if folderRows != nil {
		defer folderRows.Close()
		for folderRows.Next() {
			var f Folder
			if err := folderRows.Scan(&f.ID, &f.Name, &f.ParentID, &f.CreatedAt); err != nil {
				log.Printf("[ARCHE-TPL] WARN: scan folder: %v", err)
				continue
			}
			folders = append(folders, f)
		}
	}

	return c.JSON(fiber.Map{
		"attachments": attachments,
		"folders":     folders,
		"total":       len(attachments),
	})
}

// ─── POST /templates/:id/library/upload — upload a file to a template ──────────

func (h *TemplatesHandler) UploadToTemplate(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	templateID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	file, err := c.FormFile("file")
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Archivo requerido")
	}

	const maxSize = 50 * 1024 * 1024 // 50MB
	if file.Size > maxSize {
		return fiber.NewError(fiber.StatusBadRequest, "El archivo excede 50MB")
	}

	category := c.FormValue("category", "other")
	description := c.FormValue("description", "")
	folderIDStr := c.FormValue("folder_id", "")

	var folderID *int64
	if folderIDStr != "" && folderIDStr != "0" {
		fid, _ := strconv.ParseInt(folderIDStr, 10, 64)
		if fid > 0 {
			folderID = &fid
		}
	}

	// Sanitize the name
	safeName := strings.ReplaceAll(file.Filename, "/", "_")
	safeName = strings.ReplaceAll(safeName, "\\", "_")
	safeName = strings.ReplaceAll(safeName, ":", "_")
	safeName = strings.ReplaceAll(safeName, "*", "_")

	// Save the file
	src, err := file.Open()
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error leyendo archivo")
	}
	defer src.Close()

	uploadDir := fmt.Sprintf("/tmp/arche_uploads/tenant_%d/templates", claims.TenantID)
	os.MkdirAll(uploadDir, 0755)

	sysName := fmt.Sprintf("%d_%d_%s", time.Now().Unix(), templateID, safeName)
	destPath := filepath.Join(uploadDir, sysName)

	dst, err := os.Create(destPath)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error guardando archivo")
	}
	defer dst.Close()

	if _, err := io.Copy(dst, src); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error escribiendo archivo")
	}

	mimeType := file.Header.Get("Content-Type")
	if mimeType == "" {
		mimeType = "application/octet-stream"
	}

	var newID int64
	err = h.db.QueryRow(c.UserContext(),
		`INSERT INTO attachments
		 (tenant_id, template_id, template_folder_id, file_name, original_name,
		  mime_type, file_size, file_path, category, description, uploaded_by)
		 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id`,
		claims.TenantID, templateID, folderID,
		sysName, file.Filename,
		mimeType, file.Size, destPath,
		category, description, claims.UserID,
	).Scan(&newID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error registrando archivo")
	}

	// Index it for the AI
	ai.EnqueueNow(context.Background(), h.db, claims.TenantID, "index", "attachment", newID)

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"id":      newID,
		"message": "Archivo subido a la plantilla",
	})
}

// ─── DELETE /templates/library/:attId — delete a template file ────────

func (h *TemplatesHandler) DeleteTemplateFile(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	attID, err := strconv.ParseInt(c.Params("attId"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	// Get the path so the physical file can be removed
	var filePath string
	err = h.db.QueryRow(c.UserContext(),
		`SELECT file_path FROM attachments
		 WHERE id=$1 AND tenant_id=$2 AND template_id IS NOT NULL`,
		attID, claims.TenantID,
	).Scan(&filePath)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Archivo no encontrado")
	}

	// Delete it from the DB
	_, err = h.db.Exec(c.UserContext(),
		`DELETE FROM attachments WHERE id=$1 AND tenant_id=$2 AND template_id IS NOT NULL`,
		attID, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error eliminando archivo")
	}

	// Delete the physical file (best effort)
	os.Remove(filePath)

	// Delete the associated embeddings
	h.db.Exec(c.UserContext(),
		`DELETE FROM ai_embeddings WHERE tenant_id=$1 AND source_type='attachment' AND source_id=$2`,
		claims.TenantID, attID,
	)

	return c.JSON(fiber.Map{"message": "Archivo eliminado de la plantilla"})
}

// ─── GET /templates/:id/folders ──────────────────────────────────────────────

func (h *TemplatesHandler) ListFolders(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	templateID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	rows, err := h.db.Query(c.UserContext(),
		`SELECT id, name, parent_id, created_at::text
		 FROM template_folders
		 WHERE template_id = $1 AND tenant_id = $2
		 ORDER BY name`,
		templateID, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando carpetas")
	}
	defer rows.Close()

	type Folder struct {
		ID        int64  `json:"id"`
		Name      string `json:"name"`
		ParentID  *int64 `json:"parent_id"`
		CreatedAt string `json:"created_at"`
	}

	var folders []Folder
	for rows.Next() {
		var f Folder
		if err := rows.Scan(&f.ID, &f.Name, &f.ParentID, &f.CreatedAt); err != nil {
			log.Printf("[ARCHE-TPL] WARN: scan folder: %v", err)
			continue
		}
		folders = append(folders, f)
	}

	return c.JSON(fiber.Map{"folders": folders})
}

// ─── POST /templates/:id/folders — create a folder in a template ────────────────

func (h *TemplatesHandler) CreateFolder(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	templateID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req struct {
		Name     string `json:"name"`
		ParentID *int64 `json:"parent_id"`
	}
	if err := c.BodyParser(&req); err != nil || req.Name == "" {
		return fiber.NewError(fiber.StatusBadRequest, "El nombre de la carpeta es requerido")
	}

	var newID int64
	err = h.db.QueryRow(c.UserContext(),
		`INSERT INTO template_folders (tenant_id, template_id, name, parent_id)
		 VALUES ($1, $2, $3, $4) RETURNING id`,
		claims.TenantID, templateID, req.Name, req.ParentID,
	).Scan(&newID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error creando carpeta")
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"id":      newID,
		"message": "Carpeta creada",
	})
}

// ─── DELETE /templates/folders/:folderId — delete a folder ──────────────────

func (h *TemplatesHandler) DeleteFolder(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	folderID, err := strconv.ParseInt(c.Params("folderId"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	result, err := h.db.Exec(c.UserContext(),
		`DELETE FROM template_folders WHERE id=$1 AND tenant_id=$2`,
		folderID, claims.TenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Carpeta no encontrada")
	}

	return c.JSON(fiber.Map{"message": "Carpeta eliminada"})
}
