package handlers

import (
	"strconv"

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
	"golang.org/x/crypto/bcrypt"
)

type SignatureHandler struct {
	db *pgxpool.Pool
}

func NewSignatureHandler(db *pgxpool.Pool) *SignatureHandler {
	return &SignatureHandler{db: db}
}

// ─── POST /work-orders/:id/sign — the technician signs the WO ────────────────────────

func (h *SignatureHandler) Sign(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	woID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req struct {
		Password string `json:"password"`
	}
	if err := c.BodyParser(&req); err != nil || req.Password == "" {
		return fiber.NewError(fiber.StatusBadRequest, "La contraseña es requerida para firmar")
	}

	// Check the user's password
	var passwordHash string
	err = h.db.QueryRow(c.UserContext(),
		`SELECT password_hash FROM users WHERE id=$1 AND tenant_id=$2`,
		claims.UserID, claims.TenantID,
	).Scan(&passwordHash)
	if err != nil {
		return fiber.NewError(fiber.StatusUnauthorized, "Usuario no encontrado")
	}

	if err := bcrypt.CompareHashAndPassword([]byte(passwordHash), []byte(req.Password)); err != nil {
		return fiber.NewError(fiber.StatusUnauthorized, "Contraseña incorrecta. La firma no se ha registrado.")
	}

	// Check that the WO is completed and not already signed
	var status string
	var signedBy *int64
	var assignedTo *int64
	err = h.db.QueryRow(c.UserContext(),
		`SELECT status, signed_by, assigned_to FROM work_orders WHERE id=$1 AND tenant_id=$2`,
		woID, claims.TenantID,
	).Scan(&status, &signedBy, &assignedTo)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "OT no encontrada")
	}

	if status != "completed" && status != "verified" {
		return fiber.NewError(fiber.StatusBadRequest, "Solo se pueden firmar OTs completadas o verificadas")
	}

	if signedBy != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Esta OT ya fue firmada anteriormente")
	}

	// Only the assigned technician or a manager can sign
	isAssigned := assignedTo != nil && *assignedTo == claims.UserID
	isManager := claims.Role == "admin" || claims.Role == "supervisor"
	if !isAssigned && !isManager {
		return fiber.NewError(fiber.StatusForbidden,
			"Solo el técnico asignado o un supervisor pueden firmar esta OT")
	}

	// Record the signature
	_, err = h.db.Exec(c.UserContext(),
		`UPDATE work_orders SET signed_by=$1, signed_at=NOW() WHERE id=$2 AND tenant_id=$3`,
		claims.UserID, woID, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error registrando firma")
	}

	// Immutable log
	logExecErr(h.db.Exec(c.UserContext(),
		`INSERT INTO work_order_log (tenant_id, wo_id, user_id, to_status, comment)
		 VALUES ($1,$2,$3,$4,'Firma digital registrada por el técnico responsable')`,
		claims.TenantID, woID, claims.UserID, status,
	)).Log("sig-tech-log")

	return c.JSON(fiber.Map{
		"message":   "Firma digital registrada correctamente",
		"signed_at": "ahora",
	})
}

// ─── POST /work-orders/:id/supervisor-sign — the supervisor signs the verification ─

func (h *SignatureHandler) SupervisorSign(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	if claims.Role != "admin" && claims.Role != "supervisor" {
		return fiber.NewError(fiber.StatusForbidden, "Solo supervisores y administradores pueden firmar como supervisor")
	}

	woID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req struct {
		Password string `json:"password"`
	}
	if err := c.BodyParser(&req); err != nil || req.Password == "" {
		return fiber.NewError(fiber.StatusBadRequest, "La contraseña es requerida para firmar")
	}

	// Check the password
	var passwordHash string
	err = h.db.QueryRow(c.UserContext(),
		`SELECT password_hash FROM users WHERE id=$1 AND tenant_id=$2`,
		claims.UserID, claims.TenantID,
	).Scan(&passwordHash)
	if err != nil {
		return fiber.NewError(fiber.StatusUnauthorized, "Usuario no encontrado")
	}

	if err := bcrypt.CompareHashAndPassword([]byte(passwordHash), []byte(req.Password)); err != nil {
		return fiber.NewError(fiber.StatusUnauthorized, "Contraseña incorrecta")
	}

	// Check that the WO is verified
	var status string
	var supSignedBy *int64
	err = h.db.QueryRow(c.UserContext(),
		`SELECT status, supervisor_signed_by FROM work_orders WHERE id=$1 AND tenant_id=$2`,
		woID, claims.TenantID,
	).Scan(&status, &supSignedBy)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "OT no encontrada")
	}

	if status != "verified" && status != "closed" {
		return fiber.NewError(fiber.StatusBadRequest, "Solo se pueden firmar OTs verificadas")
	}

	if supSignedBy != nil {
		return fiber.NewError(fiber.StatusBadRequest, "El supervisor ya firmó esta OT")
	}

	_, err = h.db.Exec(c.UserContext(),
		`UPDATE work_orders SET supervisor_signed_by=$1, supervisor_signed_at=NOW()
		 WHERE id=$2 AND tenant_id=$3`,
		claims.UserID, woID, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error registrando firma")
	}

	logExecErr(h.db.Exec(c.UserContext(),
		`INSERT INTO work_order_log (tenant_id, wo_id, user_id, to_status, comment)
		 VALUES ($1,$2,$3,$4,'Firma digital del supervisor registrada')`,
		claims.TenantID, woID, claims.UserID, status,
	)).Log("sig-sup-log")

	return c.JSON(fiber.Map{"message": "Firma del supervisor registrada correctamente"})
}

// ─── GET /work-orders/:id/signatures — signature status ──────────────────────

func (h *SignatureHandler) GetSignatures(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	woID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	type SigInfo struct {
		SignedBy             *int64  `json:"signed_by"`
		SignedByName         *string `json:"signed_by_name"`
		SignedAt             *string `json:"signed_at"`
		SupervisorSignedBy   *int64  `json:"supervisor_signed_by"`
		SupervisorSignedName *string `json:"supervisor_signed_name"`
		SupervisorSignedAt   *string `json:"supervisor_signed_at"`
	}

	var s SigInfo
	h.db.QueryRow(c.UserContext(),
		`SELECT wo.signed_by, u1.full_name, wo.signed_at::text,
		        wo.supervisor_signed_by, u2.full_name, wo.supervisor_signed_at::text
		 FROM work_orders wo
		 LEFT JOIN users u1 ON u1.id=wo.signed_by
		 LEFT JOIN users u2 ON u2.id=wo.supervisor_signed_by
		 WHERE wo.id=$1 AND wo.tenant_id=$2`,
		woID, claims.TenantID,
	).Scan(
		&s.SignedBy, &s.SignedByName, &s.SignedAt,
		&s.SupervisorSignedBy, &s.SupervisorSignedName, &s.SupervisorSignedAt,
	)

	return c.JSON(s)
}
