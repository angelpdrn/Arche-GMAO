package handlers

import (
	"context"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"

	"arche-gmao/api/internal/ai"
	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type MaintenanceHandler struct {
	db *pgxpool.Pool
}

func NewMaintenanceHandler(db *pgxpool.Pool) *MaintenanceHandler {
	return &MaintenanceHandler{db: db}
}

// ─── GET /maintenance-plans — list plans ───────────────────────────────────

func (h *MaintenanceHandler) List(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID := c.Query("node_id")
	active := c.Query("active", "true")

	query := `
		SELECT mp.id, mp.node_id, fn.name AS node_name, fn.code AS node_code,
		       mp.title, mp.description, mp.wo_type, mp.priority,
		       mp.frequency_type, mp.frequency_value, mp.advance_days,
		       mp.assigned_to, u.full_name AS assigned_name,
		       mp.estimated_hours, mp.is_active,
		       mp.last_executed_at::text, mp.next_due_at::text,
		       mp.total_executions, mp.created_at::text,
		       EXTRACT(DAY FROM (mp.next_due_at - NOW()))::INT AS days_until_due,
		       mp.apply_to_children,
		       mp.instructions IS NOT NULL AS has_instructions,
		       COALESCE(jsonb_array_length(mp.checklist),0) AS checklist_count,
		       mp.equipment_template_id, et.manufacturer AS template_manufacturer, et.model AS template_model
		FROM maintenance_plans mp
		LEFT JOIN factory_nodes fn ON fn.id = mp.node_id
		LEFT JOIN equipment_templates et ON et.id = mp.equipment_template_id
		LEFT JOIN users u ON u.id = mp.assigned_to
		WHERE mp.tenant_id = $1`

	args := []interface{}{claims.TenantID}
	argIdx := 2

	if active == "true" {
		query += ` AND mp.is_active = true`
	}
	if nodeID != "" {
		query += ` AND mp.node_id = $` + strconv.Itoa(argIdx)
		args = append(args, nodeID)
		argIdx++
	}

	// Roles with a limited scope only see plans for their assigned nodes, or by template of their nodes
	if claims.Role != "admin" && claims.Role != "auditor" {
		query += ` AND (
			mp.node_id IN (
				SELECT fn2.id FROM factory_nodes fn2
				JOIN node_assignments na ON na.user_id = $` + strconv.Itoa(argIdx) + ` AND na.tenant_id = $1
				JOIN factory_nodes assigned ON assigned.id = na.node_id AND assigned.tenant_id = $1
				WHERE fn2.tenant_id = $1 AND fn2.path <@ assigned.path
			)
			OR mp.equipment_template_id IN (
				SELECT fn3.template_id FROM factory_nodes fn3
				JOIN node_assignments na2 ON na2.user_id = $` + strconv.Itoa(argIdx) + ` AND na2.tenant_id = $1
				JOIN factory_nodes assigned2 ON assigned2.id = na2.node_id AND assigned2.tenant_id = $1
				WHERE fn3.tenant_id = $1 AND fn3.path <@ assigned2.path AND fn3.template_id IS NOT NULL
			)
		)`
		args = append(args, claims.UserID)
		argIdx++
	}

	query += ` ORDER BY mp.next_due_at ASC NULLS LAST`

	rows, err := h.db.Query(c.UserContext(), query, args...)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando planes")
	}
	defer rows.Close()

	type Plan struct {
		ID                   int64    `json:"id"`
		NodeID               *int64   `json:"node_id"`
		NodeName             *string  `json:"node_name"`
		NodeCode             *string  `json:"node_code"`
		Title                string   `json:"title"`
		Description          *string  `json:"description"`
		WOType               string   `json:"wo_type"`
		Priority             string   `json:"priority"`
		FrequencyType        string   `json:"frequency_type"`
		FrequencyValue       int      `json:"frequency_value"`
		AdvanceDays          int      `json:"advance_days"`
		AssignedTo           *int64   `json:"assigned_to"`
		AssignedName         *string  `json:"assigned_name"`
		EstimatedHours       *float64 `json:"estimated_hours"`
		IsActive             bool     `json:"is_active"`
		LastExecutedAt       *string  `json:"last_executed_at"`
		NextDueAt            *string  `json:"next_due_at"`
		TotalExecutions      int      `json:"total_executions"`
		CreatedAt            string   `json:"created_at"`
		DaysUntilDue         *int     `json:"days_until_due"`
		ApplyToChildren      bool     `json:"apply_to_children"`
		HasInstructions      bool     `json:"has_instructions"`
		ChecklistCount       int      `json:"checklist_count"`
		EquipmentTemplateID  *int64   `json:"equipment_template_id"`
		TemplateManufacturer *string  `json:"template_manufacturer"`
		TemplateModel        *string  `json:"template_model"`
	}

	var plans []Plan
	for rows.Next() {
		var p Plan
		if err := rows.Scan(
			&p.ID, &p.NodeID, &p.NodeName, &p.NodeCode,
			&p.Title, &p.Description, &p.WOType, &p.Priority,
			&p.FrequencyType, &p.FrequencyValue, &p.AdvanceDays,
			&p.AssignedTo, &p.AssignedName,
			&p.EstimatedHours, &p.IsActive,
			&p.LastExecutedAt, &p.NextDueAt,
			&p.TotalExecutions, &p.CreatedAt,
			&p.DaysUntilDue,
			&p.ApplyToChildren, &p.HasInstructions, &p.ChecklistCount,
			&p.EquipmentTemplateID, &p.TemplateManufacturer, &p.TemplateModel,
		); err == nil {
			plans = append(plans, p)
		}
	}

	return c.JSON(fiber.Map{"plans": plans, "total": len(plans)})
}

// ─── POST /maintenance-plans ──────────────────────────────────────────────────

func (h *MaintenanceHandler) Create(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req struct {
		NodeID              int64            `json:"node_id"`
		EquipmentTemplateID *int64           `json:"equipment_template_id"`
		SourceTemplateID    *int64           `json:"source_template_id"`
		Title               string           `json:"title"`
		Description         *string          `json:"description"`
		WOType              string           `json:"wo_type"`
		Priority            string           `json:"priority"`
		FrequencyType       string           `json:"frequency_type"`
		FrequencyValue      int              `json:"frequency_value"`
		AdvanceDays         int              `json:"advance_days"`
		AssignedTo          *int64           `json:"assigned_to"`
		EstimatedHours      *float64         `json:"estimated_hours"`
		StartDate           *string          `json:"start_date"`
		ApplyToChildren     bool             `json:"apply_to_children"`
		Instructions        *string          `json:"instructions"`
		Checklist           json.RawMessage  `json:"checklist"`
		SafetyNotes         *string          `json:"safety_notes"`
		ToolsRequired       json.RawMessage  `json:"tools_required"`
		RequiredParts       json.RawMessage  `json:"required_parts"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	hasNode := req.NodeID > 0
	hasTemplate := req.EquipmentTemplateID != nil && *req.EquipmentTemplateID > 0
	if !hasNode && !hasTemplate {
		return fiber.NewError(fiber.StatusBadRequest, "Debe seleccionar un nodo o una plantilla de equipo")
	}
	if req.Title == "" || req.FrequencyType == "" || req.FrequencyValue == 0 {
		return fiber.NewError(fiber.StatusBadRequest, "Faltan campos obligatorios")
	}
	if req.WOType == "" { req.WOType = "preventive" }
	if req.Priority == "" { req.Priority = "medium" }
	if req.AdvanceDays == 0 { req.AdvanceDays = 3 }

	// Compute the first due date
	var nextDue time.Time
	if req.StartDate != nil && *req.StartDate != "" {
		parsed, err := time.Parse("2006-01-02", *req.StartDate)
		if err == nil {
			nextDue = parsed
		}
	}
	if nextDue.IsZero() {
		// By default: first run according to the frequency, starting today
		switch req.FrequencyType {
		case "days":
			nextDue = time.Now().AddDate(0, 0, req.FrequencyValue)
		case "weeks":
			nextDue = time.Now().AddDate(0, 0, req.FrequencyValue*7)
		case "months":
			nextDue = time.Now().AddDate(0, req.FrequencyValue, 0)
		default:
			nextDue = time.Now().AddDate(0, 1, 0)
		}
	}

	// Normalize empty JSONB values
	checklist := normalizeJSON(req.Checklist, "[]")
	toolsReq := normalizeJSON(req.ToolsRequired, "[]")
	reqParts := normalizeJSON(req.RequiredParts, "[]")

	// node_id is nullable: with no node, insert NULL
	var nodeIDPtr *int64
	if hasNode {
		nodeIDPtr = &req.NodeID
	}
	var eqTemplatePtr *int64
	if hasTemplate {
		eqTemplatePtr = req.EquipmentTemplateID
	}

	var newID int64
	err := h.db.QueryRow(c.UserContext(),
		`INSERT INTO maintenance_plans
		 (tenant_id, node_id, equipment_template_id, source_template_id,
		  title, description, wo_type, priority,
		  frequency_type, frequency_value, advance_days, assigned_to,
		  estimated_hours, next_due_at, created_by,
		  apply_to_children, instructions, checklist, safety_notes,
		  tools_required, required_parts)
		 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21) RETURNING id`,
		claims.TenantID, nodeIDPtr, eqTemplatePtr, req.SourceTemplateID,
		req.Title, req.Description,
		req.WOType, req.Priority, req.FrequencyType, req.FrequencyValue,
		req.AdvanceDays, req.AssignedTo, req.EstimatedHours,
		nextDue, claims.UserID,
		req.ApplyToChildren, req.Instructions, checklist, req.SafetyNotes,
		toolsReq, reqParts,
	).Scan(&newID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error creando plan de mantenimiento")
	}

	// Queue AI indexing
	ai.EnqueueNow(context.Background(), h.db, claims.TenantID, "index", "maintenance_plan", newID)

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"id":      newID,
		"message": "Plan de mantenimiento creado",
	})
}

// ─── PUT /maintenance-plans/:id ───────────────────────────────────────────────

func (h *MaintenanceHandler) Update(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req struct {
		NodeID              *int64           `json:"node_id"`
		EquipmentTemplateID *int64           `json:"equipment_template_id"`
		Title               string           `json:"title"`
		Description         *string          `json:"description"`
		WOType              string           `json:"wo_type"`
		Priority            string           `json:"priority"`
		FrequencyType       string           `json:"frequency_type"`
		FrequencyValue      int              `json:"frequency_value"`
		AdvanceDays         int              `json:"advance_days"`
		AssignedTo          *int64           `json:"assigned_to"`
		EstimatedHours      *float64         `json:"estimated_hours"`
		IsActive            bool             `json:"is_active"`
		NextDueAt           *string          `json:"next_due_at"`
		ApplyToChildren     bool             `json:"apply_to_children"`
		Instructions        *string          `json:"instructions"`
		Checklist           json.RawMessage  `json:"checklist"`
		SafetyNotes         *string          `json:"safety_notes"`
		ToolsRequired       json.RawMessage  `json:"tools_required"`
		RequiredParts       json.RawMessage  `json:"required_parts"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	checklist := normalizeJSON(req.Checklist, "[]")
	toolsReq := normalizeJSON(req.ToolsRequired, "[]")
	reqParts := normalizeJSON(req.RequiredParts, "[]")

	result, err := h.db.Exec(c.UserContext(),
		`UPDATE maintenance_plans SET
		 title=$1, description=$2, wo_type=$3, priority=$4,
		 frequency_type=$5, frequency_value=$6, advance_days=$7,
		 assigned_to=$8, estimated_hours=$9, is_active=$10,
		 next_due_at=COALESCE($11::date, next_due_at),
		 apply_to_children=$14, instructions=$15, checklist=$16,
		 safety_notes=$17, tools_required=$18, required_parts=$19,
		 node_id=$20, equipment_template_id=$21
		 WHERE id=$12 AND tenant_id=$13`,
		req.Title, req.Description, req.WOType, req.Priority,
		req.FrequencyType, req.FrequencyValue, req.AdvanceDays,
		req.AssignedTo, req.EstimatedHours, req.IsActive,
		req.NextDueAt, id, claims.TenantID,
		req.ApplyToChildren, req.Instructions, checklist,
		req.SafetyNotes, toolsReq, reqParts,
		req.NodeID, req.EquipmentTemplateID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Plan no encontrado")
	}

	// Queue AI re-indexing
	ai.EnqueueNow(context.Background(), h.db, claims.TenantID, "reindex", "maintenance_plan", id)

	return c.JSON(fiber.Map{"message": "Plan actualizado"})
}

// ─── DELETE /maintenance-plans/:id ────────────────────────────────────────────

func (h *MaintenanceHandler) Delete(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	result, err := h.db.Exec(c.UserContext(),
		`UPDATE maintenance_plans SET is_active=false WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Plan no encontrado")
	}

	// Clear the AI embeddings of the deactivated plan
	planID := id
	tenantID := claims.TenantID
	go func() {
		bgCtx := context.Background()
		logExecErr(h.db.Exec(bgCtx,
			`DELETE FROM ai_embeddings WHERE source_type='maintenance_plan' AND source_id=$1 AND tenant_id=$2`,
			planID, tenantID)).Log("maint-del-embed")
		logExecErr(h.db.Exec(bgCtx,
			`DELETE FROM ai_index_queue WHERE source_type='maintenance_plan' AND source_id=$1 AND tenant_id=$2 AND status='pending'`,
			planID, tenantID)).Log("maint-del-queue")
	}()

	return c.JSON(fiber.Map{"message": "Plan desactivado"})
}

// ─── GET /maintenance-plans/upcoming — upcoming due dates ─────────────────

func (h *MaintenanceHandler) Upcoming(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	days, _ := strconv.Atoi(c.Query("days", "30"))

	query := `SELECT mp.id AS plan_id, mp.node_id, COALESCE(fn.name, ''), COALESCE(fn.code, ''), COALESCE(fn.criticality, 'medium'),
		        mp.title, mp.wo_type, mp.priority, u.full_name AS assigned_name,
		        mp.next_due_at::text,
		        EXTRACT(DAY FROM (mp.next_due_at - NOW()))::INT AS days_until_due,
		        mp.total_executions
		 FROM maintenance_plans mp
		 LEFT JOIN factory_nodes fn ON fn.id = mp.node_id
		 LEFT JOIN users u ON u.id = mp.assigned_to
		 WHERE mp.tenant_id = $1
		   AND mp.is_active = true
		   AND mp.next_due_at <= NOW() + make_interval(days => $2)`
	args := []interface{}{claims.TenantID, days}
	argIdx := 3

	// Scope by assigned nodes
	if claims.Role != "admin" && claims.Role != "auditor" {
		query += ` AND mp.node_id IN (
			SELECT fn2.id FROM factory_nodes fn2
			JOIN node_assignments na ON na.user_id = $` + strconv.Itoa(argIdx) + ` AND na.tenant_id = $1
			JOIN factory_nodes assigned ON assigned.id = na.node_id AND assigned.tenant_id = $1
			WHERE fn2.tenant_id = $1 AND fn2.path <@ assigned.path
		)`
		args = append(args, claims.UserID)
		argIdx++
	}

	query += ` ORDER BY mp.next_due_at ASC LIMIT 50`

	rows, err := h.db.Query(c.UserContext(), query, args...)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error")
	}
	defer rows.Close()

	type Upcoming struct {
		PlanID          int64   `json:"plan_id"`
		NodeID          *int64  `json:"node_id"`
		NodeName        string  `json:"node_name"`
		NodeCode        *string `json:"node_code"`
		Criticality     string  `json:"criticality"`
		Title           string  `json:"title"`
		WOType          string  `json:"wo_type"`
		Priority        string  `json:"priority"`
		AssignedName    *string `json:"assigned_name"`
		NextDueAt       string  `json:"next_due_at"`
		DaysUntilDue    *int    `json:"days_until_due"`
		TotalExecutions int     `json:"total_executions"`
	}

	var items []Upcoming
	for rows.Next() {
		var u Upcoming
		if rows.Scan(
			&u.PlanID, &u.NodeID, &u.NodeName, &u.NodeCode, &u.Criticality,
			&u.Title, &u.WOType, &u.Priority, &u.AssignedName,
			&u.NextDueAt, &u.DaysUntilDue, &u.TotalExecutions,
		) == nil {
			items = append(items, u)
		}
	}

	return c.JSON(fiber.Map{"upcoming": items, "total": len(items)})
}

// ─── POST /maintenance-plans/:id/execute — run it manually ───────────────

func (h *MaintenanceHandler) Execute(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	ctx := c.UserContext()

	// Get the full plan
	var (
		nodeID              *int64
		eqTemplateID        *int64
		title               string
		planDesc            *string
		woType              string
		priority            string
		assignedTo          *int64
		estHours            *float64
		freqType            string
		freqVal             int
		nextDueAt           time.Time
		applyToChildren     bool
		instructions        *string
		checklist           json.RawMessage
		safetyNotes         *string
		toolsRequired       json.RawMessage
		requiredParts       json.RawMessage
	)

	err = h.db.QueryRow(ctx,
		`SELECT node_id, equipment_template_id, title, description, wo_type, priority, assigned_to,
		        estimated_hours, frequency_type, frequency_value,
		        COALESCE(next_due_at, NOW()),
		        apply_to_children, instructions,
		        COALESCE(checklist,'[]'), safety_notes,
		        COALESCE(tools_required,'[]'), COALESCE(required_parts,'[]')
		 FROM maintenance_plans WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	).Scan(&nodeID, &eqTemplateID, &title, &planDesc, &woType, &priority, &assignedTo,
		&estHours, &freqType, &freqVal, &nextDueAt,
		&applyToChildren, &instructions,
		&checklist, &safetyNotes,
		&toolsRequired, &requiredParts)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Plan no encontrado")
	}

	woDescription := buildWODescription(planDesc, instructions, checklist, safetyNotes, toolsRequired, requiredParts)

	generateWONumber := func() string {
		var num string
		tx, txErr := h.db.Begin(ctx)
		if txErr != nil {
			return "OT-" + time.Now().Format("20060102") + "-0001"
		}
		defer tx.Rollback(ctx)

		tx.Exec(ctx, `SELECT pg_advisory_xact_lock($1)`, claims.TenantID)
		tx.QueryRow(ctx,
			`SELECT 'OT-' || TO_CHAR(NOW(),'YYYYMMDD') || '-' ||
			 LPAD((COALESCE(MAX(CAST(SUBSTRING(wo_number FROM 14) AS INT)),0)+1)::text,4,'0')
			 FROM work_orders WHERE wo_number LIKE 'OT-' || TO_CHAR(NOW(),'YYYYMMDD') || '-%' AND tenant_id=$1`,
			claims.TenantID,
		).Scan(&num)
		tx.Commit(ctx)
		if num == "" {
			num = "OT-" + time.Now().Format("20060102") + "-0001"
		}
		return num
	}

	// Helper for creating a single WO
	createWO := func(targetNodeID int64, targetName string, suffix string) *fiber.Map {
		woNumber := generateWONumber()
		woTitle := "[PM] " + title
		if suffix != "" {
			woTitle += " — " + suffix
		}
		var woID int64
		if h.db.QueryRow(ctx,
			`INSERT INTO work_orders
			 (tenant_id, node_id, wo_number, title, description, wo_type, priority,
			  status, assigned_to, estimated_hours, created_by)
			 VALUES ($1,$2,$3,$4,$5,$6,$7,'pending',$8,$9,$10) RETURNING id`,
			claims.TenantID, targetNodeID, woNumber,
			woTitle, woDescription, woType, priority,
			assignedTo, estHours, claims.UserID,
		).Scan(&woID) != nil {
			return nil
		}
		logExecErr(h.db.Exec(ctx,
			`INSERT INTO work_order_log (tenant_id, wo_id, user_id, to_status, comment)
			 VALUES ($1,$2,$3,'pending','OT generada desde plan de mantenimiento preventivo')`,
			claims.TenantID, woID, claims.UserID)).Log("maint-wo-log")
		logExecErr(h.db.Exec(ctx,
			`INSERT INTO maintenance_plan_executions
			 (plan_id, tenant_id, wo_id, target_node_id, created_by, notes)
			 VALUES ($1,$2,$3,$4,$5,$6)`,
			id, claims.TenantID, woID, targetNodeID, claims.UserID,
			"Ejecución manual — "+targetName)).Log("maint-plan-exec")

		// Link the plan's spare parts to the WO
		linkPartsToWO(ctx, h.db, claims.TenantID, woID, requiredParts)

		// Notify the assigned technician
		if assignedTo != nil {
			logExecErr(h.db.Exec(ctx,
				`INSERT INTO notifications (tenant_id, user_id, type, title, body, link)
				 VALUES ($1,$2,'wo_assigned',$3,$4,'/work-orders')`,
				claims.TenantID, *assignedTo,
				"OT preventiva asignada: "+woNumber,
				"Se te ha asignado la OT preventiva: "+woTitle,
			)).Log("maint-notif")
		}

		return &fiber.Map{"wo_id": woID, "wo_number": woNumber, "node_name": targetName}
	}

	var generatedWOs []fiber.Map

	if eqTemplateID != nil && *eqTemplateID > 0 {
		// Plan by equipment template: generate a WO for every node using that template
		tRows, tErr := h.db.Query(ctx,
			`SELECT fn.id, fn.name FROM factory_nodes fn
			 WHERE fn.template_id=$1 AND fn.tenant_id=$2
			   AND fn.id NOT IN (SELECT node_id FROM maintenance_plan_exclusions WHERE plan_id=$3 AND tenant_id=$2)
			 ORDER BY fn.name LIMIT 50`,
			*eqTemplateID, claims.TenantID, id,
		)
		if tErr == nil {
			defer tRows.Close()
			for tRows.Next() {
				var tID int64
				var tName string
				if tRows.Scan(&tID, &tName) == nil {
					if wo := createWO(tID, tName, tName); wo != nil {
						generatedWOs = append(generatedWOs, *wo)
					}
				}
			}
		}
	} else if applyToChildren && nodeID != nil {
		// Find the node's children, leaving out the excluded ones
		childRows, childErr := h.db.Query(ctx,
			`SELECT fn.id, fn.name FROM factory_nodes fn
			 JOIN factory_nodes parent ON parent.id=$1 AND parent.tenant_id=$2
			 WHERE fn.path <@ parent.path AND fn.id != $1
			   AND fn.node_type IN ('equipment','component','measurement_point')
			   AND fn.tenant_id=$2
			   AND fn.id NOT IN (SELECT node_id FROM maintenance_plan_exclusions WHERE plan_id=$3 AND tenant_id=$2)
			 ORDER BY fn.path LIMIT 50`,
			*nodeID, claims.TenantID, id,
		)
		if childErr == nil {
			defer childRows.Close()
			for childRows.Next() {
				var childID int64
				var childName string
				if childRows.Scan(&childID, &childName) == nil {
					if wo := createWO(childID, childName, childName); wo != nil {
						generatedWOs = append(generatedWOs, *wo)
					}
				}
			}
		}
	} else if nodeID != nil {
		// Simple execution on the plan's node
		if wo := createWO(*nodeID, title, ""); wo != nil {
			generatedWOs = append(generatedWOs, *wo)
		}
	}

	// Compute the next date from the original date (avoids drift)
	var nextDue time.Time
	switch freqType {
	case "days":
		nextDue = nextDueAt.AddDate(0, 0, freqVal)
	case "weeks":
		nextDue = nextDueAt.AddDate(0, 0, freqVal*7)
	case "months":
		nextDue = nextDueAt.AddDate(0, freqVal, 0)
	default:
		nextDue = nextDueAt.AddDate(0, 1, 0)
	}
	for nextDue.Before(time.Now()) {
		switch freqType {
		case "days":
			nextDue = nextDue.AddDate(0, 0, freqVal)
		case "weeks":
			nextDue = nextDue.AddDate(0, 0, freqVal*7)
		case "months":
			nextDue = nextDue.AddDate(0, freqVal, 0)
		default:
			nextDue = nextDue.AddDate(0, 1, 0)
		}
	}

	logExecErr(h.db.Exec(ctx,
		`UPDATE maintenance_plans SET
		 last_executed_at=NOW(), next_due_at=$1,
		 total_executions=total_executions+1
		 WHERE id=$2 AND tenant_id=$3`,
		nextDue, id, claims.TenantID,
	)).Log("maint-plan-update")

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"work_orders": generatedWOs,
		"total":       len(generatedWOs),
		"next_due":    nextDue.Format("2006-01-02"),
		"message":     "OTs preventivas generadas correctamente",
	})
}

// ─── GET /maintenance-plans/:id — full detail ───────────────────────────

func (h *MaintenanceHandler) GetOne(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	type PlanDetail struct {
		ID                   int64            `json:"id"`
		NodeID               *int64           `json:"node_id"`
		NodeName             *string          `json:"node_name"`
		NodeCode             *string          `json:"node_code"`
		Title                string           `json:"title"`
		Description          *string          `json:"description"`
		WOType               string           `json:"wo_type"`
		Priority             string           `json:"priority"`
		FrequencyType        string           `json:"frequency_type"`
		FrequencyValue       int              `json:"frequency_value"`
		AdvanceDays          int              `json:"advance_days"`
		AssignedTo           *int64           `json:"assigned_to"`
		AssignedName         *string          `json:"assigned_name"`
		EstimatedHours       *float64         `json:"estimated_hours"`
		IsActive             bool             `json:"is_active"`
		LastExecutedAt       *string          `json:"last_executed_at"`
		NextDueAt            *string          `json:"next_due_at"`
		TotalExecutions      int              `json:"total_executions"`
		CreatedAt            string           `json:"created_at"`
		ApplyToChildren      bool             `json:"apply_to_children"`
		Instructions         *string          `json:"instructions"`
		Checklist            json.RawMessage  `json:"checklist"`
		SafetyNotes          *string          `json:"safety_notes"`
		ToolsRequired        json.RawMessage  `json:"tools_required"`
		RequiredParts        json.RawMessage  `json:"required_parts"`
		EquipmentTemplateID  *int64           `json:"equipment_template_id"`
		TemplateManufacturer *string          `json:"template_manufacturer"`
		TemplateModel        *string          `json:"template_model"`
		SourceTemplateID     *int64           `json:"source_template_id"`
	}

	var p PlanDetail
	err = h.db.QueryRow(c.UserContext(),
		`SELECT mp.id, mp.node_id, fn.name, fn.code,
		        mp.title, mp.description, mp.wo_type, mp.priority,
		        mp.frequency_type, mp.frequency_value, mp.advance_days,
		        mp.assigned_to, u.full_name,
		        mp.estimated_hours, mp.is_active,
		        mp.last_executed_at::text, mp.next_due_at::text,
		        mp.total_executions, mp.created_at::text,
		        mp.apply_to_children,
		        mp.instructions, COALESCE(mp.checklist, '[]'),
		        mp.safety_notes, COALESCE(mp.tools_required, '[]'),
		        COALESCE(mp.required_parts, '[]'),
		        mp.equipment_template_id, et.manufacturer, et.model,
		        mp.source_template_id
		 FROM maintenance_plans mp
		 LEFT JOIN factory_nodes fn ON fn.id = mp.node_id
		 LEFT JOIN equipment_templates et ON et.id = mp.equipment_template_id
		 LEFT JOIN users u ON u.id = mp.assigned_to
		 WHERE mp.id=$1 AND mp.tenant_id=$2`,
		id, claims.TenantID,
	).Scan(
		&p.ID, &p.NodeID, &p.NodeName, &p.NodeCode,
		&p.Title, &p.Description, &p.WOType, &p.Priority,
		&p.FrequencyType, &p.FrequencyValue, &p.AdvanceDays,
		&p.AssignedTo, &p.AssignedName,
		&p.EstimatedHours, &p.IsActive,
		&p.LastExecutedAt, &p.NextDueAt,
		&p.TotalExecutions, &p.CreatedAt,
		&p.ApplyToChildren,
		&p.Instructions, &p.Checklist,
		&p.SafetyNotes, &p.ToolsRequired,
		&p.RequiredParts,
		&p.EquipmentTemplateID, &p.TemplateManufacturer, &p.TemplateModel,
		&p.SourceTemplateID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Plan no encontrado")
	}

	// Execution history
	type Execution struct {
		ID           int64   `json:"id"`
		WOID         *int64  `json:"wo_id"`
		WONumber     *string `json:"wo_number"`
		TargetNodeID *int64  `json:"target_node_id"`
		TargetNode   *string `json:"target_node_name"`
		CreatedBy    *string `json:"created_by"`
		Notes        *string `json:"notes"`
		ExecutedAt   string  `json:"executed_at"`
	}

	execRows, _ := h.db.Query(c.UserContext(),
		`SELECT mpe.id, mpe.wo_id, wo.wo_number,
		        mpe.target_node_id, tn.name,
		        u.full_name, mpe.notes, mpe.executed_at::text
		 FROM maintenance_plan_executions mpe
		 LEFT JOIN work_orders wo ON wo.id = mpe.wo_id
		 LEFT JOIN factory_nodes tn ON tn.id = mpe.target_node_id
		 LEFT JOIN users u ON u.id = mpe.created_by
		 WHERE mpe.plan_id=$1 AND mpe.tenant_id=$2
		 ORDER BY mpe.executed_at DESC LIMIT 20`,
		id, claims.TenantID,
	)

	var executions []Execution
	if execRows != nil {
		defer execRows.Close()
		for execRows.Next() {
			var e Execution
			if execRows.Scan(&e.ID, &e.WOID, &e.WONumber,
				&e.TargetNodeID, &e.TargetNode,
				&e.CreatedBy, &e.Notes, &e.ExecutedAt) == nil {
				executions = append(executions, e)
			}
		}
	}

	// Plan exclusions
	type Exclusion struct {
		ID             int64   `json:"id"`
		NodeID         int64   `json:"node_id"`
		NodeName       string  `json:"node_name"`
		NodeCode       *string `json:"node_code"`
		ExcludedByName *string `json:"excluded_by_name"`
		CreatedAt      string  `json:"created_at"`
	}

	var exclusions []Exclusion
	exRows, _ := h.db.Query(c.UserContext(),
		`SELECT mpe.id, mpe.node_id, fn.name, fn.code,
		        u.full_name, mpe.created_at::text
		 FROM maintenance_plan_exclusions mpe
		 JOIN factory_nodes fn ON fn.id = mpe.node_id
		 LEFT JOIN users u ON u.id = mpe.excluded_by
		 WHERE mpe.plan_id=$1 AND mpe.tenant_id=$2
		 ORDER BY fn.name`,
		id, claims.TenantID,
	)
	if exRows != nil {
		defer exRows.Close()
		for exRows.Next() {
			var e Exclusion
			if exRows.Scan(&e.ID, &e.NodeID, &e.NodeName, &e.NodeCode,
				&e.ExcludedByName, &e.CreatedAt) == nil {
				exclusions = append(exclusions, e)
			}
		}
	}

	return c.JSON(fiber.Map{
		"plan":       p,
		"executions": executions,
		"exclusions": exclusions,
	})
}

// ─── GET /maintenance-plans/compliance — compliance statistics ─────────

func (h *MaintenanceHandler) Compliance(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	// Build the scope filter
	nodeFilter := ""
	args := []interface{}{claims.TenantID}
	if claims.Role != "admin" && claims.Role != "auditor" {
		nodeFilter = ` AND node_id IN (
			SELECT fn.id FROM factory_nodes fn
			JOIN node_assignments na ON na.user_id = $2 AND na.tenant_id = $1
			JOIN factory_nodes assigned ON assigned.id = na.node_id AND assigned.tenant_id = $1
			WHERE fn.tenant_id = $1 AND fn.path <@ assigned.path
		)`
		args = append(args, claims.UserID)
	}

	var totalPlans, activePlans, overdueCount, onTimeCount int
	err := h.db.QueryRow(c.UserContext(),
		`SELECT
			COUNT(*),
			COUNT(*) FILTER (WHERE is_active=true),
			COUNT(*) FILTER (WHERE is_active=true AND next_due_at < NOW()),
			COUNT(*) FILTER (WHERE is_active=true AND next_due_at >= NOW())
		 FROM maintenance_plans WHERE tenant_id=$1`+nodeFilter,
		args...,
	).Scan(&totalPlans, &activePlans, &overdueCount, &onTimeCount)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando cumplimiento")
	}

	// Executions over the last month
	var lastMonthExecutions int
	execQuery := `SELECT COUNT(*) FROM maintenance_plan_executions mpe WHERE mpe.tenant_id=$1 AND mpe.executed_at > NOW() - INTERVAL '30 days'`
	if claims.Role != "admin" && claims.Role != "auditor" {
		execQuery += ` AND mpe.plan_id IN (SELECT id FROM maintenance_plans WHERE tenant_id=$1` + nodeFilter + `)`
	}
	h.db.QueryRow(c.UserContext(), execQuery, args...).Scan(&lastMonthExecutions)

	complianceRate := 0.0
	if activePlans > 0 {
		complianceRate = float64(onTimeCount) / float64(activePlans) * 100
	}

	return c.JSON(fiber.Map{
		"total_plans":           totalPlans,
		"active_plans":          activePlans,
		"overdue_count":         overdueCount,
		"on_time_count":         onTimeCount,
		"compliance_rate":       complianceRate,
		"last_month_executions": lastMonthExecutions,
	})
}

// ─── Helper: normalize empty JSON ──────────────────────────────────────────

func normalizeJSON(data json.RawMessage, fallback string) string {
	if len(data) == 0 || string(data) == "null" {
		return fallback
	}
	return string(data)
}

// linkPartsToWO inserts the plan's required spare parts into work_order_parts.
func linkPartsToWO(ctx context.Context, db *pgxpool.Pool, tenantID, woID int64, partsRaw json.RawMessage) {
	var parts []struct {
		SparePartID int64  `json:"spare_part_id"`
		Name        string `json:"name"`
		Code        string `json:"code"`
		Quantity    int    `json:"quantity"`
	}
	if json.Unmarshal(partsRaw, &parts) != nil || len(parts) == 0 {
		return
	}
	for _, p := range parts {
		qty := p.Quantity
		if qty <= 0 {
			qty = 1
		}
		spareID := p.SparePartID
		if spareID == 0 && p.Code != "" {
			db.QueryRow(ctx,
				`SELECT id FROM spare_parts WHERE code=$1 AND tenant_id=$2 LIMIT 1`, p.Code, tenantID,
			).Scan(&spareID)
		}
		if spareID > 0 {
			db.Exec(ctx,
				`INSERT INTO work_order_parts (wo_id, spare_part_id, quantity)
				 VALUES ($1,$2,$3) ON CONFLICT (wo_id, spare_part_id) DO NOTHING`,
				woID, spareID, qty,
			)
		}
	}
}

// ─── Helper: build the formatted description for the WO ────────────────────

func buildWODescription(desc *string, instructions *string, checklistRaw json.RawMessage,
	safetyNotes *string, toolsRaw json.RawMessage, partsRaw json.RawMessage) string {

	var sb strings.Builder

	if desc != nil && *desc != "" {
		sb.WriteString(*desc)
		sb.WriteString("\n\n")
	}

	if instructions != nil && *instructions != "" {
		sb.WriteString("PROCEDIMIENTO\n")
		sb.WriteString(strings.Repeat("\u2500", 35))
		sb.WriteString("\n")
		sb.WriteString(*instructions)
		sb.WriteString("\n\n")
	}

	// Checklist
	var checklist []struct {
		Step     string `json:"step"`
		Required bool   `json:"required"`
	}
	if json.Unmarshal(checklistRaw, &checklist) == nil && len(checklist) > 0 {
		sb.WriteString("LISTA DE VERIFICACION\n")
		sb.WriteString(strings.Repeat("\u2500", 35))
		sb.WriteString("\n")
		for i, item := range checklist {
			marker := "[ ]"
			suffix := ""
			if item.Required {
				marker = "[*]"
				suffix = " (obligatorio)"
			}
			sb.WriteString(fmt.Sprintf("%s %d. %s%s\n", marker, i+1, item.Step, suffix))
		}
		sb.WriteString("\n")
	}

	if safetyNotes != nil && *safetyNotes != "" {
		sb.WriteString("NOTAS DE SEGURIDAD\n")
		sb.WriteString(strings.Repeat("\u2500", 35))
		sb.WriteString("\n")
		sb.WriteString(*safetyNotes)
		sb.WriteString("\n\n")
	}

	// Tools
	var tools []string
	if json.Unmarshal(toolsRaw, &tools) == nil && len(tools) > 0 {
		sb.WriteString("HERRAMIENTAS NECESARIAS\n")
		sb.WriteString(strings.Repeat("\u2500", 35))
		sb.WriteString("\n")
		for _, t := range tools {
			sb.WriteString(fmt.Sprintf("  - %s\n", t))
		}
		sb.WriteString("\n")
	}

	// Spare parts
	var parts []struct {
		Name     string `json:"name"`
		Code     string `json:"code"`
		Quantity int    `json:"quantity"`
	}
	if json.Unmarshal(partsRaw, &parts) == nil && len(parts) > 0 {
		sb.WriteString("REPUESTOS NECESARIOS\n")
		sb.WriteString(strings.Repeat("\u2500", 35))
		sb.WriteString("\n")
		for _, p := range parts {
			qty := p.Quantity
			if qty == 0 {
				qty = 1
			}
			sb.WriteString(fmt.Sprintf("  - %s (%s) x%d\n", p.Name, p.Code, qty))
		}
		sb.WriteString("\n")
	}

	return strings.TrimSpace(sb.String())
}

// ─── GET /maintenance-plans/effective/:nodeId — plans that affect a node ─

func (h *MaintenanceHandler) EffectivePlans(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID, err := strconv.ParseInt(c.Params("nodeId"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	type EffPlan struct {
		ID                   int64   `json:"id"`
		Title                string  `json:"title"`
		Description          *string `json:"description"`
		WOType               string  `json:"wo_type"`
		Priority             string  `json:"priority"`
		FrequencyType        string  `json:"frequency_type"`
		FrequencyValue       int     `json:"frequency_value"`
		NextDueAt            *string `json:"next_due_at"`
		IsActive             bool    `json:"is_active"`
		NodeID               *int64  `json:"node_id"`
		SourceNodeName       *string `json:"source_node_name"`
		EquipmentTemplateID  *int64  `json:"equipment_template_id"`
		Manufacturer         *string `json:"manufacturer"`
		Model                *string `json:"model"`
		ApplyToChildren      bool    `json:"apply_to_children"`
		PlanSource           string  `json:"plan_source"`
		IsExcluded           bool    `json:"is_excluded"`
		AssignedName         *string `json:"assigned_name"`
		HasInstructions      bool    `json:"has_instructions"`
		ChecklistCount       int     `json:"checklist_count"`
		ToolsCount           int     `json:"tools_count"`
	}

	rows, err := h.db.Query(c.UserContext(),
		`WITH target AS (
		    SELECT id, path, template_id FROM factory_nodes WHERE id=$2 AND tenant_id=$1
		)
		SELECT mp.id, mp.title, mp.description, mp.wo_type, mp.priority,
		       mp.frequency_type, mp.frequency_value, mp.next_due_at::text,
		       mp.is_active, mp.node_id, fn.name AS source_node_name,
		       mp.equipment_template_id, et.manufacturer, et.model,
		       mp.apply_to_children,
		       CASE
		           WHEN mp.node_id = $2 THEN 'direct'
		           WHEN mp.node_id IS NOT NULL AND mp.apply_to_children THEN 'inherited'
		           WHEN mp.equipment_template_id IS NOT NULL THEN 'template'
		       END AS plan_source,
		       EXISTS (
		           SELECT 1 FROM maintenance_plan_exclusions ex
		           WHERE ex.plan_id = mp.id AND ex.node_id = $2 AND ex.tenant_id = $1
		       ) AS is_excluded,
		       u.full_name AS assigned_name,
		       mp.instructions IS NOT NULL AND mp.instructions != '' AS has_instructions,
		       COALESCE(jsonb_array_length(mp.checklist), 0) AS checklist_count,
		       COALESCE(jsonb_array_length(mp.tools_required), 0) AS tools_count
		FROM maintenance_plans mp
		LEFT JOIN factory_nodes fn ON fn.id = mp.node_id
		LEFT JOIN equipment_templates et ON et.id = mp.equipment_template_id
		LEFT JOIN users u ON u.id = mp.assigned_to
		CROSS JOIN target t
		WHERE mp.tenant_id = $1
		  AND mp.is_active = true
		  AND (
		      mp.node_id = $2
		      OR (mp.apply_to_children = true AND mp.node_id IS NOT NULL
		          AND t.path <@ (SELECT path FROM factory_nodes WHERE id = mp.node_id AND tenant_id = $1))
		      OR (mp.equipment_template_id IS NOT NULL AND mp.equipment_template_id = t.template_id)
		  )
		ORDER BY plan_source, mp.title`,
		claims.TenantID, nodeID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando planes efectivos")
	}
	defer rows.Close()

	var plans []EffPlan
	for rows.Next() {
		var p EffPlan
		if rows.Scan(&p.ID, &p.Title, &p.Description, &p.WOType, &p.Priority,
			&p.FrequencyType, &p.FrequencyValue, &p.NextDueAt,
			&p.IsActive, &p.NodeID, &p.SourceNodeName,
			&p.EquipmentTemplateID, &p.Manufacturer, &p.Model,
			&p.ApplyToChildren, &p.PlanSource, &p.IsExcluded,
			&p.AssignedName, &p.HasInstructions, &p.ChecklistCount, &p.ToolsCount) == nil {
			plans = append(plans, p)
		}
	}

	return c.JSON(fiber.Map{"plans": plans, "total": len(plans)})
}

// ─── POST /maintenance-plans/:id/exclusions — exclude a node from the plan ──────

func (h *MaintenanceHandler) AddExclusion(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	planID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req struct {
		NodeID int64 `json:"node_id"`
	}
	if err := c.BodyParser(&req); err != nil || req.NodeID == 0 {
		return fiber.NewError(fiber.StatusBadRequest, "node_id es obligatorio")
	}

	_, err = h.db.Exec(c.UserContext(),
		`INSERT INTO maintenance_plan_exclusions (tenant_id, plan_id, node_id, excluded_by)
		 VALUES ($1, $2, $3, $4)
		 ON CONFLICT (tenant_id, plan_id, node_id) DO NOTHING`,
		claims.TenantID, planID, req.NodeID, claims.UserID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error creando exclusión")
	}

	return c.JSON(fiber.Map{"message": "Nodo excluido del plan"})
}

// ─── DELETE /maintenance-plans/:id/exclusions/:nodeId — remove an exclusion ─────

func (h *MaintenanceHandler) RemoveExclusion(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	planID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID de plan inválido")
	}
	nodeID, err := strconv.ParseInt(c.Params("nodeId"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID de nodo inválido")
	}

	result, err := h.db.Exec(c.UserContext(),
		`DELETE FROM maintenance_plan_exclusions
		 WHERE plan_id=$1 AND node_id=$2 AND tenant_id=$3`,
		planID, nodeID, claims.TenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Exclusión no encontrada")
	}

	return c.JSON(fiber.Map{"message": "Exclusión eliminada"})
}
