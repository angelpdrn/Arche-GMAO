package handlers

import (
	"testing"
)

func TestSanitizePathComponent(t *testing.T) {
	tests := []struct {
		name  string
		input string
		want  string
	}{
		{"normal", "foto.jpg", "foto.jpg"},
		{"with spaces", "mi foto.jpg", "mi foto.jpg"},
		{"dotdot", "../etc/passwd", ""},
		{"slash", "path/to/file", ""},
		{"backslash", "path\\file", ""},
		{"just dots", "..", ""},
		{"single dot", ".", ""},
		{"empty", "", ""},
		{"hidden dotdot resolved", "foo/../bar", "bar"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := sanitizePathComponent(tt.input)
			if got != tt.want {
				t.Errorf("sanitizePathComponent(%q) = %q, want %q", tt.input, got, tt.want)
			}
		})
	}
}

func TestEnsureUnderBase(t *testing.T) {
	tests := []struct {
		name string
		base string
		path string
		ok   bool
	}{
		{"inside", "/uploads", "/uploads/file.txt", true},
		{"nested", "/uploads", "/uploads/a/b/c.txt", true},
		{"escape", "/uploads", "/uploads/../etc/passwd", false},
		{"escape with dots", "/uploads", "/etc/passwd", false},
		{"same dir", "/uploads", "/uploads", true},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := ensureUnderBase(tt.base, tt.path)
			if got != tt.ok {
				t.Errorf("ensureUnderBase(%q, %q) = %v, want %v", tt.base, tt.path, got, tt.ok)
			}
		})
	}
}

func TestSanitizeFileName(t *testing.T) {
	tests := []struct {
		name  string
		input string
		want  string
	}{
		{"normal", "report.pdf", "report.pdf"},
		{"spaces", "my file.pdf", "my_file.pdf"},
		{"dotdot", "../../etc", "____etc"},
		{"slashes", "path/to\\file", "path_to_file"},
		{"special chars", "file:name<>|?.txt", "file_name____.txt"},
		{"quotes", `say "hello"`, "say__hello_"},
		{"semicolon injection", "file;rm -rf /", "file_rm_-rf__"},
		{"newlines", "file\r\nname", "file__name"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := sanitizeFileName(tt.input)
			if got != tt.want {
				t.Errorf("sanitizeFileName(%q) = %q, want %q", tt.input, got, tt.want)
			}
		})
	}
}
