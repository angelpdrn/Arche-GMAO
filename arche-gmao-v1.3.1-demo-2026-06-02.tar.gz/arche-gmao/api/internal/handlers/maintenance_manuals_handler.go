package handlers

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"

	"arche-gmao/api/internal/ai"
	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type MaintenanceManualsHandler struct {
	db *pgxpool.Pool
}

func NewMaintenanceManualsHandler(db *pgxpool.Pool) *MaintenanceManualsHandler {
	return &MaintenanceManualsHandler{db: db}
}

// ─── GET /factory/nodes/:id/manuals ─────────────────────────────────────────

func (h *MaintenanceManualsHandler) ListByNode(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	rows, err := h.db.Query(c.UserContext(),
		`SELECT mm.id, mm.title, mm.description, mm.original_name,
		        mm.mime_type, mm.file_size, mm.is_active,
		        u.full_name, mm.created_at::text
		 FROM maintenance_manuals mm
		 LEFT JOIN users u ON u.id = mm.uploaded_by
		 WHERE mm.node_id = $1 AND mm.tenant_id = $2
		 ORDER BY mm.created_at DESC`,
		nodeID, claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando manuales")
	}
	defer rows.Close()

	type Manual struct {
		ID           int64   `json:"id"`
		Title        string  `json:"title"`
		Description  *string `json:"description"`
		OriginalName string  `json:"original_name"`
		MimeType     *string `json:"mime_type"`
		FileSize     int64   `json:"file_size"`
		IsActive     bool    `json:"is_active"`
		UploadedBy   *string `json:"uploaded_by"`
		CreatedAt    string  `json:"created_at"`
	}

	var manuals []Manual
	for rows.Next() {
		var m Manual
		if rows.Scan(&m.ID, &m.Title, &m.Description, &m.OriginalName,
			&m.MimeType, &m.FileSize, &m.IsActive,
			&m.UploadedBy, &m.CreatedAt) == nil {
			manuals = append(manuals, m)
		}
	}

	return c.JSON(fiber.Map{"manuals": manuals, "total": len(manuals)})
}

// ─── POST /factory/nodes/:id/manuals/upload ─────────────────────────────────

func (h *MaintenanceManualsHandler) Upload(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	file, err := c.FormFile("file")
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "No se encontró el archivo")
	}

	// Validate the size (10MB)
	if file.Size > 10*1024*1024 {
		return fiber.NewError(fiber.StatusBadRequest, "El archivo supera el límite de 10MB")
	}

	// Validate the type
	mimeType := file.Header.Get("Content-Type")
	ext := strings.ToLower(filepath.Ext(file.Filename))
	if ext != ".pdf" && ext != ".txt" && ext != ".text" {
		return fiber.NewError(fiber.StatusBadRequest, "Solo se aceptan archivos PDF o TXT")
	}

	title := c.FormValue("title", "")
	if title == "" {
		// Use the file name without its extension as the title
		title = strings.TrimSuffix(file.Filename, filepath.Ext(file.Filename))
	}
	description := c.FormValue("description", "")

	// Create the target directory under UPLOAD_DIR (configurable)
	base := uploadBaseDir()
	uploadDir := filepath.Join(base, fmt.Sprintf("tenant_%d", claims.TenantID), "manuals", strconv.FormatInt(nodeID, 10))
	if err := os.MkdirAll(uploadDir, 0o700); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error preparando carpeta de manuales")
	}

	// Save the file
	timestamp := time.Now().Unix()
	safeFileName := fmt.Sprintf("%d_%d_%s", claims.TenantID, timestamp, sanitizeFileName(file.Filename))
	destPath := filepath.Join(uploadDir, safeFileName)
	if !ensureUnderBase(uploadDir, destPath) {
		return fiber.NewError(fiber.StatusBadRequest, "Nombre de archivo inválido")
	}

	if err := c.SaveFile(file, destPath); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error guardando el archivo")
	}

	// Extract the text
	var contentText string
	if ext == ".pdf" {
		data, readErr := os.ReadFile(destPath)
		if readErr == nil {
			contentText = extractTextFromPDF(data)
		}
	} else {
		// TXT
		data, readErr := os.ReadFile(destPath)
		if readErr == nil {
			contentText = string(data)
		}
	}

	// Cap the stored text at ~500KB, respecting the UTF-8 rune boundary
	if len(contentText) > 500*1024 {
		cut := 500 * 1024
		// step back to the start of the rune so it is not cut in half
		for cut > 0 && !utf8.RuneStart(contentText[cut]) {
			cut--
		}
		contentText = contentText[:cut]
		if !utf8.ValidString(contentText) {
			contentText = strings.ToValidUTF8(contentText, "")
		}
	}

	var descPtr *string
	if description != "" {
		descPtr = &description
	}

	var newID int64
	err = h.db.QueryRow(c.UserContext(),
		`INSERT INTO maintenance_manuals
		 (tenant_id, node_id, title, description, file_name, original_name,
		  mime_type, file_size, file_path, content_text, uploaded_by)
		 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id`,
		claims.TenantID, nodeID, title, descPtr, safeFileName, file.Filename,
		mimeType, file.Size, destPath, contentText, claims.UserID,
	).Scan(&newID)
	if err != nil {
		os.Remove(destPath)
		return fiber.NewError(fiber.StatusInternalServerError, "Error registrando manual")
	}

	// Queue it for RAG indexing
	ai.EnqueueNow(context.Background(), h.db, claims.TenantID, "index", "maintenance_manual", newID)

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"id":      newID,
		"title":   title,
		"message": "Manual subido correctamente. Será indexado por la IA en breve.",
	})
}

// ─── GET /factory/nodes/:id/manuals/:manualId/download ──────────────────────

func (h *MaintenanceManualsHandler) Download(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}
	manualID, err := strconv.ParseInt(c.Params("manualId"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID de manual inválido")
	}

	var filePath, originalName, mimeTypeVal string
	err = h.db.QueryRow(c.UserContext(),
		`SELECT file_path, original_name, COALESCE(mime_type,'application/octet-stream')
		 FROM maintenance_manuals
		 WHERE id=$1 AND node_id=$2 AND tenant_id=$3`,
		manualID, nodeID, claims.TenantID,
	).Scan(&filePath, &originalName, &mimeTypeVal)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Manual no encontrado")
	}

	// Defence in depth: check that the path stored in the DB lives
	// under UPLOAD_DIR before serving it (we cannot fully trust it if
	// someone tampered with the row through a historical SQL injection).
	if !ensureUnderBase(uploadBaseDir(), filePath) {
		return fiber.NewError(fiber.StatusForbidden, "Ruta de archivo inválida")
	}
	if _, err := os.Stat(filePath); os.IsNotExist(err) {
		return fiber.NewError(fiber.StatusNotFound, "Archivo no encontrado en disco")
	}

	c.Set("Content-Disposition", fmt.Sprintf(`attachment; filename="%s"`, sanitizeFileName(originalName)))
	c.Set("Content-Type", mimeTypeVal)
	return c.SendFile(filePath)
}

// ─── PUT /factory/nodes/:id/manuals/:manualId ───────────────────────────────

func (h *MaintenanceManualsHandler) Update(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}
	manualID, err := strconv.ParseInt(c.Params("manualId"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID de manual inválido")
	}

	var req struct {
		Title       string  `json:"title"`
		Description *string `json:"description"`
		IsActive    *bool   `json:"is_active"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	isActive := true
	if req.IsActive != nil {
		isActive = *req.IsActive
	}

	result, err := h.db.Exec(c.UserContext(),
		`UPDATE maintenance_manuals SET
		 title = COALESCE(NULLIF($1,''), title),
		 description = $2,
		 is_active = $3
		 WHERE id=$4 AND node_id=$5 AND tenant_id=$6`,
		req.Title, req.Description, isActive,
		manualID, nodeID, claims.TenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Manual no encontrado")
	}

	// Reindex when the state changed
	if req.IsActive != nil && !*req.IsActive {
		ai.EnqueueNow(context.Background(), h.db, claims.TenantID, "delete", "maintenance_manual", manualID)
	} else {
		ai.EnqueueNow(context.Background(), h.db, claims.TenantID, "reindex", "maintenance_manual", manualID)
	}

	return c.JSON(fiber.Map{"message": "Manual actualizado"})
}

// ─── DELETE /factory/nodes/:id/manuals/:manualId ────────────────────────────

func (h *MaintenanceManualsHandler) Delete(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}
	manualID, err := strconv.ParseInt(c.Params("manualId"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID de manual inválido")
	}

	// Get the path so the file can be removed
	var filePath string
	h.db.QueryRow(c.UserContext(),
		`SELECT file_path FROM maintenance_manuals WHERE id=$1 AND node_id=$2 AND tenant_id=$3`,
		manualID, nodeID, claims.TenantID,
	).Scan(&filePath)

	result, err := h.db.Exec(c.UserContext(),
		`DELETE FROM maintenance_manuals WHERE id=$1 AND node_id=$2 AND tenant_id=$3`,
		manualID, nodeID, claims.TenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Manual no encontrado")
	}

	// Delete the file from disk
	if filePath != "" {
		os.Remove(filePath)
	}

	// Delete the embeddings
	ai.EnqueueNow(context.Background(), h.db, claims.TenantID, "delete", "maintenance_manual", manualID)

	return c.JSON(fiber.Map{"message": "Manual eliminado"})
}

// Reuses sanitizeFileName from library_handler.go (same package)
// Reuses extractTextFromPDF from ai_admin_handler.go (same package)
