package handlers

import (
	"strconv"
	"strings"

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type TechnicianHandler struct {
	db *pgxpool.Pool
}

func NewTechnicianHandler(db *pgxpool.Pool) *TechnicianHandler {
	return &TechnicianHandler{db: db}
}

// ─── GET /technicians — full profiles ────────────────────────────────────

func (h *TechnicianHandler) List(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	rows, err := h.db.Query(c.UserContext(),
		`SELECT user_id, full_name, email, role,
		        tags, avg_score, scored_wos,
		        completed_wos, corrective_completed, avg_resolution_hours
		 FROM v_technician_profiles
		 WHERE tenant_id=$1
		 ORDER BY avg_score DESC NULLS LAST, completed_wos DESC`,
		claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando perfiles")
	}
	defer rows.Close()

	type Profile struct {
		UserID              int64    `json:"user_id"`
		FullName            string   `json:"full_name"`
		Email               string   `json:"email"`
		Role                string   `json:"role"`
		Tags                []string `json:"tags"`
		AvgScore            *float64 `json:"avg_score"`
		ScoredWOs           int      `json:"scored_wos"`
		CompletedWOs        int      `json:"completed_wos"`
		CorrectiveCompleted int      `json:"corrective_completed"`
		AvgResolutionHours  *float64 `json:"avg_resolution_hours"`
	}

	var profiles []Profile
	for rows.Next() {
		var p Profile
		if err := rows.Scan(
			&p.UserID, &p.FullName, &p.Email, &p.Role,
			&p.Tags, &p.AvgScore, &p.ScoredWOs,
			&p.CompletedWOs, &p.CorrectiveCompleted, &p.AvgResolutionHours,
		); err == nil {
			profiles = append(profiles, p)
		}
	}

	return c.JSON(fiber.Map{"technicians": profiles, "total": len(profiles)})
}

// ─── GET /technicians/:id — individual profile ─────────────────────────────────

func (h *TechnicianHandler) GetOne(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	userID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	type Profile struct {
		UserID              int64    `json:"user_id"`
		FullName            string   `json:"full_name"`
		Email               string   `json:"email"`
		Role                string   `json:"role"`
		Tags                []string `json:"tags"`
		AvgScore            *float64 `json:"avg_score"`
		ScoredWOs           int      `json:"scored_wos"`
		CompletedWOs        int      `json:"completed_wos"`
		CorrectiveCompleted int      `json:"corrective_completed"`
		AvgResolutionHours  *float64 `json:"avg_resolution_hours"`
	}

	var p Profile
	err = h.db.QueryRow(c.UserContext(),
		`SELECT user_id, full_name, email, role,
		        tags, avg_score, scored_wos,
		        completed_wos, corrective_completed, avg_resolution_hours
		 FROM v_technician_profiles
		 WHERE tenant_id=$1 AND user_id=$2`,
		claims.TenantID, userID,
	).Scan(
		&p.UserID, &p.FullName, &p.Email, &p.Role,
		&p.Tags, &p.AvgScore, &p.ScoredWOs,
		&p.CompletedWOs, &p.CorrectiveCompleted, &p.AvgResolutionHours,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Técnico no encontrado")
	}

	// Last 5 scores
	scoreRows, _ := h.db.Query(c.UserContext(),
		`SELECT ws.score, ws.comment, ws.created_at::text,
		        wo.wo_number, wo.title
		 FROM wo_scores ws
		 JOIN work_orders wo ON wo.id=ws.wo_id
		 WHERE ws.user_id=$1 AND ws.tenant_id=$2
		 ORDER BY ws.created_at DESC LIMIT 5`,
		userID, claims.TenantID,
	)
	type Score struct {
		Score     int     `json:"score"`
		Comment   *string `json:"comment"`
		CreatedAt string  `json:"created_at"`
		WONumber  string  `json:"wo_number"`
		WOTitle   string  `json:"wo_title"`
	}
	var scores []Score
	if scoreRows != nil {
		defer scoreRows.Close()
		for scoreRows.Next() {
			var s Score
			if scoreRows.Scan(&s.Score, &s.Comment, &s.CreatedAt, &s.WONumber, &s.WOTitle) == nil {
				scores = append(scores, s)
			}
		}
	}

	return c.JSON(fiber.Map{"profile": p, "recent_scores": scores})
}

// ─── POST /technicians/:id/tags — add a tag ────────────────────────────

func (h *TechnicianHandler) AddTag(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	userID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req struct {
		Tag string `json:"tag"`
	}
	if err := c.BodyParser(&req); err != nil || req.Tag == "" {
		return fiber.NewError(fiber.StatusBadRequest, "Tag requerido")
	}

	_, err = h.db.Exec(c.UserContext(),
		`INSERT INTO user_tags (tenant_id, user_id, tag, added_by)
		 VALUES ($1,$2,$3,$4)
		 ON CONFLICT (tenant_id, user_id, tag) DO NOTHING`,
		claims.TenantID, userID, req.Tag, claims.UserID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error añadiendo tag")
	}

	return c.JSON(fiber.Map{"message": "Etiqueta añadida"})
}

// ─── DELETE /technicians/:id/tags/:tag — remove a tag ───────────────────

func (h *TechnicianHandler) RemoveTag(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	userID, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	tag := c.Params("tag")

	h.db.Exec(c.UserContext(),
		`DELETE FROM user_tags WHERE tenant_id=$1 AND user_id=$2 AND tag=$3`,
		claims.TenantID, userID, tag,
	)
	return c.JSON(fiber.Map{"message": "Etiqueta eliminada"})
}

// ─── POST /technicians/:id/scores — score a WO ───────────────────────────

func (h *TechnicianHandler) AddScore(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	userID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req struct {
		WOId    int64   `json:"wo_id"`
		Score   int     `json:"score"`
		Comment *string `json:"comment"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}
	if req.Score < 1 || req.Score > 5 {
		return fiber.NewError(fiber.StatusBadRequest, "La puntuación debe ser entre 1 y 5")
	}
	if req.WOId == 0 {
		return fiber.NewError(fiber.StatusBadRequest, "wo_id requerido")
	}

	// They cannot score themselves
	if userID == int64(claims.UserID) {
		return fiber.NewError(fiber.StatusBadRequest, "No puedes puntuarte a ti mismo")
	}

	_, err = h.db.Exec(c.UserContext(),
		`INSERT INTO wo_scores (tenant_id, wo_id, user_id, scored_by, score, comment)
		 VALUES ($1,$2,$3,$4,$5,$6)
		 ON CONFLICT (wo_id, user_id) DO UPDATE
		 SET score=EXCLUDED.score, comment=EXCLUDED.comment`,
		claims.TenantID, req.WOId, userID, claims.UserID, req.Score, req.Comment,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error guardando puntuación")
	}

	return c.JSON(fiber.Map{"message": "Puntuación registrada"})
}

// ─── GET /technicians/suggest/:wo_id — suggest a technician for a WO ───────────

func (h *TechnicianHandler) SuggestForWO(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	woID, err := strconv.ParseInt(c.Params("wo_id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	// Get the WO and node info
	var nodeID *int64
	var woType string
	err = h.db.QueryRow(c.UserContext(),
		`SELECT node_id, wo_type FROM work_orders WHERE id=$1 AND tenant_id=$2`,
		woID, claims.TenantID,
	).Scan(&nodeID, &woType)
	if err != nil || nodeID == nil {
		return fiber.NewError(fiber.StatusNotFound, "OT no encontrada o sin nodo asignado")
	}

	// Get the node/template tags
	var templateTags []string
	tagRows, _ := h.db.Query(c.UserContext(),
		`SELECT UNNEST(et.tags) AS tag
		 FROM factory_nodes fn
		 JOIN equipment_templates et ON et.id=fn.template_id
		 WHERE fn.id=$1`,
		*nodeID,
	)
	if tagRows != nil {
		defer tagRows.Close()
		for tagRows.Next() {
			var tag string
			if tagRows.Scan(&tag) == nil {
				templateTags = append(templateTags, tag)
			}
		}
	}

	// Find technicians with access to the node (direct or through an ancestor via ltree)
	rows, err := h.db.Query(c.UserContext(),
		`SELECT
			u.id, u.full_name,
			COALESCE(ARRAY_AGG(DISTINCT ut.tag) FILTER (WHERE ut.tag IS NOT NULL), '{}') AS tags,
			ROUND(AVG(ws.score)::numeric,2) AS avg_score,
			COUNT(DISTINCT wo2.id) FILTER (WHERE wo2.status IN ('assigned','in_progress')) AS current_load
		 FROM users u
		 JOIN node_assignments na ON na.user_id = u.id
		 JOIN factory_nodes assigned_node ON assigned_node.id = na.node_id
		 JOIN factory_nodes target_node ON target_node.id = $2
		 LEFT JOIN user_tags ut ON ut.user_id=u.id
		 LEFT JOIN wo_scores ws ON ws.user_id=u.id
		 LEFT JOIN work_orders wo2 ON wo2.assigned_to=u.id AND wo2.tenant_id=$1
		 WHERE u.tenant_id=$1 AND u.role IN ('technician','supervisor') AND u.status='active'
		   AND target_node.path <@ assigned_node.path
		 GROUP BY u.id, u.full_name
		 ORDER BY avg_score DESC NULLS LAST, current_load ASC
		 LIMIT 5`,
		claims.TenantID, *nodeID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error buscando técnicos")
	}
	defer rows.Close()

	type Suggestion struct {
		UserID      int64    `json:"user_id"`
		FullName    string   `json:"full_name"`
		Tags        []string `json:"tags"`
		AvgScore    *float64 `json:"avg_score"`
		CurrentLoad int      `json:"current_load"`
		Matching    bool     `json:"matching_tags"`
	}

	tagSet := make(map[string]bool)
	for _, t := range templateTags {
		tagSet[strings.ToLower(t)] = true
	}

	var suggestions []Suggestion
	for rows.Next() {
		var s Suggestion
		if rows.Scan(&s.UserID, &s.FullName, &s.Tags, &s.AvgScore, &s.CurrentLoad) == nil {
			// Flag whether they have matching tags
			for _, t := range s.Tags {
				if tagSet[t] || tagSet[strings.ToLower(t)] {
					s.Matching = true
					break
				}
			}
			suggestions = append(suggestions, s)
		}
	}

	// If only one technician is assigned to the node, auto-assign them to the WO
	autoAssigned := false
	if len(suggestions) == 1 {
		result, execErr := h.db.Exec(c.UserContext(),
			`UPDATE work_orders SET assigned_to=$1, status='assigned', updated_at=NOW(), version=version+1
			 WHERE id=$2 AND tenant_id=$3 AND assigned_to IS NULL`,
			suggestions[0].UserID, woID, claims.TenantID,
		)
		if execErr == nil && result.RowsAffected() > 0 {
			autoAssigned = true
			logExecErr(h.db.Exec(c.UserContext(),
				`INSERT INTO work_order_log (tenant_id, wo_id, user_id, from_status, to_status, comment)
				 VALUES ($1,$2,$3,'pending','assigned','Auto-asignado (unico tecnico del nodo)')`,
				claims.TenantID, woID, claims.UserID,
			)).Log("tech-auto-assign-log")
		}
	}

	return c.JSON(fiber.Map{
		"suggestions":   suggestions,
		"template_tags": templateTags,
		"auto_assigned": autoAssigned,
	})
}
