package handlers

import (
	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/redis/go-redis/v9"
)

// Version is injected at build time with:
//
//	-ldflags "-X arche-gmao/api/internal/handlers.Version=1.2.0"
//
// In dev it stays as "dev".
var Version = "dev"

type HealthHandler struct {
	db  *pgxpool.Pool
	rdb *redis.Client
}

func NewHealthHandler(db *pgxpool.Pool, rdb *redis.Client) *HealthHandler {
	return &HealthHandler{db: db, rdb: rdb}
}

func (h *HealthHandler) Check(c *fiber.Ctx) error {
	dbOK := h.db.Ping(c.UserContext()) == nil
	redisOK := h.rdb.Ping(c.UserContext()).Err() == nil

	status := "ok"
	httpStatus := fiber.StatusOK
	if !dbOK || !redisOK {
		status = "degraded"
		httpStatus = fiber.StatusServiceUnavailable
	}

	return c.Status(httpStatus).JSON(fiber.Map{
		"status":  status,
		"version": Version,
		"services": fiber.Map{
			"database": serviceStatus(dbOK),
			"redis":    serviceStatus(redisOK),
		},
	})
}

func serviceStatus(ok bool) string {
	if ok {
		return "ok"
	}
	return "error"
}
