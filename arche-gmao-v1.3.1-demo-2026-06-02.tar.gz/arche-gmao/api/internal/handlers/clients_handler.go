package handlers

import (
	"strconv"

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type ClientsHandler struct {
	db *pgxpool.Pool
}

func NewClientsHandler(db *pgxpool.Pool) *ClientsHandler {
	return &ClientsHandler{db: db}
}

type ClientResponse struct {
	ID           int64   `json:"id"`
	TenantID     int64   `json:"tenant_id"`
	Name         string  `json:"name"`
	Code         string  `json:"code"`
	ClientType   string  `json:"client_type"`
	Status       string  `json:"status"`
	ContactName  *string `json:"contact_name"`
	ContactEmail *string `json:"contact_email"`
	ContactPhone *string `json:"contact_phone"`
	Notes        *string `json:"notes"`
	CreatedAt    string  `json:"created_at"`
	UpdatedAt    string  `json:"updated_at"`
}

func (h *ClientsHandler) List(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	rows, err := h.db.Query(c.UserContext(),
		`SELECT id, tenant_id, name, code, client_type, status,
		        contact_name, contact_email, contact_phone, notes,
		        created_at::text, updated_at::text
		 FROM clients WHERE tenant_id=$1 AND status != 'inactive'
		 ORDER BY client_type, name`,
		claims.TenantID,
	)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando clientes")
	}
	defer rows.Close()

	var clients []ClientResponse
	for rows.Next() {
		var cl ClientResponse
		if err := rows.Scan(
			&cl.ID, &cl.TenantID, &cl.Name, &cl.Code, &cl.ClientType, &cl.Status,
			&cl.ContactName, &cl.ContactEmail, &cl.ContactPhone, &cl.Notes,
			&cl.CreatedAt, &cl.UpdatedAt,
		); err == nil {
			clients = append(clients, cl)
		}
	}

	return c.JSON(fiber.Map{"clients": clients, "total": len(clients)})
}

type clientRequest struct {
	Name         string  `json:"name"`
	Code         string  `json:"code"`
	ClientType   string  `json:"client_type"`
	Status       string  `json:"status"`
	ContactName  *string `json:"contact_name"`
	ContactEmail *string `json:"contact_email"`
	ContactPhone *string `json:"contact_phone"`
	Notes        *string `json:"notes"`
}

func (h *ClientsHandler) Create(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req clientRequest
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}
	if req.Name == "" || req.Code == "" {
		return fiber.NewError(fiber.StatusBadRequest, "Nombre y código son requeridos")
	}
	if req.ClientType == "" {
		req.ClientType = "external"
	}
	if req.Status == "" {
		req.Status = "active"
	}

	var newID int64
	err := h.db.QueryRow(c.UserContext(),
		`INSERT INTO clients (tenant_id, name, code, client_type, status, contact_name, contact_email, contact_phone, notes)
		 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`,
		claims.TenantID, req.Name, req.Code, req.ClientType, req.Status,
		req.ContactName, req.ContactEmail, req.ContactPhone, req.Notes,
	).Scan(&newID)
	if err != nil {
		return fiber.NewError(fiber.StatusConflict, "El código de cliente ya existe")
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": newID, "message": "Cliente creado"})
}

func (h *ClientsHandler) Update(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	var req clientRequest
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	result, err := h.db.Exec(c.UserContext(),
		`UPDATE clients SET name=$1, code=$2, client_type=$3, status=$4,
		        contact_name=$5, contact_email=$6, contact_phone=$7, notes=$8
		 WHERE id=$9 AND tenant_id=$10`,
		req.Name, req.Code, req.ClientType, req.Status,
		req.ContactName, req.ContactEmail, req.ContactPhone, req.Notes,
		id, claims.TenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Cliente no encontrado")
	}

	return c.JSON(fiber.Map{"message": "Cliente actualizado"})
}

func (h *ClientsHandler) Delete(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID inválido")
	}

	result, err := h.db.Exec(c.UserContext(),
		`UPDATE clients SET status='inactive' WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Cliente no encontrado")
	}

	return c.JSON(fiber.Map{"message": "Cliente desactivado"})
}
