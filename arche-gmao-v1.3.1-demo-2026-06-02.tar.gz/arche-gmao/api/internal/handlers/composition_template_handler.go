package handlers

import (
	"context"
	"fmt"
	"strconv"
	"strings"

	"arche-gmao/api/internal/ai"
	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type CompositionTemplateHandler struct {
	db *pgxpool.Pool
}

func NewCompositionTemplateHandler(db *pgxpool.Pool) *CompositionTemplateHandler {
	return &CompositionTemplateHandler{db: db}
}

// ─── GET /composition-templates — list templates ──────────────────────────

func (h *CompositionTemplateHandler) List(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	rows, err := h.db.Query(c.UserContext(),
		`SELECT ct.id, ct.name, ct.description, ct.created_at::text,
		        (SELECT COUNT(*) FROM composition_template_slots WHERE template_id = ct.id) AS slot_count,
		        (SELECT COUNT(*) FROM equipment_compositions WHERE template_id = ct.id) AS usage_count
		 FROM composition_templates ct
		 WHERE ct.tenant_id = $1
		 ORDER BY ct.name`,
		claims.TenantID)
	if err != nil {
		return fiber.NewError(500, "Error listando plantillas de composicion")
	}
	defer rows.Close()

	var result []map[string]interface{}
	for rows.Next() {
		var id, slotCount, usageCount int64
		var name, createdAt string
		var desc *string
		if rows.Scan(&id, &name, &desc, &createdAt, &slotCount, &usageCount) == nil {
			result = append(result, map[string]interface{}{
				"id": id, "name": name, "description": desc,
				"created_at": createdAt, "slot_count": slotCount, "usage_count": usageCount,
			})
		}
	}
	if result == nil {
		result = []map[string]interface{}{}
	}
	return c.JSON(result)
}

// ─── GET /composition-templates/:id — detail with slots ──────────────────────

func (h *CompositionTemplateHandler) GetOne(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)

	var tmpl struct {
		ID          int64   `json:"id"`
		Name        string  `json:"name"`
		Description *string `json:"description"`
		CreatedAt   string  `json:"created_at"`
	}
	err := h.db.QueryRow(c.UserContext(),
		`SELECT id, name, description, created_at::text
		 FROM composition_templates WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID,
	).Scan(&tmpl.ID, &tmpl.Name, &tmpl.Description, &tmpl.CreatedAt)
	if err != nil {
		return fiber.NewError(404, "Plantilla no encontrada")
	}

	type Slot struct {
		ID                  int64   `json:"id"`
		Role                string  `json:"role"`
		EquipmentTemplateID *int64  `json:"equipment_template_id"`
		EquipmentName       *string `json:"equipment_name"`
		SortOrder           int     `json:"sort_order"`
	}
	var slots []Slot
	sRows, _ := h.db.Query(c.UserContext(),
		`SELECT s.id, s.role, s.equipment_template_id,
		        CASE WHEN et.id IS NOT NULL THEN et.manufacturer || ' ' || et.model END,
		        s.sort_order
		 FROM composition_template_slots s
		 LEFT JOIN equipment_templates et ON et.id = s.equipment_template_id
		 WHERE s.template_id = $1
		 ORDER BY s.sort_order, s.id`,
		id)
	if sRows != nil {
		defer sRows.Close()
		for sRows.Next() {
			var s Slot
			if sRows.Scan(&s.ID, &s.Role, &s.EquipmentTemplateID, &s.EquipmentName, &s.SortOrder) == nil {
				slots = append(slots, s)
			}
		}
	}
	if slots == nil {
		slots = []Slot{}
	}

	return c.JSON(fiber.Map{"template": tmpl, "slots": slots})
}

// ─── POST /composition-templates — create a template ───────────────────────────

func (h *CompositionTemplateHandler) Create(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req struct {
		Name        string  `json:"name"`
		Description *string `json:"description"`
		Slots       []struct {
			Role                string `json:"role"`
			EquipmentTemplateID *int64 `json:"equipment_template_id"`
			SortOrder           int    `json:"sort_order"`
		} `json:"slots"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(400, "JSON invalido")
	}
	if strings.TrimSpace(req.Name) == "" {
		return fiber.NewError(400, "El nombre es obligatorio")
	}
	if len(req.Slots) == 0 {
		return fiber.NewError(400, "Se requiere al menos un slot")
	}

	tx, err := h.db.Begin(c.UserContext())
	if err != nil {
		return fiber.NewError(500, "Error iniciando transaccion")
	}
	defer tx.Rollback(c.UserContext())

	var tmplID int64
	err = tx.QueryRow(c.UserContext(),
		`INSERT INTO composition_templates (tenant_id, name, description, created_by)
		 VALUES ($1, $2, $3, $4) RETURNING id`,
		claims.TenantID, strings.TrimSpace(req.Name), req.Description, claims.UserID,
	).Scan(&tmplID)
	if err != nil {
		return fiber.NewError(500, "Error creando plantilla")
	}

	for i, s := range req.Slots {
		order := s.SortOrder
		if order == 0 {
			order = i
		}
		_, err := tx.Exec(c.UserContext(),
			`INSERT INTO composition_template_slots (template_id, role, equipment_template_id, sort_order)
			 VALUES ($1, $2, $3, $4)`,
			tmplID, strings.TrimSpace(s.Role), s.EquipmentTemplateID, order)
		if err != nil {
			return fiber.NewError(500, "Error creando slot")
		}
	}

	if err := tx.Commit(c.UserContext()); err != nil {
		return fiber.NewError(500, "Error guardando plantilla")
	}
	return c.Status(201).JSON(fiber.Map{"id": tmplID, "message": "Plantilla de composicion creada"})
}

// ─── PUT /composition-templates/:id — update a template ───────────────────

func (h *CompositionTemplateHandler) Update(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)

	var req struct {
		Name        string  `json:"name"`
		Description *string `json:"description"`
		Slots       []struct {
			Role                string `json:"role"`
			EquipmentTemplateID *int64 `json:"equipment_template_id"`
			SortOrder           int    `json:"sort_order"`
		} `json:"slots"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(400, "JSON invalido")
	}

	tx, err := h.db.Begin(c.UserContext())
	if err != nil {
		return fiber.NewError(500, "Error iniciando transaccion")
	}
	defer tx.Rollback(c.UserContext())

	tag, err := tx.Exec(c.UserContext(),
		`UPDATE composition_templates SET name=$1, description=$2
		 WHERE id=$3 AND tenant_id=$4`,
		strings.TrimSpace(req.Name), req.Description, id, claims.TenantID)
	if err != nil || tag.RowsAffected() == 0 {
		return fiber.NewError(404, "Plantilla no encontrada")
	}

	// Replace the slots
	if _, err := tx.Exec(c.UserContext(), `DELETE FROM composition_template_slots WHERE template_id=$1`, id); err != nil {
		return fiber.NewError(500, "Error eliminando slots anteriores")
	}
	for i, s := range req.Slots {
		order := s.SortOrder
		if order == 0 {
			order = i
		}
		if _, err := tx.Exec(c.UserContext(),
			`INSERT INTO composition_template_slots (template_id, role, equipment_template_id, sort_order)
			 VALUES ($1, $2, $3, $4)`,
			id, strings.TrimSpace(s.Role), s.EquipmentTemplateID, order); err != nil {
			return fiber.NewError(500, "Error guardando slot")
		}
	}

	if err := tx.Commit(c.UserContext()); err != nil {
		return fiber.NewError(500, "Error guardando plantilla")
	}
	return c.JSON(fiber.Map{"message": "Plantilla actualizada"})
}

// ─── DELETE /composition-templates/:id ───────────────────────────────────────

func (h *CompositionTemplateHandler) Delete(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)

	tag, err := h.db.Exec(c.UserContext(),
		`DELETE FROM composition_templates WHERE id=$1 AND tenant_id=$2`,
		id, claims.TenantID)
	if err != nil || tag.RowsAffected() == 0 {
		return fiber.NewError(404, "Plantilla no encontrada")
	}
	return c.JSON(fiber.Map{"message": "Plantilla eliminada"})
}

// ─── POST /composition-templates/:id/apply — create a composition node ─────────
// Creates a factory_node of type 'composition' with child equipment from the slots

func (h *CompositionTemplateHandler) Apply(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	tmplID, _ := strconv.ParseInt(c.Params("id"), 10, 64)

	var req struct {
		ParentNodeID int64  `json:"parent_node_id"`
		Name         string `json:"name"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(400, "JSON invalido")
	}
	if req.ParentNodeID == 0 {
		return fiber.NewError(400, "parent_node_id es obligatorio — la composicion se crea como nodo en el arbol")
	}

	// 1. Get the template and its slots
	var tmplName string
	h.db.QueryRow(c.UserContext(),
		`SELECT name FROM composition_templates WHERE id=$1 AND tenant_id=$2`,
		tmplID, claims.TenantID).Scan(&tmplName)
	if tmplName == "" {
		return fiber.NewError(404, "Plantilla no encontrada")
	}

	type Slot struct {
		ID                  int64
		Role                string
		EquipmentTemplateID *int64
		SortOrder           int
	}
	var slots []Slot
	sRows, err := h.db.Query(c.UserContext(),
		`SELECT id, role, equipment_template_id, sort_order
		 FROM composition_template_slots
		 WHERE template_id = $1
		 ORDER BY sort_order, id`,
		tmplID)
	if err != nil {
		return fiber.NewError(500, "Error leyendo plantilla")
	}
	defer sRows.Close()
	for sRows.Next() {
		var s Slot
		if sRows.Scan(&s.ID, &s.Role, &s.EquipmentTemplateID, &s.SortOrder) == nil {
			slots = append(slots, s)
		}
	}
	if len(slots) == 0 {
		return fiber.NewError(400, "La plantilla no tiene slots definidos")
	}

	// 2. Check the parent node
	var parentPath string
	err = h.db.QueryRow(c.UserContext(),
		`SELECT path::text FROM factory_nodes WHERE id=$1 AND tenant_id=$2`,
		req.ParentNodeID, claims.TenantID).Scan(&parentPath)
	if err != nil {
		return fiber.NewError(404, "Nodo padre no encontrado")
	}

	compName := strings.TrimSpace(req.Name)
	if compName == "" {
		compName = tmplName
	}

	// 3. Create everything in one transaction
	tx, err := h.db.Begin(c.UserContext())
	if err != nil {
		return fiber.NewError(500, "Error iniciando transaccion")
	}
	defer tx.Rollback(c.UserContext())

	// 3a. Create a factory_node of type composition
	var compNodeID int64
	err = tx.QueryRow(c.UserContext(),
		`INSERT INTO factory_nodes
		 (tenant_id, parent_id, name, node_type, status, criticality, created_by, version)
		 VALUES ($1, $2, $3, 'composition', 'active', 'medium', $4, 1)
		 RETURNING id`,
		claims.TenantID, req.ParentNodeID, compName, claims.UserID,
	).Scan(&compNodeID)
	if err != nil {
		return fiber.NewError(500, "Error creando nodo composicion")
	}

	// Assign the ltree path
	compPath := fmt.Sprintf("%s.n%d", parentPath, compNodeID)
	tx.Exec(c.UserContext(),
		`UPDATE factory_nodes SET path = $1::ltree WHERE id = $2`, compPath, compNodeID)
	// search_vector
	tx.Exec(c.UserContext(),
		`UPDATE factory_nodes SET search_vector =
		   setweight(to_tsvector('spanish', COALESCE(name,'')), 'A')
		 WHERE id = $1`, compNodeID)

	// 3b. Create the equipment_compositions record linked to the node
	var compID int64
	err = tx.QueryRow(c.UserContext(),
		`INSERT INTO equipment_compositions (tenant_id, name, template_id, parent_node_id, node_id, created_by)
		 VALUES ($1, $2, $3, $4, $5, $6) RETURNING id`,
		claims.TenantID, compName, tmplID, req.ParentNodeID, compNodeID, claims.UserID,
	).Scan(&compID)
	if err != nil {
		return fiber.NewError(500, "Error creando registro de composicion")
	}

	// 3c. For each slot, create a child equipment node
	childrenCreated := 0
	for _, slot := range slots {
		if slot.EquipmentTemplateID == nil {
			continue
		}

		// Read the data from the equipment template
		var mfr, mdl, nodeType string
		var category *string
		qErr := h.db.QueryRow(c.UserContext(),
			`SELECT manufacturer, model, COALESCE(node_type, 'equipment'), category
			 FROM equipment_templates WHERE id=$1 AND tenant_id=$2`,
			*slot.EquipmentTemplateID, claims.TenantID,
		).Scan(&mfr, &mdl, &nodeType, &category)
		if qErr != nil {
			continue // template not found, skip it
		}

		childName := slot.Role
		if childName == "" {
			childName = mfr + " " + mdl
		}

		var childID int64
		err = tx.QueryRow(c.UserContext(),
			`INSERT INTO factory_nodes
			 (tenant_id, parent_id, name, node_type, manufacturer, model, template_id,
			  status, criticality, created_by, version)
			 VALUES ($1, $2, $3, $4, $5, $6, $7, 'active', 'medium', $8, 1)
			 RETURNING id`,
			claims.TenantID, compNodeID, childName, nodeType,
			mfr, mdl, *slot.EquipmentTemplateID, claims.UserID,
		).Scan(&childID)
		if err != nil {
			continue
		}

		// Child ltree path
		childPath := fmt.Sprintf("%s.n%d", compPath, childID)
		tx.Exec(c.UserContext(),
			`UPDATE factory_nodes SET path = $1::ltree WHERE id = $2`, childPath, childID)
		tx.Exec(c.UserContext(),
			`UPDATE factory_nodes SET search_vector =
			   setweight(to_tsvector('spanish', COALESCE(name,'')), 'A') ||
			   setweight(to_tsvector('spanish', COALESCE(manufacturer,'') || ' ' || COALESCE(model,'')), 'C')
			 WHERE id = $1`, childID)

		// Register it as a member of the composition
		tx.Exec(c.UserContext(),
			`INSERT INTO equipment_composition_members (composition_id, node_id, role, slot_id)
			 VALUES ($1, $2, $3, $4) ON CONFLICT DO NOTHING`,
			compID, childID, slot.Role, slot.ID)

		childrenCreated++
	}

	if err := tx.Commit(c.UserContext()); err != nil {
		return fiber.NewError(500, "Error guardando composicion")
	}

	// Queue AI indexing
	go func() {
		bgCtx := context.Background()
		ai.EnqueueNow(bgCtx, h.db, claims.TenantID, "create", "node_info", compNodeID)
	}()

	msg := fmt.Sprintf("Composicion '%s' creada con %d equipos", compName, childrenCreated)
	if childrenCreated < len(slots) {
		msg += fmt.Sprintf(" (%d slots sin plantilla de equipo)", len(slots)-childrenCreated)
	}

	return c.Status(201).JSON(fiber.Map{
		"message":          msg,
		"node_id":          compNodeID,
		"composition_id":   compID,
		"children_created": childrenCreated,
	})
}

// ─── POST /factory/nodes/clone — clone N equipment items from a template ────────────

func (h *CompositionTemplateHandler) CloneEquipment(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var req struct {
		EquipmentTemplateID int64  `json:"equipment_template_id"`
		ParentNodeID        int64  `json:"parent_node_id"`
		Count               int    `json:"count"`
		NamePrefix          string `json:"name_prefix"`
		StartNumber         int    `json:"start_number"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(400, "JSON invalido")
	}
	if req.EquipmentTemplateID == 0 || req.ParentNodeID == 0 || req.Count <= 0 {
		return fiber.NewError(400, "equipment_template_id, parent_node_id y count son obligatorios")
	}
	if req.Count > 100 {
		return fiber.NewError(400, "Maximo 100 equipos por operacion")
	}
	if req.StartNumber == 0 {
		req.StartNumber = 1
	}

	// Get the equipment template data
	var manufacturer, model, category string
	var nodeType string
	var desc *string
	err := h.db.QueryRow(c.UserContext(),
		`SELECT manufacturer, model, COALESCE(category,''), node_type, description
		 FROM equipment_templates WHERE id=$1 AND tenant_id=$2 AND is_active=true`,
		req.EquipmentTemplateID, claims.TenantID,
	).Scan(&manufacturer, &model, &category, &nodeType, &desc)
	if err != nil {
		return fiber.NewError(404, "Plantilla de equipo no encontrada")
	}

	// Get the parent path
	var parentPath string
	err = h.db.QueryRow(c.UserContext(),
		`SELECT path::text FROM factory_nodes WHERE id=$1 AND tenant_id=$2`,
		req.ParentNodeID, claims.TenantID).Scan(&parentPath)
	if err != nil {
		return fiber.NewError(404, "Nodo padre no encontrado")
	}

	// Default name
	prefix := req.NamePrefix
	if prefix == "" {
		prefix = manufacturer + " " + model
	}

	tx, err := h.db.Begin(c.UserContext())
	if err != nil {
		return fiber.NewError(500, "Error iniciando transaccion")
	}
	defer tx.Rollback(c.UserContext())

	var createdIDs []int64
	for i := 0; i < req.Count; i++ {
		num := req.StartNumber + i
		name := fmt.Sprintf("%s #%d", prefix, num)
		mfrLen := len(manufacturer); if mfrLen > 3 { mfrLen = 3 }
		mdlLen := len(model); if mdlLen > 4 { mdlLen = 4 }
		code := fmt.Sprintf("%s-%s-%03d", strings.ToUpper(manufacturer[:mfrLen]),
			strings.ToUpper(model[:mdlLen]), num)

		var nodeID int64
		err := tx.QueryRow(c.UserContext(),
			`INSERT INTO factory_nodes (tenant_id, parent_id, name, code, node_type,
			        manufacturer, model, template_id, status, criticality, created_by, version)
			 VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'active', 'medium', $9, 1)
			 RETURNING id`,
			claims.TenantID, req.ParentNodeID, name, code, nodeType,
			manufacturer, model, req.EquipmentTemplateID, claims.UserID,
		).Scan(&nodeID)
		if err != nil {
			return fiber.NewError(500, fmt.Sprintf("Error creando equipo %s: %v", name, err))
		}

		// Update the ltree path
		newPath := fmt.Sprintf("%s.n%d", parentPath, nodeID)
		tx.Exec(c.UserContext(),
			`UPDATE factory_nodes SET path = $1::ltree WHERE id = $2`,
			newPath, nodeID)

		// Update search_vector
		tx.Exec(c.UserContext(),
			`UPDATE factory_nodes SET search_vector =
			   setweight(to_tsvector('spanish', COALESCE(name,'')), 'A') ||
			   setweight(to_tsvector('spanish', COALESCE(code,'')), 'B') ||
			   setweight(to_tsvector('spanish', COALESCE(manufacturer,'') || ' ' || COALESCE(model,'')), 'C')
			 WHERE id = $1`, nodeID)

		createdIDs = append(createdIDs, nodeID)
	}

	if err := tx.Commit(c.UserContext()); err != nil {
		return fiber.NewError(500, "Error guardando equipos")
	}

	// Queue AI indexing for each created node (in the background, non-blocking)
	go func() {
		bgCtx := context.Background()
		for _, nid := range createdIDs {
			ai.EnqueueNow(bgCtx, h.db, claims.TenantID, "create", "node_info", nid)
		}
	}()

	return c.Status(201).JSON(fiber.Map{
		"message":  fmt.Sprintf("%d equipos creados", len(createdIDs)),
		"node_ids": createdIDs,
	})
}

