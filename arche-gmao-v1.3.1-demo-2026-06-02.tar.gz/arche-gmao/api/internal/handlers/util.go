package handlers

import (
	"log"
	"os"
	"path/filepath"
	"strings"

	"github.com/jackc/pgx/v5/pgconn"
)

// uploadBaseDir returns the root directory for attachment and manual
// uploads. Configurable through UPLOAD_DIR. Safe default:
//   - /var/lib/arche/uploads when APP_ENV=production
//   - /tmp/arche_uploads in development
// The directory is created lazily (0700) on every call so the helper
// stays safe across restarts and fresh deployments.
func uploadBaseDir() string {
	dir := os.Getenv("UPLOAD_DIR")
	if dir == "" {
		if os.Getenv("APP_ENV") == "production" {
			dir = "/var/lib/arche/uploads"
		} else {
			dir = "/tmp/arche_uploads"
		}
	}
	_ = os.MkdirAll(dir, 0o700)
	return dir
}

// auditResult makes it possible to consume the result of db.Exec on a single line.
type auditResult struct{ err error }

// Log records an [ARCHE-AUDIT] message only when there was an error.
func (a auditResult) Log(tag string) {
	if a.err != nil {
		log.Printf("[ARCHE-AUDIT] %s err=%v", tag, a.err)
	}
}

// logExecErr is a wrapper-shaped constructor compatible with the signature of
// pgxpool.Pool.Exec, which returns (pgconn.CommandTag, error). The pattern
//
//	logExecErr(h.db.Exec(ctx, sql, args...)).Log("tag")
//
// makes it possible to log errors from secondary operations (audit logs,
// notifications, embedding cleanup) without aborting the main flow.
func logExecErr(_ pgconn.CommandTag, err error) auditResult {
	return auditResult{err: err}
}

// sanitizePathComponent guarantees that a path component cannot escape its
// parent directory. It returns "" when the component is unsafe (contains "..", "/" or
// is empty after Clean).
func sanitizePathComponent(name string) string {
	cleaned := filepath.Clean(name)
	if cleaned == "" || cleaned == "." || cleaned == ".." {
		return ""
	}
	if strings.ContainsAny(cleaned, `/\`) || strings.Contains(cleaned, "..") {
		return ""
	}
	return cleaned
}

// ensureUnderBase checks that joinedPath falls under baseDir once "../" is resolved.
// Returns true when it is safe to delete/open.
func ensureUnderBase(baseDir, joinedPath string) bool {
	absBase, err1 := filepath.Abs(baseDir)
	absPath, err2 := filepath.Abs(joinedPath)
	if err1 != nil || err2 != nil {
		return false
	}
	rel, err := filepath.Rel(absBase, absPath)
	if err != nil {
		return false
	}
	return !strings.HasPrefix(rel, "..") && !strings.Contains(rel, "/../")
}
