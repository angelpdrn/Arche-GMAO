package handlers

import (
	"context"
	"fmt"
	"log"
	"strconv"

	"arche-gmao/api/internal/license"
	"arche-gmao/api/internal/middleware"
	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/redis/go-redis/v9"
)

type SuperadminHandler struct {
	db  *pgxpool.Pool
	rdb *redis.Client
}

func NewSuperadminHandler(db *pgxpool.Pool, rdb *redis.Client) *SuperadminHandler {
	return &SuperadminHandler{db: db, rdb: rdb}
}

// ListTenants returns every tenant in the system.
func (h *SuperadminHandler) ListTenants(c *fiber.Ctx) error {
	rows, err := h.db.Query(c.UserContext(),
		`SELECT t.id, t.name, t.slug, t.status, t.plan, t.max_users, t.max_nodes,
		        COALESCE(t.disabled_modules, '{}'), COALESCE(t.license_notes, ''),
		        t.system_paused, t.created_at::text,
		        (SELECT COUNT(*) FROM users u WHERE u.tenant_id = t.id) AS total_users,
		        (SELECT COUNT(*) FROM users u WHERE u.tenant_id = t.id AND u.status = 'active') AS active_users,
		        (SELECT COUNT(*) FROM factory_nodes fn WHERE fn.tenant_id = t.id) AS total_nodes
		 FROM tenants t
		 ORDER BY t.id`)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error consultando tenants")
	}
	defer rows.Close()

	var tenants []fiber.Map
	for rows.Next() {
		var (
			id, totalUsers, activeUsers, totalNodes int64
			name, slug, status, plan, created      string
			licenseNotes                           string
			maxUsers, maxNodes                     *int
			disabledModules                        []string
			paused                                 bool
		)
		if err := rows.Scan(&id, &name, &slug, &status, &plan, &maxUsers, &maxNodes,
			&disabledModules, &licenseNotes, &paused, &created,
			&totalUsers, &activeUsers, &totalNodes); err != nil {
			continue
		}
		tenants = append(tenants, fiber.Map{
			"id":               id,
			"name":             name,
			"slug":             slug,
			"status":           status,
			"plan":             plan,
			"max_users":        maxUsers,
			"max_nodes":        maxNodes,
			"disabled_modules": disabledModules,
			"license_notes":    licenseNotes,
			"system_paused":    paused,
			"total_users":      totalUsers,
			"active_users":     activeUsers,
			"total_nodes":      totalNodes,
			"created_at":       created,
		})
	}

	return c.JSON(fiber.Map{"tenants": tenants})
}

// SetMaxUsers sets the maximum user limit for a tenant.
func (h *SuperadminHandler) SetMaxUsers(c *fiber.Ctx) error {
	tenantID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID de tenant inválido")
	}

	var req struct {
		MaxUsers *int `json:"max_users"` // null = unlimited
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	if req.MaxUsers != nil && *req.MaxUsers <= 0 {
		return fiber.NewError(fiber.StatusBadRequest, "El límite debe ser un número positivo o null para ilimitado")
	}

	result, err := h.db.Exec(c.UserContext(),
		`UPDATE tenants SET max_users = $1 WHERE id = $2`,
		req.MaxUsers, tenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Tenant no encontrado")
	}

	return c.JSON(fiber.Map{"message": "Límite de usuarios actualizado"})
}

// SetMaxNodes sets the maximum node limit for a tenant.
func (h *SuperadminHandler) SetMaxNodes(c *fiber.Ctx) error {
	tenantID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID de tenant inválido")
	}

	var req struct {
		MaxNodes *int `json:"max_nodes"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	if req.MaxNodes != nil && *req.MaxNodes <= 0 {
		return fiber.NewError(fiber.StatusBadRequest, "El límite debe ser un número positivo o null para ilimitado")
	}

	result, err := h.db.Exec(c.UserContext(),
		`UPDATE tenants SET max_nodes = $1 WHERE id = $2`,
		req.MaxNodes, tenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Tenant no encontrado")
	}

	return c.JSON(fiber.Map{"message": "Límite de nodos actualizado"})
}

// SetDisabledModules sets the disabled modules for a tenant.
// It can only RESTRICT the license's modules, never extend them.
func (h *SuperadminHandler) SetDisabledModules(c *fiber.Ctx) error {
	tenantID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID de tenant inválido")
	}

	var req struct {
		DisabledModules []string `json:"disabled_modules"`
		Notes           string   `json:"notes"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	validModules := map[string]bool{
		"ai": true, "preventive": true, "qr": true, "reports": true, "metrics": true,
	}
	for _, m := range req.DisabledModules {
		if !validModules[m] {
			return fiber.NewError(fiber.StatusBadRequest, "Módulo inválido: "+m)
		}
	}

	result, err := h.db.Exec(c.UserContext(),
		`UPDATE tenants SET disabled_modules = $1, license_notes = $2 WHERE id = $3`,
		req.DisabledModules, req.Notes, tenantID,
	)
	if err != nil || result.RowsAffected() == 0 {
		return fiber.NewError(fiber.StatusNotFound, "Tenant no encontrado")
	}

	log.Printf("[ARCHE-LICENSE] Superadmin actualizó módulos deshabilitados para tenant %d: %v", tenantID, req.DisabledModules)

	return c.JSON(fiber.Map{"message": "Módulos actualizados", "disabled_modules": req.DisabledModules})
}

// PauseTenant pauses a tenant remotely.
func (h *SuperadminHandler) PauseTenant(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	tenantID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ID de tenant inválido")
	}

	var req struct {
		Paused  bool   `json:"paused"`
		Contact string `json:"contact"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Cuerpo inválido")
	}

	if req.Paused {
		if req.Contact == "" {
			req.Contact = "Contacte a Arche GMAO"
		}
		_, err = h.db.Exec(c.UserContext(),
			`UPDATE tenants SET system_paused = TRUE, paused_by = $1, paused_at = NOW(), paused_contact = $2
			 WHERE id = $3`,
			claims.UserID, req.Contact, tenantID,
		)
	} else {
		_, err = h.db.Exec(c.UserContext(),
			`UPDATE tenants SET system_paused = FALSE, paused_by = NULL, paused_at = NULL, paused_contact = NULL
			 WHERE id = $1`,
			tenantID,
		)
	}

	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error actualizando estado del tenant")
	}

	middleware.InvalidatePauseCache(c.UserContext(), h.rdb, tenantID)

	status := "reanudado"
	if req.Paused {
		status = "pausado"
	}
	return c.JSON(fiber.Map{"message": "Tenant " + status + " correctamente"})
}

// ReloadLicense reloads the license from disk and syncs max_users.
// It allows updating the license without restarting the server.
func (h *SuperadminHandler) ReloadLicense(c *fiber.Ctx) error {
	info, err := license.Load("")
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error leyendo licencia: "+err.Error())
	}
	if !info.Valid {
		return fiber.NewError(fiber.StatusBadRequest, "Licencia inválida: "+info.Error)
	}

	// Sync max_users across every tenant
	if info.MaxUsers > 0 {
		_, err := h.db.Exec(context.Background(),
			`UPDATE tenants SET max_users = $1 WHERE max_users IS NULL OR max_users != $1`, info.MaxUsers)
		if err != nil {
			log.Printf("[ARCHE-LICENSE] Error sincronizando max_users: %v", err)
		}
	}

	log.Printf("[ARCHE-LICENSE] Licencia recargada: %s | Modulos: %v | Users: %d | Nodos: %d | Caduca en %d dias",
		info.ClientName, info.Modules, info.MaxUsers, info.MaxNodes, info.DaysLeft)

	return c.JSON(fiber.Map{
		"message":     "Licencia recargada correctamente",
		"client_name": info.ClientName,
		"modules":     info.Modules,
		"max_users":   info.MaxUsers,
		"max_nodes":   info.MaxNodes,
		"days_left":   info.DaysLeft,
		"expires_at":  fmt.Sprintf("%s", info.ExpiresAt.Format("2006-01-02")),
	})
}

// WhoAmI returns information about the authenticated superadmin.
func (h *SuperadminHandler) WhoAmI(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	var email, fullName string
	err := h.db.QueryRow(c.UserContext(),
		`SELECT email, full_name FROM superadmin_accounts WHERE id = $1`,
		claims.UserID,
	).Scan(&email, &fullName)
	if err != nil {
		return fiber.NewError(fiber.StatusNotFound, "Cuenta superadmin no encontrada")
	}

	return c.JSON(fiber.Map{
		"id":            claims.UserID,
		"email":         email,
		"full_name":     fullName,
		"is_superadmin": true,
	})
}
