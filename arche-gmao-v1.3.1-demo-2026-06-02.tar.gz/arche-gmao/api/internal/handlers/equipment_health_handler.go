package handlers

import (
	"context"
	"encoding/json"
	"log"
	"math"
	"strconv"
	"time"

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

type EquipmentHealthHandler struct {
	db *pgxpool.Pool
}

func NewEquipmentHealthHandler(db *pgxpool.Pool) *EquipmentHealthHandler {
	return &EquipmentHealthHandler{db: db}
}

type healthWeights struct {
	FailureFreq      float64 `json:"failure_freq"`
	PMCompliance     float64 `json:"pm_compliance"`
	Age              float64 `json:"age"`
	MTBFTrend        float64 `json:"mtbf_trend"`
	CorrectiveRatio  float64 `json:"corrective_ratio"`
	PartsConsumption float64 `json:"parts_consumption"`
}

type healthFactor struct {
	Penalty float64 `json:"penalty"`
	Weight  float64 `json:"weight"`
	Raw     float64 `json:"raw"`
}

var defaultWeights = healthWeights{
	FailureFreq:      0.25,
	PMCompliance:     0.25,
	Age:              0.15,
	MTBFTrend:        0.15,
	CorrectiveRatio:  0.10,
	PartsConsumption: 0.10,
}

// ─── GET /factory/nodes/:id/health — score of a node ───────────────────────

func (h *EquipmentHealthHandler) GetNodeHealth(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID, _ := strconv.ParseInt(c.Params("id"), 10, 64)

	score, details, err := h.calculateHealth(c.UserContext(), claims.TenantID, nodeID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error calculando salud del equipo")
	}

	return c.JSON(fiber.Map{"node_id": nodeID, "health_score": score, "details": details})
}

// ─── GET /factory/nodes/:id/health/history — trend ──────────────────────

func (h *EquipmentHealthHandler) GetHealthHistory(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeID, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	days, _ := strconv.Atoi(c.Query("days", "90"))
	if days < 7 {
		days = 7
	}
	if days > 365 {
		days = 365
	}

	rows, err := h.db.Query(c.UserContext(), `
		SELECT score, details, recorded_at::text
		FROM equipment_health_history
		WHERE node_id = $1 AND tenant_id = $2 AND recorded_at >= CURRENT_DATE - $3::int
		ORDER BY recorded_at ASC`, nodeID, claims.TenantID, days)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error cargando historial")
	}
	defer rows.Close()

	var history []fiber.Map
	for rows.Next() {
		var score int
		var details *string
		var date string
		if err := rows.Scan(&score, &details, &date); err != nil {
			continue
		}
		entry := fiber.Map{"score": score, "date": date}
		if details != nil {
			entry["details"] = details
		}
		history = append(history, entry)
	}
	if history == nil {
		history = []fiber.Map{}
	}
	return c.JSON(fiber.Map{"node_id": nodeID, "history": history})
}

// ─── GET /factory/health-summary — health summary for the whole plant ───────

func (h *EquipmentHealthHandler) GetHealthSummary(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	rows, err := h.db.Query(c.UserContext(), `
		SELECT fn.id, fn.name, fn.node_type, fn.criticality, fn.health_score, fn.parent_id
		FROM factory_nodes fn
		WHERE fn.tenant_id = $1 AND fn.health_score IS NOT NULL
		  AND fn.node_type IN ('equipment','component')
		ORDER BY fn.health_score ASC NULLS LAST`, claims.TenantID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error cargando resumen de salud")
	}
	defer rows.Close()

	var nodes []fiber.Map
	var total, critical, poor, fair, good, excellent int
	for rows.Next() {
		var id int64
		var name, nodeType, criticality string
		var score *int
		var parentID *int64
		if err := rows.Scan(&id, &name, &nodeType, &criticality, &score, &parentID); err != nil {
			continue
		}
		total++
		if score != nil {
			s := *score
			switch {
			case s < 30:
				critical++
			case s < 50:
				poor++
			case s < 70:
				fair++
			case s < 85:
				good++
			default:
				excellent++
			}
		}
		nodes = append(nodes, fiber.Map{
			"id": id, "name": name, "node_type": nodeType,
			"criticality": criticality, "health_score": score, "parent_id": parentID,
		})
	}
	if nodes == nil {
		nodes = []fiber.Map{}
	}

	return c.JSON(fiber.Map{
		"nodes": nodes, "total": total,
		"distribution": fiber.Map{
			"critical": critical, "poor": poor, "fair": fair,
			"good": good, "excellent": excellent,
		},
	})
}

// ─── POST /factory/health/recalculate — recompute every score ─────────

func (h *EquipmentHealthHandler) RecalculateAll(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	count, err := h.recalculateAllNodes(c.UserContext(), claims.TenantID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error recalculando scores")
	}

	return c.JSON(fiber.Map{"recalculated": count})
}

// ─── GET /factory/health/weights — weight configuration ───────────────────

func (h *EquipmentHealthHandler) GetWeights(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)

	rows, err := h.db.Query(c.UserContext(), `
		SELECT node_type, weights, expected_life_years, decay_per_day
		FROM health_weight_configs WHERE tenant_id = $1`, claims.TenantID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error cargando configuración")
	}
	defer rows.Close()

	var configs []fiber.Map
	for rows.Next() {
		var nodeType, weights string
		var lifeYears int
		var decay float64
		if err := rows.Scan(&nodeType, &weights, &lifeYears, &decay); err != nil {
			continue
		}
		configs = append(configs, fiber.Map{
			"node_type": nodeType, "weights": weights,
			"expected_life_years": lifeYears, "decay_per_day": decay,
		})
	}
	if configs == nil {
		configs = []fiber.Map{}
	}
	return c.JSON(fiber.Map{"configs": configs})
}

// ─── PUT /factory/health/weights/:nodeType — update the weights ───────────────

func (h *EquipmentHealthHandler) UpdateWeights(c *fiber.Ctx) error {
	claims := c.Locals("claims").(*types.Claims)
	nodeType := c.Params("nodeType")

	var body struct {
		Weights           map[string]float64 `json:"weights"`
		ExpectedLifeYears *int               `json:"expected_life_years"`
		DecayPerDay       *float64           `json:"decay_per_day"`
	}
	if err := c.BodyParser(&body); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "Datos inválidos")
	}

	lifeYears := 15
	if body.ExpectedLifeYears != nil {
		lifeYears = *body.ExpectedLifeYears
	}
	decay := 0.1
	if body.DecayPerDay != nil {
		decay = *body.DecayPerDay
	}

	_, err := h.db.Exec(c.UserContext(), `
		INSERT INTO health_weight_configs (tenant_id, node_type, weights, expected_life_years, decay_per_day)
		VALUES ($1, $2, $3, $4, $5)
		ON CONFLICT (tenant_id, node_type)
		DO UPDATE SET weights = $3, expected_life_years = $4, decay_per_day = $5`,
		claims.TenantID, nodeType, body.Weights, lifeYears, decay)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "Error guardando configuración")
	}
	return c.JSON(fiber.Map{"success": true})
}

// ─── HEALTH SCORE CALCULATION ────────────────────────────────────────────────

func (h *EquipmentHealthHandler) calculateHealth(ctx context.Context, tenantID, nodeID int64) (int, fiber.Map, error) {
	// Get the node data
	var nodeType, criticality string
	var yearInstalled *int
	err := h.db.QueryRow(ctx, `
		SELECT node_type, criticality, year_installed
		FROM factory_nodes WHERE id = $1 AND tenant_id = $2`,
		nodeID, tenantID).Scan(&nodeType, &criticality, &yearInstalled)
	if err != nil {
		return 0, nil, err
	}

	weights := defaultWeights
	var expectedLife int = 15
	var decayPerDay float64 = 0.1

	// Try to load custom weights
	var wJSON string
	err = h.db.QueryRow(ctx, `
		SELECT weights, expected_life_years, decay_per_day
		FROM health_weight_configs WHERE tenant_id = $1 AND node_type = $2`,
		tenantID, nodeType).Scan(&wJSON, &expectedLife, &decayPerDay)
	if err == nil && wJSON != "" {
		var cw map[string]float64
		if json.Unmarshal([]byte(wJSON), &cw) == nil {
			if v, ok := cw["failure_freq"]; ok {
				weights.FailureFreq = v
			}
			if v, ok := cw["pm_compliance"]; ok {
				weights.PMCompliance = v
			}
			if v, ok := cw["age"]; ok {
				weights.Age = v
			}
			if v, ok := cw["mtbf_trend"]; ok {
				weights.MTBFTrend = v
			}
			if v, ok := cw["corrective_ratio"]; ok {
				weights.CorrectiveRatio = v
			}
			if v, ok := cw["parts_consumption"]; ok {
				weights.PartsConsumption = v
			}
		}
	}

	// ─── Factor 1: Failure frequency (corrective WOs over 12 months) ───────
	var failureCount int
	h.db.QueryRow(ctx, `
		SELECT COUNT(*) FROM work_orders
		WHERE node_id = $1 AND tenant_id = $2 AND wo_type = 'corrective'
		  AND created_at >= NOW() - INTERVAL '12 months'`,
		nodeID, tenantID).Scan(&failureCount)
	failurePenalty := math.Min(float64(failureCount)*15.0, 100.0) // ~7 failures = 100

	// ─── Factor 2: Preventive compliance ────────────────────────────
	var pmTotal, pmOnTime int
	h.db.QueryRow(ctx, `
		SELECT COUNT(*),
		       COUNT(*) FILTER (WHERE mpe.executed_at <= mp.next_due_at + INTERVAL '3 days')
		FROM maintenance_plan_executions mpe
		JOIN maintenance_plans mp ON mp.id = mpe.plan_id
		WHERE mp.node_id = $1 AND mp.tenant_id = $2
		  AND mpe.executed_at >= NOW() - INTERVAL '6 months'`,
		nodeID, tenantID).Scan(&pmTotal, &pmOnTime)
	var compliancePenalty float64
	complianceRaw := 1.0
	if pmTotal > 0 {
		complianceRaw = float64(pmOnTime) / float64(pmTotal)
		compliancePenalty = (1.0 - complianceRaw) * 100.0
	} else {
		compliancePenalty = 30.0 // No preventive work = moderate penalty
		complianceRaw = 0.0
	}

	// ─── Factor 3: Age ─────────────────────────────────────────────────
	var agePenalty, ageRaw float64
	if yearInstalled != nil && *yearInstalled > 0 {
		age := float64(time.Now().Year() - *yearInstalled)
		lifeExpected := float64(expectedLife)
		ageRaw = age / lifeExpected
		if ageRaw > 0.7 {
			agePenalty = math.Min(math.Pow(ageRaw, 2)*100.0, 100.0) // Non-linear past 70%
		} else {
			agePenalty = ageRaw * 50.0 // Linear up to 70%
		}
	}

	// ─── Factor 4: MTBF trend ───────────────────────────────────────
	var mtbfRecent, mtbfOld *float64
	h.db.QueryRow(ctx, `
		WITH recent AS (
			SELECT EXTRACT(EPOCH FROM MAX(created_at) - MIN(created_at)) / 86400.0
			       / NULLIF(COUNT(*) - 1, 0) AS mtbf
			FROM work_orders
			WHERE node_id = $1 AND tenant_id = $2 AND wo_type = 'corrective'
			  AND created_at >= NOW() - INTERVAL '6 months'
		), older AS (
			SELECT EXTRACT(EPOCH FROM MAX(created_at) - MIN(created_at)) / 86400.0
			       / NULLIF(COUNT(*) - 1, 0) AS mtbf
			FROM work_orders
			WHERE node_id = $1 AND tenant_id = $2 AND wo_type = 'corrective'
			  AND created_at >= NOW() - INTERVAL '18 months'
			  AND created_at < NOW() - INTERVAL '6 months'
		)
		SELECT recent.mtbf, older.mtbf FROM recent, older`,
		nodeID, tenantID).Scan(&mtbfRecent, &mtbfOld)

	var mtbfPenalty, mtbfRaw float64
	if mtbfRecent != nil && mtbfOld != nil && *mtbfOld > 0 {
		mtbfRaw = (*mtbfRecent - *mtbfOld) / *mtbfOld // Positive = improving, negative = getting worse
		if mtbfRaw < 0 {
			mtbfPenalty = math.Min(math.Abs(mtbfRaw)*100.0, 100.0)
		}
	}

	// ─── Factor 5: Corrective ratio ─────────────────────────────────────
	var totalWOs, correctiveWOs int
	h.db.QueryRow(ctx, `
		SELECT COUNT(*),
		       COUNT(*) FILTER (WHERE wo_type = 'corrective')
		FROM work_orders
		WHERE node_id = $1 AND tenant_id = $2
		  AND created_at >= NOW() - INTERVAL '12 months'
		  AND status NOT IN ('cancelled', 'draft')`,
		nodeID, tenantID).Scan(&totalWOs, &correctiveWOs)
	var correctiveRatioPenalty, correctiveRatioRaw float64
	if totalWOs > 0 {
		correctiveRatioRaw = float64(correctiveWOs) / float64(totalWOs)
		correctiveRatioPenalty = correctiveRatioRaw * 100.0
	}

	// ─── Factor 6: Spare part consumption ─────────────────────────────────
	var recentCost, oldCost *float64
	h.db.QueryRow(ctx, `
		SELECT
			(SELECT COALESCE(SUM(sm.quantity * sm.unit_cost), 0)
			 FROM stock_movements sm
			 JOIN spare_part_nodes spn ON spn.spare_part_id = sm.spare_part_id
			 WHERE spn.node_id = $1 AND sm.tenant_id = $2 AND sm.movement_type = 'consume'
			   AND sm.created_at >= NOW() - INTERVAL '6 months'),
			(SELECT COALESCE(SUM(sm.quantity * sm.unit_cost), 0)
			 FROM stock_movements sm
			 JOIN spare_part_nodes spn ON spn.spare_part_id = sm.spare_part_id
			 WHERE spn.node_id = $1 AND sm.tenant_id = $2 AND sm.movement_type = 'consume'
			   AND sm.created_at >= NOW() - INTERVAL '12 months'
			   AND sm.created_at < NOW() - INTERVAL '6 months')`,
		nodeID, tenantID).Scan(&recentCost, &oldCost)

	var partsPenalty, partsRaw float64
	if recentCost != nil && oldCost != nil && *oldCost > 0 {
		partsRaw = *recentCost / *oldCost
		if partsRaw > 1.0 {
			partsPenalty = math.Min((partsRaw-1.0)*100.0, 100.0)
		}
	}

	// ─── Criticality modifier ──────────────────────────────────────
	critMult := 1.0
	switch criticality {
	case "critical":
		critMult = 1.2
	case "high":
		critMult = 1.1
	case "low":
		critMult = 0.8
	}

	// ─── Time decay ─────────────────────────────────────────────────
	var lastActivity *time.Time
	h.db.QueryRow(ctx, `
		SELECT MAX(updated_at) FROM work_orders
		WHERE node_id = $1 AND tenant_id = $2 AND status NOT IN ('cancelled', 'draft')`,
		nodeID, tenantID).Scan(&lastActivity)

	var decayPenalty float64
	if lastActivity != nil {
		daysSince := time.Since(*lastActivity).Hours() / 24.0
		if daysSince > 30 {
			decayPenalty = math.Min((daysSince-30)*decayPerDay, 15.0)
		}
	}

	// ─── Final calculation ──────────────────────────────────────────────────
	totalPenalty := (failurePenalty*weights.FailureFreq +
		compliancePenalty*weights.PMCompliance +
		agePenalty*weights.Age +
		mtbfPenalty*weights.MTBFTrend +
		correctiveRatioPenalty*weights.CorrectiveRatio +
		partsPenalty*weights.PartsConsumption) * critMult + decayPenalty

	score := int(math.Max(0, math.Min(100, 100-totalPenalty)))

	details := fiber.Map{
		"failure_freq":      fiber.Map{"penalty": round2(failurePenalty), "weight": weights.FailureFreq, "raw": failureCount},
		"pm_compliance":     fiber.Map{"penalty": round2(compliancePenalty), "weight": weights.PMCompliance, "raw": round2(complianceRaw)},
		"age":               fiber.Map{"penalty": round2(agePenalty), "weight": weights.Age, "raw": round2(ageRaw)},
		"mtbf_trend":        fiber.Map{"penalty": round2(mtbfPenalty), "weight": weights.MTBFTrend, "raw": round2(mtbfRaw)},
		"corrective_ratio":  fiber.Map{"penalty": round2(correctiveRatioPenalty), "weight": weights.CorrectiveRatio, "raw": round2(correctiveRatioRaw)},
		"parts_consumption": fiber.Map{"penalty": round2(partsPenalty), "weight": weights.PartsConsumption, "raw": round2(partsRaw)},
		"criticality_mult":  critMult,
		"decay_penalty":     round2(decayPenalty),
		"total_penalty":     round2(totalPenalty),
		"final_score":       score,
	}

	// Store it in factory_nodes
	h.db.Exec(ctx, `
		UPDATE factory_nodes SET health_score = $1, health_details = $2, health_calculated_at = NOW()
		WHERE id = $3 AND tenant_id = $4`,
		score, details, nodeID, tenantID)

	return score, details, nil
}

func round2(v float64) float64 {
	return math.Round(v*100) / 100
}

// ─── BULK RECALCULATION (called by the worker or the endpoint) ───────────────────────

func (h *EquipmentHealthHandler) recalculateAllNodes(ctx context.Context, tenantID int64) (int, error) {
	rows, err := h.db.Query(ctx, `
		SELECT id FROM factory_nodes
		WHERE tenant_id = $1 AND node_type IN ('equipment', 'component')
		  AND status = 'active'`, tenantID)
	if err != nil {
		return 0, err
	}
	defer rows.Close()

	var nodeIDs []int64
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			log.Printf("[ARCHE-HEALTH] WARN: scan node id: %v", err)
			continue
		}
		nodeIDs = append(nodeIDs, id)
	}

	count := 0
	today := time.Now().Format("2006-01-02")
	for _, nodeID := range nodeIDs {
		score, details, err := h.calculateHealth(ctx, tenantID, nodeID)
		if err != nil {
			continue
		}
		// Store the daily history
		h.db.Exec(ctx, `
			INSERT INTO equipment_health_history (tenant_id, node_id, score, details, recorded_at)
			VALUES ($1, $2, $3, $4, $5)
			ON CONFLICT (node_id, recorded_at) DO UPDATE SET score = $3, details = $4`,
			tenantID, nodeID, score, details, today)
		count++
	}

	// Aggregate parent scores (a line = the average of its child equipment weighted by criticality)
	h.db.Exec(ctx, `
		UPDATE factory_nodes parent SET
			health_score = sub.avg_score,
			health_calculated_at = NOW()
		FROM (
			SELECT fn.parent_id,
			       ROUND(SUM(child.health_score * CASE child.criticality
			           WHEN 'critical' THEN 1.5 WHEN 'high' THEN 1.2
			           WHEN 'medium' THEN 1.0 ELSE 0.8 END)
			       / NULLIF(SUM(CASE child.criticality
			           WHEN 'critical' THEN 1.5 WHEN 'high' THEN 1.2
			           WHEN 'medium' THEN 1.0 ELSE 0.8 END), 0))::int AS avg_score
			FROM factory_nodes child
			JOIN factory_nodes fn ON fn.id = child.parent_id
			WHERE child.tenant_id = $1 AND child.health_score IS NOT NULL
			  AND child.node_type IN ('equipment', 'component')
			GROUP BY fn.parent_id
		) sub
		WHERE parent.id = sub.parent_id AND parent.tenant_id = $1`,
		tenantID)

	return count, nil
}

// RecalculateForTenant is the entry point for the background worker
func (h *EquipmentHealthHandler) RecalculateForTenant(ctx context.Context, tenantID int64) (int, error) {
	return h.recalculateAllNodes(ctx, tenantID)
}

