//go:build !production

package static

import "github.com/gofiber/fiber/v2"

// Mount does nothing in development.
// The frontend is served from the Vite dev server (port 5173).
func Mount(app *fiber.App) {}
