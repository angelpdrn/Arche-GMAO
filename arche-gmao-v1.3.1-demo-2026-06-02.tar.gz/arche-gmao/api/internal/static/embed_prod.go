//go:build production

package static

import (
	"embed"
	"io/fs"
	"net/http"
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/filesystem"
)

//go:embed dist/*
var embeddedFS embed.FS

// Mount registers the static file serving for the embedded frontend.
// It must be called AFTER every /api/* route, so the fallback
// to index.html does not interfere with the API.
//
// Cache policy:
//   - Hashed assets (/assets/*): Cache-Control 1 year (immutable)
//   - index.html and the rest: no-cache (always revalidate)
//   - Fallback to index.html for every non-API route (Vue Router history mode)
func Mount(app *fiber.App) {
	distFS, err := fs.Sub(embeddedFS, "dist")
	if err != nil {
		panic("Error montando frontend embebido: " + err.Error())
	}

	// Cache header middleware
	app.Use(func(c *fiber.Ctx) error {
		path := c.Path()

		// Leave API routes alone
		if strings.HasPrefix(path, "/api/") {
			return c.Next()
		}

		err := c.Next()

		// Apply the cache headers AFTER serving
		if c.Response().StatusCode() == 200 {
			if strings.HasPrefix(path, "/assets/") {
				// Assets with a hash in the name: cache for 1 year
				c.Set("Cache-Control", "public, max-age=31536000, immutable")
			} else if path == "/" || strings.HasSuffix(path, ".html") {
				// HTML: always revalidate
				c.Set("Cache-Control", "no-cache, no-store, must-revalidate")
				c.Set("Pragma", "no-cache")
			} else if strings.HasPrefix(path, "/icons/") || path == "/manifest.json" || path == "/sw.js" {
				// PWA assets: short cache, revalidate
				c.Set("Cache-Control", "public, max-age=3600, must-revalidate")
			}
		}

		return err
	})

	// Serve static files
	app.Use("/", filesystem.New(filesystem.Config{
		Root:       http.FS(distFS),
		Browse:     false,
		Index:      "index.html",
		NotFoundFile: "index.html", // Fallback for Vue Router history mode
	}))
}
