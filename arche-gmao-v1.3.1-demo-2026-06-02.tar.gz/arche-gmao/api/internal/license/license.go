package license

import (
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"log"
	"net"
	"os"
	"slices"
	"strings"
	"time"
)

// publicKeyHex is injected at build time with:
//
//	-ldflags "-X arche-gmao/api/internal/license.publicKeyHex=..."
//
// In dev it stays empty and the check is skipped.
var publicKeyHex string

// ─── Types ───────────────────────────────────────────────────────────────────────

type Payload struct {
	LicenseID   string   `json:"license_id"`
	ClientName  string   `json:"client_name"`
	ClientID    string   `json:"client_id"`
	Modules     []string `json:"modules"`
	MaxUsers    int      `json:"max_users"`
	MaxNodes    int      `json:"max_nodes"`
	MaxTenants  int      `json:"max_tenants"`
	HardwareID  string   `json:"hardware_id,omitempty"`
	IssuedAt    string   `json:"issued_at"`
	ExpiresAt   string   `json:"expires_at"`
	Version     string   `json:"version"`
}

type SignedLicense struct {
	Payload   json.RawMessage `json:"payload"`
	Signature string          `json:"signature"`
}

type Info struct {
	Valid      bool
	LicenseID  string
	ClientName string
	ClientID   string
	Modules    []string
	MaxUsers   int
	MaxNodes   int
	MaxTenants int
	ExpiresAt  time.Time
	DaysLeft   int
	Error      string
}

var Current *Info

// ─── Verification ──────────────────────────────────────────────────────────

func Load(path string) (*Info, error) {
	if path == "" {
		path = os.Getenv("ARCHE_LICENSE_PATH")
	}
	if path == "" {
		path = "/opt/arche-gmao/config/license.key"
	}

	data, err := os.ReadFile(path)
	if err != nil {
		return &Info{Valid: false, Error: "Archivo de licencia no encontrado: " + path}, nil
	}

	raw, err := base64.StdEncoding.DecodeString(strings.TrimSpace(string(data)))
	if err != nil {
		return &Info{Valid: false, Error: "Licencia corrupta (base64)"}, nil
	}

	var signed SignedLicense
	if err := json.Unmarshal(raw, &signed); err != nil {
		return &Info{Valid: false, Error: "Licencia corrupta (JSON)"}, nil
	}

	// --- Verify the Ed25519 signature ---
	pubKey, err := decodePublicKey()
	if err != nil {
		return &Info{Valid: false, Error: "Clave publica no configurada: " + err.Error()}, nil
	}

	sigBytes, err := base64.StdEncoding.DecodeString(signed.Signature)
	if err != nil {
		return &Info{Valid: false, Error: "Firma corrupta"}, nil
	}

	if !ed25519.Verify(pubKey, signed.Payload, sigBytes) {
		return &Info{Valid: false, Error: "Firma invalida — licencia no autentica"}, nil
	}

	// --- Parse the payload ---
	var payload Payload
	if err := json.Unmarshal(signed.Payload, &payload); err != nil {
		return &Info{Valid: false, Error: "Payload corrupto"}, nil
	}

	// --- Check the version ---
	if payload.Version != "2.0" {
		return &Info{Valid: false, Error: "Version de licencia incompatible: " + payload.Version}, nil
	}

	// --- Check the expiry ---
	expiresAt, err := time.Parse(time.RFC3339, payload.ExpiresAt)
	if err != nil {
		return &Info{Valid: false, Error: "Fecha de caducidad invalida"}, nil
	}

	daysLeft := int(time.Until(expiresAt).Hours() / 24)
	if daysLeft < 0 {
		return &Info{
			Valid:      false,
			ClientName: payload.ClientName,
			Error:      fmt.Sprintf("Licencia caducada hace %d dias", -daysLeft),
		}, nil
	}

	// --- Check the hardware fingerprint (when present) ---
	if payload.HardwareID != "" {
		localFP := HardwareFingerprint()
		if localFP != payload.HardwareID {
			return &Info{
				Valid:      false,
				ClientName: payload.ClientName,
				Error:      "Hardware no coincide con la licencia",
			}, nil
		}
	}

	info := &Info{
		Valid:      true,
		LicenseID:  payload.LicenseID,
		ClientName: payload.ClientName,
		ClientID:   payload.ClientID,
		Modules:    payload.Modules,
		MaxUsers:   payload.MaxUsers,
		MaxNodes:   payload.MaxNodes,
		MaxTenants: payload.MaxTenants,
		ExpiresAt:  expiresAt,
		DaysLeft:   daysLeft,
	}

	Current = info
	return info, nil
}

func decodePublicKey() (ed25519.PublicKey, error) {
	if publicKeyHex == "" {
		return nil, fmt.Errorf("no hay clave publica embebida (build sin -ldflags?)")
	}
	b, err := hex.DecodeString(publicKeyHex)
	if err != nil {
		return nil, fmt.Errorf("clave publica hex invalida: %w", err)
	}
	if len(b) != ed25519.PublicKeySize {
		return nil, fmt.Errorf("tamano de clave incorrecto: %d bytes", len(b))
	}
	return ed25519.PublicKey(b), nil
}

// HasModule checks whether a module is enabled in the global license.
func HasModule(module string) bool {
	if Current == nil || !Current.Valid {
		return false
	}
	return slices.Contains(Current.Modules, module) || slices.Contains(Current.Modules, "all")
}

// HasModuleForTenant checks the global license AND that the tenant does not have the module disabled.
func HasModuleForTenant(module string, disabledModules []string) bool {
	if !HasModule(module) {
		return false
	}
	return !slices.Contains(disabledModules, module)
}

// GetMaxUsers returns the license's user limit. 0 = unlimited.
func GetMaxUsers() int {
	if Current == nil {
		return 0
	}
	return Current.MaxUsers
}

// GetMaxNodes returns the license's node limit. 0 = unlimited.
func GetMaxNodes() int {
	if Current == nil {
		return 0
	}
	return Current.MaxNodes
}

// GetMaxTenants returns the license's tenant limit. 0 = unlimited.
func GetMaxTenants() int {
	if Current == nil {
		return 0
	}
	return Current.MaxTenants
}

// HardwareFingerprint builds a hash of the local hardware.
// It combines machine-id + the MAC of the first active interface.
func HardwareFingerprint() string {
	machineID, _ := os.ReadFile("/etc/machine-id")
	mac := primaryMAC()

	h := sha256.New()
	h.Write([]byte(strings.TrimSpace(string(machineID))))
	h.Write([]byte("|"))
	h.Write([]byte(mac))
	return hex.EncodeToString(h.Sum(nil))
}

func primaryMAC() string {
	ifaces, err := net.Interfaces()
	if err != nil {
		return ""
	}
	for _, iface := range ifaces {
		if iface.Flags&net.FlagLoopback != 0 || iface.Flags&net.FlagUp == 0 {
			continue
		}
		mac := iface.HardwareAddr.String()
		if mac != "" {
			return mac
		}
	}
	return ""
}

// ─── Check — startup verification ───────────────────────────────────────

func Check(path string) {
	// In dev, init() already marked Current as valid
	if Current != nil && Current.Valid {
		return
	}

	info, err := Load(path)
	if err != nil {
		log.Fatalf("[ARCHE-LICENSE] Error cargando licencia: %v", err)
	}

	if !info.Valid {
		fmt.Printf("\n")
		fmt.Printf("  ╔══════════════════════════════════════════════════╗\n")
		fmt.Printf("  ║       ARCHE GMAO — LICENCIA INVALIDA          ║\n")
		fmt.Printf("  ╠══════════════════════════════════════════════════╣\n")
		fmt.Printf("  ║  %-47s ║\n", info.Error)
		fmt.Printf("  ║  Contacte con Arche GMAO.                      ║\n")
		fmt.Printf("  ╚══���═══════════════════════════════════════════════╝\n\n")
		os.Exit(1)
	}

	log.Printf("[ARCHE-LICENSE] %s | Modulos: %v | Users: %d | Nodos: %d | Caduca en %d dias",
		info.ClientName, info.Modules, info.MaxUsers, info.MaxNodes, info.DaysLeft)

	if info.DaysLeft <= 30 {
		log.Printf("[ARCHE-LICENSE] AVISO: La licencia caduca en %d dias", info.DaysLeft)
	}
}

// ─── Periodic check (goroutine) ────────────────────────────────────────────

func StartPeriodicCheck(path string, stopCh <-chan struct{}) {
	go func() {
		ticker := time.NewTicker(24 * time.Hour)
		defer ticker.Stop()

		graceDeadline := time.Time{}

		for {
			select {
			case <-stopCh:
				return
			case <-ticker.C:
				info, err := Load(path)
				if err != nil || !info.Valid {
					msg := "desconocido"
					if info != nil {
						msg = info.Error
					}
					if graceDeadline.IsZero() {
						graceDeadline = time.Now().Add(72 * time.Hour)
						log.Printf("[ARCHE-LICENSE] Licencia invalida: %s — gracia hasta %s",
							msg, graceDeadline.Format("2006-01-02 15:04"))
					} else if time.Now().After(graceDeadline) {
						log.Fatalf("[ARCHE-LICENSE] Periodo de gracia agotado. Sistema detenido. Error: %s", msg)
					} else {
						remaining := time.Until(graceDeadline).Hours()
						log.Printf("[ARCHE-LICENSE] Licencia invalida: %s — %.0fh de gracia restantes", msg, remaining)
					}
				} else {
					graceDeadline = time.Time{}
					if info.DaysLeft <= 30 {
						log.Printf("[ARCHE-LICENSE] La licencia caduca en %d dias", info.DaysLeft)
					}
				}
			}
		}
	}()
}
