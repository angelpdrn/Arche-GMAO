package license

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"sync"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
)

var phoneHomeURL = getPhoneHomeURL()

func getPhoneHomeURL() string {
	if u := os.Getenv("ARCHE_PHONEHOME_URL"); u != "" {
		return u
	}
	return "https://archesystem.com/api/license/check.php"
}

type PhoneHomeRequest struct {
	LicenseID      string `json:"license_id"`
	HardwareID     string `json:"hardware_id"`
	AppVersion     string `json:"app_version"`
	CurrentUsers   int    `json:"current_users"`
	CurrentEquipos int    `json:"current_equipos"`
	CurrentTenants int    `json:"current_tenants"`
}

type PhoneHomeResponse struct {
	Status        string         `json:"status"`
	PenaltyLevel  string         `json:"penalty_level"`
	Message       string         `json:"message"`
	Limits        PhoneHomeLimits `json:"limits"`
	DaysLeft      int            `json:"days_left"`
	ExpiresAt     string         `json:"expires_at"`
	SignedLicense string         `json:"signed_license,omitempty"`
}

type PhoneHomeLimits struct {
	MaxUsers    int  `json:"max_users"`
	MaxEquipos  int  `json:"max_equipos"`
	MaxTenants  int  `json:"max_tenants"`
	IAEnabled   bool `json:"ia_enabled"`
}

var (
	penaltyMu    sync.RWMutex
	penaltyLevel = "none"

	lastPhoneHome     time.Time
	phoneHomeFailures int
)

func GetPenaltyLevel() string {
	penaltyMu.RLock()
	defer penaltyMu.RUnlock()
	return penaltyLevel
}

func SetPenaltyLevel(level string) {
	penaltyMu.Lock()
	defer penaltyMu.Unlock()
	penaltyLevel = level
}

func IsReadOnly() bool {
	level := GetPenaltyLevel()
	return level == "lectura" || level == "bloqueo" || level == "suspension"
}

func IsBlocked() bool {
	level := GetPenaltyLevel()
	return level == "bloqueo" || level == "suspension"
}

func IsSuspended() bool {
	return GetPenaltyLevel() == "suspension"
}

func StartPhoneHome(db *pgxpool.Pool, appVersion string, stopCh <-chan struct{}) {
	go func() {
		// First check after 1 minute (give time for server to fully start)
		time.Sleep(1 * time.Minute)
		doPhoneHome(db, appVersion)

		ticker := time.NewTicker(24 * time.Hour)
		defer ticker.Stop()

		for {
			select {
			case <-stopCh:
				return
			case <-ticker.C:
				doPhoneHome(db, appVersion)
			}
		}
	}()
}

func doPhoneHome(db *pgxpool.Pool, appVersion string) {
	if Current == nil || Current.ClientID == "" || Current.ClientID == "dev" {
		return
	}

	ctx := context.Background()

	// Count current usage
	var userCount, equipoCount, tenantCount int
	db.QueryRow(ctx, `SELECT COUNT(*) FROM users WHERE status = 'active'`).Scan(&userCount)
	db.QueryRow(ctx, `SELECT COUNT(*) FROM factory_nodes WHERE node_type = 'equipment'`).Scan(&equipoCount)
	db.QueryRow(ctx, `SELECT COUNT(*) FROM tenants`).Scan(&tenantCount)

	req := PhoneHomeRequest{
		LicenseID:      Current.LicenseID,
		HardwareID:     HardwareFingerprint(),
		AppVersion:     appVersion,
		CurrentUsers:   userCount,
		CurrentEquipos: equipoCount,
		CurrentTenants: tenantCount,
	}

	body, _ := json.Marshal(req)

	client := &http.Client{Timeout: 30 * time.Second}
	resp, err := client.Post(phoneHomeURL, "application/json", bytes.NewReader(body))
	if err != nil {
		phoneHomeFailures++
		log.Printf("[ARCHE-PHONEHOME] Error conectando (%d fallos): %v", phoneHomeFailures, err)
		handlePhoneHomeFailure()
		return
	}
	defer resp.Body.Close()

	respBody, err := io.ReadAll(resp.Body)
	if err != nil {
		phoneHomeFailures++
		log.Printf("[ARCHE-PHONEHOME] Error leyendo respuesta: %v", err)
		handlePhoneHomeFailure()
		return
	}

	var phResp PhoneHomeResponse
	if err := json.Unmarshal(respBody, &phResp); err != nil {
		phoneHomeFailures++
		log.Printf("[ARCHE-PHONEHOME] Error parseando respuesta: %v", err)
		handlePhoneHomeFailure()
		return
	}

	// Success
	phoneHomeFailures = 0
	lastPhoneHome = time.Now()

	// Update penalty level
	oldLevel := GetPenaltyLevel()
	SetPenaltyLevel(phResp.PenaltyLevel)

	if phResp.PenaltyLevel != oldLevel {
		log.Printf("[ARCHE-PHONEHOME] Nivel de penalizacion: %s -> %s", oldLevel, phResp.PenaltyLevel)
	}

	// Update limits from server (remote limit changes)
	if phResp.Limits.MaxUsers > 0 {
		Current.MaxUsers = phResp.Limits.MaxUsers
	}
	if phResp.Limits.MaxEquipos > 0 {
		Current.MaxNodes = phResp.Limits.MaxEquipos
	}
	if phResp.Limits.MaxTenants > 0 {
		Current.MaxTenants = phResp.Limits.MaxTenants
	}
	Current.DaysLeft = phResp.DaysLeft

	// Update AI module
	if phResp.Limits.IAEnabled {
		if !hasModule(Current.Modules, "ai") {
			Current.Modules = append(Current.Modules, "ai")
		}
	} else {
		Current.Modules = removeModule(Current.Modules, "ai")
	}

	if phResp.Message != "" {
		log.Printf("[ARCHE-PHONEHOME] %s (dias: %d, penalizacion: %s)",
			phResp.Message, phResp.DaysLeft, phResp.PenaltyLevel)
	}
}

func handlePhoneHomeFailure() {
	// Grace period: if we can't reach the server for 7 days, go to read-only
	// 14 days = blocked, 30 days = suspended
	if lastPhoneHome.IsZero() {
		return
	}

	daysSince := int(time.Since(lastPhoneHome).Hours() / 24)
	switch {
	case daysSince >= 30:
		SetPenaltyLevel("suspension")
		log.Printf("[ARCHE-PHONEHOME] %d dias sin phone-home -> suspension", daysSince)
	case daysSince >= 14:
		SetPenaltyLevel("bloqueo")
		log.Printf("[ARCHE-PHONEHOME] %d dias sin phone-home -> bloqueo", daysSince)
	case daysSince >= 7:
		SetPenaltyLevel("lectura")
		log.Printf("[ARCHE-PHONEHOME] %d dias sin phone-home -> modo lectura", daysSince)
	}
}

func hasModule(modules []string, mod string) bool {
	for _, m := range modules {
		if m == mod {
			return true
		}
	}
	return false
}

func removeModule(modules []string, mod string) []string {
	result := make([]string, 0, len(modules))
	for _, m := range modules {
		if m != mod {
			result = append(result, m)
		}
	}
	return result
}

func PhoneHomeStatus() map[string]interface{} {
	return map[string]interface{}{
		"penalty_level":     GetPenaltyLevel(),
		"last_phone_home":   lastPhoneHome.Format(time.RFC3339),
		"failures":          phoneHomeFailures,
		"is_read_only":      IsReadOnly(),
		"is_blocked":        IsBlocked(),
		"is_suspended":      IsSuspended(),
	}
}

func FormatPenaltyMessage() string {
	level := GetPenaltyLevel()
	switch level {
	case "aviso":
		return fmt.Sprintf("Su licencia caduca en %d días. Contacte con Arche GMAO para renovar.", Current.DaysLeft)
	case "lectura":
		return "Licencia caducada. Sistema en modo solo lectura."
	case "bloqueo":
		return "Licencia caducada. Acceso restringido a consulta básica."
	case "suspension":
		return "Licencia suspendida. Sistema bloqueado."
	default:
		return ""
	}
}
