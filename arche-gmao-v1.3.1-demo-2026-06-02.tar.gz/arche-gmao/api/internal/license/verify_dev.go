//go:build !production

package license

import "log"

func init() {
	// In development, when there is no public key we mark the license as valid
	// so the system starts without one.
	if publicKeyHex == "" {
		Current = &Info{
			Valid:      true,
			LicenseID:  "dev-license",
			ClientName: "Desarrollo",
			ClientID:   "dev",
			Modules:    []string{"all"},
			MaxUsers:   999,
			MaxNodes:   9999,
			MaxTenants: 99,
			DaysLeft:   9999,
		}
		log.Println("[ARCHE-LICENSE] Modo desarrollo — licencia omitida")
	}
}
