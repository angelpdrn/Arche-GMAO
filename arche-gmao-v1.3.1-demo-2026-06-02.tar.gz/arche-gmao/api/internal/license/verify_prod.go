//go:build production

package license

// In production, Check() and Load() use the Ed25519 public key
// injected through ldflags into publicKeyHex.
// If the key is missing or the license is invalid, the system does not start.

func init() {
	if publicKeyHex == "" {
		panic("[ARCHE-LICENSE] Build de produccion sin clave publica embebida. Usar build.sh.")
	}
}
