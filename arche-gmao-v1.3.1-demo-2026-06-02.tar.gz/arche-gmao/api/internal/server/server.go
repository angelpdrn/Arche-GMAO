package server

import (
	"context"
	"log"
	"os"
	"time"

	"arche-gmao/api/internal/ai"
	"arche-gmao/api/internal/config"
	"arche-gmao/api/internal/handlers"
	"arche-gmao/api/internal/license"
	"arche-gmao/api/internal/middleware"
	"arche-gmao/api/internal/static"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/compress"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/gofiber/fiber/v2/middleware/etag"
	fiberlogger "github.com/gofiber/fiber/v2/middleware/logger"
	"github.com/gofiber/fiber/v2/middleware/limiter"
	"github.com/gofiber/fiber/v2/middleware/recover"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/redis/go-redis/v9"
)

// Server wraps the Fiber app and background workers for graceful shutdown.
type Server struct {
	App           *fiber.App
	stopWorkers   func()
}

// Shutdown stops all background workers gracefully.
func (s *Server) Shutdown() {
	if s.stopWorkers != nil {
		s.stopWorkers()
	}
}

func New(cfg *config.Config, db *pgxpool.Pool, rdb *redis.Client) *Server {
	app := fiber.New(fiber.Config{
		AppName:               "Arche GMAO API " + handlers.Version,
		ErrorHandler:          errorHandler,
		ReadTimeout:           30 * time.Second,
		WriteTimeout:          120 * time.Second,
		IdleTimeout:           60 * time.Second,
		BodyLimit:             55 * 1024 * 1024,
		DisableStartupMessage: false,
		ReduceMemoryUsage:     true,
	})

	app.Use(recover.New())
	app.Use(compress.New(compress.Config{Level: compress.LevelDefault}))
	app.Use(etag.New())
	app.Use(middleware.SecurityHeaders())
	app.Use(fiberlogger.New(fiberlogger.Config{
		Format: "[ARCHE] ${time} | ${status} | ${latency} | ${method} ${path}\n",
	}))

	// CORS configurable through an env var, with a dev fallback
	allowedOrigins := os.Getenv("CORS_ORIGINS")
	if allowedOrigins == "" {
		allowedOrigins = "http://localhost:5173"
	}
	app.Use(cors.New(cors.Config{
		AllowOrigins:     allowedOrigins,
		AllowHeaders:     "Origin, Content-Type, Accept, Authorization",
		AllowMethods:     "GET, POST, PUT, PATCH, DELETE, OPTIONS",
		AllowCredentials: true,
		MaxAge:           3600,
	}))

	ollamaURL  := cfg.OllamaURL
	chatModel  := cfg.OllamaChatModel
	embedModel := cfg.OllamaEmbedModel
	if ollamaURL  == "" { ollamaURL  = "http://host.docker.internal:11434" }
	if chatModel  == "" { chatModel  = "llama3" }
	if embedModel == "" { embedModel = "nomic-embed-text" }

	baseURL := os.Getenv("APP_BASE_URL")
	if baseURL == "" { baseURL = "http://localhost:5173" }

	ollamaClient    := ai.NewOllamaClient(ollamaURL, chatModel, embedModel)
	ragService      := ai.NewRAGService(db, ollamaClient)
	promptBuilder   := ai.NewPromptBuilder(db)
	indexWorker     := ai.NewIndexWorker(db, ragService)
	patternDetector := ai.NewPatternDetector(db)
	staggerService  := ai.NewStaggeringService(db)
	maintWorker     := ai.NewMaintenanceWorker(db)
	summaryWorker   := ai.NewMonthlySummaryWorker(db)
	aiSemaphore     := ai.NewAISemaphore(3)

	indexWorker.Start()
	maintWorker.Start()
	summaryWorker.Start()

	// Register Redis for the access token blacklist in RequireAuth.
	middleware.SetRedisClient(rdb)

	// ── Push Service + notification for the workers ────────────────────────────
	pushService := handlers.NewPushService(db, cfg.VAPIDPublicKey, cfg.VAPIDPrivateKey, cfg.VAPIDContact)
	handlers.SetGlobalPushService(pushService)
	// Inject the notification callbacks into the workers
	maintWorker.SetNotifyFunc(func(db *pgxpool.Pool, tenantID, userID int64, notifType, title, body string, link *string) {
		handlers.Notify(db, pushService, tenantID, userID, notifType, title, body, link)
	})
	indexWorker.SetNotifyRoleFunc(func(db *pgxpool.Pool, tenantID int64, role, notifType, title, body string, link *string) {
		handlers.NotifyRole(db, pushService, tenantID, role, notifType, title, body, link)
	})

	if pushService.Enabled() {
		log.Printf("[ARCHE] Push notifications habilitadas (VAPID configurado)")
	} else {
		log.Printf("[ARCHE] Push notifications deshabilitadas — configure VAPID_PUBLIC_KEY y VAPID_PRIVATE_KEY")
	}

	// Sync the license's max_users across every tenant
	if maxU := license.GetMaxUsers(); maxU > 0 {
		_, err := db.Exec(context.Background(),
			`UPDATE tenants SET max_users = $1 WHERE max_users IS NULL OR max_users != $1`, maxU)
		if err != nil {
			log.Printf("[ARCHE-LICENSE] Error sincronizando max_users: %v", err)
		} else {
			log.Printf("[ARCHE-LICENSE] max_users sincronizado: %d", maxU)
		}
	}

	log.Printf("[ARCHE] API %s — Ollama: %s | BaseURL: %s", handlers.Version, ollamaURL, baseURL)

	healthHandler       := handlers.NewHealthHandler(db, rdb)
	authHandler         := handlers.NewAuthHandler(db, rdb, cfg)
	systemHandler       := handlers.NewSystemHandler(db, rdb)
	superadminHandler   := handlers.NewSuperadminHandler(db, rdb)
	nodesHandler        := handlers.NewNodesHandler(db)
	clientsHandler      := handlers.NewClientsHandler(db)
	nodeTypesHandler    := handlers.NewNodeTypesHandler(db)
	woHandler           := handlers.NewWorkOrdersHandler(db, staggerService)
	spareHandler        := handlers.NewSparePartsHandler(db)
	usersHandler        := handlers.NewUsersHandler(db, rdb)
	personnelHandler    := handlers.NewPersonnelHandler(db)
	_ = handlers.NewVerificationHandler(db) // Verifications self-managed since v1.8
	calendarHandler     := handlers.NewCalendarHandler(db)
	libraryHandler      := handlers.NewLibraryHandler(db)
	dirHandler          := handlers.NewDirectoriesHandler(db)
	templatesHandler    := handlers.NewTemplatesHandler(db)
	aiHandler           := handlers.NewAIHandler(db, ollamaClient, ragService, promptBuilder, indexWorker, aiSemaphore)
	aiAdminHandler      := handlers.NewAIAdminHandler(db, ragService, ollamaClient, aiSemaphore)
	reportsHandler      := handlers.NewReportsHandler(db)
	patternsHandler     := handlers.NewPatternsHandler(db, patternDetector)
	metricsHandler      := handlers.NewMetricsHandler(db)
	maintHandler        := handlers.NewMaintenanceHandler(db)
	staggerHandler      := handlers.NewStaggeringHandler(db, staggerService)
	maintTemplateHandler := handlers.NewMaintenancePlanTemplateHandler(db)
	manualsHandler      := handlers.NewMaintenanceManualsHandler(db)
	techHandler         := handlers.NewTechnicianHandler(db)
	signatureHandler    := handlers.NewSignatureHandler(db)
	notifHandler        := handlers.NewNotificationHandler(db)
	qrHandler           := handlers.NewQRHandler(db, baseURL)
	pushHandler         := handlers.NewPushHandler(db, cfg)
	importHandler       := handlers.NewImportHandler(db)
	userProfileHandler  := handlers.NewUserProfileHandler(db, rdb)
	dailySummariesHandler := handlers.NewDailySummariesHandler(db)
	compositionHandler  := handlers.NewCompositionHandler(db)
	compTemplateHandler := handlers.NewCompositionTemplateHandler(db)
	licenseHandler      := handlers.NewLicenseHandler(db)
	procedureHandler    := handlers.NewProcedureHandler(db, ollamaClient)
	equipHealthHandler  := handlers.NewEquipmentHealthHandler(db)

	api := app.Group("/api/v1")

	// QR scan API route — it tries to authenticate but does not require it
	// The frontend (ScanView.vue) consumes this endpoint with axios (Bearer token included)
	scanLimiter := limiter.New(limiter.Config{
		Max: 30, Expiration: time.Minute,
		KeyGenerator: func(c *fiber.Ctx) string { return c.IP() },
		LimitReached: func(c *fiber.Ctx) error {
			return c.Status(fiber.StatusTooManyRequests).JSON(fiber.Map{"error": "Demasiadas solicitudes de escaneo."})
		},
	})
	api.Get("/scan/:code", scanLimiter, middleware.OptionalAuth(cfg), qrHandler.ScanPage)

	loginLimiter := limiter.New(limiter.Config{
		Max: 10, Expiration: time.Minute,
		KeyGenerator: func(c *fiber.Ctx) string { return c.IP() },
		LimitReached: func(c *fiber.Ctx) error {
			return c.Status(fiber.StatusTooManyRequests).JSON(fiber.Map{"error": "Demasiados intentos."})
		},
	})
	// Global rate limiter: 120 req/min per IP for protected endpoints
	globalLimiter := limiter.New(limiter.Config{
		Max: 120, Expiration: time.Minute,
		KeyGenerator: func(c *fiber.Ctx) string { return c.IP() },
		LimitReached: func(c *fiber.Ctx) error {
			return c.Status(fiber.StatusTooManyRequests).JSON(fiber.Map{"error": "Límite de peticiones excedido."})
		},
	})
	// Rate limiter for uploads: 10 req/min
	uploadLimiter := limiter.New(limiter.Config{
		Max: 10, Expiration: time.Minute,
		KeyGenerator: func(c *fiber.Ctx) string { return c.IP() },
		LimitReached: func(c *fiber.Ctx) error {
			return c.Status(fiber.StatusTooManyRequests).JSON(fiber.Map{"error": "Demasiados uploads."})
		},
	})
	api.Get("/health", healthHandler.Check)
	// Content-Type validation BEFORE the limiter on login, so clients sending the
	// wrong format do not burn quota (415, not 429). Refresh accepts a
	// cookie with no body, which is why CT is not validated there.
	api.Post("/auth/login", middleware.RequireJSONContentType(), loginLimiter, authHandler.Login)
	api.Post("/auth/refresh", loginLimiter, authHandler.Refresh)
	api.Get("/push/vapid-public-key", pushHandler.GetVAPIDPublicKey)

	protected := api.Group("", middleware.RequireAuth(cfg), middleware.SetTenantContext(), globalLimiter, middleware.RequireSystemActive(db, rdb), middleware.PenaltyGuard())
	protected.Post("/auth/logout", authHandler.Logout)
	protected.Get("/auth/me", authHandler.Me)

	// License — info for the frontend
	protected.Get("/license/info", licenseHandler.Info)

	// Push
	push := protected.Group("/push")
	push.Post("/subscribe", pushHandler.Subscribe)
	push.Delete("/unsubscribe", pushHandler.Unsubscribe)

	// ─── Import ──────────────────────────────────────────────────────────
	importGroup := protected.Group("/import", middleware.RequireRole("admin", "supervisor"))
	importGroup.Get("/template", importHandler.DownloadTemplate)
	importGroup.Post("/nodes", importHandler.ImportNodes)
	importGroup.Get("/conflicts", importHandler.Conflicts)
	importGroup.Post("/cleanup", middleware.RequireRole("admin"), importHandler.Cleanup)

	// Virtual Factory
	factory := protected.Group("/factory")
	factory.Get("/tree", nodesHandler.GetTree)
	factory.Get("/search", nodesHandler.Search)
	factory.Post("/nodes", middleware.RequireRole("admin", "supervisor"), nodesHandler.Create)
	factory.Get("/nodes/qr-sheet", middleware.RequireModuleTenant(db, "qr"), qrHandler.PrintSheet)
	factory.Get("/nodes/qr-excel", middleware.RequireModuleTenant(db, "qr"), qrHandler.QRExcel)
	factory.Post("/nodes/clone", middleware.RequireRole("admin", "supervisor"), compTemplateHandler.CloneEquipment)
	nodeScope := middleware.RequireNodeScope(db)
	factory.Get("/nodes/:id", nodeScope, nodesHandler.GetOne)
	factory.Put("/nodes/:id", nodeScope, middleware.RequireRole("admin", "supervisor"), nodesHandler.Update)
	factory.Delete("/nodes/:id", nodeScope, middleware.RequireRole("admin", "supervisor"), nodesHandler.Delete)
	factory.Patch("/nodes/:id/move", nodeScope, middleware.RequireRole("admin", "supervisor"), nodesHandler.Move)
	factory.Get("/nodes/:id/children", nodeScope, nodesHandler.GetChildren)
	factory.Get("/nodes/:id/personnel", nodeScope, personnelHandler.GetNodePersonnel)
	factory.Delete("/nodes/:id/personnel/:userId", nodeScope, middleware.RequireRole("admin", "supervisor"), personnelHandler.RemoveFromNode)
	factory.Post("/nodes/:id/personnel/:userId/exclude", nodeScope, middleware.RequireRole("admin", "supervisor"), personnelHandler.ExcludeFromNode)
	factory.Delete("/nodes/:id/personnel/:userId/exclude", nodeScope, middleware.RequireRole("admin", "supervisor"), personnelHandler.RestoreToNode)
	factory.Post("/nodes/:id/spare-parts", nodeScope, middleware.RequireRole("admin", "supervisor", "warehouse"), spareHandler.LinkToNode)
	factory.Delete("/nodes/:id/spare-parts/:spareId", nodeScope, middleware.RequireRole("admin", "supervisor", "warehouse"), spareHandler.UnlinkFromNode)
	factory.Get("/nodes/:id/library", nodeScope, libraryHandler.ListByNode)
	factory.Post("/nodes/:id/library/upload", nodeScope, uploadLimiter, libraryHandler.Upload)
	factory.Patch("/nodes/:id/template", nodeScope, templatesHandler.AssignToNode)
	factory.Get("/nodes/:id/siblings", nodeScope, templatesHandler.GetSiblings)
	factory.Get("/nodes/:id/patterns", nodeScope, patternsHandler.GetNodePatterns)
	factory.Get("/nodes/:id/metrics", nodeScope, metricsHandler.NodeMetrics)
	factory.Get("/nodes/:id/health", nodeScope, equipHealthHandler.GetNodeHealth)
	factory.Get("/nodes/:id/health/history", nodeScope, equipHealthHandler.GetHealthHistory)
	factory.Get("/nodes/:id/qr", nodeScope, middleware.RequireModuleTenant(db, "qr"), qrHandler.GenerateQR)
	factory.Get("/nodes/:id/qr-scans", nodeScope, middleware.RequireModuleTenant(db, "qr"), qrHandler.ScanHistory)
	factory.Get("/nodes/:id/manuals", nodeScope, manualsHandler.ListByNode)
	factory.Post("/nodes/:id/manuals/upload", nodeScope, uploadLimiter, middleware.RequireRole("admin", "supervisor"), manualsHandler.Upload)
	factory.Get("/nodes/:id/manuals/:manualId/download", nodeScope, manualsHandler.Download)
	factory.Put("/nodes/:id/manuals/:manualId", nodeScope, middleware.RequireRole("admin", "supervisor"), manualsHandler.Update)
	factory.Delete("/nodes/:id/manuals/:manualId", nodeScope, middleware.RequireRole("admin", "supervisor"), manualsHandler.Delete)

	// ─── Equipment compositions ──────────────────────────────────────
	comps := protected.Group("/compositions")
	comps.Get("/", compositionHandler.List)
	comps.Post("/", middleware.RequireRole("admin", "supervisor"), compositionHandler.Create)
	comps.Get("/by-node/:nodeId", compositionHandler.GetNodeCompositions)
	comps.Get("/:id", compositionHandler.GetOne)
	comps.Put("/:id", middleware.RequireRole("admin", "supervisor"), compositionHandler.Update)
	comps.Delete("/:id", middleware.RequireRole("admin", "supervisor"), compositionHandler.Delete)
	comps.Post("/:id/members", middleware.RequireRole("admin", "supervisor"), compositionHandler.AddMember)
	comps.Delete("/:id/members/:nodeId", middleware.RequireRole("admin", "supervisor"), compositionHandler.RemoveMember)
	comps.Get("/:id/qr", middleware.RequireModuleTenant(db, "qr"), qrHandler.GenerateCompositionQR)

	// ─── Composition templates ────────────────────────────────────
	compTmpl := protected.Group("/composition-templates")
	compTmpl.Get("/", compTemplateHandler.List)
	compTmpl.Post("/", middleware.RequireRole("admin", "supervisor"), compTemplateHandler.Create)
	compTmpl.Get("/:id", compTemplateHandler.GetOne)
	compTmpl.Put("/:id", middleware.RequireRole("admin", "supervisor"), compTemplateHandler.Update)
	compTmpl.Delete("/:id", middleware.RequireRole("admin", "supervisor"), compTemplateHandler.Delete)
	compTmpl.Post("/:id/apply", middleware.RequireRole("admin", "supervisor"), compTemplateHandler.Apply)

	clients := protected.Group("/clients")
	clients.Get("/", clientsHandler.List)
	clients.Post("/", middleware.RequireRole("admin", "supervisor"), clientsHandler.Create)
	clients.Put("/:id", middleware.RequireRole("admin", "supervisor"), clientsHandler.Update)
	clients.Delete("/:id", middleware.RequireRole("admin"), clientsHandler.Delete)

	protected.Get("/node-types", nodeTypesHandler.List)

	wo := protected.Group("/work-orders")
	wo.Get("/", woHandler.List)
	wo.Get("/offline-bundle", woHandler.OfflineBundle)
	wo.Get("/suggest-parts", woHandler.SuggestParts)
	wo.Post("/", middleware.RequireRole("admin", "supervisor", "technician", "operator"), woHandler.Create)
	wo.Get("/:id", woHandler.GetOne)
	wo.Put("/:id", middleware.RequireRole("admin", "supervisor", "technician"), woHandler.Update)
	wo.Patch("/:id/status", middleware.RequireRole("admin", "supervisor", "technician", "operator"), woHandler.ChangeStatus)
	wo.Post("/:id/comments", middleware.RequireRole("admin", "supervisor", "technician", "operator"), woHandler.AddComment)
	wo.Get("/:id/intervals", woHandler.GetIntervals)
	wo.Get("/:id/library", libraryHandler.ListByWO)
	wo.Post("/:id/sign", signatureHandler.Sign)
	wo.Post("/:id/supervisor-sign", middleware.RequireRole("admin","supervisor"), signatureHandler.SupervisorSign)
	wo.Get("/:id/signatures", signatureHandler.GetSignatures)

	spare := protected.Group("/spare-parts")
	spare.Get("/", spareHandler.List)
	spare.Post("/", middleware.RequireRole("admin", "supervisor", "warehouse"), spareHandler.Create)
	spare.Get("/:id", spareHandler.GetOne)
	spare.Put("/:id", middleware.RequireRole("admin", "supervisor", "warehouse"), spareHandler.Update)
	spare.Post("/:id/movements", middleware.RequireRole("admin", "supervisor", "warehouse", "technician"), spareHandler.AddMovement)

	lib := protected.Group("/library")
	lib.Get("/all", libraryHandler.ListAll)
	lib.Get("/:id/download", libraryHandler.Download)
	lib.Delete("/:id", middleware.RequireRole("admin", "supervisor"), libraryHandler.Delete)

	personnel := protected.Group("/personnel")
	personnel.Get("/", personnelHandler.List)
	personnel.Get("/:id/competencies", personnelHandler.GetCompetencies)
	personnel.Post("/:id/competencies", middleware.RequireRole("admin", "supervisor"), personnelHandler.AddCompetency)
	personnel.Delete("/competencies/:id", middleware.RequireRole("admin", "supervisor"), personnelHandler.DeleteCompetency)
	personnel.Get("/:id/assignments", personnelHandler.GetAssignments)
	personnel.Post("/:id/assignments", middleware.RequireRole("admin", "supervisor"), personnelHandler.AddAssignment)

	// Verifications removed in v1.8 — auto-verification on WO completion

	calendar := protected.Group("/calendar")
	calendar.Get("/", calendarHandler.List)
	calendar.Get("/upcoming", calendarHandler.Upcoming)
	calendar.Post("/", middleware.RequireRole("admin", "supervisor"), calendarHandler.Create)
	calendar.Delete("/:id", middleware.RequireRole("admin", "supervisor"), calendarHandler.Delete)

	dirs := protected.Group("/directories")
	dirs.Get("/", dirHandler.List)
	dirs.Post("/", dirHandler.Create)
	dirs.Put("/:id", dirHandler.Update)
	dirs.Delete("/:id", dirHandler.Delete)
	dirs.Post("/:id/verify-pin", dirHandler.VerifyPin)
	dirs.Get("/:id/items", dirHandler.GetItems)
	dirs.Post("/:id/items", dirHandler.AddItem)
	dirs.Delete("/items/:id", dirHandler.RemoveItem)

	templates := protected.Group("/templates")
	templates.Get("/", templatesHandler.List)
	templates.Get("/categories", templatesHandler.GetCategories)
	templates.Post("/", middleware.RequireRole("admin", "supervisor"), templatesHandler.Create)
	templates.Get("/:id", templatesHandler.GetOne)
	templates.Put("/:id", middleware.RequireRole("admin", "supervisor"), templatesHandler.Update)
	templates.Delete("/:id", middleware.RequireRole("admin"), templatesHandler.Delete)
	templates.Get("/:id/library", templatesHandler.ListLibrary)
	templates.Post("/:id/library/upload", uploadLimiter, middleware.RequireRole("admin", "supervisor"), templatesHandler.UploadToTemplate)
	templates.Delete("/library/:attId", middleware.RequireRole("admin", "supervisor"), templatesHandler.DeleteTemplateFile)
	templates.Get("/:id/folders", templatesHandler.ListFolders)
	templates.Post("/:id/folders", middleware.RequireRole("admin", "supervisor"), templatesHandler.CreateFolder)
	templates.Delete("/folders/:folderId", middleware.RequireRole("admin", "supervisor"), templatesHandler.DeleteFolder)

	maint := protected.Group("/maintenance-plans", middleware.RequireModuleTenant(db, "preventive"))
	maint.Get("/", maintHandler.List)
	maint.Post("/", middleware.RequireRole("admin", "supervisor"), maintHandler.Create)
	maint.Put("/:id", middleware.RequireRole("admin", "supervisor"), maintHandler.Update)
	maint.Delete("/:id", middleware.RequireRole("admin", "supervisor"), maintHandler.Delete)
	maint.Get("/upcoming", maintHandler.Upcoming)
	maint.Get("/compliance", maintHandler.Compliance)
	maint.Get("/effective/:nodeId", maintHandler.EffectivePlans)
	maint.Get("/:id", maintHandler.GetOne)
	maint.Post("/:id/execute", middleware.RequireRole("admin", "supervisor"), maintHandler.Execute)
	maint.Post("/:id/exclusions", middleware.RequireRole("admin", "supervisor"), maintHandler.AddExclusion)
	maint.Delete("/:id/exclusions/:nodeId", middleware.RequireRole("admin", "supervisor"), maintHandler.RemoveExclusion)

	// Preventive maintenance staggering
	stagger := protected.Group("/maintenance/staggering", middleware.RequireModuleTenant(db, "preventive"), middleware.RequireRole("admin", "supervisor"))
	stagger.Get("/config", staggerHandler.GetConfig)
	stagger.Put("/config", staggerHandler.UpdateConfig)
	stagger.Post("/preview", staggerHandler.Preview)
	stagger.Post("/apply", staggerHandler.Apply)
	stagger.Get("/schedule", staggerHandler.GetSchedule)
	stagger.Get("/cycles", staggerHandler.ListCycles)

	// Maintenance plan templates
	mpt := protected.Group("/maintenance-plan-templates", middleware.RequireModuleTenant(db, "preventive"))
	mpt.Get("/", maintTemplateHandler.List)
	mpt.Post("/", middleware.RequireRole("admin", "supervisor"), maintTemplateHandler.Create)
	mpt.Post("/from-plan/:planId", middleware.RequireRole("admin", "supervisor"), maintTemplateHandler.SaveFromPlan)
	mpt.Get("/:id", maintTemplateHandler.GetOne)
	mpt.Put("/:id", middleware.RequireRole("admin", "supervisor"), maintTemplateHandler.Update)
	mpt.Delete("/:id", middleware.RequireRole("admin", "supervisor"), maintTemplateHandler.Delete)

	tech := protected.Group("/technicians")
	tech.Get("/", techHandler.List)
	tech.Get("/suggest/:wo_id", techHandler.SuggestForWO)
	tech.Get("/:id", techHandler.GetOne)
	tech.Post("/:id/tags", middleware.RequireRole("admin", "supervisor"), techHandler.AddTag)
	tech.Delete("/:id/tags/:tag", middleware.RequireRole("admin", "supervisor"), techHandler.RemoveTag)
	tech.Post("/:id/scores", middleware.RequireRole("admin", "supervisor"), techHandler.AddScore)

	notif := protected.Group("/notifications")
	notif.Get("/", notifHandler.List)
	notif.Patch("/read-all", notifHandler.MarkAllRead)
	notif.Patch("/:id/read", notifHandler.MarkRead)
	notif.Get("/preferences", notifHandler.GetPreferences)
	notif.Put("/preferences", notifHandler.UpdatePreferences)
	notif.Get("/smtp", middleware.RequireRole("admin"), notifHandler.GetSMTP)
	notif.Put("/smtp", middleware.RequireRole("admin"), notifHandler.UpdateSMTP)

	aiLimiter := limiter.New(limiter.Config{
		Max: 30, Expiration: time.Minute,
		KeyGenerator: func(c *fiber.Ctx) string { return c.IP() },
		LimitReached: func(c *fiber.Ctx) error {
			return c.Status(fiber.StatusTooManyRequests).JSON(fiber.Map{"error": "Demasiadas consultas."})
		},
	})
	aiAccess := middleware.RequireAIAccess(db)
	aiGroup := protected.Group("/ai", middleware.RequireModuleTenant(db, "ai"))
	aiGroup.Get("/status", aiHandler.Status)
	aiGroup.Post("/chat", aiLimiter, aiAccess, aiHandler.Chat)
	aiGroup.Post("/create-wo", aiAccess, aiHandler.CreateWOFromChat)
	aiGroup.Get("/suggest-root-cause/:wo_id", aiAccess, aiHandler.SuggestRootCause)
	aiGroup.Get("/conversations", aiHandler.ListConversations)
	aiGroup.Get("/conversations/:id", aiHandler.GetConversation)
	aiGroup.Delete("/conversations/:id", aiHandler.DeleteConversation)
	aiGroup.Post("/index-nodes", middleware.RequireRole("admin", "supervisor"), aiHandler.IndexAllNodes)
	aiGroup.Post("/index/:source_type/:source_id", middleware.RequireRole("admin", "supervisor"), aiHandler.IndexManual)
	aiGroup.Post("/reindex-all", middleware.RequireRole("admin"), aiHandler.ReindexAll)
	aiGroup.Get("/calcs", aiAdminHandler.ListCalcs)
	aiGroup.Post("/calculate", middleware.RequireRole("admin","supervisor"), aiAdminHandler.Calculate)

	aiAdmin := aiGroup.Group("/admin", middleware.RequireRole("admin"))
	aiAdmin.Get("/models", aiAdminHandler.ListModels)
	aiAdmin.Put("/models", aiAdminHandler.SetModel)
	aiAdmin.Get("/roles", aiAdminHandler.GetRoles)
	aiAdmin.Put("/roles", aiAdminHandler.SetRoles)
	aiAdmin.Get("/permission-log", aiAdminHandler.GetPermissionLog)
	aiAdmin.Get("/knowledge", aiAdminHandler.ListKnowledge)
	aiAdmin.Get("/knowledge/:id", aiAdminHandler.GetKnowledge)
	aiAdmin.Post("/knowledge", aiAdminHandler.CreateKnowledge)
	aiAdmin.Post("/knowledge/upload", uploadLimiter, aiAdminHandler.UploadKnowledge)
	aiAdmin.Put("/knowledge/:id", aiAdminHandler.UpdateKnowledge)
	aiAdmin.Delete("/knowledge/:id", aiAdminHandler.DeleteKnowledge)
	aiAdmin.Get("/folders", aiAdminHandler.ListFolders)
	aiAdmin.Post("/folders", aiAdminHandler.CreateFolder)
	aiAdmin.Put("/folders/:id", aiAdminHandler.RenameFolder)
	aiAdmin.Delete("/folders/:id", aiAdminHandler.DeleteFolder)
	aiAdmin.Get("/calcs", aiAdminHandler.ListCalcs)
	aiAdmin.Post("/calcs", aiAdminHandler.CreateCalc)
	aiAdmin.Put("/calcs/:id", aiAdminHandler.UpdateCalc)
	aiAdmin.Delete("/calcs/:id", aiAdminHandler.DeleteCalc)
	aiAdmin.Get("/log", aiAdminHandler.GetLog)
	aiAdmin.Get("/stats", aiAdminHandler.GetStats)
	aiAdmin.Post("/system-prompt", aiAdminHandler.SetSystemPrompt)

	patterns := protected.Group("/patterns", middleware.RequireModuleTenant(db, "ai"))
	patterns.Get("/", patternsHandler.List)
	patterns.Post("/detect", middleware.RequireRole("admin", "supervisor"), patternsHandler.Detect)
	patterns.Patch("/:id/acknowledge", patternsHandler.Acknowledge)

	reports := protected.Group("/reports", middleware.RequireModuleTenant(db, "reports"))
	reports.Get("/wo/:id/html", reportsHandler.WorkOrderHTML)
	reports.Get("/wo/:id/data", reportsHandler.WorkOrderData)
	reports.Get("/spare-parts/excel", reportsHandler.SparePartsExcel)
	reports.Get("/work-orders/excel", reportsHandler.WorkOrdersExcel)

	metrics := protected.Group("/metrics", middleware.RequireModuleTenant(db, "metrics"))
	metrics.Get("/summary", metricsHandler.Summary)
	metrics.Get("/equipment", metricsHandler.Equipment)
	metrics.Get("/trends", metricsHandler.Trends)
	metrics.Get("/technicians", metricsHandler.Technicians)
	metrics.Get("/spare-parts", metricsHandler.SpareParts)
	metrics.Get("/corrective-ratio", metricsHandler.CorrectiveRatio)
	metrics.Get("/alerts-summary", metricsHandler.AlertsSummary)

	// ─── Health Score (equipment health) ────────────────────────────────────
	healthGroup := protected.Group("/factory/health")
	healthGroup.Get("/summary", equipHealthHandler.GetHealthSummary)
	healthGroup.Post("/recalculate", middleware.RequireRole("admin"), equipHealthHandler.RecalculateAll)
	healthGroup.Get("/weights", middleware.RequireRole("admin"), equipHealthHandler.GetWeights)
	healthGroup.Put("/weights/:nodeType", middleware.RequireRole("admin"), equipHealthHandler.UpdateWeights)

	// ─── Guided procedures (digital SOPs) ─────────────────────────────
	proc := protected.Group("/procedures", middleware.RequireModuleTenant(db, "preventive"))
	proc.Get("/", procedureHandler.ListTemplates)
	proc.Get("/suggest", procedureHandler.SuggestForWO)
	proc.Post("/generate", middleware.RequireModuleTenant(db, "ai"), middleware.RequireRole("admin", "supervisor"), procedureHandler.GenerateWithAI)
	proc.Post("/", middleware.RequireRole("admin", "supervisor"), procedureHandler.CreateTemplate)
	proc.Get("/:id", procedureHandler.GetTemplate)
	proc.Put("/:id", middleware.RequireRole("admin", "supervisor"), procedureHandler.UpdateTemplate)
	proc.Delete("/:id", middleware.RequireRole("admin", "supervisor"), procedureHandler.DeleteTemplate)
	proc.Post("/:id/link", middleware.RequireRole("admin", "supervisor"), procedureHandler.LinkTemplate)
	proc.Delete("/:id/link/:linkId", middleware.RequireRole("admin", "supervisor"), procedureHandler.UnlinkTemplate)
	proc.Post("/:id/execute", procedureHandler.StartExecution)
	proc.Get("/executions/:execId", procedureHandler.GetExecution)
	proc.Post("/executions/:execId/steps/:stepId", procedureHandler.SubmitStepResult)
	proc.Post("/executions/:execId/complete", procedureHandler.CompleteExecution)

	// Procedures linked to WOs (reachable from the WO detail)
	wo.Get("/:id/procedures", procedureHandler.GetWOProcedures)

	// User profiles — reachable by any authenticated role (register BEFORE the admin /users group)
	protected.Get("/users/:id/profile", userProfileHandler.GetProfile)
	protected.Put("/users/:id/profile", userProfileHandler.UpdateProfile)
	protected.Patch("/users/:id/change-password", loginLimiter, userProfileHandler.ChangeOwnPassword)

	// ─── Technicians' daily summaries ──────────────────────────────────────
	ds := protected.Group("/daily-summaries")
	ds.Get("/", dailySummariesHandler.List)
	ds.Post("/", dailySummariesHandler.Create)
	ds.Put("/:id", dailySummariesHandler.Update)
	ds.Delete("/:id", dailySummariesHandler.Delete)
	ds.Get("/days", dailySummariesHandler.GetDays)
	ds.Get("/recent-wos", dailySummariesHandler.RecentWOs)
	ds.Get("/months", middleware.RequireRole("admin", "supervisor"), dailySummariesHandler.MonthlyFolders)
	ds.Get("/export", middleware.RequireRole("admin", "supervisor"), dailySummariesHandler.ExportUser)
	ds.Get("/export-all", middleware.RequireRole("admin", "supervisor"), dailySummariesHandler.ExportAll)

	// User management — admin only
	users := protected.Group("/users", middleware.RequireRole("admin"))
	users.Get("/", usersHandler.List)
	users.Post("/", usersHandler.Create)
	users.Put("/:id", usersHandler.Update)
	users.Delete("/:id", usersHandler.Delete)

	// ─── System: status, pause ──────────────────────────────────────────────
	system := protected.Group("/system")
	system.Get("/status", systemHandler.Status)
	system.Post("/pause", middleware.RequirePrimaryAdminOrSuperadmin(db), systemHandler.Pause)
	system.Post("/resume", middleware.RequirePrimaryAdminOrSuperadmin(db), systemHandler.Resume)
	system.Get("/retention", middleware.RequireRole("admin"), systemHandler.GetRetention)
	system.Put("/retention", middleware.RequireRole("admin"), systemHandler.SetRetention)

	// ─── Arche GMAO superadmin: routes invisible to the client ────────────
	sa := protected.Group("/superadmin", middleware.RequireSuperadminOnly())
	sa.Get("/whoami", superadminHandler.WhoAmI)
	sa.Get("/tenants", superadminHandler.ListTenants)
	sa.Put("/tenants/:id/max-users", superadminHandler.SetMaxUsers)
	sa.Put("/tenants/:id/max-nodes", superadminHandler.SetMaxNodes)
	sa.Put("/tenants/:id/modules", superadminHandler.SetDisabledModules)
	sa.Post("/tenants/:id/pause", superadminHandler.PauseTenant)
	sa.Post("/license/reload", superadminHandler.ReloadLicense)

	// 404 for API routes that do not exist
	api.Use(func(c *fiber.Ctx) error {
		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{"error": "Ruta no encontrada"})
	})

	// In production: serve the embedded frontend for everything that is not /api/*
	// In development: does nothing (frontend served by the Vite dev server)
	static.Mount(app)

	return &Server{
		App: app,
		stopWorkers: func() {
			log.Println("[ARCHE] Deteniendo workers...")
			indexWorker.Stop()
			maintWorker.Stop()
			summaryWorker.Stop()
			log.Println("[ARCHE] Workers detenidos")
		},
	}
}

func errorHandler(c *fiber.Ctx, err error) error {
	code := fiber.StatusInternalServerError
	message := "Error interno del servidor"
	if e, ok := err.(*fiber.Error); ok {
		code = e.Code
		message = e.Message
	}
	return c.Status(code).JSON(fiber.Map{"error": message})
}
