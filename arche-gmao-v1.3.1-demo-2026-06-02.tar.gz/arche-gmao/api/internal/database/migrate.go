package database

import (
	"context"
	"embed"
	"fmt"
	"log"
	"sort"
	"strings"

	"github.com/jackc/pgx/v5/pgxpool"
)

// migrationsFS is defined in embed_production.go or embed_dev.go
// depending on the build tag. In production it holds the embedded .sql files;
// in dev it is empty (migrations are applied through Docker init).

// RunMigrations applies every pending migration at startup.
// It creates the schema_migrations table if it does not exist and records each applied migration.
// In dev (no production tag) there are no embedded migrations and it is skipped silently.
func RunMigrations(db *pgxpool.Pool) error {
	ctx := context.Background()

	// Check whether there are embedded migrations
	files, err := listMigrationFiles(migrationsFS)
	if err != nil || len(files) == 0 {
		log.Println("[ARCHE-DB] Sin migraciones embebidas — omitiendo auto-migración")
		return nil
	}

	// Create the tracking table if it does not exist
	_, err = db.Exec(ctx, `
		CREATE TABLE IF NOT EXISTS schema_migrations (
			version  TEXT PRIMARY KEY,
			applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
		)`)
	if err != nil {
		return fmt.Errorf("error creando schema_migrations: %w", err)
	}

	// Read the applied migrations
	applied := make(map[string]bool)
	rows, err := db.Query(ctx, `SELECT version FROM schema_migrations`)
	if err != nil {
		return fmt.Errorf("error leyendo migraciones aplicadas: %w", err)
	}
	defer rows.Close()
	for rows.Next() {
		var v string
		if err := rows.Scan(&v); err != nil {
			return fmt.Errorf("error leyendo versión de migración: %w", err)
		}
		applied[v] = true
	}

	// Apply the pending ones
	count := 0
	for _, filename := range files {
		version := strings.TrimSuffix(filename, ".sql")
		if applied[version] {
			continue
		}

		content, err := migrationsFS.ReadFile("migrations/" + filename)
		if err != nil {
			return fmt.Errorf("error leyendo %s: %w", filename, err)
		}

		log.Printf("[ARCHE-DB] Aplicando migración: %s", filename)

		_, err = db.Exec(ctx, string(content))
		if err != nil {
			return fmt.Errorf("error aplicando %s: %w", filename, err)
		}

		_, err = db.Exec(ctx, `INSERT INTO schema_migrations (version) VALUES ($1) ON CONFLICT (version) DO NOTHING`, version)
		if err != nil {
			return fmt.Errorf("error registrando %s: %w", filename, err)
		}

		count++
	}

	if count > 0 {
		log.Printf("[ARCHE-DB] %d migración(es) aplicada(s)", count)
	} else {
		log.Println("[ARCHE-DB] Base de datos al día — sin migraciones pendientes")
	}

	return nil
}

// listMigrationFiles lists and sorts the .sql files in the embed.FS.
func listMigrationFiles(fs embed.FS) ([]string, error) {
	entries, err := fs.ReadDir("migrations")
	if err != nil {
		return nil, err
	}

	var files []string
	for _, e := range entries {
		if !e.IsDir() && strings.HasSuffix(e.Name(), ".sql") {
			files = append(files, e.Name())
		}
	}
	sort.Strings(files)
	return files, nil
}
