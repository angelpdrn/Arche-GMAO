//go:build production

package database

import "embed"

// In production, build.sh copies migrations/*.sql into this directory
// before compiling, and cleans them up afterwards.
//
//go:embed migrations/*.sql
var migrationsFS embed.FS
