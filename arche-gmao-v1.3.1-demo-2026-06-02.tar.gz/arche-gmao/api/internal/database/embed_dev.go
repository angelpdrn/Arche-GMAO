//go:build !production

package database

import "embed"

// In development the migrations are applied through docker-entrypoint-initdb.d.
// This file provides an empty embed.FS so it compiles without the migrations/ directory.
var migrationsFS embed.FS
