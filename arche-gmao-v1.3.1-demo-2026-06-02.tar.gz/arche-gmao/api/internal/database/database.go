package database

import (
	"context"
	"fmt"
	"log"
	"os"
	"strconv"
	"time"

	"arche-gmao/api/internal/config"
	"arche-gmao/api/internal/middleware"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/redis/go-redis/v9"
)

// Connect sets up the PostgreSQL connection pool with parameters
// tuned for production: idle timeout, periodic health check.
func Connect(cfg *config.Config) (*pgxpool.Pool, error) {
	dsn := fmt.Sprintf(
		"host=%s port=%s dbname=%s user=%s password=%s sslmode=%s",
		cfg.DBHost, cfg.DBPort, cfg.DBName, cfg.DBUser, cfg.DBPassword, cfg.DBSSLMode,
	)

	poolCfg, err := pgxpool.ParseConfig(dsn)
	if err != nil {
		return nil, fmt.Errorf("error parseando config de pool: %w", err)
	}

	maxConns := int32(20)
	if v := os.Getenv("DB_MAX_CONNS"); v != "" {
		if n, err := strconv.ParseInt(v, 10, 32); err == nil && n > 0 {
			maxConns = int32(n)
		}
	}
	poolCfg.MaxConns = maxConns
	poolCfg.MinConns = 2
	poolCfg.MaxConnIdleTime = 5 * time.Minute
	poolCfg.MaxConnLifetime = 30 * time.Minute
	poolCfg.HealthCheckPeriod = 30 * time.Second

	// RLS: SET ROLE arche_app + SET tenant_id on every acquire when there is a tenant in the context.
	// Workers (context.Background with no tenant) do not trigger SET ROLE → the owner bypasses RLS.
	poolCfg.BeforeAcquire = func(ctx context.Context, conn *pgx.Conn) bool {
		tid, ok := ctx.Value(middleware.TenantIDKey).(int64)
		if !ok || tid <= 0 {
			return true
		}
		_, err := conn.Exec(ctx,
			"SET ROLE arche_app; SET app.current_tenant_id = '"+strconv.FormatInt(tid, 10)+"'")
		if err != nil {
			log.Printf("[ARCHE-RLS] WARN: SET ROLE/tenant_id=%d: %v", tid, err)
			return false
		}
		return true
	}
	poolCfg.AfterRelease = func(conn *pgx.Conn) bool {
		_, err := conn.Exec(context.Background(), "RESET ROLE; RESET app.current_tenant_id")
		if err != nil {
			log.Printf("[ARCHE-RLS] WARN: RESET ROLE: %v", err)
			return false
		}
		return true
	}

	pool, err := pgxpool.NewWithConfig(context.Background(), poolCfg)
	if err != nil {
		return nil, fmt.Errorf("no se pudo crear el pool: %w", err)
	}

	if err := pool.Ping(context.Background()); err != nil {
		return nil, fmt.Errorf("no se pudo conectar a PostgreSQL: %w", err)
	}

	return pool, nil
}

// ConnectRedis sets up the Redis connection with configured timeouts and pool.
func ConnectRedis(cfg *config.Config) (*redis.Client, error) {
	rdb := redis.NewClient(&redis.Options{
		Addr:         fmt.Sprintf("%s:%s", cfg.RedisHost, cfg.RedisPort),
		Password:     cfg.RedisPassword,
		DB:           0,
		DialTimeout:  5 * time.Second,
		ReadTimeout:  3 * time.Second,
		WriteTimeout: 3 * time.Second,
		PoolSize:     10,
		MinIdleConns: 2,
	})

	if err := rdb.Ping(context.Background()).Err(); err != nil {
		return nil, fmt.Errorf("no se pudo conectar a Redis: %w", err)
	}

	return rdb, nil
}
