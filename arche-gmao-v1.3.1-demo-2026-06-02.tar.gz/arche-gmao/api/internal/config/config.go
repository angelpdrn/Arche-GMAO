package config

import (
	"log"
	"os"
	"strconv"
	"strings"
)

type Config struct {
	// Database (individual fields for database.go)
	DBHost     string
	DBPort     string
	DBName     string
	DBUser     string
	DBPassword string
	DBSSLMode  string

	// Redis
	RedisHost     string
	RedisPort     string
	RedisPassword string

	// JWT
	JWTSecret        string
	JWTRefreshSecret string
	JWTExpiry        string
	JWTRefreshExpiry string

	// Server
	Port string

	// Ollama / AI
	OllamaURL        string
	OllamaChatModel  string
	OllamaEmbedModel string

	// Push / VAPID
	VAPIDPublicKey  string
	VAPIDPrivateKey string
	VAPIDContact    string
}

func Load() *Config {
	cfg := &Config{
		DBHost:     getEnv("DB_HOST", "postgres"),
		DBPort:     getEnv("DB_PORT", "5432"),
		DBName:     getEnv("DB_NAME", "arche"),
		DBUser:     getEnv("DB_USER", "arche"),
		DBPassword: getEnv("DB_PASSWORD", "arche"),
		DBSSLMode:  getEnv("DB_SSLMODE", "disable"),
		RedisHost:     getEnv("REDIS_HOST", "redis"),
		RedisPort:     getEnv("REDIS_PORT", "6379"),
		RedisPassword: getEnv("REDIS_PASSWORD", "arche-redis-secret"),
		JWTSecret:        getEnv("JWT_SECRET", "arche-dev-secret-change-in-production"),
		JWTRefreshSecret: getEnv("JWT_REFRESH_SECRET", "arche-dev-refresh-secret"),
		JWTExpiry:        getEnv("JWT_EXPIRY", "15m"),
		JWTRefreshExpiry: getEnv("JWT_REFRESH_EXPIRY", "7d"),
		Port:             getEnv("PORT", "3000"),
		OllamaURL:        getEnv("OLLAMA_URL", "http://host.docker.internal:11434"),
		OllamaChatModel:  getEnv("OLLAMA_CHAT_MODEL", "llama3"),
		OllamaEmbedModel: getEnv("OLLAMA_EMBED_MODEL", "nomic-embed-text"),
		VAPIDPublicKey:  os.Getenv("VAPID_PUBLIC_KEY"),
		VAPIDPrivateKey: os.Getenv("VAPID_PRIVATE_KEY"),
		VAPIDContact:    getEnv("VAPID_CONTACT", "mailto:admin@arche.local"),
	}

	// Validate that the port is a valid number
	if _, err := strconv.Atoi(cfg.Port); err != nil {
		log.Printf("[ARCHE] WARN: PORT '%s' no es válido, usando 3000", cfg.Port)
		cfg.Port = "3000"
	}

	return cfg
}

// ValidateSecrets emits a log.Fatal when the JWT secrets are the default values
// and the environment is not development.
func (c *Config) ValidateSecrets() {
	env := strings.ToLower(os.Getenv("APP_ENV"))
	if env == "" || env == "development" || env == "dev" {
		return
	}
	defaults := []string{
		"arche-dev-secret-change-in-production",
		"arche-dev-refresh-secret",
	}
	for _, d := range defaults {
		if c.JWTSecret == d || c.JWTRefreshSecret == d {
			log.Fatalf("[ARCHE] FATAL: Los secretos JWT son valores por defecto. " +
				"Configure JWT_SECRET y JWT_REFRESH_SECRET antes de usar en producción.")
		}
	}

	// Warn when Redis uses the default password in production
	if c.RedisPassword == "arche-redis-secret" {
		log.Fatalf("[ARCHE] FATAL: REDIS_PASSWORD es el valor por defecto. " +
			"Configure REDIS_PASSWORD antes de usar en producción.")
	}

	// Warn when the DB has no SSL in production
	if c.DBSSLMode == "disable" {
		log.Println("[ARCHE] WARN: DB_SSLMODE=disable — la conexión a PostgreSQL no está cifrada. " +
			"En redes locales (Docker) es aceptable; en remoto considere DB_SSLMODE=require")
	}
}

// IsProd returns true when APP_ENV indicates production.
func IsProd() bool {
	env := strings.ToLower(os.Getenv("APP_ENV"))
	return env == "production" || env == "prod"
}

func getEnv(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}
