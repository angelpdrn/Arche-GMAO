package middleware

import (
	"context"
	"fmt"
	"strings"
	"time"

	"arche-gmao/api/internal/config"
	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/golang-jwt/jwt/v5"
	"github.com/redis/go-redis/v9"
)

// rdbRef lets RequireAuth query Redis for the token blacklist.
// It is initialized through SetRedisClient from server.go.
var rdbRef *redis.Client

// SetRedisClient registers the Redis client used by RequireAuth for the
// access token blacklist. Call it once when the server starts.
func SetRedisClient(rdb *redis.Client) {
	rdbRef = rdb
}

// IsTokenRevoked returns true when the JTI or the user is on the blacklist.
// It uses a context detached from the request so it does not block when the client cancels.
func IsTokenRevoked(claims *types.Claims) bool {
	if rdbRef == nil {
		return false
	}
	ctx, cancel := context.WithTimeout(context.Background(), 200*time.Millisecond)
	defer cancel()

	if claims.JTI != "" {
		if n, err := rdbRef.Exists(ctx, "revoked:"+claims.JTI).Result(); err == nil && n > 0 {
			return true
		}
	}

	// Bulk revocation per user (password change).
	// When the token's iat is older than the stored timestamp, the token is stale.
	userKey := fmt.Sprintf("revoked_user:%d", claims.UserID)
	if claims.IsSuperadmin {
		userKey = fmt.Sprintf("revoked_sa:%d", claims.UserID)
	}
	cutoffStr, err := rdbRef.Get(ctx, userKey).Result()
	if err == nil && cutoffStr != "" && claims.IssuedAt != nil {
		var cutoff int64
		if _, err := fmt.Sscanf(cutoffStr, "%d", &cutoff); err == nil {
			// We use <= to cover the case where login and revoke happen
			// within the same second (the resolution of the JWT iat).
			if claims.IssuedAt.Unix() <= cutoff {
				return true
			}
		}
	}
	return false
}

// RequireAuth validates the JWT, checks the blacklist and leaves the claims in the context.
func RequireAuth(cfg *config.Config) fiber.Handler {
	return func(c *fiber.Ctx) error {
		authHeader := c.Get("Authorization")
		if authHeader == "" {
			return fiber.NewError(fiber.StatusUnauthorized, "Authorization header requerido")
		}

		parts := strings.SplitN(authHeader, " ", 2)
		if len(parts) != 2 || parts[0] != "Bearer" {
			return fiber.NewError(fiber.StatusUnauthorized, "Formato inválido: se espera 'Bearer <token>'")
		}

		claims := &types.Claims{}
		token, err := jwt.ParseWithClaims(parts[1], claims, func(t *jwt.Token) (interface{}, error) {
			if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
				return nil, fmt.Errorf("método de firma inesperado")
			}
			return []byte(cfg.JWTSecret), nil
		})

		if err != nil || !token.Valid {
			return fiber.NewError(fiber.StatusUnauthorized, "Token inválido o expirado")
		}

		if IsTokenRevoked(claims) {
			return fiber.NewError(fiber.StatusUnauthorized, "Sesión cerrada o revocada")
		}

		c.Locals("claims", claims)
		return c.Next()
	}
}


// OptionalAuth tries to authenticate but lets the request through without auth (for public endpoints
// that optionally record the user, such as QR scanning).
func OptionalAuth(cfg *config.Config) fiber.Handler {
	return func(c *fiber.Ctx) error {
		authHeader := c.Get("Authorization")
		if authHeader == "" {
			return c.Next()
		}
		parts := strings.SplitN(authHeader, " ", 2)
		if len(parts) != 2 || parts[0] != "Bearer" {
			return c.Next()
		}
		claims := &types.Claims{}
		token, err := jwt.ParseWithClaims(parts[1], claims, func(t *jwt.Token) (interface{}, error) {
			if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
				return nil, fmt.Errorf("método de firma inesperado")
			}
			return []byte(cfg.JWTSecret), nil
		})
		if err == nil && token.Valid && !IsTokenRevoked(claims) {
			c.Locals("claims", claims)
		}
		return c.Next()
	}
}
