package middleware

import (
	"strconv"

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

// RequireRole checks that the user holds one of the allowed roles.
// The Arche GMAO superadmin bypasses it automatically.
func RequireRole(roles ...string) fiber.Handler {
	roleSet := make(map[string]bool, len(roles))
	for _, r := range roles {
		roleSet[r] = true
	}
	return func(c *fiber.Ctx) error {
		claims, ok := c.Locals("claims").(*types.Claims)
		if !ok || claims == nil {
			return fiber.NewError(fiber.StatusUnauthorized, "No autenticado")
		}
		if claims.IsSuperadmin {
			return c.Next()
		}
		if !roleSet[claims.Role] {
			return fiber.NewError(fiber.StatusForbidden,
				"Acceso denegado. Rol requerido: "+joinRoles(roles))
		}
		return c.Next()
	}
}

// RequireNodeScope checks that the user can reach the requested node.
// Admin and auditor can reach every node in the tenant.
// Supervisor, technician, operator and warehouse only reach nodes assigned through node_assignments.
func RequireNodeScope(db *pgxpool.Pool) fiber.Handler {
	return func(c *fiber.Ctx) error {
		claims, ok := c.Locals("claims").(*types.Claims)
		if !ok || claims == nil {
			return fiber.NewError(fiber.StatusUnauthorized, "No autenticado")
		}

		// Superadmin, admin and auditor have full access to every node in the tenant
		if claims.IsSuperadmin || claims.Role == "admin" || claims.Role == "auditor" {
			return c.Next()
		}

		nodeIDStr := c.Params("id")
		if nodeIDStr == "" {
			return c.Next()
		}

		nodeID, err := strconv.ParseInt(nodeIDStr, 10, 64)
		if err != nil {
			return fiber.NewError(fiber.StatusBadRequest, "ID de nodo inválido")
		}

		// For technicians, operators and warehouse: check the assignment through ltree
		var hasAccess bool
		err = db.QueryRow(c.UserContext(),
			`SELECT EXISTS(
				SELECT 1 FROM node_assignments na
				JOIN factory_nodes assigned ON assigned.id = na.node_id AND assigned.tenant_id = $2
				JOIN factory_nodes target ON target.id = $3 AND target.tenant_id = $2
				WHERE na.user_id = $1
				  AND na.tenant_id = $2
				  AND (
				      na.node_id = $3
				      OR target.path <@ assigned.path
				  )
			)`,
			claims.UserID, claims.TenantID, nodeID,
		).Scan(&hasAccess)

		if err != nil {
			return fiber.NewError(fiber.StatusInternalServerError, "Error verificando acceso")
		}

		// Warehouse can reach nodes to see spare parts, but not to edit them
		if !hasAccess && claims.Role == "warehouse" {
			// Read-only for warehouse
			if c.Method() != "GET" {
				return fiber.NewError(fiber.StatusForbidden, "Sin acceso a este equipo")
			}
			return c.Next()
		}

		if !hasAccess {
			return fiber.NewError(fiber.StatusForbidden,
				"No tienes acceso a este equipo. Contacta con tu supervisor.")
		}

		return c.Next()
	}
}

// RequireAIAccess checks that the role can use the AI.
// The admin can turn per-role access off from the configuration.
func RequireAIAccess(db *pgxpool.Pool) fiber.Handler {
	return func(c *fiber.Ctx) error {
		claims, ok := c.Locals("claims").(*types.Claims)
		if !ok {
			return fiber.NewError(fiber.StatusUnauthorized, "No autenticado")
		}

		// Superadmin and admin always have access
		if claims.IsSuperadmin || claims.Role == "admin" {
			return c.Next()
		}

		// Check whether the role can use the AI (configurable per tenant)
		var aiEnabled bool
		err := db.QueryRow(c.UserContext(),
			`SELECT COALESCE(ai_enabled_roles, '["admin","supervisor","technician","operator","warehouse","auditor"]'::jsonb) ? $1
			 FROM tenants WHERE id=$2`,
			claims.Role, claims.TenantID,
		).Scan(&aiEnabled)

		if err != nil || !aiEnabled {
			return fiber.NewError(fiber.StatusForbidden,
				"Tu rol no tiene acceso a Arché IA en este sistema.")
		}

		return c.Next()
	}
}

// RequireSupervisor is an alias for the management roles
func RequireSupervisor() fiber.Handler {
	return RequireRole("admin", "supervisor")
}

// RequireSuperadminOnly blocks every user who is not the Arche GMAO superadmin.
func RequireSuperadminOnly() fiber.Handler {
	return func(c *fiber.Ctx) error {
		claims, ok := c.Locals("claims").(*types.Claims)
		if !ok || claims == nil {
			return fiber.NewError(fiber.StatusUnauthorized, "No autenticado")
		}
		if !claims.IsSuperadmin {
			return fiber.NewError(fiber.StatusForbidden, "Acceso restringido")
		}
		return c.Next()
	}
}

// RequirePrimaryAdminOrSuperadmin allows only the tenant's primary admin or the superadmin.
func RequirePrimaryAdminOrSuperadmin(db *pgxpool.Pool) fiber.Handler {
	return func(c *fiber.Ctx) error {
		claims, ok := c.Locals("claims").(*types.Claims)
		if !ok || claims == nil {
			return fiber.NewError(fiber.StatusUnauthorized, "No autenticado")
		}
		if claims.IsSuperadmin {
			return c.Next()
		}
		var isPrimary bool
		err := db.QueryRow(c.UserContext(),
			`SELECT is_primary_admin FROM users WHERE id = $1 AND tenant_id = $2`,
			claims.UserID, claims.TenantID,
		).Scan(&isPrimary)
		if err != nil || !isPrimary {
			return fiber.NewError(fiber.StatusForbidden,
				"Solo el administrador principal puede realizar esta accion")
		}
		return c.Next()
	}
}

func joinRoles(roles []string) string {
	result := ""
	for i, r := range roles {
		if i > 0 {
			result += ", "
		}
		result += r
	}
	return result
}
