package middleware

import (
	"io"
	"net/http/httptest"
	"testing"

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
)

func TestRequireRole_Allowed(t *testing.T) {
	app := fiber.New()
	app.Use(func(c *fiber.Ctx) error {
		c.Locals("claims", &types.Claims{UserID: 1, TenantID: 1, Role: "admin"})
		return c.Next()
	})
	app.Use(RequireRole("admin", "supervisor"))
	app.Get("/test", func(c *fiber.Ctx) error {
		return c.SendString("ok")
	})

	req := httptest.NewRequest("GET", "/test", nil)
	resp, err := app.Test(req)
	if err != nil {
		t.Fatal(err)
	}
	if resp.StatusCode != 200 {
		t.Errorf("expected 200, got %d", resp.StatusCode)
	}
}

func TestRequireRole_Denied(t *testing.T) {
	app := fiber.New(fiber.Config{ErrorHandler: func(c *fiber.Ctx, err error) error {
		if e, ok := err.(*fiber.Error); ok {
			return c.Status(e.Code).SendString(e.Message)
		}
		return c.Status(500).SendString(err.Error())
	}})
	app.Use(func(c *fiber.Ctx) error {
		c.Locals("claims", &types.Claims{UserID: 1, TenantID: 1, Role: "technician"})
		return c.Next()
	})
	app.Use(RequireRole("admin", "supervisor"))
	app.Get("/test", func(c *fiber.Ctx) error {
		return c.SendString("ok")
	})

	req := httptest.NewRequest("GET", "/test", nil)
	resp, err := app.Test(req)
	if err != nil {
		t.Fatal(err)
	}
	if resp.StatusCode != 403 {
		t.Errorf("expected 403, got %d", resp.StatusCode)
	}
}

func TestRequireRole_SuperadminBypass(t *testing.T) {
	app := fiber.New()
	app.Use(func(c *fiber.Ctx) error {
		c.Locals("claims", &types.Claims{UserID: 1, TenantID: 1, Role: "admin", IsSuperadmin: true})
		return c.Next()
	})
	app.Use(RequireRole("warehouse"))
	app.Get("/test", func(c *fiber.Ctx) error {
		return c.SendString("ok")
	})

	req := httptest.NewRequest("GET", "/test", nil)
	resp, err := app.Test(req)
	if err != nil {
		t.Fatal(err)
	}
	if resp.StatusCode != 200 {
		t.Errorf("superadmin should bypass, got %d", resp.StatusCode)
	}
}

func TestRequireRole_NoClaims(t *testing.T) {
	app := fiber.New(fiber.Config{ErrorHandler: func(c *fiber.Ctx, err error) error {
		if e, ok := err.(*fiber.Error); ok {
			return c.Status(e.Code).SendString(e.Message)
		}
		return c.Status(500).SendString(err.Error())
	}})
	app.Use(RequireRole("admin"))
	app.Get("/test", func(c *fiber.Ctx) error {
		return c.SendString("ok")
	})

	req := httptest.NewRequest("GET", "/test", nil)
	resp, err := app.Test(req)
	if err != nil {
		t.Fatal(err)
	}
	if resp.StatusCode != 401 {
		t.Errorf("expected 401, got %d", resp.StatusCode)
	}
}

func TestRequireRole_AllSixRoles(t *testing.T) {
	roles := []string{"admin", "supervisor", "technician", "operator", "warehouse", "auditor"}
	for _, role := range roles {
		t.Run(role, func(t *testing.T) {
			app := fiber.New()
			app.Use(func(c *fiber.Ctx) error {
				c.Locals("claims", &types.Claims{UserID: 1, TenantID: 1, Role: role})
				return c.Next()
			})
			app.Use(RequireRole(role))
			app.Get("/test", func(c *fiber.Ctx) error {
				return c.SendString("ok")
			})

			req := httptest.NewRequest("GET", "/test", nil)
			resp, err := app.Test(req)
			if err != nil {
				t.Fatal(err)
			}
			body, _ := io.ReadAll(resp.Body)
			if resp.StatusCode != 200 {
				t.Errorf("role %s should be allowed, got %d: %s", role, resp.StatusCode, body)
			}
		})
	}
}
