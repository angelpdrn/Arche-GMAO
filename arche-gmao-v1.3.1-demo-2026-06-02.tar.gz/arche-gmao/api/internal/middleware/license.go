package middleware

import (
	"arche-gmao/api/internal/license"
	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

// RequireModule checks that the module is enabled in the active license
// AND that the tenant has not had it disabled.
func RequireModule(module string) fiber.Handler {
	return func(c *fiber.Ctx) error {
		if !license.HasModule(module) {
			return fiber.NewError(fiber.StatusForbidden,
				"El módulo '"+module+"' no está incluido en su licencia. Contacte con Arche GMAO.")
		}
		return c.Next()
	}
}

// RequireModuleTenant works like RequireModule but additionally checks
// the modules the superadmin disabled for the user's tenant.
func RequireModuleTenant(db *pgxpool.Pool, module string) fiber.Handler {
	return func(c *fiber.Ctx) error {
		if !license.HasModule(module) {
			return fiber.NewError(fiber.StatusForbidden,
				"El módulo '"+module+"' no está incluido en su licencia. Contacte con Arche GMAO.")
		}

		claims := c.Locals("claims").(*types.Claims)
		if claims.IsSuperadmin {
			return c.Next()
		}

		var disabled []string
		if err := db.QueryRow(c.UserContext(),
			`SELECT COALESCE(disabled_modules, '{}') FROM tenants WHERE id = $1`,
			claims.TenantID,
		).Scan(&disabled); err != nil {
			return fiber.NewError(fiber.StatusInternalServerError, "Error verificando módulos del tenant")
		}

		for _, d := range disabled {
			if d == module {
				return fiber.NewError(fiber.StatusForbidden,
					"El módulo '"+module+"' ha sido deshabilitado para su organización. Contacte con Arche GMAO.")
			}
		}

		return c.Next()
	}
}
