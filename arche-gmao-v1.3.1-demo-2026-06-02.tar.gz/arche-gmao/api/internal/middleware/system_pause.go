package middleware

import (
	"context"
	"fmt"
	"time"

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/redis/go-redis/v9"
)

// RequireSystemActive blocks write requests while the system is in stop mode.
// GET/HEAD/OPTIONS always pass.
// Superadmin: full bypass.
// Primary admin: can only change the pause state (/system/* routes).
// Everyone else: 423 Locked with a message.
func RequireSystemActive(db *pgxpool.Pool, rdb *redis.Client) fiber.Handler {
	return func(c *fiber.Ctx) error {
		// Read methods always pass
		method := c.Method()
		if method == "GET" || method == "HEAD" || method == "OPTIONS" {
			return c.Next()
		}

		claims, ok := c.Locals("claims").(*types.Claims)
		if !ok || claims == nil {
			return c.Next()
		}

		// Superadmin: full bypass
		if claims.IsSuperadmin {
			return c.Next()
		}

		paused, contact := isSystemPaused(c.UserContext(), db, rdb, claims.TenantID)
		if !paused {
			return c.Next()
		}

		// Primary admin: allow the system control routes only
		if isPrimaryAdminCached(c.UserContext(), db, rdb, claims.UserID, claims.TenantID) {
			path := c.Path()
			if len(path) >= 15 && path[:15] == "/api/v1/system/" {
				return c.Next()
			}
		}

		msg := "Sistema en modo de solo lectura. No se permiten modificaciones."
		if contact != "" {
			msg += " Contacto: " + contact
		}
		return c.Status(fiber.StatusLocked).JSON(fiber.Map{"error": msg})
	}
}

// isSystemPaused checks Redis first and falls back to the DB. Cached for 60s.
func isSystemPaused(ctx context.Context, db *pgxpool.Pool, rdb *redis.Client, tenantID int64) (bool, string) {
	key := fmt.Sprintf("system_paused:%d", tenantID)

	// Try reading from Redis
	val, err := rdb.Get(ctx, key).Result()
	if err == nil {
		if val == "0" {
			return false, ""
		}
		// The value is "1|contact"
		contact := ""
		if len(val) > 2 {
			contact = val[2:]
		}
		return true, contact
	}

	// Fall back to the DB
	var paused bool
	var contact *string
	err = db.QueryRow(ctx,
		`SELECT system_paused, paused_contact FROM tenants WHERE id = $1`,
		tenantID,
	).Scan(&paused, &contact)
	if err != nil {
		return false, ""
	}

	// Cache it in Redis with a 60s TTL
	contactStr := ""
	if contact != nil {
		contactStr = *contact
	}
	if paused {
		rdb.Set(ctx, key, "1|"+contactStr, 60*time.Second)
	} else {
		rdb.Set(ctx, key, "0", 60*time.Second)
	}

	return paused, contactStr
}

// isPrimaryAdminCached checks whether the user is the primary admin, cached in Redis.
func isPrimaryAdminCached(ctx context.Context, db *pgxpool.Pool, rdb *redis.Client, userID, tenantID int64) bool {
	key := fmt.Sprintf("is_primary_admin:%d:%d", tenantID, userID)

	val, err := rdb.Get(ctx, key).Result()
	if err == nil {
		return val == "1"
	}

	var isPrimary bool
	err = db.QueryRow(ctx,
		`SELECT is_primary_admin FROM users WHERE id = $1 AND tenant_id = $2`,
		userID, tenantID,
	).Scan(&isPrimary)
	if err != nil {
		return false
	}

	if isPrimary {
		rdb.Set(ctx, key, "1", 5*time.Minute)
	} else {
		rdb.Set(ctx, key, "0", 5*time.Minute)
	}

	return isPrimary
}

// InvalidatePauseCache clears the pause cache to force an immediate re-read.
func InvalidatePauseCache(ctx context.Context, rdb *redis.Client, tenantID int64) {
	key := fmt.Sprintf("system_paused:%d", tenantID)
	rdb.Del(ctx, key)
}
