package middleware

import (
	"testing"
	"time"

	"arche-gmao/api/internal/types"

	"github.com/golang-jwt/jwt/v5"
)

func TestIsTokenRevoked_NilRedis(t *testing.T) {
	old := rdbRef
	rdbRef = nil
	defer func() { rdbRef = old }()

	claims := &types.Claims{
		UserID: 1,
		JTI:    "test-jti",
	}
	if IsTokenRevoked(claims) {
		t.Error("expected false when Redis is nil")
	}
}

func TestIsTokenRevoked_EmptyJTI(t *testing.T) {
	old := rdbRef
	rdbRef = nil
	defer func() { rdbRef = old }()

	claims := &types.Claims{
		UserID: 1,
		JTI:    "",
	}
	if IsTokenRevoked(claims) {
		t.Error("expected false for empty JTI with nil Redis")
	}
}

func TestIsTokenRevoked_SuperadminKeyFormat(t *testing.T) {
	// Checks that superadmins use a different key ("revoked_sa:" vs "revoked_user:")
	claims := &types.Claims{
		UserID:       42,
		IsSuperadmin: true,
		JTI:          "sa-jti",
		RegisteredClaims: jwt.RegisteredClaims{
			IssuedAt: jwt.NewNumericDate(time.Now()),
		},
	}

	// Without Redis it always returns false — but we check that it does not panic
	old := rdbRef
	rdbRef = nil
	defer func() { rdbRef = old }()

	if IsTokenRevoked(claims) {
		t.Error("expected false with nil Redis")
	}
}
