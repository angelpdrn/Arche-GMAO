package middleware

import (
	"context"
	"net/http/httptest"
	"testing"

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
)

func TestSetTenantContext_InjectsID(t *testing.T) {
	app := fiber.New()
	app.Use(func(c *fiber.Ctx) error {
		c.Locals("claims", &types.Claims{UserID: 1, TenantID: 42, Role: "admin"})
		return c.Next()
	})
	app.Use(SetTenantContext())
	app.Get("/test", func(c *fiber.Ctx) error {
		tid, ok := c.UserContext().Value(TenantIDKey).(int64)
		if !ok || tid != 42 {
			t.Errorf("expected tenant_id=42, got %v (ok=%v)", tid, ok)
		}
		return c.SendString("ok")
	})

	req := httptest.NewRequest("GET", "/test", nil)
	_, err := app.Test(req)
	if err != nil {
		t.Fatal(err)
	}
}

func TestSetTenantContext_NoClaims(t *testing.T) {
	app := fiber.New()
	app.Use(SetTenantContext())
	app.Get("/test", func(c *fiber.Ctx) error {
		tid, ok := c.UserContext().Value(TenantIDKey).(int64)
		if ok && tid != 0 {
			t.Errorf("expected no tenant_id without claims, got %v", tid)
		}
		return c.SendString("ok")
	})

	req := httptest.NewRequest("GET", "/test", nil)
	resp, err := app.Test(req)
	if err != nil {
		t.Fatal(err)
	}
	if resp.StatusCode != 200 {
		t.Errorf("expected 200, got %d", resp.StatusCode)
	}
}

func TestTenantIDKey_ContextRoundtrip(t *testing.T) {
	ctx := context.WithValue(context.Background(), TenantIDKey, int64(99))
	tid, ok := ctx.Value(TenantIDKey).(int64)
	if !ok || tid != 99 {
		t.Errorf("context roundtrip failed: got %v, ok=%v", tid, ok)
	}
}
