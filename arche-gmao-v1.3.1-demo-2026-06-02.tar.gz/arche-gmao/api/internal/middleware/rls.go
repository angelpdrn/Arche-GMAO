package middleware

import (
	"context"

	"arche-gmao/api/internal/types"

	"github.com/gofiber/fiber/v2"
)

type contextKey string

const TenantIDKey contextKey = "rls_tenant_id"

// SetTenantContext stores the JWT's TenantID in the request context.
// The DB pool's BeforeAcquire/AfterRelease hooks read this value
// to run SET ROLE arche_app + SET app.current_tenant_id automatically.
func SetTenantContext() fiber.Handler {
	return func(c *fiber.Ctx) error {
		claims, ok := c.Locals("claims").(*types.Claims)
		if !ok || claims == nil {
			return c.Next()
		}
		ctx := context.WithValue(c.UserContext(), TenantIDKey, claims.TenantID)
		c.SetUserContext(ctx)
		return c.Next()
	}
}
