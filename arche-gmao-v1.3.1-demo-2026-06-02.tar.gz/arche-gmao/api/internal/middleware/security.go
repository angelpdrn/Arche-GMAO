package middleware

import (
	"strings"

	"github.com/gofiber/fiber/v2"
)

// RequireJSONContentType rejects requests whose Content-Type is not
// application/json on endpoints that require JSON. It returns 415 BEFORE
// rate limiters or other policies are evaluated.
func RequireJSONContentType() fiber.Handler {
	return func(c *fiber.Ctx) error {
		ct := c.Get("Content-Type")
		if ct == "" {
			return fiber.NewError(fiber.StatusUnsupportedMediaType, "Falta Content-Type: application/json")
		}
		// Tolerate extra parameters (charset, boundary)
		base := strings.TrimSpace(strings.ToLower(strings.SplitN(ct, ";", 2)[0]))
		if base != "application/json" {
			return fiber.NewError(fiber.StatusUnsupportedMediaType, "Content-Type debe ser application/json")
		}
		return c.Next()
	}
}

// SecurityHeaders adds security headers to every HTTP response.
func SecurityHeaders() fiber.Handler {
	return func(c *fiber.Ctx) error {
		// Prevent clickjacking
		c.Set("X-Frame-Options", "SAMEORIGIN")
		// Prevent MIME type sniffing
		c.Set("X-Content-Type-Options", "nosniff")
		// Restrictive referrer policy
		c.Set("Referrer-Policy", "strict-origin-when-cross-origin")
		// Prevent XSS (legacy, but useful for old browsers)
		c.Set("X-XSS-Protection", "1; mode=block")
		// Disable caching on API responses carrying sensitive data
		c.Set("Cache-Control", "no-store")
		c.Set("Pragma", "no-cache")
		// Content Security Policy for HTML responses (QR scan, reports)
		c.Set("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; script-src 'none'; frame-ancestors 'self'")
		// Force HTTPS (turned on when SSL is present)
		c.Set("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
		// Do not let the APIs be embedded
		c.Set("X-Permitted-Cross-Domain-Policies", "none")
		return c.Next()
	}
}
