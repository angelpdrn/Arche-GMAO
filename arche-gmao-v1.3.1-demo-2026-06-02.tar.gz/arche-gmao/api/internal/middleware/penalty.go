package middleware

import (
	"arche-gmao/api/internal/license"

	"github.com/gofiber/fiber/v2"
)

// PenaltyGuard blocks or restricts requests based on the current penalty level.
// Applied after auth, before handlers.
//
// Levels:
//   - none:       full access
//   - aviso:      full access + warning header
//   - lectura:    GET only (read-only mode)
//   - bloqueo:    only /api/license, /api/auth, /api/health
//   - suspension: all API calls blocked
func PenaltyGuard() fiber.Handler {
	return func(c *fiber.Ctx) error {
		level := license.GetPenaltyLevel()

		if level == "none" {
			return c.Next()
		}

		// Add penalty info to every response
		c.Set("X-Arche-Penalty", level)
		if msg := license.FormatPenaltyMessage(); msg != "" {
			c.Set("X-Arche-Penalty-Message", msg)
		}

		path := c.Path()

		// Always allow these paths regardless of penalty
		if isExemptPath(path) {
			return c.Next()
		}

		switch level {
		case "aviso":
			return c.Next()

		case "lectura":
			if c.Method() != "GET" && c.Method() != "HEAD" && c.Method() != "OPTIONS" {
				return fiber.NewError(fiber.StatusForbidden,
					"Sistema en modo solo lectura. Su licencia ha caducado. Contacte con Arche GMAO para renovar.")
			}
			return c.Next()

		case "bloqueo":
			if !isBasicReadPath(path) {
				return fiber.NewError(fiber.StatusForbidden,
					"Acceso restringido. Su licencia lleva más de 7 días caducada. Contacte con Arche GMAO.")
			}
			if c.Method() != "GET" && c.Method() != "HEAD" && c.Method() != "OPTIONS" {
				return fiber.NewError(fiber.StatusForbidden,
					"Sistema bloqueado por licencia caducada.")
			}
			return c.Next()

		case "suspension":
			return fiber.NewError(fiber.StatusServiceUnavailable,
				"Sistema suspendido. Licencia inactiva. Contacte con Arche GMAO urgentemente.")
		}

		return c.Next()
	}
}

func isExemptPath(path string) bool {
	exempts := []string{
		"/api/health",
		"/api/auth/login",
		"/api/auth/logout",
		"/api/auth/refresh",
		"/api/license",
	}
	for _, p := range exempts {
		if path == p || (len(path) > len(p) && path[:len(p)+1] == p+"/") {
			return true
		}
	}
	return false
}

func isBasicReadPath(path string) bool {
	basics := []string{
		"/api/license",
		"/api/auth",
		"/api/health",
		"/api/factory-nodes",
		"/api/work-orders",
		"/api/users/me",
	}
	for _, p := range basics {
		if path == p || (len(path) > len(p) && path[:len(p)+1] == p+"/") {
			return true
		}
	}
	return false
}
