package ai

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"strings"
	"sync"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
)

// NotifyFunc is a callback for sending notifications (in-app + push).
// It lets the worker notify without importing the handlers package.
type NotifyFunc func(db *pgxpool.Pool, tenantID, userID int64, notifType, title, body string, link *string)

// MaintenanceWorker automatically generates preventive WOs from the configured plans.
// It runs hourly and generates WOs with the lead time configured on each plan.
type MaintenanceWorker struct {
	db       *pgxpool.Pool
	stopCh   chan struct{}
	wg       sync.WaitGroup
	notifyFn NotifyFunc
}

func NewMaintenanceWorker(db *pgxpool.Pool) *MaintenanceWorker {
	return &MaintenanceWorker{db: db, stopCh: make(chan struct{})}
}

// SetNotifyFunc sets the notification function (called from server.go once the PushService is created).
func (w *MaintenanceWorker) SetNotifyFunc(fn NotifyFunc) {
	w.notifyFn = fn
}

func (w *MaintenanceWorker) Start() {
	w.wg.Add(1)
	go func() { defer w.wg.Done(); w.run() }()
	log.Println("[ARCHE-PM] Worker de mantenimiento preventivo iniciado")
}

func (w *MaintenanceWorker) Stop() {
	close(w.stopCh)
	w.wg.Wait()
}

func (w *MaintenanceWorker) run() {
	// First run 30 seconds after startup
	select {
	case <-w.stopCh:
		return
	case <-time.After(30 * time.Second):
	}
	w.processPlans()

	ticker := time.NewTicker(1 * time.Hour)
	defer ticker.Stop()

	for {
		select {
		case <-w.stopCh:
			return
		case <-ticker.C:
			w.processPlans()
		}
	}
}

// planRow holds every field needed to generate WOs
type planRow struct {
	PlanID              int64
	TenantID            int64
	NodeID              *int64
	EquipmentTemplateID *int64
	Title               string
	Description         *string
	WOType              string
	Priority            string
	AssignedTo          *int64
	EstHours            *float64
	FreqType            string
	FreqVal             int
	NextDueAt           time.Time
	ApplyToChildren     bool
	Instructions        *string
	Checklist           json.RawMessage
	SafetyNotes         *string
	ToolsRequired       json.RawMessage
	RequiredParts       json.RawMessage
}

func (w *MaintenanceWorker) processPlans() {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()

	// 1. Process WOs from staggered_schedule (plans with staggering enabled)
	staggeredCount := w.processStaggeredSchedule(ctx)

	// 1b. Auto-renew expired staggered cycles
	w.autoRenewStaggeredCycles(ctx)

	// 2. Process normal plans (no staggering)
	rows, err := w.db.Query(ctx, `
		SELECT
			mp.id AS plan_id,
			mp.tenant_id,
			mp.node_id,
			mp.equipment_template_id,
			mp.title,
			mp.description,
			mp.wo_type,
			mp.priority,
			mp.assigned_to,
			mp.estimated_hours,
			mp.frequency_type,
			mp.frequency_value,
			mp.next_due_at,
			mp.apply_to_children,
			mp.instructions,
			COALESCE(mp.checklist, '[]'),
			mp.safety_notes,
			COALESCE(mp.tools_required, '[]'),
			COALESCE(mp.required_parts, '[]')
		FROM maintenance_plans mp
		WHERE mp.is_active = true
		  AND mp.staggering_enabled = false
		  AND (mp.next_due_at - (mp.advance_days || ' days')::INTERVAL) <= NOW()
		  AND mp.next_due_at > NOW() - INTERVAL '30 days'
		  AND NOT EXISTS (
		      SELECT 1 FROM maintenance_plan_executions mpe
		      WHERE mpe.plan_id = mp.id
		        AND mpe.executed_at >= NOW() - INTERVAL '23 hours'
		  )
		ORDER BY mp.tenant_id, mp.next_due_at ASC
	`)
	if err != nil {
		log.Printf("[ARCHE-PM] Error consultando planes: %v", err)
		return
	}
	defer rows.Close()

	generated := 0
	for rows.Next() {
		var p planRow
		if err := rows.Scan(
			&p.PlanID, &p.TenantID, &p.NodeID, &p.EquipmentTemplateID,
			&p.Title, &p.Description,
			&p.WOType, &p.Priority, &p.AssignedTo, &p.EstHours,
			&p.FreqType, &p.FreqVal, &p.NextDueAt,
			&p.ApplyToChildren, &p.Instructions, &p.Checklist,
			&p.SafetyNotes, &p.ToolsRequired, &p.RequiredParts,
		); err != nil {
			continue
		}

		count, genErr := w.generateWOs(ctx, p)
		if genErr != nil {
			log.Printf("[ARCHE-PM] Error generando OTs para plan %d: %v", p.PlanID, genErr)
		} else {
			generated += count
		}
	}

	total := generated + staggeredCount
	if total > 0 {
		log.Printf("[ARCHE-PM] %d OTs preventivas generadas (%d normales, %d escalonadas)", total, generated, staggeredCount)
	}
}

// processStaggeredSchedule generates WOs for the staggered_schedule entries scheduled for today.
func (w *MaintenanceWorker) processStaggeredSchedule(ctx context.Context) int {
	today := time.Now().Format("2006-01-02")

	rows, err := w.db.Query(ctx, `
		SELECT ss.id, ss.tenant_id, ss.cycle_id, ss.plan_id, ss.node_id, ss.technician_id,
		       mp.title, mp.description, mp.wo_type, mp.priority, mp.estimated_hours,
		       mp.instructions, COALESCE(mp.checklist,'[]'), mp.safety_notes,
		       COALESCE(mp.tools_required,'[]'), COALESCE(mp.required_parts,'[]'),
		       fn.name AS node_name
		FROM staggered_schedule ss
		JOIN maintenance_plans mp ON mp.id = ss.plan_id
		JOIN factory_nodes fn ON fn.id = ss.node_id
		WHERE ss.status = 'scheduled'
		  AND ss.scheduled_date = $1::date
		ORDER BY ss.tenant_id, ss.id
	`, today)
	if err != nil {
		log.Printf("[ARCHE-PM] Error consultando schedule escalonado: %v", err)
		return 0
	}
	defer rows.Close()

	generated := 0
	for rows.Next() {
		var (
			entryID, tenantID, cycleID, planID, nodeID int64
			techID                                      *int64
			title                                       string
			description                                 *string
			woType, priority                            string
			estHours                                    *float64
			instructions                                *string
			checklist, toolsReq, partsReq               json.RawMessage
			safetyNotes                                 *string
			nodeName                                    string
		)
		if err := rows.Scan(
			&entryID, &tenantID, &cycleID, &planID, &nodeID, &techID,
			&title, &description, &woType, &priority, &estHours,
			&instructions, &checklist, &safetyNotes, &toolsReq, &partsReq,
			&nodeName,
		); err != nil {
			log.Printf("[ARCHE-PM] Error leyendo schedule entry: %v", err)
			continue
		}

		// Find an admin for the tenant
		var adminID int64
		w.db.QueryRow(ctx,
			`SELECT id FROM users WHERE tenant_id=$1 AND role IN ('admin','supervisor') AND status='active'
			 ORDER BY role='admin' DESC LIMIT 1`, tenantID,
		).Scan(&adminID)
		if adminID == 0 {
			continue
		}

		woDescription := workerBuildDescription(description, instructions, checklist, safetyNotes, toolsReq, partsReq)
		woNumber := w.generateWONumber(ctx, tenantID)
		woTitle := "[PM] " + title + " — " + nodeName

		assignee := techID
		if assignee == nil {
			// Fallback: use the plan's assignee
			var planAssignee *int64
			w.db.QueryRow(ctx,
				`SELECT assigned_to FROM maintenance_plans WHERE id=$1`, planID,
			).Scan(&planAssignee)
			assignee = planAssignee
		}

		woID, insertErr := w.insertWO(ctx, tenantID, nodeID, woNumber,
			woTitle, woDescription, woType, priority, assignee, estHours, time.Now(), adminID, partsReq)
		if insertErr != nil {
			log.Printf("[ARCHE-PM] Error creando OT escalonada para nodo %d: %v", nodeID, insertErr)
			continue
		}

		// Mark the entry as generated and link the WO
		w.db.Exec(ctx,
			`UPDATE staggered_schedule SET status='generated', wo_id=$1 WHERE id=$2`,
			woID, entryID,
		)

		// Record the plan execution
		w.db.Exec(ctx,
			`INSERT INTO maintenance_plan_executions (plan_id, tenant_id, wo_id, target_node_id, notes)
			 VALUES ($1,$2,$3,$4,$5)`,
			planID, tenantID, woID, nodeID,
			fmt.Sprintf("Auto escalonado — %s — %s", nodeName, today),
		)

		// Update the cycle counters
		w.db.Exec(ctx,
			`UPDATE staggered_cycles SET total_executed = total_executed + 1,
			 status = CASE WHEN status = 'planned' THEN 'in_progress' ELSE status END
			 WHERE id = $1`, cycleID,
		)

		generated++
		log.Printf("[ARCHE-PM] OT escalonada generada: %s — Plan %d — %s", woNumber, planID, nodeName)
	}

	return generated
}

// autoRenewStaggeredCycles spots expired cycles and creates the next one automatically
// when the staggering configuration is still active.
func (w *MaintenanceWorker) autoRenewStaggeredCycles(ctx context.Context) {
	// Find cycles whose period has ended while their config is still active
	rows, err := w.db.Query(ctx, `
		SELECT cy.id, cy.config_id, cy.tenant_id, sc.is_active
		FROM staggered_cycles cy
		JOIN staggered_configs sc ON sc.id = cy.config_id AND sc.tenant_id = cy.tenant_id
		WHERE cy.status IN ('planned', 'in_progress')
		  AND cy.cycle_end < CURRENT_DATE
		ORDER BY cy.tenant_id, cy.id
	`)
	if err != nil {
		return
	}
	defer rows.Close()

	type expiredCycle struct {
		CycleID  int64
		ConfigID int64
		TenantID int64
		IsActive bool
	}
	var expired []expiredCycle
	for rows.Next() {
		var ec expiredCycle
		if rows.Scan(&ec.CycleID, &ec.ConfigID, &ec.TenantID, &ec.IsActive) == nil {
			expired = append(expired, ec)
		}
	}

	for _, ec := range expired {
		// Mark the previous cycle as completed
		w.db.Exec(ctx,
			`UPDATE staggered_cycles SET status='completed' WHERE id=$1 AND tenant_id=$2`,
			ec.CycleID, ec.TenantID,
		)
		log.Printf("[ARCHE-PM] Ciclo escalonado %d marcado como completado (expirado)", ec.CycleID)

		// When the config is still active, create a new cycle
		if ec.IsActive {
			// Find an admin/supervisor for created_by
			var createdBy int64
			w.db.QueryRow(ctx,
				`SELECT id FROM users WHERE tenant_id=$1 AND role IN ('admin','supervisor') AND status='active'
				 ORDER BY role='admin' DESC LIMIT 1`, ec.TenantID,
			).Scan(&createdBy)
			if createdBy == 0 {
				continue
			}

			svc := NewStaggeringService(w.db)
			cycleID, err := svc.ApplySchedule(ctx, ec.TenantID, ec.ConfigID, createdBy)
			if err != nil {
				log.Printf("[ARCHE-PM] Error auto-renovando ciclo para config %d: %v", ec.ConfigID, err)
			} else {
				log.Printf("[ARCHE-PM] Nuevo ciclo escalonado %d creado automáticamente (renovación de config %d)", cycleID, ec.ConfigID)
			}
		}
	}
}

func (w *MaintenanceWorker) generateWOs(ctx context.Context, p planRow) (int, error) {
	// Per-plan lock to prevent duplicate generation under concurrency
	_, _ = w.db.Exec(ctx, `SELECT pg_advisory_lock($1)`, p.PlanID)
	defer w.db.Exec(ctx, `SELECT pg_advisory_unlock($1)`, p.PlanID)

	// Re-check that it was not generated while we waited for the lock
	var recentExec int
	w.db.QueryRow(ctx,
		`SELECT COUNT(*) FROM maintenance_plan_executions WHERE plan_id=$1 AND executed_at >= NOW() - INTERVAL '23 hours'`,
		p.PlanID).Scan(&recentExec)
	if recentExec > 0 {
		return 0, nil
	}

	// Find an admin for the tenant
	var adminID int64
	err := w.db.QueryRow(ctx,
		`SELECT id FROM users WHERE tenant_id=$1 AND role IN ('admin','supervisor') AND status='active' ORDER BY role='admin' DESC LIMIT 1`,
		p.TenantID,
	).Scan(&adminID)
	if err != nil || adminID == 0 {
		return 0, fmt.Errorf("no se encontró usuario admin/supervisor para tenant %d", p.TenantID)
	}

	// Build the formatted description
	woDescription := workerBuildDescription(p.Description, p.Instructions, p.Checklist,
		p.SafetyNotes, p.ToolsRequired, p.RequiredParts)

	generated := 0

	// Helper for generating a WO on a node
	createWOForNode := func(targetID int64, targetName string) {
		woNumber := w.generateWONumber(ctx, p.TenantID)
		woTitle := "[PM] " + p.Title
		if targetName != "" && (p.ApplyToChildren || (p.EquipmentTemplateID != nil && *p.EquipmentTemplateID > 0)) {
			woTitle += " — " + targetName
		}
		woID, insertErr := w.insertWO(ctx, p.TenantID, targetID, woNumber,
			woTitle, woDescription,
			p.WOType, p.Priority, p.AssignedTo, p.EstHours, p.NextDueAt, adminID, p.RequiredParts)
		if insertErr != nil {
			log.Printf("[ARCHE-PM] Error creando OT para nodo %d del plan %d: %v", targetID, p.PlanID, insertErr)
			return
		}
		w.db.Exec(ctx,
			`INSERT INTO maintenance_plan_executions
			 (plan_id, tenant_id, wo_id, target_node_id, notes)
			 VALUES ($1,$2,$3,$4,$5)`,
			p.PlanID, p.TenantID, woID, targetID,
			fmt.Sprintf("Auto — %s — programada: %s", targetName, p.NextDueAt.Format("02/01/2006")))
		log.Printf("[ARCHE-PM] OT generada: %s — Plan %d — %s", woNumber, p.PlanID, targetName)
		generated++
	}

	if p.EquipmentTemplateID != nil && *p.EquipmentTemplateID > 0 {
		// Plan by equipment template: generate a WO for every node using that template
		tRows, tErr := w.db.Query(ctx,
			`SELECT fn.id, fn.name FROM factory_nodes fn
			 WHERE fn.template_id=$1 AND fn.tenant_id=$2
			   AND NOT EXISTS (
			       SELECT 1 FROM maintenance_plan_exclusions mpe
			       JOIN factory_nodes excl ON excl.id = mpe.node_id AND excl.tenant_id = $2
			       WHERE mpe.plan_id=$3 AND mpe.tenant_id=$2 AND fn.path <@ excl.path
			   )
			 ORDER BY fn.name LIMIT 50`,
			*p.EquipmentTemplateID, p.TenantID, p.PlanID,
		)
		if tErr != nil {
			return 0, fmt.Errorf("error buscando nodos para template %d: %w", *p.EquipmentTemplateID, tErr)
		}
		defer tRows.Close()
		for tRows.Next() {
			var nID int64
			var nName string
			if tRows.Scan(&nID, &nName) == nil {
				createWOForNode(nID, nName)
			}
		}
	} else if p.ApplyToChildren && p.NodeID != nil {
		// Find the node's children, leaving out the excluded ones
		childRows, childErr := w.db.Query(ctx,
			`SELECT fn.id, fn.name FROM factory_nodes fn
			 JOIN factory_nodes parent ON parent.id=$1 AND parent.tenant_id=$2
			 WHERE fn.path <@ parent.path AND fn.id != $1
			   AND fn.node_type IN ('equipment','component','measurement_point')
			   AND fn.tenant_id=$2
			   AND NOT EXISTS (
			       SELECT 1 FROM maintenance_plan_exclusions mpe
			       JOIN factory_nodes excl ON excl.id = mpe.node_id AND excl.tenant_id = $2
			       WHERE mpe.plan_id=$3 AND mpe.tenant_id=$2 AND fn.path <@ excl.path
			   )
			 ORDER BY fn.path LIMIT 50`,
			*p.NodeID, p.TenantID, p.PlanID,
		)
		if childErr != nil {
			return 0, fmt.Errorf("error buscando hijos del nodo %d: %w", *p.NodeID, childErr)
		}
		defer childRows.Close()
		for childRows.Next() {
			var childID int64
			var childName string
			if childRows.Scan(&childID, &childName) == nil {
				createWOForNode(childID, childName)
			}
		}
	} else if p.NodeID != nil {
		// Simple execution on the plan's node
		createWOForNode(*p.NodeID, p.Title)
	}

	// Compute and store the next date (once only)
	newNextDue := advanceDate(p.NextDueAt, p.FreqType, p.FreqVal)
	w.db.Exec(ctx,
		`UPDATE maintenance_plans SET
		 last_executed_at=NOW(), next_due_at=$1,
		 total_executions=total_executions+1
		 WHERE id=$2 AND tenant_id=$3`,
		newNextDue, p.PlanID, p.TenantID,
	)

	return generated, nil
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

func (w *MaintenanceWorker) generateWONumber(ctx context.Context, tenantID int64) string {
	var woNumber string
	tx, err := w.db.Begin(ctx)
	if err != nil {
		return fmt.Sprintf("OT-%s-0001", time.Now().Format("20060102"))
	}
	defer tx.Rollback(ctx)

	tx.Exec(ctx, `SELECT pg_advisory_xact_lock($1)`, tenantID)
	tx.QueryRow(ctx,
		`SELECT 'OT-' || TO_CHAR(NOW(),'YYYYMMDD') || '-' ||
		 LPAD((COALESCE(MAX(CAST(SUBSTRING(wo_number FROM 14) AS INT)),0)+1)::text,4,'0')
		 FROM work_orders WHERE wo_number LIKE 'OT-' || TO_CHAR(NOW(),'YYYYMMDD') || '-%' AND tenant_id=$1`,
		tenantID,
	).Scan(&woNumber)
	tx.Commit(ctx)
	if woNumber == "" {
		woNumber = fmt.Sprintf("OT-%s-0001", time.Now().Format("20060102"))
	}
	return woNumber
}

func (w *MaintenanceWorker) insertWO(ctx context.Context,
	tenantID, nodeID int64, woNumber, title, description, woType, priority string,
	assignedTo *int64, estHours *float64, plannedEnd time.Time, createdBy int64,
	partsRaw json.RawMessage,
) (int64, error) {
	var woID int64
	err := w.db.QueryRow(ctx,
		`INSERT INTO work_orders
		 (tenant_id, node_id, wo_number, title, description, wo_type, priority,
		  status, assigned_to, estimated_hours, planned_end, created_by)
		 VALUES ($1,$2,$3,$4,$5,$6,$7,'pending',$8,$9,$10,$11) RETURNING id`,
		tenantID, nodeID, woNumber, title, description, woType, priority,
		assignedTo, estHours, plannedEnd, createdBy,
	).Scan(&woID)
	if err != nil {
		return 0, fmt.Errorf("error insertando OT: %w", err)
	}

	w.db.Exec(ctx,
		`INSERT INTO work_order_log (tenant_id, wo_id, user_id, to_status, comment)
		 VALUES ($1,$2,$3,'pending','OT generada automáticamente por plan de mantenimiento preventivo')`,
		tenantID, woID, createdBy,
	)

	// Link the plan's spare parts to the WO
	w.linkPartsToWO(ctx, tenantID, woID, partsRaw)

	// Notify the assigned technician (in-app + push)
	if assignedTo != nil && w.notifyFn != nil {
		link := "/work-orders"
		w.notifyFn(w.db, tenantID, *assignedTo,
			"wo_assigned",
			"OT preventiva asignada: "+woNumber,
			"Se te ha asignado la OT preventiva: "+title,
			&link)
	}

	return woID, nil
}

// linkPartsToWO inserts the plan's required spare parts into work_order_parts.
func (w *MaintenanceWorker) linkPartsToWO(ctx context.Context, tenantID, woID int64, partsRaw json.RawMessage) {
	var parts []struct {
		SparePartID int64 `json:"spare_part_id"`
		Name        string `json:"name"`
		Code        string `json:"code"`
		Quantity    int    `json:"quantity"`
	}
	if json.Unmarshal(partsRaw, &parts) != nil || len(parts) == 0 {
		return
	}
	for _, p := range parts {
		qty := p.Quantity
		if qty <= 0 {
			qty = 1
		}
		spareID := p.SparePartID
		if spareID == 0 && p.Code != "" {
			// Resolve by code when there is no direct ID
			w.db.QueryRow(ctx,
				`SELECT id FROM spare_parts WHERE code=$1 AND tenant_id=$2 LIMIT 1`, p.Code, tenantID,
			).Scan(&spareID)
		}
		if spareID > 0 {
			w.db.Exec(ctx,
				`INSERT INTO work_order_parts (wo_id, spare_part_id, quantity)
				 VALUES ($1,$2,$3) ON CONFLICT (wo_id, spare_part_id) DO NOTHING`,
				woID, spareID, qty,
			)
		}
	}
}

func advanceDate(from time.Time, freqType string, freqVal int) time.Time {
	if freqVal <= 0 {
		freqVal = 1
	}
	var next time.Time
	switch freqType {
	case "days":
		next = from.AddDate(0, 0, freqVal)
	case "weeks":
		next = from.AddDate(0, 0, freqVal*7)
	case "months":
		next = from.AddDate(0, freqVal, 0)
	default:
		next = from.AddDate(0, 1, 0)
	}
	// When it is already in the past, move it forward into the future
	for next.Before(time.Now()) {
		switch freqType {
		case "days":
			next = next.AddDate(0, 0, freqVal)
		case "weeks":
			next = next.AddDate(0, 0, freqVal*7)
		case "months":
			next = next.AddDate(0, freqVal, 0)
		default:
			next = next.AddDate(0, 1, 0)
		}
	}
	return next
}

func workerBuildDescription(desc *string, instructions *string, checklistRaw json.RawMessage,
	safetyNotes *string, toolsRaw json.RawMessage, partsRaw json.RawMessage) string {

	var sb strings.Builder

	if desc != nil && *desc != "" {
		sb.WriteString(*desc)
		sb.WriteString("\n\n")
	}

	if instructions != nil && *instructions != "" {
		sb.WriteString("PROCEDIMIENTO\n")
		sb.WriteString(strings.Repeat("\u2500", 35))
		sb.WriteString("\n")
		sb.WriteString(*instructions)
		sb.WriteString("\n\n")
	}

	var checklist []struct {
		Step     string `json:"step"`
		Required bool   `json:"required"`
	}
	if json.Unmarshal(checklistRaw, &checklist) == nil && len(checklist) > 0 {
		sb.WriteString("LISTA DE VERIFICACION\n")
		sb.WriteString(strings.Repeat("\u2500", 35))
		sb.WriteString("\n")
		for i, item := range checklist {
			marker := "[ ]"
			suffix := ""
			if item.Required {
				marker = "[*]"
				suffix = " (obligatorio)"
			}
			sb.WriteString(fmt.Sprintf("%s %d. %s%s\n", marker, i+1, item.Step, suffix))
		}
		sb.WriteString("\n")
	}

	if safetyNotes != nil && *safetyNotes != "" {
		sb.WriteString("NOTAS DE SEGURIDAD\n")
		sb.WriteString(strings.Repeat("\u2500", 35))
		sb.WriteString("\n")
		sb.WriteString(*safetyNotes)
		sb.WriteString("\n\n")
	}

	var tools []string
	if json.Unmarshal(toolsRaw, &tools) == nil && len(tools) > 0 {
		sb.WriteString("HERRAMIENTAS NECESARIAS\n")
		sb.WriteString(strings.Repeat("\u2500", 35))
		sb.WriteString("\n")
		for _, t := range tools {
			sb.WriteString(fmt.Sprintf("  - %s\n", t))
		}
		sb.WriteString("\n")
	}

	var parts []struct {
		Name     string `json:"name"`
		Code     string `json:"code"`
		Quantity int    `json:"quantity"`
	}
	if json.Unmarshal(partsRaw, &parts) == nil && len(parts) > 0 {
		sb.WriteString("REPUESTOS NECESARIOS\n")
		sb.WriteString(strings.Repeat("\u2500", 35))
		sb.WriteString("\n")
		for _, p := range parts {
			qty := p.Quantity
			if qty == 0 {
				qty = 1
			}
			sb.WriteString(fmt.Sprintf("  - %s (%s) x%d\n", p.Name, p.Code, qty))
		}
		sb.WriteString("\n")
	}

	return strings.TrimSpace(sb.String())
}
