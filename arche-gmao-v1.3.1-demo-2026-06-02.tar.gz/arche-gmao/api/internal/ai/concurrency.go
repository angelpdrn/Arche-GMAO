package ai

import "context"

// AISemaphore limits the concurrency of requests to the AI model.
// Implemented as a buffered channel (counting semaphore).
type AISemaphore struct {
	ch chan struct{}
}

// NewAISemaphore creates a semaphore with the given capacity (default 3).
func NewAISemaphore(capacity int) *AISemaphore {
	if capacity <= 0 {
		capacity = 3
	}
	return &AISemaphore{ch: make(chan struct{}, capacity)}
}

// TryAcquire tries to take a slot without blocking.
// It returns true when a slot was acquired immediately.
func (s *AISemaphore) TryAcquire() bool {
	select {
	case s.ch <- struct{}{}:
		return true
	default:
		return false
	}
}

// Acquire blocks until a slot is acquired or the context expires.
func (s *AISemaphore) Acquire(ctx context.Context) error {
	select {
	case s.ch <- struct{}{}:
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}

// Release frees a semaphore slot.
func (s *AISemaphore) Release() {
	<-s.ch
}
