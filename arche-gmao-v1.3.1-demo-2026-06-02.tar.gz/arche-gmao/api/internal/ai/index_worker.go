package ai

import (
	"context"
	"fmt"
	"log"
	"sync"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
)

// NotifyRoleFunc is a callback for sending notifications to a role without importing handlers.
type NotifyRoleFunc func(db *pgxpool.Pool, tenantID int64, role, notifType, title, body string, link *string)

// IndexWorker processes the ai_index_queue in the background
// and runs the pattern detector periodically.
type IndexWorker struct {
	db           *pgxpool.Pool
	rag          *RAGService
	detector     *PatternDetector
	stopCh       chan struct{}
	wg           sync.WaitGroup
	sem          chan struct{}
	notifyRoleFn NotifyRoleFunc
}

func NewIndexWorker(db *pgxpool.Pool, rag *RAGService) *IndexWorker {
	return &IndexWorker{
		db:       db,
		rag:      rag,
		detector: NewPatternDetector(db),
		stopCh:   make(chan struct{}),
		sem:      make(chan struct{}, 3), // at most 3 concurrent detections
	}
}

// SetNotifyRoleFunc sets the per-role notification function.
func (w *IndexWorker) SetNotifyRoleFunc(fn NotifyRoleFunc) {
	w.notifyRoleFn = fn
}

func (w *IndexWorker) Start() {
	w.wg.Add(2)
	go func() { defer w.wg.Done(); w.runIndexQueue() }()
	go func() { defer w.wg.Done(); w.runPatternDetection() }()
	log.Println("[ARCHE-AI] Workers iniciados: indexación + detección de patrones")
}

func (w *IndexWorker) Stop() {
	close(w.stopCh)
	w.wg.Wait()
}

// ─── Indexing worker (every 10 seconds) ──────────────────────────────────

func (w *IndexWorker) runIndexQueue() {
	ticker := time.NewTicker(10 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-w.stopCh:
			return
		case <-ticker.C:
			w.processQueue()
		}
	}
}

func (w *IndexWorker) processQueue() {
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()

	var (
		queueID    int64
		tenantID   int64
		action     string
		sourceType string
		sourceID   int64
	)

	err := w.db.QueryRow(ctx,
		`UPDATE ai_index_queue
		 SET status='processing', processed_at=NOW()
		 WHERE id = (
		     SELECT id FROM ai_index_queue
		     WHERE status='pending'
		     ORDER BY priority ASC, created_at ASC
		     LIMIT 1
		     FOR UPDATE SKIP LOCKED
		 )
		 RETURNING id, tenant_id, action, source_type, source_id`,
	).Scan(&queueID, &tenantID, &action, &sourceType, &sourceID)

	if err != nil {
		return // No pending items
	}

	log.Printf("[ARCHE-AI] Procesando: %s %s/%d (tenant %d)", action, sourceType, sourceID, tenantID)

	var processErr error
	switch action {
	case "index", "reindex":
		switch sourceType {
		case "work_order":
			processErr = w.rag.IndexWorkOrder(ctx, tenantID, sourceID)
		case "node_info":
			processErr = w.rag.IndexNode(ctx, tenantID, sourceID)
		case "maintenance_manual":
			processErr = w.rag.IndexMaintenanceManual(ctx, tenantID, sourceID)
		case "spare_part":
			processErr = w.rag.IndexSparePart(ctx, sourceID, tenantID)
		case "maintenance_plan":
			processErr = w.rag.IndexMaintenancePlan(ctx, sourceID, tenantID)
		case "knowledge":
			processErr = w.rag.IndexKnowledge(ctx, tenantID, sourceID)
		case "attachment":
			processErr = w.rag.IndexAttachment(ctx, tenantID, sourceID)
		}
	case "delete":
		processErr = w.rag.DeleteEmbeddings(ctx, tenantID, sourceType, sourceID)
	}

	if processErr != nil {
		log.Printf("[ARCHE-AI] Error item %d: %v", queueID, processErr)
		w.db.Exec(ctx,
			`UPDATE ai_index_queue SET status='error', error_msg=$1 WHERE id=$2`,
			processErr.Error(), queueID,
		)
	} else {
		w.db.Exec(ctx, `UPDATE ai_index_queue SET status='done' WHERE id=$1`, queueID)

		// After indexing a WO, run pattern detection for that tenant
		if sourceType == "work_order" {
			select {
			case w.sem <- struct{}{}:
				go func() {
					defer func() { <-w.sem }()
					detCtx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
					defer cancel()
					w.detector.RunDetection(detCtx, tenantID)
				}()
			default:
				// semaphore full, detection will run in the periodic cycle
			}
		}
	}
}

// ─── Pattern detection worker (hourly) ─────────────────────────────

func (w *IndexWorker) runPatternDetection() {
	// First run at startup (with a 2 minute delay so the API is ready)
	select {
	case <-w.stopCh:
		return
	case <-time.After(2 * time.Minute):
	}
	w.detectAllTenants()

	// Then every hour
	ticker := time.NewTicker(1 * time.Hour)
	defer ticker.Stop()

	for {
		select {
		case <-w.stopCh:
			return
		case <-ticker.C:
			w.detectAllTenants()
		}
	}
}

func (w *IndexWorker) detectAllTenants() {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()

	// Get every active tenant
	rows, err := w.db.Query(ctx,
		`SELECT id FROM tenants WHERE status = 'active'`,
	)
	if err != nil {
		return
	}
	defer rows.Close()

	for rows.Next() {
		var tenantID int64
		if rows.Scan(&tenantID) == nil {
			count, err := w.detector.RunDetection(ctx, tenantID)
			if err != nil {
				log.Printf("[ARCHE-AI] Error detección patrones tenant %d: %v", tenantID, err)
			} else if count > 0 {
				log.Printf("[ARCHE-AI] Patrones detectados tenant %d: %d nuevos", tenantID, count)
				// Notify supervisors about new patterns
				if w.notifyRoleFn != nil {
					link := "/dashboard"
					w.notifyRoleFn(w.db, tenantID, "supervisor",
						"pattern_detected",
						fmt.Sprintf("%d patron(es) detectado(s)", count),
						"Se han detectado nuevos patrones de mantenimiento. Revisa el panel de alertas.",
						&link)
				}
			}
		}
	}
}

// EnqueueNow adds an item to the queue with high priority.
// It avoids duplicates: when a pending item already exists for the same source, no second one is created.
func EnqueueNow(ctx context.Context, db *pgxpool.Pool, tenantID int64, action, sourceType string, sourceID int64) error {
	_, err := db.Exec(ctx,
		`INSERT INTO ai_index_queue (tenant_id, action, source_type, source_id, priority)
		 SELECT $1,$2,$3,$4,1
		 WHERE NOT EXISTS (
		     SELECT 1 FROM ai_index_queue
		     WHERE tenant_id=$1 AND source_type=$3 AND source_id=$4 AND status='pending'
		 )`,
		tenantID, action, sourceType, sourceID,
	)
	return err
}
