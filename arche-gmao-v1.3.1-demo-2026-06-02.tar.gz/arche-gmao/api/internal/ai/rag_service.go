package ai

import (
	"bufio"
	"bytes"
	"context"
	"fmt"
	"os"
	"strings"
	"unicode/utf8"

	"github.com/jackc/pgx/v5/pgxpool"
)

type RAGService struct {
	db     *pgxpool.Pool
	ollama *OllamaClient
}

func NewRAGService(db *pgxpool.Pool, ollama *OllamaClient) *RAGService {
	return &RAGService{db: db, ollama: ollama}
}

type Chunk struct {
	Text       string
	SourceType string
	SourceID   int64
	ChunkIndex int
	DataType   string
}

type RelevantChunk struct {
	ChunkText  string
	SourceType string
	SourceID   int64
	DataType   string
	Similarity float64
	NodeID     *int64
}

// ─── Index a verified WO ────────────────────────────────────────────────────

func (s *RAGService) IndexWorkOrder(ctx context.Context, tenantID, woID int64) error {
	var (
		title     string
		woNumber  string
		desc      *string
		rootCause *string
		solution  *string
		woType    string
		woStatus  string
		nodeName  string
		nodeID    int64
		actualH   *float64
		createdAt string
	)

	err := s.db.QueryRow(ctx,
		`SELECT wo.title, wo.wo_number, wo.description, wo.root_cause, wo.solution,
		        wo.wo_type, wo.status, fn.name, fn.id,
		        wo.actual_hours, TO_CHAR(wo.created_at, 'DD/MM/YYYY')
		 FROM work_orders wo
		 JOIN factory_nodes fn ON fn.id = wo.node_id
		 WHERE wo.id=$1 AND wo.tenant_id=$2`,
		woID, tenantID,
	).Scan(&title, &woNumber, &desc, &rootCause, &solution, &woType, &woStatus,
		&nodeName, &nodeID, &actualH, &createdAt)
	if err != nil {
		return fmt.Errorf("OT no encontrada: %w", err)
	}

	var templateID *int64
	s.db.QueryRow(ctx, `SELECT template_id FROM factory_nodes WHERE id=$1 AND tenant_id=$2`, nodeID, tenantID).Scan(&templateID)

	var textParts []string
	textParts = append(textParts, fmt.Sprintf("OT: %s (%s)", woNumber, createdAt))
	textParts = append(textParts, fmt.Sprintf("Equipo: %s", nodeName))
	textParts = append(textParts, fmt.Sprintf("Tipo: %s | Estado: %s", woTypeLabel(woType), woStatus))
	textParts = append(textParts, fmt.Sprintf("Título: %s", title))

	if desc != nil && *desc != "" {
		textParts = append(textParts, fmt.Sprintf("Descripción: %s", *desc))
	}
	if rootCause != nil && *rootCause != "" {
		textParts = append(textParts, fmt.Sprintf("Causa raíz identificada: %s", *rootCause))
	}
	if solution != nil && *solution != "" {
		textParts = append(textParts, fmt.Sprintf("Solución aplicada: %s", *solution))
	}
	if actualH != nil && *actualH > 0 {
		textParts = append(textParts, fmt.Sprintf("Horas reales: %.1f", *actualH))
	}

	// Technician comments
	commentRows, _ := s.db.Query(ctx,
		`SELECT content FROM work_order_comments WHERE wo_id=$1 AND tenant_id=$2 ORDER BY created_at`, woID, tenantID,
	)
	if commentRows != nil {
		defer commentRows.Close()
		for commentRows.Next() {
			var comment string
			if err := commentRows.Scan(&comment); err == nil && comment != "" {
				textParts = append(textParts, fmt.Sprintf("Nota del técnico: %s", comment))
			}
		}
	}

	fullText := strings.Join(textParts, "\n")
	chunks := chunkText(fullText, 400, 50)

	for i, chunkText := range chunks {
		embedding, err := s.ollama.GenerateEmbedding(ctx, chunkText)
		if err != nil {
			return fmt.Errorf("error generando embedding chunk %d: %w", i, err)
		}
		embStr := float32SliceToString(embedding)

		_, err = s.db.Exec(ctx,
			`INSERT INTO ai_embeddings
			 (tenant_id, node_id, template_id, source_type, source_id,
			  chunk_text, chunk_index, embedding, verification_status,
			  confidence_level, data_type)
			 VALUES ($1,$2,$3,'work_order',$4,$5,$6,$7::vector,'verified',3,'repair_report')
			 ON CONFLICT (tenant_id, source_type, source_id, chunk_index)
			 DO UPDATE SET chunk_text=EXCLUDED.chunk_text, embedding=EXCLUDED.embedding,
			               indexed_at=NOW()`,
			tenantID, nodeID, templateID, woID,
			chunkText, i, embStr,
		)
		if err != nil {
			return fmt.Errorf("error guardando embedding: %w", err)
		}
	}

	return nil
}

// ─── Index a node's information (virtual factory) ────────────────────────

func (s *RAGService) IndexNode(ctx context.Context, tenantID, nodeID int64) error {
	var (
		name         string
		code         *string
		nodeType     string
		criticality  string
		status       string
		manufacturer *string
		model        *string
		serialNumber *string
		description  *string
		templateMfr  *string
		templateMdl  *string
		parentName   *string
	)

	err := s.db.QueryRow(ctx,
		`SELECT fn.name, fn.code, fn.node_type, fn.criticality, fn.status,
		        fn.manufacturer, fn.model, fn.serial_number, fn.description,
		        et.manufacturer, et.model,
		        parent.name
		 FROM factory_nodes fn
		 LEFT JOIN equipment_templates et ON et.id = fn.template_id
		 LEFT JOIN factory_nodes parent ON parent.id = fn.parent_id
		 WHERE fn.id=$1 AND fn.tenant_id=$2`,
		nodeID, tenantID,
	).Scan(
		&name, &code, &nodeType, &criticality, &status,
		&manufacturer, &model, &serialNumber, &description,
		&templateMfr, &templateMdl, &parentName,
	)
	if err != nil {
		return fmt.Errorf("nodo no encontrado: %w", err)
	}

	var textParts []string
	textParts = append(textParts, fmt.Sprintf("Equipo: %s", name))
	textParts = append(textParts, fmt.Sprintf("Tipo: %s", nodeTypeLabel(nodeType)))
	textParts = append(textParts, fmt.Sprintf("Criticidad: %s", criticality))
	textParts = append(textParts, fmt.Sprintf("Estado: %s", status))

	if code != nil && *code != "" {
		textParts = append(textParts, fmt.Sprintf("Código de equipo: %s", *code))
	}
	if parentName != nil {
		textParts = append(textParts, fmt.Sprintf("Ubicado en: %s", *parentName))
	}
	if manufacturer != nil && *manufacturer != "" {
		textParts = append(textParts, fmt.Sprintf("Fabricante: %s", *manufacturer))
	}
	if model != nil && *model != "" {
		textParts = append(textParts, fmt.Sprintf("Modelo: %s", *model))
	}
	if serialNumber != nil && *serialNumber != "" {
		textParts = append(textParts, fmt.Sprintf("Número de serie: %s", *serialNumber))
	}
	if templateMfr != nil && templateMdl != nil {
		textParts = append(textParts, fmt.Sprintf("Modelo de referencia: %s %s", *templateMfr, *templateMdl))
	}
	if description != nil && *description != "" {
		textParts = append(textParts, fmt.Sprintf("Descripción técnica: %s", *description))
	}

	// Attached spare parts
	spRows, _ := s.db.Query(ctx,
		`SELECT sp.name, sp.code, sp.category,
		        CASE WHEN sp.current_stock <= sp.min_stock THEN 'stock bajo' ELSE 'stock ok' END
		 FROM spare_parts sp
		 JOIN spare_part_nodes spn ON spn.spare_part_id=sp.id AND spn.node_id=$1
		 WHERE sp.tenant_id=$2`,
		nodeID, tenantID,
	)
	if spRows != nil {
		defer spRows.Close()
		var spareParts []string
		for spRows.Next() {
			var spName, spCode, spCat, spStock string
			if spRows.Scan(&spName, &spCode, &spCat, &spStock) == nil {
				spareParts = append(spareParts, fmt.Sprintf("%s (%s) - %s", spName, spCode, spStock))
			}
		}
		if len(spareParts) > 0 {
			textParts = append(textParts, fmt.Sprintf("Repuestos asociados: %s", strings.Join(spareParts, ", ")))
		}
	}

	fullText := strings.Join(textParts, "\n")
	chunks := chunkText(fullText, 400, 50)

	var templateID *int64
	s.db.QueryRow(ctx, `SELECT template_id FROM factory_nodes WHERE id=$1 AND tenant_id=$2`, nodeID, tenantID).Scan(&templateID)

	for i, chunkText := range chunks {
		embedding, err := s.ollama.GenerateEmbedding(ctx, chunkText)
		if err != nil {
			return fmt.Errorf("error generando embedding nodo: %w", err)
		}
		embStr := float32SliceToString(embedding)

		_, err = s.db.Exec(ctx,
			`INSERT INTO ai_embeddings
			 (tenant_id, node_id, template_id, source_type, source_id,
			  chunk_text, chunk_index, embedding, verification_status, data_type)
			 VALUES ($1,$2,$3,'node_info',$4,$5,$6,$7::vector,'verified','node_data')
			 ON CONFLICT (tenant_id, source_type, source_id, chunk_index)
			 DO UPDATE SET chunk_text=EXCLUDED.chunk_text, embedding=EXCLUDED.embedding,
			               indexed_at=NOW()`,
			tenantID, nodeID, templateID, nodeID,
			chunkText, i, embStr,
		)
		if err != nil {
			return fmt.Errorf("error guardando embedding nodo: %w", err)
		}
	}

	return nil
}

// ─── Index a maintenance manual ─────────────────────────────────────────

func (s *RAGService) IndexMaintenanceManual(ctx context.Context, tenantID, manualID int64) error {
	var (
		nodeID      int64
		title       string
		description *string
		contentText *string
		nodeName    string
	)

	err := s.db.QueryRow(ctx,
		`SELECT mm.node_id, mm.title, mm.description, mm.content_text, fn.name
		 FROM maintenance_manuals mm
		 JOIN factory_nodes fn ON fn.id = mm.node_id
		 WHERE mm.id=$1 AND mm.tenant_id=$2 AND mm.is_active=true`,
		manualID, tenantID,
	).Scan(&nodeID, &title, &description, &contentText, &nodeName)
	if err != nil {
		return fmt.Errorf("manual no encontrado: %w", err)
	}

	var textParts []string
	textParts = append(textParts, fmt.Sprintf("Manual de mantenimiento: %s", title))
	textParts = append(textParts, fmt.Sprintf("Equipo: %s", nodeName))
	if description != nil && *description != "" {
		textParts = append(textParts, fmt.Sprintf("Descripción: %s", *description))
	}
	if contentText != nil && *contentText != "" {
		textParts = append(textParts, *contentText)
	}

	fullText := strings.Join(textParts, "\n")
	chunks := chunkText(fullText, 400, 50)

	var templateID *int64
	s.db.QueryRow(ctx, `SELECT template_id FROM factory_nodes WHERE id=$1 AND tenant_id=$2`, nodeID, tenantID).Scan(&templateID)

	for i, chunkText := range chunks {
		embedding, err := s.ollama.GenerateEmbedding(ctx, chunkText)
		if err != nil {
			return fmt.Errorf("error generando embedding manual chunk %d: %w", i, err)
		}
		embStr := float32SliceToString(embedding)

		_, err = s.db.Exec(ctx,
			`INSERT INTO ai_embeddings
			 (tenant_id, node_id, template_id, source_type, source_id,
			  chunk_text, chunk_index, embedding, verification_status,
			  confidence_level, data_type)
			 VALUES ($1,$2,$3,'maintenance_manual',$4,$5,$6,$7::vector,'verified',3,'maintenance_procedure')
			 ON CONFLICT (tenant_id, source_type, source_id, chunk_index)
			 DO UPDATE SET chunk_text=EXCLUDED.chunk_text, embedding=EXCLUDED.embedding,
			               indexed_at=NOW()`,
			tenantID, nodeID, templateID, manualID,
			chunkText, i, embStr,
		)
		if err != nil {
			return fmt.Errorf("error guardando embedding manual: %w", err)
		}
	}

	return nil
}

// ─── Index a spare part ────────────────────────────────────────────────────────

func (s *RAGService) IndexSparePart(ctx context.Context, partID, tenantID int64) error {
	var name, code, category, unit, supplier string
	var currentStock, minStock, maxStock int
	var unitPrice *float64
	var description *string

	err := s.db.QueryRow(ctx,
		`SELECT sp.name, sp.code, sp.category, sp.unit,
		        sp.current_stock, sp.min_stock, sp.max_stock,
		        COALESCE(sp.supplier,''), sp.unit_price, sp.notes
		 FROM spare_parts sp WHERE sp.id=$1 AND sp.tenant_id=$2`,
		partID, tenantID,
	).Scan(&name, &code, &category, &unit,
		&currentStock, &minStock, &maxStock,
		&supplier, &unitPrice, &description)
	if err != nil {
		return fmt.Errorf("repuesto %d no encontrado: %w", partID, err)
	}

	// Linked equipment (get node_ids and template_ids for the RAG search)
	var linkedNodes []string
	var firstNodeID *int64
	var firstTemplateID *int64
	lnRows, _ := s.db.Query(ctx,
		`SELECT fn.id, fn.name, fn.template_id FROM spare_part_nodes spn
		 JOIN factory_nodes fn ON fn.id = spn.node_id
		 WHERE spn.spare_part_id=$1 AND fn.tenant_id=$2`,
		partID, tenantID,
	)
	if lnRows != nil {
		defer lnRows.Close()
		for lnRows.Next() {
			var nid int64
			var n string
			var tid *int64
			if lnRows.Scan(&nid, &n, &tid) == nil {
				linkedNodes = append(linkedNodes, n)
				if firstNodeID == nil {
					firstNodeID = &nid
				}
				if firstTemplateID == nil && tid != nil {
					firstTemplateID = tid
				}
			}
		}
	}

	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("Repuesto: %s (codigo: %s)\n", name, code))
	sb.WriteString(fmt.Sprintf("Categoria: %s, Unidad: %s\n", category, unit))
	sb.WriteString(fmt.Sprintf("Stock actual: %d, Minimo: %d, Maximo: %d\n", currentStock, minStock, maxStock))
	if currentStock <= minStock {
		sb.WriteString("ALERTA: Stock por debajo del minimo.\n")
	}
	if supplier != "" {
		sb.WriteString(fmt.Sprintf("Proveedor: %s\n", supplier))
	}
	if unitPrice != nil {
		sb.WriteString(fmt.Sprintf("Precio unitario: %.2f EUR\n", *unitPrice))
	}
	if description != nil && *description != "" {
		sb.WriteString(fmt.Sprintf("Descripcion: %s\n", *description))
	}
	if len(linkedNodes) > 0 {
		sb.WriteString(fmt.Sprintf("Equipos que lo usan: %s\n", strings.Join(linkedNodes, ", ")))
	}

	text := sb.String()
	chunks := chunkText(text, 400, 50)

	for i, chunkText := range chunks {
		embedding, err := s.ollama.GenerateEmbedding(ctx, chunkText)
		if err != nil {
			return fmt.Errorf("error generando embedding repuesto: %w", err)
		}
		embStr := float32SliceToString(embedding)

		_, err = s.db.Exec(ctx,
			`INSERT INTO ai_embeddings
			 (tenant_id, node_id, template_id, source_type, source_id,
			  chunk_text, chunk_index, embedding, verification_status, data_type)
			 VALUES ($1,$2,$3,'spare_part',$4,$5,$6,$7::vector,'verified','inventory_data')
			 ON CONFLICT (tenant_id, source_type, source_id, chunk_index)
			 DO UPDATE SET chunk_text=EXCLUDED.chunk_text, embedding=EXCLUDED.embedding,
			               node_id=COALESCE(EXCLUDED.node_id, ai_embeddings.node_id),
			               template_id=COALESCE(EXCLUDED.template_id, ai_embeddings.template_id),
			               indexed_at=NOW()`,
			tenantID, firstNodeID, firstTemplateID, partID, chunkText, i, embStr,
		)
		if err != nil {
			return fmt.Errorf("error guardando embedding repuesto: %w", err)
		}
	}
	return nil
}

// ─── Index a maintenance plan ──────────────────────────────────────────

func (s *RAGService) IndexMaintenancePlan(ctx context.Context, planID, tenantID int64) error {
	var title, freqType string
	var freqValue int
	var nodeName, instructions, safetyNotes string
	var nodeID int64
	var nextDue *string

	var templateID *int64

	err := s.db.QueryRow(ctx,
		`SELECT mp.title, mp.frequency_type, mp.frequency_value,
		        fn.name, mp.node_id, fn.template_id,
		        COALESCE(mp.instructions,''),
		        COALESCE(mp.safety_notes,''),
		        COALESCE(TO_CHAR(mp.next_due_at, 'DD/MM/YYYY'), '')
		 FROM maintenance_plans mp
		 JOIN factory_nodes fn ON fn.id = mp.node_id
		 WHERE mp.id=$1 AND mp.tenant_id=$2`,
		planID, tenantID,
	).Scan(&title, &freqType, &freqValue,
		&nodeName, &nodeID, &templateID, &instructions, &safetyNotes, &nextDue)
	if err != nil {
		return fmt.Errorf("plan %d no encontrado: %w", planID, err)
	}

	// Last 5 executions
	var executions []string
	exRows, _ := s.db.Query(ctx,
		`SELECT 'Ejecutado: ' || TO_CHAR(mpe.executed_at, 'DD/MM/YYYY') ||
		        COALESCE(' — ' || COALESCE(mpe.notes,''), '')
		 FROM maintenance_plan_executions mpe
		 WHERE mpe.plan_id=$1 AND mpe.tenant_id=$2 ORDER BY mpe.executed_at DESC LIMIT 5`,
		planID, tenantID,
	)
	if exRows != nil {
		defer exRows.Close()
		for exRows.Next() {
			var s string
			if exRows.Scan(&s) == nil {
				executions = append(executions, s)
			}
		}
	}

	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("Plan preventivo: %s\n", title))
	sb.WriteString(fmt.Sprintf("Equipo: %s\n", nodeName))
	sb.WriteString(fmt.Sprintf("Frecuencia: cada %d %s\n", freqValue, freqType))
	if nextDue != nil && *nextDue != "" {
		sb.WriteString(fmt.Sprintf("Proxima ejecucion: %s\n", *nextDue))
	}
	if instructions != "" {
		sb.WriteString(fmt.Sprintf("Instrucciones: %s\n", instructions))
	}
	if safetyNotes != "" {
		sb.WriteString(fmt.Sprintf("Notas de seguridad: %s\n", safetyNotes))
	}
	if len(executions) > 0 {
		sb.WriteString("Historial de ejecuciones:\n")
		for _, e := range executions {
			sb.WriteString(fmt.Sprintf("  - %s\n", e))
		}
	}

	text := sb.String()
	chunks := chunkText(text, 400, 50)

	for i, chunkText := range chunks {
		embedding, err := s.ollama.GenerateEmbedding(ctx, chunkText)
		if err != nil {
			return fmt.Errorf("error generando embedding plan: %w", err)
		}
		embStr := float32SliceToString(embedding)

		_, err = s.db.Exec(ctx,
			`INSERT INTO ai_embeddings
			 (tenant_id, node_id, template_id, source_type, source_id,
			  chunk_text, chunk_index, embedding, verification_status, data_type)
			 VALUES ($1,$2,$3,'maintenance_plan',$4,$5,$6,$7::vector,'verified','maintenance_plan')
			 ON CONFLICT (tenant_id, source_type, source_id, chunk_index)
			 DO UPDATE SET chunk_text=EXCLUDED.chunk_text, embedding=EXCLUDED.embedding,
			               template_id=COALESCE(EXCLUDED.template_id, ai_embeddings.template_id),
			               indexed_at=NOW()`,
			tenantID, nodeID, templateID, planID, chunkText, i, embStr,
		)
		if err != nil {
			return fmt.Errorf("error guardando embedding plan: %w", err)
		}
	}
	return nil
}

// ─── Index a knowledge article ────────────────────────────────────────

func (s *RAGService) IndexKnowledge(ctx context.Context, tenantID, knowledgeID int64) error {
	var (
		title    string
		content  string
		category string
		folder   string
		source   *string
		isActive bool
	)

	err := s.db.QueryRow(ctx,
		`SELECT title, content, category, folder, source, is_active
		 FROM ai_knowledge WHERE id=$1 AND tenant_id=$2`,
		knowledgeID, tenantID,
	).Scan(&title, &content, &category, &folder, &source, &isActive)
	if err != nil {
		return fmt.Errorf("conocimiento %d no encontrado: %w", knowledgeID, err)
	}

	if !isActive {
		// When it is deactivated, remove the existing embeddings
		return s.DeleteEmbeddings(ctx, tenantID, "knowledge", knowledgeID)
	}

	var textParts []string
	textParts = append(textParts, fmt.Sprintf("Base de conocimiento: %s", title))
	textParts = append(textParts, fmt.Sprintf("Categoría: %s", category))
	if folder != "" && folder != "General" {
		textParts = append(textParts, fmt.Sprintf("Carpeta: %s", folder))
	}
	if source != nil && *source != "" {
		textParts = append(textParts, fmt.Sprintf("Fuente: %s", *source))
	}
	textParts = append(textParts, content)

	fullText := strings.Join(textParts, "\n")
	chunks := chunkText(fullText, 400, 50)

	for i, chunkText := range chunks {
		embedding, err := s.ollama.GenerateEmbedding(ctx, chunkText)
		if err != nil {
			return fmt.Errorf("error generando embedding conocimiento chunk %d: %w", i, err)
		}
		embStr := float32SliceToString(embedding)

		_, err = s.db.Exec(ctx,
			`INSERT INTO ai_embeddings
			 (tenant_id, source_type, source_id,
			  chunk_text, chunk_index, embedding, verification_status,
			  confidence_level, data_type)
			 VALUES ($1,'knowledge',$2,$3,$4,$5::vector,'verified',4,'knowledge_base')
			 ON CONFLICT (tenant_id, source_type, source_id, chunk_index)
			 DO UPDATE SET chunk_text=EXCLUDED.chunk_text, embedding=EXCLUDED.embedding,
			               indexed_at=NOW()`,
			tenantID, knowledgeID,
			chunkText, i, embStr,
		)
		if err != nil {
			return fmt.Errorf("error guardando embedding conocimiento: %w", err)
		}
	}

	return nil
}

// ─── Index a library file (attachment) ─────────────────────────────

func (s *RAGService) IndexAttachment(ctx context.Context, tenantID, attachmentID int64) error {
	var (
		nodeID       *int64
		templateID   *int64
		originalName string
		mimeType     *string
		category     string
		description  *string
		fileName     string
		filePath     string
		nodeName     *string
		templateInfo *string
	)

	err := s.db.QueryRow(ctx,
		`SELECT a.node_id, a.template_id, a.original_name, a.mime_type,
		        COALESCE(a.category,'other'), a.description, a.file_name, a.file_path,
		        fn.name,
		        CASE WHEN et.id IS NOT NULL THEN et.manufacturer || ' ' || et.model ELSE NULL END
		 FROM attachments a
		 LEFT JOIN factory_nodes fn ON fn.id = a.node_id
		 LEFT JOIN equipment_templates et ON et.id = COALESCE(a.template_id, fn.template_id)
		 WHERE a.id=$1 AND a.tenant_id=$2`,
		attachmentID, tenantID,
	).Scan(&nodeID, &templateID, &originalName, &mimeType, &category,
		&description, &fileName, &filePath, &nodeName, &templateInfo)
	if err != nil {
		return fmt.Errorf("attachment %d no encontrado: %w", attachmentID, err)
	}

	// Read the file from disk — try file_path first, then /tmp/fileName
	actualPath := filePath
	if _, err := os.Stat(actualPath); err != nil {
		actualPath = fmt.Sprintf("/tmp/%s", fileName)
	}
	raw, err := os.ReadFile(actualPath)
	if err != nil {
		return fmt.Errorf("no se pudo leer archivo %s: %w", filePath, err)
	}

	// Extract the text according to the type
	var content string
	mime := ""
	if mimeType != nil {
		mime = *mimeType
	}

	if strings.Contains(mime, "pdf") || strings.HasSuffix(strings.ToLower(originalName), ".pdf") {
		content = extractPDFText(raw)
	} else if strings.Contains(mime, "text") || strings.HasSuffix(strings.ToLower(originalName), ".txt") ||
		strings.HasSuffix(strings.ToLower(originalName), ".csv") || strings.HasSuffix(strings.ToLower(originalName), ".md") {
		if utf8.Valid(raw) {
			content = string(raw)
		}
	}

	// When no text could be extracted, index the metadata alone
	var textParts []string
	textParts = append(textParts, fmt.Sprintf("Documento: %s", originalName))
	textParts = append(textParts, fmt.Sprintf("Categoría: %s", categoryLabel(category)))
	if nodeName != nil {
		textParts = append(textParts, fmt.Sprintf("Equipo: %s", *nodeName))
	}
	if templateInfo != nil {
		textParts = append(textParts, fmt.Sprintf("Modelo de referencia: %s", *templateInfo))
	}
	if description != nil && *description != "" {
		textParts = append(textParts, fmt.Sprintf("Descripción: %s", *description))
	}
	if content != "" {
		// Clean up and truncate
		content = cleanExtractedText(content)
		if len(content) > 50000 {
			content = content[:50000]
		}
		textParts = append(textParts, fmt.Sprintf("Contenido del documento:\n%s", content))
	}

	fullText := strings.Join(textParts, "\n")
	if len(strings.TrimSpace(fullText)) < 20 {
		return nil // Nothing useful to index
	}

	chunks := chunkText(fullText, 400, 50)

	// Resolve template_id: from the attachment or from the node
	var effectiveTemplateID *int64
	if templateID != nil {
		effectiveTemplateID = templateID
	} else if nodeID != nil {
		var tid *int64
		s.db.QueryRow(ctx, `SELECT template_id FROM factory_nodes WHERE id=$1 AND tenant_id=$2`, *nodeID, tenantID).Scan(&tid)
		effectiveTemplateID = tid
	}

	for i, chunkText := range chunks {
		embedding, err := s.ollama.GenerateEmbedding(ctx, chunkText)
		if err != nil {
			return fmt.Errorf("error generando embedding attachment chunk %d: %w", i, err)
		}
		embStr := float32SliceToString(embedding)

		_, err = s.db.Exec(ctx,
			`INSERT INTO ai_embeddings
			 (tenant_id, node_id, template_id, source_type, source_id,
			  chunk_text, chunk_index, embedding, verification_status,
			  confidence_level, data_type)
			 VALUES ($1,$2,$3,'attachment',$4,$5,$6,$7::vector,'verified',3,$8)
			 ON CONFLICT (tenant_id, source_type, source_id, chunk_index)
			 DO UPDATE SET chunk_text=EXCLUDED.chunk_text, embedding=EXCLUDED.embedding,
			               node_id=EXCLUDED.node_id, template_id=EXCLUDED.template_id,
			               indexed_at=NOW()`,
			tenantID, nodeID, effectiveTemplateID, attachmentID,
			chunkText, i, embStr, attachmentDataType(category),
		)
		if err != nil {
			return fmt.Errorf("error guardando embedding attachment: %w", err)
		}
	}

	return nil
}

func categoryLabel(cat string) string {
	labels := map[string]string{
		"manual":     "Manual del fabricante",
		"procedure":  "Procedimiento",
		"datasheet":  "Ficha técnica",
		"diagram":    "Diagrama/Esquema",
		"report":     "Informe",
		"photo":      "Fotografía",
		"other":      "Documento",
	}
	if l, ok := labels[cat]; ok {
		return l
	}
	return cat
}

func attachmentDataType(category string) string {
	switch category {
	case "manual":
		return "manufacturer_manual"
	case "procedure":
		return "maintenance_procedure"
	case "datasheet":
		return "technical_datasheet"
	default:
		return "technical_document"
	}
}

func extractPDFText(data []byte) string {
	var buf bytes.Buffer
	scanner := bufio.NewScanner(bytes.NewReader(data))
	scanner.Buffer(make([]byte, 64*1024), 64*1024)
	inText := false
	for scanner.Scan() {
		line := scanner.Text()
		if strings.Contains(line, "BT") {
			inText = true
		}
		if strings.Contains(line, "ET") {
			inText = false
		}
		if inText && strings.Contains(line, "Tj") {
			start := strings.Index(line, "(")
			end := strings.LastIndex(line, ")")
			if start >= 0 && end > start {
				text := line[start+1 : end]
				text = strings.ReplaceAll(text, `\n`, "\n")
				text = strings.ReplaceAll(text, `\r`, " ")
				text = strings.ReplaceAll(text, `\t`, " ")
				buf.WriteString(text + " ")
			}
		}
	}
	if result := buf.String(); len(strings.TrimSpace(result)) > 0 {
		return result
	}
	// Fallback: readable ASCII text
	var fallback bytes.Buffer
	for i := 0; i < len(data)-3; i++ {
		if data[i] >= 32 && data[i] < 127 {
			fallback.WriteByte(data[i])
		} else if data[i] == '\n' || data[i] == '\r' {
			fallback.WriteByte('\n')
		}
	}
	return fallback.String()
}

func cleanExtractedText(s string) string {
	lines := strings.Split(s, "\n")
	var clean []string
	blank := 0
	for _, line := range lines {
		trimmed := strings.TrimSpace(line)
		if trimmed == "" {
			blank++
			if blank <= 2 {
				clean = append(clean, "")
			}
		} else {
			blank = 0
			clean = append(clean, trimmed)
		}
	}
	return strings.Join(clean, "\n")
}

// ─── Index every node of the tenant ───────────────────────────────────────

func (s *RAGService) IndexAllNodes(ctx context.Context, tenantID int64) (int, error) {
	rows, err := s.db.Query(ctx,
		`SELECT id FROM factory_nodes
		 WHERE tenant_id=$1 AND status != 'decommissioned'
		 ORDER BY id`,
		tenantID,
	)
	if err != nil {
		return 0, err
	}
	defer rows.Close()

	count := 0
	for rows.Next() {
		var nodeID int64
		if rows.Scan(&nodeID) == nil {
			if err := s.IndexNode(ctx, tenantID, nodeID); err == nil {
				count++
			}
		}
	}
	return count, nil
}

// ─── Delete the embeddings ──────────────────────────────────────────────────────

func (s *RAGService) DeleteEmbeddings(ctx context.Context, tenantID int64, sourceType string, sourceID int64) error {
	_, err := s.db.Exec(ctx,
		`DELETE FROM ai_embeddings
		 WHERE tenant_id=$1 AND source_type=$2 AND source_id=$3`,
		tenantID, sourceType, sourceID,
	)
	return err
}

// ─── Semantic search ───────────────────────────────────────────────────────

type SearchOptions struct {
	TenantID        int64
	NodeID          *int64
	TemplateID      *int64
	IncludeSiblings bool
	Limit           int
	MinSimilarity   float64
	Role            string
	UserID          int64
}

func (s *RAGService) Search(ctx context.Context, query string, opts SearchOptions) ([]RelevantChunk, error) {
	queryEmbedding, err := s.ollama.GenerateEmbedding(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("error generando embedding de consulta: %w", err)
	}

	embStr := float32SliceToString(queryEmbedding)

	limit := opts.Limit
	if limit == 0 {
		limit = 10
	}
	if opts.MinSimilarity == 0 {
		opts.MinSimilarity = 0.2
	}

	baseQuery := `
		SELECT ae.chunk_text, ae.source_type, ae.source_id,
		       ae.data_type, ae.node_id,
		       1 - (ae.embedding <=> $1::vector) AS similarity
		FROM ai_embeddings ae
		WHERE ae.tenant_id = $2
		  AND 1 - (ae.embedding <=> $1::vector) > $3`

	args := []interface{}{embStr, opts.TenantID, opts.MinSimilarity}
	argIdx := 4

	if opts.NodeID != nil {
		if opts.IncludeSiblings && opts.TemplateID != nil {
			// Search in: this node, sibling equipment (same template), or global chunks (node_id NULL)
			baseQuery += fmt.Sprintf(
				` AND (ae.node_id = $%d OR ae.template_id = $%d OR ae.node_id IS NULL)`,
				argIdx, argIdx+1,
			)
			args = append(args, *opts.NodeID, *opts.TemplateID)
			argIdx += 2
		} else {
			// This node or global chunks
			baseQuery += fmt.Sprintf(` AND (ae.node_id = $%d OR ae.node_id IS NULL)`, argIdx)
			args = append(args, *opts.NodeID)
			argIdx++
		}
	}

	// Filter by reachable nodes: admin, auditor and superadmin see everything.
	// Other roles only see chunks from nodes assigned through node_assignments + ltree,
	// OR global chunks (node_id IS NULL) such as spare parts and knowledge.
	if opts.UserID > 0 && opts.Role != "admin" && opts.Role != "auditor" {
		baseQuery += fmt.Sprintf(` AND (ae.node_id IS NULL OR ae.node_id IN (
			SELECT fn.id FROM factory_nodes fn
			JOIN node_assignments na ON na.tenant_id = fn.tenant_id
			JOIN factory_nodes assigned ON assigned.id = na.node_id AND assigned.tenant_id = fn.tenant_id
			WHERE na.user_id = $%d AND na.tenant_id = $%d
			  AND (fn.id = na.node_id OR fn.path <@ assigned.path)
		))`, argIdx, argIdx+1)
		args = append(args, opts.UserID, opts.TenantID)
		argIdx += 2
	}

	baseQuery += fmt.Sprintf(` ORDER BY similarity DESC LIMIT $%d`, argIdx)
	args = append(args, limit)

	rows, err := s.db.Query(ctx, baseQuery, args...)
	if err != nil {
		return nil, fmt.Errorf("error buscando en pgvector: %w", err)
	}
	defer rows.Close()

	var chunks []RelevantChunk
	for rows.Next() {
		var c RelevantChunk
		if err := rows.Scan(
			&c.ChunkText, &c.SourceType, &c.SourceID,
			&c.DataType, &c.NodeID, &c.Similarity,
		); err == nil {
			chunks = append(chunks, c)
		}
	}

	return chunks, nil
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

func chunkText(text string, chunkSize, overlap int) []string {
	words := strings.Fields(text)
	if len(words) == 0 {
		return nil
	}
	var chunks []string
	for i := 0; i < len(words); i += chunkSize - overlap {
		end := i + chunkSize
		if end > len(words) {
			end = len(words)
		}
		chunk := strings.Join(words[i:end], " ")
		if strings.TrimSpace(chunk) != "" {
			chunks = append(chunks, chunk)
		}
		if end == len(words) {
			break
		}
	}
	return chunks
}

func float32SliceToString(v []float32) string {
	if len(v) == 0 {
		return "[]"
	}
	parts := make([]string, len(v))
	for i, f := range v {
		parts[i] = fmt.Sprintf("%f", f)
	}
	return "[" + strings.Join(parts, ",") + "]"
}

func woTypeLabel(t string) string {
	labels := map[string]string{
		"corrective":  "Reparación correctiva",
		"preventive":  "Mantenimiento preventivo",
		"predictive":  "Intervención predictiva",
		"improvement": "Mejora",
		"inspection":  "Inspección",
	}
	if l, ok := labels[t]; ok {
		return l
	}
	return t
}

func nodeTypeLabel(t string) string {
	labels := map[string]string{
		"organization":      "Organización",
		"plant":             "Planta",
		"area":              "Área",
		"line":              "Línea",
		"equipment":         "Equipo",
		"component":         "Componente",
		"measurement_point": "Punto de Medición",
	}
	if l, ok := labels[t]; ok {
		return l
	}
	return t
}
