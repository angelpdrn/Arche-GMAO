package ai

import (
	"context"
	"fmt"
	"strings"

	"github.com/jackc/pgx/v5/pgxpool"
)

type PromptBuilder struct {
	db *pgxpool.Pool
}

func NewPromptBuilder(db *pgxpool.Pool) *PromptBuilder {
	return &PromptBuilder{db: db}
}

type CompositionInfo struct {
	Name    string
	Members []CompositionMember
}

type CompositionMember struct {
	NodeID       int64
	Name         string
	Role         string
	Manufacturer string
	Model        string
	RecentWOs    []string
}

type NodeContext struct {
	Name         string
	Code         string
	NodeType     string
	Criticality  string
	Status       string
	Manufacturer string
	Model        string
	SerialNumber string
	Description  string
	TemplateName string
	SiblingCount int
	RecentWOs    []string
	SpareParts   []string
	MaintPlans   []string
	Personnel    []string
	Compositions []CompositionInfo
}

// WebContext holds web search results that complement RAG.
type WebContext struct {
	Results []WebSearchResult
	Query   string
}

func (b *PromptBuilder) BuildSystemPrompt(role string, nodeCtx *NodeContext, chunks []RelevantChunk, webCtx *WebContext) string {
	var sb strings.Builder

	sb.WriteString(`Eres Arché IA, asistente tecnico experto en mantenimiento industrial integrado
en el sistema CMMS Arche GMAO. Tienes dos fuentes de conocimiento:

A) DATOS DEL SISTEMA — equipos registrados, OTs, inventario, planes, personal, metricas.
   Para estos datos, usa SOLO lo que aparezca en las secciones "CONTEXTO DEL SISTEMA" o
   "EQUIPO ACTIVO". Si no tienes un dato especifico del sistema, dilo.

B) CONOCIMIENTO TECNICO GENERAL — tu formacion como experto en electricidad, electronica,
   automatizacion (PLCs, VFDs, SCADA, HMI), mecanica, hidraulica, neumatica,
   instrumentacion, motores, bombas, compresores, rodamientos, y todo lo relacionado
   con mantenimiento industrial. Usa este conocimiento libremente para ayudar.

Si hay seccion "INFORMACION DE REFERENCIA (WEB)", usala para complementar.

═══════════════════════════════════════════
COMO DEBES ACTUAR:
═══════════════════════════════════════════

1. SE UTIL Y PROACTIVO: Tu objetivo es AYUDAR. No te limites a decir "no tengo datos".
   Si no hay datos del sistema, usa tu conocimiento tecnico. Siempre ofrece algo util.

2. DIAGNOSTICO BASADO EN HISTORIAL: Cuando te consulten sobre una averia:
   a) PRIMERO revisa el historial de OTs cerradas del equipo y de equipos identicos
      (misma plantilla). Busca averias similares, causas raiz ya identificadas y
      soluciones que funcionaron. Esta es tu fuente MAS VALIOSA.
   b) Si encuentras OTs anteriores relevantes, di: "Segun el historial, este equipo
      (o equipos del mismo modelo) ya tuvo un problema similar en [fecha]: [causa raiz].
      La solucion fue [solucion]. Esto podria aplicar aqui."
   c) Luego da tu evaluacion tecnica con las causas mas probables, priorizando
      las que ya ocurrieron en el historial.
   d) DECIDE si necesitas preguntar o si ya puedes responder:
     * Si la tarea es CLARA (ej: "cambiar presion de 10 a 8 bar", "reemplazar
       rodamiento", "ajustar tension de correa"): NO preguntes. Ve DIRECTO a dar
       instrucciones paso a paso. El usuario ya sabe que necesita.
     * Si la averia es AMBIGUA y necesitas mas informacion para dar un buen
       diagnostico, haz las preguntas que consideres necesarias — pocas o muchas,
       las que hagan falta para llegar a la causa raiz. Normalmente con una o dos
       preguntas bien hechas es suficiente para deducir la averia.
     * Siempre que preguntes, acompana la pregunta con una hipotesis inicial basada
       en el historial: "Dado que este equipo ya tuvo [problema X], podria ser eso.
       Para confirmarlo: ¿[pregunta]?"
   e) Con cada respuesta, refina el diagnostico usando PRIMERO el historial del equipo
      y equipos identicos, y LUEGO tu conocimiento tecnico general.
   f) Llega a una CONCLUSION con causa raiz probable y solucion paso a paso.
      La solucion debe ser tan detallada que CUALQUIER persona pueda seguirla:
      herramientas necesarias, pasos exactos, torques, presiones, verificaciones.

3. PLANTILLAS DE EQUIPO = MAQUINAS IDENTICAS: Los equipos que comparten la misma plantilla
   (Modelo de referencia) son EXACTAMENTE el mismo tipo de maquina — mismo fabricante,
   mismo modelo, mismas especificaciones, mismos repuestos, mismos procedimientos.
   Por tanto:
   - El historial de reparaciones de un equipo APLICA a todos los equipos de su misma plantilla
   - Los documentos tecnicos (manuales, fichas, procedimientos) de una plantilla aplican a
     TODOS los equipos vinculados a esa plantilla
   - Si un equipo X tuvo un problema Y con solucion Z, y el equipo W es del mismo modelo
     (misma plantilla), entonces Z es una solucion probable para W
   - Dos maquinas con nombres parecidos NO son iguales a menos que compartan la misma
     plantilla. No mezcles datos de maquinas diferentes

4. CONOCIMIENTO TECNICO LIBRE: Para preguntas sobre componentes genericos (VFDs, PLCs,
   motores, sensores, protocolos Modbus/Profinet, etc.), responde con tu conocimiento.
   No necesitas datos del sistema para explicar como funciona un variador de frecuencia
   o cuales son las fallas tipicas de un rodamiento.

5. COMPOSICIONES FUNCIONALES: Los equipos pueden estar agrupados en "composiciones"
   que representan un sistema funcional completo (ej. controlador + ventilador + sensor).
   Si un equipo pertenece a una composicion:
   - Revisa el historial de TODOS los componentes hermanos, no solo el consultado
   - La causa raiz de una averia puede estar en OTRO componente del sistema
   - Equipos del mismo modelo comercial (ej. STC 2050 de Sertic) son productos
     conocidos con documentacion publica — usa tu conocimiento sobre ellos
   - Si varias composiciones comparten la misma plantilla, son sistemas identicos
     con historiales individuales — los patrones de una aplican a las demas

6. NO INVENTES DATOS DEL SISTEMA: No inventes nombres de equipos, usuarios, OTs,
   numeros de stock ni datos que deberian venir de la base de datos. Distingue claramente
   entre "segun el historial del sistema..." y "en general, para este tipo de equipo...".

7. IDIOMA: Responde en espanol por defecto. Si el usuario te escribe en otro idioma
   o te pide explicitamente que respondas en otro idioma, responde en ese idioma.

8. FORMATO Y EXTENSION: Se claro y estructurado. Usa listas cuando ayude.
   - Para preguntas simples o de si/no: responde en 1-3 oraciones. No repitas la pregunta.
   - Para diagnosticos: se detallado pero sin repetir informacion. Llega al punto rapido.
   - Para procedimientos paso a paso: detalla cada paso pero no añadas introducciones
     ni conclusiones innecesarias. Ve directo a los pasos.
   - NUNCA rellenes con frases genericas ("espero que esta informacion te sea util",
     "no dudes en preguntar", "quedo a tu disposicion"). Termina cuando hayas respondido.
   - NO repitas informacion que ya dijiste en mensajes anteriores de la conversacion.
   - Si ya diste un diagnostico y el usuario confirma, da la solucion directamente
     sin repetir el diagnostico completo.
   PRIORIDAD: El historial de OTs y reparaciones del equipo (y equipos identicos)
   es tu fuente de informacion MAS IMPORTANTE. Siempre mencionalo antes que tu
   conocimiento general. Si el historial dice algo, eso pesa mas que la teoria.

`)

	// ─── Role restrictions ──────────────────────────────────────────────
	switch role {
	case "admin":
		sb.WriteString(`TU ROL: Administrador
Tienes acceso completo a toda la informacion del sistema.
Puedes informar sobre usuarios, costes, metricas, inventario, personal y cualquier dato.

`)
	case "supervisor":
		sb.WriteString(`TU ROL: Supervisor
Tienes acceso a la informacion de tus areas asignadas.
Puedes ver datos de personal, OTs, inventario (con precios), planes y metricas de tu zona.
NO reveles informacion de areas que no te corresponden si te lo piden.

`)
	case "technician", "operator":
		sb.WriteString(`TU ROL: Tecnico/Operario — RESTRICCIONES DE ACCESO:
- NO reveles informacion sobre otros usuarios (nombres, actividad, puntuaciones, horas de otros)
- NO menciones precios, costes ni informacion de proveedores de repuestos
- NO compartas metricas administrativas globales (MTBF, MTTR, OEE, costes)
- NO informes sobre personal asignado a equipos o areas (quien trabaja donde)
- Solo puedes hablar de equipos, OTs, repuestos (sin precio) y diagnostico tecnico
- Si preguntan por informacion administrativa o de otros usuarios, responde:
  "Esa informacion es de acceso restringido. Consulte con su supervisor."

`)
	case "warehouse":
		sb.WriteString(`TU ROL: Almacen — RESTRICCIONES DE ACCESO:
- Puedes informar sobre inventario: stock, precios, proveedores, movimientos, pedidos
- NO reveles informacion personal de tecnicos (actividad, puntuaciones, horas trabajadas)
- NO compartas detalles operativos de OTs (diagnosticos, causas raiz, soluciones)
- Si preguntan por informacion operativa o de personal, responde:
  "Esa informacion es de acceso restringido para su rol."

`)
	case "auditor":
		sb.WriteString(`TU ROL: Auditor — RESTRICCIONES DE ACCESO:
- Puedes informar sobre metricas, tendencias y datos agregados
- Puedes ver estado de equipos, OTs e inventario
- NO reveles informacion personal especifica de usuarios (horas, puntuaciones individuales)
- Presenta datos de forma resumida y anonima cuando sea posible

`)
	}

	// Context of the active node
	if nodeCtx != nil {
		sb.WriteString("═══════════════════════════════════════════\n")
		sb.WriteString("EQUIPO ACTIVO:\n")
		sb.WriteString("═══════════════════════════════════════════\n")
		sb.WriteString(fmt.Sprintf("Nombre: %s\n", nodeCtx.Name))
		if nodeCtx.Code != "" {
			sb.WriteString(fmt.Sprintf("Codigo: %s\n", nodeCtx.Code))
		}
		sb.WriteString(fmt.Sprintf("Tipo: %s\n", nodeCtx.NodeType))
		sb.WriteString(fmt.Sprintf("Criticidad: %s\n", nodeCtx.Criticality))
		sb.WriteString(fmt.Sprintf("Estado actual: %s\n", nodeCtx.Status))
		if nodeCtx.Manufacturer != "" {
			sb.WriteString(fmt.Sprintf("Fabricante: %s\n", nodeCtx.Manufacturer))
		}
		if nodeCtx.Model != "" {
			sb.WriteString(fmt.Sprintf("Modelo: %s\n", nodeCtx.Model))
		}
		if nodeCtx.SerialNumber != "" {
			sb.WriteString(fmt.Sprintf("N Serie: %s\n", nodeCtx.SerialNumber))
		}
		if nodeCtx.TemplateName != "" {
			sb.WriteString(fmt.Sprintf("Modelo de referencia: %s\n", nodeCtx.TemplateName))
			if nodeCtx.SiblingCount > 0 {
				sb.WriteString(fmt.Sprintf("Maquinas del mismo modelo en planta: %d\n", nodeCtx.SiblingCount))
			}
		}
		if nodeCtx.Description != "" {
			sb.WriteString(fmt.Sprintf("Descripcion: %s\n", nodeCtx.Description))
		}

		// Special instructions for commercial equipment (with a known manufacturer+model)
		mfr := nodeCtx.Manufacturer
		mdl := nodeCtx.Model
		if mfr == "" && nodeCtx.TemplateName != "" {
			// Use the template data
			parts := strings.SplitN(nodeCtx.TemplateName, " ", 2)
			if len(parts) == 2 {
				mfr = parts[0]
				mdl = parts[1]
			}
		}
		if mfr != "" && mdl != "" {
			sb.WriteString(fmt.Sprintf(`
EQUIPO COMERCIAL IDENTIFICADO: %s %s
Este es un equipo/producto comercial con documentacion publica del fabricante.
DEBES usar todo tu conocimiento sobre este modelo especifico:
- Especificaciones tecnicas y parametros tipicos del %s %s
- Problemas y averias comunes documentadas por el fabricante o la industria
- Procedimientos de mantenimiento recomendados por %s
- Codigos de error y alarmas especificos de este modelo
- Repuestos originales y compatibles habituales
- Intervalos de mantenimiento recomendados por el fabricante
- Precauciones de seguridad especificas del equipo
Combina este conocimiento del fabricante con el historial real de este equipo
en la planta (OTs, repuestos usados, intervenciones anteriores) para dar
respuestas completas y especificas.
`, mfr, mdl, mfr, mdl, mfr))
		}
		if len(nodeCtx.RecentWOs) > 0 {
			sb.WriteString("\n══ HISTORIAL DE INTERVENCIONES (PRIORIDAD MAXIMA PARA DIAGNOSTICO) ══\n")
			sb.WriteString("Usa este historial para identificar patrones, causas recurrentes y soluciones probadas:\n")
			for _, wo := range nodeCtx.RecentWOs {
				sb.WriteString(fmt.Sprintf("  - %s\n", wo))
			}
		}
		if len(nodeCtx.SpareParts) > 0 {
			sb.WriteString("\nRepuestos asociados:\n")
			for _, sp := range nodeCtx.SpareParts {
				sb.WriteString(fmt.Sprintf("  - %s\n", sp))
			}
		}
		if len(nodeCtx.MaintPlans) > 0 {
			sb.WriteString("\nPlanes de mantenimiento preventivo:\n")
			for _, mp := range nodeCtx.MaintPlans {
				sb.WriteString(fmt.Sprintf("  - %s\n", mp))
			}
		}
		if len(nodeCtx.Personnel) > 0 {
			sb.WriteString("\nPersonal asignado:\n")
			for _, p := range nodeCtx.Personnel {
				sb.WriteString(fmt.Sprintf("  - %s\n", p))
			}
		}

		// Functional compositions
		if len(nodeCtx.Compositions) > 0 {
			sb.WriteString("\n══ COMPOSICIONES FUNCIONALES (DIAGNOSTICO CRUZADO) ══\n")
			sb.WriteString("Este equipo forma parte de los siguientes sistemas funcionales.\n")
			sb.WriteString("Los componentes de un mismo sistema TRABAJAN JUNTOS — si uno falla,\n")
			sb.WriteString("la causa puede estar en otro componente del sistema.\n\n")
			for _, comp := range nodeCtx.Compositions {
				sb.WriteString(fmt.Sprintf("Sistema: %s\n", comp.Name))
				sb.WriteString("Componentes:\n")
				for _, m := range comp.Members {
					if m.NodeID == 0 {
						continue
					}
					role := m.Role
					if role == "" {
						role = "componente"
					}
					label := m.Name
					if m.Manufacturer != "" && m.Model != "" {
						label += fmt.Sprintf(" (%s %s)", m.Manufacturer, m.Model)
					}
					sb.WriteString(fmt.Sprintf("  - [%s] %s\n", role, label))
					for _, wo := range m.RecentWOs {
						sb.WriteString(fmt.Sprintf("      OT: %s\n", wo))
					}
				}
				sb.WriteString("\n")
			}
			sb.WriteString("IMPORTANTE: Al diagnosticar, correlaciona los historiales de TODOS los\n")
			sb.WriteString("componentes del sistema. La causa raiz puede estar en otro componente.\n\n")
		}

		sb.WriteString("\n")
	}

	// RAG chunks
	if len(chunks) > 0 {
		sb.WriteString("═══════════════════════════════════════════\n")
		sb.WriteString("CONTEXTO DEL SISTEMA:\n")
		sb.WriteString("═══════════════════════════════════════════\n\n")
		for i, chunk := range chunks {
			label := chunkSourceLabel(chunk.SourceType, chunk.DataType)
			sb.WriteString(fmt.Sprintf("[%s %d — relevancia %.0f%%]\n%s\n\n",
				label, i+1, chunk.Similarity*100, chunk.ChunkText))
		}
	} else {
		sb.WriteString("═══════════════════════════════════════════\n")
		sb.WriteString("CONTEXTO DEL SISTEMA: No se encontraron datos relevantes en la base de datos.\n")
		sb.WriteString("═══════════════════════════════════════════\n\n")
		sb.WriteString("Puedes usar tu conocimiento tecnico general para responder sobre componentes,\n")
		sb.WriteString("maquinaria o procedimientos de mantenimiento estandar.\n\n")
	}

	// Web search results
	if webCtx != nil && len(webCtx.Results) > 0 {
		sb.WriteString("═══════════════════════════════════════════\n")
		sb.WriteString("INFORMACION DE REFERENCIA (WEB):\n")
		sb.WriteString("═══════════════════════════════════════════\n\n")
		for i, r := range webCtx.Results {
			sb.WriteString(fmt.Sprintf("[Web %d] %s\n%s\nFuente: %s\n\n", i+1, r.Title, r.Snippet, r.URL))
		}
	}

	sb.WriteString("Recuerda: para datos del sistema usa SOLO el contexto proporcionado. Para conocimiento tecnico general, puedes usar tu formacion y las referencias web. Se directo y conciso — no rellenes con cortesias ni repitas lo ya dicho.")

	return sb.String()
}

func (b *PromptBuilder) GetNodeContext(ctx context.Context, nodeID, tenantID int64, role string) (*NodeContext, error) {
	nc := &NodeContext{}

	err := b.db.QueryRow(ctx,
		`SELECT fn.name, COALESCE(fn.code,''), fn.node_type, fn.criticality, fn.status,
		        COALESCE(fn.manufacturer,''), COALESCE(fn.model,''),
		        COALESCE(fn.serial_number,''), COALESCE(fn.description,''),
		        COALESCE(et.manufacturer || ' ' || et.model, '')
		 FROM factory_nodes fn
		 LEFT JOIN equipment_templates et ON et.id = fn.template_id
		 WHERE fn.id=$1 AND fn.tenant_id=$2`,
		nodeID, tenantID,
	).Scan(
		&nc.Name, &nc.Code, &nc.NodeType, &nc.Criticality, &nc.Status,
		&nc.Manufacturer, &nc.Model, &nc.SerialNumber, &nc.Description,
		&nc.TemplateName,
	)
	if err != nil {
		return nil, err
	}

	// Sibling machines
	b.db.QueryRow(ctx,
		`SELECT COUNT(*) FROM factory_nodes fn
		 JOIN factory_nodes src ON src.id=$1 AND src.template_id IS NOT NULL
		     AND fn.template_id=src.template_id AND fn.id!=$1 AND fn.tenant_id=$2`,
		nodeID, tenantID,
	).Scan(&nc.SiblingCount)

	// Latest WOs: this equipment + equipment on the SAME MODEL (template)
	// technicians do not see who did them, warehouse does not see operational detail
	if role != "warehouse" {
		// Work out whether it has a template, so siblings can be found
		var srcTemplateID *int64
		b.db.QueryRow(ctx, `SELECT template_id FROM factory_nodes WHERE id=$1 AND tenant_id=$2 AND template_id IS NOT NULL`, nodeID, tenantID).Scan(&srcTemplateID)

		var woQuery string
		switch role {
		case "technician", "operator":
			if srcTemplateID != nil {
				woQuery = `SELECT
				  CASE WHEN wo.node_id = $1 THEN '' ELSE '[Mismo modelo: ' || fn.name || '] ' END ||
				  wo.wo_type || ': ' || wo.title || ' [' || wo.status || ']' ||
				  COALESCE(' — Horas: ' || wo.actual_hours::text, '') ||
				  COALESCE(' — Causa: ' || wo.root_cause, '') ||
				  COALESCE(' — Solucion: ' || wo.solution, '') ||
				  ' (' || TO_CHAR(wo.created_at, 'DD/MM/YYYY') || ')'
				 FROM work_orders wo
				 JOIN factory_nodes fn ON fn.id = wo.node_id
				 WHERE wo.tenant_id=$2 AND fn.template_id = $3
				 ORDER BY (wo.node_id = $1) DESC, wo.created_at DESC LIMIT 10`
			} else {
				woQuery = `SELECT wo.wo_type || ': ' || wo.title || ' [' || wo.status || ']' ||
				  COALESCE(' — Horas: ' || wo.actual_hours::text, '') ||
				  COALESCE(' — Causa: ' || wo.root_cause, '') ||
				  COALESCE(' — Solucion: ' || wo.solution, '') ||
				  ' (' || TO_CHAR(wo.created_at, 'DD/MM/YYYY') || ')'
				 FROM work_orders wo
				 JOIN factory_nodes fn ON fn.id = wo.node_id
				 WHERE wo.node_id=$1 AND wo.tenant_id=$2
				 ORDER BY wo.created_at DESC LIMIT 10`
			}
		default:
			if srcTemplateID != nil {
				woQuery = `SELECT
				  CASE WHEN wo.node_id = $1 THEN '' ELSE '[Mismo modelo: ' || fn.name || '] ' END ||
				  wo.wo_type || ': ' || wo.title || ' [' || wo.status || ']' ||
				  COALESCE(' — Tecnico: ' || u.full_name, '') ||
				  COALESCE(' — Horas: ' || wo.actual_hours::text, '') ||
				  COALESCE(' — Causa: ' || wo.root_cause, '') ||
				  COALESCE(' — Solucion: ' || wo.solution, '') ||
				  ' (' || TO_CHAR(wo.created_at, 'DD/MM/YYYY') || ')'
				 FROM work_orders wo
				 JOIN factory_nodes fn ON fn.id = wo.node_id
				 LEFT JOIN users u ON u.id = wo.assigned_to
				 WHERE wo.tenant_id=$2 AND fn.template_id = $3
				 ORDER BY (wo.node_id = $1) DESC, wo.created_at DESC LIMIT 10`
			} else {
				woQuery = `SELECT wo.wo_type || ': ' || wo.title || ' [' || wo.status || ']' ||
				  COALESCE(' — Tecnico: ' || u.full_name, '') ||
				  COALESCE(' — Horas: ' || wo.actual_hours::text, '') ||
				  COALESCE(' — Causa: ' || wo.root_cause, '') ||
				  COALESCE(' — Solucion: ' || wo.solution, '') ||
				  ' (' || TO_CHAR(wo.created_at, 'DD/MM/YYYY') || ')'
				 FROM work_orders wo
				 JOIN factory_nodes fn ON fn.id = wo.node_id
				 LEFT JOIN users u ON u.id = wo.assigned_to
				 WHERE wo.node_id=$1 AND wo.tenant_id=$2
				 ORDER BY wo.created_at DESC LIMIT 10`
			}
		}

		var woRows interface{ Next() bool; Scan(...interface{}) error; Close() }
		if srcTemplateID != nil {
			woRows, _ = b.db.Query(ctx, woQuery, nodeID, tenantID, *srcTemplateID)
		} else {
			woRows, _ = b.db.Query(ctx, woQuery, nodeID, tenantID)
		}
		if woRows != nil {
			defer woRows.Close()
			for woRows.Next() {
				var s string
				if woRows.Scan(&s) == nil {
					nc.RecentWOs = append(nc.RecentWOs, s)
				}
			}
		}
	}

	// Spare parts — technicians/operators get no prices or suppliers
	var spQuery string
	switch role {
	case "technician", "operator":
		spQuery = `SELECT sp.name || ' (' || sp.code || ') — stock: ' || sp.current_stock || '/' || sp.min_stock || ' ' || sp.unit ||
		        CASE WHEN sp.current_stock <= sp.min_stock THEN ' [STOCK BAJO]' ELSE '' END
		 FROM spare_parts sp
		 JOIN spare_part_nodes spn ON spn.spare_part_id=sp.id AND spn.node_id=$1
		 WHERE sp.tenant_id=$2
		 ORDER BY sp.name`
	default:
		spQuery = `SELECT sp.name || ' (' || sp.code || ') — stock: ' || sp.current_stock || '/' || sp.min_stock || ' ' || sp.unit ||
		        CASE WHEN sp.current_stock <= sp.min_stock THEN ' [STOCK BAJO]' ELSE '' END ||
		        COALESCE(' — Proveedor: ' || sp.supplier, '') ||
		        COALESCE(' — Precio: ' || sp.unit_price::text || ' EUR', '')
		 FROM spare_parts sp
		 JOIN spare_part_nodes spn ON spn.spare_part_id=sp.id AND spn.node_id=$1
		 WHERE sp.tenant_id=$2
		 ORDER BY sp.name`
	}
	spRows, _ := b.db.Query(ctx, spQuery, nodeID, tenantID)
	if spRows != nil {
		defer spRows.Close()
		for spRows.Next() {
			var s string
			if spRows.Scan(&s) == nil {
				nc.SpareParts = append(nc.SpareParts, s)
			}
		}
	}

	// Active maintenance plans (max 10, with execution history)
	mpRows, _ := b.db.Query(ctx,
		`SELECT mp.title || ' (' || mp.frequency_value || ' ' || mp.frequency_type || ')' ||
		        COALESCE(' — Proxima: ' || TO_CHAR(mp.next_due_at, 'DD/MM/YYYY'), '') ||
		        COALESCE(' — Ultima ejecucion: ' || TO_CHAR(mpe.executed_at, 'DD/MM/YYYY'), ' — Sin ejecuciones')
		 FROM maintenance_plans mp
		 LEFT JOIN LATERAL (
		   SELECT executed_at FROM maintenance_plan_executions
		   WHERE plan_id = mp.id ORDER BY executed_at DESC LIMIT 1
		 ) mpe ON true
		 WHERE mp.node_id=$1 AND mp.tenant_id=$2 AND mp.is_active=true
		 ORDER BY mp.next_due_at ASC NULLS LAST LIMIT 10`,
		nodeID, tenantID,
	)
	if mpRows != nil {
		defer mpRows.Close()
		for mpRows.Next() {
			var s string
			if mpRows.Scan(&s) == nil {
				nc.MaintPlans = append(nc.MaintPlans, s)
			}
		}
	}

	// ─── Functional compositions ──────────────────────────────────────
	// When the node IS a composition, load its own linked composition
	// When the node is an equipment item, look for compositions it belongs to
	compRows, _ := b.db.Query(ctx,
		`SELECT ec.id, ec.name
		 FROM equipment_compositions ec
		 LEFT JOIN equipment_composition_members ecm ON ecm.composition_id = ec.id AND ecm.node_id = $1
		 WHERE ec.tenant_id = $2
		   AND (ecm.node_id IS NOT NULL OR ec.node_id = $1)
		 ORDER BY ec.name`,
		nodeID, tenantID)
	if compRows != nil {
		defer compRows.Close()
		for compRows.Next() {
			var cID int64
			var cName string
			if compRows.Scan(&cID, &cName) != nil {
				continue
			}
			ci := CompositionInfo{Name: cName}

			// Get the members of this composition (histories included)
			mRows, _ := b.db.Query(ctx,
				`SELECT ecm.node_id, fn.name, COALESCE(ecm.role, ''),
				        COALESCE(fn.manufacturer, et.manufacturer, ''),
				        COALESCE(fn.model, et.model, '')
				 FROM equipment_composition_members ecm
				 JOIN factory_nodes fn ON fn.id = ecm.node_id
				 LEFT JOIN equipment_templates et ON et.id = fn.template_id
				 WHERE ecm.composition_id = $1
				 ORDER BY ecm.role, fn.name`,
				cID)
			if mRows != nil {
				for mRows.Next() {
					var m CompositionMember
					if mRows.Scan(&m.NodeID, &m.Name, &m.Role, &m.Manufacturer, &m.Model) != nil {
						continue
					}
					// Only load WOs from sibling components (not from the current node, already loaded above)
					if m.NodeID != nodeID {
						woRows2, _ := b.db.Query(ctx,
							`SELECT wo.wo_type || ': ' || wo.title || ' [' || wo.status || ']' ||
							        COALESCE(' — Causa: ' || wo.root_cause, '') ||
							        COALESCE(' — Solucion: ' || wo.solution, '') ||
							        ' (' || TO_CHAR(wo.created_at, 'DD/MM/YYYY') || ')'
							 FROM work_orders wo
							 WHERE wo.node_id = $1 AND wo.tenant_id = $2
							 ORDER BY wo.created_at DESC LIMIT 5`,
							m.NodeID, tenantID)
						if woRows2 != nil {
							for woRows2.Next() {
								var s string
								if woRows2.Scan(&s) == nil {
									m.RecentWOs = append(m.RecentWOs, s)
								}
							}
							woRows2.Close()
						}
					}
					ci.Members = append(ci.Members, m)
				}
				mRows.Close()
			}
			nc.Compositions = append(nc.Compositions, ci)
		}
	}

	// Staff assigned to the node — admin, supervisor and auditor only
	if role == "admin" || role == "supervisor" || role == "auditor" {
		pRows, _ := b.db.Query(ctx,
			`SELECT u.full_name || ' (' || u.role || ')' ||
			        CASE WHEN na.is_primary THEN ' [Principal]' ELSE '' END
			 FROM node_assignments na
			 JOIN users u ON u.id = na.user_id AND u.tenant_id = $2
			 WHERE na.node_id=$1 AND na.tenant_id=$2
			 ORDER BY na.is_primary DESC, u.full_name`,
			nodeID, tenantID,
		)
		if pRows != nil {
			defer pRows.Close()
			for pRows.Next() {
				var s string
				if pRows.Scan(&s) == nil {
					nc.Personnel = append(nc.Personnel, s)
				}
			}
		}
	}

	return nc, nil
}

func chunkSourceLabel(sourceType, dataType string) string {
	switch sourceType {
	case "work_order":
		return "Historial de reparacion"
	case "spare_part":
		return "Inventario de repuestos"
	case "maintenance_plan":
		return "Plan de mantenimiento"
	case "attachment":
		switch dataType {
		case "manual", "manufacturer_manual":
			return "Manual del fabricante"
		case "procedure", "maintenance_procedure":
			return "Procedimiento"
		case "datasheet", "technical_datasheet":
			return "Ficha tecnica"
		default:
			return "Documento tecnico"
		}
	case "node_info":
		return "Ficha del equipo"
	case "maintenance_manual":
		return "Manual de mantenimiento"
	case "knowledge":
		return "Base de conocimiento"
	default:
		return "Referencia"
	}
}
