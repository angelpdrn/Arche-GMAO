package ai

import (
	"context"
	"crypto/md5"
	"encoding/json"
	"fmt"
	"log"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
)

// PatternDetector analyses the plant data and detects risk patterns.
type PatternDetector struct {
	db *pgxpool.Pool
}

func NewPatternDetector(db *pgxpool.Pool) *PatternDetector {
	return &PatternDetector{db: db}
}

// RunDetection runs every detector for a tenant.
func (d *PatternDetector) RunDetection(ctx context.Context, tenantID int64) (int, error) {
	total := 0

	n, err := d.detectRecurringFailures(ctx, tenantID)
	if err != nil {
		log.Printf("[ARCHE-AI] Error detectando fallos recurrentes: %v", err)
	} else {
		total += n
	}

	n, err = d.detectLowStockRisk(ctx, tenantID)
	if err != nil {
		log.Printf("[ARCHE-AI] Error detectando riesgo de stock: %v", err)
	} else {
		total += n
	}

	n, err = d.detectHighFrequency(ctx, tenantID)
	if err != nil {
		log.Printf("[ARCHE-AI] Error detectando alta frecuencia: %v", err)
	} else {
		total += n
	}

	n, err = d.detectOverduePreventive(ctx, tenantID)
	if err != nil {
		log.Printf("[ARCHE-AI] Error detectando preventivas vencidas: %v", err)
	} else {
		total += n
	}

	return total, nil
}

// ─── Detector 1: Recurring failures (same cause on the same equipment ≥3 times) ───

func (d *PatternDetector) detectRecurringFailures(ctx context.Context, tenantID int64) (int, error) {
	rows, err := d.db.Query(ctx, `
		SELECT
			wo.node_id,
			fn.name AS node_name,
			COUNT(*) AS failure_count,
			STRING_AGG(DISTINCT wo.root_cause, ' | ' ORDER BY wo.root_cause) AS causes,
			MAX(wo.completed_at) AS last_occurrence
		FROM work_orders wo
		JOIN factory_nodes fn ON fn.id = wo.node_id
		WHERE wo.tenant_id = $1
		  AND wo.wo_type = 'corrective'
		  AND wo.status IN ('completed', 'verified', 'closed')
		  AND wo.root_cause IS NOT NULL
		  AND wo.completed_at > NOW() - INTERVAL '90 days'
		GROUP BY wo.node_id, fn.name
		HAVING COUNT(*) >= 3
		ORDER BY failure_count DESC
	`, tenantID)
	if err != nil {
		return 0, err
	}
	defer rows.Close()

	count := 0
	for rows.Next() {
		var nodeID int64
		var nodeName string
		var failureCount int
		var causes string
		var lastOccurrence time.Time

		if err := rows.Scan(&nodeID, &nodeName, &failureCount, &causes, &lastOccurrence); err != nil {
			continue
		}

		patternData, _ := json.Marshal(map[string]interface{}{
			"failure_count":   failureCount,
			"causes":          causes,
			"last_occurrence": lastOccurrence,
			"period_days":     90,
		})

		severity := "medium"
		if failureCount >= 5 {
			severity = "critical"
		} else if failureCount >= 4 {
			severity = "high"
		}

		period := time.Now().Format("2006-01")
		hash := fmt.Sprintf("%x", md5.Sum([]byte(fmt.Sprintf("recurring_%d_%d_%s", nodeID, failureCount, period))))

		if _, err := d.db.Exec(ctx, `
			INSERT INTO ai_patterns
			(tenant_id, node_id, pattern_type, severity, title, description,
			 recommendation, pattern_data, pattern_hash, valid_until)
			VALUES ($1,$2,'recurring_failure',$3,$4,$5,$6,$7,$8, NOW() + INTERVAL '30 days')
			ON CONFLICT (tenant_id, node_id, pattern_type, pattern_hash) DO UPDATE
			SET detected_at=NOW(), pattern_data=EXCLUDED.pattern_data,
			    valid_until=NOW() + INTERVAL '30 days'
		`,
			tenantID, nodeID, severity,
			fmt.Sprintf("Fallo recurrente: %s (%d averías en 90 días)", nodeName, failureCount),
			fmt.Sprintf("El equipo %s ha tenido %d averías correctivas en los últimos 90 días. Causas: %s",
				nodeName, failureCount, causes),
			"Revisar plan de mantenimiento preventivo. Considerar inspección profunda o sustitución de componentes críticos.",
			patternData, hash,
		); err != nil {
			log.Printf("[ARCHE-PATTERNS] Error insertando patrón recurring_failure: %v", err)
			continue
		}
		count++
	}
	return count, nil
}

// ─── Detector 2: Low stock risk + an upcoming preventive WO ────────────────

func (d *PatternDetector) detectLowStockRisk(ctx context.Context, tenantID int64) (int, error) {
	rows, err := d.db.Query(ctx, `
		SELECT
			sp.id AS spare_part_id,
			sp.name AS spare_name,
			sp.code AS spare_code,
			sp.current_stock,
			sp.min_stock,
			sp.unit,
			fn.id AS node_id,
			fn.name AS node_name,
			wo.wo_number,
			wo.planned_start
		FROM spare_parts sp
		JOIN spare_part_nodes spn ON spn.spare_part_id = sp.id
		JOIN factory_nodes fn ON fn.id = spn.node_id AND fn.tenant_id = $1
		JOIN factory_nodes wo_node ON wo_node.path <@ fn.path AND wo_node.tenant_id = $1
		JOIN work_orders wo ON wo.node_id = wo_node.id AND wo.tenant_id = $1
		WHERE sp.tenant_id = $1
		  AND sp.current_stock <= sp.min_stock
		  AND wo.wo_type = 'preventive'
		  AND wo.status IN ('assigned', 'approved')
		  AND wo.planned_start BETWEEN NOW() AND NOW() + INTERVAL '14 days'
	`, tenantID)
	if err != nil {
		return 0, err
	}
	defer rows.Close()

	count := 0
	for rows.Next() {
		var spareID, nodeID int64
		var spareName, spareCode, unit, nodeName, woNumber string
		var currentStock, minStock float64
		var plannedStart time.Time

		if err := rows.Scan(&spareID, &spareName, &spareCode, &currentStock, &minStock,
			&unit, &nodeID, &nodeName, &woNumber, &plannedStart); err != nil {
			continue
		}

		patternData, _ := json.Marshal(map[string]interface{}{
			"spare_part_id":   spareID,
			"spare_name":      spareName,
			"spare_code":      spareCode,
			"current_stock":   currentStock,
			"min_stock":       minStock,
			"wo_number":       woNumber,
			"planned_start":   plannedStart,
		})

		period := time.Now().Format("2006-01")
		hash := fmt.Sprintf("%x", md5.Sum([]byte(fmt.Sprintf("lowstock_%d_%d_%s", spareID, nodeID, period))))

		if _, err := d.db.Exec(ctx, `
			INSERT INTO ai_patterns
			(tenant_id, node_id, pattern_type, severity, title, description,
			 recommendation, pattern_data, pattern_hash, valid_until)
			VALUES ($1,$2,'low_stock_risk','high',$3,$4,$5,$6,$7, $8)
			ON CONFLICT (tenant_id, node_id, pattern_type, pattern_hash) DO UPDATE
			SET detected_at=NOW(), valid_until=EXCLUDED.valid_until
		`,
			tenantID, nodeID,
			fmt.Sprintf("Stock bajo antes de mantenimiento: %s", spareName),
			fmt.Sprintf("El repuesto '%s' (%s) tiene stock de %.1f %s (mínimo: %.1f). "+
				"Hay una OT preventiva %s programada para %s.",
				spareName, spareCode, currentStock, unit, minStock,
				woNumber, plannedStart.Format("02/01/2006")),
			fmt.Sprintf("Solicitar reposición urgente de '%s'. Stock actual insuficiente para la OT %s.",
				spareName, woNumber),
			patternData, hash,
			plannedStart.Add(24*time.Hour),
		); err != nil {
			log.Printf("[ARCHE-PATTERNS] Error insertando patrón low_stock_risk: %v", err)
			continue
		}
		count++
	}
	return count, nil
}

// ─── Detector 3: High WO frequency (>2 in 30 days) ─────────────────────

func (d *PatternDetector) detectHighFrequency(ctx context.Context, tenantID int64) (int, error) {
	rows, err := d.db.Query(ctx, `
		SELECT
			wo.node_id,
			fn.name AS node_name,
			fn.criticality,
			COUNT(*) AS wo_count
		FROM work_orders wo
		JOIN factory_nodes fn ON fn.id = wo.node_id
		WHERE wo.tenant_id = $1
		  AND wo.created_at > NOW() - INTERVAL '30 days'
		  AND wo.wo_type = 'corrective'
		GROUP BY wo.node_id, fn.name, fn.criticality
		HAVING COUNT(*) > 2
	`, tenantID)
	if err != nil {
		return 0, err
	}
	defer rows.Close()

	count := 0
	for rows.Next() {
		var nodeID int64
		var nodeName, criticality string
		var woCount int

		if err := rows.Scan(&nodeID, &nodeName, &criticality, &woCount); err != nil {
			continue
		}

		severity := "medium"
		if criticality == "critical" {
			severity = "critical"
		} else if criticality == "high" {
			severity = "high"
		}

		patternData, _ := json.Marshal(map[string]interface{}{
			"wo_count": woCount, "period_days": 30,
		})
		period := time.Now().Format("2006-01")
		hash := fmt.Sprintf("%x", md5.Sum([]byte(fmt.Sprintf("highfreq_%d_%d_%s", nodeID, woCount, period))))

		if _, err := d.db.Exec(ctx, `
			INSERT INTO ai_patterns
			(tenant_id, node_id, pattern_type, severity, title, description,
			 recommendation, pattern_data, pattern_hash, valid_until)
			VALUES ($1,$2,'high_frequency',$3,$4,$5,$6,$7,$8, NOW() + INTERVAL '15 days')
			ON CONFLICT (tenant_id, node_id, pattern_type, pattern_hash) DO UPDATE
			SET detected_at=NOW(), valid_until=NOW() + INTERVAL '15 days'
		`,
			tenantID, nodeID, severity,
			fmt.Sprintf("Alta frecuencia de averías: %s (%d OTs en 30 días)", nodeName, woCount),
			fmt.Sprintf("El equipo %s ha generado %d órdenes correctivas en los últimos 30 días, lo que indica degradación acelerada.",
				nodeName, woCount),
			"Programar inspección completa. Evaluar sustitución de componentes o revisión del proceso de operación.",
			patternData, hash,
		); err != nil {
			log.Printf("[ARCHE-PATTERNS] Error insertando patrón high_frequency: %v", err)
			continue
		}
		count++
	}
	return count, nil
}

// ─── Detector 4: Overdue preventive work ────────────────────────────────────────

func (d *PatternDetector) detectOverduePreventive(ctx context.Context, tenantID int64) (int, error) {
	rows, err := d.db.Query(ctx, `
		SELECT
			wo.id AS wo_id,
			wo.wo_number,
			wo.node_id,
			fn.name AS node_name,
			fn.criticality,
			wo.planned_end,
			EXTRACT(DAY FROM NOW() - wo.planned_end)::INT AS days_overdue
		FROM work_orders wo
		JOIN factory_nodes fn ON fn.id = wo.node_id
		WHERE wo.tenant_id = $1
		  AND wo.wo_type = 'preventive'
		  AND wo.status IN ('assigned', 'approved', 'in_progress')
		  AND wo.planned_end < NOW()
		  AND wo.planned_end IS NOT NULL
	`, tenantID)
	if err != nil {
		return 0, err
	}
	defer rows.Close()

	count := 0
	for rows.Next() {
		var woID, nodeID int64
		var woNumber, nodeName, criticality string
		var plannedEnd time.Time
		var daysOverdue int

		if err := rows.Scan(&woID, &woNumber, &nodeID, &nodeName,
			&criticality, &plannedEnd, &daysOverdue); err != nil {
			continue
		}

		severity := "medium"
		if daysOverdue > 14 && criticality == "critical" {
			severity = "critical"
		} else if daysOverdue > 7 {
			severity = "high"
		}

		patternData, _ := json.Marshal(map[string]interface{}{
			"wo_number": woNumber, "days_overdue": daysOverdue,
		})
		period := time.Now().Format("2006-01")
		hash := fmt.Sprintf("%x", md5.Sum([]byte(fmt.Sprintf("overdue_%d_%s", woID, period))))

		if _, err := d.db.Exec(ctx, `
			INSERT INTO ai_patterns
			(tenant_id, node_id, pattern_type, severity, title, description,
			 recommendation, pattern_data, pattern_hash, valid_until)
			VALUES ($1,$2,'overdue_preventive',$3,$4,$5,$6,$7,$8, NOW() + INTERVAL '7 days')
			ON CONFLICT (tenant_id, node_id, pattern_type, pattern_hash) DO UPDATE
			SET detected_at=NOW(), valid_until=NOW() + INTERVAL '7 days'
		`,
			tenantID, nodeID, severity,
			fmt.Sprintf("Preventiva vencida: %s (%d días de retraso)", woNumber, daysOverdue),
			fmt.Sprintf("La OT preventiva %s del equipo %s lleva %d días de retraso (fecha planificada: %s).",
				woNumber, nodeName, daysOverdue, plannedEnd.Format("02/01/2006")),
			"Reasignar y completar urgentemente. El retraso en preventivas aumenta el riesgo de avería correctiva.",
			patternData, hash,
		); err != nil {
			log.Printf("[ARCHE-PATTERNS] Error insertando patrón overdue_preventive: %v", err)
			continue
		}
		count++
	}
	return count, nil
}
