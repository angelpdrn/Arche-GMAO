package ai

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"time"
)

// WebSearchResult is a single web search result.
type WebSearchResult struct {
	Title   string
	Snippet string
	URL     string
}

// WebSearcher looks up technical information on the internet to complement the local RAG.
type WebSearcher struct {
	client *http.Client
}

func NewWebSearcher() *WebSearcher {
	return &WebSearcher{
		client: &http.Client{Timeout: 8 * time.Second},
	}
}

// Search queries DuckDuckGo HTML and extracts the relevant results.
// It returns up to maxResults snippets.
func (ws *WebSearcher) Search(ctx context.Context, query string, maxResults int) ([]WebSearchResult, error) {
	if maxResults <= 0 {
		maxResults = 5
	}

	// Add technical/industrial context to the search
	searchQuery := query + " mantenimiento industrial"

	reqURL := fmt.Sprintf("https://html.duckduckgo.com/html/?q=%s", url.QueryEscape(searchQuery))
	req, err := http.NewRequestWithContext(ctx, "GET", reqURL, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", "Mozilla/5.0 (compatible; ArcheGMAO/1.8; CMMS)")

	resp, err := ws.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("error buscando en web: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("búsqueda web devolvió status %d", resp.StatusCode)
	}

	body, err := io.ReadAll(io.LimitReader(resp.Body, 512*1024)) // Max 512KB
	if err != nil {
		return nil, err
	}

	return parseSearchResults(string(body), maxResults), nil
}

// parseSearchResults extracts the results from DuckDuckGo's HTML.
func parseSearchResults(html string, maxResults int) []WebSearchResult {
	var results []WebSearchResult

	// Pattern for DuckDuckGo HTML results
	// Every result carries class="result" with a link and a snippet
	resultBlocks := splitByResult(html)

	for _, block := range resultBlocks {
		if len(results) >= maxResults {
			break
		}

		title := extractBetween(block, `class="result__a"`, "</a>")
		snippet := extractBetween(block, `class="result__snippet"`, "</a>")
		if snippet == "" {
			snippet = extractBetween(block, `class="result__snippet"`, "</td>")
		}
		link := extractHref(block, `class="result__a"`)

		title = cleanHTML(title)
		snippet = cleanHTML(snippet)

		if title == "" || snippet == "" {
			continue
		}

		// Filter out low quality results
		if len(snippet) < 30 {
			continue
		}

		results = append(results, WebSearchResult{
			Title:   title,
			Snippet: snippet,
			URL:     link,
		})
	}

	return results
}

func splitByResult(html string) []string {
	parts := strings.Split(html, `class="result `)
	if len(parts) <= 1 {
		// Try the alternative format
		parts = strings.Split(html, `class="web-result"`)
	}
	if len(parts) > 1 {
		return parts[1:] // Skip whatever comes before the first result
	}
	return nil
}

func extractBetween(s, startMarker, endMarker string) string {
	idx := strings.Index(s, startMarker)
	if idx < 0 {
		return ""
	}
	// Find the closing of the tag holding the startMarker
	tagClose := strings.Index(s[idx:], ">")
	if tagClose < 0 {
		return ""
	}
	start := idx + tagClose + 1
	end := strings.Index(s[start:], endMarker)
	if end < 0 {
		return ""
	}
	return s[start : start+end]
}

func extractHref(s, marker string) string {
	idx := strings.Index(s, marker)
	if idx < 0 {
		return ""
	}
	// Find href= before the marker (inside the same <a> tag)
	before := s[:idx]
	lastA := strings.LastIndex(before, "<a ")
	if lastA < 0 {
		lastA = strings.LastIndex(before, "<A ")
	}
	if lastA < 0 {
		return ""
	}
	aTag := s[lastA:idx]
	hrefIdx := strings.Index(aTag, `href="`)
	if hrefIdx < 0 {
		return ""
	}
	start := hrefIdx + 6
	end := strings.Index(aTag[start:], `"`)
	if end < 0 {
		return ""
	}
	rawURL := aTag[start : start+end]

	// DuckDuckGo uses a redirect — extract the real URL when possible
	if strings.Contains(rawURL, "uddg=") {
		parts := strings.SplitN(rawURL, "uddg=", 2)
		if len(parts) == 2 {
			decoded, err := url.QueryUnescape(parts[1])
			if err == nil {
				// Cut at the first & when there are more params
				if ampIdx := strings.Index(decoded, "&"); ampIdx > 0 {
					decoded = decoded[:ampIdx]
				}
				return decoded
			}
		}
	}

	return rawURL
}

var htmlTagRe = regexp.MustCompile(`<[^>]+>`)
var multiSpaceRe = regexp.MustCompile(`\s+`)

func cleanHTML(s string) string {
	s = strings.ReplaceAll(s, "&amp;", "&")
	s = strings.ReplaceAll(s, "&lt;", "<")
	s = strings.ReplaceAll(s, "&gt;", ">")
	s = strings.ReplaceAll(s, "&quot;", `"`)
	s = strings.ReplaceAll(s, "&#x27;", "'")
	s = strings.ReplaceAll(s, "&nbsp;", " ")
	s = htmlTagRe.ReplaceAllString(s, "")
	s = multiSpaceRe.ReplaceAllString(s, " ")
	return strings.TrimSpace(s)
}

// ShouldSearchWeb decides whether the query would benefit from a web search.
// It returns true when the query looks like generic technical knowledge
// and there are not enough local RAG results.
func ShouldSearchWeb(query string, ragResultCount int) bool {
	// When we already have good RAG results, skip the web search
	if ragResultCount >= 3 {
		return false
	}

	q := strings.ToLower(query)

	// Keywords that point to generic technical knowledge
	genericKeywords := []string{
		"que es", "qué es", "como funciona", "cómo funciona",
		"para que sirve", "para qué sirve", "como se", "cómo se",
		"tipos de", "diferencia entre", "ventajas de", "desventajas",
		"como instalar", "cómo instalar", "como configurar", "cómo configurar",
		"como reparar", "cómo reparar", "como cambiar", "cómo cambiar",
		"falla comun", "falla común", "fallas comunes", "averia tipica", "avería típica",
		"causa de", "causas de", "sintomas de", "síntomas de",
		"principio de funcionamiento", "diagrama", "esquema",
		"manual de", "especificaciones", "ficha tecnica", "ficha técnica",
		"vida util", "vida útil", "mantenimiento de",
		"por que falla", "por qué falla", "codigo de error", "código de error",
		"alarma", "parametros", "parámetros", "calibrar", "calibración",
		"what is", "how to", "how does", "troubleshoot",
	}

	for _, kw := range genericKeywords {
		if strings.Contains(q, kw) {
			return true
		}
	}

	// Generic industrial components — when mentioned without a specific equipment context
	genericComponents := []string{
		"vfd", "variador de frecuencia", "plc", "hmi", "scada",
		"contactor", "rele", "relé", "relay", "fusible", "disyuntor",
		"motor electrico", "motor eléctrico", "servomotor", "encoder",
		"sensor", "termocupla", "termopar", "pt100", "rtd",
		"valvula", "válvula", "bomba", "compresor", "cilindro",
		"rodamiento", "bearing", "cojinete", "reten", "retén",
		"correa", "cadena", "engranaje", "reductor", "acoplamiento",
		"transformador", "arrancador", "soft starter",
		"placa base", "tarjeta", "inverter", "inversor",
		"modbus", "profinet", "profibus", "ethernet/ip", "canopen",
		"neumática", "hidráulica", "neumatica", "hidraulica",
		"electrovalvula", "electroválvula", "presostato", "manometro",
		"caudalimetro", "caudalímetro", "termostato",
		"siemens", "allen bradley", "abb", "schneider", "omron",
		"mitsubishi", "fanuc", "danfoss", "sew", "nord",
	}

	for _, comp := range genericComponents {
		if strings.Contains(q, comp) {
			return true
		}
	}

	// When there is NO RAG result at all, search the web for any question
	if ragResultCount == 0 && (strings.Contains(q, "?") || len(q) > 20) {
		return true
	}

	return false
}
