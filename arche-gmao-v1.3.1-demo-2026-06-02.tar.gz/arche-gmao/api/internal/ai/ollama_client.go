package ai

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"strings"
	"time"
)

// OllamaClient handles the calls to the local Ollama server.
// It supports text generation (streaming) and embedding generation.
type OllamaClient struct {
	baseURL    string
	httpClient *http.Client
	chatModel  string
	embedModel string
}

func NewOllamaClient(baseURL, chatModel, embedModel string) *OllamaClient {
	return &OllamaClient{
		baseURL:    baseURL,
		chatModel:  chatModel,
		embedModel: embedModel,
		httpClient: &http.Client{
			Timeout: 120 * time.Second,
		},
	}
}

// ChatModel returns the chat model configured by default.
func (c *OllamaClient) ChatModel() string { return c.chatModel }

// EmbedModel returns the embedding model configured by default.
func (c *OllamaClient) EmbedModel() string { return c.embedModel }

// WithModels returns a copy of the client with the models overridden.
// When either is empty, the original value is kept.
func (c *OllamaClient) WithModels(chatModel, embedModel string) *OllamaClient {
	clone := *c
	if chatModel != "" {
		clone.chatModel = chatModel
	}
	if embedModel != "" {
		clone.embedModel = embedModel
	}
	return &clone
}

// ─── Status: check that Ollama is available ────────────────────────────

func (c *OllamaClient) IsAvailable(ctx context.Context) bool {
	req, err := http.NewRequestWithContext(ctx, "GET", c.baseURL+"/api/tags", nil)
	if err != nil {
		return false
	}
	resp, err := c.httpClient.Do(req)
	if err != nil {
		return false
	}
	defer resp.Body.Close()
	return resp.StatusCode == http.StatusOK
}

// ─── Embeddings ───────────────────────────────────────────────────────────────

type EmbeddingRequest struct {
	Model  string `json:"model"`
	Prompt string `json:"prompt"`
}

type EmbeddingResponse struct {
	Embedding []float32 `json:"embedding"`
}

// GenerateEmbedding turns a text into an embedding vector.
func (c *OllamaClient) GenerateEmbedding(ctx context.Context, text string) ([]float32, error) {
	reqBody := EmbeddingRequest{
		Model:  c.embedModel,
		Prompt: text,
	}

	body, err := json.Marshal(reqBody)
	if err != nil {
		return nil, fmt.Errorf("error serializando request: %w", err)
	}

	req, err := http.NewRequestWithContext(ctx, "POST",
		c.baseURL+"/api/embeddings", bytes.NewBuffer(body))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("error llamando a Ollama embeddings: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		return nil, fmt.Errorf("ollama embeddings error %d: %s", resp.StatusCode, string(body))
	}

	var embResp EmbeddingResponse
	if err := json.NewDecoder(resp.Body).Decode(&embResp); err != nil {
		return nil, fmt.Errorf("error decodificando embedding: %w", err)
	}

	return embResp.Embedding, nil
}

// ─── Text generation (streaming) ─────────────────────────────────────────

type Message struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

type GenerateRequest struct {
	Model    string    `json:"model"`
	Messages []Message `json:"messages"`
	Stream   bool      `json:"stream"`
	Options  map[string]interface{} `json:"options,omitempty"`
}

type GenerateChunk struct {
	Message struct {
		Role    string `json:"role"`
		Content string `json:"content"`
	} `json:"message"`
	Done bool `json:"done"`
}

// GenerateStream calls Ollama's /api/chat endpoint and pushes chunks
// to the channel as they arrive. The caller must close the context to cancel.
func (c *OllamaClient) GenerateStream(
	ctx context.Context,
	messages []Message,
	onChunk func(string),
) (string, error) {
	reqBody := GenerateRequest{
		Model:    c.chatModel,
		Messages: messages,
		Stream:   true,
		Options: map[string]interface{}{
			"temperature":    0.3,
			"num_predict":    1024,
			"num_ctx":        4096,
			"repeat_penalty": 1.15,
			"repeat_last_n":  128,
		},
	}

	body, err := json.Marshal(reqBody)
	if err != nil {
		return "", fmt.Errorf("error serializando request: %w", err)
	}

	req, err := http.NewRequestWithContext(ctx, "POST",
		c.baseURL+"/api/chat", bytes.NewBuffer(body))
	if err != nil {
		return "", err
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return "", fmt.Errorf("error llamando a Ollama: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		return "", fmt.Errorf("ollama error %d: %s", resp.StatusCode, string(body))
	}

	// Read the stream line by line
	var sb strings.Builder
	scanner := bufio.NewScanner(resp.Body)
	for scanner.Scan() {
		line := scanner.Text()
		if line == "" {
			continue
		}

		var chunk GenerateChunk
		if err := json.Unmarshal([]byte(line), &chunk); err != nil {
			continue
		}

		if chunk.Message.Content != "" {
			onChunk(chunk.Message.Content)
			sb.WriteString(chunk.Message.Content)
		}

		if chunk.Done {
			break
		}
	}

	return sb.String(), scanner.Err()
}

// GenerateSimple produces an answer without streaming (for internal classification).
func (c *OllamaClient) GenerateSimple(ctx context.Context, messages []Message) (string, error) {
	reqBody := GenerateRequest{
		Model:    c.chatModel,
		Messages: messages,
		Stream:   false,
		Options: map[string]interface{}{
			"temperature": 0.1,
			"num_predict": 512,
		},
	}

	body, err := json.Marshal(reqBody)
	if err != nil {
		return "", err
	}

	req, err := http.NewRequestWithContext(ctx, "POST",
		c.baseURL+"/api/chat", bytes.NewBuffer(body))
	if err != nil {
		return "", err
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return "", fmt.Errorf("error llamando a Ollama: %w", err)
	}
	defer resp.Body.Close()

	type SimpleResponse struct {
		Message struct {
			Content string `json:"content"`
		} `json:"message"`
	}

	var result SimpleResponse
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return "", fmt.Errorf("error decodificando respuesta: %w", err)
	}

	return result.Message.Content, nil
}

func (c *OllamaClient) GenerateForProcedure(ctx context.Context, messages []Message) (string, error) {
	reqBody := GenerateRequest{
		Model:    c.chatModel,
		Messages: messages,
		Stream:   false,
		Options: map[string]interface{}{
			"temperature": 0.3,
			"num_predict": 4096,
		},
	}

	body, err := json.Marshal(reqBody)
	if err != nil {
		return "", err
	}

	req, err := http.NewRequestWithContext(ctx, "POST",
		c.baseURL+"/api/chat", bytes.NewBuffer(body))
	if err != nil {
		return "", err
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return "", fmt.Errorf("error llamando a Ollama: %w", err)
	}
	defer resp.Body.Close()

	type SimpleResponse struct {
		Message struct {
			Content string `json:"content"`
		} `json:"message"`
	}

	var result SimpleResponse
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return "", fmt.Errorf("error decodificando respuesta: %w", err)
	}

	return result.Message.Content, nil
}

// ─── Text generation (streaming with retry) ──────────────────────────

// GenerateStreamWithRetry attempts streaming generation with an automatic retry.
// First attempt: 30s for the initial response. Retry: 15s.
// onRetrying is called before the retry to let the caller know.
func (c *OllamaClient) GenerateStreamWithRetry(
	ctx context.Context,
	messages []Message,
	onChunk func(string),
	onRetrying func(),
) (string, error) {
	result, gotChunks, err := c.attemptStream(ctx, messages, onChunk, 30*time.Second)
	if err == nil {
		return result, nil
	}
	// Do not retry once partial chunks have arrived (inconsistent data)
	if gotChunks {
		return result, err
	}

	if onRetrying != nil {
		onRetrying()
	}

	result, _, err = c.attemptStream(ctx, messages, onChunk, 15*time.Second)
	return result, err
}

// attemptStream makes one streaming attempt with a timeout on the initial connection.
// ResponseHeaderTimeout controls how long it waits for Ollama's response.
// Once the response starts, the streaming continues without a timeout.
func (c *OllamaClient) attemptStream(
	ctx context.Context,
	messages []Message,
	onChunk func(string),
	headerTimeout time.Duration,
) (string, bool, error) {
	reqBody := GenerateRequest{
		Model:    c.chatModel,
		Messages: messages,
		Stream:   true,
		Options: map[string]interface{}{
			"temperature":    0.3,
			"num_predict":    1024,
			"num_ctx":        4096,
			"repeat_penalty": 1.15,
			"repeat_last_n":  128,
		},
	}

	body, err := json.Marshal(reqBody)
	if err != nil {
		return "", false, fmt.Errorf("error serializando request: %w", err)
	}

	// A temporary client with timeouts specific to this attempt.
	// DialContext timeout: the maximum for establishing the TCP connection.
	// ResponseHeaderTimeout: the maximum for receiving the HTTP headers.
	// Once the headers arrive, the body (stream) is read without a timeout.
	client := &http.Client{
		Transport: &http.Transport{
			DialContext: (&net.Dialer{
				Timeout: headerTimeout,
			}).DialContext,
			ResponseHeaderTimeout: headerTimeout,
		},
	}

	req, err := http.NewRequestWithContext(ctx, "POST",
		c.baseURL+"/api/chat", bytes.NewBuffer(body))
	if err != nil {
		return "", false, err
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		return "", false, fmt.Errorf("error conectando a Ollama: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		respBody, _ := io.ReadAll(resp.Body)
		return "", false, fmt.Errorf("ollama error %d: %s", resp.StatusCode, string(respBody))
	}

	var sb strings.Builder
	gotChunks := false
	scanner := bufio.NewScanner(resp.Body)
	for scanner.Scan() {
		line := scanner.Text()
		if line == "" {
			continue
		}
		var chunk GenerateChunk
		if err := json.Unmarshal([]byte(line), &chunk); err != nil {
			continue
		}
		if chunk.Message.Content != "" {
			gotChunks = true
			onChunk(chunk.Message.Content)
			sb.WriteString(chunk.Message.Content)
		}
		if chunk.Done {
			break
		}
	}

	return sb.String(), gotChunks, scanner.Err()
}

// ─── List the available models ───────────────────────────────────────────────

type ModelInfo struct {
	Name       string `json:"name"`
	ModifiedAt string `json:"modified_at"`
	Size       int64  `json:"size"`
}

func (c *OllamaClient) ListModels(ctx context.Context) ([]ModelInfo, error) {
	req, err := http.NewRequestWithContext(ctx, "GET", c.baseURL+"/api/tags", nil)
	if err != nil {
		return nil, err
	}

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var result struct {
		Models []ModelInfo `json:"models"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}

	return result.Models, nil
}
