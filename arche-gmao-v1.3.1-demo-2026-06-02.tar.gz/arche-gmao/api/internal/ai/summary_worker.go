package ai

import (
	"archive/zip"
	"bytes"
	"context"
	"fmt"
	"log"
	"strings"
	"sync"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/xuri/excelize/v2"
)

// MonthlySummaryWorker rebuilds the monthly summary ZIPs daily
// and freezes past months after a 10 working day grace period.
type MonthlySummaryWorker struct {
	db     *pgxpool.Pool
	stopCh chan struct{}
	wg     sync.WaitGroup
}

func NewMonthlySummaryWorker(db *pgxpool.Pool) *MonthlySummaryWorker {
	return &MonthlySummaryWorker{db: db, stopCh: make(chan struct{})}
}

func (w *MonthlySummaryWorker) Start() {
	w.wg.Add(1)
	go func() { defer w.wg.Done(); w.run() }()
}

func (w *MonthlySummaryWorker) Stop() {
	close(w.stopCh)
	w.wg.Wait()
}

func (w *MonthlySummaryWorker) run() {
	select {
	case <-w.stopCh:
		return
	case <-time.After(60 * time.Second):
	}

	w.process()

	// Run once a day at 03:00
	ticker := time.NewTicker(1 * time.Hour)
	defer ticker.Stop()
	lastRun := time.Now().Format("2006-01-02")

	for {
		select {
		case <-w.stopCh:
			return
		case <-ticker.C:
			today := time.Now().Format("2006-01-02")
			if today != lastRun && time.Now().Hour() >= 3 {
				w.process()
				lastRun = today
			}
		}
	}
}

func (w *MonthlySummaryWorker) process() {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Minute)
	defer cancel()

	rows, err := w.db.Query(ctx, `SELECT id FROM tenants WHERE status = 'active'`)
	if err != nil {
		log.Printf("[SUMMARY] Error consultando tenants: %v", err)
		return
	}
	defer rows.Close()

	var tenantIDs []int64
	for rows.Next() {
		var id int64
		if rows.Scan(&id) == nil {
			tenantIDs = append(tenantIDs, id)
		}
	}

	for _, tenantID := range tenantIDs {
		w.processForTenant(ctx, tenantID)
	}
}

func (w *MonthlySummaryWorker) processForTenant(ctx context.Context, tenantID int64) {
	now := time.Now()
	currentMonth := now.Format("2006-01")

	// 1. Build the current month
	w.compileMonth(ctx, tenantID, currentMonth)

	// 2. Build and possibly freeze the previous month
	prevMonth := now.AddDate(0, -1, 0).Format("2006-01")
	w.compileMonth(ctx, tenantID, prevMonth)
	w.tryFreezeMonth(ctx, tenantID, prevMonth)

	// 3. Freeze older months that are still not frozen
	oldRows, err := w.db.Query(ctx,
		`SELECT DISTINCT TO_CHAR(summary_date, 'YYYY-MM')
		 FROM daily_summaries WHERE tenant_id=$1
		 AND TO_CHAR(summary_date, 'YYYY-MM') < $2`,
		tenantID, prevMonth,
	)
	if err != nil {
		log.Printf("[SUMMARY] Error consultando meses antiguos: %v", err)
		return
	}
	defer oldRows.Close()
	for oldRows.Next() {
		var m string
		if oldRows.Scan(&m) == nil {
			w.compileMonth(ctx, tenantID, m)
			w.tryFreezeMonth(ctx, tenantID, m)
		}
	}
}

func (w *MonthlySummaryWorker) compileMonth(ctx context.Context, tenantID int64, month string) {
	// Do not rebuild months that are already frozen
	var frozen bool
	w.db.QueryRow(ctx,
		`SELECT frozen FROM monthly_summary_folders WHERE tenant_id=$1 AND month=$2`,
		tenantID, month,
	).Scan(&frozen)
	if frozen {
		return
	}

	// Get the technicians with summaries in that month
	rows, err := w.db.Query(ctx,
		`SELECT DISTINCT ds.user_id, u.full_name, u.role
		 FROM daily_summaries ds
		 JOIN users u ON u.id = ds.user_id
		 WHERE ds.tenant_id=$1 AND TO_CHAR(ds.summary_date, 'YYYY-MM') = $2
		 ORDER BY u.full_name`,
		tenantID, month,
	)
	if err != nil {
		log.Printf("[SUMMARY] Error consultando técnicos mes %s: %v", month, err)
		return
	}
	defer rows.Close()

	type userInfo struct {
		ID   int64
		Name string
		Role string
	}
	var users []userInfo
	for rows.Next() {
		var u userInfo
		if rows.Scan(&u.ID, &u.Name, &u.Role) == nil {
			users = append(users, u)
		}
	}

	if len(users) == 0 {
		return
	}

	// Build the ZIP
	var zipBuf bytes.Buffer
	zw := zip.NewWriter(&zipBuf)
	monthLabel := workerSpanishMonth(month)
	folderName := fmt.Sprintf("Resumenes_%s", monthLabel)

	for _, u := range users {
		excelBytes, err := w.buildUserExcel(ctx, tenantID, u.ID, u.Name, u.Role, month, monthLabel)
		if err != nil {
			log.Printf("[SUMMARY] Error generando Excel para %s: %v", u.Name, err)
			continue
		}
		safeName := workerSanitizeName(u.Name)
		fileName := fmt.Sprintf("%s/%s_%s.xlsx", folderName, safeName, month)
		fw, err := zw.Create(fileName)
		if err != nil {
			continue
		}
		fw.Write(excelBytes)
	}
	zw.Close()

	// Store it in the DB
	_, err = w.db.Exec(ctx,
		`INSERT INTO monthly_summary_folders (tenant_id, month, file_name, file_data, last_compiled)
		 VALUES ($1, $2, $3, $4, NOW())
		 ON CONFLICT (tenant_id, month) DO UPDATE
		 SET file_data=$4, file_name=$3, last_compiled=NOW()`,
		tenantID, month,
		fmt.Sprintf("Resumenes_%s.zip", month),
		zipBuf.Bytes(),
	)
	if err != nil {
		log.Printf("[SUMMARY] Error guardando ZIP mes %s: %v", month, err)
		return
	}
	log.Printf("[SUMMARY] Carpeta compilada: tenant %d, mes %s (%d técnicos)", tenantID, month, len(users))
}

func (w *MonthlySummaryWorker) tryFreezeMonth(ctx context.Context, tenantID int64, month string) {
	// Already frozen?
	var frozen bool
	w.db.QueryRow(ctx,
		`SELECT frozen FROM monthly_summary_folders WHERE tenant_id=$1 AND month=$2`,
		tenantID, month,
	).Scan(&frozen)
	if frozen {
		return
	}

	// Compute the deadline: first day of the next month + 10 working days
	t, err := time.Parse("2006-01", month)
	if err != nil {
		return
	}
	nextMonth := t.AddDate(0, 1, 0)
	deadline := workerAddBusinessDays(nextMonth, 10)

	if time.Now().After(deadline) {
		if _, err := w.db.Exec(ctx,
			`UPDATE monthly_summary_folders SET frozen=true, frozen_at=NOW()
			 WHERE tenant_id=$1 AND month=$2`,
			tenantID, month,
		); err != nil {
			log.Printf("[SUMMARY] Error congelando mes %s: %v", month, err)
			return
		}
		log.Printf("[SUMMARY] Mes congelado: tenant %d, mes %s", tenantID, month)
	}
}

func (w *MonthlySummaryWorker) buildUserExcel(ctx context.Context, tenantID, userID int64, userName, userRole, month, monthLabel string) ([]byte, error) {
	rows, err := w.db.Query(ctx,
		`SELECT ds.summary_date::text, COALESCE(cl.name, 'Interno'),
		        COALESCE(wo.wo_number, ''), COALESCE(wo.title, ''),
		        COALESCE(ds.project_number, 'Interno'), ds.shift, ds.shift_extras,
		        ds.hours, COALESCE(ds.observations, ''),
		        COALESCE(fn.name, '')
		 FROM daily_summaries ds
		 LEFT JOIN clients cl ON cl.id = ds.client_id
		 LEFT JOIN work_orders wo ON wo.id = ds.wo_id
		 LEFT JOIN factory_nodes fn ON fn.id = wo.node_id
		 WHERE ds.tenant_id=$1 AND ds.user_id=$2
		   AND TO_CHAR(ds.summary_date, 'YYYY-MM') = $3
		 ORDER BY ds.summary_date, ds.created_at`,
		tenantID, userID, month,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	f := excelize.NewFile()
	defer f.Close()

	headerStyle, _ := f.NewStyle(&excelize.Style{
		Fill:      excelize.Fill{Type: "pattern", Color: []string{"0F3460"}, Pattern: 1},
		Font:      &excelize.Font{Color: "FFFFFF", Bold: true, Size: 10},
		Alignment: &excelize.Alignment{Horizontal: "center", Vertical: "center", WrapText: true},
	})

	// ─── Detail sheet ───
	f.SetSheetName("Sheet1", "Detalle")
	headers := []string{"Fecha", "Cliente", "N° OT", "Titulo OT", "Equipo", "Proyecto", "Turno", "Extras", "Horas", "Observaciones"}
	for i, h := range headers {
		col := string(rune('A' + i))
		f.SetCellValue("Detalle", col+"1", h)
	}
	f.SetCellStyle("Detalle", "A1", "J1", headerStyle)
	f.SetColWidth("Detalle", "A", "A", 12)
	f.SetColWidth("Detalle", "B", "B", 18)
	f.SetColWidth("Detalle", "C", "C", 20)
	f.SetColWidth("Detalle", "D", "D", 30)
	f.SetColWidth("Detalle", "E", "E", 22)
	f.SetColWidth("Detalle", "F", "F", 14)
	f.SetColWidth("Detalle", "G", "G", 10)
	f.SetColWidth("Detalle", "H", "H", 28)
	f.SetColWidth("Detalle", "I", "I", 8)
	f.SetColWidth("Detalle", "J", "J", 40)

	row := 2
	var totalHours float64
	var totalEntries int
	daysSet := map[string]bool{}
	shiftCount := map[string]int{}

	for rows.Next() {
		var date, client, woNum, woTitle, project, shift, obs, nodeName string
		var extras []string
		var hours float64
		if rows.Scan(&date, &client, &woNum, &woTitle, &project, &shift, &extras, &hours, &obs, &nodeName) != nil {
			continue
		}

		f.SetCellValue("Detalle", fmt.Sprintf("A%d", row), date)
		f.SetCellValue("Detalle", fmt.Sprintf("B%d", row), client)
		f.SetCellValue("Detalle", fmt.Sprintf("C%d", row), woNum)
		f.SetCellValue("Detalle", fmt.Sprintf("D%d", row), woTitle)
		f.SetCellValue("Detalle", fmt.Sprintf("E%d", row), nodeName)
		f.SetCellValue("Detalle", fmt.Sprintf("F%d", row), project)
		f.SetCellValue("Detalle", fmt.Sprintf("G%d", row), shift)
		f.SetCellValue("Detalle", fmt.Sprintf("H%d", row), strings.Join(extras, ", "))
		f.SetCellValue("Detalle", fmt.Sprintf("I%d", row), fmt.Sprintf("%.1f", hours))
		f.SetCellValue("Detalle", fmt.Sprintf("J%d", row), obs)
		row++

		totalHours += hours
		totalEntries++
		daysSet[date] = true
		shiftCount[shift]++
	}

	// ─── Summary sheet ───
	f.NewSheet("Resumen")
	f.SetCellValue("Resumen", "A1", "RESUMEN MENSUAL DE HORAS")
	f.SetCellValue("Resumen", "A2", "Tecnico: "+userName)
	f.SetCellValue("Resumen", "A3", "Rol: "+userRole)
	f.SetCellValue("Resumen", "A4", "Periodo: "+monthLabel)
	f.SetCellValue("Resumen", "A5", "Generado: "+time.Now().Format("02/01/2006 15:04"))

	f.SetCellValue("Resumen", "A7", "Dias con registro:")
	f.SetCellValue("Resumen", "B7", len(daysSet))
	f.SetCellValue("Resumen", "A8", "Total entradas:")
	f.SetCellValue("Resumen", "B8", totalEntries)
	f.SetCellValue("Resumen", "A9", "Horas totales:")
	f.SetCellValue("Resumen", "B9", fmt.Sprintf("%.1f", totalHours))

	r := 11
	for shift, cnt := range shiftCount {
		f.SetCellValue("Resumen", fmt.Sprintf("A%d", r), shift)
		f.SetCellValue("Resumen", fmt.Sprintf("B%d", r), cnt)
		r++
	}

	var buf bytes.Buffer
	if err := f.Write(&buf); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

// ─── Helpers (prefixed to avoid collisions inside the package) ──────────────

func workerAddBusinessDays(start time.Time, days int) time.Time {
	d := start
	added := 0
	for added < days {
		d = d.AddDate(0, 0, 1)
		if d.Weekday() != time.Saturday && d.Weekday() != time.Sunday {
			added++
		}
	}
	return d
}

func workerSanitizeName(name string) string {
	var result []byte
	for _, r := range name {
		if (r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z') || (r >= '0' && r <= '9') || r == '-' {
			result = append(result, byte(r))
		} else {
			result = append(result, '_')
		}
	}
	return string(result)
}

func workerSpanishMonth(monthStr string) string {
	months := map[string]string{
		"01": "Enero", "02": "Febrero", "03": "Marzo", "04": "Abril",
		"05": "Mayo", "06": "Junio", "07": "Julio", "08": "Agosto",
		"09": "Septiembre", "10": "Octubre", "11": "Noviembre", "12": "Diciembre",
	}
	parts := strings.Split(monthStr, "-")
	if len(parts) == 2 {
		if m, ok := months[parts[1]]; ok {
			return m + "_" + parts[0]
		}
	}
	return monthStr
}
