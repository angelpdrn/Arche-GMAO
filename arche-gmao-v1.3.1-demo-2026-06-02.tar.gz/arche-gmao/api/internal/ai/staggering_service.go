package ai

import (
	"context"
	"fmt"
	"log"
	"sort"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
)

// StaggeringService manages the staggered distribution of preventive maintenance.
// It computes schedules that spread WOs evenly over the available period,
// respecting the maximum load per technician and prioritizing by equipment criticality.
type StaggeringService struct {
	db *pgxpool.Pool
}

func NewStaggeringService(db *pgxpool.Pool) *StaggeringService {
	return &StaggeringService{db: db}
}

// ScheduleEntry is a single schedule entry (one WO to be generated on a date).
type ScheduleEntry struct {
	PlanID        int64  `json:"plan_id"`
	PlanTitle     string `json:"plan_title"`
	NodeID        int64  `json:"node_id"`
	NodeName      string `json:"node_name"`
	NodeCode      string `json:"node_code"`
	Criticality   string `json:"criticality"`
	TechnicianID  *int64 `json:"technician_id"`
	TechnicianName string `json:"technician_name"`
	ScheduledDate string `json:"scheduled_date"`
	Priority      string `json:"priority"`
}

// SchedulePreview is the full preview of a cycle.
type SchedulePreview struct {
	CycleStart     string          `json:"cycle_start"`
	CycleEnd       string          `json:"cycle_end"`
	TotalPlanned   int             `json:"total_planned"`
	Entries        []ScheduleEntry `json:"entries"`
	DailyLoad      map[string]int  `json:"daily_load"`
	MaxDailyPerTech int            `json:"max_daily_per_tech"`
}

// planTarget is a concrete plan+node that needs a staggered WO.
type planTarget struct {
	PlanID       int64
	PlanTitle    string
	NodeID       int64
	NodeName     string
	NodeCode     string
	Criticality  string
	Priority     string
	TechnicianID *int64
	TechName     string
}

var criticalityOrder = map[string]int{
	"critical": 0,
	"high":     1,
	"medium":   2,
	"low":      3,
}

// CalculatePreview computes the distribution without storing anything in the DB.
// It returns the preview so the admin can validate it.
func (s *StaggeringService) CalculatePreview(ctx context.Context, tenantID int64, configID int64) (*SchedulePreview, error) {
	// 1. Get the configuration
	var scope, period string
	var scopeNodeID *int64
	var maxDaily int
	err := s.db.QueryRow(ctx,
		`SELECT scope, scope_node_id, period, max_daily_per_tech
		 FROM staggered_configs WHERE id=$1 AND tenant_id=$2 AND is_active=true`,
		configID, tenantID,
	).Scan(&scope, &scopeNodeID, &period, &maxDaily)
	if err != nil {
		return nil, fmt.Errorf("configuración de escalonado no encontrada o inactiva")
	}

	// 2. Compute the period
	cycleStart := time.Now().Truncate(24 * time.Hour).AddDate(0, 0, 1) // tomorrow
	cycleEnd := calculateCycleEnd(cycleStart, period)

	// 3. Get the active plans with staggering enabled in the scope
	targets, err := s.collectTargets(ctx, tenantID, scope, scopeNodeID)
	if err != nil {
		return nil, err
	}

	if len(targets) == 0 {
		return &SchedulePreview{
			CycleStart:      cycleStart.Format("2006-01-02"),
			CycleEnd:        cycleEnd.Format("2006-01-02"),
			TotalPlanned:    0,
			Entries:         []ScheduleEntry{},
			DailyLoad:       map[string]int{},
			MaxDailyPerTech: maxDaily,
		}, nil
	}

	// 4. Get the available technicians
	techs, err := s.getAvailableTechnicians(ctx, tenantID, scope, scopeNodeID)
	if err != nil {
		return nil, err
	}

	// 5. Sort by criticality (critical > high > medium > low)
	sort.Slice(targets, func(i, j int) bool {
		ci := criticalityOrder[targets[i].Criticality]
		cj := criticalityOrder[targets[j].Criticality]
		if ci != cj {
			return ci < cj
		}
		return targets[i].NodeName < targets[j].NodeName
	})

	// 6. Spread them across the available days
	entries, dailyLoad := s.distribute(targets, techs, cycleStart, cycleEnd, maxDaily)

	return &SchedulePreview{
		CycleStart:      cycleStart.Format("2006-01-02"),
		CycleEnd:        cycleEnd.Format("2006-01-02"),
		TotalPlanned:    len(entries),
		Entries:         entries,
		DailyLoad:       dailyLoad,
		MaxDailyPerTech: maxDaily,
	}, nil
}

// ApplySchedule computes and stores the schedule in the DB, creating a new cycle.
func (s *StaggeringService) ApplySchedule(ctx context.Context, tenantID int64, configID int64, createdBy int64) (int64, error) {
	preview, err := s.CalculatePreview(ctx, tenantID, configID)
	if err != nil {
		return 0, err
	}

	if preview.TotalPlanned == 0 {
		return 0, fmt.Errorf("no hay tareas de mantenimiento para escalonar en este período")
	}

	// Create the cycle
	var cycleID int64
	err = s.db.QueryRow(ctx,
		`INSERT INTO staggered_cycles (tenant_id, config_id, cycle_start, cycle_end, total_planned, status)
		 VALUES ($1, $2, $3::date, $4::date, $5, 'planned') RETURNING id`,
		tenantID, configID, preview.CycleStart, preview.CycleEnd, preview.TotalPlanned,
	).Scan(&cycleID)
	if err != nil {
		return 0, fmt.Errorf("error creando ciclo de escalonado: %w", err)
	}

	// Insert the schedule entries
	for _, e := range preview.Entries {
		_, err = s.db.Exec(ctx,
			`INSERT INTO staggered_schedule
			 (tenant_id, cycle_id, plan_id, node_id, scheduled_date, technician_id, status)
			 VALUES ($1, $2, $3, $4, $5::date, $6, 'scheduled')`,
			tenantID, cycleID, e.PlanID, e.NodeID, e.ScheduledDate, e.TechnicianID,
		)
		if err != nil {
			log.Printf("[ARCHE-STAGGER] Error insertando entrada schedule plan=%d node=%d: %v", e.PlanID, e.NodeID, err)
		}
	}

	log.Printf("[ARCHE-STAGGER] Ciclo %d creado: %d tareas del %s al %s",
		cycleID, preview.TotalPlanned, preview.CycleStart, preview.CycleEnd)

	return cycleID, nil
}

// RescheduleNode moves a node's pending preventive work to the next free slot.
// It is called automatically when a corrective WO is created for that node.
func (s *StaggeringService) RescheduleNode(ctx context.Context, tenantID int64, nodeID int64) (int, error) {
	// Find the pending entries for this node
	rows, err := s.db.Query(ctx,
		`SELECT ss.id, ss.cycle_id, ss.scheduled_date, ss.technician_id,
		        sc.max_daily_per_tech
		 FROM staggered_schedule ss
		 JOIN staggered_cycles cy ON cy.id = ss.cycle_id AND cy.tenant_id = $1
		 JOIN staggered_configs sc ON sc.id = cy.config_id AND sc.tenant_id = $1
		 WHERE ss.tenant_id = $1 AND ss.node_id = $2 AND ss.status = 'scheduled'
		   AND ss.scheduled_date >= CURRENT_DATE
		 ORDER BY ss.scheduled_date`,
		tenantID, nodeID,
	)
	if err != nil {
		return 0, err
	}
	defer rows.Close()

	rescheduled := 0
	for rows.Next() {
		var entryID, cycleID int64
		var scheduledDate time.Time
		var techID *int64
		var maxDaily int
		if err := rows.Scan(&entryID, &cycleID, &scheduledDate, &techID, &maxDaily); err != nil {
			continue
		}

		// Find the next available day after the original date
		newDate := s.findNextAvailableDate(ctx, tenantID, cycleID, techID, scheduledDate.AddDate(0, 0, 1), maxDaily)

		_, err = s.db.Exec(ctx,
			`UPDATE staggered_schedule
			 SET scheduled_date = $1, status = 'rescheduled', rescheduled_from = $2
			 WHERE id = $3 AND tenant_id = $4`,
			newDate, scheduledDate, entryID, tenantID,
		)
		if err == nil {
			rescheduled++
			// Update the cycle counters
			s.db.Exec(ctx,
				`UPDATE staggered_cycles SET total_rescheduled = total_rescheduled + 1 WHERE id = $1 AND tenant_id = $2`,
				cycleID, tenantID,
			)
			log.Printf("[ARCHE-STAGGER] Reescalonado: nodo %d movido de %s a %s",
				nodeID, scheduledDate.Format("2006-01-02"), newDate.Format("2006-01-02"))
		}
	}

	return rescheduled, nil
}

// ─── Internal methods ────────────────────────────────────────────────────────

// collectTargets gathers every plan+node that needs staggering.
func (s *StaggeringService) collectTargets(ctx context.Context, tenantID int64, scope string, scopeNodeID *int64) ([]planTarget, error) {
	query := `
		SELECT mp.id, mp.title, fn.id, fn.name, fn.code, fn.criticality, mp.priority,
		       mp.assigned_to, COALESCE(u.full_name, '')
		FROM maintenance_plans mp
		JOIN factory_nodes fn ON fn.id = mp.node_id AND fn.tenant_id = $1
		LEFT JOIN users u ON u.id = mp.assigned_to
		WHERE mp.tenant_id = $1
		  AND mp.is_active = true
		  AND mp.staggering_enabled = true
		  AND mp.node_id IS NOT NULL`

	args := []interface{}{tenantID}

	if scope == "area" && scopeNodeID != nil {
		query += ` AND fn.path <@ (SELECT path FROM factory_nodes WHERE id = $2 AND tenant_id = $1)`
		args = append(args, *scopeNodeID)
	} else if scope == "line" && scopeNodeID != nil {
		query += ` AND fn.path <@ (SELECT path FROM factory_nodes WHERE id = $2 AND tenant_id = $1)`
		args = append(args, *scopeNodeID)
	}

	query += ` ORDER BY fn.criticality, fn.name`

	rows, err := s.db.Query(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("error consultando planes para escalonado: %w", err)
	}
	defer rows.Close()

	var targets []planTarget
	for rows.Next() {
		var t planTarget
		if err := rows.Scan(&t.PlanID, &t.PlanTitle, &t.NodeID, &t.NodeName, &t.NodeCode,
			&t.Criticality, &t.Priority, &t.TechnicianID, &t.TechName); err != nil {
			continue
		}
		targets = append(targets, t)
	}

	return targets, nil
}

// getAvailableTechnicians gets technicians with active assignments in the scope.
func (s *StaggeringService) getAvailableTechnicians(ctx context.Context, tenantID int64, scope string, scopeNodeID *int64) ([]struct{ ID int64; Name string }, error) {
	query := `
		SELECT DISTINCT u.id, u.full_name
		FROM users u
		WHERE u.tenant_id = $1 AND u.status = 'active'
		  AND u.role IN ('technician', 'operator', 'supervisor')
		ORDER BY u.full_name`

	rows, err := s.db.Query(ctx, query, tenantID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var techs []struct{ ID int64; Name string }
	for rows.Next() {
		var t struct{ ID int64; Name string }
		if rows.Scan(&t.ID, &t.Name) == nil {
			techs = append(techs, t)
		}
	}
	return techs, nil
}

// distribute spreads the targets across the cycle days, respecting the maximum load.
func (s *StaggeringService) distribute(targets []planTarget, techs []struct{ ID int64; Name string },
	cycleStart, cycleEnd time.Time, maxDaily int) ([]ScheduleEntry, map[string]int) {

	entries := make([]ScheduleEntry, 0, len(targets))
	dailyLoad := make(map[string]int)

	// Load map per technician per day: "YYYY-MM-DD:techID" -> count
	techDayLoad := make(map[string]int)

	// Working days of the cycle (Monday to Friday)
	var workDays []time.Time
	for d := cycleStart; !d.After(cycleEnd); d = d.AddDate(0, 0, 1) {
		if d.Weekday() != time.Saturday && d.Weekday() != time.Sunday {
			workDays = append(workDays, d)
		}
	}

	if len(workDays) == 0 {
		return entries, dailyLoad
	}

	dayIdx := 0

	for _, target := range targets {
		// Decide the technician for this task
		techID := target.TechnicianID
		techName := target.TechName

		// When the plan has no assigned technician, try to take one from the pool
		if techID == nil && len(techs) > 0 {
			// Find the technician with the lightest load on the current day
			bestTech := techs[0]
			bestLoad := techDayLoad[fmt.Sprintf("%s:%d", workDays[dayIdx].Format("2006-01-02"), techs[0].ID)]
			for _, t := range techs[1:] {
				load := techDayLoad[fmt.Sprintf("%s:%d", workDays[dayIdx].Format("2006-01-02"), t.ID)]
				if load < bestLoad {
					bestTech = t
					bestLoad = load
				}
			}
			techID = &bestTech.ID
			techName = bestTech.Name
		}

		// Find a day where the technician stays under the maximum load
		placed := false
		startIdx := dayIdx
		for attempts := 0; attempts < len(workDays); attempts++ {
			idx := (startIdx + attempts) % len(workDays)
			dateStr := workDays[idx].Format("2006-01-02")

			var loadKey string
			if techID != nil {
				loadKey = fmt.Sprintf("%s:%d", dateStr, *techID)
			} else {
				loadKey = dateStr
			}

			if techDayLoad[loadKey] < maxDaily {
				entries = append(entries, ScheduleEntry{
					PlanID:         target.PlanID,
					PlanTitle:      target.PlanTitle,
					NodeID:         target.NodeID,
					NodeName:       target.NodeName,
					NodeCode:       target.NodeCode,
					Criticality:    target.Criticality,
					TechnicianID:   techID,
					TechnicianName: techName,
					ScheduledDate:  dateStr,
					Priority:       target.Priority,
				})
				techDayLoad[loadKey]++
				dailyLoad[dateStr]++
				placed = true

				// Advance the day index for the next task
				dayIdx = (idx + 1) % len(workDays)
				break
			}
		}

		// If it could not be placed (every day full), force it onto the least loaded one
		if !placed {
			minDay := workDays[0]
			minLoad := dailyLoad[workDays[0].Format("2006-01-02")]
			for _, d := range workDays[1:] {
				ds := d.Format("2006-01-02")
				if dailyLoad[ds] < minLoad {
					minDay = d
					minLoad = dailyLoad[ds]
				}
			}
			dateStr := minDay.Format("2006-01-02")
			entries = append(entries, ScheduleEntry{
				PlanID:         target.PlanID,
				PlanTitle:      target.PlanTitle,
				NodeID:         target.NodeID,
				NodeName:       target.NodeName,
				NodeCode:       target.NodeCode,
				Criticality:    target.Criticality,
				TechnicianID:   techID,
				TechnicianName: techName,
				ScheduledDate:  dateStr,
				Priority:       target.Priority,
			})
			dailyLoad[dateStr]++
		}
	}

	return entries, dailyLoad
}

// findNextAvailableDate looks for the next working day with spare capacity.
func (s *StaggeringService) findNextAvailableDate(ctx context.Context, tenantID, cycleID int64, techID *int64, from time.Time, maxDaily int) time.Time {
	// Get the end of the cycle
	var cycleEnd time.Time
	err := s.db.QueryRow(ctx,
		`SELECT cycle_end FROM staggered_cycles WHERE id=$1 AND tenant_id=$2`,
		cycleID, tenantID,
	).Scan(&cycleEnd)
	if err != nil {
		return from
	}

	for d := from; !d.After(cycleEnd.AddDate(0, 0, 7)); d = d.AddDate(0, 0, 1) {
		// Skip weekends
		if d.Weekday() == time.Saturday || d.Weekday() == time.Sunday {
			continue
		}

		// Count how many tasks this technician has on this day
		var count int
		if techID != nil {
			s.db.QueryRow(ctx,
				`SELECT COUNT(*) FROM staggered_schedule
				 WHERE tenant_id=$1 AND cycle_id=$2 AND technician_id=$3
				   AND scheduled_date=$4 AND status IN ('scheduled','rescheduled')`,
				tenantID, cycleID, *techID, d,
			).Scan(&count)
		} else {
			s.db.QueryRow(ctx,
				`SELECT COUNT(*) FROM staggered_schedule
				 WHERE tenant_id=$1 AND cycle_id=$2
				   AND scheduled_date=$3 AND status IN ('scheduled','rescheduled')`,
				tenantID, cycleID, d,
			).Scan(&count)
		}

		if count < maxDaily {
			return d
		}
	}

	// Fallback: use the requested date
	return from
}

func calculateCycleEnd(start time.Time, period string) time.Time {
	switch period {
	case "weekly":
		return start.AddDate(0, 0, 7)
	case "biweekly":
		return start.AddDate(0, 0, 14)
	case "monthly":
		return start.AddDate(0, 1, 0)
	default:
		return start.AddDate(0, 1, 0)
	}
}
