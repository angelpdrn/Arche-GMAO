package main

import (
	"bufio"
	"crypto/aes"
	"crypto/cipher"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"arche-gmao/api/internal/license"

	"golang.org/x/crypto/pbkdf2"
	"golang.org/x/term"
)

const archeDir = ".arche"

func main() {
	if len(os.Args) < 2 {
		printUsage()
		os.Exit(1)
	}

	switch os.Args[1] {
	case "init":
		cmdInit()
	case "license":
		if len(os.Args) < 3 {
			fmt.Println("Uso: arche license <create|list>")
			os.Exit(1)
		}
		switch os.Args[2] {
		case "create":
			cmdLicenseCreate()
		case "list":
			cmdLicenseList()
		default:
			fmt.Printf("Subcomando desconocido: license %s\n", os.Args[2])
		}
	case "fingerprint":
		cmdFingerprint()
	case "pubkey":
		cmdPubkey()
	default:
		fmt.Printf("Comando desconocido: %s\n", os.Args[1])
		printUsage()
		os.Exit(1)
	}
}

func printUsage() {
	fmt.Println(`
  Arche GMAO — CLI de administracion

  Uso: arche <comando>

  Comandos:
    init              Generar par de claves Ed25519 (primera vez)
    license create    Crear nueva licencia firmada
    license list      Listar licencias generadas
    fingerprint       Mostrar fingerprint de hardware local
    pubkey            Mostrar clave publica (hex) para build.sh
	`)
}

// ─── File paths ──────────────────────────────────────────────────────

func configDir() string {
	home, _ := os.UserHomeDir()
	return filepath.Join(home, archeDir)
}

func privateKeyPath() string { return filepath.Join(configDir(), "private.key.enc") }
func publicKeyPath() string  { return filepath.Join(configDir(), "public.key") }
func licensesDBPath() string { return filepath.Join(configDir(), "licenses.json") }

// ─── Crypto helpers ─────────────────────────────────────────────────────────

func deriveKey(password string, salt []byte) []byte {
	return pbkdf2.Key([]byte(password), salt, 200_000, 32, sha256.New)
}

func encryptPrivateKey(privKey ed25519.PrivateKey, password string) ([]byte, error) {
	salt := make([]byte, 32)
	if _, err := io.ReadFull(rand.Reader, salt); err != nil {
		return nil, err
	}

	key := deriveKey(password, salt)

	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}

	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return nil, err
	}

	ciphertext := gcm.Seal(nil, nonce, []byte(privKey), nil)

	// Format: salt(32) + nonce(12) + ciphertext
	result := make([]byte, 0, len(salt)+len(nonce)+len(ciphertext))
	result = append(result, salt...)
	result = append(result, nonce...)
	result = append(result, ciphertext...)
	return result, nil
}

func decryptPrivateKey(data []byte, password string) (ed25519.PrivateKey, error) {
	if len(data) < 44 { // 32 salt + 12 nonce min
		return nil, fmt.Errorf("datos cifrados demasiado cortos")
	}

	salt := data[:32]
	key := deriveKey(password, salt)

	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}

	nonceSize := gcm.NonceSize()
	if len(data) < 32+nonceSize {
		return nil, fmt.Errorf("datos cifrados corruptos")
	}

	nonce := data[32 : 32+nonceSize]
	ciphertext := data[32+nonceSize:]

	plaintext, err := gcm.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return nil, fmt.Errorf("contrasena incorrecta o datos corruptos")
	}

	return ed25519.PrivateKey(plaintext), nil
}

func readPassword(prompt string) string {
	fmt.Print(prompt)
	pw, err := term.ReadPassword(int(os.Stdin.Fd()))
	fmt.Println()
	if err != nil {
		// Fallback when there is no terminal (pipe)
		scanner := bufio.NewScanner(os.Stdin)
		scanner.Scan()
		return scanner.Text()
	}
	return string(pw)
}

func readLine(prompt string) string {
	fmt.Print(prompt)
	scanner := bufio.NewScanner(os.Stdin)
	scanner.Scan()
	return strings.TrimSpace(scanner.Text())
}

func loadPrivateKey() ed25519.PrivateKey {
	data, err := os.ReadFile(privateKeyPath())
	if err != nil {
		fmt.Println("  Error: No se encontro clave privada. Ejecuta 'arche init' primero.")
		os.Exit(1)
	}

	raw, err := base64.StdEncoding.DecodeString(strings.TrimSpace(string(data)))
	if err != nil {
		fmt.Println("  Error: Clave privada corrupta.")
		os.Exit(1)
	}

	password := readPassword("  Contrasena maestra: ")
	privKey, err := decryptPrivateKey(raw, password)
	if err != nil {
		fmt.Printf("  Error: %v\n", err)
		os.Exit(1)
	}

	return privKey
}

// ─── Commands ───────────────────────────────────────────────────────────────

func cmdInit() {
	fmt.Println()
	fmt.Println("  ╔══════════════════════════════════════════════════╗")
	fmt.Println("  ║    ARCHE GMAO — Inicializacion de claves       ║")
	fmt.Println("  ╚══════════════════════════════════════════════════╝")
	fmt.Println()

	dir := configDir()
	if _, err := os.Stat(privateKeyPath()); err == nil {
		fmt.Println("  Ya existe un par de claves en " + dir)
		fmt.Println("  Si quieres regenerar, elimina el directorio ~/.arche/ primero.")
		fmt.Println("  CUIDADO: Esto invalidara TODAS las licencias existentes.")
		os.Exit(1)
	}

	os.MkdirAll(dir, 0700)

	// Generate an Ed25519 pair
	pubKey, privKey, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		fmt.Printf("  Error generando claves: %v\n", err)
		os.Exit(1)
	}

	// Ask for the master password
	fmt.Println("  Elige una contrasena maestra para proteger la clave privada.")
	fmt.Println("  Esta contrasena se necesita para generar licencias.")
	fmt.Println()

	pw1 := readPassword("  Contrasena maestra: ")
	if len(pw1) < 8 {
		fmt.Println("  Error: La contrasena debe tener al menos 8 caracteres.")
		os.Exit(1)
	}
	pw2 := readPassword("  Repetir contrasena: ")
	if pw1 != pw2 {
		fmt.Println("  Error: Las contrasenas no coinciden.")
		os.Exit(1)
	}

	// Encrypt the private key
	encrypted, err := encryptPrivateKey(privKey, pw1)
	if err != nil {
		fmt.Printf("  Error cifrando clave: %v\n", err)
		os.Exit(1)
	}

	// Save the encrypted private key
	if err := os.WriteFile(privateKeyPath(), []byte(base64.StdEncoding.EncodeToString(encrypted)), 0600); err != nil {
		fmt.Printf("  Error guardando clave privada: %v\n", err)
		os.Exit(1)
	}

	// Save the public key (hex)
	pubHex := hex.EncodeToString(pubKey)
	if err := os.WriteFile(publicKeyPath(), []byte(pubHex), 0644); err != nil {
		fmt.Printf("  Error guardando clave publica: %v\n", err)
		os.Exit(1)
	}

	fmt.Println()
	fmt.Println("  Claves generadas:")
	fmt.Printf("  Privada (cifrada): %s\n", privateKeyPath())
	fmt.Printf("  Publica:           %s\n", publicKeyPath())
	fmt.Println()
	fmt.Println("  Clave publica (hex) — para build.sh:")
	fmt.Printf("  %s\n", pubHex)
	fmt.Println()
	fmt.Println("  IMPORTANTE:")
	fmt.Println("  - La clave privada esta protegida con tu contrasena.")
	fmt.Println("  - Sin ella, no puedes generar licencias.")
	fmt.Println("  - Haz backup de ~/.arche/ en un lugar seguro.")
	fmt.Println("  - Si pierdes la clave privada, necesitas regenerar y")
	fmt.Println("    reemplazar TODAS las licencias de clientes.")
	fmt.Println()
}

func cmdLicenseCreate() {
	fmt.Println()
	fmt.Println("  ╔══════════════════════════════════════════════════╗")
	fmt.Println("  ║    ARCHE GMAO — Nueva licencia                 ║")
	fmt.Println("  ╚══════════════════════════════════════════════════╝")
	fmt.Println()

	privKey := loadPrivateKey()
	fmt.Println("  Autorizacion correcta.")
	fmt.Println()

	clientName := readLine("  Nombre del cliente: ")
	clientID := readLine("  ID cliente (sin espacios, ej: acme-corp): ")

	fmt.Println()
	fmt.Println("  Modulos disponibles:")
	fmt.Println("  [1] core        — OTs, Fabrica Virtual, Inventario")
	fmt.Println("  [2] ai          — Arche IA con RAG")
	fmt.Println("  [3] metrics     — Metricas, KPIs, MTBF, MTTR")
	fmt.Println("  [4] preventive  — Plan preventivo automatico")
	fmt.Println("  [5] qr          — Codigos QR")
	fmt.Println("  [6] reports     — Informes PDF y Excel")
	fmt.Println("  [7] all         — Todos los modulos")

	modulesInput := readLine("\n  Modulos (ej: 1,2,3 o 7 para todos): ")
	moduleMap := map[string]string{
		"1": "core", "2": "ai", "3": "metrics",
		"4": "preventive", "5": "qr", "6": "reports",
	}

	var modules []string
	if strings.Contains(modulesInput, "7") {
		modules = []string{"core", "ai", "metrics", "preventive", "qr", "reports"}
	} else {
		modules = []string{"core"}
		for _, m := range strings.Split(modulesInput, ",") {
			m = strings.TrimSpace(m)
			if name, ok := moduleMap[m]; ok && name != "core" {
				modules = append(modules, name)
			}
		}
	}

	maxUsersStr := readLine("  Maximo de usuarios (50): ")
	maxUsers := 50
	if n, err := strconv.Atoi(maxUsersStr); err == nil && n > 0 {
		maxUsers = n
	}

	maxNodesStr := readLine("  Maximo de nodos/equipos (200): ")
	maxNodes := 200
	if n, err := strconv.Atoi(maxNodesStr); err == nil && n > 0 {
		maxNodes = n
	}

	maxTenantsStr := readLine("  Maximo de tenants/fabricas (1): ")
	maxTenants := 1
	if n, err := strconv.Atoi(maxTenantsStr); err == nil && n > 0 {
		maxTenants = n
	}

	daysStr := readLine("  Duracion en dias (365): ")
	days := 365
	if n, err := strconv.Atoi(daysStr); err == nil && n > 0 {
		days = n
	}

	hwID := readLine("  Hardware fingerprint del servidor (dejar vacio si no tienes): ")

	// Build the payload
	licenseID := make([]byte, 16)
	rand.Read(licenseID)

	payload := license.Payload{
		LicenseID:  hex.EncodeToString(licenseID),
		ClientName: clientName,
		ClientID:   clientID,
		Modules:    modules,
		MaxUsers:   maxUsers,
		MaxNodes:   maxNodes,
		MaxTenants: maxTenants,
		HardwareID: hwID,
		IssuedAt:   time.Now().UTC().Format(time.RFC3339),
		ExpiresAt:  time.Now().UTC().Add(time.Duration(days) * 24 * time.Hour).Format(time.RFC3339),
		Version:    "2.0",
	}

	payloadJSON, _ := json.Marshal(payload)

	// Sign with Ed25519
	signature := ed25519.Sign(privKey, payloadJSON)

	signed := struct {
		Payload   json.RawMessage `json:"payload"`
		Signature string          `json:"signature"`
	}{
		Payload:   payloadJSON,
		Signature: base64.StdEncoding.EncodeToString(signature),
	}

	signedJSON, _ := json.Marshal(signed)
	licenseB64 := base64.StdEncoding.EncodeToString(signedJSON)

	// Save the .key file
	filename := fmt.Sprintf("license_%s.key", clientID)
	os.WriteFile(filename, []byte(licenseB64), 0600)

	// Save the record
	saveLicenseRecord(payload)

	fmt.Println()
	fmt.Printf("  Licencia generada: %s\n", filename)
	fmt.Printf("  ID:          %s\n", payload.LicenseID)
	fmt.Printf("  Cliente:     %s\n", payload.ClientName)
	fmt.Printf("  Caduca:      %s\n", payload.ExpiresAt[:10])
	fmt.Printf("  Modulos:     %s\n", strings.Join(modules, ", "))
	fmt.Printf("  Max users:   %d\n", maxUsers)
	fmt.Printf("  Max nodos:   %d\n", maxNodes)
	if hwID != "" {
		fmt.Printf("  Hardware ID: %s\n", hwID[:16]+"...")
	}
	fmt.Println()
}

func cmdLicenseList() {
	fmt.Println()

	data, err := os.ReadFile(licensesDBPath())
	if err != nil {
		fmt.Println("  Sin licencias generadas.")
		return
	}

	var records []map[string]interface{}
	json.Unmarshal(data, &records)

	if len(records) == 0 {
		fmt.Println("  Sin licencias generadas.")
		return
	}

	fmt.Printf("  %-20s %-25s %-12s %-12s %s\n", "ID", "Cliente", "Caduca", "Generada", "HW")
	fmt.Println("  " + strings.Repeat("-", 85))
	for _, r := range records {
		id := fmt.Sprintf("%v", r["license_id"])
		if len(id) > 18 {
			id = id[:18]
		}
		hw := "no"
		if hwid, ok := r["hardware_id"].(string); ok && hwid != "" {
			hw = "si"
		}
		fmt.Printf("  %-20s %-25v %-12v %-12v %s\n",
			id, r["client_name"], str(r["expires_at"], 10), str(r["generated_at"], 10), hw)
	}
	fmt.Println()
}

func str(v interface{}, maxLen int) string {
	s := fmt.Sprintf("%v", v)
	if len(s) > maxLen {
		return s[:maxLen]
	}
	return s
}

func cmdFingerprint() {
	fp := license.HardwareFingerprint()
	fmt.Println()
	fmt.Println("  Hardware fingerprint de este servidor:")
	fmt.Printf("  %s\n", fp)
	fmt.Println()
	fmt.Println("  Envia este valor a Arche GMAO para generar tu licencia.")
	fmt.Println()
}

func cmdPubkey() {
	data, err := os.ReadFile(publicKeyPath())
	if err != nil {
		fmt.Println("  Error: No se encontro clave publica. Ejecuta 'arche init' primero.")
		os.Exit(1)
	}
	fmt.Println(strings.TrimSpace(string(data)))
}

// ─── License registry ──────────────────────────────────────────────────

func saveLicenseRecord(p license.Payload) {
	path := licensesDBPath()
	var records []map[string]interface{}

	if data, err := os.ReadFile(path); err == nil {
		json.Unmarshal(data, &records)
	}

	records = append(records, map[string]interface{}{
		"license_id":   p.LicenseID,
		"client_name":  p.ClientName,
		"client_id":    p.ClientID,
		"modules":      p.Modules,
		"max_users":    p.MaxUsers,
		"max_nodes":    p.MaxNodes,
		"hardware_id":  p.HardwareID,
		"expires_at":   p.ExpiresAt,
		"generated_at": time.Now().UTC().Format(time.RFC3339),
	})

	data, _ := json.MarshalIndent(records, "", "  ")
	os.WriteFile(path, data, 0600)
}
