package main

import (
	"log"
	"os"
	"os/signal"
	"runtime"
	"strconv"
	"syscall"

	webpush "github.com/SherClockHolmes/webpush-go"

	"arche-gmao/api/internal/config"
	"arche-gmao/api/internal/database"
	"arche-gmao/api/internal/handlers"
	"arche-gmao/api/internal/hwcheck"
	"arche-gmao/api/internal/installer"
	"arche-gmao/api/internal/license"
	"arche-gmao/api/internal/server"
)

func main() {
	if installer.NeedsSetup() {
		installer.Run()
		return
	}

	// Respect the host/container resource limits
	if v := os.Getenv("GOMAXPROCS"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			runtime.GOMAXPROCS(n)
			log.Printf("[ARCHE] GOMAXPROCS=%d", n)
		}
	}
	// Hardware check: in production it compares machine-id, MAC and IP
	// against the values recorded during installation.
	// In development (a build without the "production" tag) this function does nothing.
	hwcheck.Verify("/etc/arche/hardware.conf")
	license.Check("")

	cfg := config.Load()
	cfg.ValidateSecrets()

	// Auto-generate VAPID keys if they are not configured
	if cfg.VAPIDPublicKey == "" || cfg.VAPIDPrivateKey == "" {
		priv, pub, err := webpush.GenerateVAPIDKeys()
		if err != nil {
			log.Printf("[ARCHE] Error generando claves VAPID: %v", err)
		} else {
			cfg.VAPIDPrivateKey = priv
			cfg.VAPIDPublicKey = pub
			log.Println("[ARCHE] ═══════════════════════════════════════════════════════════")
			log.Println("[ARCHE] Claves VAPID generadas automaticamente.")
			log.Println("[ARCHE] Para que persistan entre reinicios, copie estas lineas a su .env:")
			log.Printf("[ARCHE]   VAPID_PUBLIC_KEY=%s", pub)
			log.Printf("[ARCHE]   VAPID_PRIVATE_KEY=%s", priv)
			log.Println("[ARCHE] ═══════════════════════════════════════════════════════════")
		}
	}

	db, err := database.Connect(cfg)
	if err != nil {
		log.Fatalf("[ARCHE] Error conectando a PostgreSQL: %v", err)
	}
	defer db.Close()

	// Auto-migration: applies the pending embedded SQL migrations.
	// In production the migrations are embedded in the binary.
	// In dev they are empty (applied through Docker init).
	if err := database.RunMigrations(db); err != nil {
		log.Fatalf("[ARCHE] Error aplicando migraciones: %v", err)
	}

	rdb, err := database.ConnectRedis(cfg)
	if err != nil {
		log.Fatalf("[ARCHE] Error conectando a Redis: %v", err)
	}
	defer rdb.Close()

	log.Println("[ARCHE] Conexiones establecidas. Iniciando servidor...")

	srv := server.New(cfg, db, rdb)

	// Periodic license check (every 24h)
	licenseStop := make(chan struct{})
	license.StartPeriodicCheck("", licenseStop)

	// Phone-home: validates the license against archesystem.com periodically
	phoneHomeStop := make(chan struct{})
	license.StartPhoneHome(db, handlers.Version, phoneHomeStop)

	// Graceful shutdown: catch system signals
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		<-quit
		log.Println("[ARCHE] Señal de parada recibida, cerrando...")
		close(licenseStop)
		close(phoneHomeStop)
		srv.Shutdown()
		if err := srv.App.Shutdown(); err != nil {
			log.Printf("[ARCHE] Error cerrando servidor HTTP: %v", err)
		}
	}()

	listenAddr := ":" + cfg.Port
	log.Printf("[ARCHE] API escuchando en %s", listenAddr)
	if err := srv.App.Listen(listenAddr); err != nil {
		log.Printf("[ARCHE] Servidor detenido: %v", err)
	}
}
