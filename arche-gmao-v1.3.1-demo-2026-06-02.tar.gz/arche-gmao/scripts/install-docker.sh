#!/bin/bash
# ============================================================
# install-docker.sh
# Installs Docker Engine + Docker Compose Plugin on Ubuntu
# ============================================================
set -e

echo "============================================"
echo " Arche GMAO - Instalación de dependencias"
echo "============================================"
echo ""

# Check that this is Ubuntu
if ! grep -qi ubuntu /etc/os-release 2>/dev/null; then
    echo "ADVERTENCIA: Este script está pensado para Ubuntu."
    echo "Puede funcionar en Debian u otras distros basadas en Debian."
    read -p "¿Continuar de todas formas? (s/n): " -r
    [[ ! $REPLY =~ ^[Ss]$ ]] && exit 1
fi

echo "[1/5] Actualizando paquetes..."
sudo apt-get update -q

echo "[2/5] Instalando prerequisitos..."
sudo apt-get install -y -q \
    ca-certificates \
    curl \
    gnupg \
    lsb-release

echo "[3/5] Añadiendo clave GPG de Docker..."
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
    | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

echo "[4/5] Añadiendo repositorio de Docker..."
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
  https://download.docker.com/linux/ubuntu \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" \
  | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

echo "[5/5] Instalando Docker..."
sudo apt-get update -q
sudo apt-get install -y -q \
    docker-ce \
    docker-ce-cli \
    containerd.io \
    docker-buildx-plugin \
    docker-compose-plugin

# Add the current user to the docker group
sudo usermod -aG docker "$USER"

echo ""
echo "============================================"
echo " Docker instalado correctamente"
echo "============================================"
echo ""
docker --version
docker compose version
echo ""
echo "IMPORTANTE: Debes cerrar sesion y volver a entrar para que"
echo "los cambios de grupo surtan efecto. O ejecuta:"
echo ""
echo "  newgrp docker"
echo ""
echo "Luego ve al directorio del proyecto y ejecuta:"
echo ""
echo "  make up"
echo ""
