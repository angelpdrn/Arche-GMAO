#!/usr/bin/env bash
# Arche GMAO — Exhaustive HTTP test suite
# Works like Postman/Bruno: runs hundreds of requests and records failures
set -uo pipefail

API="http://localhost:3000/api/v1"
EMAIL="admin@arche.local"
PASS="Admin@1234"
RESULTS_DIR="/tmp/arche_test_results"
mkdir -p "$RESULTS_DIR"

# Counters
TOTAL=0
PASSED=0
FAIL=0
WARN=0
FINDINGS_FILE="$RESULTS_DIR/findings.txt"
> "$FINDINGS_FILE"

log_finding() {
  local sev="$1" code="$2" expected="$3" endpoint="$4" detail="${5:-}"
  echo "[$sev] $endpoint => $code (esperado $expected) $detail" | tee -a "$FINDINGS_FILE"
}

# Test helper
# args: METHOD PATH EXPECTED_CODE [DATA] [SEVERITY_ON_FAIL] [DESC]
test_req() {
  local method="$1" path="$2" expected="$3" data="${4:-}" sev="${5:-MEDIO}" desc="${6:-}"
  TOTAL=$((TOTAL+1))
  local args=(-s -o "$RESULTS_DIR/last.json" -w "%{http_code}" -X "$method" "${API}${path}" -H "Authorization: Bearer ${TOKEN:-}")
  if [ -n "$data" ]; then
    args+=(-H "Content-Type: application/json" -d "$data")
  fi
  local code
  code=$(curl "${args[@]}")
  # Accept a |-separated expected list
  if [[ "|$expected|" == *"|$code|"* ]]; then
    PASSED=$((PASSED+1))
    return 0
  fi
  FAIL=$((FAIL+1))
  log_finding "$sev" "$code" "$expected" "$method $path" "$desc"
  if [ "$code" = "500" ]; then
    echo "    body: $(head -c 300 $RESULTS_DIR/last.json)" >> "$FINDINGS_FILE"
  fi
  return 1
}

# ─── 1. Health (no auth) ─────────────────────────────────────────────────────
echo "== HEALTH =="
TOKEN=""
test_req GET /health 200 "" CRÍTICO "health debe estar UP"

# ─── 2. AUTH ──────────────────────────────────────────────────────────────────
echo "== AUTH =="
# Good login
RESP=$(curl -s -X POST "$API/auth/login" -H "Content-Type: application/json" \
  -d "{\"email\":\"$EMAIL\",\"password\":\"$PASS\"}")
TOKEN=$(echo "$RESP" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("access_token",""))')
if [ -z "$TOKEN" ]; then
  echo "[CRÍTICO] No se pudo obtener token" | tee -a "$FINDINGS_FILE"
  exit 1
fi
echo "Token OK"

# Login with a bad email
test_req POST /auth/login 401 '{"email":"noexiste@test.com","password":"x"}' ALTO "login email inexistente debe ser 401"
# Login with an empty password
test_req POST /auth/login "400|401|422" '{"email":"admin@arche.local","password":""}' ALTO "password vacío"
# Login with invalid JSON
test_req POST /auth/login "400|422" 'not-json' MEDIO "JSON malformado"
# Login with a malformed email
test_req POST /auth/login "400|401|422" '{"email":"no-es-email","password":"Admin@1234"}' MEDIO "email malformado"
# Login with extra fields (should ignore them)
test_req POST /auth/login 200 "{\"email\":\"$EMAIL\",\"password\":\"$PASS\",\"extra\":\"x\"}" BAJO "campos extras"
# SQL injection in the email
test_req POST /auth/login "400|401" "{\"email\":\"' OR 1=1--\",\"password\":\"x\"}" CRÍTICO "SQLi email"
# Email with XSS
test_req POST /auth/login "401|400" "{\"email\":\"<script>alert(1)</script>@x.com\",\"password\":\"x\"}" ALTO "XSS email"
# Login without Content-Type
TOTAL=$((TOTAL+1)); CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$API/auth/login" -d "{\"email\":\"$EMAIL\",\"password\":\"$PASS\"}")
if [[ "$CODE" =~ ^(200|400|415)$ ]]; then PASSED=$((PASSED+1)); else FAIL=$((FAIL+1)); log_finding ALTO "$CODE" "200|400|415" "POST /auth/login (sin CT)"; fi

# Me with a valid token
test_req GET /auth/me 200 "" CRÍTICO "me debe devolver usuario"
# Me without a token
ORIG=$TOKEN; TOKEN=""
test_req GET /auth/me 401 "" CRÍTICO "me sin auth debe 401"
TOKEN=$ORIG
# Me with a corrupt token
ORIG=$TOKEN; TOKEN="xxx.yyy.zzz"
test_req GET /auth/me "401" "" CRÍTICO "me con token corrupto debe 401"
TOKEN=$ORIG
# Me with a forged HS512
ORIG=$TOKEN; TOKEN="eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0.eyJ1c2VyX2lkIjo5OTksInRlbmFudF9pZCI6OTk5LCJyb2xlIjoiYWRtaW4ifQ."
test_req GET /auth/me 401 "" CRÍTICO "JWT alg=none debe rechazarse"
TOKEN=$ORIG

# Refresh without a cookie
test_req POST /auth/refresh "401|400" '{}' MEDIO "refresh sin cookie"

# ─── 3. PROTECTED ROUTES — no token ──────────────────────────────────────────
echo "== AUTH ENFORCEMENT =="
ORIG=$TOKEN; TOKEN=""
PROTECTED_ROUTES=(
  "/factory/tree" "/factory/search" "/users" "/clients/" "/work-orders/" "/spare-parts/"
  "/library/all" "/personnel/" "/calendar/" "/directories/?section=general" "/templates/" "/maintenance-plans/"
  "/notifications/" "/ai/status" "/patterns/" "/reports/spare-parts/excel" "/metrics/summary"
  "/factory/health/summary" "/procedures/" "/daily-summaries/" "/system/status" "/license/info"
  "/superadmin/whoami" "/node-types"
)
for r in "${PROTECTED_ROUTES[@]}"; do
  test_req GET "$r" 401 "" CRÍTICO "ruta protegida sin token"
done
TOKEN=$ORIG

# ─── 4. PUBLIC GET ROUTES ────────────────────────────────────────────────────
echo "== GETs PROTEGIDOS CON TOKEN =="
for r in "${PROTECTED_ROUTES[@]}"; do
  test_req GET "$r" "200|403|404" "" ALTO "GET con token admin"
done

# ─── 5. NODES ─────────────────────────────────────────────────────────────────
echo "== NODOS =="
# List the tree
test_req GET /factory/tree 200 "" CRÍTICO ""
# Get a non-existent node
test_req GET /factory/nodes/999999 "404|403" "" ALTO "nodo inexistente"
# Get a node with a non-numeric id
test_req GET /factory/nodes/abc "400|404" "" MEDIO "id no numérico"
# Get a negative node
test_req GET /factory/nodes/-1 "400|404|403" "" MEDIO "id negativo"
# Create a node without a name
test_req POST /factory/nodes "400|422" '{}' MEDIO "POST sin payload"
# Create a node with an invalid type
test_req POST /factory/nodes "400|422" '{"name":"Test","node_type":"inventado"}' ALTO "node_type inválido"
# Search with a short query
test_req GET "/factory/search?q=a" "200|400" "" BAJO "search 1 char"

# ─── 6. WORK ORDERS ──────────────────────────────────────────────────────────
echo "== WORK ORDERS =="
test_req GET /work-orders/ 200 "" CRÍTICO ""
test_req GET "/work-orders/?status=pending" 200 "" BAJO ""
test_req GET "/work-orders/?status=invalid_status" "200|400" "" MEDIO "status inválido"
test_req GET /work-orders/999999 "404" "" ALTO "OT inexistente"
test_req GET /work-orders/abc "400|404" "" MEDIO "id no numérico"
# Create an incomplete WO
test_req POST /work-orders/ "400|422" '{}' MEDIO "POST OT vacía"
test_req POST /work-orders/ "400|422" '{"title":"x"}' MEDIO "POST OT sin node_id"
# State change to an invalid status
test_req PATCH /work-orders/1/status "400|404|422" '{"status":"frobnicate"}' ALTO "estado libre permitido"
# Comment without text
test_req POST /work-orders/1/comments "400|404|422" '{}' MEDIO "comentario vacío"
# Offline bundle
test_req GET /work-orders/offline-bundle "200|404" "" ALTO ""

# ─── 7. USERS ────────────────────────────────────────────────────────────────
echo "== USERS =="
test_req GET /users 200 "" CRÍTICO ""
# Create with a duplicate email
test_req POST /users "400|409|422" "{\"email\":\"$EMAIL\",\"password\":\"abc\",\"full_name\":\"X\",\"role\":\"technician\"}" ALTO "email duplicado"
# Create with a weak password
test_req POST /users "400|422" '{"email":"new1@test.com","password":"123","full_name":"X","role":"technician"}' ALTO "password débil aceptada"
# Create with an invalid role
test_req POST /users "400|422" '{"email":"new2@test.com","password":"GoodPass@1","full_name":"X","role":"hacker"}' ALTO "rol inválido aceptado"
# Create without an email
test_req POST /users "400|422" '{"password":"GoodPass@1","full_name":"X","role":"technician"}' MEDIO "sin email"
# Delete an admin (should be blocked)
test_req DELETE /users/1 "400|403" "" CRÍTICO "borrar admin principal"

# ─── 8. CLIENTS ─────────────────────────────────────────────────────────────
echo "== CLIENTES =="
test_req GET /clients/ 200 "" ALTO ""
test_req POST /clients/ "400|422" '{}' MEDIO "cliente vacío"
test_req POST /clients/ "200|201|400|409" '{"name":"Cliente Test","code":"CLI-T1","contact_name":"X","email":"c@t.com"}' ALTO "crear cliente"

# ─── 9. INVENTORY ───────────────────────────────────────────────────────────
echo "== SPARES =="
test_req GET /spare-parts/ 200 "" ALTO ""
test_req POST /spare-parts/ "400|422" '{}' MEDIO "spare vacío"
test_req POST /spare-parts/1/movements "400|404|422" '{}' MEDIO "movement vacío"
test_req POST /spare-parts/1/movements "400|404|422" '{"quantity":-99999999,"type":"out"}' ALTO "stock negativo gigante"

# ─── 10. CALENDAR ────────────────────────────────────────────────────────────
echo "== CALENDAR =="
test_req GET /calendar/ "200" "" ALTO ""
test_req GET "/calendar/upcoming?days=7" 200 "" BAJO ""
test_req GET "/calendar/upcoming?days=99999999" "200|400" "" MEDIO "days enorme"
test_req GET "/calendar/upcoming?days=-1" "200|400" "" MEDIO "days negativo"
test_req POST /calendar/ "400|422" '{}' MEDIO "calendar vacío"

# ─── 11. DIRECTORIES ─────────────────────────────────────────────────────────
echo "== DIRECTORIES =="
test_req GET "/directories/?section=general" 200 "" MEDIO ""
test_req POST /directories/ "400|422" '{}' MEDIO ""
test_req POST /directories/999999/verify-pin "400|404" '{"pin":"000000"}' MEDIO ""

# ─── 12. TEMPLATES ───────────────────────────────────────────────────────────
echo "== TEMPLATES =="
test_req GET /templates/ 200 "" ALTO ""
test_req GET /templates/categories 200 "" BAJO ""
test_req POST /templates/ "400|422" '{}' MEDIO ""

# ─── 13. MAINTENANCE PLANS ────────────────────────────────────────────────────
echo "== MAINTENANCE PLANS =="
test_req GET /maintenance-plans/ "200|403" "" ALTO ""
test_req GET /maintenance-plans/upcoming "200|403" "" BAJO ""
test_req GET /maintenance-plans/compliance "200|403" "" BAJO ""
test_req POST /maintenance-plans/ "400|422|403" '{}' MEDIO ""

# ─── 14. AI ──────────────────────────────────────────────────────────────────
echo "== AI =="
test_req GET /ai/status "200|403" "" MEDIO ""
test_req POST /ai/chat "400|422|429|403" '{"message":""}' MEDIO "chat vacío"
test_req GET /ai/conversations "200|403" "" BAJO ""

# ─── 15. METRICS / REPORTS ────────────────────────────────────────────────────
echo "== METRICS / REPORTS =="
test_req GET /metrics/summary "200|403" "" ALTO ""
test_req GET /metrics/equipment "200|403" "" ALTO ""
test_req GET /metrics/trends "200|403" "" ALTO ""
test_req GET /metrics/technicians "200|403" "" ALTO ""
test_req GET /metrics/spare-parts "200|403" "" ALTO ""
test_req GET /metrics/corrective-ratio "200|403" "" ALTO ""
test_req GET /metrics/alerts-summary "200|403" "" ALTO ""
test_req GET "/metrics/trends?from=invalid&to=invalid" "200|400|403" "" MEDIO ""
test_req GET /reports/wo/999999/data "404|403" "" ALTO ""
test_req GET /reports/wo/999999/html "404|403" "" ALTO ""
test_req GET /reports/spare-parts/excel "200|403" "" ALTO ""
test_req GET /reports/work-orders/excel "200|403" "" ALTO ""

# ─── 16. NOTIFICATIONS ───────────────────────────────────────────────────────
echo "== NOTIFICACIONES =="
test_req GET /notifications/ 200 "" ALTO ""
test_req GET /notifications/preferences 200 "" BAJO ""
test_req PATCH /notifications/read-all 200 '{}' BAJO ""
test_req PATCH /notifications/999999/read "200|404" "" BAJO ""
test_req GET /notifications/smtp 200 "" BAJO ""

# ─── 17. SUPERADMIN (admin should have no access) ───────────────────────────
echo "== SUPERADMIN =="
test_req GET /superadmin/whoami "403" "" CRÍTICO "admin NO debería ver superadmin"
test_req GET /superadmin/tenants "403" "" CRÍTICO "admin NO debería listar tenants"

# ─── 18. PROFILE ──────────────────────────────────────────────────────────────
echo "== PROFILE =="
test_req GET /users/1/profile 200 "" ALTO ""
test_req GET /users/999999/profile "200|404" "" MEDIO ""
test_req PATCH /users/1/change-password "400|401|422|429" '{}' MEDIO ""
test_req PATCH /users/1/change-password "400|401|422|429" '{"current_password":"x","new_password":"x"}' ALTO ""

# ─── 19. SYSTEM ──────────────────────────────────────────────────────────────
echo "== SISTEMA =="
test_req GET /system/status 200 "" ALTO ""
test_req GET /system/retention 200 "" BAJO ""

# ─── 20. RATE LIMITING — Rapid fire login ─────────────────────────────────────
echo "== RATE LIMITING =="
LIMITED=0
for i in $(seq 1 15); do
  CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$API/auth/login" \
    -H "Content-Type: application/json" -d '{"email":"x@x.com","password":"x"}')
  if [ "$CODE" = "429" ]; then LIMITED=1; break; fi
done
TOTAL=$((TOTAL+1))
if [ "$LIMITED" = "1" ]; then PASSED=$((PASSED+1)); else FAIL=$((FAIL+1)); log_finding ALTO "no-429" "429" "/auth/login rapid" "rate limit no se activó tras 15 intentos"; fi

# ─── 21. HUGE PAYLOAD ──────────────────────────────────────────────────────
echo "== PAYLOAD LIMITS =="
HUGE=$(python3 -c "import json; print(json.dumps({'name':'x'*60_000_000}))")
TOTAL=$((TOTAL+1))
CODE=$(echo -n "$HUGE" | curl -s -o /dev/null -w "%{http_code}" -X POST "$API/factory/nodes" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" --data-binary @-)
if [[ "$CODE" =~ ^(400|413|422)$ ]]; then PASSED=$((PASSED+1)); else FAIL=$((FAIL+1)); log_finding ALTO "$CODE" "400|413|422" "POST /factory/nodes payload 60MB"; fi
unset HUGE

# ─── 22. PATH TRAVERSAL on download ──────────────────────────────────────────
echo "== PATH TRAVERSAL =="
test_req GET "/factory/nodes/1/manuals/..%2F..%2F..%2Fetc%2Fpasswd/download" "400|404" "" CRÍTICO ""
test_req GET "/factory/nodes/1/manuals/abc/download" "400|404" "" MEDIO ""

# ─── 23. CROSS-TENANT (try to reach tenant 2) ───────────────────────────
echo "== CROSS-TENANT =="
# Creating a second tenant needs a superadmin — here we only check that routes require a tenant
# Tampering with tenant_id in the JWT should not be possible (signature) — already covered by the corrupt JWT case

# ─── SUMMARY ──────────────────────────────────────────────────────────────────
echo ""
echo "════════════════════════════════════════"
echo "TOTAL: $TOTAL   PASSED: $PASSED   FAIL: $FAIL"
echo "════════════════════════════════════════"
echo ""
echo "Hallazgos en: $FINDINGS_FILE"
