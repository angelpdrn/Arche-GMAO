-- ============================================================
-- BonArea Demo - Block 07: Preventive maintenance plans
-- ============================================================
-- ~12 maintenance_plans with instructions, checklist, safety_notes,
-- tools_required and required_parts. Some overdue so the
-- "overdue preventive" detector shows up.
-- ============================================================

BEGIN;

-- User IDs
DO $$
DECLARE
    u_admin BIGINT;
    u_caristiven BIGINT;
    u_angel BIGINT;
BEGIN
    SELECT id INTO u_admin      FROM users WHERE email='admin@arche.local';
    SELECT id INTO u_caristiven FROM users WHERE email='caristiven.padrino@bonarea.local';
    SELECT id INTO u_angel      FROM users WHERE email='angel.padrino@bonarea.local';

    -- ── Plan 1: Robot ABB - Lubricación cojinetes (cada 90 días) ───────────
    INSERT INTO maintenance_plans
        (tenant_id, node_id, title, description, wo_type, priority,
         frequency_type, frequency_value, advance_days, assigned_to, estimated_hours,
         is_active, last_executed_at, next_due_at, total_executions, created_by,
         instructions, checklist, safety_notes, tools_required, required_parts)
    VALUES
    (1, (SELECT id FROM bonarea_demo_ids WHERE key='robot'),
     'PM-90: Lubricación cojinetes robot ABB',
     'Lubricación trimestral de los cojinetes de los brazos paralelos del robot delta IRB 360.',
     'preventive', 'high',
     'days', 90, 7, u_angel, 1.5,
     true, NOW() - INTERVAL '15 days', NOW() + INTERVAL '75 days', 12, u_admin,
     E'1. Aislar el robot mediante el seccionador principal.\n2. Realizar bloqueo y etiquetado (LOTO).\n3. Limpiar los puntos de engrase con paño limpio.\n4. Aplicar 5 g de Mobilith SHC 220 en cada cojinete (8 puntos).\n5. Mover manualmente los brazos para distribuir.\n6. Limpiar excesos.\n7. Quitar LOTO y reanudar.',
     '[
        {"step":"Robot aislado eléctricamente","required":true},
        {"step":"LOTO colocado","required":true},
        {"step":"Puntos limpios sin restos antiguos","required":true},
        {"step":"Grasa aplicada en los 8 cojinetes","required":true},
        {"step":"Movimiento manual sin ruidos","required":true},
        {"step":"LOTO retirado y producción reanudada","required":true}
     ]'::jsonb,
     E'⚠ Riesgo de aplastamiento por movimiento del robot.\n⚠ Riesgo eléctrico si LOTO no se aplica correctamente.\n⚠ Verificar que el cerramiento perimetral está cerrado al reanudar.',
     '["Pistola de engrase manual","Paños sin pelusa","Cartucho Mobilith SHC 220","Llave permiso PRL"]'::jsonb,
     '[{"code":"RP-ABB-GRASA-MOBI","qty":1}]'::jsonb);

    -- ── Plan 2: Robot ABB - Tensión correa GT2 (cada 30 días) ──────────────
    INSERT INTO maintenance_plans
        (tenant_id, node_id, title, description, wo_type, priority,
         frequency_type, frequency_value, advance_days, assigned_to, estimated_hours,
         is_active, last_executed_at, next_due_at, total_executions, created_by,
         instructions, checklist, safety_notes, tools_required, required_parts)
    VALUES
    (1, (SELECT id FROM bonarea_demo_ids WHERE key='robot'),
     'PM-30: Inspección correa GT2 robot ABB',
     'Inspección visual y verificación de tensión de la correa de la rótula central del robot.',
     'preventive', 'medium',
     'days', 30, 5, u_angel, 0.5,
     true, NOW() - INTERVAL '5 days', NOW() + INTERVAL '25 days', 24, u_admin,
     E'1. LOTO.\n2. Abrir tapa de inspección de la rótula central.\n3. Aplicar 10 N en el punto medio de la correa con dinamómetro.\n4. Medir deflexión (debe ser 3-5 mm).\n5. Inspeccionar dientes de la correa: descartar si hay roturas o desgaste lateral.\n6. Cerrar tapa y quitar LOTO.',
     '[{"step":"LOTO colocado"},{"step":"Tensión 3-5 mm OK"},{"step":"Sin roturas en dientes"},{"step":"Tapa cerrada"}]'::jsonb,
     E'⚠ Riesgo eléctrico. LOTO obligatorio.',
     '["Dinamómetro digital","Llave Allen 4 mm","Linterna LED"]'::jsonb,
     '[]'::jsonb);

    -- ── Plan 3: Cognex - Limpieza objetivo (semanal) ───────────────────────
    INSERT INTO maintenance_plans
        (tenant_id, node_id, title, description, wo_type, priority,
         frequency_type, frequency_value, advance_days, assigned_to, estimated_hours,
         is_active, last_executed_at, next_due_at, total_executions, created_by,
         instructions, checklist, safety_notes, tools_required, required_parts)
    VALUES
    (1, (SELECT id FROM bonarea_demo_ids WHERE key='vision'),
     'PM-7: Limpieza óptica Cognex',
     'Limpieza semanal del objetivo y del iluminador anular de la cámara.',
     'preventive', 'medium',
     'days', 7, 2, u_angel, 0.25,
     true, NOW() - INTERVAL '3 days', NOW() + INTERVAL '4 days', 48, u_admin,
     E'1. Detener línea desde HMI.\n2. Limpiar objetivo con paño microfibra y VL-CL.\n3. Limpiar iluminador LED.\n4. Verificar imagen patrón en EasyBuilder.\n5. Reanudar producción.',
     '[{"step":"Línea detenida"},{"step":"Objetivo limpio"},{"step":"Iluminador limpio"},{"step":"Imagen patrón OK"}]'::jsonb,
     E'No usar disolventes agresivos. La cámara es sensible al ESD.',
     '["Paño microfibra","Limpiador Cognex VL-CL"]'::jsonb,
     '[{"code":"RP-COG-LENS-CL","qty":0.05}]'::jsonb);

    -- ── Plan 4: Cintas A/B/C - Tensión banda + lubricación (60 días) ───────
    INSERT INTO maintenance_plans
        (tenant_id, node_id, title, description, wo_type, priority,
         frequency_type, frequency_value, advance_days, assigned_to, estimated_hours,
         is_active, last_executed_at, next_due_at, total_executions, created_by,
         instructions, checklist, safety_notes, tools_required, required_parts,
         apply_to_children)
    VALUES
    (1, (SELECT id FROM bonarea_demo_ids WHERE key='cinta_a'),
     'PM-60: Tensión banda + lubricación cinta A',
     'Verificación de tensión de la banda modular y lubricación de los rodamientos del rodillo motriz.',
     'preventive', 'medium',
     'days', 60, 5, u_angel, 1.0,
     true, NOW() - INTERVAL '40 days', NOW() + INTERVAL '20 days', 8, u_admin,
     E'1. LOTO.\n2. Abrir carro tensor y medir tensión actual (25-30 N/m).\n3. Reapretar tornillos del carro si procede.\n4. Lubricar rodamientos del rodillo motriz.\n5. Verificar alineación de la banda.\n6. Quitar LOTO.',
     '[{"step":"LOTO"},{"step":"Tensión OK"},{"step":"Lubricación realizada"},{"step":"Banda alineada"}]'::jsonb,
     E'⚠ Aplastamiento por banda en movimiento. LOTO obligatorio.',
     '["Llave dinamométrica","Pistola engrase","Linterna"]'::jsonb,
     '[]'::jsonb,
     false);

    -- Cinta B - aumentar frecuencia por desgaste recurrente
    INSERT INTO maintenance_plans
        (tenant_id, node_id, title, description, wo_type, priority,
         frequency_type, frequency_value, advance_days, assigned_to, estimated_hours,
         is_active, last_executed_at, next_due_at, total_executions, created_by,
         instructions, checklist, safety_notes, tools_required, required_parts)
    VALUES
    (1, (SELECT id FROM bonarea_demo_ids WHERE key='cinta_b'),
     'PM-30 reforzado: Cinta B (chorizo) - Inspección RollerDrive',
     'Inspección reforzada de la cinta B por histórico de fallos en motor RollerDrive.',
     'preventive', 'high',
     'days', 30, 5, u_angel, 1.0,
     true, NOW() - INTERVAL '50 days', NOW() - INTERVAL '20 days', 4, u_admin,
     E'1. LOTO completo.\n2. Termografía del motor: descartar >75 °C.\n3. Inspección visual de cojinetes y rodamiento 6203.\n4. Limpieza de partículas grasas en el rodillo motriz.\n5. Comprobar par de apriete (12 Nm).\n6. Cambiar rodamientos si hay holgura.\n7. Quitar LOTO.',
     '[{"step":"LOTO"},{"step":"Termografía OK"},{"step":"Sin holgura en rodamientos"},{"step":"Limpieza grasa producto"},{"step":"Par 12 Nm OK"}]'::jsonb,
     E'⚠ Aplastamiento. Producto graso: superficie deslizante.\n⚠ Si motor >75 °C, sustitución inmediata, no esperar.',
     '["Cámara termográfica FLIR","Llave dinamométrica","Linterna","Paño limpieza"]'::jsonb,
     '[{"code":"RP-INT-RODAM-6203","qty":2}]'::jsonb);

    -- ── Plan 5: Pesadora MULTIPOND - Calibración semanal ────────────────────
    INSERT INTO maintenance_plans
        (tenant_id, node_id, title, description, wo_type, priority,
         frequency_type, frequency_value, advance_days, assigned_to, estimated_hours,
         is_active, last_executed_at, next_due_at, total_executions, created_by,
         instructions, checklist, safety_notes, tools_required, required_parts)
    VALUES
    (1, (SELECT id FROM bonarea_demo_ids WHERE key='pesadora'),
     'PM-7: Calibración pesadora MULTIPOND',
     'Calibración semanal de las 14 células de carga con pesa patrón.',
     'preventive', 'high',
     'days', 7, 2, u_angel, 0.75,
     true, NOW() - INTERVAL '2 days', NOW() + INTERVAL '5 days', 50, u_admin,
     E'1. Acceder a menú Mantenimiento → Calibración.\n2. Por cada cabeza: colocar pesa patrón 200 g.\n3. Verificar lectura ±0.2 g.\n4. Si fuera de tolerancia: tarar y recalibrar.\n5. Si recalibración no soluciona, sustituir célula.\n6. Imprimir certificado.',
     '[{"step":"14 cabezas calibradas"},{"step":"Tolerancia ±0.2 g"},{"step":"Certificado impreso y archivado"}]'::jsonb,
     E'Higiene: lavar manos antes y después.',
     '["Pesa patrón 200 g F1","Guantes nitrilo","Impresora térmica"]'::jsonb,
     '[]'::jsonb);

    -- ── Plan 6: Pesadora - Limpieza CIP fin de turno (diario) ──────────────
    INSERT INTO maintenance_plans
        (tenant_id, node_id, title, description, wo_type, priority,
         frequency_type, frequency_value, advance_days, assigned_to, estimated_hours,
         is_active, last_executed_at, next_due_at, total_executions, created_by,
         instructions, checklist, safety_notes, tools_required, required_parts)
    VALUES
    (1, (SELECT id FROM bonarea_demo_ids WHERE key='pesadora'),
     'PM-1: Limpieza CIP fin de turno pesadora',
     'Limpieza CIP diaria al final del último turno productivo.',
     'preventive', 'medium',
     'days', 1, 1, u_angel, 0.5,
     true, NOW() - INTERVAL '1 day', NOW(), 200, u_admin,
     E'1. Activar modo CIP en HMI.\n2. Verificar cierre de tolvas.\n3. Lanzar ciclo (60 °C, detergente 2%, aclarado 30 s).\n4. Verificar conductividad final <50 µS.\n5. Salir de modo CIP.',
     '[{"step":"CIP completado"},{"step":"Conductividad <50 µS"},{"step":"Sin residuos visibles"}]'::jsonb,
     E'⚠ Quemadura por agua caliente. EPI obligatorio: guantes y gafas.',
     '["EPI estándar","Reserva detergente BonArea-CL12"]'::jsonb,
     '[]'::jsonb);

    -- ── Plan 7: Etiquetadora - Sustitución consumibles (mensual) ───────────
    INSERT INTO maintenance_plans
        (tenant_id, node_id, title, description, wo_type, priority,
         frequency_type, frequency_value, advance_days, assigned_to, estimated_hours,
         is_active, last_executed_at, next_due_at, total_executions, created_by,
         instructions, checklist, safety_notes, tools_required, required_parts)
    VALUES
    (1, (SELECT id FROM bonarea_demo_ids WHERE key='etiqueta'),
     'PM-30: Cambio tinta + makeup etiquetadora',
     'Sustitución mensual de cartucho de tinta y solvente makeup.',
     'preventive', 'medium',
     'days', 30, 5, u_angel, 0.5,
     true, NOW() - INTERVAL '10 days', NOW() + INTERVAL '20 days', 12, u_admin,
     E'1. Apagar la etiquetadora desde HMI.\n2. Sustituir cartucho de tinta agotado.\n3. Sustituir bidón de makeup.\n4. Purga 30 s.\n5. Test de impresión.',
     '[{"step":"Tinta nueva colocada"},{"step":"Makeup nuevo"},{"step":"Test impresión OK"}]'::jsonb,
     E'Tintas con solventes orgánicos: trabajar en zona ventilada, EPI.',
     '["Guantes nitrilo","Gafas protección","Bolsa residuos peligrosos"]'::jsonb,
     '[{"code":"RP-MAR-TINTA-CIJ","qty":1},{"code":"RP-MAR-MAKEUP","qty":1}]'::jsonb);

    -- ── Plan 8: Selladora CRYOVAC - Verificación HACCP (diario) ────────────
    INSERT INTO maintenance_plans
        (tenant_id, node_id, title, description, wo_type, priority,
         frequency_type, frequency_value, advance_days, assigned_to, estimated_hours,
         is_active, last_executed_at, next_due_at, total_executions, created_by,
         instructions, checklist, safety_notes, tools_required, required_parts)
    VALUES
    (1, (SELECT id FROM bonarea_demo_ids WHERE key='selladora'),
     'PM-1: Verificación HACCP selladora CRYOVAC',
     'Comprobación diaria del PCC de temperatura del túnel de retracción.',
     'preventive', 'critical',
     'days', 1, 1, u_caristiven, 0.25,
     true, NOW() - INTERVAL '1 day', NOW(), 200, u_admin,
     E'1. Verificar temperatura del túnel: 88-92 °C.\n2. Verificar caudal de vapor (4-6 bar).\n3. Anotar lectura en registro HACCP.\n4. Si T<85 °C >2 min: bloquear lote y avisar a calidad.',
     '[{"step":"Temperatura 88-92 °C"},{"step":"Vapor 4-6 bar"},{"step":"Registro HACCP firmado"}]'::jsonb,
     E'⚠ Quemaduras por vapor. EPI clase 3 obligatorio.',
     '["EPI clase 3","Cuaderno HACCP","Termómetro patrón"]'::jsonb,
     '[]'::jsonb);

    -- ── Plan 9: Selladora - Limpieza boquillas (semestral) ─────────────────
    INSERT INTO maintenance_plans
        (tenant_id, node_id, title, description, wo_type, priority,
         frequency_type, frequency_value, advance_days, assigned_to, estimated_hours,
         is_active, last_executed_at, next_due_at, total_executions, created_by,
         instructions, checklist, safety_notes, tools_required, required_parts)
    VALUES
    (1, (SELECT id FROM bonarea_demo_ids WHERE key='selladora'),
     'PM-180: Limpieza/sustitución boquillas vapor',
     'Limpieza profunda de las 12 boquillas del túnel. Si hay obstrucción persistente, sustitución completa del juego.',
     'preventive', 'high',
     'months', 6, 14, u_angel, 4.0,
     true, NOW() - INTERVAL '120 days', NOW() + INTERVAL '60 days', 2, u_admin,
     E'1. LOTO completo (eléctrico + vapor).\n2. Esperar enfriamiento 30 min.\n3. Desmontar tapa lateral.\n4. Extraer 12 boquillas con llave T-14.\n5. Limpieza ultrasónica 20 min.\n6. Inspección: si hay deformación → sustituir juego completo.\n7. Montar con par 8 Nm + sellador anaeróbico.\n8. Test de hermeticidad.',
     '[{"step":"LOTO completo"},{"step":"Enfriamiento >30 min"},{"step":"Boquillas limpias o sustituidas"},{"step":"Test hermeticidad OK"}]'::jsonb,
     E'⚠ ALTA QUEMADURA. ⚠ Vapor a presión: bloqueo válvula obligatorio.',
     '["Llave T-14","Baño ultrasónico","Sellador Loctite 577","Llave dinamométrica","EPI clase 3"]'::jsonb,
     '[{"code":"RP-CRY-NZL-12","qty":1,"only_if_failed":true}]'::jsonb);

    -- ── Plan 10: PLC - Backup configuración (mensual) ──────────────────────
    INSERT INTO maintenance_plans
        (tenant_id, node_id, title, description, wo_type, priority,
         frequency_type, frequency_value, advance_days, assigned_to, estimated_hours,
         is_active, last_executed_at, next_due_at, total_executions, created_by,
         instructions, checklist, safety_notes, tools_required, required_parts)
    VALUES
    (1, (SELECT id FROM bonarea_demo_ids WHERE key='plc'),
     'PM-30: Backup PLC + verificación pila',
     'Backup mensual del programa del PLC y verificación de la pila CR2032 de la CPU.',
     'preventive', 'medium',
     'days', 30, 5, u_caristiven, 0.5,
     true, NOW() - INTERVAL '8 days', NOW() + INTERVAL '22 days', 12, u_admin,
     E'1. TIA Portal: conectar al PLC.\n2. Upload del programa actual a backup remoto.\n3. Verificar voltaje pila (>2.8 V).\n4. Sustituir si <2.8 V.\n5. Anotar versión en logbook.',
     '[{"step":"Backup creado"},{"step":"Voltaje pila OK"},{"step":"Versión anotada"}]'::jsonb,
     E'No descargar el programa al PLC durante producción salvo necesidad.',
     '["Portátil con TIA Portal V18","Cable PROFINET","Multímetro"]'::jsonb,
     '[{"code":"RP-SIE-CR2032","qty":1,"only_if_low_voltage":true}]'::jsonb);

    -- ── Plan 11: Compresor - Cambio aceite (cada 4000h ≈ 6 meses) ──────────
    INSERT INTO maintenance_plans
        (tenant_id, node_id, title, description, wo_type, priority,
         frequency_type, frequency_value, advance_days, assigned_to, estimated_hours,
         is_active, last_executed_at, next_due_at, total_executions, created_by,
         instructions, checklist, safety_notes, tools_required, required_parts)
    VALUES
    (1, (SELECT id FROM bonarea_demo_ids WHERE key='compresor'),
     'PM-180: Cambio aceite + filtros compresor Atlas Copco',
     'Cambio de aceite Roto-Xtend, filtro aceite y filtro separador. Equivalente a 4000 h de funcionamiento.',
     'preventive', 'high',
     'months', 6, 14, u_angel, 3.0,
     true, NOW() - INTERVAL '170 days', NOW() + INTERVAL '10 days', 2, u_admin,
     E'1. Despresurizar el calderín.\n2. Vaciar aceite usado (recipiente residuos).\n3. Sustituir filtro aceite y separador.\n4. Llenar con 7.5 L Roto-Xtend Duty Fluid.\n5. Arrancar y verificar fugas durante 30 min.\n6. Reset contador horas Service Plan A.',
     '[{"step":"Aceite drenado"},{"step":"Filtros nuevos"},{"step":"7.5 L aceite"},{"step":"Sin fugas en 30 min"},{"step":"Contador reseteado"}]'::jsonb,
     E'⚠ Riesgo presión residual: despresurizar antes.\n⚠ Aceite usado = residuo peligroso, gestionar como tal.',
     '["Bandeja recolección","Llave de filtros","Embudo limpio","Recipiente homologado residuo aceite usado"]'::jsonb,
     '[{"code":"RP-ATL-OIL-ROTO","qty":0.4},{"code":"RP-ATL-FILT-OIL","qty":1},{"code":"RP-ATL-FILT-SEP","qty":1}]'::jsonb);

    -- ── Plan 12: Compresor - Limpieza filtro aire (cada 30 días) ───────────
    INSERT INTO maintenance_plans
        (tenant_id, node_id, title, description, wo_type, priority,
         frequency_type, frequency_value, advance_days, assigned_to, estimated_hours,
         is_active, last_executed_at, next_due_at, total_executions, created_by,
         instructions, checklist, safety_notes, tools_required, required_parts)
    VALUES
    (1, (SELECT id FROM bonarea_demo_ids WHERE key='compresor'),
     'PM-30: Inspección filtro aire compresor',
     'Inspección y limpieza del filtro de aire de admisión del compresor.',
     'preventive', 'low',
     'days', 30, 5, u_angel, 0.25,
     true, NOW() - INTERVAL '6 days', NOW() + INTERVAL '24 days', 12, u_admin,
     E'1. Apagar compresor desde HMI.\n2. Aflojar mariposas y extraer filtro.\n3. Soplar con aire seco a 6 bar (¡no a más!).\n4. Si está dañado o saturado: sustituir.\n5. Montar con junta nueva si procede.',
     '[{"step":"Compresor apagado"},{"step":"Filtro inspeccionado"},{"step":"Limpio o sustituido"}]'::jsonb,
     E'No usar aire >6 bar: rompe el material filtrante.',
     '["Pistola aire","Trapo limpio"]'::jsonb,
     '[{"code":"RP-ATL-FILT-AIR","qty":1,"only_if_damaged":true}]'::jsonb);

END $$;

COMMIT;

-- Verification
SELECT id, title,
       CASE WHEN next_due_at < NOW() THEN '⚠ VENCIDO'
            WHEN next_due_at < NOW() + INTERVAL '7 days' THEN '⏰ próximo'
            ELSE 'OK' END AS estado,
       to_char(next_due_at, 'YYYY-MM-DD HH24:MI') AS proximo,
       total_executions
  FROM maintenance_plans WHERE tenant_id=1 ORDER BY next_due_at;
