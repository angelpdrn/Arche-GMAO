-- ============================================================
-- BonArea Demo - Block 01: Client + Users
-- ============================================================
-- Idempotent: uses ON CONFLICT where applicable.
-- Tenant 1 = Arche GMAO (preserved).
-- Primary admin preserved.
-- ============================================================

BEGIN;

-- Clean up the leftover test client (it should have no references yet)
DELETE FROM clients WHERE tenant_id = 1 AND code = 'CLI-T1';

-- ─── CLIENT: BonArea SCA ──────────────────────────────────────────────────
INSERT INTO clients (tenant_id, name, code, client_type, status,
                     contact_name, contact_email, contact_phone, notes)
VALUES (1, 'BonArea SCA', 'BONAREA',
        'internal', 'active',
        'Departamento de Mantenimiento',
        'mantenimiento@bonarea.com',
        '+34 973 55 00 00',
        'Cooperativa agrícola y ganadera. Planta cárnica de Guissona (Lleida). Demo CMMS Arche GMAO.')
ON CONFLICT (tenant_id, code) DO UPDATE SET
    name = EXCLUDED.name,
    client_type = EXCLUDED.client_type,
    contact_name = EXCLUDED.contact_name,
    contact_email = EXCLUDED.contact_email,
    contact_phone = EXCLUDED.contact_phone,
    notes = EXCLUDED.notes;

-- ─── USERS (4 + the existing admin) ────────────────────────────────────────
-- Shared password: Admin@1234 (same as the primary admin)
-- bcrypt cost 10

-- Andrés Padrino — Warehouse
INSERT INTO users (tenant_id, email, password_hash, full_name, role, status)
VALUES (1, 'andres.padrino@bonarea.local',
        crypt('Admin@1234', gen_salt('bf', 10)),
        'Andrés Padrino', 'warehouse', 'active')
ON CONFLICT (tenant_id, email) DO UPDATE SET
    password_hash = EXCLUDED.password_hash,
    full_name = EXCLUDED.full_name,
    role = EXCLUDED.role,
    status = 'active';

-- Caristiven Padrino — Supervisor
INSERT INTO users (tenant_id, email, password_hash, full_name, role, status)
VALUES (1, 'caristiven.padrino@bonarea.local',
        crypt('Admin@1234', gen_salt('bf', 10)),
        'Caristiven Padrino', 'supervisor', 'active')
ON CONFLICT (tenant_id, email) DO UPDATE SET
    password_hash = EXCLUDED.password_hash,
    full_name = EXCLUDED.full_name,
    role = EXCLUDED.role,
    status = 'active';

-- Ángel Padrino — Technician
INSERT INTO users (tenant_id, email, password_hash, full_name, role, status)
VALUES (1, 'angel.padrino@bonarea.local',
        crypt('Admin@1234', gen_salt('bf', 10)),
        'Ángel Padrino', 'technician', 'active')
ON CONFLICT (tenant_id, email) DO UPDATE SET
    password_hash = EXCLUDED.password_hash,
    full_name = EXCLUDED.full_name,
    role = EXCLUDED.role,
    status = 'active';

-- Ysabel Salazar — Operator
INSERT INTO users (tenant_id, email, password_hash, full_name, role, status)
VALUES (1, 'ysabel.salazar@bonarea.local',
        crypt('Admin@1234', gen_salt('bf', 10)),
        'Ysabel Salazar', 'operator', 'active')
ON CONFLICT (tenant_id, email) DO UPDATE SET
    password_hash = EXCLUDED.password_hash,
    full_name = EXCLUDED.full_name,
    role = EXCLUDED.role,
    status = 'active';

-- ─── Staff competencies (user_competencies) ─────────────────────────
INSERT INTO user_competencies (tenant_id, user_id, name, level, is_certified, expires_at, notes)
SELECT 1, u.id, 'Operador autorizado robótica industrial ABB', 'avanzado', true, '2027-06-30',
       'Curso ABB Robotics RobotStudio + Safety FlexPendant'
FROM users u WHERE u.tenant_id=1 AND u.email='angel.padrino@bonarea.local'
ON CONFLICT DO NOTHING;

INSERT INTO user_competencies (tenant_id, user_id, name, level, is_certified, expires_at, notes)
SELECT 1, u.id, 'PRL nivel intermedio (50h)', 'intermedio', true, '2028-03-15', NULL
FROM users u WHERE u.tenant_id=1 AND u.email='angel.padrino@bonarea.local'
ON CONFLICT DO NOTHING;

INSERT INTO user_competencies (tenant_id, user_id, name, level, is_certified, expires_at, notes)
SELECT 1, u.id, 'Manipulador de alimentos', 'básico', true, '2027-09-12', NULL
FROM users u WHERE u.tenant_id=1 AND u.email='ysabel.salazar@bonarea.local'
ON CONFLICT DO NOTHING;

INSERT INTO user_competencies (tenant_id, user_id, name, level, is_certified, expires_at, notes)
SELECT 1, u.id, 'Manejo de carretillas elevadoras', 'avanzado', true, '2027-11-04', NULL
FROM users u WHERE u.tenant_id=1 AND u.email='andres.padrino@bonarea.local'
ON CONFLICT DO NOTHING;

INSERT INTO user_competencies (tenant_id, user_id, name, level, is_certified, expires_at, notes)
SELECT 1, u.id, 'Supervisor PRL (200h)', 'avanzado', true, '2028-01-20', NULL
FROM users u WHERE u.tenant_id=1 AND u.email='caristiven.padrino@bonarea.local'
ON CONFLICT DO NOTHING;

-- ─── Skill tags (user_tags) ───────────────────────────────────────
INSERT INTO user_tags (tenant_id, user_id, tag, added_by)
SELECT 1, u.id, t.tag, 1
FROM users u
CROSS JOIN (VALUES ('mecánica'),('hidráulica'),('lubricación'),('robótica'),('PLC')) AS t(tag)
WHERE u.tenant_id=1 AND u.email='angel.padrino@bonarea.local'
ON CONFLICT DO NOTHING;

INSERT INTO user_tags (tenant_id, user_id, tag, added_by)
SELECT 1, u.id, t.tag, 1
FROM users u
CROSS JOIN (VALUES ('eléctrica'),('PLC'),('seguridad'),('producción')) AS t(tag)
WHERE u.tenant_id=1 AND u.email='caristiven.padrino@bonarea.local'
ON CONFLICT DO NOTHING;

INSERT INTO user_tags (tenant_id, user_id, tag, added_by)
SELECT 1, u.id, t.tag, 1
FROM users u
CROSS JOIN (VALUES ('producción'),('inspección visual'),('limpieza')) AS t(tag)
WHERE u.tenant_id=1 AND u.email='ysabel.salazar@bonarea.local'
ON CONFLICT DO NOTHING;

INSERT INTO user_tags (tenant_id, user_id, tag, added_by)
SELECT 1, u.id, t.tag, 1
FROM users u
CROSS JOIN (VALUES ('almacén'),('repuestos'),('logística')) AS t(tag)
WHERE u.tenant_id=1 AND u.email='andres.padrino@bonarea.local'
ON CONFLICT DO NOTHING;

COMMIT;

-- Verification
SELECT id, email, full_name, role, status, is_primary_admin
  FROM users WHERE tenant_id=1 ORDER BY id;
SELECT id, name, code, client_type FROM clients WHERE tenant_id=1;
