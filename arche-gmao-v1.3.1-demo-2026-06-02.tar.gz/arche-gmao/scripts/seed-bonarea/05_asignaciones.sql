-- ============================================================
-- BonArea Demo - Block 05: Hierarchical assignments + home_node
-- ============================================================
-- node_assignments with is_primary
-- ltree inheritance: assigning to the line ⇒ covers the composition + 10 equipment items
-- ============================================================

BEGIN;

-- User IDs
DO $$
DECLARE
    u_admin       BIGINT;
    u_andres      BIGINT;
    u_caristiven  BIGINT;
    u_angel       BIGINT;
    u_ysabel      BIGINT;
    n_org         BIGINT;
    n_plant       BIGINT;
    n_line        BIGINT;
    n_comp        BIGINT;
BEGIN
    SELECT id INTO u_admin      FROM users WHERE tenant_id=1 AND email='admin@arche.local';
    SELECT id INTO u_andres     FROM users WHERE tenant_id=1 AND email='andres.padrino@bonarea.local';
    SELECT id INTO u_caristiven FROM users WHERE tenant_id=1 AND email='caristiven.padrino@bonarea.local';
    SELECT id INTO u_angel      FROM users WHERE tenant_id=1 AND email='angel.padrino@bonarea.local';
    SELECT id INTO u_ysabel     FROM users WHERE tenant_id=1 AND email='ysabel.salazar@bonarea.local';

    SELECT id INTO n_org   FROM bonarea_demo_ids WHERE key='org';
    SELECT id INTO n_plant FROM bonarea_demo_ids WHERE key='plant';
    SELECT id INTO n_line  FROM bonarea_demo_ids WHERE key='line';
    SELECT id INTO n_comp  FROM bonarea_demo_ids WHERE key='comp_node';

    -- ── home_node: nodo principal "donde vive" cada usuario en la jerarquía
    UPDATE users SET home_node_id = n_plant WHERE id = u_andres;
    UPDATE users SET home_node_id = n_line  WHERE id = u_caristiven;
    UPDATE users SET home_node_id = n_comp  WHERE id = u_angel;
    UPDATE users SET home_node_id = n_comp  WHERE id = u_ysabel;
    UPDATE users SET home_node_id = n_org   WHERE id = u_admin;

    -- ── Asignaciones (idempotentes con ON CONFLICT)
    -- Andrés (almacén): planta entera → ve todos los equipos para abastecer repuestos
    INSERT INTO node_assignments (tenant_id, user_id, node_id, is_primary, assigned_by)
    VALUES (1, u_andres, n_plant, true, u_admin)
    ON CONFLICT DO NOTHING;

    -- Caristiven (supervisor): línea L-01 → cubre composición + 10 equipos por ltree
    INSERT INTO node_assignments (tenant_id, user_id, node_id, is_primary, assigned_by)
    VALUES (1, u_caristiven, n_line, true, u_admin)
    ON CONFLICT DO NOTHING;

    -- Ángel (técnico): la composición → cubre los 10 equipos
    INSERT INTO node_assignments (tenant_id, user_id, node_id, is_primary, assigned_by)
    VALUES (1, u_angel, n_comp, true, u_admin)
    ON CONFLICT DO NOTHING;

    -- Ysabel (operario): la composición también → opera la célula
    INSERT INTO node_assignments (tenant_id, user_id, node_id, is_primary, assigned_by)
    VALUES (1, u_ysabel, n_comp, true, u_admin)
    ON CONFLICT DO NOTHING;
END $$;

COMMIT;

-- Verification
SELECT u.full_name, u.role, fn.name AS home_node, fn.path::text
  FROM users u LEFT JOIN factory_nodes fn ON fn.id = u.home_node_id
  WHERE u.tenant_id=1 ORDER BY u.id;

SELECT u.full_name, u.role, na.is_primary, fn.name AS asignado_a
  FROM node_assignments na
  JOIN users u ON u.id = na.user_id
  JOIN factory_nodes fn ON fn.id = na.node_id
  WHERE na.tenant_id=1 ORDER BY u.id;
