-- ============================================================
-- BonArea Demo - Block 14: Signatures + photographic evidence on WOs
-- ============================================================
-- Fills the signed_by/at + supervisor_signed_by/at fields of the
-- WOs in closed/verified/completed state, so the PDFs
-- (reports) show the digital signatures.
-- It also adds evidence attachments (references) so the WO view can show
-- before/after photos.
-- ============================================================

BEGIN;

DO $$
DECLARE
    u_admin BIGINT;
    u_caristiven BIGINT;
    u_angel BIGINT;
    u_ysabel BIGINT;
    rec RECORD;
    v_supervisor BIGINT;
BEGIN
    SELECT id INTO u_admin      FROM users WHERE email='admin@arche.local';
    SELECT id INTO u_caristiven FROM users WHERE email='caristiven.padrino@bonarea.local';
    SELECT id INTO u_angel      FROM users WHERE email='angel.padrino@bonarea.local';
    SELECT id INTO u_ysabel     FROM users WHERE email='ysabel.salazar@bonarea.local';

    -- ─── FIRMAS EN OTs CLOSED ──────────────────────────────────────────────
    -- closed = completada + verificada + firmada por supervisor
    -- Firma técnico = assigned_to en completed_at
    -- Firma supervisor = created_by si es supervisor/admin, else caristiven, en closed_at
    FOR rec IN
        SELECT id, assigned_to, created_by, completed_at, closed_at
          FROM work_orders
         WHERE tenant_id=1 AND status='closed'
    LOOP
        -- Determinar quién firma como supervisor
        SELECT CASE WHEN role IN ('supervisor','admin') THEN rec.created_by
                    ELSE u_caristiven END
          INTO v_supervisor
          FROM users WHERE id = rec.created_by;
        IF v_supervisor IS NULL THEN v_supervisor := u_caristiven; END IF;

        UPDATE work_orders SET
            signed_by = COALESCE(rec.assigned_to, u_angel),
            signed_at = COALESCE(rec.completed_at, NOW() - interval '1 day'),
            supervisor_signed_by = v_supervisor,
            supervisor_signed_at = COALESCE(rec.closed_at, rec.completed_at + interval '1 hour', NOW())
         WHERE id = rec.id;
    END LOOP;

    -- ─── FIRMAS EN OTs VERIFIED ────────────────────────────────────────────
    -- verified = técnico firma + supervisor verifica pero aún no firma cierre
    FOR rec IN
        SELECT id, assigned_to, created_by, completed_at
          FROM work_orders
         WHERE tenant_id=1 AND status='verified'
    LOOP
        SELECT CASE WHEN role IN ('supervisor','admin') THEN rec.created_by
                    ELSE u_caristiven END
          INTO v_supervisor
          FROM users WHERE id = rec.created_by;
        IF v_supervisor IS NULL THEN v_supervisor := u_caristiven; END IF;

        UPDATE work_orders SET
            signed_by = COALESCE(rec.assigned_to, u_angel),
            signed_at = COALESCE(rec.completed_at, NOW() - interval '6 hours'),
            supervisor_signed_by = v_supervisor,
            supervisor_signed_at = COALESCE(rec.completed_at + interval '30 minutes', NOW() - interval '5 hours')
         WHERE id = rec.id;
    END LOOP;

    -- ─── FIRMAS EN OTs COMPLETED ───────────────────────────────────────────
    -- completed = técnico ya firmó al finalizar, supervisor pendiente
    FOR rec IN
        SELECT id, assigned_to, completed_at
          FROM work_orders
         WHERE tenant_id=1 AND status='completed'
    LOOP
        UPDATE work_orders SET
            signed_by = COALESCE(rec.assigned_to, u_angel),
            signed_at = COALESCE(rec.completed_at, NOW() - interval '3 hours')
         WHERE id = rec.id;
    END LOOP;

    -- ─── EVIDENCIAS / ATTACHMENTS para OTs cerradas con causas mecánicas ──
    -- Añadimos attachment metadata como referencia (file_path apunta a directorio
    -- de evidencias que se servirían en producción). Marcamos photo_phase
    -- before/after.
    FOR rec IN
        SELECT id, node_id, completed_at FROM work_orders
         WHERE tenant_id=1 AND status='closed'
           AND root_cause_code IN ('mechanical','electrical','pneumatic')
         ORDER BY completed_at DESC LIMIT 25
    LOOP
        -- Foto BEFORE
        INSERT INTO attachments
            (tenant_id, node_id, wo_id, file_name, original_name, mime_type, file_size,
             file_path, category, description, photo_phase, uploaded_by, created_at)
        VALUES
            (1, rec.node_id, rec.id,
             'evidencia_before_' || rec.id || '.jpg',
             'foto_antes.jpg', 'image/jpeg', 2480000,
             '/var/data/evidencia/before_' || rec.id || '.jpg',
             'evidencia',
             'Foto del estado del equipo antes de la intervención',
             'before', u_angel,
             COALESCE(rec.completed_at - interval '90 minutes', NOW() - interval '90 minutes')),
            (1, rec.node_id, rec.id,
             'evidencia_after_' || rec.id || '.jpg',
             'foto_despues.jpg', 'image/jpeg', 2710000,
             '/var/data/evidencia/after_' || rec.id || '.jpg',
             'evidencia',
             'Foto del equipo tras la reparación, en marcha de nuevo',
             'after', u_angel,
             COALESCE(rec.completed_at, NOW())),
            -- Documento de tarjeta de intervención
            (1, rec.node_id, rec.id,
             'tarjeta_intervencion_' || rec.id || '.pdf',
             'tarjeta_intervencion.pdf', 'application/pdf', 95400,
             '/var/data/evidencia/tarjeta_' || rec.id || '.pdf',
             'documento',
             'Tarjeta de intervención firmada con LOTO aplicado',
             NULL, u_angel,
             COALESCE(rec.completed_at - interval '2 hours', NOW() - interval '2 hours'));
    END LOOP;

    RAISE NOTICE 'OTs firmadas (closed): %',
        (SELECT count(*) FROM work_orders WHERE tenant_id=1 AND signed_by IS NOT NULL AND supervisor_signed_by IS NOT NULL);
    RAISE NOTICE 'Attachments creados: %',
        (SELECT count(*) FROM attachments WHERE tenant_id=1);
END $$;

COMMIT;

-- Verification
SELECT wo_number, title, status,
       u1.full_name AS firmado_tecnico, signed_at::text,
       u2.full_name AS firmado_supervisor, supervisor_signed_at::text
  FROM work_orders wo
  LEFT JOIN users u1 ON u1.id = wo.signed_by
  LEFT JOIN users u2 ON u2.id = wo.supervisor_signed_by
 WHERE wo.tenant_id=1 AND wo.status IN ('closed','verified','completed')
 ORDER BY wo.id DESC LIMIT 6;

SELECT category, photo_phase, count(*) FROM attachments WHERE tenant_id=1
 GROUP BY category, photo_phase ORDER BY category, photo_phase;
