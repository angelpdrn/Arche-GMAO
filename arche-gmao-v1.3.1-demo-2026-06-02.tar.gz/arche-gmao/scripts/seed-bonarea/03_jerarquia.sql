-- ============================================================
-- BonArea Demo - Block 03: factory_nodes hierarchy
-- ============================================================
-- Organization → Plant → Area → Line → Composition → 10 equipment items
-- path is computed automatically by an AFTER INSERT trigger
-- ============================================================

BEGIN;

DO $$
DECLARE
    v_client_id  BIGINT;
    v_org_id     BIGINT;
    v_plant_id   BIGINT;
    v_area_id    BIGINT;
    v_line_id    BIGINT;
    v_comp_id    BIGINT;  -- composition node

    -- equipos
    v_robot_id   BIGINT;
    v_vision_id  BIGINT;
    v_cinta_a_id BIGINT;
    v_cinta_b_id BIGINT;
    v_cinta_c_id BIGINT;
    v_pesadora_id BIGINT;
    v_etiqueta_id BIGINT;
    v_selladora_id BIGINT;
    v_plc_id     BIGINT;
    v_compresor_id BIGINT;

    -- templates
    t_robot     BIGINT;
    t_vision    BIGINT;
    t_cinta     BIGINT;
    t_pesadora  BIGINT;
    t_etiqueta  BIGINT;
    t_selladora BIGINT;
    t_plc       BIGINT;
    t_compresor BIGINT;
BEGIN
    SELECT id INTO v_client_id FROM clients WHERE tenant_id=1 AND code='BONAREA';

    -- Resolver IDs de plantillas
    SELECT id INTO t_robot     FROM equipment_templates WHERE tenant_id=1 AND manufacturer='ABB'            AND model='IRB 360-3/1130 FlexPicker';
    SELECT id INTO t_vision    FROM equipment_templates WHERE tenant_id=1 AND manufacturer='Cognex'         AND model='In-Sight 9912';
    SELECT id INTO t_cinta     FROM equipment_templates WHERE tenant_id=1 AND manufacturer='Interroll'      AND model='MCP 5500-200';
    SELECT id INTO t_pesadora  FROM equipment_templates WHERE tenant_id=1 AND manufacturer='MULTIPOND'      AND model='PMC 14-1200';
    SELECT id INTO t_etiqueta  FROM equipment_templates WHERE tenant_id=1 AND manufacturer='Markem-Imaje'   AND model='9450';
    SELECT id INTO t_selladora FROM equipment_templates WHERE tenant_id=1 AND manufacturer='Sealed Air'     AND model='CRYOVAC ST98';
    SELECT id INTO t_plc       FROM equipment_templates WHERE tenant_id=1 AND manufacturer='Siemens'        AND model='SIMATIC S7-1517F-3 PN/DP';
    SELECT id INTO t_compresor FROM equipment_templates WHERE tenant_id=1 AND manufacturer='Atlas Copco'    AND model='GA22 VSD+';

    -- ─── ORGANIZACIÓN ──────────────────────────────────────────────────────
    INSERT INTO factory_nodes (tenant_id, client_id, parent_id, name, code, node_type, status, criticality, description)
    VALUES (1, v_client_id, NULL, 'BonArea SCA', 'BONAREA',
            'organization', 'active', 'high',
            'Cooperativa agrícola y ganadera. Sede central Guissona (Lleida). Demo CMMS Arché.')
    RETURNING id INTO v_org_id;

    -- ─── PLANTA ────────────────────────────────────────────────────────────
    INSERT INTO factory_nodes (tenant_id, client_id, parent_id, name, code, node_type, status, criticality, description)
    VALUES (1, v_client_id, v_org_id, 'Planta cárnica Guissona', 'PLT-GUI',
            'plant', 'active', 'high',
            'Planta de procesado y envasado de productos cárnicos. Capacidad 80 t/día. Certificada IFS y BRC.')
    RETURNING id INTO v_plant_id;

    -- ─── ÁREA ──────────────────────────────────────────────────────────────
    INSERT INTO factory_nodes (tenant_id, client_id, parent_id, name, code, node_type, status, criticality, description)
    VALUES (1, v_client_id, v_plant_id, 'Envasado y Clasificación', 'AREA-ENV',
            'area', 'active', 'high',
            'Área aguas abajo del horno de cocción: clasificación por producto, envasado al vacío y etiquetado.')
    RETURNING id INTO v_area_id;

    -- ─── LÍNEA ─────────────────────────────────────────────────────────────
    INSERT INTO factory_nodes (tenant_id, client_id, parent_id, name, code, node_type, status, criticality, description)
    VALUES (1, v_client_id, v_area_id, 'Línea de Selección Triple L-01', 'LIN-L01',
            'line', 'active', 'critical',
            'Línea de selección automática que separa salchichón, chorizo y fuet en cintas independientes.')
    RETURNING id INTO v_line_id;

    -- ─── COMPOSICIÓN (nodo composition) ────────────────────────────────────
    INSERT INTO factory_nodes (tenant_id, client_id, parent_id, name, code, node_type, status, criticality, description)
    VALUES (1, v_client_id, v_line_id, 'Célula Robótica Triple-Pick', 'COMP-TRIPLE-PICK',
            'composition', 'active', 'critical',
            'Célula formada por brazo robot ABB delta + visión Cognex + 3 cintas modulares + pesadora + etiquetadora + selladora + PLC + compresor. Selecciona producto cárnico y lo enruta a la cinta correcta.')
    RETURNING id INTO v_comp_id;

    -- ─── EQUIPOS dentro de la composición ──────────────────────────────────
    -- 1. Brazo robótico ABB
    INSERT INTO factory_nodes (tenant_id, client_id, parent_id, template_id, name, code, node_type, status,
        criticality, description, manufacturer, model, serial_number, year_installed, rated_power_kw)
    VALUES (1, v_client_id, v_comp_id, t_robot,
        'Robot Triple-Pick ABB R1', 'ROBOT-R1',
        'equipment', 'active', 'critical',
        'Brazo robot delta principal de la célula. Selecciona producto del flujo y lo coloca en la cinta correspondiente según señal de visión.',
        'ABB', 'IRB 360-3/1130 FlexPicker', 'ABB-IRB360-2024-0341', 2024, 1.50)
    RETURNING id INTO v_robot_id;

    -- 2. Visión Cognex
    INSERT INTO factory_nodes (tenant_id, client_id, parent_id, template_id, name, code, node_type, status,
        criticality, description, manufacturer, model, serial_number, year_installed, rated_power_kw)
    VALUES (1, v_client_id, v_comp_id, t_vision,
        'Cámara Visión Cognex CX1', 'CAM-CX1',
        'equipment', 'active', 'high',
        'Sistema de visión que clasifica producto por forma, color y tamaño. Envía al PLC el ID de la cinta destino.',
        'Cognex', 'In-Sight 9912', 'COG-9912-2024-0118', 2024, 0.05)
    RETURNING id INTO v_vision_id;

    -- 3. Cinta A (Salchichón)
    INSERT INTO factory_nodes (tenant_id, client_id, parent_id, template_id, name, code, node_type, status,
        criticality, description, manufacturer, model, serial_number, year_installed, rated_power_kw)
    VALUES (1, v_client_id, v_comp_id, t_cinta,
        'Cinta CTA-A Salchichón', 'CTA-A',
        'equipment', 'active', 'high',
        'Cinta modular de salida 1: salchichón. Va hacia pesadora y etiquetadora.',
        'Interroll', 'MCP 5500-200', 'INT-MCP-A-2024-0712', 2024, 0.55)
    RETURNING id INTO v_cinta_a_id;

    -- 4. Cinta B (Chorizo)
    INSERT INTO factory_nodes (tenant_id, client_id, parent_id, template_id, name, code, node_type, status,
        criticality, description, manufacturer, model, serial_number, year_installed, rated_power_kw)
    VALUES (1, v_client_id, v_comp_id, t_cinta,
        'Cinta CTA-B Chorizo', 'CTA-B',
        'equipment', 'active', 'high',
        'Cinta modular de salida 2: chorizo. Histórico recurrente de fallos en motor RollerDrive.',
        'Interroll', 'MCP 5500-200', 'INT-MCP-B-2024-0713', 2024, 0.55)
    RETURNING id INTO v_cinta_b_id;

    -- 5. Cinta C (Fuet)
    INSERT INTO factory_nodes (tenant_id, client_id, parent_id, template_id, name, code, node_type, status,
        criticality, description, manufacturer, model, serial_number, year_installed, rated_power_kw)
    VALUES (1, v_client_id, v_comp_id, t_cinta,
        'Cinta CTA-C Fuet', 'CTA-C',
        'equipment', 'active', 'medium',
        'Cinta modular de salida 3: fuet. Producto más liviano, menos desgaste.',
        'Interroll', 'MCP 5500-200', 'INT-MCP-C-2024-0714', 2024, 0.55)
    RETURNING id INTO v_cinta_c_id;

    -- 6. Pesadora
    INSERT INTO factory_nodes (tenant_id, client_id, parent_id, template_id, name, code, node_type, status,
        criticality, description, manufacturer, model, serial_number, year_installed, rated_power_kw)
    VALUES (1, v_client_id, v_comp_id, t_pesadora,
        'Pesadora MULTIPOND M14', 'PESA-M14',
        'equipment', 'active', 'high',
        'Pesadora multicabezal a la salida de las cintas. Verifica peso final antes de envasado.',
        'MULTIPOND', 'PMC 14-1200', 'MUL-PMC14-2023-2204', 2023, 4.20)
    RETURNING id INTO v_pesadora_id;

    -- 7. Etiquetadora
    INSERT INTO factory_nodes (tenant_id, client_id, parent_id, template_id, name, code, node_type, status,
        criticality, description, manufacturer, model, serial_number, year_installed, rated_power_kw)
    VALUES (1, v_client_id, v_comp_id, t_etiqueta,
        'Etiquetadora Markem 9450', 'ETI-9450',
        'equipment', 'active', 'high',
        'Imprime y aplica etiqueta con lote, fecha, peso y código EAN. Comunicación con MES.',
        'Markem-Imaje', '9450', 'MAR-9450-2023-0987', 2023, 0.40)
    RETURNING id INTO v_etiqueta_id;

    -- 8. Selladora
    INSERT INTO factory_nodes (tenant_id, client_id, parent_id, template_id, name, code, node_type, status,
        criticality, description, manufacturer, model, serial_number, year_installed, rated_power_kw)
    VALUES (1, v_client_id, v_comp_id, t_selladora,
        'Selladora CRYOVAC ST98', 'SEL-ST98',
        'equipment', 'active', 'critical',
        'Túnel de retracción al vapor. Punto crítico HACCP por temperatura.',
        'Sealed Air', 'CRYOVAC ST98', 'SEA-ST98-2022-1450', 2022, 18.00)
    RETURNING id INTO v_selladora_id;

    -- 9. PLC
    INSERT INTO factory_nodes (tenant_id, client_id, parent_id, template_id, name, code, node_type, status,
        criticality, description, manufacturer, model, serial_number, year_installed, rated_power_kw)
    VALUES (1, v_client_id, v_comp_id, t_plc,
        'PLC Siemens S7-1517F', 'PLC-CC1',
        'equipment', 'active', 'critical',
        'PLC failsafe que coordina toda la célula. Profinet + Profisafe a robot, visión, cintas y selladora.',
        'Siemens', 'SIMATIC S7-1517F-3 PN/DP', 'SIE-1517F-2022-0321', 2022, 0.10)
    RETURNING id INTO v_plc_id;

    -- 10. Compresor
    INSERT INTO factory_nodes (tenant_id, client_id, parent_id, template_id, name, code, node_type, status,
        criticality, description, manufacturer, model, serial_number, year_installed, rated_power_kw)
    VALUES (1, v_client_id, v_comp_id, t_compresor,
        'Compresor Atlas Copco GA22', 'COMP-GA22',
        'equipment', 'active', 'high',
        'Compresor de tornillo VSD+ 22 kW que alimenta toda la célula y otros consumidores de la planta.',
        'Atlas Copco', 'GA22 VSD+', 'ATL-GA22-2021-7783', 2021, 22.00)
    RETURNING id INTO v_compresor_id;

    -- ─── COMPOSICIÓN: vincular nodo composición con el registro composition ─
    -- (la migración 030 vincula equipment_compositions.node_id → factory_nodes)
    -- y migración 026 mete los miembros
    -- Esto se gestiona en el bloque siguiente cuando creemos la composición

    -- Guardar IDs en una tabla temporal para uso posterior
    DROP TABLE IF EXISTS demo_node_ids;
    CREATE TEMP TABLE demo_node_ids (key TEXT PRIMARY KEY, id BIGINT NOT NULL) ON COMMIT DROP;
    -- En lugar de TEMP, usamos una tabla persistente para que otros scripts puedan leerla
    -- y asegurar idempotencia.
    -- Replicamos a tabla normal:
    DROP TABLE IF EXISTS bonarea_demo_ids;
    CREATE TABLE bonarea_demo_ids (key TEXT PRIMARY KEY, id BIGINT NOT NULL);
    INSERT INTO bonarea_demo_ids VALUES
        ('client',    v_client_id),
        ('org',       v_org_id),
        ('plant',     v_plant_id),
        ('area',      v_area_id),
        ('line',      v_line_id),
        ('comp_node', v_comp_id),
        ('robot',     v_robot_id),
        ('vision',    v_vision_id),
        ('cinta_a',   v_cinta_a_id),
        ('cinta_b',   v_cinta_b_id),
        ('cinta_c',   v_cinta_c_id),
        ('pesadora',  v_pesadora_id),
        ('etiqueta',  v_etiqueta_id),
        ('selladora', v_selladora_id),
        ('plc',       v_plc_id),
        ('compresor', v_compresor_id);

    RAISE NOTICE 'Jerarquía creada: org=%, plant=%, area=%, line=%, comp=%',
        v_org_id, v_plant_id, v_area_id, v_line_id, v_comp_id;
    RAISE NOTICE 'Equipos: robot=%, vision=%, cintas=%/%/%, pesa=%, eti=%, sel=%, plc=%, comp=%',
        v_robot_id, v_vision_id, v_cinta_a_id, v_cinta_b_id, v_cinta_c_id,
        v_pesadora_id, v_etiqueta_id, v_selladora_id, v_plc_id, v_compresor_id;
END $$;

COMMIT;

-- Verification
SELECT id, name, code, node_type, status, criticality, path::text
  FROM factory_nodes WHERE tenant_id=1
  ORDER BY path;

SELECT * FROM bonarea_demo_ids ORDER BY id;
