-- ============================================================
-- BonArea Demo - Block 04: Composition + Manuals for RAG
-- ============================================================

BEGIN;

-- ─── COMPOSITION TEMPLATE ───────────────────────────────────────────────────
DO $$
DECLARE
    v_tmpl_id BIGINT;
    v_slot_robot   BIGINT;
    v_slot_vision  BIGINT;
    v_slot_cinta_a BIGINT;
    v_slot_cinta_b BIGINT;
    v_slot_cinta_c BIGINT;
    v_slot_pesa    BIGINT;
    v_slot_eti     BIGINT;
    v_slot_sel     BIGINT;
    v_slot_plc     BIGINT;
    v_slot_comp    BIGINT;

    v_comp_id   BIGINT;  -- registro en equipment_compositions
    v_comp_node BIGINT;
    t_robot     BIGINT;
    t_vision    BIGINT;
    t_cinta     BIGINT;
    t_pesadora  BIGINT;
    t_etiqueta  BIGINT;
    t_selladora BIGINT;
    t_plc       BIGINT;
    t_compresor BIGINT;
BEGIN
    SELECT id INTO v_comp_node FROM bonarea_demo_ids WHERE key='comp_node';

    SELECT id INTO t_robot     FROM equipment_templates WHERE tenant_id=1 AND model='IRB 360-3/1130 FlexPicker';
    SELECT id INTO t_vision    FROM equipment_templates WHERE tenant_id=1 AND model='In-Sight 9912';
    SELECT id INTO t_cinta     FROM equipment_templates WHERE tenant_id=1 AND model='MCP 5500-200';
    SELECT id INTO t_pesadora  FROM equipment_templates WHERE tenant_id=1 AND model='PMC 14-1200';
    SELECT id INTO t_etiqueta  FROM equipment_templates WHERE tenant_id=1 AND model='9450';
    SELECT id INTO t_selladora FROM equipment_templates WHERE tenant_id=1 AND model='CRYOVAC ST98';
    SELECT id INTO t_plc       FROM equipment_templates WHERE tenant_id=1 AND model='SIMATIC S7-1517F-3 PN/DP';
    SELECT id INTO t_compresor FROM equipment_templates WHERE tenant_id=1 AND model='GA22 VSD+';

    -- Crear plantilla de composición
    INSERT INTO composition_templates (tenant_id, name, description, created_by)
    VALUES (1, 'Célula Triple-Pick (BonArea)',
            'Plantilla estándar de célula robótica de selección triple para producto cárnico curado.',
            1)
    RETURNING id INTO v_tmpl_id;

    -- Slots del template
    INSERT INTO composition_template_slots (template_id, role, equipment_template_id, sort_order) VALUES
        (v_tmpl_id, 'Brazo robótico delta',     t_robot,     1) RETURNING id INTO v_slot_robot;
    INSERT INTO composition_template_slots (template_id, role, equipment_template_id, sort_order) VALUES
        (v_tmpl_id, 'Sistema de visión',        t_vision,    2) RETURNING id INTO v_slot_vision;
    INSERT INTO composition_template_slots (template_id, role, equipment_template_id, sort_order) VALUES
        (v_tmpl_id, 'Cinta salida A',           t_cinta,     3) RETURNING id INTO v_slot_cinta_a;
    INSERT INTO composition_template_slots (template_id, role, equipment_template_id, sort_order) VALUES
        (v_tmpl_id, 'Cinta salida B',           t_cinta,     4) RETURNING id INTO v_slot_cinta_b;
    INSERT INTO composition_template_slots (template_id, role, equipment_template_id, sort_order) VALUES
        (v_tmpl_id, 'Cinta salida C',           t_cinta,     5) RETURNING id INTO v_slot_cinta_c;
    INSERT INTO composition_template_slots (template_id, role, equipment_template_id, sort_order) VALUES
        (v_tmpl_id, 'Pesadora multicabezal',    t_pesadora,  6) RETURNING id INTO v_slot_pesa;
    INSERT INTO composition_template_slots (template_id, role, equipment_template_id, sort_order) VALUES
        (v_tmpl_id, 'Etiquetadora P&A',         t_etiqueta,  7) RETURNING id INTO v_slot_eti;
    INSERT INTO composition_template_slots (template_id, role, equipment_template_id, sort_order) VALUES
        (v_tmpl_id, 'Selladora termoencogible', t_selladora, 8) RETURNING id INTO v_slot_sel;
    INSERT INTO composition_template_slots (template_id, role, equipment_template_id, sort_order) VALUES
        (v_tmpl_id, 'PLC failsafe',             t_plc,       9) RETURNING id INTO v_slot_plc;
    INSERT INTO composition_template_slots (template_id, role, equipment_template_id, sort_order) VALUES
        (v_tmpl_id, 'Compresor de aire',        t_compresor, 10) RETURNING id INTO v_slot_comp;

    -- Crear instancia (equipment_compositions) vinculada al nodo composition
    INSERT INTO equipment_compositions (tenant_id, name, description, template_id, parent_node_id, created_by, node_id)
    VALUES (1, 'Célula Triple-Pick L-01',
            'Instancia operativa de la célula en línea L-01.',
            v_tmpl_id,
            (SELECT id FROM bonarea_demo_ids WHERE key='line'),
            1,
            v_comp_node)
    RETURNING id INTO v_comp_id;

    -- Miembros: cada equipo de la célula
    INSERT INTO equipment_composition_members (composition_id, node_id, role, slot_id) VALUES
        (v_comp_id, (SELECT id FROM bonarea_demo_ids WHERE key='robot'),     'Brazo robótico delta',     v_slot_robot),
        (v_comp_id, (SELECT id FROM bonarea_demo_ids WHERE key='vision'),    'Sistema de visión',        v_slot_vision),
        (v_comp_id, (SELECT id FROM bonarea_demo_ids WHERE key='cinta_a'),   'Cinta salida A',           v_slot_cinta_a),
        (v_comp_id, (SELECT id FROM bonarea_demo_ids WHERE key='cinta_b'),   'Cinta salida B',           v_slot_cinta_b),
        (v_comp_id, (SELECT id FROM bonarea_demo_ids WHERE key='cinta_c'),   'Cinta salida C',           v_slot_cinta_c),
        (v_comp_id, (SELECT id FROM bonarea_demo_ids WHERE key='pesadora'),  'Pesadora multicabezal',    v_slot_pesa),
        (v_comp_id, (SELECT id FROM bonarea_demo_ids WHERE key='etiqueta'),  'Etiquetadora P&A',         v_slot_eti),
        (v_comp_id, (SELECT id FROM bonarea_demo_ids WHERE key='selladora'), 'Selladora termoencogible', v_slot_sel),
        (v_comp_id, (SELECT id FROM bonarea_demo_ids WHERE key='plc'),       'PLC failsafe',             v_slot_plc),
        (v_comp_id, (SELECT id FROM bonarea_demo_ids WHERE key='compresor'), 'Compresor de aire',        v_slot_comp);

    INSERT INTO bonarea_demo_ids VALUES ('comp_template', v_tmpl_id), ('comp_instance', v_comp_id)
        ON CONFLICT (key) DO UPDATE SET id = EXCLUDED.id;
END $$;

-- ─── MAINTENANCE MANUALS (plain text for RAG) ──────────────────────
-- file_path is fictitious; what matters is content_text (what RAG indexes).

INSERT INTO maintenance_manuals
    (tenant_id, node_id, title, description, file_name, original_name,
     mime_type, file_size, file_path, content_text, is_active, uploaded_by)
SELECT 1, (SELECT id FROM bonarea_demo_ids WHERE key='robot'),
    'Manual ABB IRB 360 FlexPicker — Mantenimiento preventivo',
    'Procedimientos oficiales de mantenimiento del fabricante ABB para el robot delta IRB 360. Incluye lubricación, ajuste de correas, inspección de articulaciones y calibración.',
    'abb_irb360_pm.txt', 'ABB_IRB360_FlexPicker_PM.pdf',
    'text/plain', 8420,
    '/seed/manuals/abb_irb360_pm.txt',
$txt$Robot ABB IRB 360-3/1130 FlexPicker — Mantenimiento preventivo

1. PUNTOS DE LUBRICACIÓN
- Cojinetes de los brazos paralelos: grasa Mobilith SHC 220 cada 2.000 h.
- Junta universal del eje 4: Castrol Optitemp RB1 cada 4.000 h.
- Husillos de bolas de los servomotores: ya lubricados de fábrica, no requieren mantenimiento durante los primeros 20.000 ciclos.

2. CORREA DE LA RÓTULA CENTRAL
- Inspección visual cada 1.000 h.
- Tensión correcta: deflexión de 3-5 mm con fuerza de 10 N.
- Sustitución cada 8.000 h o cuando se observe desgaste lateral o rotura de dientes.
- Repuesto: ABB 3HAC027433-001 (correa GT2 800 mm).

3. CALIBRACIÓN
- Recalibrar tras sustituir cualquier componente mecánico.
- TCP (Tool Center Point) verificación semanal con utillaje de pin.
- Tolerancia máxima: ±0,2 mm en pick, ±0,5 mm en place.

4. SEGURIDAD
- Aislar el suministro eléctrico mediante el seccionador principal del armario.
- Despresurizar la línea neumática (pinza de vacío) abriendo la válvula manual de purga.
- Bloqueo y etiquetado (LOTO) obligatorio.
- Verificar que los enclavamientos del cerramiento perimetral funcionan correctamente antes de devolver a producción.

5. FALLOS COMUNES
- Error E0021 "Excessive position error" → habitualmente causado por correa floja o motor 1 desalineado.
- Pérdida de vacío en pinza → revisar membrana del eyector y manguera de Ø8.
- Pick fallido → comprobar iluminación de la cámara Cognex y limpieza del lente.
$txt$,
    true, 1
WHERE NOT EXISTS (
    SELECT 1 FROM maintenance_manuals WHERE tenant_id=1 AND file_name='abb_irb360_pm.txt'
);

INSERT INTO maintenance_manuals
    (tenant_id, node_id, title, description, file_name, original_name,
     mime_type, file_size, file_path, content_text, is_active, uploaded_by)
SELECT 1, (SELECT id FROM bonarea_demo_ids WHERE key='vision'),
    'Cognex In-Sight 9912 — Operación y limpieza',
    'Procedimiento de mantenimiento del sistema de visión.',
    'cognex_9912_op.txt', 'Cognex_InSight_9912_OP.pdf',
    'text/plain', 5200,
    '/seed/manuals/cognex_9912_op.txt',
$txt$Cognex In-Sight 9912 — Operación, limpieza y mantenimiento

1. LIMPIEZA DEL OBJETIVO
- Diariamente con paño de microfibra y producto neutro tipo Cognex VL-CL.
- No usar disolventes agresivos (acetona, alcohol >70%).
- Verificar que no quede polvo en el iluminador anular LED.

2. CALIBRACIÓN DE COLOR
- Cuando cambie la iluminación ambiente, calibrar con tarjeta Macbeth.
- Acceder a EasyBuilder → Tools → Calibration Wizard.

3. RED Y COMUNICACIÓN
- Comprobar IP fija (192.168.10.21) con el PLC Siemens.
- Profinet: dispositivo en bus, debe estar en estado Conn=Yes, Status=Ready.

4. FALLOS COMUNES
- Imagen oscura → comprobar iluminador y conexión 24 V.
- Falsos negativos → recalibrar con muestras patrón cada cambio de producto.
- Cámara reinicia cíclicamente → suele ser fallo de fuente 24 V o cable Ethernet en mal estado.
$txt$,
    true, 1
WHERE NOT EXISTS (
    SELECT 1 FROM maintenance_manuals WHERE tenant_id=1 AND file_name='cognex_9912_op.txt'
);

INSERT INTO maintenance_manuals
    (tenant_id, node_id, title, description, file_name, original_name,
     mime_type, file_size, file_path, content_text, is_active, uploaded_by)
SELECT 1, (SELECT id FROM bonarea_demo_ids WHERE key='cinta_b'),
    'Interroll MCP 5500 — Sustitución motor RollerDrive',
    'Procedimiento detallado para diagnóstico y sustitución del motor en cinta modular Interroll, especialmente la unidad de la cinta CTA-B donde se han observado fallos repetitivos.',
    'interroll_mcp_motor.txt', 'Interroll_MCP_RollerDrive_Service.pdf',
    'text/plain', 6700,
    '/seed/manuals/interroll_mcp_motor.txt',
$txt$Interroll MCP 5500 — Sustitución del motor RollerDrive EC5000

1. SÍNTOMAS DE FALLO
- Sobrecalentamiento del motor (>75 °C carcasa).
- Ruido metálico durante el arranque.
- Cinta se detiene y reinicia con error E03 en el variador ACS580.
- Vibración anómala en el rodillo motriz.

2. CAUSAS COMUNES
- Cojinete interno del motor (rodamiento SKF 6203-2RS) desgastado por contaminación con grasa.
- Temperatura ambiente elevada (>40 °C) por proximidad al túnel de retracción.
- Sobreesfuerzo por desalineación de la banda modular.

3. PROCEDIMIENTO DE SUSTITUCIÓN
a) Aislar eléctricamente desde el variador ACS580.
b) Despresurizar línea neumática del tensor.
c) Desmontar el carro tensor y aflojar la banda modular.
d) Liberar el rodillo motriz: 4 tornillos M6 inox.
e) Desconectar el cable M12 de alimentación + datos.
f) Extraer el RollerDrive completo (peso 4.5 kg).
g) Montar el repuesto Interroll EC5000-200-50 con par de apriete 12 Nm.
h) Reconectar y verificar sentido de giro desde el HMI.
i) Recolocar banda con tensión 25-30 N/m.
j) Ensayo en vacío 30 min antes de devolver a producción.

4. REPUESTOS
- Motor RollerDrive: Interroll EC5000-200-50 (RP-INT-EC5000)
- Rodamiento de repuesto: SKF 6203-2RS
- Cable M12: Interroll PD-CBL-M12-5M

5. NOTA HISTÓRICA
La cinta CTA-B (chorizo) trabaja con producto más graso que CTA-A y CTA-C. Esto provoca mayor desgaste por contaminación de grasa en el rodamiento. Considerar reducir el intervalo de inspección a 1.500 h (vs 3.000 h en cintas A y C).
$txt$,
    true, 1
WHERE NOT EXISTS (
    SELECT 1 FROM maintenance_manuals WHERE tenant_id=1 AND file_name='interroll_mcp_motor.txt'
);

INSERT INTO maintenance_manuals
    (tenant_id, node_id, title, description, file_name, original_name,
     mime_type, file_size, file_path, content_text, is_active, uploaded_by)
SELECT 1, (SELECT id FROM bonarea_demo_ids WHERE key='pesadora'),
    'MULTIPOND PMC 14 — Calibración y limpieza',
    'Calibración de células de carga y limpieza CIP.',
    'multipond_pmc14_cal.txt', 'MULTIPOND_PMC14_Calibration.pdf',
    'text/plain', 4900,
    '/seed/manuals/multipond_pmc14_cal.txt',
$txt$MULTIPOND PMC 14-1200 — Calibración y limpieza

1. CALIBRACIÓN DE CÉLULAS DE CARGA
- Pesa patrón certificada de 200 g clase F1.
- Frecuencia: cada 7 días o tras movimiento mecánico.
- Tolerancia: ±0,2 g por cabeza.
- Compensación de temperatura automática a partir de la sonda PT100 interna.

2. LIMPIEZA CIP
- Frecuencia: al final de cada turno productivo (3/día).
- Producto: detergente alcalino BonArea-CL12, dilución 2%.
- Temperatura: 65 ± 5 °C.
- Aclarado: agua osmotizada hasta conductividad <50 µS/cm.

3. ALARMAS HABITUALES
- "Cabeza fuera de tolerancia" → calibrar o sustituir célula KMD-208.
- "Sensor de tolva atascado" → comprobar fotocélula SICK WL12G.
$txt$,
    true, 1
WHERE NOT EXISTS (
    SELECT 1 FROM maintenance_manuals WHERE tenant_id=1 AND file_name='multipond_pmc14_cal.txt'
);

INSERT INTO maintenance_manuals
    (tenant_id, node_id, title, description, file_name, original_name,
     mime_type, file_size, file_path, content_text, is_active, uploaded_by)
SELECT 1, (SELECT id FROM bonarea_demo_ids WHERE key='compresor'),
    'Atlas Copco GA22 VSD+ — Plan de mantenimiento',
    'Plan oficial de mantenimiento para compresor de tornillo Atlas Copco.',
    'atlas_copco_ga22.txt', 'AtlasCopco_GA22_Maintenance.pdf',
    'text/plain', 6100,
    '/seed/manuals/atlas_copco_ga22.txt',
$txt$Atlas Copco GA22 VSD+ — Plan de mantenimiento

1. INTERVALOS
- Cada 4.000 h: cambio de aceite Roto-Xtend Duty Fluid + filtro de aceite + filtro separador.
- Cada 8.000 h: filtro de aire + cambio de aceite.
- Cada 16.000 h: revisión general (motor, válvula de admisión, válvula de presión mínima).

2. ACEITE
- Tipo: Atlas Copco Roto-Xtend Duty Fluid 4000h, ref. 1630-2076-00.
- Capacidad: 7.5 litros.
- Verificar nivel cada 200 h en la mirilla del separador.

3. FILTROS
- Filtro de aceite: ref. 1622-3651-00.
- Filtro separador: ref. 1622-3148-00.
- Filtro de aire: ref. 1613-7406-00.

4. ALARMAS
- Pe alta → comprobar válvula de salida y filtro separador (puede estar saturado).
- Tem alta → revisar refrigerador, ventilador y nivel de aceite.
- Servicio Plan A/B/C → contacto con servicio técnico Atlas Copco.

5. ATEX
La sala de compresores no es zona ATEX. No retirar la trampilla de ventilación cruzada.
$txt$,
    true, 1
WHERE NOT EXISTS (
    SELECT 1 FROM maintenance_manuals WHERE tenant_id=1 AND file_name='atlas_copco_ga22.txt'
);

INSERT INTO maintenance_manuals
    (tenant_id, node_id, title, description, file_name, original_name,
     mime_type, file_size, file_path, content_text, is_active, uploaded_by)
SELECT 1, (SELECT id FROM bonarea_demo_ids WHERE key='selladora'),
    'CRYOVAC ST98 — Operación HACCP',
    'Procedimiento HACCP del túnel de retracción al vapor.',
    'cryovac_st98_haccp.txt', 'CRYOVAC_ST98_HACCP.pdf',
    'text/plain', 4200,
    '/seed/manuals/cryovac_st98_haccp.txt',
$txt$CRYOVAC ST98 — Operación y control HACCP

1. PUNTO CRÍTICO DE CONTROL (PCC)
- Temperatura del túnel: 88-92 °C.
- Tiempo de retracción: 1.8-2.4 s.
- Si la temperatura cae por debajo de 85 °C durante >2 minutos, alarma y producto en cuarentena.

2. COMPROBACIONES DIARIAS
- Verificar caudal de vapor (manómetro 4-6 bar).
- Inspeccionar boquillas: limpiar con agua a presión si hay obstrucción.
- Comprobar puerta de entrada/salida: deben cerrar sin fricción.

3. SEGURIDAD
- Quemaduras por vapor: usar EPI (guantes térmicos clase 3) en cualquier intervención.
- Antes de abrir trampillas, despresurizar y esperar 5 min de enfriamiento.

4. SUSTITUCIÓN DE BOQUILLAS
- Cada 6.000 h o cuando se observe distribución irregular de vapor.
- Repuesto: Sealed Air ST98-NZL-12 (juego de 12 boquillas).
$txt$,
    true, 1
WHERE NOT EXISTS (
    SELECT 1 FROM maintenance_manuals WHERE tenant_id=1 AND file_name='cryovac_st98_haccp.txt'
);

COMMIT;

-- Verification
SELECT id, name, code FROM equipment_compositions WHERE tenant_id=1;
SELECT count(*) AS slots FROM composition_template_slots
  WHERE template_id IN (SELECT id FROM composition_templates WHERE tenant_id=1);
SELECT count(*) AS members FROM equipment_composition_members
  WHERE composition_id IN (SELECT id FROM equipment_compositions WHERE tenant_id=1);
SELECT id, title, length(content_text) AS chars FROM maintenance_manuals WHERE tenant_id=1 ORDER BY id;
