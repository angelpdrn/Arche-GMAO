-- ============================================================
-- BonArea Demo - Block 12: Historical health score + ai_knowledge + extras
-- ============================================================

BEGIN;

-- ─── HEALTH WEIGHT CONFIGS per node type ──────────────────────────────
INSERT INTO health_weight_configs (tenant_id, node_type, weights, expected_life_years, decay_per_day)
VALUES
(1, 'equipment',
 '{"failure_freq":0.30,"pm_compliance":0.25,"age":0.10,"mtbf_trend":0.15,"corrective_ratio":0.15,"parts_consumption":0.05}'::jsonb,
 12, 0.10),
(1, 'composition',
 '{"failure_freq":0.25,"pm_compliance":0.30,"age":0.10,"mtbf_trend":0.15,"corrective_ratio":0.15,"parts_consumption":0.05}'::jsonb,
 15, 0.08)
ON CONFLICT (tenant_id, node_type) DO NOTHING;

-- ─── Current HEALTH SCORE + history ─────────────────────────────────────
DO $$
DECLARE
    rec RECORD;
    d INTEGER;
    base_score INTEGER;
    score INTEGER;
    drift NUMERIC;
BEGIN
    -- Para cada equipo, fijamos un score base según su histórico de fallos
    FOR rec IN
        SELECT id, code, criticality FROM factory_nodes
        WHERE tenant_id=1 AND node_type IN ('equipment','composition')
    LOOP
        -- Cinta B: muchos fallos → score bajo
        -- Cognex: bastantes → medio-bajo
        -- Robot, selladora: críticos pero bien mantenidos → medio-alto
        -- Resto: bien
        base_score := CASE
            WHEN rec.code = 'CTA-B'   THEN 58
            WHEN rec.code = 'CAM-CX1' THEN 68
            WHEN rec.code = 'COMP-GA22' THEN 75
            WHEN rec.code = 'SEL-ST98' THEN 78
            WHEN rec.code = 'ROBOT-R1' THEN 82
            WHEN rec.code = 'PESA-M14' THEN 85
            WHEN rec.code = 'PLC-CC1' THEN 87
            WHEN rec.code = 'COMP-TRIPLE-PICK' THEN 72
            ELSE 88
        END;

        -- Insertar score actual en el nodo
        UPDATE factory_nodes SET
            health_score = base_score,
            health_calculated_at = NOW(),
            health_details = jsonb_build_object(
                'failure_freq',     jsonb_build_object('penalty', GREATEST(0, 25 - base_score/4),  'weight', 0.30, 'raw', GREATEST(0, 8 - base_score/12)),
                'pm_compliance',    jsonb_build_object('penalty', GREATEST(0, 18 - base_score/5),  'weight', 0.25, 'raw', LEAST(1.0, base_score/100.0)),
                'age',              jsonb_build_object('penalty', 8, 'weight', 0.10, 'raw', 0.4),
                'mtbf_trend',       jsonb_build_object('penalty', CASE WHEN base_score < 70 THEN 12 ELSE 4 END, 'weight', 0.15, 'raw', CASE WHEN base_score < 70 THEN -0.2 ELSE 0.05 END),
                'corrective_ratio', jsonb_build_object('penalty', GREATEST(0, 20 - base_score/4),  'weight', 0.15, 'raw', GREATEST(0.1, 1.0 - base_score/100.0)),
                'parts_consumption',jsonb_build_object('penalty', 3, 'weight', 0.05, 'raw', 1.0),
                'criticality_mult', CASE rec.criticality WHEN 'critical' THEN 1.2 WHEN 'high' THEN 1.1 ELSE 1.0 END,
                'total_penalty',    100 - base_score,
                'final_score',      base_score
            )
        WHERE id = rec.id;

        -- Insertar 60 días de historial con drift gradual (mejora o empeora según equipo)
        FOR d IN 0..60 LOOP
            -- Cinta B muestra deterioro creciente (más reciente = peor)
            IF rec.code = 'CTA-B' THEN
                drift := (60 - d) * 0.15;  -- hace 60 días estaba mejor
                score := LEAST(95, GREATEST(40, base_score + drift::int + (random()*4 - 2)::int));
            -- Cognex se estabiliza
            ELSIF rec.code = 'CAM-CX1' THEN
                drift := CASE WHEN d > 30 THEN (d-30) * 0.3 ELSE 0 END;
                score := LEAST(95, GREATEST(50, base_score + drift::int + (random()*4 - 2)::int));
            ELSE
                -- Resto: variaciones aleatorias pequeñas
                score := LEAST(98, GREATEST(50, base_score + (random()*6 - 3)::int));
            END IF;

            INSERT INTO equipment_health_history (tenant_id, node_id, score, recorded_at, details)
            VALUES (1, rec.id, score, CURRENT_DATE - d,
                    jsonb_build_object('final_score', score, 'snapshot', 'demo'))
            ON CONFLICT (node_id, recorded_at) DO NOTHING;
        END LOOP;
    END LOOP;
END $$;

-- ─── AI KNOWLEDGE BASE ────────────────────────────────────────────────────
INSERT INTO ai_knowledge (tenant_id, title, content, category, folder, source, is_active, created_by)
VALUES
(1, 'Política HACCP de la línea L-01',
 E'La línea L-01 de selección triple es PCC HACCP por la temperatura del túnel CRYOVAC ST98 (88-92 °C). Cualquier desviación >2 minutos por debajo de 85 °C requiere bloqueo inmediato del lote y aviso a Calidad. Los registros de temperatura se conservan 5 años.',
 'normativa', 'HACCP', 'manual_calidad', true, 1),

(1, 'Niveles ATEX en zona célula L-01',
 E'La célula Triple-Pick NO se encuentra en zona ATEX. La sala de compresores Atlas Copco GA22 tampoco (ventilación cruzada certificada). Sí está clasificada como zona ATEX 22 la sala de envasado de polvos cárnicos seca anexa, donde no opera ningún equipo de mantenimiento de esta línea.',
 'normativa', 'Seguridad', 'manual_PRL', true, 1),

(1, 'Procedimiento parada controlada de la línea por mantenimiento',
 E'1. Avisar a producción 30 min antes.\n2. Programar parada en HMI principal.\n3. Vaciar cintas (~3 min).\n4. Esperar fin de lote en selladora.\n5. Aplicar LOTO en TODOS los puntos: seccionador eléctrico, válvula de aire, válvula de vapor.\n6. Confirmar con multímetro ausencia de tensión.',
 'procedimiento', 'Operaciones', 'SOP-MANT-001', true, 1),

(1, 'Histórico de fallos cinta B (chorizo)',
 E'La cinta CTA-B presenta un patrón recurrente de fallos del motor RollerDrive (Interroll EC5000-200-50). En el último año se han registrado 8 sustituciones, frente a 0 en cintas A y C. La causa raíz confirmada por el fabricante es la contaminación del rodamiento interno con grasa del producto cárnico (chorizo, más graso que salchichón y fuet). Se ha abierto caso técnico con Interroll para evaluar variante IP66.',
 'historial', 'Fallos recurrentes', 'analisis_RCA', true, 1),

(1, 'Sustitución correa GT2 robot ABB',
 E'La correa GT2 de la rótula central del robot debe reemplazarse cada 8.000 h o cuando la deflexión a 10 N esté fuera del rango 3-5 mm. Repuesto: ABB 3HAC027433-001. Tras la sustitución es OBLIGATORIO recalibrar el TCP con utillaje de pin. Tolerancia post-calibración: ±0.2 mm en pick.',
 'mantenimiento', 'Robot ABB', 'manual_ABB', true, 1),

(1, 'Calibración semanal pesadora MULTIPOND',
 E'Calibrar todas las 14 cabezas con pesa patrón certificada de 200 g clase F1. Tolerancia: ±0.2 g por cabeza. Si una cabeza está fuera de tolerancia tras tarado, sustituir la célula KMD-208. Imprimir certificado y archivar en carpeta HACCP.',
 'mantenimiento', 'Pesadora', 'PM-7', true, 1),

(1, 'Cambio de aceite compresor Atlas Copco',
 E'Cada 4.000 h. Aceite Roto-Xtend Duty Fluid 4000h ref. 1630-2076-00, capacidad 7.5 L. Sustituir simultáneamente filtro de aceite (1622-3651-00) y separador (1622-3148-00). Aceite usado = residuo peligroso, gestionar mediante gestor autorizado.',
 'mantenimiento', 'Compresor', 'PM-180', true, 1),

(1, 'EPI obligatorio en selladora CRYOVAC',
 E'Cualquier intervención en la selladora CRYOVAC ST98 (purga, limpieza, sustitución boquillas) requiere EPI clase 3: guantes térmicos clase 3, gafas de protección, pantalla facial. Antes de abrir trampillas, despresurizar línea de vapor y esperar enfriamiento mínimo 30 minutos.',
 'PRL', 'EPI', 'manual_PRL_v2', true, 1),

(1, 'Composición de la célula Triple-Pick',
 E'La célula consta de: 1 brazo robótico ABB IRB 360-3/1130 FlexPicker, 1 cámara visión Cognex In-Sight 9912, 3 cintas Interroll MCP 5500-200 (A=salchichón, B=chorizo, C=fuet), 1 pesadora MULTIPOND PMC 14, 1 etiquetadora Markem-Imaje 9450, 1 selladora CRYOVAC ST98, 1 PLC Siemens S7-1517F-3, 1 compresor Atlas Copco GA22 VSD+. Producción nominal 800 paquetes/h.',
 'arquitectura', 'Línea L-01', 'doc_diseno', true, 1),

(1, 'Limites de operación y alarmas',
 E'Robot: temperatura motor < 65°C; presión ventosa 700-900 mbar.\nCognex: imagen luminosidad 40-200; conexión Profinet OK.\nCintas: velocidad 0.6-1.2 m/s; corriente motor < 2.4 A.\nPesadora: tolerancia ±0.5 g; cabezas activas ≥ 12.\nSelladora: 88-92 °C, vapor 4-6 bar.\nCompresor: 7-10 bar; aceite > 60°C; filtro separador < 1.5 bar caída.',
 'parámetros', 'Setpoints', 'doc_operacion', true, 1)
ON CONFLICT DO NOTHING;

-- ─── NOTIFICATIONS (some active so the badge shows) ──────────────
DO $$
DECLARE
    u_caristiven BIGINT;
    u_angel BIGINT;
    u_andres BIGINT;
BEGIN
    SELECT id INTO u_caristiven FROM users WHERE email='caristiven.padrino@bonarea.local';
    SELECT id INTO u_angel      FROM users WHERE email='angel.padrino@bonarea.local';
    SELECT id INTO u_andres     FROM users WHERE email='andres.padrino@bonarea.local';

    INSERT INTO notifications (tenant_id, user_id, type, title, body, link, is_read, created_at) VALUES
    (1, u_andres, 'stock_low', 'Stock bajo: Motor RollerDrive Interroll',
     'El repuesto RP-INT-EC5000 está a 0 unidades (mínimo 2). Pedir urgente.',
     '/inventory', false, NOW() - interval '2 hours'),

    (1, u_andres, 'stock_low', 'Stock bajo: LED iluminador Cognex',
     'El repuesto RP-COG-LED-RING está a 1 unidad (mínimo 2).',
     '/inventory', false, NOW() - interval '5 hours'),

    (1, u_caristiven, 'pattern_detected', 'Patrón de fallos en cinta B',
     '8 fallos correctivos del motor RollerDrive en 90 días. Considerar acción correctiva permanente.',
     '/dashboard', false, NOW() - interval '1 hour'),

    (1, u_caristiven, 'pattern_detected', 'Stock crítico: 6 repuestos bajo mínimo',
     'Repuestos por debajo del mínimo: motor Interroll, LED Cognex, célula MULTIPOND, boquillas CRYOVAC, makeup Markem, tarjeta DI16.',
     '/inventory?low_stock=true', true, NOW() - interval '1 day'),

    (1, u_angel, 'wo_assigned', 'Nueva OT asignada: Boquillas vapor',
     'Se te ha asignado: Boquillas vapor con distribución irregular - Selladora CRYOVAC ST98',
     '/work-orders', false, NOW() - interval '6 days'),

    (1, u_angel, 'wo_assigned', 'PM próximo: Inspección correa GT2 robot ABB',
     'Mantenimiento mensual programado para mañana.',
     '/work-orders', true, NOW() - interval '1 day'),

    (1, u_caristiven, 'wo_to_verify', '3 OTs pendientes de verificación',
     'Tienes 3 OTs completadas esperando tu verificación.',
     '/work-orders?status=completed', false, NOW() - interval '12 hours');
END $$;

-- ─── Demo QR SCANS ────────────────────────────────────────────
DO $$
DECLARE
    u_angel BIGINT; u_ysabel BIGINT;
    n_robot BIGINT; n_cinta_b BIGINT; n_pesadora BIGINT;
BEGIN
    SELECT id INTO u_angel FROM users WHERE email='angel.padrino@bonarea.local';
    SELECT id INTO u_ysabel FROM users WHERE email='ysabel.salazar@bonarea.local';
    SELECT id INTO n_robot FROM bonarea_demo_ids WHERE key='robot';
    SELECT id INTO n_cinta_b FROM bonarea_demo_ids WHERE key='cinta_b';
    SELECT id INTO n_pesadora FROM bonarea_demo_ids WHERE key='pesadora';

    INSERT INTO qr_scans (tenant_id, node_id, scanned_by, ip_address, user_agent, created_at)
    SELECT 1, n.node_id, n.user_id, '192.168.1.50', 'Mozilla/5.0 (Linux; Android 13) Chrome/120 Mobile Safari',
           NOW() - (random()*60 || ' days')::interval
    FROM (
        SELECT n_robot AS node_id, u_angel AS user_id FROM generate_series(1,8)
        UNION ALL
        SELECT n_cinta_b, u_angel FROM generate_series(1,12)
        UNION ALL
        SELECT n_cinta_b, u_ysabel FROM generate_series(1,15)
        UNION ALL
        SELECT n_pesadora, u_ysabel FROM generate_series(1,10)
    ) n;
END $$;

-- ─── CALENDAR EVENTS (upcoming PMs) ─────────────────────────────────
DO $$
DECLARE
    u_angel BIGINT;
BEGIN
    SELECT id INTO u_angel FROM users WHERE email='angel.padrino@bonarea.local';

    INSERT INTO calendar_events (tenant_id, user_id, wo_id, title, description, event_type, color, start_at, end_at, is_auto)
    SELECT 1, u_angel, NULL,
           'Próximo PM: ' || mp.title,
           mp.description,
           'preventive', '#0F3460',
           mp.next_due_at, mp.next_due_at + interval '2 hours',
           true
      FROM maintenance_plans mp
     WHERE mp.tenant_id=1 AND mp.is_active=true AND mp.next_due_at < NOW() + interval '30 days'
     ORDER BY mp.next_due_at LIMIT 10;
END $$;

COMMIT;

-- Verification
SELECT 'health_history' AS tabla, count(*) FROM equipment_health_history
UNION ALL SELECT 'ai_knowledge', count(*) FROM ai_knowledge WHERE tenant_id=1
UNION ALL SELECT 'notifications', count(*) FROM notifications WHERE tenant_id=1
UNION ALL SELECT 'qr_scans', count(*) FROM qr_scans WHERE tenant_id=1
UNION ALL SELECT 'calendar_events', count(*) FROM calendar_events WHERE tenant_id=1;

SELECT name, code, health_score, criticality FROM factory_nodes
  WHERE tenant_id=1 AND health_score IS NOT NULL ORDER BY health_score;
