-- ============================================================
-- BonArea Demo - Block 10: Spare part consumption + comments + verifications + scores
-- ============================================================

BEGIN;

DO $$
DECLARE
    u_admin BIGINT;
    u_caristiven BIGINT;
    u_angel BIGINT;
    u_ysabel BIGINT;
    u_andres BIGINT;
    rec RECORD;
    v_wo_id BIGINT;
    v_part_id BIGINT;
    v_qty NUMERIC;
BEGIN
    SELECT id INTO u_admin      FROM users WHERE email='admin@arche.local';
    SELECT id INTO u_caristiven FROM users WHERE email='caristiven.padrino@bonarea.local';
    SELECT id INTO u_angel      FROM users WHERE email='angel.padrino@bonarea.local';
    SELECT id INTO u_ysabel     FROM users WHERE email='ysabel.salazar@bonarea.local';
    SELECT id INTO u_andres     FROM users WHERE email='andres.padrino@bonarea.local';

    -- ─── CONSUMO DE REPUESTOS por OTs cerradas ────────────────────────────
    -- Cinta B - 8 sustituciones de motor → cada una consumió 1 motor RollerDrive
    FOR rec IN
        SELECT id, completed_at FROM work_orders
        WHERE tenant_id=1 AND title LIKE '%cinta B%' AND status='closed'
          AND (root_cause LIKE '%Sust%' OR solution LIKE '%Sustitución motor%')
        ORDER BY completed_at
    LOOP
        v_wo_id := rec.id;
        SELECT id INTO v_part_id FROM spare_parts WHERE tenant_id=1 AND code='RP-INT-EC5000';
        INSERT INTO work_order_parts (wo_id, spare_part_id, quantity)
        VALUES (v_wo_id, v_part_id, 1) ON CONFLICT DO NOTHING;
        -- registro de movimiento (out)
        INSERT INTO stock_movements (tenant_id, spare_part_id, movement_type, quantity, unit_cost,
                                     stock_before, stock_after, notes, created_by, created_at)
        VALUES (1, v_part_id, 'out', 1, 845.00, 0, 0,
                'Consumido en OT cinta B (siembra demo)', u_andres, rec.completed_at);
    END LOOP;

    -- Robot ABB - sustitución correa GT2 (OT seq 16)
    SELECT id INTO v_wo_id FROM work_orders WHERE tenant_id=1 AND title='Error E0021 robot ABB';
    SELECT id INTO v_part_id FROM spare_parts WHERE tenant_id=1 AND code='RP-ABB-CORREA-GT2';
    INSERT INTO work_order_parts (wo_id, spare_part_id, quantity) VALUES (v_wo_id, v_part_id, 1) ON CONFLICT DO NOTHING;
    INSERT INTO stock_movements (tenant_id, spare_part_id, movement_type, quantity, unit_cost,
                                 stock_before, stock_after, notes, created_by, created_at)
    VALUES (1, v_part_id, 'out', 1, 142.00, 4, 3, 'Consumido en OT correa GT2', u_andres, NOW() - interval '178 days');

    -- Robot - membrana ventosa (OT 15)
    SELECT id INTO v_wo_id FROM work_orders WHERE tenant_id=1 AND title='Robot pierde vacío en pinza';
    SELECT id INTO v_part_id FROM spare_parts WHERE tenant_id=1 AND code='RP-ABB-VENTOSA-ALI';
    INSERT INTO work_order_parts (wo_id, spare_part_id, quantity) VALUES (v_wo_id, v_part_id, 2) ON CONFLICT DO NOTHING;
    INSERT INTO stock_movements (tenant_id, spare_part_id, movement_type, quantity, unit_cost,
                                 stock_before, stock_after, notes, created_by, created_at)
    VALUES (1, v_part_id, 'out', 2, 8.75, 14, 12, 'Sustitución membrana ventosa', u_andres, NOW() - interval '220 days');

    -- Cognex - LED ring sustituido (OT 12)
    SELECT id INTO v_wo_id FROM work_orders WHERE tenant_id=1 AND title='LED iluminador no enciende';
    SELECT id INTO v_part_id FROM spare_parts WHERE tenant_id=1 AND code='RP-COG-LED-RING';
    INSERT INTO work_order_parts (wo_id, spare_part_id, quantity) VALUES (v_wo_id, v_part_id, 1) ON CONFLICT DO NOTHING;
    INSERT INTO stock_movements (tenant_id, spare_part_id, movement_type, quantity, unit_cost,
                                 stock_before, stock_after, notes, created_by, created_at)
    VALUES (1, v_part_id, 'out', 1, 215.00, 2, 1, 'Sustitución anillo iluminador Cognex', u_andres, NOW() - interval '122 days');

    -- Pesadora - célula KMD (OT 19)
    SELECT id INTO v_wo_id FROM work_orders WHERE tenant_id=1 AND title='Cabeza 7 fuera de tolerancia';
    SELECT id INTO v_part_id FROM spare_parts WHERE tenant_id=1 AND code='RP-MUL-CELDA-KMD';
    INSERT INTO work_order_parts (wo_id, spare_part_id, quantity) VALUES (v_wo_id, v_part_id, 1) ON CONFLICT DO NOTHING;
    INSERT INTO stock_movements (tenant_id, spare_part_id, movement_type, quantity, unit_cost,
                                 stock_before, stock_after, notes, created_by, created_at)
    VALUES (1, v_part_id, 'out', 1, 480.00, 3, 2, 'Sustitución célula carga MULTIPOND', u_andres, NOW() - interval '175 days');

    -- Selladora - PT100 (OT 26)
    SELECT id INTO v_wo_id FROM work_orders WHERE tenant_id=1 AND title='Sonda PT100 fuera de rango';
    SELECT id INTO v_part_id FROM spare_parts WHERE tenant_id=1 AND code='RP-CRY-SENS-PT100';
    INSERT INTO work_order_parts (wo_id, spare_part_id, quantity) VALUES (v_wo_id, v_part_id, 1) ON CONFLICT DO NOTHING;
    INSERT INTO stock_movements (tenant_id, spare_part_id, movement_type, quantity, unit_cost,
                                 stock_before, stock_after, notes, created_by, created_at)
    VALUES (1, v_part_id, 'out', 1, 110.00, 3, 2, 'Sustitución sonda PT100', u_andres, NOW() - interval '145 days');

    -- PLC - tarjeta DI16 (OT 31)
    SELECT id INTO v_wo_id FROM work_orders WHERE tenant_id=1 AND title='Tarjeta DI16 con entradas erráticas';
    SELECT id INTO v_part_id FROM spare_parts WHERE tenant_id=1 AND code='RP-SIE-DI16';
    INSERT INTO work_order_parts (wo_id, spare_part_id, quantity) VALUES (v_wo_id, v_part_id, 1) ON CONFLICT DO NOTHING;
    INSERT INTO stock_movements (tenant_id, spare_part_id, movement_type, quantity, unit_cost,
                                 stock_before, stock_after, notes, created_by, created_at)
    VALUES (1, v_part_id, 'out', 1, 380.00, 2, 1, 'Sustitución tarjeta DI16', u_andres, NOW() - interval '22 days');

    -- Compresor - cambio aceite + filtros (OT 35 PM)
    SELECT id INTO v_wo_id FROM work_orders WHERE tenant_id=1 AND title='Service Plan A vencido';
    SELECT id INTO v_part_id FROM spare_parts WHERE tenant_id=1 AND code='RP-ATL-OIL-ROTO';
    INSERT INTO work_order_parts (wo_id, spare_part_id, quantity) VALUES (v_wo_id, v_part_id, 0.4) ON CONFLICT DO NOTHING;
    INSERT INTO stock_movements (tenant_id, spare_part_id, movement_type, quantity, unit_cost,
                                 stock_before, stock_after, notes, created_by, created_at)
    VALUES (1, v_part_id, 'out', 0.4, 175.00, 4.4, 4.0, 'PM-180 cambio aceite', u_andres, NOW() - interval '40 days');
    SELECT id INTO v_part_id FROM spare_parts WHERE tenant_id=1 AND code='RP-ATL-FILT-OIL';
    INSERT INTO work_order_parts (wo_id, spare_part_id, quantity) VALUES (v_wo_id, v_part_id, 1) ON CONFLICT DO NOTHING;
    INSERT INTO stock_movements (tenant_id, spare_part_id, movement_type, quantity, unit_cost,
                                 stock_before, stock_after, notes, created_by, created_at)
    VALUES (1, v_part_id, 'out', 1, 38.00, 4, 3, 'PM-180 filtro aceite', u_andres, NOW() - interval '40 days');
    SELECT id INTO v_part_id FROM spare_parts WHERE tenant_id=1 AND code='RP-ATL-FILT-SEP';
    INSERT INTO work_order_parts (wo_id, spare_part_id, quantity) VALUES (v_wo_id, v_part_id, 1) ON CONFLICT DO NOTHING;
    INSERT INTO stock_movements (tenant_id, spare_part_id, movement_type, quantity, unit_cost,
                                 stock_before, stock_after, notes, created_by, created_at)
    VALUES (1, v_part_id, 'out', 1, 95.00, 3, 2, 'PM-180 filtro separador', u_andres, NOW() - interval '40 days');

    -- Etiquetadora - tinta+makeup (cada PM mensual)
    FOR rec IN SELECT id, completed_at FROM work_orders
        WHERE tenant_id=1 AND title='PM-30: Cambio tinta + makeup etiquetadora' AND status='closed'
        ORDER BY completed_at
    LOOP
        v_wo_id := rec.id;
        SELECT id INTO v_part_id FROM spare_parts WHERE tenant_id=1 AND code='RP-MAR-TINTA-CIJ';
        INSERT INTO work_order_parts (wo_id, spare_part_id, quantity) VALUES (v_wo_id, v_part_id, 1) ON CONFLICT DO NOTHING;
        INSERT INTO stock_movements (tenant_id, spare_part_id, movement_type, quantity, unit_cost,
                                     stock_before, stock_after, notes, created_by, created_at)
        VALUES (1, v_part_id, 'out', 1, 95.00, 0, 0, 'Consumo PM mensual', u_andres, rec.completed_at);

        SELECT id INTO v_part_id FROM spare_parts WHERE tenant_id=1 AND code='RP-MAR-MAKEUP';
        INSERT INTO work_order_parts (wo_id, spare_part_id, quantity) VALUES (v_wo_id, v_part_id, 1) ON CONFLICT DO NOTHING;
        INSERT INTO stock_movements (tenant_id, spare_part_id, movement_type, quantity, unit_cost,
                                     stock_before, stock_after, notes, created_by, created_at)
        VALUES (1, v_part_id, 'out', 1, 64.00, 0, 0, 'Consumo PM mensual', u_andres, rec.completed_at);
    END LOOP;

    -- Robot - grasa cada PM-90 trimestral (3 ejecuciones)
    FOR rec IN SELECT id, completed_at FROM work_orders
        WHERE tenant_id=1 AND title='PM-90: Lubricación cojinetes robot ABB' AND status='closed'
        ORDER BY completed_at
    LOOP
        v_wo_id := rec.id;
        SELECT id INTO v_part_id FROM spare_parts WHERE tenant_id=1 AND code='RP-ABB-GRASA-MOBI';
        INSERT INTO work_order_parts (wo_id, spare_part_id, quantity) VALUES (v_wo_id, v_part_id, 1) ON CONFLICT DO NOTHING;
        INSERT INTO stock_movements (tenant_id, spare_part_id, movement_type, quantity, unit_cost,
                                     stock_before, stock_after, notes, created_by, created_at)
        VALUES (1, v_part_id, 'out', 1, 18.50, 0, 0, 'Consumo PM-90 robot', u_andres, rec.completed_at);
    END LOOP;

    -- Cinta B - rodamientos en PM reforzado
    FOR rec IN SELECT id, completed_at FROM work_orders
        WHERE tenant_id=1 AND title='PM-30 reforzado: Cinta B - Inspección RollerDrive' AND status='closed'
        ORDER BY completed_at
    LOOP
        v_wo_id := rec.id;
        SELECT id INTO v_part_id FROM spare_parts WHERE tenant_id=1 AND code='RP-INT-RODAM-6203';
        INSERT INTO work_order_parts (wo_id, spare_part_id, quantity) VALUES (v_wo_id, v_part_id, 2) ON CONFLICT DO NOTHING;
        INSERT INTO stock_movements (tenant_id, spare_part_id, movement_type, quantity, unit_cost,
                                     stock_before, stock_after, notes, created_by, created_at)
        VALUES (1, v_part_id, 'out', 2, 6.20, 0, 0, 'PM cinta B rodamientos', u_andres, rec.completed_at);
    END LOOP;

    -- ─── ENTRADAS DE STOCK (compras / entradas almacén) ─────────────────────
    -- Reposiciones para que el current_stock final cuadre
    SELECT id INTO v_part_id FROM spare_parts WHERE tenant_id=1 AND code='RP-INT-EC5000';
    INSERT INTO stock_movements (tenant_id, spare_part_id, movement_type, quantity, unit_cost,
                                 stock_before, stock_after, notes, created_by, created_at)
    VALUES (1, v_part_id, 'in', 8, 845.00, 0, 8, 'Compra a Interroll: 8 motores RollerDrive', u_andres, NOW() - interval '250 days'),
           (1, v_part_id, 'in', 4, 845.00, 0, 4, 'Reposición urgente Interroll', u_andres, NOW() - interval '90 days');

    SELECT id INTO v_part_id FROM spare_parts WHERE tenant_id=1 AND code='RP-ABB-CORREA-GT2';
    INSERT INTO stock_movements (tenant_id, spare_part_id, movement_type, quantity, unit_cost,
                                 stock_before, stock_after, notes, created_by, created_at)
    VALUES (1, v_part_id, 'in', 4, 142.00, 0, 4, 'Pedido inicial ABB Robotics', u_andres, NOW() - interval '300 days');

    SELECT id INTO v_part_id FROM spare_parts WHERE tenant_id=1 AND code='RP-ABB-GRASA-MOBI';
    INSERT INTO stock_movements (tenant_id, spare_part_id, movement_type, quantity, unit_cost,
                                 stock_before, stock_after, notes, created_by, created_at)
    VALUES (1, v_part_id, 'in', 12, 18.50, 0, 12, 'Pedido lubricantes Brammer', u_andres, NOW() - interval '300 days');

    SELECT id INTO v_part_id FROM spare_parts WHERE tenant_id=1 AND code='RP-MAR-TINTA-CIJ';
    INSERT INTO stock_movements (tenant_id, spare_part_id, movement_type, quantity, unit_cost,
                                 stock_before, stock_after, notes, created_by, created_at)
    VALUES (1, v_part_id, 'in', 12, 95.00, 0, 12, 'Pedido tintas trimestral', u_andres, NOW() - interval '300 days'),
           (1, v_part_id, 'in', 6, 95.00, 0, 6, 'Reposición tintas', u_andres, NOW() - interval '60 days');

    -- ─── COMENTARIOS en OTs cerradas (selección, no todas) ────────────────
    -- En las OTs de cinta B ponemos varios comentarios para mostrar diálogo técnico
    FOR rec IN SELECT id, completed_at, title FROM work_orders WHERE tenant_id=1
        AND title LIKE '%cinta B%' AND status='closed' ORDER BY completed_at LIMIT 3
    LOOP
        INSERT INTO work_order_comments (tenant_id, wo_id, user_id, content, created_at) VALUES
        (1, rec.id, u_ysabel, 'Cinta detenida hace 5 minutos. Producto acumulado en cabezal.', rec.completed_at - interval '90 minutes'),
        (1, rec.id, u_caristiven, 'Voy en camino. Llamo al técnico.', rec.completed_at - interval '85 minutes'),
        (1, rec.id, u_angel, 'Termografía hecha. Confirmo motor sobrecalentado. Procedo a sustituir.', rec.completed_at - interval '70 minutes'),
        (1, rec.id, u_angel, 'Sustitución completada. Línea de vuelta a producción.', rec.completed_at - interval '5 minutes');
    END LOOP;

    -- Comentarios en OT del robot (correa)
    SELECT id INTO v_wo_id FROM work_orders WHERE tenant_id=1 AND title='Error E0021 robot ABB' LIMIT 1;
    INSERT INTO work_order_comments (tenant_id, wo_id, user_id, content, created_at) VALUES
    (1, v_wo_id, u_ysabel, 'Robot detenido al inicio de turno. Display muestra E0021.',
        (SELECT completed_at FROM work_orders WHERE id=v_wo_id) - interval '2 hours'),
    (1, v_wo_id, u_angel, 'Inspeccionada la correa: deflexión 8 mm, fuera de tolerancia. Sustituyo.',
        (SELECT completed_at FROM work_orders WHERE id=v_wo_id) - interval '90 minutes'),
    (1, v_wo_id, u_angel, 'Recalibración TCP completada. ±0.15 mm en pick.',
        (SELECT completed_at FROM work_orders WHERE id=v_wo_id) - interval '15 minutes');

    -- ─── VERIFICATION RECORDS para OTs verified/closed ─────────────────────
    -- Insertar para todas las OTs verified+closed
    FOR rec IN SELECT id, completed_at, assigned_to, created_by FROM work_orders
        WHERE tenant_id=1 AND status IN ('verified','closed') AND completed_at IS NOT NULL
    LOOP
        INSERT INTO verification_records
            (tenant_id, wo_id, submitted_by, verified_by, status, confidence_level, notes,
             submitted_at, verified_at)
        VALUES (1, rec.id, rec.assigned_to, rec.created_by,
                'approved', 4 + (random()*1)::int,
                'Trabajo verificado correctamente. Equipo operativo.',
                rec.completed_at, rec.completed_at + interval '30 minutes')
        ON CONFLICT DO NOTHING;
    END LOOP;

    -- ─── WO SCORES (puntuación del trabajo del técnico) ─────────────────────
    FOR rec IN SELECT id, completed_at, assigned_to, created_by FROM work_orders
        WHERE tenant_id=1 AND status='closed' AND completed_at IS NOT NULL
        ORDER BY completed_at DESC LIMIT 30
    LOOP
        INSERT INTO wo_scores (tenant_id, wo_id, user_id, scored_by, score, comment, created_at)
        VALUES (1, rec.id, rec.assigned_to, rec.created_by,
                4 + (random()*1)::int,
                CASE WHEN random()>0.6 THEN 'Trabajo bien ejecutado.'
                     WHEN random()>0.3 THEN 'Buena resolución.'
                     ELSE 'Excelente. Equipo recuperado en tiempo récord.' END,
                rec.completed_at + interval '1 hour')
        ON CONFLICT DO NOTHING;
    END LOOP;

    RAISE NOTICE 'Consumo: % piezas en %=OTs',
        (SELECT count(*) FROM work_order_parts),
        (SELECT count(DISTINCT wo_id) FROM work_order_parts);
END $$;

COMMIT;

-- Verification
SELECT 'work_order_parts' AS tabla, count(*) FROM work_order_parts
UNION ALL SELECT 'stock_movements', count(*) FROM stock_movements
UNION ALL SELECT 'work_order_comments', count(*) FROM work_order_comments
UNION ALL SELECT 'verification_records', count(*) FROM verification_records
UNION ALL SELECT 'wo_scores', count(*) FROM wo_scores;
