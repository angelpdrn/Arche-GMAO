-- ============================================================
-- BonArea Demo - Block 15: Complete professional checklists
-- ============================================================
-- Enriches the 13 maintenance_plans with detailed
-- checklists (10-15 items each) to show clients the
-- operational depth of the CMMS.
-- ============================================================

BEGIN;

-- ─── PLAN 1: PM-90 ABB robot bearing lubrication ──────────────────────
UPDATE maintenance_plans SET
    instructions = E'1. Aislar el robot mediante el seccionador principal del armario eléctrico.\n2. Aplicar candado y tarjeta personal de bloqueo (LOTO).\n3. Despresurizar la línea neumática del eyector de vacío.\n4. Verificar con multímetro la ausencia de tensión en bornes del motor.\n5. Limpiar los puntos de engrase con paño limpio sin pelusa y alcohol isopropílico.\n6. Aplicar 5 g de Mobilith SHC 220 en cada uno de los 8 cojinetes con pistola manual calibrada.\n7. Mover manualmente los brazos para distribuir la grasa, escuchando ruidos anómalos.\n8. Limpiar excesos visibles.\n9. Inspeccionar visualmente correas, articulaciones y cableado expuesto.\n10. Retirar LOTO siguiendo el orden inverso.\n11. Verificar arranque suave en modo manual antes de devolver a producción.\n12. Anotar lectura en el logbook del robot.',
    checklist = '[
        {"step":"EPI completo: gafas, guantes mecánicos, calzado de seguridad","required":true},
        {"step":"Permiso de trabajo PT-RB firmado por el supervisor","required":true},
        {"step":"Robot en posición HOME y modo manual desde FlexPendant","required":true},
        {"step":"Seccionador principal del armario en OFF + candado LOTO colocado","required":true},
        {"step":"Tarjeta personal de bloqueo con nombre y fecha","required":true},
        {"step":"Línea neumática despresurizada (manómetro a 0 bar)","required":true},
        {"step":"Verificación ausencia de tensión en bornes con multímetro","required":true},
        {"step":"8 puntos de engrase limpios, sin restos de grasa antigua oxidada","required":true},
        {"step":"Grasa Mobilith SHC 220 aplicada (5 g por punto, 40 g totales)","required":true},
        {"step":"Movimiento manual de los 4 brazos sin ruidos metálicos","required":true},
        {"step":"Inspección visual de correa GT2: sin grietas ni deshilachado","required":true},
        {"step":"Inspección de cableado: sin daños, sin codos forzados","required":false},
        {"step":"Excesos de grasa retirados, zona limpia","required":true},
        {"step":"LOTO retirado siguiendo orden inverso documentado","required":true},
        {"step":"Test de arranque en modo manual a velocidad reducida (10%) durante 2 min","required":true},
        {"step":"Logbook firmado y fecha próxima inspección anotada","required":true}
    ]'::jsonb,
    safety_notes = E'⚠ RIESGO ELÉCTRICO: tensión 400 V en armario. LOTO no negociable.\n⚠ RIESGO DE APLASTAMIENTO: el robot puede caer si se quitan brazos sin soporte.\n⚠ RIESGO QUÍMICO: la grasa Mobilith SHC 220 es irritante en contacto prolongado con piel. Usar guantes nitrilo.\n⚠ ESPACIO CONFINADO: trabajar siempre con compañero designado para emergencias.\n⚠ Verificar enclavamientos del cerramiento perimetral antes de devolver a producción.',
    tools_required = '["Pistola de engrase manual calibrada","Cartucho Mobilith SHC 220","Llave Allen 4 mm","Llave Allen 6 mm","Multímetro Fluke 87V","Paños sin pelusa Kimtech","Alcohol isopropílico 99%","Linterna LED frontal","Candado LOTO personal","Tarjeta de bloqueo","Termómetro infrarrojo","Cuaderno de inspección"]'::jsonb,
    required_parts = '[{"code":"RP-ABB-GRASA-MOBI","qty":1,"notes":"1 cartucho cubre los 8 puntos"},{"code":"RP-ABB-CORREA-GT2","qty":0,"notes":"Solo si inspección detecta desgaste"}]'::jsonb,
    advance_days = 7
WHERE tenant_id=1 AND title='PM-90: Lubricación cojinetes robot ABB';

-- ─── PLAN 2: PM-30 ABB robot GT2 belt inspection ──────────────────────
UPDATE maintenance_plans SET
    instructions = E'1. LOTO eléctrico y neumático del robot.\n2. Abrir tapa de inspección de la rótula central (4 tornillos M5).\n3. Limpiar zona con paño y aire comprimido a baja presión (máx. 4 bar).\n4. Inspección visual: buscar grietas, dientes rotos, desgaste lateral.\n5. Aplicar 10 N en el punto medio de la correa con dinamómetro digital.\n6. Medir deflexión: tolerancia 3-5 mm. Si está fuera, generar OT correctiva.\n7. Verificar alineación de poleas con regla de precisión.\n8. Cerrar tapa con par 8 Nm en cada tornillo.\n9. Quitar LOTO.\n10. Test funcional a velocidad reducida en modo manual.',
    checklist = '[
        {"step":"EPI: gafas, guantes anticorte","required":true},
        {"step":"Permiso de trabajo firmado","required":true},
        {"step":"LOTO eléctrico colocado","required":true},
        {"step":"LOTO neumático aplicado (válvula bloqueada en cerrado)","required":true},
        {"step":"Tapa de inspección abierta sin daño en junta","required":true},
        {"step":"Zona limpia, sin polvo ni residuos de producto","required":true},
        {"step":"Inspección visual: sin grietas en flanco","required":true},
        {"step":"Inspección visual: sin dientes rotos ni deformados","required":true},
        {"step":"Inspección visual: sin desgaste lateral asimétrico","required":true},
        {"step":"Tensión correcta: deflexión 3-5 mm con 10 N (registrar valor)","required":true},
        {"step":"Alineación de poleas: desviación <0.5 mm","required":true},
        {"step":"Tornillos de la tapa apretados a 8 Nm","required":true},
        {"step":"Junta de la tapa sin deterioro (sustituir si procede)","required":false},
        {"step":"LOTO retirado","required":true},
        {"step":"Test funcional 30 s a velocidad 20% sin alarmas","required":true},
        {"step":"Lectura registrada en logbook con valor de deflexión","required":true}
    ]'::jsonb,
    safety_notes = E'⚠ El robot puede generar movimiento brusco al energizar si la cinemática se desconfigura. Validar siempre en modo manual antes de auto.\n⚠ El aire comprimido a alta presión puede dañar el ojo: gafas obligatorias.',
    tools_required = '["Dinamómetro digital 0-20 N","Regla de precisión 300 mm","Llave dinamométrica 0-20 Nm","Llave Allen 5 mm","Linterna LED","Pistola de aire comprimido (4 bar máx)","Paños limpios","Cuaderno de inspección"]'::jsonb
WHERE tenant_id=1 AND title='PM-30: Inspección correa GT2 robot ABB';

-- ─── PLAN 3: PM-7 Cognex optics cleaning ────────────────────────────────
UPDATE maintenance_plans SET
    instructions = E'1. Detener línea desde HMI principal (no usar E-Stop salvo emergencia).\n2. Aislar la cámara mediante mini-disyuntor del cuadro auxiliar.\n3. Esperar 30 s a que enfríe el LED iluminador.\n4. Limpiar objetivo con paño microfibra + Cognex VL-CL.\n5. Limpiar iluminador anular con bastoncillo + alcohol isopropílico (no usar VL-CL en el LED).\n6. Verificar imagen patrón en EasyBuilder: nitidez en las 4 esquinas.\n7. Calibración rápida si la luminosidad media está fuera de rango 80-160.\n8. Reactivar mini-disyuntor y reanudar línea.\n9. Confirmar primera detección correcta antes de marcharse.',
    checklist = '[
        {"step":"Línea detenida desde HMI principal (NO E-Stop)","required":true},
        {"step":"Mini-disyuntor de la cámara en OFF","required":true},
        {"step":"Esperado 30 s para enfriamiento del LED","required":true},
        {"step":"Objetivo limpio con paño microfibra + VL-CL","required":true},
        {"step":"Iluminador anular limpio con bastoncillo + isopropílico","required":true},
        {"step":"Sin marcas, polvo ni huellas digitales en el objetivo","required":true},
        {"step":"Imagen patrón nítida en las 4 esquinas","required":true},
        {"step":"Luminosidad media en rango 80-160 (registrar valor)","required":true},
        {"step":"Calibración color verificada con tarjeta de referencia","required":false},
        {"step":"Sin warnings en EasyBuilder","required":true},
        {"step":"Mini-disyuntor reactivado","required":true},
        {"step":"Primera detección de producto OK antes de finalizar","required":true},
        {"step":"Limpieza zona y residuos retirados","required":true}
    ]'::jsonb,
    safety_notes = E'⚠ NO usar disolventes agresivos (acetona, alcohol >70%, amoniaco) en el objetivo.\n⚠ La cámara es ESD sensible: pulsera antiestática recomendada.\n⚠ El LED puede alcanzar 60 °C tras horas de uso: esperar enfriamiento.',
    tools_required = '["Paño microfibra Cognex","Limpiador Cognex VL-CL","Alcohol isopropílico 99%","Bastoncillos algodón","Pulsera ESD","Linterna LED","Tarjeta calibración Macbeth"]'::jsonb,
    required_parts = '[{"code":"RP-COG-LENS-CL","qty":0.05,"notes":"Aprox 5 ml por limpieza"}]'::jsonb
WHERE tenant_id=1 AND title='PM-7: Limpieza óptica Cognex';

-- ─── PLAN 4: PM-60 Conveyor A belt tension ────────────────────────────────
UPDATE maintenance_plans SET
    instructions = E'1. Detener línea y aplicar LOTO eléctrico al variador ACS580.\n2. Despresurizar circuito neumático del tensor.\n3. Abrir el carro tensor y medir tensión actual con dinamómetro: target 25-30 N/m.\n4. Si fuera de rango, ajustar reapretando los tornillos del carro.\n5. Lubricar los rodamientos del rodillo motriz y del rodillo libre.\n6. Verificar alineación de la banda con regla.\n7. Inspeccionar eslabones plásticos: sin roturas, sin grietas, sin deformación.\n8. Quitar LOTO.\n9. Test en vacío 5 min y registrar corriente del motor (debe ser <1.8 A).',
    checklist = '[
        {"step":"EPI: guantes anticorte, calzado seguridad","required":true},
        {"step":"Línea detenida desde HMI","required":true},
        {"step":"LOTO eléctrico en variador ACS580","required":true},
        {"step":"LOTO neumático en circuito tensor","required":true},
        {"step":"Carro tensor abierto sin dañar guías","required":true},
        {"step":"Tensión medida con dinamómetro: 25-30 N/m (registrar)","required":true},
        {"step":"Tornillos carro tensor apretados a 12 Nm","required":true},
        {"step":"Rodamientos rodillo motriz lubricados (3 g cada uno)","required":true},
        {"step":"Rodamientos rodillo libre lubricados","required":true},
        {"step":"Alineación banda OK: desviación <2 mm en 5 m","required":true},
        {"step":"Eslabones inspeccionados: sin grietas ni deformaciones","required":true},
        {"step":"Sin restos de producto entre eslabones","required":false},
        {"step":"Carro tensor cerrado correctamente","required":true},
        {"step":"LOTO retirado","required":true},
        {"step":"Test 5 min en vacío sin vibración anómala","required":true},
        {"step":"Corriente motor en marcha: <1.8 A (registrar)","required":true}
    ]'::jsonb,
    safety_notes = E'⚠ APLASTAMIENTO por banda en movimiento. LOTO obligatorio.\n⚠ Producto cárnico: superficie deslizante. Limpiar derrames antes de pisar.\n⚠ Aire comprimido a 7 bar en el tensor: despresurizar antes de abrir.',
    tools_required = '["Dinamómetro digital 0-50 N","Llave dinamométrica 0-25 Nm","Pistola de engrase","Grasa alimentaria H1","Regla 1 m","Linterna LED","Pinza amperimétrica Fluke","Cuaderno"]'::jsonb
WHERE tenant_id=1 AND title='PM-60: Tensión banda + lubricación cinta A';

-- ─── PLAN 5: PM-30 reinforced, Conveyor B ────────────────────────────────────
UPDATE maintenance_plans SET
    instructions = E'INSPECCIÓN REFORZADA por histórico de fallos recurrentes en motor RollerDrive.\n1. LOTO eléctrico + neumático completo.\n2. Termografía del motor con FLIR (evaluar antes de parar).\n3. Si carcasa >75 °C → sustitución preventiva inmediata, no esperar.\n4. Inspección visual de cojinetes y rodamiento SKF 6203.\n5. Limpieza profunda zona contaminada con grasa de chorizo (desengrasante alimentario).\n6. Comprobar par de apriete del rodillo motriz: 12 Nm.\n7. Inspección de banda: alineación, tensión, eslabones.\n8. Si holgura detectada en rodamiento → sustituir.\n9. Test post-mantenimiento 30 min con monitorización térmica.',
    checklist = '[
        {"step":"EPI: guantes térmicos, gafas, calzado seguridad","required":true},
        {"step":"TERMOGRAFÍA antes de parar (registrar °C carcasa)","required":true},
        {"step":"LOTO eléctrico aplicado en variador","required":true},
        {"step":"LOTO neumático aplicado en tensor","required":true},
        {"step":"Si T >75 °C → DECISIÓN: sustitución preventiva inmediata","required":true},
        {"step":"Inspección visual cojinetes: sin holgura ni juego radial","required":true},
        {"step":"Rodamiento SKF 6203: sin ruido al girar manualmente","required":true},
        {"step":"Limpieza grasa producto con desengrasante alimentario","required":true},
        {"step":"Par de apriete rodillo motriz verificado: 12 Nm","required":true},
        {"step":"Banda: alineación correcta","required":true},
        {"step":"Banda: tensión 25-30 N/m","required":true},
        {"step":"Eslabones sin daño","required":true},
        {"step":"Conector M12 alimentación: sin humedad ni corrosión","required":true},
        {"step":"Cable apantallado sin daño","required":true},
        {"step":"LOTO retirado","required":true},
        {"step":"Test 30 min con monitorización térmica","required":true},
        {"step":"Termografía post-mantenimiento <70 °C (registrar)","required":true},
        {"step":"Datos enviados al historial de patrones IA","required":false}
    ]'::jsonb,
    safety_notes = E'⚠ ALTA TEMPERATURA: motor puede estar a >75 °C, usar guantes térmicos.\n⚠ APLASTAMIENTO: nunca operar la cinta sin LOTO.\n⚠ Producto graso: superficies deslizantes.\n⚠ Si tras la 3ª sustitución del año el problema persiste, ESCALAR a Interroll para evaluación de motor IP66.',
    tools_required = '["Cámara termográfica FLIR E5","Llave dinamométrica 0-20 Nm","Llave Allen 6 mm","Pistola de engrase","Desengrasante alimentario H1","Paños limpios","Multímetro Fluke","Linterna LED","Guantes térmicos clase 2","Cuaderno"]'::jsonb,
    required_parts = '[{"code":"RP-INT-RODAM-6203","qty":2,"notes":"Sustituir solo si holgura detectada"},{"code":"RP-INT-EC5000","qty":0,"notes":"Solo si T >75 °C o agarrotamiento"}]'::jsonb
WHERE tenant_id=1 AND title='PM-30 reforzado: Cinta B (chorizo) - Inspección RollerDrive';

-- ─── PLAN 6: PM-7 MULTIPOND weigher calibration ────────────────────────
UPDATE maintenance_plans SET
    instructions = E'1. Acceder al menú Mantenimiento → Calibración (clave técnico).\n2. Limpieza CIP previa si la pesadora estuvo en producción <2 h antes.\n3. Por cada cabeza (1 a 14): colocar pesa patrón 200 g certificada F1.\n4. Verificar lectura: tolerancia ±0.2 g.\n5. Si fuera de tolerancia: ejecutar tarado y reintentar.\n6. Si tras tarado sigue fuera: marcar para sustitución de célula.\n7. Imprimir certificado con valores y firma técnico.\n8. Archivar en carpeta HACCP del turno correspondiente.\n9. Reanudar producción.',
    checklist = '[
        {"step":"EPI alimentario: bata blanca, gorro, calzas, guantes nitrilo","required":true},
        {"step":"Pesa patrón 200 g F1 con certificado de calibración vigente","required":true},
        {"step":"Pesadora limpia (CIP previa si aplica)","required":true},
        {"step":"Acceso menú Mantenimiento autorizado","required":true},
        {"step":"Cabeza 1 calibrada: ±0.2 g (registrar valor)","required":true},
        {"step":"Cabeza 2 calibrada: ±0.2 g","required":true},
        {"step":"Cabeza 3 calibrada: ±0.2 g","required":true},
        {"step":"Cabeza 4 calibrada: ±0.2 g","required":true},
        {"step":"Cabeza 5 calibrada: ±0.2 g","required":true},
        {"step":"Cabeza 6 calibrada: ±0.2 g","required":true},
        {"step":"Cabeza 7 calibrada: ±0.2 g","required":true},
        {"step":"Cabeza 8 calibrada: ±0.2 g","required":true},
        {"step":"Cabeza 9 calibrada: ±0.2 g","required":true},
        {"step":"Cabeza 10 calibrada: ±0.2 g","required":true},
        {"step":"Cabeza 11 calibrada: ±0.2 g","required":true},
        {"step":"Cabeza 12 calibrada: ±0.2 g","required":true},
        {"step":"Cabeza 13 calibrada: ±0.2 g","required":true},
        {"step":"Cabeza 14 calibrada: ±0.2 g","required":true},
        {"step":"Compensación de temperatura PT100 funcional","required":true},
        {"step":"Certificado impreso con sello y firma","required":true},
        {"step":"Certificado archivado en carpeta HACCP del turno","required":true},
        {"step":"Sin cabezas marcadas para sustitución","required":false}
    ]'::jsonb,
    safety_notes = E'Higiene OBLIGATORIA: la pesadora está en zona ALIMENTARIA.\n⚠ Lavar manos antes y después de cada actuación.\n⚠ Cualquier herramienta que entre en zona alimentaria debe estar limpia y certificada food-grade.\n⚠ No usar lubricantes no-alimentarios cerca de la pesadora.',
    tools_required = '["Pesa patrón 200 g clase F1 (con certificado vigente)","Guantes nitrilo desechables","Bata, gorro y calzas alimentarias","Impresora térmica de certificados","Cuaderno HACCP","Carpeta de archivo HACCP"]'::jsonb
WHERE tenant_id=1 AND title='PM-7: Calibración pesadora MULTIPOND';

-- ─── PLAN 7: PM-1 End-of-shift CIP cleaning, weigher ────────────────────
UPDATE maintenance_plans SET
    instructions = E'PROCEDIMIENTO CIP DIARIO al final del último turno productivo.\n1. Aviso al supervisor de turno antes de iniciar.\n2. Verificar tolvas vacías, sin producto residual visible.\n3. Activar modo CIP en HMI (Bot.Mantenimiento → CIP).\n4. Confirmar cierre de tolvas en pantalla.\n5. Lanzar ciclo predefinido: 60 °C, detergente BonArea-CL12 al 2%, aclarado 30 s.\n6. Esperar fin de ciclo (aprox. 18 minutos).\n7. Verificar conductividad final del agua de aclarado: <50 µS/cm.\n8. Salir de modo CIP.\n9. Inspección visual de superficies: sin residuos.\n10. Registrar en hoja de control HACCP del turno.',
    checklist = '[
        {"step":"EPI: guantes nitrilo, gafas, bata","required":true},
        {"step":"Supervisor avisado del inicio del CIP","required":true},
        {"step":"Tolvas vacías, sin producto residual","required":true},
        {"step":"Modo CIP activado desde HMI","required":true},
        {"step":"Tolvas cerradas confirmado en pantalla","required":true},
        {"step":"Detergente BonArea-CL12 con stock suficiente","required":true},
        {"step":"Temperatura agua: 60 ± 5 °C","required":true},
        {"step":"Concentración detergente: 2% confirmada","required":true},
        {"step":"Tiempo de contacto: 8 min","required":true},
        {"step":"Aclarado con agua osmotizada: 30 s","required":true},
        {"step":"Conductividad final <50 µS/cm (registrar valor)","required":true},
        {"step":"Modo CIP cerrado correctamente","required":true},
        {"step":"Inspección visual: superficies brillantes sin residuos","required":true},
        {"step":"Registro HACCP del turno firmado","required":true},
        {"step":"Próximo turno notificado del CIP completado","required":false}
    ]'::jsonb,
    safety_notes = E'⚠ QUEMADURAS: agua a 60 °C + vapor.\n⚠ DETERGENTE ALCALINO: irritante. Si hay contacto con piel, lavar con agua abundante 15 min.\n⚠ NO mezclar detergentes diferentes.\n⚠ Resbalones por agua: mantener zona acordonada.',
    tools_required = '["EPI estándar","Bidón detergente BonArea-CL12","Conductímetro portátil","Cinta acordonado","Cuaderno HACCP"]'::jsonb
WHERE tenant_id=1 AND title='PM-1: Limpieza CIP fin de turno pesadora';

-- ─── PLAN 8: PM-30 Labeller ink change ────────────────────────────
UPDATE maintenance_plans SET
    instructions = E'1. Apagar la etiquetadora desde HMI (NO desconectar de red).\n2. Trasladar a zona ventilada el bidón antiguo de makeup.\n3. Sustituir cartucho de tinta agotado (clic + giro).\n4. Sustituir bidón de makeup (recordar: residuo peligroso, bolsa específica).\n5. Purga del cabezal: 30 segundos.\n6. Limpieza externa del cabezal con paño + makeup.\n7. Test de impresión sobre cinta de prueba: nitidez OK.\n8. Verificar lectura código EAN con escáner manual.\n9. Reactivar etiquetadora en HMI.\n10. Cambiar etiqueta del bidón con fecha y operario.',
    checklist = '[
        {"step":"EPI: gafas, guantes nitrilo, mascarilla COV","required":true},
        {"step":"Trabajar en zona con ventilación forzada","required":true},
        {"step":"Etiquetadora apagada desde HMI","required":true},
        {"step":"Cartucho tinta antiguo retirado a contenedor residuos","required":true},
        {"step":"Cartucho tinta nuevo instalado correctamente","required":true},
        {"step":"Bidón makeup antiguo a bolsa de residuos peligrosos","required":true},
        {"step":"Bidón makeup nuevo conectado y purgado","required":true},
        {"step":"Purga del cabezal: 30 s sin obstrucciones","required":true},
        {"step":"Cabezal limpio externamente","required":true},
        {"step":"Test de impresión: nitidez OK","required":true},
        {"step":"Test de impresión: legibilidad código EAN","required":true},
        {"step":"Lectura del EAN con escáner manual: 100% OK","required":true},
        {"step":"Etiquetadora reactivada","required":true},
        {"step":"Bidón makeup etiquetado: fecha + operario","required":true},
        {"step":"Residuos depositados en contenedor PELIGROSOS","required":true}
    ]'::jsonb,
    safety_notes = E'⚠ COV: tinta y makeup contienen disolventes orgánicos. Mascarilla COV obligatoria.\n⚠ INFLAMABLE: alejar de fuentes de calor.\n⚠ RESIDUO PELIGROSO: gestor autorizado, NO al alcantarillado.\n⚠ Trabajar siempre con ventilación forzada activa.',
    tools_required = '["Mascarilla con filtro COV","Guantes nitrilo gruesos","Gafas protección química","Bolsa residuos peligrosos código LER","Paños absorbentes","Escáner manual códigos EAN","Cinta papel para test","Etiquetas de identificación"]'::jsonb,
    required_parts = '[{"code":"RP-MAR-TINTA-CIJ","qty":1},{"code":"RP-MAR-MAKEUP","qty":1}]'::jsonb
WHERE tenant_id=1 AND title='PM-30: Cambio tinta + makeup etiquetadora';

-- ─── PLAN 9: PM-1 CRYOVAC sealer HACCP check ──────────────────
UPDATE maintenance_plans SET
    instructions = E'PUNTO CRÍTICO DE CONTROL HACCP — Verificación diaria obligatoria.\n1. Comprobar temperatura del túnel desde HMI: rango aceptable 88-92 °C.\n2. Verificar caudal de vapor: manómetro 4-6 bar.\n3. Inspección visual exterior: sin fugas, sin condensación anómala.\n4. Lectura sonda PT100 vs termómetro patrón.\n5. Anotar lectura en cuaderno HACCP del turno.\n6. Si T < 85 °C durante >2 minutos: BLOQUEAR LOTE y avisar a Calidad.\n7. Cuando todo OK, firmar y archivar.',
    checklist = '[
        {"step":"EPI: gafas, guantes térmicos clase 3 si hay intervención","required":true},
        {"step":"HMI accesible y autenticado","required":true},
        {"step":"Temperatura túnel HMI: 88-92 °C (registrar)","required":true},
        {"step":"Caudal de vapor: 4-6 bar (registrar)","required":true},
        {"step":"Sonda PT100 lectura: registrar valor","required":true},
        {"step":"Termómetro patrón lectura: registrar valor","required":true},
        {"step":"Diferencia PT100 vs patrón: <2 °C (registrar)","required":true},
        {"step":"Inspección visual: sin fugas de vapor","required":true},
        {"step":"Inspección visual: sin condensación anómala","required":true},
        {"step":"Trampillas exteriores cerradas correctamente","required":true},
        {"step":"Sin alarmas activas en HMI","required":true},
        {"step":"Si T<85 °C >2 min: protocolo BLOQUEO LOTE activado","required":true},
        {"step":"Cuaderno HACCP del turno firmado y fechado","required":true},
        {"step":"Cambio anotado en libro de PCC","required":true}
    ]'::jsonb,
    safety_notes = E'⚠ HACCP: este es un PUNTO CRÍTICO DE CONTROL. Cualquier desviación >2 min implica bloqueo de lote.\n⚠ QUEMADURAS POR VAPOR: si hay que abrir trampilla, EPI clase 3.\n⚠ Comunicación obligatoria a Calidad ante cualquier desviación.',
    tools_required = '["Termómetro patrón certificado","Cuaderno HACCP","Libro de PCC","EPI clase 3 (en caso de intervención)","Linterna LED"]'::jsonb
WHERE tenant_id=1 AND title='PM-1: Verificación HACCP selladora CRYOVAC';

-- ─── PLAN 10: PM-180 Steam nozzle cleaning/replacement ───────────────
UPDATE maintenance_plans SET
    instructions = E'INTERVENCIÓN MAYOR — Solo en parada programada.\n1. Aviso a Producción 24 h antes.\n2. LOTO eléctrico + bloqueo válvula vapor.\n3. Esperar enfriamiento mínimo 30 min (T<40 °C).\n4. Desmontar tapa lateral (8 tornillos M8).\n5. Extraer 12 boquillas con llave T-14.\n6. Inspección visual: descartar boquillas con deformación o fisura.\n7. Limpieza ultrasónica 20 min en baño con desincrustante.\n8. Si ≥4 boquillas dañadas → SUSTITUCIÓN COMPLETA del juego.\n9. Montar boquillas con sellador anaeróbico Loctite 577.\n10. Par de apriete: 8 Nm cada boquilla.\n11. Cerrar tapa con junta nueva + 8 Nm tornillos.\n12. Test de hermeticidad a 6 bar durante 5 min: caída <0.1 bar.\n13. Quitar LOTO.\n14. Calentamiento progresivo desde HMI hasta 90 °C.\n15. Test de distribución: vapor uniforme en las 12 zonas.',
    checklist = '[
        {"step":"Aviso a Producción confirmado 24 h antes","required":true},
        {"step":"EPI clase 3 completo: traje, guantes, pantalla facial","required":true},
        {"step":"Permiso de trabajo en caliente firmado","required":true},
        {"step":"LOTO eléctrico colocado","required":true},
        {"step":"Válvula vapor bloqueada con candado","required":true},
        {"step":"Enfriamiento >30 min (T <40 °C verificado)","required":true},
        {"step":"Tapa lateral desmontada sin dañar junta","required":true},
        {"step":"12 boquillas extraídas y numeradas","required":true},
        {"step":"Inspección visual: registrar nº boquillas dañadas","required":true},
        {"step":"DECISIÓN: limpieza vs sustitución completa","required":true},
        {"step":"Limpieza ultrasónica 20 min completada","required":true},
        {"step":"Sellador anaeróbico Loctite 577 aplicado","required":true},
        {"step":"Par de apriete boquillas: 8 Nm cada una","required":true},
        {"step":"Junta tapa nueva instalada","required":true},
        {"step":"Tornillos tapa apretados a 8 Nm","required":true},
        {"step":"Test hermeticidad 6 bar 5 min: caída <0.1 bar","required":true},
        {"step":"LOTO retirado","required":true},
        {"step":"Calentamiento progresivo hasta 90 °C","required":true},
        {"step":"Distribución vapor uniforme verificada","required":true},
        {"step":"Test producción 30 min sin alarmas","required":true},
        {"step":"Calidad firma reanudación de PCC","required":true}
    ]'::jsonb,
    safety_notes = E'⚠ ALTA QUEMADURA: vapor a 92 °C, presión 6 bar.\n⚠ ESPACIO CONFINADO: trabajo con compañero designado.\n⚠ TRABAJO EN CALIENTE: permiso específico, extintor cercano.\n⚠ NO operar sin enfriamiento previo. T >50 °C puede deformar piel en segundos.\n⚠ Calidad debe firmar reanudación tras intervención en PCC.',
    tools_required = '["Llave T-14","Llave dinamométrica 0-15 Nm","Llave Allen 6 mm","Baño ultrasónico industrial","Desincrustante",  "Sellador Loctite 577","Manómetro patrón 0-10 bar","Termómetro infrarrojo","EPI clase 3 completo","Extintor CO2","Linterna LED","Permiso trabajo caliente","Numerador para boquillas"]'::jsonb,
    required_parts = '[{"code":"RP-CRY-NZL-12","qty":1,"notes":"Solo si ≥4 boquillas dañadas"}]'::jsonb
WHERE tenant_id=1 AND title='PM-180: Limpieza/sustitución boquillas vapor';

-- ─── PLAN 11: PM-30 PLC backup ─────────────────────────────────────────
UPDATE maintenance_plans SET
    instructions = E'1. Notificar a Producción antes de conectar al PLC.\n2. Conectar portátil con TIA Portal V18 vía Profinet (cable industrial).\n3. Establecer conexión online sin interrumpir programa.\n4. Upload completo del programa a backup remoto NAS.\n5. Comparar checksum con versión documentada.\n6. Verificar voltaje de la pila CR2032 (debe ser >2.8 V).\n7. Si <2.8 V, sustituir durante parada programada (NO en marcha).\n8. Anotar versión + fecha en logbook.\n9. Cerrar TIA Portal.',
    checklist = '[
        {"step":"EPI: pulsera ESD","required":true},
        {"step":"Producción notificada de la conexión","required":true},
        {"step":"Portátil con TIA Portal V18 + licencia activa","required":true},
        {"step":"Cable industrial Profinet en buen estado","required":true},
        {"step":"Conexión online establecida sin warnings","required":true},
        {"step":"Backup completo realizado (registrar tamaño .ap18)","required":true},
        {"step":"Backup guardado en NAS \\\\backup\\plc\\","required":true},
        {"step":"Checksum verificado vs versión documentada","required":true},
        {"step":"Voltaje pila CR2032: >2.8 V (registrar valor)","required":true},
        {"step":"DECISIÓN sustituir pila si <2.8 V","required":false},
        {"step":"Sustitución pila solo en parada programada","required":false},
        {"step":"Versión + fecha anotada en logbook","required":true},
        {"step":"TIA Portal cerrado correctamente","required":true},
        {"step":"Cable Profinet retirado y guardado","required":true}
    ]'::jsonb,
    safety_notes = E'⚠ NUNCA descargar programa al PLC durante producción salvo orden explícita.\n⚠ Pila: NO retirar con PLC alimentado, podría perder retentivos.\n⚠ ESD sensible: usar pulsera antiestática.',
    tools_required = '["Portátil con TIA Portal V18","Licencia STEP 7 Pro","Cable industrial Profinet","Multímetro Fluke","Pulsera ESD","Acceso NAS \\\\backup\\plc\\","Logbook PLC"]'::jsonb,
    required_parts = '[{"code":"RP-SIE-CR2032","qty":1,"notes":"Solo si voltaje <2.8 V"}]'::jsonb
WHERE tenant_id=1 AND title='PM-30: Backup PLC + verificación pila';

-- ─── PLAN 12: PM-180 Atlas Copco compressor oil change ────────────────
UPDATE maintenance_plans SET
    instructions = E'INTERVENCIÓN MAYOR — Service Plan A (cada 4000 h).\n1. Aviso a Producción 48 h antes (compresor afecta a varios consumidores).\n2. Bajar carga gradualmente desde HMI hasta parada.\n3. LOTO eléctrico en cuadro principal.\n4. Despresurizar calderín completamente (verificar 0 bar).\n5. Vaciar aceite usado a recipiente homologado para residuo peligroso.\n6. Sustituir filtro de aceite (1622-3651-00).\n7. Sustituir filtro separador (1622-3148-00).\n8. Llenar 7.5 L de Roto-Xtend Duty Fluid 4000h.\n9. Inspeccionar mangueras, juntas, refrigerador.\n10. Quitar LOTO.\n11. Arrancar compresor.\n12. Vigilar 30 min: presión, temperatura, fugas.\n13. Reset contador horas Service Plan A en HMI.\n14. Aceite usado a gestor autorizado (con albarán LER 130208).',
    checklist = '[
        {"step":"EPI: gafas, guantes nitrilo, calzado seguridad","required":true},
        {"step":"Producción notificada 48 h antes","required":true},
        {"step":"Permiso trabajo firmado","required":true},
        {"step":"Compresor parado desde HMI (no E-Stop)","required":true},
        {"step":"LOTO eléctrico en cuadro principal","required":true},
        {"step":"Calderín despresurizado: manómetro 0 bar","required":true},
        {"step":"Aceite usado vaciado a recipiente homologado","required":true},
        {"step":"Filtro aceite antiguo retirado","required":true},
        {"step":"Filtro aceite nuevo (1622-3651-00) instalado","required":true},
        {"step":"Filtro separador antiguo retirado","required":true},
        {"step":"Filtro separador nuevo (1622-3148-00) instalado","required":true},
        {"step":"7.5 L Roto-Xtend Duty Fluid llenados","required":true},
        {"step":"Nivel correcto en mirilla","required":true},
        {"step":"Inspección mangueras: sin grietas ni abrasión","required":true},
        {"step":"Inspección juntas: sin manchas de aceite","required":true},
        {"step":"Refrigerador limpio (sin polvo ni acumulación)","required":true},
        {"step":"LOTO retirado","required":true},
        {"step":"Arranque OK","required":true},
        {"step":"Monitorización 30 min: presión 7-10 bar, T <85 °C","required":true},
        {"step":"Sin fugas durante test","required":true},
        {"step":"Reset contador Service Plan A en HMI","required":true},
        {"step":"Aceite usado entregado a gestor con albarán LER 130208","required":true},
        {"step":"Logbook compresor firmado","required":true}
    ]'::jsonb,
    safety_notes = E'⚠ PRESIÓN RESIDUAL: despresurizar antes de cualquier desmontaje.\n⚠ ACEITE USADO = RESIDUO PELIGROSO LER 130208. Gestor autorizado obligatorio. NO al alcantarillado, NO mezclar con otros residuos.\n⚠ El aceite caliente puede quemar: esperar enfriamiento si recién operado.\n⚠ ESPACIO CONFINADO: ventilación forzada en sala de compresores.',
    tools_required = '["Bandeja recolección aceite (10 L)","Recipiente homologado residuo aceite (LER 130208)","Llave de filtros tipo cazoleta","Llave dinamométrica","Embudo limpio","Bidón nuevo Roto-Xtend Duty Fluid 20 L","Paños absorbentes","Mascarilla COV","Albaranes residuos peligrosos","Linterna LED","Cuaderno"]'::jsonb,
    required_parts = '[{"code":"RP-ATL-OIL-ROTO","qty":0.4,"notes":"7.5 L de un bidón de 20 L"},{"code":"RP-ATL-FILT-OIL","qty":1},{"code":"RP-ATL-FILT-SEP","qty":1}]'::jsonb
WHERE tenant_id=1 AND title='PM-180: Cambio aceite + filtros compresor Atlas Copco';

-- ─── PLAN 13: PM-30 Compressor air filter inspection ────────────────────
UPDATE maintenance_plans SET
    instructions = E'1. Apagar compresor desde HMI.\n2. Esperar 5 min para descarga total del calderín.\n3. Aflojar las 4 mariposas que sujetan la tapa del filtro.\n4. Extraer filtro de aire.\n5. Inspección visual: nivel de suciedad, daños, deformaciones.\n6. Si suciedad ligera: soplar con aire seco a máx. 6 bar (NO MÁS).\n7. Si suciedad alta o daño: sustituir por filtro nuevo (1613-7406-00).\n8. Limpiar interior del compartimento del filtro.\n9. Montar filtro con junta nueva si procede.\n10. Cerrar tapa apretando mariposas a mano.\n11. Reactivar compresor desde HMI.\n12. Verificar arranque sin alarmas.',
    checklist = '[
        {"step":"EPI: gafas, guantes, mascarilla polvo P2","required":true},
        {"step":"Compresor apagado desde HMI","required":true},
        {"step":"Esperado 5 min descarga calderín","required":true},
        {"step":"Mariposas tapa filtro aflojadas","required":true},
        {"step":"Filtro extraído sin dañar el compartimento","required":true},
        {"step":"Inspección visual: registrar nivel suciedad (1-5)","required":true},
        {"step":"Inspección: sin daños, deformaciones, agujeros","required":true},
        {"step":"DECISIÓN: limpieza vs sustitución","required":true},
        {"step":"Limpieza con aire seco MÁX 6 bar (no más)","required":false},
        {"step":"Filtro nuevo instalado si daño detectado","required":false},
        {"step":"Compartimento interior limpio","required":true},
        {"step":"Junta nueva si procede","required":false},
        {"step":"Filtro montado correctamente","required":true},
        {"step":"Mariposas apretadas a mano (sin herramienta)","required":true},
        {"step":"Compresor reactivado","required":true},
        {"step":"Arranque OK sin alarmas","required":true},
        {"step":"Sin caída de presión anómala","required":true}
    ]'::jsonb,
    safety_notes = E'⚠ AIRE COMPRIMIDO: NO usar >6 bar en el filtro, rompe el material.\n⚠ POLVO INHALABLE: mascarilla P2 obligatoria en zona de filtro sucio.\n⚠ Tapa pesada: agarrar con ambas manos al desmontar.',
    tools_required = '["Pistola aire comprimido regulada a 6 bar","Mascarilla polvo P2","Trapo limpio","Aspirador industrial","Linterna LED","Bolsa residuos no peligrosos"]'::jsonb,
    required_parts = '[{"code":"RP-ATL-FILT-AIR","qty":1,"notes":"Solo si daño o suciedad alta"}]'::jsonb
WHERE tenant_id=1 AND title='PM-30: Inspección filtro aire compresor';

COMMIT;

-- Verification
SELECT id, title,
       jsonb_array_length(checklist) AS items_chk,
       length(instructions) AS chars_instr,
       jsonb_array_length(tools_required) AS tools,
       jsonb_array_length(required_parts) AS parts,
       length(COALESCE(safety_notes,'')) AS chars_safety
  FROM maintenance_plans WHERE tenant_id=1 ORDER BY id;
