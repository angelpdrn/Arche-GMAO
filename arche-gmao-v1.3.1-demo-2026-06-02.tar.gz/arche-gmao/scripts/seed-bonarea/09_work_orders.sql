-- ============================================================
-- BonArea Demo - Block 09: WO history
-- ============================================================
-- ~80 WOs over the last 9 months with:
--  • A mix of corrective and preventive work
--  • Assorted states
--  • Repeated root causes on conveyor B → mechanical pattern
--  • Recurring electrical causes on Cognex vision → electrical pattern
--  • Consumed spare parts + stock_movements (in the next block)
-- ============================================================

BEGIN;

DO $$
DECLARE
    u_admin BIGINT;
    u_caristiven BIGINT;
    u_angel BIGINT;
    u_ysabel BIGINT;

    n_robot BIGINT;
    n_vision BIGINT;
    n_cinta_a BIGINT;
    n_cinta_b BIGINT;
    n_cinta_c BIGINT;
    n_pesadora BIGINT;
    n_etiqueta BIGINT;
    n_selladora BIGINT;
    n_plc BIGINT;
    n_compresor BIGINT;

    rec RECORD;
    v_wo_id BIGINT;
    v_wo_number TEXT;
    v_started TIMESTAMPTZ;
    v_completed TIMESTAMPTZ;
    v_initial_status TEXT;
    v_dup_offset INTEGER;
BEGIN
    SELECT id INTO u_admin FROM users WHERE email='admin@arche.local';
    SELECT id INTO u_caristiven FROM users WHERE email='caristiven.padrino@bonarea.local';
    SELECT id INTO u_angel FROM users WHERE email='angel.padrino@bonarea.local';
    SELECT id INTO u_ysabel FROM users WHERE email='ysabel.salazar@bonarea.local';

    SELECT id INTO n_robot     FROM bonarea_demo_ids WHERE key='robot';
    SELECT id INTO n_vision    FROM bonarea_demo_ids WHERE key='vision';
    SELECT id INTO n_cinta_a   FROM bonarea_demo_ids WHERE key='cinta_a';
    SELECT id INTO n_cinta_b   FROM bonarea_demo_ids WHERE key='cinta_b';
    SELECT id INTO n_cinta_c   FROM bonarea_demo_ids WHERE key='cinta_c';
    SELECT id INTO n_pesadora  FROM bonarea_demo_ids WHERE key='pesadora';
    SELECT id INTO n_etiqueta  FROM bonarea_demo_ids WHERE key='etiqueta';
    SELECT id INTO n_selladora FROM bonarea_demo_ids WHERE key='selladora';
    SELECT id INTO n_plc       FROM bonarea_demo_ids WHERE key='plc';
    SELECT id INTO n_compresor FROM bonarea_demo_ids WHERE key='compresor';

    DROP TABLE IF EXISTS demo_wo_defs;
    CREATE TEMP TABLE demo_wo_defs (
        seq INT PRIMARY KEY,
        days_ago INT,
        node_id BIGINT,
        title TEXT,
        description TEXT,
        wo_type TEXT,
        priority TEXT,
        status TEXT,
        assigned_to BIGINT,
        created_by BIGINT,
        actual_minutes INT,
        root_cause TEXT,
        root_cause_code TEXT,
        solution TEXT
    ) ON COMMIT DROP;

    -- ─── 8 fallos recurrentes CINTA B (mechanical) ─────────────────────────
    INSERT INTO demo_wo_defs VALUES
    (1, 245, n_cinta_b, 'Cinta B parada - motor sobrecalentado',
     'Termografía marca 82 °C en carcasa motor RollerDrive. Cinta detenida por seguridad.',
     'corrective','high','closed', u_angel, u_caristiven, 95,
     'Rodamiento interno SKF 6203 con holgura por contaminación con grasa de producto cárnico. Sustituido. Termografía post-reparación: 58 °C OK.',
     'mechanical', 'Sustitución motor RollerDrive completo + limpieza zona contaminada con desengrasante alimentario.'),
    (2, 215, n_cinta_b, 'Ruido metálico en motor cinta B',
     'Operario reporta ruido metálico durante el arranque de la cinta B.',
     'corrective','high','closed', u_angel, u_ysabel, 75,
     'Holgura en rodamiento del motor. Confirmado por inspección.',
     'mechanical', 'Sustitución motor RollerDrive Interroll EC5000.'),
    (3, 188, n_cinta_b, 'Cinta B detenida - error E03 variador',
     'Variador ACS580 muestra E03 (sobrecorriente) tras 2 h de producción.',
     'corrective','high','closed', u_angel, u_angel, 110,
     'Motor con sobreesfuerzo por rodamiento desgastado. Confirmado SKF 6203 con corrosión.',
     'mechanical', 'Sustitución motor RollerDrive + limpieza de carro tensor.'),
    (4, 162, n_cinta_b, 'Vibración anómala motor cinta B',
     'Vibración perceptible al tacto en el rodillo motriz de la cinta B.',
     'corrective','medium','closed', u_angel, u_ysabel, 65,
     'Cojinete del motor con desgaste prematuro. Recurrente por contaminación con grasa producto cárnico.',
     'mechanical', 'Sustitución motor + recomendación de aumentar frecuencia inspección.'),
    (5, 135, n_cinta_b, 'Sobrecalentamiento motor cinta B (recurrente)',
     'Cuarto sobrecalentamiento del motor en este año. Termografía 79 °C.',
     'corrective','critical','closed', u_angel, u_caristiven, 130,
     'Patrón claro de fallo recurrente: contaminación con grasa de producto. El motor estándar IP55 es insuficiente.',
     'mechanical', 'Sustitución motor + apertura caso al fabricante para recomendación motor IP66.'),
    (6, 102, n_cinta_b, 'Cinta B parada - rodamiento agarrotado',
     'Cinta B no arranca, motor calienta sin girar.',
     'corrective','critical','closed', u_angel, u_angel, 85,
     'Rodamiento interno completamente agarrotado. Motor inservible.',
     'mechanical', 'Sustitución completa motor RollerDrive.'),
    (7, 75, n_cinta_b, 'Cinta B - ruido y vibración',
     'Misma sintomatología que casos previos.',
     'corrective','high','closed', u_angel, u_caristiven, 70,
     'Rodamiento desgastado, contaminación grasa producto.',
     'mechanical', 'Sustitución motor.'),
    (8, 48, n_cinta_b, 'Sobrecalentamiento motor cinta B',
     'Termografía 81 °C. Confirmado mismo patrón.',
     'corrective','high','closed', u_angel, u_angel, 90,
     'Patrón recurrente confirmado: grasa producto cárnico contamina rodamiento estándar.',
     'mechanical', 'Sustitución motor RollerDrive + escalada técnica al fabricante para opción IP66.'),

    -- ─── 6 OTs en VISION COGNEX (electrical) ─────────────────────────────
    (9, 230, n_vision, 'Cámara Cognex se reinicia cíclicamente',
     'Cada 5-10 minutos la cámara Cognex se reinicia y pierde producción durante 30 s.',
     'corrective','high','closed', u_angel, u_caristiven, 100,
     'Cable Ethernet con conector RJ45 dañado: oxidación por humedad ambiental.',
     'electrical','Sustitución cable comunicación por uno apantallado IP67.'),
    (10, 195, n_vision, 'Imagen oscura en cámara Cognex',
     'Imagen muy oscura, falsos negativos en detección.',
     'corrective','medium','closed', u_angel, u_ysabel, 45,
     'Iluminador LED defectuoso, alimentación 24 V baja a 18 V por contacto sucio.',
     'electrical','Limpieza contactos + ajuste fuente alimentación.'),
    (11, 158, n_vision, 'Cámara fuera de línea Profinet',
     'PLC reporta dispositivo fuera de bus.',
     'corrective','high','closed', u_angel, u_angel, 80,
     'Conector M12 Profinet con humedad interna.',
     'electrical','Sustitución conector + sellado con grasa dieléctrica.'),
    (12, 122, n_vision, 'LED iluminador no enciende',
     'Anillo LED apagado, imagen inutilizable.',
     'corrective','high','closed', u_angel, u_caristiven, 55,
     'Driver LED quemado por sobretensión transitoria.',
     'electrical','Sustitución anillo iluminador completo + adición varistor en línea 24 V.'),
    (13, 88, n_vision, 'Falsos positivos detección Cognex',
     'Detecta producto donde no lo hay tras cambio de turno.',
     'corrective','medium','closed', u_angel, u_ysabel, 30,
     'Iluminación ambiente diferente del turno noche desbalancea calibración color.',
     'parameters','Recalibración con tarjeta Macbeth y guardar perfil "noche".'),
    (14, 35, n_vision, 'Cámara Cognex se reinicia (recurrente)',
     'Mismo patrón que en marzo.',
     'corrective','high','closed', u_angel, u_angel, 70,
     'Fuente 24 V con caída de tensión en transitorios. Tercer caso similar este año.',
     'electrical','Sustitución fuente alimentación por modelo industrial PULS CP10.241.'),

    -- ─── 4 OTs ROBOT ABB ────────────────────────────────────────────────
    (15, 220, n_robot, 'Robot pierde vacío en pinza',
     'Producto se cae a mitad del trayecto pick&place.',
     'corrective','high','closed', u_angel, u_caristiven, 85,
     'Membrana del eyector Schmalz desgastada.',
     'pneumatic','Sustitución membrana + revisión manguera Ø8.'),
    (16, 178, n_robot, 'Error E0021 robot ABB',
     'Excessive position error, robot detenido.',
     'corrective','critical','closed', u_angel, u_angel, 145,
     'Correa GT2 floja por desgaste. Deflexión 8 mm (fuera de tolerancia 3-5 mm).',
     'mechanical','Sustitución correa GT2 + recalibración TCP.'),
    (17, 95, n_robot, 'Pick fallido recurrente',
     'Robot pierde productos en posición de pick con frecuencia.',
     'corrective','medium','closed', u_angel, u_ysabel, 50,
     'Lente Cognex con grasa, no es problema del robot.',
     'operation','Limpieza lente Cognex y mejora del SOP de limpieza.'),
    (18, 12, n_robot, 'Robot no responde al HMI',
     'Tras parada turno, no responde a comandos del PLC.',
     'corrective','high','in_progress', u_angel, u_caristiven, 0,
     NULL, NULL, NULL),

    -- ─── 3 OTs PESADORA ────────────────────────────────────────────────
    (19, 175, n_pesadora, 'Cabeza 7 fuera de tolerancia',
     'Cabeza 7 da +0.8 g sistemáticamente.',
     'corrective','medium','closed', u_angel, u_caristiven, 60,
     'Célula KMD-208 con drift por golpe accidental durante limpieza CIP.',
     'mechanical','Sustitución célula + actualización SOP limpieza.'),
    (20, 110, n_pesadora, 'Sensor tolva atascado',
     'Cabeza 11 no descarga.',
     'corrective','medium','closed', u_ysabel, u_ysabel, 25,
     'Fotocélula SICK WL12G obstruida por residuo de chorizo.',
     'environment','Limpieza fotocélula + revisión SOP CIP.'),
    (21, 58, n_pesadora, 'Pantalla HMI pesadora congelada',
     'HMI no responde al tacto, sin alarmas.',
     'corrective','low','closed', u_angel, u_angel, 35,
     'Driver pantalla táctil con bug conocido tras 30+ días sin reinicio.',
     'electronic','Reinicio HMI + actualización firmware.'),

    -- ─── 3 OTs ETIQUETADORA ────────────────────────────────────────────
    (22, 165, n_etiqueta, 'Impresión borrosa etiquetadora',
     'Etiquetas con texto borroso al final del cartucho.',
     'corrective','medium','closed', u_angel, u_ysabel, 30,
     'Cartucho de tinta agotado + boquilla CIJ obstruida.',
     'wear','Sustitución cartucho + ciclo de purga.'),
    (23, 70, n_etiqueta, 'Etiquetadora no aplica etiqueta',
     'El robot aplicador no avanza.',
     'corrective','high','closed', u_angel, u_caristiven, 75,
     'Cilindro neumático del aplicador con fuga interna.',
     'pneumatic','Sustitución cilindro + revisión electroválvula.'),
    (24, 25, n_etiqueta, 'Sin aire comprimido en etiquetadora',
     'No hay presión.',
     'corrective','medium','closed', u_angel, u_ysabel, 20,
     'Manguera neumática perforada por roce.',
     'pneumatic','Sustitución tramo manguera + reorganización trayecto.'),

    -- ─── 4 OTs SELLADORA CRYOVAC ───────────────────────────────────────
    (25, 200, n_selladora, 'Temperatura selladora baja - PCC en peligro',
     'Temperatura cae a 84 °C durante 3 minutos. Lote en cuarentena.',
     'corrective','critical','closed', u_angel, u_caristiven, 115,
     'Boquillas de vapor parcialmente obstruidas por cal.',
     'environment','Limpieza ultrasónica boquillas + ajuste PID.'),
    (26, 145, n_selladora, 'Sonda PT100 fuera de rango',
     'Lectura sonda 25 °C (real 90 °C según patrón).',
     'corrective','critical','closed', u_angel, u_angel, 60,
     'Sonda PT100 averiada por choque térmico.',
     'electronic','Sustitución sonda PT100 sumergible Endress+Hauser TR47.'),
    (27, 92, n_selladora, 'Vapor a presión baja',
     'Manómetro en 3.2 bar (mínimo 4 bar).',
     'corrective','high','closed', u_angel, u_caristiven, 50,
     'Filtro de la línea de vapor saturado.',
     'environment','Limpieza filtro + plan de inspección bimensual.'),
    (28, 6, n_selladora, 'Boquillas vapor con distribución irregular',
     'Inspección visual: vapor sale más por boquillas 1-3 que del resto.',
     'corrective','medium','assigned', u_angel, u_caristiven, 0, NULL, NULL, NULL),

    -- ─── 3 OTs PLC ─────────────────────────────────────────────────────
    (29, 182, n_plc, 'PLC alarma pila baja',
     'CPU con LED BATF parpadeante.',
     'corrective','low','closed', u_angel, u_caristiven, 15,
     'Pila CR2032 al final de su vida útil.',
     'wear','Sustitución pila durante parada programada.'),
    (30, 80, n_plc, 'Comunicación intermitente PROFINET',
     'Pérdida puntual de comunicación con visión Cognex.',
     'corrective','high','closed', u_angel, u_angel, 90,
     'Cable PROFINET con conector dañado en switch IE-Switch.',
     'electrical','Sustitución cable industrial + crimpado nuevo.'),
    (31, 22, n_plc, 'Tarjeta DI16 con entradas erráticas',
     'Entradas DI4-DI8 con lecturas inestables.',
     'corrective','high','completed', u_angel, u_caristiven, 80,
     'Tarjeta 6ES7521 dañada por sobretensión en paro turno.',
     'electrical','Sustitución tarjeta DI16. Verificación protecciones.'),

    -- ─── 5 OTs COMPRESOR ───────────────────────────────────────────────
    (32, 240, n_compresor, 'Compresor presión alta - parada',
     'Compresor se detiene por alta presión.',
     'corrective','high','closed', u_angel, u_caristiven, 65,
     'Filtro separador saturado.',
     'wear','Sustitución filtro separador.'),
    (33, 175, n_compresor, 'Pérdida de aceite compresor',
     'Mancha de aceite bajo el compresor.',
     'corrective','high','closed', u_angel, u_angel, 95,
     'Junta de retorno de aceite con corte por envejecimiento.',
     'mechanical','Sustitución junta + cambio aceite preventivo.'),
    (34, 105, n_compresor, 'Temperatura alta compresor',
     'Tem alta repetitivo.',
     'corrective','high','closed', u_angel, u_caristiven, 75,
     'Refrigerador con polvo + ventilador con aspas dañadas.',
     'environment','Limpieza completa refrigerador + sustitución ventilador.'),
    (35, 40, n_compresor, 'Service Plan A vencido',
     'Sistema indica Plan A vencido (cambio aceite).',
     'preventive','medium','closed', u_angel, u_admin, 165,
     NULL, NULL,'Cambio aceite + filtros aceite/separador. Reset contador.'),
    (36, 4, n_compresor, 'Caudal de aire bajo',
     'Producción reporta caudal de aire insuficiente.',
     'corrective','medium','pending', u_angel, u_caristiven, 0, NULL, NULL, NULL),

    -- ─── 3 OTs CINTAS A/C ──────────────────────────────────────────────
    (37, 130, n_cinta_a, 'Banda modular con eslabón roto',
     'Eslabón Intralox roto detectado en inspección.',
     'corrective','medium','closed', u_angel, u_caristiven, 30,
     'Desgaste normal de la banda.','wear','Sustitución eslabón individual.'),
    (38, 65, n_cinta_c, 'Cinta C deslizamiento',
     'Banda desliza, no avanza producto.',
     'corrective','medium','closed', u_angel, u_ysabel, 25,
     'Tensión de la banda relajada por estiramiento.','wear','Reapriete del carro tensor.'),
    (39, 18, n_cinta_a, 'Cinta A no arranca',
     'No responde al comando del PLC.',
     'corrective','high','verified', u_angel, u_caristiven, 55,
     'Variador ACS580 con error de comunicación Modbus.','electrical',
     'Reinicio variador + revisión cableado RS485.'),

    -- ─── PREVENTIVAS COMPLETADAS ──────────────────────────────────────
    (40, 260, n_robot, 'PM-90: Lubricación cojinetes robot ABB',
     'Mantenimiento preventivo programado.','preventive','high','closed', u_angel, u_admin, 90, NULL, NULL,
     'Realizado según procedimiento. Estado cojinetes: bueno.'),
    (41, 170, n_robot, 'PM-90: Lubricación cojinetes robot ABB',
     'Mantenimiento preventivo programado.','preventive','high','closed', u_angel, u_admin, 95, NULL, NULL,
     'Realizado según procedimiento. Estado cojinetes: bueno.'),
    (42, 80, n_robot, 'PM-90: Lubricación cojinetes robot ABB',
     'Mantenimiento preventivo programado.','preventive','high','closed', u_angel, u_admin, 88, NULL, NULL,
     'Realizado según procedimiento. Cojinete 3 con leve ruido en frío, monitorizar.'),
    (43, 250, n_robot, 'PM-30: Inspección correa GT2 robot ABB','Inspección mensual.','preventive','medium','closed', u_angel, u_admin, 28, NULL, NULL, 'Tensión OK 4.2 mm.'),
    (44, 220, n_robot, 'PM-30: Inspección correa GT2 robot ABB','Inspección mensual.','preventive','medium','closed', u_angel, u_admin, 30, NULL, NULL, 'OK.'),
    (45, 190, n_robot, 'PM-30: Inspección correa GT2 robot ABB','Inspección mensual.','preventive','medium','closed', u_angel, u_admin, 32, NULL, NULL, 'OK.'),
    (46, 160, n_robot, 'PM-30: Inspección correa GT2 robot ABB','Inspección mensual.','preventive','medium','closed', u_angel, u_admin, 35, NULL, NULL, 'Tensión 6 mm — fuera de tolerancia.'),
    (47, 130, n_robot, 'PM-30: Inspección correa GT2 robot ABB','Inspección mensual.','preventive','medium','closed', u_angel, u_admin, 28, NULL, NULL, 'OK tras sustitución.'),
    (48, 100, n_robot, 'PM-30: Inspección correa GT2 robot ABB','Inspección mensual.','preventive','medium','closed', u_angel, u_admin, 28, NULL, NULL, 'OK.'),
    (49, 70, n_robot, 'PM-30: Inspección correa GT2 robot ABB','Inspección mensual.','preventive','medium','closed', u_angel, u_admin, 28, NULL, NULL, 'OK.'),
    (50, 40, n_robot, 'PM-30: Inspección correa GT2 robot ABB','Inspección mensual.','preventive','medium','closed', u_angel, u_admin, 28, NULL, NULL, 'OK.'),
    (51, 120, n_vision, 'PM-7: Limpieza óptica Cognex','Limpieza semanal.','preventive','medium','closed', u_angel, u_admin, 18, NULL, NULL, 'OK.'),
    (52, 100, n_vision, 'PM-7: Limpieza óptica Cognex','Limpieza semanal.','preventive','medium','closed', u_angel, u_admin, 18, NULL, NULL, 'OK.'),
    (53, 80, n_vision, 'PM-7: Limpieza óptica Cognex','Limpieza semanal.','preventive','medium','closed', u_angel, u_admin, 20, NULL, NULL, 'Lente con polvo significativo.'),
    (54, 50, n_vision, 'PM-7: Limpieza óptica Cognex','Limpieza semanal.','preventive','medium','closed', u_angel, u_admin, 17, NULL, NULL, 'OK.'),
    (55, 20, n_vision, 'PM-7: Limpieza óptica Cognex','Limpieza semanal.','preventive','medium','closed', u_angel, u_admin, 18, NULL, NULL, 'OK.'),
    (56, 200, n_cinta_a, 'PM-60: Tensión banda + lubricación cinta A','Mantenimiento bimestral.','preventive','medium','closed', u_angel, u_admin, 65, NULL, NULL, 'Tensión 27 N/m OK.'),
    (57, 140, n_cinta_a, 'PM-60: Tensión banda + lubricación cinta A','Mantenimiento bimestral.','preventive','medium','closed', u_angel, u_admin, 60, NULL, NULL, 'OK.'),
    (58, 80, n_cinta_a, 'PM-60: Tensión banda + lubricación cinta A','Mantenimiento bimestral.','preventive','medium','closed', u_angel, u_admin, 58, NULL, NULL, 'OK.'),
    (59, 250, n_cinta_b, 'PM-30 reforzado: Cinta B - Inspección RollerDrive','Inspección reforzada.','preventive','high','closed', u_angel, u_admin, 65, NULL, NULL, 'Termografía 62 °C OK.'),
    (60, 220, n_cinta_b, 'PM-30 reforzado: Cinta B - Inspección RollerDrive','Inspección reforzada.','preventive','high','closed', u_angel, u_admin, 65, NULL, NULL, 'Termografía 78 °C — marginal.'),
    (61, 190, n_cinta_b, 'PM-30 reforzado: Cinta B - Inspección RollerDrive','Inspección reforzada.','preventive','high','closed', u_angel, u_admin, 70, NULL, NULL, 'OK tras sustitución motor.'),
    (62, 160, n_cinta_b, 'PM-30 reforzado: Cinta B - Inspección RollerDrive','Inspección reforzada.','preventive','high','closed', u_angel, u_admin, 65, NULL, NULL, 'OK.'),
    (63, 100, n_pesadora, 'PM-7: Calibración pesadora MULTIPOND','Calibración semanal.','preventive','high','closed', u_angel, u_admin, 50, NULL, NULL, '14 cabezas OK.'),
    (64, 70, n_pesadora, 'PM-7: Calibración pesadora MULTIPOND','Calibración semanal.','preventive','high','closed', u_angel, u_admin, 48, NULL, NULL, 'OK.'),
    (65, 40, n_pesadora, 'PM-7: Calibración pesadora MULTIPOND','Calibración semanal.','preventive','high','closed', u_angel, u_admin, 50, NULL, NULL, 'OK.'),
    (66, 15, n_pesadora, 'PM-7: Calibración pesadora MULTIPOND','Calibración semanal.','preventive','high','closed', u_angel, u_admin, 50, NULL, NULL, 'OK.'),
    (67, 165, n_etiqueta, 'PM-30: Cambio tinta + makeup etiquetadora','Sustitución mensual.','preventive','medium','closed', u_angel, u_admin, 30, NULL, NULL, 'OK.'),
    (68, 130, n_etiqueta, 'PM-30: Cambio tinta + makeup etiquetadora','Sustitución mensual.','preventive','medium','closed', u_angel, u_admin, 32, NULL, NULL, 'OK.'),
    (69, 95, n_etiqueta, 'PM-30: Cambio tinta + makeup etiquetadora','Sustitución mensual.','preventive','medium','closed', u_angel, u_admin, 28, NULL, NULL, 'OK.'),
    (70, 60, n_etiqueta, 'PM-30: Cambio tinta + makeup etiquetadora','Sustitución mensual.','preventive','medium','closed', u_angel, u_admin, 30, NULL, NULL, 'OK.'),
    (71, 25, n_etiqueta, 'PM-30: Cambio tinta + makeup etiquetadora','Sustitución mensual.','preventive','medium','closed', u_angel, u_admin, 30, NULL, NULL, 'OK.'),
    (72, 150, n_plc, 'PM-30: Backup PLC + verificación pila','Backup mensual.','preventive','medium','closed', u_caristiven, u_admin, 30, NULL, NULL, 'Backup OK. Pila 3.0 V.'),
    (73, 90, n_plc, 'PM-30: Backup PLC + verificación pila','Backup mensual.','preventive','medium','closed', u_caristiven, u_admin, 28, NULL, NULL, 'OK.'),
    (74, 30, n_plc, 'PM-30: Backup PLC + verificación pila','Backup mensual.','preventive','medium','closed', u_caristiven, u_admin, 30, NULL, NULL, 'OK. Pila sustituida preventivamente.'),

    -- ─── EN CURSO / VENCIDAS / PENDIENTES ─────────────────────────────
    (75, 3, n_compresor, 'PM-30: Inspección filtro aire compresor',
     'Mantenimiento mensual.','preventive','low','in_progress', u_angel, u_admin, 0, NULL, NULL, NULL),
    (76, 1, n_robot, 'PM-30: Inspección correa GT2 robot ABB',
     'Mantenimiento mensual.','preventive','medium','assigned', u_angel, u_admin, 0, NULL, NULL, NULL),
    (77, 2, n_etiqueta, 'PM-30: Cambio tinta + makeup etiquetadora',
     'Mantenimiento mensual.','preventive','medium','pending', u_angel, u_admin, 0, NULL, NULL, NULL),
    (78, 0, n_pesadora, 'PM-7: Calibración pesadora MULTIPOND',
     'Calibración semanal.','preventive','high','pending', u_angel, u_admin, 0, NULL, NULL, NULL),
    (79, 5, n_cinta_b, 'Vibración cinta B - revisar',
     'Operario reporta vibración leve nuevamente. Inspección preventiva.',
     'corrective','medium','completed', u_angel, u_ysabel, 60,
     'Banda con leve desalineación, no es problema del motor (recién cambiado).',
     'mechanical','Realineación banda + ajuste tensor.'),
    (80, 8, n_vision, 'Cámara con baja calidad imagen tras turno',
     'Inspección visual del cambio.',
     'corrective','low','completed', u_angel, u_ysabel, 22,
     'Lente con grasa de producto.','environment','Limpieza extra fuera de planning.');

    -- ─── INSERT ────────────────────────────────────────────────────────
    -- Bucle: una iteración por OT
    v_dup_offset := 0;
    FOR rec IN SELECT * FROM demo_wo_defs ORDER BY days_ago DESC, seq LOOP

        -- Calcular started/completed según estado
        IF rec.status IN ('closed','verified','completed') AND rec.actual_minutes > 0 THEN
            v_started   := ((CURRENT_DATE - rec.days_ago)::timestamp + interval '8 hours')::timestamptz;
            v_completed := v_started + (rec.actual_minutes || ' minutes')::interval;
        ELSIF rec.status = 'in_progress' THEN
            v_started   := NOW() - interval '2 hours';
            v_completed := NULL;
        ELSE
            v_started := NULL;
            v_completed := NULL;
        END IF;

        v_initial_status := CASE WHEN rec.wo_type = 'preventive' THEN 'assigned' ELSE 'pending' END;

        -- Construir wo_number único: prefix día + secuencia + offset (para evitar colisión)
        v_wo_number := 'OT-' || to_char(CURRENT_DATE - rec.days_ago, 'YYYYMMDD') || '-' ||
                       lpad(rec.seq::text, 4, '0');

        INSERT INTO work_orders
            (tenant_id, node_id, wo_number, title, description, wo_type, priority, status,
             assigned_to, created_by, estimated_hours, actual_hours,
             planned_start, planned_end, started_at, completed_at, closed_at,
             root_cause, root_cause_code, solution, accumulated_minutes,
             created_at, updated_at)
        VALUES (1, rec.node_id, v_wo_number, rec.title, rec.description,
            rec.wo_type, rec.priority, rec.status,
            rec.assigned_to, rec.created_by,
            CASE WHEN rec.actual_minutes>0 THEN GREATEST(rec.actual_minutes/60.0, 0.25) ELSE 1 END,
            CASE WHEN rec.status IN ('closed','verified','completed') THEN rec.actual_minutes/60.0 ELSE NULL END,
            ((CURRENT_DATE - rec.days_ago)::timestamp + interval '7 hours')::timestamptz,
            ((CURRENT_DATE - rec.days_ago)::timestamp + interval '9 hours')::timestamptz,
            v_started,
            CASE WHEN rec.status IN ('closed','verified','completed') THEN v_completed ELSE NULL END,
            CASE WHEN rec.status = 'closed' THEN v_completed + interval '1 hour' ELSE NULL END,
            rec.root_cause, rec.root_cause_code, rec.solution, rec.actual_minutes,
            ((CURRENT_DATE - rec.days_ago)::timestamp + interval '7 hours')::timestamptz,
            COALESCE(v_completed, ((CURRENT_DATE - rec.days_ago)::timestamp + interval '7 hours')::timestamptz))
        RETURNING id INTO v_wo_id;

        -- Log inicial
        INSERT INTO work_order_log (tenant_id, wo_id, user_id, from_status, to_status, comment, created_at)
        VALUES (1, v_wo_id, rec.created_by, NULL, v_initial_status, 'OT creada',
                ((CURRENT_DATE - rec.days_ago)::timestamp + interval '7 hours')::timestamptz);

        -- Logs de transición
        IF rec.status = 'closed' THEN
            INSERT INTO work_order_log (tenant_id, wo_id, user_id, from_status, to_status, comment, created_at) VALUES
            (1, v_wo_id, rec.assigned_to, v_initial_status, 'in_progress', 'Iniciado', v_started),
            (1, v_wo_id, rec.assigned_to, 'in_progress', 'completed', 'Completado', v_completed),
            (1, v_wo_id, rec.created_by,  'completed', 'verified', 'Verificado', v_completed + interval '30 minutes'),
            (1, v_wo_id, rec.created_by,  'verified', 'closed', 'Firmado y cerrado', v_completed + interval '1 hour');
        ELSIF rec.status = 'verified' THEN
            INSERT INTO work_order_log (tenant_id, wo_id, user_id, from_status, to_status, comment, created_at) VALUES
            (1, v_wo_id, rec.assigned_to, v_initial_status, 'in_progress', 'Iniciado', v_started),
            (1, v_wo_id, rec.assigned_to, 'in_progress', 'completed', 'Completado', v_completed),
            (1, v_wo_id, rec.created_by,  'completed', 'verified', 'Verificado', v_completed + interval '30 minutes');
        ELSIF rec.status = 'completed' THEN
            INSERT INTO work_order_log (tenant_id, wo_id, user_id, from_status, to_status, comment, created_at) VALUES
            (1, v_wo_id, rec.assigned_to, v_initial_status, 'in_progress', 'Iniciado', v_started),
            (1, v_wo_id, rec.assigned_to, 'in_progress', 'completed', 'Completado', v_completed);
        ELSIF rec.status = 'in_progress' THEN
            INSERT INTO work_order_log (tenant_id, wo_id, user_id, from_status, to_status, comment, created_at) VALUES
            (1, v_wo_id, rec.assigned_to, v_initial_status, 'in_progress', 'Iniciado', v_started);
        END IF;

        -- Intervalos de trabajo
        IF rec.status IN ('closed','verified','completed') AND rec.actual_minutes > 0 THEN
            INSERT INTO work_order_intervals (tenant_id, wo_id, started_at, ended_at, ended_reason)
            VALUES (1, v_wo_id, v_started, v_completed, 'completed');
        ELSIF rec.status = 'in_progress' THEN
            INSERT INTO work_order_intervals (tenant_id, wo_id, started_at)
            VALUES (1, v_wo_id, v_started);
        END IF;

    END LOOP;

    RAISE NOTICE 'OTs creadas: %', (SELECT count(*) FROM work_orders WHERE tenant_id=1);
END $$;

COMMIT;

SELECT status, count(*) FROM work_orders WHERE tenant_id=1 GROUP BY status ORDER BY count(*) DESC;
SELECT wo_type, count(*) FROM work_orders WHERE tenant_id=1 GROUP BY wo_type;
SELECT root_cause_code, count(*) FROM work_orders WHERE tenant_id=1 AND root_cause_code IS NOT NULL
  GROUP BY root_cause_code ORDER BY count(*) DESC;
