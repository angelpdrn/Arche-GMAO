-- ============================================================
-- BonArea Demo - Block 02: Equipment templates + Manuals
-- ============================================================
-- 10 equipment_templates with real manufacturer/model values.
-- 10 maintenance_manuals with content_text (plain text for RAG).
-- ============================================================

BEGIN;

-- ─── EQUIPMENT TEMPLATES ──────────────────────────────────────────────────
INSERT INTO equipment_templates (tenant_id, manufacturer, model, category, node_type,
                                 description, notes, tags, is_active, created_by)
VALUES
-- 1. Delta robotic arm (Pick & Place, food industry)
(1, 'ABB', 'IRB 360-3/1130 FlexPicker', 'Robótica', 'equipment',
 'Robot delta de alta velocidad para selección y empaquetado de productos cárnicos. Carga 3 kg, alcance 1130 mm.',
 'IP69K certificado para lavado en línea. Hasta 200 picks/min. Software RobotWare 6.x.',
 ARRAY['robot','delta','pick-and-place','iso-IP69K','alimentario'], true, 1),

-- 2. Machine vision
(1, 'Cognex', 'In-Sight 9912', 'Visión artificial', 'equipment',
 'Cámara industrial 12 MP con iluminación integrada. Identifica producto por forma, color y código.',
 'Comunicación EtherNet/IP. Software In-Sight Explorer + EasyBuilder.',
 ARRAY['visión','cámara','identificación','HMI'], true, 1),

-- 3. Modular conveyor belt
(1, 'Interroll', 'MCP 5500-200', 'Transporte', 'equipment',
 'Cinta modular plástica grado alimentario, anchura 200 mm, longitud 5500 mm. Motor RollerDrive EC5000.',
 'Velocidad regulable 0-1.2 m/s. Limpieza CIP. Banda azul detectable por visión.',
 ARRAY['cinta','transporte','modular','grado-alimentario'], true, 1),

-- 4. Multihead weigher
(1, 'MULTIPOND', 'PMC 14-1200', 'Dosificación', 'equipment',
 'Pesadora multicabezal de 14 cabezas para producto cárnico. Precisión ±0.5 g.',
 'Pantalla táctil 12". Hasta 120 pesadas/min. Conexión OPC-UA al MES.',
 ARRAY['pesadora','dosificación','multicabezal'], true, 1),

-- 5. Print & apply labeller
(1, 'Markem-Imaje', '9450', 'Etiquetado', 'equipment',
 'Sistema de impresión y aplicación de etiquetas RFID/EAN. Velocidad 60 m/min.',
 'CIJ ink-jet, tinta soft pigment. Driver PLM 5.x. Compatible con TPV cárnico.',
 ARRAY['etiquetadora','RFID','impresión'], true, 1),

-- 6. Shrink-wrap sealer
(1, 'Sealed Air', 'CRYOVAC ST98', 'Envasado', 'equipment',
 'Túnel de retracción al vapor para envasado al vacío de productos cárnicos.',
 'Caudal 800 paquetes/h. Temperatura 85-95°C. Tiempo retracción 1.5-3.5 s.',
 ARRAY['selladora','vapor','retráctil','vacío'], true, 1),

-- 7. Control PLC
(1, 'Siemens', 'SIMATIC S7-1517F-3 PN/DP', 'Control', 'equipment',
 'PLC de seguridad failsafe para control de célula completa. CPU + 32 DI/16 DO.',
 'TIA Portal V18. Profinet + Profisafe. Redundancia opcional.',
 ARRAY['PLC','automatización','safety','profinet'], true, 1),

-- 8. Screw compressor
(1, 'Atlas Copco', 'GA22 VSD+', 'Aire comprimido', 'equipment',
 'Compresor de tornillo refrigerado por aire, variador de frecuencia. 22 kW, 3.5-13 bar.',
 'Caudal hasta 3.78 m³/min. Aceite Roto-Xtend Duty Fluid 4000h.',
 ARRAY['compresor','aire','tornillo','VSD'], true, 1),

-- 9. Variable frequency drive
(1, 'ABB', 'ACS580-01-04A1-4', 'Accionamiento', 'equipment',
 'Variador de frecuencia 1.5 kW para motores de cinta. IP21, comunicación Modbus RTU.',
 'Filtro EMC integrado. Frenado dinámico opcional. PID interno.',
 ARRAY['variador','vfd','accionamiento'], true, 1),

-- 10. Pressure sensor
(1, 'IFM Electronic', 'PN7094', 'Instrumentación', 'sensor',
 'Sensor de presión electrónico 0-10 bar con display, salida 4-20 mA + 2 PNP.',
 'IP67. Pantalla LED roja 4 dígitos. Programación por menú.',
 ARRAY['sensor','presión','4-20mA','IFM'], true, 1)

ON CONFLICT DO NOTHING;

COMMIT;

SELECT id, manufacturer, model, category FROM equipment_templates WHERE tenant_id=1 ORDER BY id;
