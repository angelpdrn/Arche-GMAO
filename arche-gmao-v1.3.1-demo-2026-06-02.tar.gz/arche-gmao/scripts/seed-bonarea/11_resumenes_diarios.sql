-- ============================================================
-- BonArea Demo - Block 11: Daily summaries + monthly folders
-- ============================================================
-- daily_summaries for Ángel/Ysabel/Caristiven over the last 9 months
-- Linked to real WOs for consistency.
-- The MonthlySummaryWorker will build the Excel + ZIP and freeze the month on startup.
-- ============================================================

BEGIN;

DO $$
DECLARE
    u_caristiven BIGINT;
    u_angel BIGINT;
    u_ysabel BIGINT;
    c_bonarea BIGINT;
    v_date DATE;
    v_shift TEXT;
    v_hours NUMERIC;
    v_obs TEXT;
    v_wo BIGINT;
    v_proj TEXT;
    i INTEGER;
    days_back INTEGER;
    weekday INTEGER;
    rnd FLOAT;
BEGIN
    SELECT id INTO u_caristiven FROM users WHERE email='caristiven.padrino@bonarea.local';
    SELECT id INTO u_angel      FROM users WHERE email='angel.padrino@bonarea.local';
    SELECT id INTO u_ysabel     FROM users WHERE email='ysabel.salazar@bonarea.local';
    SELECT id INTO c_bonarea    FROM clients WHERE tenant_id=1 AND code='BONAREA';

    -- ─── ÁNGEL (técnico) — resúmenes detallados de turnos
    -- 270 días hacia atrás (~9 meses), días laborables, alterna mañana/tarde
    FOR i IN 0..269 LOOP
        v_date := CURRENT_DATE - i;
        weekday := EXTRACT(ISODOW FROM v_date);  -- 1=Lun..7=Dom

        -- Saltarse fines de semana excepto algunos casos de retén
        IF weekday IN (6, 7) THEN
            -- 25 % de fines de semana cae como retén
            IF random() > 0.75 THEN
                v_shift := 'mañana';
                v_hours := 4 + (random()*4)::numeric(6,2);
                v_obs := 'Guardia de retén. Sin incidencias relevantes.';
                INSERT INTO daily_summaries
                    (tenant_id, user_id, summary_date, client_id, wo_id,
                     project_number, shift, shift_extras, hours, observations)
                VALUES (1, u_angel, v_date, c_bonarea, NULL, 'BONAREA-2026-01',
                        v_shift, ARRAY['fin_de_semana','reten']::TEXT[],
                        v_hours, v_obs);
            END IF;
            CONTINUE;
        END IF;

        -- Alternar turno aleatoriamente: 60 % mañana, 30 % tarde, 10 % noche
        rnd := random();
        v_shift := CASE
            WHEN rnd < 0.60 THEN 'mañana'
            WHEN rnd < 0.90 THEN 'tarde'
            ELSE 'noche'
        END;

        -- Horas: 7-9 con ocasional jornada larga
        v_hours := 7 + (random()*2)::numeric(6,2);

        -- Vincular ocasionalmente a una OT real cerrada de ese día
        SELECT id INTO v_wo FROM work_orders
        WHERE tenant_id=1 AND assigned_to = u_angel
          AND DATE(completed_at) = v_date
        LIMIT 1;

        IF v_wo IS NOT NULL THEN
            v_obs := 'Resolución de OT correctiva. ' ||
                     CASE WHEN random()>0.5 THEN 'Equipo de vuelta a producción.' ELSE 'Trabajo completado en turno.' END;
        ELSE
            -- Día sin avería: tareas rutinarias
            v_obs := CASE (random()*5)::int
                WHEN 0 THEN 'Inspección rutinaria de la célula. Sin anomalías.'
                WHEN 1 THEN 'Apoyo a producción durante cambio de producto.'
                WHEN 2 THEN 'Limpieza programada de equipos.'
                WHEN 3 THEN 'Lubricación rutinaria de cojinetes y guías.'
                WHEN 4 THEN 'Verificación de presión y caudales del compresor.'
                ELSE 'Apoyo a operario en arranque de turno.'
            END;
        END IF;

        v_proj := 'BONAREA-' || to_char(v_date, 'YYYY-MM');

        INSERT INTO daily_summaries
            (tenant_id, user_id, summary_date, client_id, wo_id,
             project_number, shift, shift_extras, hours, observations)
        VALUES (1, u_angel, v_date, c_bonarea, v_wo, v_proj,
                v_shift, ARRAY[]::TEXT[], v_hours, v_obs);
    END LOOP;

    -- ─── YSABEL (operario) — más constancia, turnos rotatorios ─────────────
    FOR i IN 0..200 LOOP
        v_date := CURRENT_DATE - i;
        weekday := EXTRACT(ISODOW FROM v_date);
        IF weekday IN (6, 7) THEN CONTINUE; END IF;

        -- Rotación semanal: lunes-miércoles mañana, jueves-viernes tarde
        v_shift := CASE WHEN weekday <= 3 THEN 'mañana' ELSE 'tarde' END;
        v_hours := 8 + (random()*0.5)::numeric(6,2);

        v_obs := CASE (random()*4)::int
            WHEN 0 THEN 'Producción nominal. Sin paradas relevantes.'
            WHEN 1 THEN 'Cambio de producto a media jornada. Producción normal.'
            WHEN 2 THEN 'Paro técnico breve. Aviso al técnico de mantenimiento.'
            WHEN 3 THEN 'Limpieza CIP al final de turno completada.'
            ELSE 'Inspección visual sin anomalías.'
        END;

        INSERT INTO daily_summaries
            (tenant_id, user_id, summary_date, client_id, wo_id,
             project_number, shift, shift_extras, hours, observations)
        VALUES (1, u_ysabel, v_date, c_bonarea, NULL,
                'BONAREA-' || to_char(v_date, 'YYYY-MM'),
                v_shift, ARRAY[]::TEXT[], v_hours, v_obs);
    END LOOP;

    -- ─── CARISTIVEN (supervisor) — más esporádico, oficina ────────────────
    FOR i IN 0..200 LOOP
        v_date := CURRENT_DATE - i;
        weekday := EXTRACT(ISODOW FROM v_date);
        IF weekday IN (6, 7) THEN CONTINUE; END IF;

        v_shift := 'mañana';  -- supervisor solo turno mañana
        v_hours := 8 + (random()*1)::numeric(6,2);

        v_obs := CASE (random()*5)::int
            WHEN 0 THEN 'Coordinación de turno. Aprobación de OTs pendientes.'
            WHEN 1 THEN 'Supervisión inspección semanal de seguridad robot.'
            WHEN 2 THEN 'Reunión con Producción y Calidad.'
            WHEN 3 THEN 'Verificación de mantenimientos preventivos completados.'
            WHEN 4 THEN 'Análisis de patrones detectados por la IA.'
            ELSE 'Tareas administrativas y firma de OTs cerradas.'
        END;

        INSERT INTO daily_summaries
            (tenant_id, user_id, summary_date, client_id, wo_id,
             project_number, shift, shift_extras, hours, observations)
        VALUES (1, u_caristiven, v_date, c_bonarea, NULL,
                'BONAREA-' || to_char(v_date, 'YYYY-MM'),
                v_shift, ARRAY[]::TEXT[], v_hours, v_obs);
    END LOOP;

    -- Festivos: insertar algunos días con shift_extras=festivo en fechas conocidas
    -- (Año Nuevo 2026, Reyes, etc — solo Ángel para mostrar el flag)
    FOR v_date IN SELECT unnest(ARRAY['2026-01-01','2026-01-06','2026-04-03','2026-05-01']::DATE[]) LOOP
        IF v_date <= CURRENT_DATE THEN
            INSERT INTO daily_summaries
                (tenant_id, user_id, summary_date, client_id, wo_id,
                 project_number, shift, shift_extras, hours, observations)
            VALUES (1, u_angel, v_date, c_bonarea, NULL,
                    'BONAREA-' || to_char(v_date, 'YYYY-MM'),
                    'mañana', ARRAY['festivo','reten']::TEXT[],
                    4.5, 'Día festivo - guardia de retén.')
            ON CONFLICT DO NOTHING;
        END IF;
    END LOOP;
END $$;

COMMIT;

-- Verification
SELECT u.full_name, count(*) AS dias, round(SUM(ds.hours)::numeric, 1) AS horas_totales,
       MIN(summary_date) AS primer, MAX(summary_date) AS ultimo
  FROM daily_summaries ds JOIN users u ON u.id = ds.user_id
  WHERE ds.tenant_id=1 GROUP BY u.id, u.full_name ORDER BY u.id;

SELECT to_char(summary_date, 'YYYY-MM') AS mes, count(*) AS dias, count(DISTINCT user_id) AS usuarios
  FROM daily_summaries WHERE tenant_id=1
  GROUP BY mes ORDER BY mes;
