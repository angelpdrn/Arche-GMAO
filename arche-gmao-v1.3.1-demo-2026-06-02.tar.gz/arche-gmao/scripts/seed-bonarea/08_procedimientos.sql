-- ============================================================
-- BonArea Demo - Block 08: Guided procedures (SOP)
-- ============================================================
-- 4 procedure_templates with interactive steps.
-- Linked to plans and/or nodes through procedure_template_links.
-- ============================================================

BEGIN;

DO $$
DECLARE
    u_admin BIGINT;
    p_inspeccion BIGINT;
    p_lubricacion BIGINT;
    p_calibracion BIGINT;
    p_emergencia BIGINT;
BEGIN
    SELECT id INTO u_admin FROM users WHERE email='admin@arche.local';

    -- ─── SOP 1: Inspección de seguridad robot ABB ──────────────────────────
    INSERT INTO procedure_templates
        (tenant_id, title, description, category, node_type_target, version, is_active, created_by, updated_by)
    VALUES (1,
        'Inspección semanal de seguridad robot ABB',
        'Procedimiento obligatorio de inspección de los sistemas de seguridad del robot delta antes de cada turno semanal.',
        'safety', 'equipment', 1, true, u_admin, u_admin)
    RETURNING id INTO p_inspeccion;

    INSERT INTO procedure_steps (template_id, step_number, title, description, step_type, is_required, config, estimated_minutes) VALUES
    (p_inspeccion, 1, 'Verificación visual del cerramiento perimetral',
        'Comprobar que no hay daños, intrusiones ni objetos sueltos.',
        'passfail', true, '{"fail_action":"stop"}'::jsonb, 2),
    (p_inspeccion, 2, 'Test de seta de emergencia (E-Stop)',
        'Pulsar la seta de emergencia y verificar que el robot se detiene en <500 ms.',
        'passfail', true, '{"fail_action":"stop"}'::jsonb, 1),
    (p_inspeccion, 3, 'Test de cortina fotoeléctrica',
        'Interrumpir la cortina con varilla patrón y verificar paro inmediato.',
        'passfail', true, '{"fail_action":"stop"}'::jsonb, 2),
    (p_inspeccion, 4, 'Lectura voltaje 24 V control',
        'Medir voltaje en bornes X1.1-X1.2.',
        'numeric', true, '{"unit":"V","min":23.5,"max":24.5,"alert_min":23.0,"alert_max":25.0}'::jsonb, 2),
    (p_inspeccion, 5, 'Foto de evidencia general',
        'Foto de la célula con cerramiento cerrado.',
        'photo', true, '{"min_photos":1,"max_photos":3}'::jsonb, 1),
    (p_inspeccion, 6, 'Firma del inspector',
        'Firma electrónica.',
        'signature', true, '{}'::jsonb, 1);

    -- ─── SOP 2: Lubricación cojinetes robot ABB ────────────────────────────
    INSERT INTO procedure_templates
        (tenant_id, title, description, category, node_type_target, version, is_active, created_by, updated_by)
    VALUES (1,
        'Lubricación trimestral cojinetes robot',
        'SOP detallado para la lubricación de los 8 cojinetes del robot delta.',
        'preventive', 'equipment', 1, true, u_admin, u_admin)
    RETURNING id INTO p_lubricacion;

    INSERT INTO procedure_steps (template_id, step_number, title, description, step_type, is_required, config, estimated_minutes) VALUES
    (p_lubricacion, 1, 'LOTO aplicado',
        'Confirmar candado y tarjeta colocados. Foto.',
        'photo', true, '{"min_photos":1,"max_photos":2}'::jsonb, 2),
    (p_lubricacion, 2, 'Limpieza puntos de engrase',
        'Limpiar los 8 puntos con paño y alcohol.',
        'checkbox', true, '{}'::jsonb, 5),
    (p_lubricacion, 3, 'Cantidad grasa aplicada',
        'Total aplicado en gramos.',
        'numeric', true, '{"unit":"g","min":35,"max":50,"alert_min":30,"alert_max":60}'::jsonb, 15),
    (p_lubricacion, 4, 'Movimiento manual sin ruidos extraños',
        'Mover los brazos sin alimentación y escuchar.',
        'passfail', true, '{"fail_action":"warn"}'::jsonb, 5),
    (p_lubricacion, 5, 'Estado general cojinetes',
        'Selección visual del estado',
        'selection', true, '{"options":["Bueno","Regular","Malo"]}'::jsonb, 2),
    (p_lubricacion, 6, 'Notas y observaciones',
        'Cualquier observación adicional.',
        'text', false, '{"max_length":500}'::jsonb, 3);

    -- ─── SOP 3: Calibración pesadora MULTIPOND ─────────────────────────────
    INSERT INTO procedure_templates
        (tenant_id, title, description, category, node_type_target, version, is_active, created_by, updated_by)
    VALUES (1,
        'Calibración 14 cabezas MULTIPOND PMC 14',
        'Calibración semanal célula a célula con pesa patrón certificada.',
        'inspection', 'equipment', 1, true, u_admin, u_admin)
    RETURNING id INTO p_calibracion;

    INSERT INTO procedure_steps (template_id, step_number, title, description, step_type, is_required, config, estimated_minutes) VALUES
    (p_calibracion, 1, 'Lectura cabeza 1', '',
        'meter_reading', true, '{"unit":"g","min":199.8,"max":200.2,"target":200.0}'::jsonb, 2),
    (p_calibracion, 2, 'Lectura cabeza 2', '',
        'meter_reading', true, '{"unit":"g","min":199.8,"max":200.2,"target":200.0}'::jsonb, 2),
    (p_calibracion, 3, 'Lectura cabeza 3', '',
        'meter_reading', true, '{"unit":"g","min":199.8,"max":200.2,"target":200.0}'::jsonb, 2),
    (p_calibracion, 4, 'Lectura cabezas 4 a 14',
        'Continuar el proceso para las 11 cabezas restantes.',
        'checkbox', true, '{}'::jsonb, 22),
    (p_calibracion, 5, '¿Alguna cabeza fuera de tolerancia?',
        '',
        'passfail', true, '{"fail_action":"continue"}'::jsonb, 1),
    (p_calibracion, 6, 'Certificado impreso',
        'Imprimir certificado y archivar en carpeta HACCP.',
        'photo', true, '{"min_photos":1,"max_photos":1}'::jsonb, 2),
    (p_calibracion, 7, 'Firma técnico',
        '', 'signature', true, '{}'::jsonb, 1);

    -- ─── SOP 4: Parada de emergencia de la célula ──────────────────────────
    INSERT INTO procedure_templates
        (tenant_id, title, description, category, node_type_target, version, is_active, created_by, updated_by)
    VALUES (1,
        'Parada de emergencia controlada de la célula',
        'Procedimiento ordenado para detener toda la célula sin generar producto en cuarentena.',
        'safety', 'composition', 1, true, u_admin, u_admin)
    RETURNING id INTO p_emergencia;

    INSERT INTO procedure_steps (template_id, step_number, title, description, step_type, is_required, config, estimated_minutes) VALUES
    (p_emergencia, 1, 'Avisar al supervisor',
        'Notificar verbalmente al supervisor de turno.',
        'checkbox', true, '{}'::jsonb, 1),
    (p_emergencia, 2, 'Pulsar paro de línea (no E-Stop)',
        'Usar botón rojo del HMI principal, NO la seta a no ser que sea peligro inminente.',
        'checkbox', true, '{}'::jsonb, 1),
    (p_emergencia, 3, 'Vaciado de cintas',
        'Esperar a que las cintas A/B/C se vacíen completamente.',
        'checkbox', true, '{}'::jsonb, 3),
    (p_emergencia, 4, 'Parada selladora',
        'Selladora debe terminar el lote en curso antes de detenerse.',
        'checkbox', true, '{}'::jsonb, 2),
    (p_emergencia, 5, 'Cuántos paquetes han quedado en cuarentena',
        '0 si todo OK',
        'numeric', true, '{"unit":"ud","min":0,"max":500,"alert_max":10}'::jsonb, 2),
    (p_emergencia, 6, 'Razón de la parada',
        '', 'selection', true,
        '{"options":["Mantenimiento programado","Avería","Cambio de producto","Limpieza","Otra"]}'::jsonb, 1),
    (p_emergencia, 7, 'Observaciones',
        '', 'text', false, '{"max_length":500}'::jsonb, 2);

    -- ─── Vincular SOPs a planes y nodos ───────────────────────────────────
    -- Inspección semanal robot → al nodo robot
    INSERT INTO procedure_template_links (tenant_id, template_id, node_id)
    VALUES (1, p_inspeccion, (SELECT id FROM bonarea_demo_ids WHERE key='robot'));

    -- Lubricación robot → al plan PM-90
    INSERT INTO procedure_template_links (tenant_id, template_id, maintenance_plan_id)
    SELECT 1, p_lubricacion, mp.id FROM maintenance_plans mp
    WHERE mp.tenant_id=1 AND mp.title='PM-90: Lubricación cojinetes robot ABB';

    -- Calibración pesadora → al plan PM-7
    INSERT INTO procedure_template_links (tenant_id, template_id, maintenance_plan_id)
    SELECT 1, p_calibracion, mp.id FROM maintenance_plans mp
    WHERE mp.tenant_id=1 AND mp.title='PM-7: Calibración pesadora MULTIPOND';

    -- Parada de emergencia → al nodo composición
    INSERT INTO procedure_template_links (tenant_id, template_id, node_id)
    VALUES (1, p_emergencia, (SELECT id FROM bonarea_demo_ids WHERE key='comp_node'));

    -- Guardar IDs para uso posterior
    INSERT INTO bonarea_demo_ids VALUES ('sop_inspeccion', p_inspeccion), ('sop_lubricacion', p_lubricacion),
        ('sop_calibracion', p_calibracion), ('sop_emergencia', p_emergencia)
    ON CONFLICT (key) DO UPDATE SET id=EXCLUDED.id;
END $$;

COMMIT;

SELECT id, title, category, version, is_active FROM procedure_templates WHERE tenant_id=1 ORDER BY id;
SELECT t.title, count(s.id) AS pasos
  FROM procedure_templates t
  LEFT JOIN procedure_steps s ON s.template_id = t.id
  WHERE t.tenant_id=1 GROUP BY t.id, t.title ORDER BY t.id;
SELECT count(*) AS vinculos FROM procedure_template_links WHERE tenant_id=1;
