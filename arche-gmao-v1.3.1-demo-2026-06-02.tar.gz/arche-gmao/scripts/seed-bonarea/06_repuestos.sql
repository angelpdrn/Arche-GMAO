-- ============================================================
-- BonArea Demo - Block 06: Spare parts + links to equipment
-- ============================================================
-- ~22 spare parts. Some below the minimum so the PatternDetector
-- low-stock detector fires.
-- ============================================================

BEGIN;

INSERT INTO spare_parts
    (tenant_id, code, name, category, unit, current_stock, min_stock, max_stock,
     location, supplier, supplier_ref, unit_price, lead_days, notes, is_active)
VALUES
-- ABB robot (conveyor composition)
(1, 'RP-ABB-CORREA-GT2', 'Correa GT2 800 mm rótula central robot ABB IRB360', 'mecánica', 'ud',
  3, 2, 6, 'Almacén central, estante A-1', 'ABB Robotics Spain', '3HAC027433-001', 142.00, 14,
  'Crítico: rotura provoca paro de toda la línea', true),

(1, 'RP-ABB-GRASA-MOBI', 'Grasa Mobilith SHC 220 (cartucho 400 g)', 'lubricación', 'ud',
  6, 3, 12, 'Almacén lubricantes', 'Brammer', 'MOBI-SHC-220', 18.50, 7,
  'Para articulaciones del robot', true),

(1, 'RP-ABB-VENTOSA-ALI', 'Ventosa silicona alimentaria FDA Ø50 mm', 'neumática', 'ud',
  12, 6, 24, 'Almacén central, estante B-2', 'Schmalz Iberia', 'SAB-50-NBR-G18', 8.75, 5,
  'Repuesto frecuente, desgaste por contacto con producto', true),

-- Cognex
(1, 'RP-COG-LENS-CL', 'Limpiador para óptica Cognex VL-CL (botella 250 ml)', 'consumible', 'ud',
  4, 2, 8, 'Almacén central, estante C-3', 'Cognex Iberia', 'VL-CL-250', 24.00, 10, NULL, true),

(1, 'RP-COG-LED-RING', 'Anillo iluminador LED 12 V para In-Sight 9912', 'eléctrica', 'ud',
  1, 2, 3, 'Almacén central, estante C-1', 'Cognex Iberia', 'IS-LED-12V', 215.00, 21,
  'Stock CRÍTICO bajo mínimo: pedir', true),

-- Interroll conveyors
(1, 'RP-INT-EC5000', 'Motor RollerDrive Interroll EC5000-200-50', 'eléctrica', 'ud',
  0, 2, 4, 'Pedido en curso', 'Interroll Iberia', 'EC5000-200-50', 845.00, 18,
  'Stock VACÍO: tres sustituciones en CTA-B en 90 días, pedir más', true),

(1, 'RP-INT-RODAM-6203', 'Rodamiento SKF 6203-2RS', 'mecánica', 'ud',
  10, 4, 20, 'Almacén central, estante A-2', 'Brammer', 'SKF-6203-2RS', 6.20, 3, NULL, true),

(1, 'RP-INT-BANDA-MOD', 'Eslabón modular Intralox S400 azul (1 m)', 'consumible', 'ud',
  5, 2, 10, 'Almacén central, estante B-4', 'Intralox Iberia', 'S400-AZ-1M', 38.00, 7,
  'Banda modular grado alimentario', true),

(1, 'RP-INT-CABLE-M12', 'Cable M12 5 m alimentación + datos RollerDrive', 'eléctrica', 'ud',
  4, 2, 8, 'Almacén central, estante C-2', 'Interroll Iberia', 'PD-CBL-M12-5M', 42.50, 14, NULL, true),

-- MULTIPOND
(1, 'RP-MUL-CELDA-KMD', 'Célula de carga MULTIPOND KMD-208', 'instrumentación', 'ud',
  2, 2, 4, 'Almacén instrumentación, A-1', 'MULTIPOND Iberia', 'KMD-208', 480.00, 30,
  'Sustituir si calibración fuera de tolerancia', true),

-- Markem-Imaje
(1, 'RP-MAR-TINTA-CIJ', 'Cartucho tinta CIJ Markem 9450 negro', 'consumible', 'ud',
  6, 4, 12, 'Almacén consumibles', 'Markem-Imaje Iberia', 'MX-820-BK', 95.00, 7,
  'Consumo medio: 1 cartucho/semana', true),

(1, 'RP-MAR-MAKEUP', 'Solvente makeup Markem 9450 (5 L)', 'consumible', 'ud',
  3, 3, 6, 'Almacén consumibles', 'Markem-Imaje Iberia', 'MX-MK-5L', 64.00, 7, NULL, true),

-- CRYOVAC sealer
(1, 'RP-CRY-NZL-12', 'Juego boquillas vapor ST98 (12 ud)', 'mecánica', 'ud',
  1, 1, 2, 'Almacén central, estante D-1', 'Sealed Air Iberia', 'ST98-NZL-12', 320.00, 21, NULL, true),

(1, 'RP-CRY-SENS-PT100', 'Sonda PT100 ST98 sumergible', 'instrumentación', 'ud',
  2, 1, 4, 'Almacén instrumentación', 'Endress+Hauser', 'TR47-PT100', 110.00, 14, NULL, true),

-- Siemens PLC
(1, 'RP-SIE-CR2032', 'Pila litio CR2032 PLC S7', 'consumible', 'ud',
  20, 5, 30, 'Almacén consumibles', 'RS Components', 'RS-456-2123', 1.20, 1, NULL, true),

(1, 'RP-SIE-DI16', 'Tarjeta DI 16x24V S7-1500 6ES7521', 'eléctrica', 'ud',
  1, 1, 2, 'Almacén central, estante E-1', 'Siemens Spain', '6ES7521-1BH00-0AB0', 380.00, 21, NULL, true),

-- Atlas Copco compressor
(1, 'RP-ATL-OIL-ROTO', 'Aceite Roto-Xtend Duty Fluid 4000h (20 L)', 'lubricación', 'ud',
  4, 2, 6, 'Almacén lubricantes', 'Atlas Copco Iberia', '1630-2076-00', 175.00, 7,
  'Cambio cada 4000h, capacidad 7.5 L por unidad', true),

(1, 'RP-ATL-FILT-OIL', 'Filtro de aceite GA22', 'mecánica', 'ud',
  3, 2, 6, 'Almacén central, estante F-1', 'Atlas Copco Iberia', '1622-3651-00', 38.00, 7, NULL, true),

(1, 'RP-ATL-FILT-SEP', 'Filtro separador GA22', 'mecánica', 'ud',
  2, 1, 3, 'Almacén central, estante F-2', 'Atlas Copco Iberia', '1622-3148-00', 95.00, 14, NULL, true),

(1, 'RP-ATL-FILT-AIR', 'Filtro de aire GA22', 'consumible', 'ud',
  4, 2, 6, 'Almacén central, estante F-3', 'Atlas Copco Iberia', '1613-7406-00', 42.00, 7, NULL, true),

-- General
(1, 'RP-GEN-FUSE-10A', 'Fusible 10 A clase gG 10x38 mm', 'eléctrica', 'ud',
  35, 10, 50, 'Almacén eléctrico', 'Schneider Electric', 'DF2GA10', 1.85, 3, NULL, true),

(1, 'RP-GEN-RELE-24V', 'Relé Phoenix Contact PLC-RSC-24DC/21 24 V', 'eléctrica', 'ud',
  8, 4, 16, 'Almacén eléctrico', 'Phoenix Contact', '2966171', 6.50, 5, NULL, true),

(1, 'RP-GEN-EPI-GUANT', 'Guantes térmicos clase 3 (par)', 'EPI', 'par',
  6, 3, 12, 'Almacén EPI', 'Industrial Starter', 'IS-TH3-09', 28.00, 7,
  'Obligatorio para intervención en CRYOVAC', true)

ON CONFLICT (tenant_id, code) DO NOTHING;

-- ─── Link spare parts to nodes ────────────────────────────────────────────
-- ABB robot
INSERT INTO spare_part_nodes (spare_part_id, node_id)
SELECT sp.id, (SELECT id FROM bonarea_demo_ids WHERE key='robot')
FROM spare_parts sp WHERE sp.tenant_id=1 AND sp.code IN ('RP-ABB-CORREA-GT2','RP-ABB-GRASA-MOBI','RP-ABB-VENTOSA-ALI')
ON CONFLICT DO NOTHING;

-- Cognex
INSERT INTO spare_part_nodes (spare_part_id, node_id)
SELECT sp.id, (SELECT id FROM bonarea_demo_ids WHERE key='vision')
FROM spare_parts sp WHERE sp.tenant_id=1 AND sp.code IN ('RP-COG-LENS-CL','RP-COG-LED-RING')
ON CONFLICT DO NOTHING;

-- Conveyors A, B, C — they all share the same spare parts
INSERT INTO spare_part_nodes (spare_part_id, node_id)
SELECT sp.id, n.id
FROM spare_parts sp,
     (SELECT id FROM bonarea_demo_ids WHERE key IN ('cinta_a','cinta_b','cinta_c')) n
WHERE sp.tenant_id=1 AND sp.code IN ('RP-INT-EC5000','RP-INT-RODAM-6203','RP-INT-BANDA-MOD','RP-INT-CABLE-M12')
ON CONFLICT DO NOTHING;

-- Weigher
INSERT INTO spare_part_nodes (spare_part_id, node_id)
SELECT sp.id, (SELECT id FROM bonarea_demo_ids WHERE key='pesadora')
FROM spare_parts sp WHERE sp.tenant_id=1 AND sp.code='RP-MUL-CELDA-KMD'
ON CONFLICT DO NOTHING;

-- Labeller
INSERT INTO spare_part_nodes (spare_part_id, node_id)
SELECT sp.id, (SELECT id FROM bonarea_demo_ids WHERE key='etiqueta')
FROM spare_parts sp WHERE sp.tenant_id=1 AND sp.code IN ('RP-MAR-TINTA-CIJ','RP-MAR-MAKEUP')
ON CONFLICT DO NOTHING;

-- Sealer
INSERT INTO spare_part_nodes (spare_part_id, node_id)
SELECT sp.id, (SELECT id FROM bonarea_demo_ids WHERE key='selladora')
FROM spare_parts sp WHERE sp.tenant_id=1 AND sp.code IN ('RP-CRY-NZL-12','RP-CRY-SENS-PT100','RP-GEN-EPI-GUANT')
ON CONFLICT DO NOTHING;

-- PLC
INSERT INTO spare_part_nodes (spare_part_id, node_id)
SELECT sp.id, (SELECT id FROM bonarea_demo_ids WHERE key='plc')
FROM spare_parts sp WHERE sp.tenant_id=1 AND sp.code IN ('RP-SIE-CR2032','RP-SIE-DI16')
ON CONFLICT DO NOTHING;

-- Compressor
INSERT INTO spare_part_nodes (spare_part_id, node_id)
SELECT sp.id, (SELECT id FROM bonarea_demo_ids WHERE key='compresor')
FROM spare_parts sp WHERE sp.tenant_id=1 AND sp.code IN ('RP-ATL-OIL-ROTO','RP-ATL-FILT-OIL','RP-ATL-FILT-SEP','RP-ATL-FILT-AIR')
ON CONFLICT DO NOTHING;

-- General (electrical, shared by several)
INSERT INTO spare_part_nodes (spare_part_id, node_id)
SELECT sp.id, n.id
FROM spare_parts sp,
     (SELECT id FROM bonarea_demo_ids WHERE key IN ('plc','etiqueta','vision')) n
WHERE sp.tenant_id=1 AND sp.code IN ('RP-GEN-FUSE-10A','RP-GEN-RELE-24V')
ON CONFLICT DO NOTHING;

COMMIT;

SELECT code, name, current_stock, min_stock,
       CASE WHEN current_stock <= min_stock THEN 'BAJO' ELSE 'OK' END AS estado
  FROM spare_parts WHERE tenant_id=1 ORDER BY code;
SELECT count(*) AS total_relaciones FROM spare_part_nodes;
