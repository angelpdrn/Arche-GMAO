-- ============================================================
-- BonArea Demo - Block 13: Queue everything into ai_index_queue
-- ============================================================
-- The IndexWorker (every 10 s) processes them one by one with Ollama,
-- generating 768d embeddings. The pattern detector fires
-- automatically once work_orders are indexed.
-- ============================================================

BEGIN;

-- node_info for every node
INSERT INTO ai_index_queue (tenant_id, source_type, source_id, action, priority, status)
SELECT 1, 'node_info', id, 'index', 5, 'pending'
  FROM factory_nodes WHERE tenant_id=1
ON CONFLICT DO NOTHING;

-- work_order for every closed WO (better context)
INSERT INTO ai_index_queue (tenant_id, source_type, source_id, action, priority, status)
SELECT 1, 'work_order', id, 'index', 3, 'pending'
  FROM work_orders WHERE tenant_id=1
    AND status IN ('closed','verified','completed')
ON CONFLICT DO NOTHING;

-- maintenance_manual
INSERT INTO ai_index_queue (tenant_id, source_type, source_id, action, priority, status)
SELECT 1, 'maintenance_manual', id, 'index', 2, 'pending'
  FROM maintenance_manuals WHERE tenant_id=1
ON CONFLICT DO NOTHING;

-- spare_part
INSERT INTO ai_index_queue (tenant_id, source_type, source_id, action, priority, status)
SELECT 1, 'spare_part', id, 'index', 4, 'pending'
  FROM spare_parts WHERE tenant_id=1
ON CONFLICT DO NOTHING;

-- maintenance_plan
INSERT INTO ai_index_queue (tenant_id, source_type, source_id, action, priority, status)
SELECT 1, 'maintenance_plan', id, 'index', 4, 'pending'
  FROM maintenance_plans WHERE tenant_id=1
ON CONFLICT DO NOTHING;

-- knowledge
INSERT INTO ai_index_queue (tenant_id, source_type, source_id, action, priority, status)
SELECT 1, 'knowledge', id, 'index', 1, 'pending'
  FROM ai_knowledge WHERE tenant_id=1
ON CONFLICT DO NOTHING;

COMMIT;

SELECT source_type, count(*) FROM ai_index_queue
  WHERE tenant_id=1 AND status='pending' GROUP BY source_type ORDER BY source_type;
