#!/bin/bash
# ============================================================
# setup-ubuntu.sh
# Installs EVERYTHING needed on a clean Ubuntu for Arche GMAO
# ============================================================
set -e

echo "╔══════════════════════════════════════════════╗"
echo "║  Arche GMAO — Setup completo Ubuntu        ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# ─── 1. BASE PACKAGES ─────────────────────────────────────
echo "[1/5] Instalando paquetes base..."
sudo apt-get update -q
sudo apt-get install -y -q \
    git \
    make \
    curl \
    wget \
    ca-certificates \
    gnupg \
    lsb-release \
    htop \
    net-tools

# ─── 2. DOCKER + COMPOSE ──────────────────────────────────
echo ""
echo "[2/5] Instalando Docker..."

if command -v docker &>/dev/null; then
    echo "  Docker ya instalado: $(docker --version)"
else
    sudo install -m 0755 -d /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
        | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
    sudo chmod a+r /etc/apt/keyrings/docker.gpg

    echo \
      "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
      https://download.docker.com/linux/ubuntu \
      $(. /etc/os-release && echo "$VERSION_CODENAME") stable" \
      | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

    sudo apt-get update -q
    sudo apt-get install -y -q \
        docker-ce \
        docker-ce-cli \
        containerd.io \
        docker-buildx-plugin \
        docker-compose-plugin

    sudo usermod -aG docker "$USER"
    echo "  Docker instalado: $(docker --version)"
fi

# ─── 3. OLLAMA ─────────────────────────────────────────────
echo ""
echo "[3/5] Instalando Ollama..."

if command -v ollama &>/dev/null; then
    echo "  Ollama ya instalado: $(ollama --version)"
else
    curl -fsSL https://ollama.com/install.sh | sh
    echo "  Ollama instalado"
fi

# Make sure ollama is running
if ! systemctl is-active --quiet ollama 2>/dev/null; then
    sudo systemctl enable ollama
    sudo systemctl start ollama
    echo "  Servicio ollama iniciado"
fi

# Wait for ollama to be ready
echo "  Esperando a que Ollama esté listo..."
for i in $(seq 1 15); do
    if curl -s http://localhost:11434/api/tags &>/dev/null; then
        break
    fi
    sleep 2
done

# ─── 4. AI MODELS ─────────────────────────────────────────
echo ""
echo "[4/5] Descargando modelos IA (esto tarda unos minutos)..."

echo "  Descargando llama3..."
ollama pull llama3

echo "  Descargando nomic-embed-text..."
ollama pull nomic-embed-text

# ─── 5. VERIFICATION ──────────────────────────────────────
echo ""
echo "[5/5] Verificando instalacion..."
echo ""
echo "  Docker:          $(docker --version 2>/dev/null || echo 'NO INSTALADO')"
echo "  Docker Compose:  $(docker compose version 2>/dev/null || echo 'NO INSTALADO')"
echo "  Git:             $(git --version 2>/dev/null || echo 'NO INSTALADO')"
echo "  Make:            $(make --version | head -1 2>/dev/null || echo 'NO INSTALADO')"
echo "  Ollama:          $(ollama --version 2>/dev/null || echo 'NO INSTALADO')"
echo ""

echo "╔══════════════════════════════════════════════╗"
echo "║  Instalacion completada                      ║"
echo "╚══════════════════════════════════════════════╝"
echo ""
echo "IMPORTANTE: Cierra sesion y vuelve a entrar para"
echo "que el grupo docker surta efecto, o ejecuta:"
echo ""
echo "  newgrp docker"
echo ""
echo "Luego clona el proyecto y arrancalo:"
echo ""
echo "  git clone <tu-repo> arche-gmao"
echo "  cd arche-gmao"
echo "  make up"
echo ""
echo "  Frontend: http://localhost:5173"
echo "  API:      http://localhost:3000/api/v1/health"
echo "  Login:    admin@arche.local / Admin@1234"
echo ""
