#!/bin/bash
# ============================================================
# arche-preflight.sh
# Automatic check at system startup.
# Verifies that everything is installed and installs whatever is missing.
# Designed for SSDs that boot on different devices.
# ============================================================
set -e

LOG="/var/log/arche-preflight.log"
ARCHE_DIR="/home/angel/arche-gmao"
NEED_REBOOT=0

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG"
}

log "========== Arche Preflight iniciado =========="
log "Hostname: $(hostname)"
log "Kernel:   $(uname -r)"
log "CPU:      $(grep -m1 'model name' /proc/cpuinfo | cut -d: -f2 | xargs)"
log "RAM:      $(free -h | awk '/Mem:/{print $2}')"
log "GPU:      $(lspci 2>/dev/null | grep -i 'vga\|3d\|display' | head -1 || echo 'no detectada')"

# ─── 1. BASE PACKAGES ─────────────────────────────────────
PKGS_NEEDED=""
for pkg in git make curl wget ca-certificates gnupg lsb-release htop net-tools; do
    if ! dpkg -s "$pkg" &>/dev/null; then
        PKGS_NEEDED="$PKGS_NEEDED $pkg"
    fi
done

if [ -n "$PKGS_NEEDED" ]; then
    log "[1/5] Instalando paquetes base:$PKGS_NEEDED"
    apt-get update -qq
    apt-get install -y -qq $PKGS_NEEDED
    log "  Paquetes base OK"
else
    log "[1/5] Paquetes base OK"
fi

# ─── 2. DOCKER ────────────────────────────────────────────
if command -v docker &>/dev/null && command -v containerd &>/dev/null; then
    log "[2/5] Docker OK ($(docker --version))"
else
    log "[2/5] Docker no encontrado, instalando..."
    install -m 0755 -d /etc/apt/keyrings

    if [ ! -f /etc/apt/keyrings/docker.gpg ]; then
        curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
            | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
        chmod a+r /etc/apt/keyrings/docker.gpg
    fi

    CODENAME=$(. /etc/os-release && echo "$VERSION_CODENAME")
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $CODENAME stable" \
        > /etc/apt/sources.list.d/docker.list

    apt-get update -qq
    apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

    systemctl enable docker
    systemctl start docker

    # Make sure user angel is in the docker group
    usermod -aG docker angel

    log "  Docker instalado: $(docker --version)"
fi

# Check that docker is running
if ! systemctl is-active --quiet docker; then
    log "  Docker no estaba corriendo, iniciando..."
    systemctl start docker
fi

# ─── 3. OLLAMA ────────────────────────────────────────────
if command -v ollama &>/dev/null; then
    log "[3/5] Ollama OK ($(ollama --version 2>/dev/null || echo 'instalado'))"
else
    log "[3/5] Ollama no encontrado, instalando..."
    curl -fsSL https://ollama.com/install.sh | sh
    log "  Ollama instalado"
fi

# Make sure ollama is running
if ! systemctl is-active --quiet ollama; then
    log "  Ollama no estaba corriendo, iniciando..."
    systemctl enable ollama
    systemctl start ollama
fi

# Wait for ollama to respond
log "  Esperando a Ollama..."
for i in $(seq 1 20); do
    if curl -s http://localhost:11434/api/tags &>/dev/null; then
        break
    fi
    sleep 2
done

# ─── 4. AI MODELS ────────────────────────────────────────
MODELS_OK=1

if ! sudo -u angel ollama list 2>/dev/null | grep -q "llama3"; then
    log "[4/5] Descargando modelo llama3..."
    sudo -u angel ollama pull llama3
    MODELS_OK=0
fi

if ! sudo -u angel ollama list 2>/dev/null | grep -q "nomic-embed-text"; then
    log "  Descargando modelo nomic-embed-text..."
    sudo -u angel ollama pull nomic-embed-text
    MODELS_OK=0
fi

if [ $MODELS_OK -eq 1 ]; then
    log "[4/5] Modelos IA OK"
else
    log "[4/5] Modelos IA descargados"
fi

# ─── 5. PROJECT ──────────────────────────────────────────
if [ -f "$ARCHE_DIR/docker-compose.yml" ]; then
    log "[5/5] Proyecto encontrado en $ARCHE_DIR"
else
    log "[5/5] ADVERTENCIA: No se encontró docker-compose.yml en $ARCHE_DIR"
fi

# ─── SUMMARY ──────────────────────────────────────────────
log "========== Preflight completado =========="
log "  Docker:     $(docker --version 2>/dev/null || echo 'FALTA')"
log "  Compose:    $(docker compose version 2>/dev/null || echo 'FALTA')"
log "  Ollama:     $(ollama --version 2>/dev/null || echo 'FALTA')"
log "  Git:        $(git --version 2>/dev/null || echo 'FALTA')"
log "  Proyecto:   $([ -f $ARCHE_DIR/docker-compose.yml ] && echo 'OK' || echo 'NO ENCONTRADO')"
log "============================================"

exit 0
