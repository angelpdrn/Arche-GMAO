#!/bin/bash
# ─── Arche GMAO — Security hardening script ──────────────────────────
# Run as root: sudo bash scripts/security-setup.sh
#
# This script configures:
# 1. UFW (firewall)
# 2. fail2ban (brute force protection)
# 3. Security kernel parameters
# 4. File permissions
# 5. Secure secret generation

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log() { echo -e "${GREEN}[ARCHE]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; }

if [ "$EUID" -ne 0 ]; then
  error "Este script debe ejecutarse como root (sudo)"
  exit 1
fi

# ─── 1. UFW Firewall ─────────────────────────────────────────────────────────
log "Configurando UFW..."

apt-get update -qq && apt-get install -y -qq ufw fail2ban > /dev/null 2>&1

# Reset and set default policies
ufw --force reset > /dev/null 2>&1
ufw default deny incoming
ufw default allow outgoing

# SSH — ALWAYS allow it so we do not lock ourselves out
ufw allow 22/tcp comment 'SSH'

# HTTP and HTTPS (for Nginx in production)
ufw allow 80/tcp comment 'HTTP'
ufw allow 443/tcp comment 'HTTPS'

# Do NOT open the PostgreSQL (5432), Redis (6379) or API (3000) ports to the outside
# These services are only reachable over the internal Docker network

# Rate limiting on SSH to prevent brute force
ufw limit ssh

# Enable UFW
ufw --force enable
log "UFW configurado y activado"
ufw status verbose

# ─── 2. fail2ban ─────────────────────────────────────────────────────────────
log "Configurando fail2ban..."

cat > /etc/fail2ban/jail.local << 'FAIL2BAN'
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 5
backend = systemd

[sshd]
enabled = true
port = ssh
filter = sshd
maxretry = 3
bantime = 7200
FAIL2BAN

systemctl enable fail2ban > /dev/null 2>&1
systemctl restart fail2ban
log "fail2ban configurado (SSH: 3 intentos, ban 2h)"

# ─── 3. Security kernel parameters ────────────────────────────────────
log "Aplicando parámetros de seguridad del kernel..."

cat > /etc/sysctl.d/99-arche-security.conf << 'SYSCTL'
# IP spoofing protection
net.ipv4.conf.all.rp_filter = 1
net.ipv4.conf.default.rp_filter = 1

# No aceptar source routing
net.ipv4.conf.all.accept_source_route = 0
net.ipv4.conf.default.accept_source_route = 0

# Ignorar broadcasts ICMP (prevenir Smurf attacks)
net.ipv4.icmp_echo_ignore_broadcasts = 1

# SYN flood protection
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_max_syn_backlog = 2048
net.ipv4.tcp_synack_retries = 2

# No aceptar ICMP redirects (prevenir MITM)
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.default.accept_redirects = 0
net.ipv4.conf.all.secure_redirects = 0

# No enviar ICMP redirects
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.default.send_redirects = 0

# Log de paquetes sospechosos
net.ipv4.conf.all.log_martians = 1
net.ipv4.conf.default.log_martians = 1

# Deshabilitar IPv6 si no se usa
net.ipv6.conf.all.disable_ipv6 = 1
net.ipv6.conf.default.disable_ipv6 = 1

# Memory protection
kernel.randomize_va_space = 2
SYSCTL

sysctl --system > /dev/null 2>&1
log "Parámetros de kernel aplicados"

# ─── 4. File permissions ─────────────────────────────────────────────────
log "Ajustando permisos..."

ARCHE_DIR="$(cd "$(dirname "$0")/.." && pwd)"

# Protect sensitive files
if [ -f "$ARCHE_DIR/.env" ]; then
  chmod 600 "$ARCHE_DIR/.env"
  log "Permisos de .env: 600"
fi

# Make sure the migrations are not writable
if [ -d "$ARCHE_DIR/migrations" ]; then
  chmod 644 "$ARCHE_DIR/migrations"/*.sql 2>/dev/null || true
fi

# ─── 5. Generate secure secrets ─────────────────────────────────────────────
log ""
log "─── SECRETOS PARA PRODUCCIÓN ───"
log "Agrega estos valores a tu archivo .env:"
echo ""
echo "JWT_SECRET=$(openssl rand -base64 64 | tr -d '\n')"
echo "JWT_REFRESH_SECRET=$(openssl rand -base64 64 | tr -d '\n')"
echo "DB_PASSWORD=$(openssl rand -base64 32 | tr -d '\n' | tr -d '/')"
echo "REDIS_PASSWORD=$(openssl rand -base64 32 | tr -d '\n' | tr -d '/')"
echo ""

# ─── 6. Docker protection ────────────────────────────────────────────────────
log "Verificando configuración Docker..."

# Make sure Docker does not expose iptables ports outside UFW control
DOCKER_DAEMON="/etc/docker/daemon.json"
if [ ! -f "$DOCKER_DAEMON" ] || ! grep -q '"iptables": false' "$DOCKER_DAEMON" 2>/dev/null; then
  warn "Docker puede bypassear UFW. Para prevenir esto:"
  warn "Agrega a /etc/docker/daemon.json:"
  echo '  { "iptables": false }'
  warn "Y reinicia Docker: sudo systemctl restart docker"
  warn "NOTA: Luego necesitarás configurar NAT manualmente o usar docker-compose con 127.0.0.1"
fi

# ─── Summary ──────────────────────────────────────────────────────────────────
echo ""
log "═══════════════════════════════════════════════"
log "   Hardening completado"
log "═══════════════════════════════════════════════"
log ""
log "Protecciones activas:"
log "  - UFW firewall (solo SSH, HTTP, HTTPS)"
log "  - fail2ban (protección brute force SSH)"
log "  - Kernel hardening (SYN flood, spoofing, etc.)"
log "  - Docker: puertos bind a 127.0.0.1"
log "  - PostgreSQL/Redis: sin puertos expuestos"
log ""
log "IMPORTANTE: Recuerda configurar tu .env con los"
log "secretos generados arriba antes de ir a producción."
